<?php
/**
 * Plugin Name:       WP-Phishing
 * Plugin URI:        https://github.com/alltimeuk/wp-phishing
 * Description:       Self-service and consultant-operated phishing simulation and human-risk assessment platform.
 * Version:           0.1.1
 * Requires at least: 6.6
 * Requires PHP:      8.2
 * Author:            Simon Jackson @ Alltime Technologies Ltd
 * Author URI:        https://alltimetech.co.uk
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-phishing
 * Domain Path:       /languages
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WPP_VERSION        = '0.1.1';
const WPP_SCHEMA_VERSION = 10;

/**
 * This plugin's identifier on the shared Alltime\CustomerPlatform usage ledger and entitlement
 * contracts (Section 49/50) - distinguishes wp-phishing's own rows from a co-installed sibling
 * plugin's, since both write to the same physical shared tables.
 */
const WPP_PRODUCT_ID = 'wp-phishing';

if ( ! defined( __NAMESPACE__ . '\WPP_PLUGIN_FILE' ) ) {
	define( __NAMESPACE__ . '\WPP_PLUGIN_FILE', __FILE__ );
	define( __NAMESPACE__ . '\WPP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
	define( __NAMESPACE__ . '\WPP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	define( __NAMESPACE__ . '\WPP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}

$wpp_autoloader = WPP_PLUGIN_DIR . 'vendor/autoload.php';

if ( ! file_exists( $wpp_autoloader ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html__( 'WP-Phishing cannot start because its Composer dependencies are not installed. Run "composer install" in the plugin directory.', 'wp-phishing' )
			);
		}
	);
	return;
}

require_once $wpp_autoloader;

register_activation_hook( __FILE__, array( Support\Plugin::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( Support\Plugin::class, 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function (): void {
		Support\Plugin::instance()->boot();
	}
);

// Plugin updater - runs in admin and WP-Cron contexts only, which is where WordPress's update
// checks actually fire; no need to load it on every public request.
if ( is_admin() || wp_doing_cron() ) {
	add_action(
		'plugins_loaded',
		static function (): void {
			new Support\Updater();
		}
	);
}
