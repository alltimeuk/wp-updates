# Changelog

## 0.1.1 - 2026-09-08

Hotfix: v0.1.0's activation failed outright on real MySQL 8.0+/MariaDB 10.2+ - the very first
real-world install (this plugin's schema had never been run against genuine MySQL before; the
project's own integration test harness runs against a SQLite shim, not MySQL, so this was
invisible until now):

- `wpp_recipient_import_rows`' `row_number` column is renamed to `row_index`. `ROW_NUMBER` became
  a reserved word once MySQL 8.0/MariaDB 10.2 added window functions, and dbDelta does not
  reliably support backtick-quoted column names, so an unquoted `row_number` column failed the
  `CREATE TABLE` statement outright with a syntax error, which stopped schema installation at
  version 2 and left every later table (versions 3-10) never created. No existing installs are
  affected by the rename itself - the table was never successfully created anywhere prior to this
  fix, so there is no data to migrate.
- Verified directly against real MariaDB 10.11 (not just the project's own SQLite-backed
  integration tests): every one of this plugin's 41 tables, across all 10 `Data\Schema` versions
  and all 4 `Alltime\CustomerPlatform\Schema` versions, now creates cleanly from a fresh database.

## 0.1.0 - 2026-09-06

Phase 6.6 (Commercial & integration, per PLAN.md) - AntiAbuse: rate limiting and Cloudflare
Turnstile (Section 57/58), the last of the six Phase 6 sub-phases. Ports WP-Questionnaires'
`wpq_rate_limits`/`WPQ_Turnstile` mechanisms near-verbatim, fixing two gaps found in that
implementation rather than reproducing them:

- New `AntiAbuse\RateLimiter`/`Repositories\RateLimitRepository` backed by a new `wpp_rate_limits`
  table (schema version 10): a single collapsed, HMAC-hashed `bucket_key` per (endpoint,
  dimensions) combination, enforced `UNIQUE`, with one atomic `INSERT ... ON DUPLICATE KEY UPDATE`
  per check. IP and email are HMAC'd with `wp_salt('auth')` before storage, never raw.
- **Fixed a gap in WP-Questionnaires' own implementation**: a second dimension is now actually
  populated - `Auth\RateLimiter`'s register/login/forgot-password calls pass the submitted email
  address alongside the client IP, rather than degrading to IP+endpoint only.
- **Fixed another gap**: a new hourly `AntiAbuseBootstrap` cron sweep deletes expired rate-limit
  buckets, which WP-Questionnaires' own table never had.
- New `AntiAbuse\Turnstile`, ported near-verbatim from `WPQ_Turnstile` - fails open on
  unconfigured/unreachable/erroring/unparsable responses, fails closed only on an empty token or an
  explicit `success:false`. Wired into registration and forgot-password only (not login, per
  Section 58). New `Secrets::turnstile_site_key()`/`turnstile_secret_key()`.

Phase 6.5 (Commercial & integration, per PLAN.md) - emergency controls (Section 71's six actions,
all audited), directly reusing existing infrastructure rather than inventing parallel mechanisms:

- New global send-pause and tracking-disable flags (`Emergency\EmergencyControls`), checked at the
  single respective entry points in `DeliveryQueueService::process_batch()` and
  `TrackingService::record_event()`.
- "Pause all campaigns" also flips every running campaign to a new `Paused` status for visibility;
  "cancel unsent deliveries", "disable sender domain", "suspend organisation" and "suppress
  recipient" reuse existing services directly.
- **Fixed a pre-existing gap**: `CampaignService::cancel()` never actually cancelled the campaign's
  own unsent deliveries, contradicting Section 72's own requirement - `DeliveryRepository::mark_cancelled()`
  had been unwired dead code since Phase 3. Fixed via a new polymorphic-source-object query rather
  than a campaign-specific one.
- New `Capabilities::MANAGE_EMERGENCY_CONTROLS` (operator-only) and a WP-admin Emergency Controls
  screen.

Phase 6.4 (Commercial & integration, per PLAN.md) - privacy requests and retention. Both wire up
pieces that already existed since earlier phases with zero callers: `atcp_privacy_requests` (a
table with no repository since schema version 2) and
`CustomerPlatform\RetentionSweeper::purge_old_interactions()`/`AuditLogger::purge_older_than()`
(working methods nothing ever invoked):

- New `CustomerPlatform\PrivacyRequestService` logs and fulfils discovery/export/anonymisation/
  deletion/suppression requests (§53), admin-initiated only. Deletion is implemented as
  anonymisation (PII overwritten, every contact identity removed outright), not a cascading
  cross-table delete.
- New daily retention sweep, scoped to audit logs and cross-tool interaction history for this
  release (2 of §54's 8 named categories) - configurable per-category in Settings, defaulting to
  "keep forever" until an administrator opts in.
- New WP-admin Privacy Requests screen (log/view export/fulfil/reject).

Phase 6.3 (Commercial & integration, per PLAN.md) - HaloPSA pull/ack (Data\Schema version 9),
scoped to campaigns and their aggregate statistics for this increment:

- New `Api\HaloController` (`wpp/v1/halo/campaigns/...`) ports WP-Questionnaires' pull/acknowledge
  REST lifecycle (pending/detail/start/acknowledge/fail) near-verbatim, including its WordPress
  Application Passwords + HTTP Basic auth convention and sync-state-columns-on-the-primary-table
  pattern (`halo_sync_status` and friends, added to `wpp_campaigns`).
- New `Capabilities::HALO_API`, deliberately excluded from the operator role's auto-grant list -
  matches WP-Questionnaires' own convention of keeping this capability off ordinary admins,
  granted only to the pre-existing `wpp_integration` role.
- The campaign detail response is always aggregate-only, computed fresh regardless of any report's
  own visibility setting - named-recipient data never reaches this external-facing route.

Phase 6.2 (Commercial & integration, per PLAN.md) - commercial models and campaign integration
(Data\Schema version 8):

- New `wpp_commercial_models`/`wpp_organisation_commercial_models` tables (§46-48): reusable
  charging-basis templates (all 8 bases from §47), assigned to an organisation via a mapping
  table rather than a column on the shared Organisation contract. Deliberately never calculates
  an actual charge - only records and assigns (§51: no Halo invoice-generation logic here).
- Campaign approval now gates on the organisation holding a valid entitlement (§21); campaign
  completion now records usage facts and consumes the covering entitlement, via a new
  `wpp_campaign_completed` action other listeners can also subscribe to.

Phase 6.1 (Commercial & integration, per PLAN.md) - the shared Usage and Entitlement contracts:

- Usage ledger (§49) and Entitlements (§50) elevated into the shared `Alltime\CustomerPlatform`
  layer as discovered services (`UsagePlatformDiscovery`/`EntitlementPlatformDiscovery`), the same
  pattern already established for Organisation - both are explicitly declared "a shared logical
  resource" by the requirements spec. New `atcp_usage_events` (append-only usage facts) and
  `atcp_entitlements` tables, `Alltime\CustomerPlatform\Schema` version 4.
- Entitlements are keyed by organisation + product (not contact + tool + domain, unlike
  wp-reconnaissance's simpler one-shot model), with `allowance_quantity`/`consumed_quantity`
  supporting a real capacity pool drawn down over multiple campaigns (`partially_consumed`).
  `EntitlementPolicy` is pure decision logic with no I/O, fully unit-tested without a database -
  the same split wp-reconnaissance's own entitlement service uses.
- New WP-admin Entitlements screen (list/grant/revoke per organisation).

Phase 5 findings remediation - fixes from a multi-angle code review of the Phase 5 diff
(`findings.md`):

- Fixed a cross-tenant PDF download-token issuance gap in the WP-Admin reports screen (a missing
  tenant-role check every sibling handler already had).
- Consolidated named-results visibility policy into one class (`Reports\Support\ReportVisibilityPolicy`),
  closing a gap where the WP-Admin HTML report view had no re-check at all, and fixing the Reports
  REST API being unreachable by any customer account regardless of organisation role.
- PDFs containing named-recipient data are no longer cached (the anonymous public download route
  has no per-request identity to re-check access against); aggregate-only PDFs are now pre-rendered
  at generation time instead of on first download.
- Every targeted recipient now appears under full named-results visibility, including one never
  delivered (marked "Not delivered"), matching that visibility level's documented guarantee.
- Download tokens are claimed atomically (fixing a use-limit race) and a use is no longer recorded
  until the PDF has actually been produced (fixing a transient-failure burning a single-use token).
- `RiskWeightSetRepository::create()`'s default-clearing is now transactional; a default-weight-set
  seeding failure during migration is caught and logged instead of fataling every page load.
- Fixed an N+1 query pattern in campaign result computation via two new batched repository methods.
- Added `Support\Dates::from_mysql()` for explicit-UTC datetime parsing (WPCS forbids
  `date_default_timezone_set()`), applied to the Reports/Results/Delivery/Tracking entities this
  batch touches; risk weights are now clamped to a sane range before being frozen into an immutable
  weight set; a `max_uses = 0` download token no longer misreads as unlimited.

Multi-provider delivery modes (ahead of Phase 6, per PLAN.md) - a customer-facing choice between
API-send (existing) and direct mailbox injection into the customer's own M365/Google Workspace
tenant, addressing a real gap where a customer's own mail security correctly quarantining a
simulation before an employee ever sees it defeats the test:

- `Sending\SenderDomain` gains a `delivery_mode` column (Data\Schema version 7): `api_send`
  (default, unchanged) or `mailbox_injection`, which requires an `organisation_uuid` and is backed
  by a customer tenant integration rather than DNS-authenticated transport.
- Two new providers behind the existing `MailProviderInterface`: `GraphMailboxWriteProvider`
  (create-then-move-to-Inbox via Microsoft Graph, bypassing Exchange Online Protection/mail flow)
  and `GmailMailboxInsertProvider` (`users.messages.insert`, per Google's own docs "bypasses most
  scanning and classification"). Both require the customer's own tenant admin to consent -
  Alltime writes into the customer's tenant, never sends from it.
- `wpp_organisation_mail_integrations` (new table, unique per organisation/provider/capability)
  tracks per-customer consent state; `MailManager::resolve()` is now organisation-aware so it can
  construct an injection provider with the calling organisation's own tenant/credential context.
  `SenderHealthService` branches on `delivery_mode`, substituting "does the org hold an active
  matching integration" for the SPF/DKIM/DMARC/MX checks that don't apply to a mode with no real
  transport to authenticate.
- Two separate Entra app registrations for Microsoft (`Mail.ReadWrite` only; directory-sync scopes
  only), since a single app's admin-consent grant is all-or-nothing; one Google service account
  suffices, since Workspace domain-wide delegation is independently curatable per scope from a
  single client ID. `Verification\Support\MxProviderClassifier` gates which consent option a
  customer is offered by their own domain's MX records.
- Injected mail carries honest, self-disclosing simulation headers (`Support\SimulationHeaders`) -
  a genuine `Authentication-Results` reflecting no real check occurred, plus `X-WPP-Simulation` -
  visible in raw source/"View Original" for a security-aware reviewer, never forged-plausible.
- Every delivery, regardless of provider, now includes an unsubscribe path: a new
  `SuppressionReason::RecipientOptOut` case and a `/tracking/unsubscribe/{token}` route (GET
  confirms, POST suppresses, mirroring the existing click-tracking scanner-avoidance pattern);
  `CampaignActivationService` auto-appends the unsubscribe footer to every rendered delivery.

Phase 5 (results & reporting, per PLAN.md), scoped to aggregate reporting, named reporting with
access controls, and PDF reporting - longitudinal reporting and repeat-risk analysis remain
Phase 2:

- Risk scoring and results (`wpp_risk_weight_sets`, Data\Schema version 6, Section 37-39/43):
  results are computed on demand from delivery status and tracking events rather than stored
  denormalised, so evidence and score can never drift apart. Risk weight sets are named,
  immutable, versioned configurations (a default seeds automatically from the spec's own example
  weighting); cohort breakdown covers department/team/location; a simple threshold-based
  recommendation engine reads the same aggregates.
- Campaign reports (`wpp_reports`/`wpp_download_tokens`, Section 44/59/62/63): a formal report
  covering all 13 minimum sections (executive summary through limitations), generated as a frozen,
  regenerable-but-never-edited artefact, exportable as HTML, PDF (via Dompdf) or JSON from one
  stored structure. PDFs are cached in fail-closed protected storage (an uploads subdirectory
  behind both `.htaccess` and a blank `index.php`, re-verified on every access) and served only
  through hashed, expiring, use-limited, revocable download tokens via a new public
  `/reports/download/{token}` route.
- Named-result visibility (aggregate-only / named / restricted-named) is chosen when a report is
  generated and re-enforced against the current viewer's role every time that report is viewed
  afterwards - a role change or disabled feature flag hides named results from a report that
  already has them, without needing to regenerate it.
- WP-admin: a real Reports screen (generate, view, issue PDF download links) and risk-weight-set
  management under Settings - every screen the spec's admin menu structure names is now
  functional.

Phase 4 (campaigns & delivery, per PLAN.md), scoped to single-wave/scheduled campaigns only -
multi-wave, randomised windows, recurring schedules and scanner classification remain Phase 2:

- Versioned templates and landing pages (`wpp_templates`/`wpp_template_versions`,
  `wpp_landing_pages`/`wpp_landing_page_versions`, Data\Schema version 5, Section 28/29/30/31):
  editing creates a new immutable version rather than mutating one already locked into a campaign
  wave. A whitelisted `{{variable}}` renderer (no PHP execution) covers every documented
  template variable. Landing pages support click-only, behavioural-continuation and credential-
  simulation modes; educational content is shown after any mode's interaction, not a separate
  mode.
- Campaigns (`wpp_campaigns`/`wpp_campaign_waves`/`wpp_campaign_wave_recipients`/
  `wpp_campaign_approvals`, Section 18-21): full approval workflow (customer self-approval,
  Alltime-required, dual, managed-service-only), auto-scheduling once approval requirements are
  met, a 5-minute cron sweep that activates due campaigns and detects completion, and
  cancellation that marks unsent deliveries cancelled while preserving delivered evidence
  (Section 72). Wave activation freezes the recipient cohort and metadata snapshot (Section
  16/20) before rendering and enqueueing each delivery through Phase 3's queue.
- Tracking (`wpp_tracking_tokens`/`wpp_tracking_events`, Section 32-36): opaque 256-bit tokens
  (hash-only persisted), public `/tracking/open/{token}`, `/tracking/click/{token}` and
  `/simulation/{token}` routes, and append-only events. The credential-simulation submission
  handler never reads `$_POST` - only that a submission was attempted is recorded (Section
  31.3). The delivery queue now also records a `message_accepted` event (Section 36).
- WP-admin: real Campaigns, Templates and Landing Pages screens, replacing three more "coming
  soon" placeholders.

Phase 3 (sending infrastructure, per PLAN.md):

- Sender domains and identities (`wpp_sender_domains`, `wpp_sender_identities`, Data\Schema
  version 4, Section 22): domains may be shared-pool or organisation-dedicated; identities are
  scoped to a domain. `SenderHealthService` runs DNS-based health checks (SPF, DMARC, mail
  routing/MX) - DKIM is reported `Unknown` rather than pass/fail since no selector is tracked yet.
- Three-provider mail abstraction (`Integrations\Mail`, Section 25), each provider built against
  real request/response shapes with no AWS/Google/Microsoft SDK dependency: Amazon SES v2
  `SendEmail`, signed with a from-scratch pure-PHP AWS Signature V4 implementation
  (`Support\AwsSignatureV4`); Microsoft Graph `sendMail` via an Entra app registration's
  client-credentials OAuth2 flow (`Mail.Send` application permission, cached access token); Gmail
  `users.messages.send` via a stored OAuth2 refresh token and a hand-built, base64url-encoded raw
  RFC 2822 message. `MailManager` resolves the active provider from a per-sender-domain override
  or a site-wide administrator preference, never a silent default. All three accept an injectable
  HTTP transport for testing instead of making live calls.
- Durable, idempotent delivery queue (`wpp_deliveries`, `Delivery\DeliveryQueueService`, Section
  26): enqueue is idempotent by key; a WP-Cron worker claims a batch atomically (a `claim_token`
  stamped in one `UPDATE ... LIMIT`, then read back) so concurrent workers never double-process a
  row; sends re-check suppression at send time, enforce `SenderHealthService`'s fail-closed
  preflight, and retry transient failures with exponential backoff up to a fixed ceiling.
  Deliveries reference their source via a polymorphic `source_object_type`/`source_object_uuid`
  pair so Phase 4's Campaign engine can populate them later without this phase needing to know
  what a campaign is.
- WP-admin: real "Sender Domains" (create, health-check, retire, manage identities) and "Queue"
  (recent deliveries) screens, plus a mail-provider preference selector on Settings.

Customer portal + admin UI (circling back to Phase 1's deferred scope, per PLAN.md):

- Customer-facing `/customer/*` routes (`Auth\AuthBootstrap`): self-service registration (email
  verification required before login), login/logout, forgot/reset password, and an account
  dashboard covering Section 1's core journey end-to-end - create/select an organisation,
  add and DNS-verify a domain, accept a pending invitation. Deliberately open self-service
  registration (per explicit decision), with low-cost protections that don't require the full
  Phase 6 AntiAbuse module: a transient-based per-IP rate limiter, a honeypot + minimum-fill-time
  check, and hashed single-use tokens for email verification/password reset.
- WP-admin "Phishing" menu (`Admin\AdminBootstrap`, Section 67): real screens for organisations,
  domains (including audited administrator override), recipients, groups, recipient imports,
  suppressions, audit log, and settings; placeholder "coming soon" screens for the modules the
  spec's menu structure names but later phases haven't built yet (campaigns, templates, sender
  domains, reports, queue).
- REST namespace `wpp/v1` in place since the previous entry; no further change here.

Phase 2 (recipients, per PLAN.md):

- Recipient data model (`wpp_recipients`, contact_uuid nullable per Section 14), static
  recipient groups (`wpp_recipient_groups`/`wpp_recipient_group_members`, Section 17), and
  suppression (`wpp_suppressions`, Section 55 - multiple independent reasons per address,
  survives re-import).
- Full async recipient-import pipeline (Section 15): CSV and XLSX upload, column mapping
  (`Recipients\Support\ColumnMapper`, canonical fields + custom metadata), bounded-batch
  validation (invalid-address detection, within-file duplicate detection, suppression checks)
  and commit, each resumable via `RecipientsBootstrap`'s 5-minute cron sweep - "large imports
  shall run asynchronously" without a new job-queue dependency.
- REST API: `RecipientsController`, `RecipientGroupsController`, `RecipientImportsController`,
  `SuppressionsController` - all `TenantGuard`-gated, UUID-addressed.
- New dependency: `phpoffice/phpspreadsheet` (XLSX reading), plus `ext-zip`/`ext-fileinfo`/
  `ext-gd` declared as real requirements it needs.
- REST namespace corrected from `wp-phishing/v1` to `wpp/v1`, matching this plugin's own
  abbreviation used everywhere else (`WPP_VERSION`, `wpp_*` tables/capabilities).

Phase 1 (tenancy & identity, partial - see PLAN.md):

- DNS TXT domain-ownership verification (`Verification\DomainVerificationService` +
  `VerificationBootstrap`), per Section 11: challenge generation, DNS TXT matching, a 30-minute
  background sweep, and audited administrator override.
- `Support\TenantGuard`: resolves organisation access from the authenticated identity's active
  organisation membership (Section 65) - never trusted from request parameters.
- REST API (`wpp/v1`): organisations (self-service create, list mine, get one) and
  organisation domains (add, list, start/check/override DNS verification), all permission-gated
  through `TenantGuard`.
- `OrganisationServiceInterface::get_domain()` and `record_domain_verification()`'s
  `$requested_by` parameter added to the shared Organisation contract.

Initial scaffold (Phase 0 of PLAN.md):

- Plugin bootstrap, activation/deactivation, self-hosted updater.
- Database schema/migration framework (`wpp_audit_log`).
- Secrets resolution (constant → environment → option), feature flags, capabilities and roles.
- Shared `Alltime\CustomerPlatform` layer copied from `alltimeuk/wp-reconnaissance` (contacts,
  consent, interactions, visitor context).
- New shared Organisation contract (`OrganisationServiceInterface` +
  `OrganisationPlatformDiscovery`) added to `Alltime\CustomerPlatform`: organisations,
  membership and domains, per the design specification's Sections 8/9/10/80.
