<?php
/**
 * Fires when the plugin is deleted through the WordPress plugin screen.
 *
 * Data is preserved by default. Destructive removal only happens if an administrator has
 * explicitly opted in via the "wpp_remove_data_on_uninstall" option before deletion.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing;

use Alltime\CustomerPlatform\Migrator as CustomerPlatformMigrator;
use Alltime\WPPhishing\Data\Migrator;

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$wpp_autoloader = __DIR__ . '/vendor/autoload.php';

if ( ! file_exists( $wpp_autoloader ) ) {
	return;
}

require_once $wpp_autoloader;

if ( ! get_option( 'wpp_remove_data_on_uninstall', false ) ) {
	return;
}

Migrator::uninstall();

// The Customer Platform's tables are shared with any other installed Alltime plugin (Section 4)
// - only remove them if nothing else is still relying on the shared contract.
if ( null === \Alltime\CustomerPlatform\ContactPlatformDiscovery::resolve() ) {
	CustomerPlatformMigrator::uninstall();
}
