<?php
/**
 * Persistence for landing pages and their versions, against `wpp_landing_pages` and
 * `wpp_landing_page_versions`, per Section 31.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Landing\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Landing\Enums\LandingPageMode;
use Alltime\WPPhishing\Landing\Enums\LandingPageStatus;
use Alltime\WPPhishing\Landing\LandingPage;
use Alltime\WPPhishing\Landing\LandingPageVersion;

final class LandingPageRepository {

	public function find( int $id ): ?LandingPage {
		global $wpdb;

		$table = Schema::table( 'landing_pages' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? LandingPage::from_row( $row ) : null;
	}

	public function find_by_uuid( string $landing_page_uuid ): ?LandingPage {
		global $wpdb;

		$table = Schema::table( 'landing_pages' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE landing_page_uuid = %s", $landing_page_uuid ), ARRAY_A );

		return null !== $row ? LandingPage::from_row( $row ) : null;
	}

	/**
	 * @return LandingPage[]
	 */
	public function find_available_for_organisation( string $organisation_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'landing_pages' );

		$query = "SELECT * FROM `{$table}` WHERE (organisation_uuid = %s OR organisation_uuid IS NULL) AND status = %s ORDER BY name ASC";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, $organisation_uuid, LandingPageStatus::Active->value ), ARRAY_A );

		return array_map( array( LandingPage::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function find_version( int $id ): ?LandingPageVersion {
		global $wpdb;

		$table = Schema::table( 'landing_page_versions' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? LandingPageVersion::from_row( $row ) : null;
	}

	public function create( ?string $organisation_uuid, string $name, LandingPageMode $mode, ?int $created_by ): LandingPage {
		global $wpdb;

		$table = Schema::table( 'landing_pages' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'landing_page_uuid' => wp_generate_uuid4(),
			'organisation_uuid' => $organisation_uuid,
			'name'              => $name,
			'mode'              => $mode->value,
			'status'            => LandingPageStatus::Draft->value,
			'created_by'        => $created_by,
			'created_at'        => $now,
			'updated_at'        => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function create_version( int $landing_page_id, string $html_body, ?string $educational_html, ?int $created_by ): LandingPageVersion {
		global $wpdb;

		$versions_table      = Schema::table( 'landing_page_versions' );
		$landing_pages_table = Schema::table( 'landing_pages' );
		$now                 = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $versions_table is a fixed, internally derived identifier, not user input.
		$next_version = 1 + (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(version_number) FROM `{$versions_table}` WHERE landing_page_id = %d", $landing_page_id ) );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$versions_table,
			array(
				'landing_page_id'  => $landing_page_id,
				'version_number'   => $next_version,
				'html_body'        => $html_body,
				'educational_html' => $educational_html,
				'created_by'       => $created_by,
				'created_at'       => $now,
			)
		);

		$version_id = (int) $wpdb->insert_id;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$landing_pages_table,
			array(
				'current_version_id' => $version_id,
				'updated_at'         => $now,
			),
			array( 'id' => $landing_page_id )
		);

		return $this->find_version_or_fail( $version_id );
	}

	public function update_status( int $landing_page_id, LandingPageStatus $status ): LandingPage {
		global $wpdb;

		$table = Schema::table( 'landing_pages' );

		$wpdb->update(
			$table,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $landing_page_id )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.Arrays.MultipleStatementAlignment.DoubleArrowNotAligned

		return $this->find_or_fail( $landing_page_id );
	}

	private function find_or_fail( int $id ): LandingPage {
		$landing_page = $this->find( $id );

		if ( null === $landing_page ) {
			throw new \RuntimeException( esc_html( "Landing page {$id} was expected to exist but could not be loaded." ) );
		}

		return $landing_page;
	}

	private function find_version_or_fail( int $id ): LandingPageVersion {
		$version = $this->find_version( $id );

		if ( null === $version ) {
			throw new \RuntimeException( esc_html( "Landing page version {$id} was expected to exist but could not be loaded." ) );
		}

		return $version;
	}
}
