<?php
/**
 * Landing page identity, per Section 31. `organisation_uuid` is nullable: null is a shared
 * library page, set is organisation-authored - mirrors `Templates\Template`.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Landing;

use Alltime\WPPhishing\Landing\Enums\LandingPageMode;
use Alltime\WPPhishing\Landing\Enums\LandingPageStatus;

final class LandingPage {

	public function __construct(
		public readonly int $id,
		public readonly string $landing_page_uuid,
		public readonly ?string $organisation_uuid,
		public readonly string $name,
		public readonly LandingPageMode $mode,
		public readonly LandingPageStatus $status,
		public readonly ?int $current_version_id,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			landing_page_uuid: (string) $row['landing_page_uuid'],
			organisation_uuid: ! empty( $row['organisation_uuid'] ) ? (string) $row['organisation_uuid'] : null,
			name: (string) $row['name'],
			mode: LandingPageMode::from( (string) $row['mode'] ),
			status: LandingPageStatus::from( (string) $row['status'] ),
			current_version_id: ! empty( $row['current_version_id'] ) ? (int) $row['current_version_id'] : null,
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
