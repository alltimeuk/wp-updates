<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Landing\Enums;

enum LandingPageStatus: string {
	case Draft    = 'draft';
	case Active   = 'active';
	case Archived = 'archived';
}
