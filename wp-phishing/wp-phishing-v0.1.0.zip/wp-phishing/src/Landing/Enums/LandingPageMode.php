<?php
/**
 * Landing page simulation mode, per Section 31. `EducationalIntervention` (31.4) is deliberately
 * not a fourth case here: it is content shown after any interaction, not a distinct mode - every
 * landing page version's `educational_html` is shown once the recipient has done whatever this
 * mode asks of them (Click's is shown immediately; Credential Simulation's after form submission).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Landing\Enums;

enum LandingPageMode: string {
	/** Section 31.1: record that the link was followed, then show the educational page. */
	case ClickOnly = 'click_only';
	/** Section 31.2: present a simulated login or business workflow the recipient continues. */
	case BehaviouralContinuation = 'behavioural_continuation';
	/** Section 31.3: prompts for credentials; the supplied value is never stored or logged. */
	case CredentialSimulation = 'credential_simulation';
}
