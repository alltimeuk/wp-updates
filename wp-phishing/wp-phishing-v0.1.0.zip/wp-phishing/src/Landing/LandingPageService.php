<?php
/**
 * Landing page service, per Section 31.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Landing;

use Alltime\WPPhishing\Landing\Enums\LandingPageMode;
use Alltime\WPPhishing\Landing\Enums\LandingPageStatus;
use Alltime\WPPhishing\Landing\Repositories\LandingPageRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class LandingPageService {

	public function __construct(
		private readonly LandingPageRepository $landing_pages = new LandingPageRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return LandingPage[]
	 */
	public function list_available_for_organisation( string $organisation_uuid ): array {
		return $this->landing_pages->find_available_for_organisation( $organisation_uuid );
	}

	public function get( string $landing_page_uuid ): ?LandingPage {
		return $this->landing_pages->find_by_uuid( $landing_page_uuid );
	}

	public function current_version( LandingPage $landing_page ): ?LandingPageVersion {
		return null !== $landing_page->current_version_id ? $this->landing_pages->find_version( $landing_page->current_version_id ) : null;
	}

	public function create(
		?string $organisation_uuid,
		string $name,
		LandingPageMode $mode,
		string $html_body,
		?string $educational_html,
		?int $created_by = null
	): LandingPage {
		$landing_page = $this->landing_pages->create( $organisation_uuid, $name, $mode, $created_by );

		$this->landing_pages->create_version( $landing_page->id, $html_body, $educational_html, $created_by );

		$this->audit_logger->log( 'landing_page.created', 'landing_page', $landing_page->landing_page_uuid, $created_by, summary: $name, organisation_uuid: $organisation_uuid );

		return $this->landing_pages->find( $landing_page->id ) ?? $landing_page;
	}

	public function create_new_version( LandingPage $landing_page, string $html_body, ?string $educational_html, ?int $created_by = null ): LandingPageVersion {
		$version = $this->landing_pages->create_version( $landing_page->id, $html_body, $educational_html, $created_by );

		$this->audit_logger->log( 'landing_page.new_version', 'landing_page', $landing_page->landing_page_uuid, $created_by, summary: "version {$version->version_number}", organisation_uuid: $landing_page->organisation_uuid );

		return $version;
	}

	public function update_status( LandingPage $landing_page, LandingPageStatus $status, ?int $updated_by = null ): LandingPage {
		$updated = $this->landing_pages->update_status( $landing_page->id, $status );

		$this->audit_logger->log( 'landing_page.status_updated', 'landing_page', $landing_page->landing_page_uuid, $updated_by, summary: $status->value, organisation_uuid: $landing_page->organisation_uuid );

		return $updated;
	}
}
