<?php
/**
 * One immutable version of a landing page's content, per Section 31. A campaign wave locks in a
 * specific version so a later edit never rewrites what a recipient actually saw.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Landing;

final class LandingPageVersion {

	public function __construct(
		public readonly int $id,
		public readonly int $landing_page_id,
		public readonly int $version_number,
		public readonly string $html_body,
		public readonly ?string $educational_html,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			landing_page_id: (int) $row['landing_page_id'],
			version_number: (int) $row['version_number'],
			html_body: (string) $row['html_body'],
			educational_html: ! empty( $row['educational_html'] ) ? (string) $row['educational_html'] : null,
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] )
		);
	}
}
