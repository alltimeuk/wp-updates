<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\MailIntegrations\Enums;

enum MailIntegrationProvider: string {
	case Microsoft365    = 'microsoft365';
	case GoogleWorkspace = 'google_workspace';
}
