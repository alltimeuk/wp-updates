<?php
/**
 * Independently grantable capabilities against a customer's own tenant. Deliberately not one
 * combined grant per organisation: a customer may want mailbox injection without directory sync,
 * or vice versa, and (for Microsoft specifically) each capability is a *separate* Entra app
 * registration for exactly this reason - see PLAN.md's "Multi-provider delivery modes" section.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\MailIntegrations\Enums;

enum MailIntegrationCapability: string {
	/** Write simulation messages directly into recipients' own mailboxes. */
	case MailboxInjection = 'mailbox_injection';
	/**
	 * Consent tracking only in this increment - the actual directory-scrape recipient-sync
	 * feature this capability will eventually authorise is Phase 2 per the spec's own Section 77
	 * ("Microsoft Graph / Entra recipient synchronisation") and is not built yet.
	 */
	case DirectorySync = 'directory_sync';
}
