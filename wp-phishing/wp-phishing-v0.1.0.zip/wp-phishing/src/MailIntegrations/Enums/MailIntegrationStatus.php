<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\MailIntegrations\Enums;

enum MailIntegrationStatus: string {
	/** Initiated but not yet confirmed granted. */
	case Pending = 'pending';
	/** Confirmed granted and currently usable. */
	case Active = 'active';
	/** Explicitly revoked, either by the customer or an Alltime operator. */
	case Revoked = 'revoked';
	/** Verification was attempted and failed (e.g. consent was never actually completed). */
	case Failed = 'failed';
}
