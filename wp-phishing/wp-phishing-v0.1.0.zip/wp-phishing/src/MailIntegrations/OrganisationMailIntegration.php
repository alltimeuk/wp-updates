<?php
/**
 * One organisation's consent grant for one capability against one provider, per the "Multi-
 * provider delivery modes" plan addition. `tenant_identifier` is the Entra tenant ID for
 * Microsoft or the primary Workspace domain for Google - set once verification succeeds.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\MailIntegrations;

use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationStatus;

final class OrganisationMailIntegration {

	public function __construct(
		public readonly int $id,
		public readonly string $integration_uuid,
		public readonly string $organisation_uuid,
		public readonly MailIntegrationProvider $provider,
		public readonly MailIntegrationCapability $capability,
		public readonly MailIntegrationStatus $status,
		public readonly ?string $tenant_identifier,
		public readonly ?\DateTimeImmutable $verified_at,
		public readonly ?\DateTimeImmutable $revoked_at,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	public function is_active(): bool {
		return MailIntegrationStatus::Active === $this->status;
	}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			integration_uuid: (string) $row['integration_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			provider: MailIntegrationProvider::from( (string) $row['provider'] ),
			capability: MailIntegrationCapability::from( (string) $row['capability'] ),
			status: MailIntegrationStatus::from( (string) $row['status'] ),
			tenant_identifier: ! empty( $row['tenant_identifier'] ) ? (string) $row['tenant_identifier'] : null,
			verified_at: ! empty( $row['verified_at'] ) ? new \DateTimeImmutable( (string) $row['verified_at'] ) : null,
			revoked_at: ! empty( $row['revoked_at'] ) ? new \DateTimeImmutable( (string) $row['revoked_at'] ) : null,
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
