<?php
/**
 * Orchestrates consent for mailbox-injection/directory-sync capabilities against a customer's own
 * Microsoft 365 or Google Workspace tenant, per the "Multi-provider delivery modes" plan
 * addition.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\MailIntegrations;

use Alltime\WPPhishing\Integrations\Mail\Support\GoogleServiceAccountToken;
use Alltime\WPPhishing\Integrations\Mail\Support\GraphAppOnlyToken;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\Repositories\OrganisationMailIntegrationRepository;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Support\Secrets;

final class MailIntegrationService {

	/** @var array<string,string> MailIntegrationCapability value => Graph application-permission scope. */
	private const GRAPH_SCOPES = array(
		'mailbox_injection' => 'https://graph.microsoft.com/.default',
		'directory_sync'    => 'https://graph.microsoft.com/.default',
	);

	/** @var array<string,string> MailIntegrationCapability value => Google OAuth scope. */
	private const GOOGLE_SCOPES = array(
		'mailbox_injection' => 'https://www.googleapis.com/auth/gmail.insert',
		'directory_sync'    => 'https://www.googleapis.com/auth/admin.directory.user.readonly',
	);

	public function __construct(
		private readonly OrganisationMailIntegrationRepository $integrations = new OrganisationMailIntegrationRepository(),
		private readonly GraphAppOnlyToken $graph_token = new GraphAppOnlyToken(),
		private readonly GoogleServiceAccountToken $google_token = new GoogleServiceAccountToken(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return OrganisationMailIntegration[]
	 */
	public function list_for_organisation( string $organisation_uuid ): array {
		return $this->integrations->find_all_for_organisation( $organisation_uuid );
	}

	public function get( string $organisation_uuid, string $integration_uuid ): ?OrganisationMailIntegration {
		return $this->integrations->find_by_uuid( $organisation_uuid, $integration_uuid );
	}

	public function initiate( string $organisation_uuid, MailIntegrationProvider $provider, MailIntegrationCapability $capability, ?int $created_by = null ): OrganisationMailIntegration {
		$integration = $this->integrations->find_or_create_pending( $organisation_uuid, $provider, $capability, $created_by );

		$this->audit_logger->log( 'mail_integration.initiated', 'organisation_mail_integration', $integration->integration_uuid, $created_by, summary: "{$provider->value}:{$capability->value}", organisation_uuid: $organisation_uuid );

		return $integration;
	}

	/**
	 * The tenant-wide admin-consent URL for the Entra app registration matching $capability -
	 * Microsoft only. Returns null if that app's client ID isn't configured yet.
	 */
	public function microsoft_consent_url( MailIntegrationCapability $capability, string $redirect_uri ): ?string {
		$client_id = $this->microsoft_credentials( $capability )['client_id'];

		if ( '' === $client_id ) {
			return null;
		}

		return add_query_arg(
			array(
				'client_id'    => $client_id,
				'redirect_uri' => $redirect_uri,
			),
			'https://login.microsoftonline.com/common/adminconsent'
		);
	}

	/**
	 * What to tell the customer's Workspace admin to enter for domain-wide delegation - Google
	 * only. There is no interactive consent redirect for domain-wide delegation; the admin
	 * manually authorises a client ID for a scope in their own Admin Console.
	 *
	 * @return array{client_email:string,scope:string}
	 */
	public function google_delegation_instructions( MailIntegrationCapability $capability ): array {
		return array(
			'client_email' => Secrets::google_workspace_client_email()['value'],
			'scope'        => self::GOOGLE_SCOPES[ $capability->value ],
		);
	}

	/**
	 * Confirms a pending Microsoft grant actually works by fetching an app-only token against the
	 * tenant - a successful fetch is the only reliable signal that admin consent was completed;
	 * Entra has no separate "was this consented" query suitable for the app-only flow.
	 */
	public function verify_microsoft( OrganisationMailIntegration $integration, string $tenant_id ): OrganisationMailIntegration {
		$credentials = $this->microsoft_credentials( $integration->capability );

		try {
			$this->graph_token->fetch( $tenant_id, $credentials['client_id'], $credentials['client_secret'], self::GRAPH_SCOPES[ $integration->capability->value ] );
		} catch ( \RuntimeException $exception ) {
			$this->audit_logger->log( 'mail_integration.verification_failed', 'organisation_mail_integration', $integration->integration_uuid, null, outcome: 'failure', summary: $exception->getMessage(), organisation_uuid: $integration->organisation_uuid ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- AuditLogger's $summary is stored, never echoed as HTML; every message here is a fixed string built by GraphAppOnlyToken, never raw response bodies.

			return $this->integrations->mark_failed( $integration->id );
		}

		$this->audit_logger->log( 'mail_integration.activated', 'organisation_mail_integration', $integration->integration_uuid, null, organisation_uuid: $integration->organisation_uuid );

		return $this->integrations->mark_active( $integration->id, $tenant_id );
	}

	/**
	 * Confirms a pending Google grant by fetching a token impersonating $test_mailbox - the
	 * customer must supply a real mailbox in their own Workspace to test against, since domain-
	 * wide delegation is scoped by (client, scope) but only actually usable against real users.
	 */
	public function verify_google( OrganisationMailIntegration $integration, string $primary_domain, string $test_mailbox ): OrganisationMailIntegration {
		$client_email = Secrets::google_workspace_client_email()['value'];
		$private_key  = Secrets::google_workspace_private_key()['value'];

		try {
			$this->google_token->fetch( $client_email, $private_key, self::GOOGLE_SCOPES[ $integration->capability->value ], $test_mailbox );
		} catch ( \RuntimeException $exception ) {
			$this->audit_logger->log( 'mail_integration.verification_failed', 'organisation_mail_integration', $integration->integration_uuid, null, outcome: 'failure', summary: $exception->getMessage(), organisation_uuid: $integration->organisation_uuid ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- see verify_microsoft() above; every message here is a fixed string, never a raw response body.

			return $this->integrations->mark_failed( $integration->id );
		}

		$this->audit_logger->log( 'mail_integration.activated', 'organisation_mail_integration', $integration->integration_uuid, null, organisation_uuid: $integration->organisation_uuid );

		return $this->integrations->mark_active( $integration->id, $primary_domain );
	}

	public function revoke( OrganisationMailIntegration $integration, ?int $revoked_by = null ): OrganisationMailIntegration {
		$updated = $this->integrations->mark_revoked( $integration->id );

		$this->audit_logger->log( 'mail_integration.revoked', 'organisation_mail_integration', $integration->integration_uuid, $revoked_by, organisation_uuid: $integration->organisation_uuid );

		return $updated;
	}

	/**
	 * @return array{client_id:string,client_secret:string}
	 */
	private function microsoft_credentials( MailIntegrationCapability $capability ): array {
		return match ( $capability ) {
			MailIntegrationCapability::MailboxInjection => array(
				'client_id'     => Secrets::graph_mailbox_access_client_id()['value'],
				'client_secret' => Secrets::graph_mailbox_access_client_secret()['value'],
			),
			MailIntegrationCapability::DirectorySync => array(
				'client_id'     => Secrets::graph_directory_sync_client_id()['value'],
				'client_secret' => Secrets::graph_directory_sync_client_secret()['value'],
			),
		};
	}
}
