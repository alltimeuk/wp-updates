<?php
/**
 * Persistence for organisation mail integrations, against `wpp_organisation_mail_integrations`.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\MailIntegrations\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationStatus;
use Alltime\WPPhishing\MailIntegrations\OrganisationMailIntegration;

final class OrganisationMailIntegrationRepository {

	public function find( int $id ): ?OrganisationMailIntegration {
		global $wpdb;

		$table = Schema::table( 'organisation_mail_integrations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? OrganisationMailIntegration::from_row( $row ) : null;
	}

	public function find_by_uuid( string $organisation_uuid, string $integration_uuid ): ?OrganisationMailIntegration {
		global $wpdb;

		$table = Schema::table( 'organisation_mail_integrations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE integration_uuid = %s AND organisation_uuid = %s", $integration_uuid, $organisation_uuid ), ARRAY_A );

		return null !== $row ? OrganisationMailIntegration::from_row( $row ) : null;
	}

	public function find_one( string $organisation_uuid, MailIntegrationProvider $provider, MailIntegrationCapability $capability ): ?OrganisationMailIntegration {
		global $wpdb;

		$table = Schema::table( 'organisation_mail_integrations' );

		$query = "SELECT * FROM `{$table}` WHERE organisation_uuid = %s AND provider = %s AND capability = %s";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$row = $wpdb->get_row( $wpdb->prepare( $query, $organisation_uuid, $provider->value, $capability->value ), ARRAY_A );

		return null !== $row ? OrganisationMailIntegration::from_row( $row ) : null;
	}

	/**
	 * @return OrganisationMailIntegration[]
	 */
	public function find_all_for_organisation( string $organisation_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'organisation_mail_integrations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY id ASC", $organisation_uuid ), ARRAY_A );

		return array_map( array( OrganisationMailIntegration::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Creates (or returns the existing) pending grant for this (organisation, provider,
	 * capability) triple - idempotent via the table's own unique key, so re-initiating consent
	 * never creates a duplicate row.
	 */
	public function find_or_create_pending( string $organisation_uuid, MailIntegrationProvider $provider, MailIntegrationCapability $capability, ?int $created_by ): OrganisationMailIntegration {
		$existing = $this->find_one( $organisation_uuid, $provider, $capability );

		if ( null !== $existing ) {
			return $existing;
		}

		global $wpdb;

		$table = Schema::table( 'organisation_mail_integrations' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'integration_uuid'  => wp_generate_uuid4(),
				'organisation_uuid' => $organisation_uuid,
				'provider'          => $provider->value,
				'capability'        => $capability->value,
				'status'            => MailIntegrationStatus::Pending->value,
				'created_by'        => $created_by,
				'created_at'        => $now,
				'updated_at'        => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function mark_active( int $id, string $tenant_identifier ): OrganisationMailIntegration {
		return $this->update(
			$id,
			array(
				'status'            => MailIntegrationStatus::Active->value,
				'tenant_identifier' => $tenant_identifier,
				'verified_at'       => current_time( 'mysql', true ),
				'revoked_at'        => null,
			)
		);
	}

	public function mark_failed( int $id ): OrganisationMailIntegration {
		return $this->update( $id, array( 'status' => MailIntegrationStatus::Failed->value ) );
	}

	public function mark_revoked( int $id ): OrganisationMailIntegration {
		return $this->update(
			$id,
			array(
				'status'     => MailIntegrationStatus::Revoked->value,
				'revoked_at' => current_time( 'mysql', true ),
			)
		);
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function update( int $id, array $data ): OrganisationMailIntegration {
		global $wpdb;

		$table              = Schema::table( 'organisation_mail_integrations' );
		$data['updated_at'] = current_time( 'mysql', true );

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): OrganisationMailIntegration {
		$integration = $this->find( $id );

		if ( null === $integration ) {
			throw new \RuntimeException( esc_html( "Organisation mail integration {$id} was expected to exist but could not be loaded." ) );
		}

		return $integration;
	}
}
