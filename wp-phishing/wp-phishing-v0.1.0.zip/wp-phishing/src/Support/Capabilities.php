<?php
/**
 * Custom capability identifiers, per Section 66 of the design specification.
 *
 * These are checked explicitly on every admin action and REST endpoint; nonces authenticate the
 * request origin but are never treated as authorisation on their own. WordPress capability
 * checks do not replace organisation membership checks (Section 65/66) - both are required
 * where applicable.
 *
 * The `alltime_*` capabilities are shared identifiers, granted the same way by every installed
 * Alltime plugin so a user recognised as (for example) an Alltime organisation manager in one
 * product is recognised the same way in another.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

final class Capabilities {

	// Shared Alltime platform capabilities (Section 66).
	public const ALLTIME_MANAGE_CUSTOMER_PLATFORM = 'alltime_manage_customer_platform';
	public const ALLTIME_MANAGE_ORGANISATIONS     = 'alltime_manage_organisations';
	public const ALLTIME_MANAGE_HALO              = 'alltime_manage_halo';
	public const ALLTIME_MANAGE_COMMERCIAL_MODELS = 'alltime_manage_commercial_models';

	// WP-Phishing specific capabilities (Section 66).
	public const MANAGE_SETTINGS            = 'wpp_manage_settings';
	public const MANAGE_PHISHING            = 'wpp_manage_phishing';
	public const MANAGE_SENDER_DOMAINS      = 'wpp_manage_sender_domains';
	public const MANAGE_TEMPLATES           = 'wpp_manage_templates';
	public const MANAGE_RECIPIENTS          = 'wpp_manage_recipients';
	public const MANAGE_GROUPS              = 'wpp_manage_groups';
	public const MANAGE_CAMPAIGNS           = 'wpp_manage_campaigns';
	public const APPROVE_CAMPAIGNS          = 'wpp_approve_campaigns';
	public const VIEW_NAMED_RESULTS         = 'wpp_view_named_results';
	public const VIEW_REPORTS               = 'wpp_view_reports';
	public const MANAGE_SUPPRESSIONS        = 'wpp_manage_suppressions';
	public const MANAGE_ENTITLEMENTS        = 'wpp_manage_entitlements';
	public const VIEW_AUDIT_LOG             = 'wpp_view_audit_log';
	public const VIEW_ASSIGNED_ORGANISATION = 'wpp_view_assigned_organisation';
	public const MANAGE_EMERGENCY_CONTROLS  = 'wpp_manage_emergency_controls';

	/**
	 * Section 51's HaloPSA pull/ack REST API. Deliberately never included in
	 * {@see operator_capabilities()} - granted only to {@see Roles::INTEGRATION_ROLE}, matching
	 * WP-Questionnaires' own convention (`wpq_halopsa_api` is likewise excluded from its admin
	 * auto-grant list) of keeping this narrow-blast-radius, no-wp-admin-access-implied capability
	 * off the ordinary administrator role entirely.
	 */
	public const HALO_API = 'wpp_halo_api';

	/**
	 * All capabilities granted to the administrator/operator role.
	 *
	 * @return string[]
	 */
	public static function operator_capabilities(): array {
		return array(
			self::ALLTIME_MANAGE_CUSTOMER_PLATFORM,
			self::ALLTIME_MANAGE_ORGANISATIONS,
			self::ALLTIME_MANAGE_HALO,
			self::ALLTIME_MANAGE_COMMERCIAL_MODELS,
			self::MANAGE_SETTINGS,
			self::MANAGE_PHISHING,
			self::MANAGE_SENDER_DOMAINS,
			self::MANAGE_TEMPLATES,
			self::MANAGE_RECIPIENTS,
			self::MANAGE_GROUPS,
			self::MANAGE_CAMPAIGNS,
			self::APPROVE_CAMPAIGNS,
			self::VIEW_NAMED_RESULTS,
			self::VIEW_REPORTS,
			self::MANAGE_SUPPRESSIONS,
			self::MANAGE_ENTITLEMENTS,
			self::VIEW_AUDIT_LOG,
			self::MANAGE_EMERGENCY_CONTROLS,
		);
	}

	/**
	 * Capabilities granted to the dedicated customer role. Deliberately minimal: a customer only
	 * ever sees their own assigned organisation(s), enforced at the query layer (TenantGuard,
	 * Section 65) via organisation membership rather than through capability checks alone. Named
	 * result visibility and campaign approval within an organisation are further gated by the
	 * customer's organisation membership role (Section 9), not by a WordPress capability.
	 *
	 * @return string[]
	 */
	public static function customer_capabilities(): array {
		return array(
			self::VIEW_ASSIGNED_ORGANISATION,
		);
	}
}
