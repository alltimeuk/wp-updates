<?php
/**
 * Feature flags, per Section 60: `constant override -> WordPress option` precedence.
 *
 * A constant lets an environment (e.g. a staging site) pin a flag regardless of what an
 * administrator has configured through the UI; absent that, the stored option applies.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

final class FeatureFlags {

	public const CAMPAIGN_SELF_SERVICE  = 'campaign_self_service';
	public const NAMED_REPORTING        = 'named_reporting';
	public const RECURRING_SCHEDULES    = 'recurring_schedules';
	public const EXPERIMENTAL_ANALYTICS = 'experimental_analytics';
	public const HALO_INTEGRATION       = 'halo_integration';
	public const TRAINING_MODULES       = 'training_modules';

	/**
	 * @return array<string,bool> Every known flag, defaulted false unless the option or a
	 *                             constant override says otherwise.
	 */
	public static function defaults(): array {
		return array(
			self::CAMPAIGN_SELF_SERVICE  => false,
			self::NAMED_REPORTING        => true,
			self::RECURRING_SCHEDULES    => false,
			self::EXPERIMENTAL_ANALYTICS => false,
			self::HALO_INTEGRATION       => false,
			self::TRAINING_MODULES       => false,
		);
	}

	public static function is_enabled( string $flag ): bool {
		$constant = 'WPP_FEATURE_' . strtoupper( $flag );

		if ( defined( $constant ) ) {
			return (bool) constant( $constant );
		}

		$stored  = get_option( 'wpp_feature_flags', array() );
		$default = self::defaults()[ $flag ] ?? false;

		if ( ! is_array( $stored ) || ! array_key_exists( $flag, $stored ) ) {
			return $default;
		}

		return (bool) $stored[ $flag ];
	}

	public static function set( string $flag, bool $enabled ): void {
		$stored          = get_option( 'wpp_feature_flags', array() );
		$stored          = is_array( $stored ) ? $stored : array();
		$stored[ $flag ] = $enabled;

		update_option( 'wpp_feature_flags', $stored, true );
	}
}
