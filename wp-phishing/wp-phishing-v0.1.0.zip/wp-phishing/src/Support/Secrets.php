<?php
/**
 * Resolves plugin secrets following the `constant -> environment variable -> WordPress option`
 * convention established by `WPQ_Secrets` in alltimeuk/wp-questionnaires (Section 56).
 *
 * Secrets are never hard-coded and never committed to source control; the WordPress option is
 * the last-resort fallback for environments where constants/env vars aren't practical, and is
 * always deleted on uninstall (see {@see \Alltime\WPPhishing\Data\Migrator::uninstall()}).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

final class Secrets {

	// -----------------------------------------------------------------------------------
	// Amazon SES (Section 25)
	// -----------------------------------------------------------------------------------

	public static function ses_region(): array {
		return self::resolve( 'WPP_SES_REGION', 'WPP_SES_REGION', 'wpp_ses_region' );
	}

	// -----------------------------------------------------------------------------------
	// Cloudflare Turnstile (Section 58)
	// -----------------------------------------------------------------------------------

	public static function turnstile_site_key(): array {
		return self::resolve( 'WPP_TURNSTILE_SITE_KEY', 'WPP_TURNSTILE_SITE_KEY', 'wpp_turnstile_site_key' );
	}

	public static function turnstile_secret_key(): array {
		return self::resolve( 'WPP_TURNSTILE_SECRET_KEY', 'WPP_TURNSTILE_SECRET_KEY', 'wpp_turnstile_secret_key' );
	}

	public static function ses_access_key_id(): array {
		return self::resolve( 'WPP_SES_ACCESS_KEY_ID', 'WPP_SES_ACCESS_KEY_ID', 'wpp_ses_access_key_id' );
	}

	public static function ses_secret_access_key(): array {
		return self::resolve( 'WPP_SES_SECRET_ACCESS_KEY', 'WPP_SES_SECRET_ACCESS_KEY', 'wpp_ses_secret_access_key' );
	}

	public static function ses_sender_address(): array {
		return self::resolve( 'WPP_SES_SENDER_ADDRESS', 'WPP_SES_SENDER_ADDRESS', 'wpp_ses_sender_address', '/^[^@\s]+@[^@\s]+\.[^@\s]+$/' );
	}

	// -----------------------------------------------------------------------------------
	// Microsoft Graph / Entra app registration (Section 25)
	// -----------------------------------------------------------------------------------

	public static function graph_tenant_id(): array {
		return self::resolve( 'WPP_GRAPH_TENANT_ID', 'WPP_GRAPH_TENANT_ID', 'wpp_graph_tenant_id' );
	}

	public static function graph_client_id(): array {
		return self::resolve( 'WPP_GRAPH_CLIENT_ID', 'WPP_GRAPH_CLIENT_ID', 'wpp_graph_client_id' );
	}

	public static function graph_client_secret(): array {
		return self::resolve( 'WPP_GRAPH_CLIENT_SECRET', 'WPP_GRAPH_CLIENT_SECRET', 'wpp_graph_client_secret' );
	}

	public static function graph_sender_address(): array {
		return self::resolve( 'WPP_GRAPH_SENDER_ADDRESS', 'WPP_GRAPH_SENDER_ADDRESS', 'wpp_graph_sender_address', '/^[^@\s]+@[^@\s]+\.[^@\s]+$/' );
	}

	// -----------------------------------------------------------------------------------
	// Gmail API (Section 25)
	// -----------------------------------------------------------------------------------

	public static function gmail_oauth_client_id(): array {
		return self::resolve( 'WPP_GMAIL_OAUTH_CLIENT_ID', 'WPP_GMAIL_OAUTH_CLIENT_ID', 'wpp_gmail_oauth_client_id' );
	}

	public static function gmail_oauth_client_secret(): array {
		return self::resolve( 'WPP_GMAIL_OAUTH_CLIENT_SECRET', 'WPP_GMAIL_OAUTH_CLIENT_SECRET', 'wpp_gmail_oauth_client_secret' );
	}

	public static function gmail_sender_address(): array {
		return self::resolve( 'WPP_GMAIL_SENDER_ADDRESS', 'WPP_GMAIL_SENDER_ADDRESS', 'wpp_gmail_sender_address', '/^[^@\s]+@[^@\s]+\.[^@\s]+$/' );
	}

	public static function gmail_refresh_token(): array {
		return self::resolve( 'WPP_GMAIL_REFRESH_TOKEN', 'WPP_GMAIL_REFRESH_TOKEN', 'wpp_gmail_refresh_token' );
	}

	// -----------------------------------------------------------------------------------
	// Mailbox-injection delivery mode (Alltime's own Entra/GCP apps, "Multi-provider delivery
	// modes" plan addition) - distinct from the Section 25 Mail.Send app above, since Entra's
	// tenant-wide admin consent grants everything one app declares at once; a customer must be
	// able to authorise mailbox access and directory sync independently, so each is a separate
	// app registration with its own credentials.
	// -----------------------------------------------------------------------------------

	public static function graph_mailbox_access_client_id(): array {
		return self::resolve( 'WPP_GRAPH_MAILBOX_ACCESS_CLIENT_ID', 'WPP_GRAPH_MAILBOX_ACCESS_CLIENT_ID', 'wpp_graph_mailbox_access_client_id' );
	}

	public static function graph_mailbox_access_client_secret(): array {
		return self::resolve( 'WPP_GRAPH_MAILBOX_ACCESS_CLIENT_SECRET', 'WPP_GRAPH_MAILBOX_ACCESS_CLIENT_SECRET', 'wpp_graph_mailbox_access_client_secret' );
	}

	public static function graph_directory_sync_client_id(): array {
		return self::resolve( 'WPP_GRAPH_DIRECTORY_SYNC_CLIENT_ID', 'WPP_GRAPH_DIRECTORY_SYNC_CLIENT_ID', 'wpp_graph_directory_sync_client_id' );
	}

	public static function graph_directory_sync_client_secret(): array {
		return self::resolve( 'WPP_GRAPH_DIRECTORY_SYNC_CLIENT_SECRET', 'WPP_GRAPH_DIRECTORY_SYNC_CLIENT_SECRET', 'wpp_graph_directory_sync_client_secret' );
	}

	public static function google_workspace_client_email(): array {
		return self::resolve( 'WPP_GOOGLE_WORKSPACE_CLIENT_EMAIL', 'WPP_GOOGLE_WORKSPACE_CLIENT_EMAIL', 'wpp_google_workspace_client_email' );
	}

	public static function google_workspace_private_key(): array {
		return self::resolve( 'WPP_GOOGLE_WORKSPACE_PRIVATE_KEY', 'WPP_GOOGLE_WORKSPACE_PRIVATE_KEY', 'wpp_google_workspace_private_key' );
	}

	// -----------------------------------------------------------------------------------
	// HaloPSA (Section 51)
	// -----------------------------------------------------------------------------------

	public static function halo_client_id(): array {
		return self::resolve( 'WPP_HALO_CLIENT_ID', 'WPP_HALO_CLIENT_ID', 'wpp_halo_client_id' );
	}

	public static function halo_client_secret(): array {
		return self::resolve( 'WPP_HALO_CLIENT_SECRET', 'WPP_HALO_CLIENT_SECRET', 'wpp_halo_client_secret' );
	}

	/**
	 * @return array{value:string,source:string,present:bool,valid:bool}
	 */
	private static function resolve( string $constant, string $environment_key, string $option_key, string $pattern = '/^.+$/' ): array {
		$value  = '';
		$source = 'none';

		if ( defined( $constant ) && constant( $constant ) ) {
			$value  = (string) constant( $constant );
			$source = 'constant';
		} else {
			$environment_value = getenv( $environment_key );

			if ( is_string( $environment_value ) && '' !== $environment_value ) {
				$value  = $environment_value;
				$source = 'environment';
			} else {
				$option_value = (string) get_option( $option_key, '' );

				if ( '' !== $option_value ) {
					$value  = $option_value;
					$source = 'option';
				}
			}
		}

		return array(
			'value'   => $value,
			'source'  => $source,
			'present' => '' !== $value,
			'valid'   => '' !== $value && 1 === preg_match( $pattern, $value ),
		);
	}
}
