<?php
/**
 * Append-only audit logging against `wpp_audit_log`, per Section 61.
 *
 * Never pass passwords, tokens, supplied credentials, or raw tracking/personal payloads into
 * `$summary` or `$metadata` - the audit log records that an action happened, not the sensitive
 * payload it happened to.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

use Alltime\WPPhishing\Data\Schema;

class AuditLogger {

	/**
	 * Deliberately never throws: the action `log()` is called alongside has, in every caller,
	 * already happened (or is unconditionally about to) by the time this runs - a lost audit
	 * entry must never also silently undo or abort an otherwise-successful operation. A failed
	 * write is still never silently swallowed: it's written to PHP's own error log and fired as a
	 * WordPress action other code can listen to.
	 *
	 * @param array<string,mixed>|null $metadata
	 */
	public function log(
		string $action,
		string $object_type,
		?string $object_uuid = null,
		?int $actor_id = null,
		string $outcome = 'success',
		?string $summary = null,
		string $source = 'admin',
		?string $organisation_uuid = null,
		?array $metadata = null
	): void {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'event_uuid'        => wp_generate_uuid4(),
				'actor_id'          => $actor_id,
				'organisation_uuid' => $organisation_uuid,
				'action'            => $action,
				'object_type'       => $object_type,
				'object_uuid'       => $object_uuid,
				'outcome'           => $outcome,
				'summary'           => $summary,
				'source'            => $source,
				'ip_address'        => $this->current_ip_address(),
				'metadata'          => null !== $metadata ? wp_json_encode( $metadata ) : null,
				'occurred_at'       => current_time( 'mysql', true ),
			)
		);

		if ( false === $inserted ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate, the one place this codebase intentionally surfaces a failure this way; see the docblock above for why this can't throw instead.
			error_log( "WP-Phishing: failed to write an audit log entry for action \"{$action}\" (object_type={$object_type}, object_uuid=" . ( $object_uuid ?? 'null' ) . ').' );
			do_action( 'wpp_audit_log_write_failed', $action, $object_type, $object_uuid );
		}
	}

	/**
	 * Every entry recorded against a given actor - used by the personal-data locator's export
	 * (Section 53) and by admin "view audit history" screens.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function find_by_actor( int $actor_id ): array {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE actor_id = %d ORDER BY id DESC", $actor_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return null !== $rows ? $rows : array();
	}

	/**
	 * The most recent entries across every organisation - the Alltime-staff admin "Audit" screen's
	 * unfiltered view (Section 67).
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function find_recent( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return null !== $rows ? $rows : array();
	}

	/**
	 * Every entry recorded against a given organisation - the tenant-scoped audit view (Section
	 * 67's admin "Audit" screen, and any future customer-facing audit surface).
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function find_by_organisation( string $organisation_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY id DESC", $organisation_uuid ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return null !== $rows ? $rows : array();
	}

	/**
	 * Deletes audit log entries older than the cutoff - Section 54's "audit logs" retention
	 * category.
	 */
	public function purge_older_than( \DateTimeImmutable $cutoff ): int {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE occurred_at < %s", $cutoff->format( 'Y-m-d H:i:s' ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Best-effort client IP for the audit trail (Section 61: "IP where appropriate"). Not used
	 * for any security decision - only recorded for later investigation - so a spoofable
	 * X-Forwarded-For value is an acceptable source when present.
	 */
	private function current_ip_address(): ?string {
		$candidates = array( 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );

		foreach ( $candidates as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$value = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				$first = trim( explode( ',', $value )[0] );

				if ( '' !== $first ) {
					return $first;
				}
			}
		}

		return null;
	}
}
