<?php
/**
 * Plugin bootstrap container.
 *
 * The bootstrap file only wires activation/deactivation hooks and defers everything else to
 * this class. No business logic lives here or in the plugin bootstrap file itself.
 *
 * Module boot order matches the phased delivery sequence in PLAN.md: Phase 0 (this class,
 * CustomerPlatform) is the only module wired so far. Later phases add their own *Bootstrap
 * classes here in the same place recon's Plugin::boot() wires AdminBootstrap, RestBootstrap,
 * and so on - see PLAN.md Section 4 for the full module map.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

use Alltime\CustomerPlatform\Bootstrap as CustomerPlatformBootstrap;
use Alltime\CustomerPlatform\Migrator as CustomerPlatformMigrator;
use Alltime\WPPhishing\Admin\AdminBootstrap;
use Alltime\WPPhishing\AntiAbuse\AntiAbuseBootstrap;
use Alltime\WPPhishing\Api\RestBootstrap;
use Alltime\WPPhishing\Auth\AuthBootstrap;
use Alltime\WPPhishing\Campaigns\CampaignsBootstrap;
use Alltime\WPPhishing\Commercial\CommercialBootstrap;
use Alltime\WPPhishing\Data\Migrator;
use Alltime\WPPhishing\Recipients\RecipientsBootstrap;
use Alltime\WPPhishing\Reports\ReportsBootstrap;
use Alltime\WPPhishing\Retention\RetentionBootstrap;
use Alltime\WPPhishing\Sending\SendingBootstrap;
use Alltime\WPPhishing\Tracking\TrackingBootstrap;
use Alltime\WPPhishing\Verification\VerificationBootstrap;

final class Plugin {

	private static ?self $instance = null;

	private bool $booted = false;

	private function __construct() {}

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Runs on plugin activation: installs/upgrades the database schema and registers roles.
	 * Never destroys existing data.
	 */
	public static function activate(): void {
		Migrator::install();
		CustomerPlatformMigrator::install();
		Roles::register();

		add_option( 'wpp_remove_data_on_uninstall', false );

		flush_rewrite_rules();
	}

	/**
	 * Runs on plugin deactivation. Deliberately does not remove data, tables or roles - only
	 * uninstall.php (with explicit administrator opt-in) may do that.
	 */
	public static function deactivate(): void {
		flush_rewrite_rules();
	}

	/**
	 * Boots the plugin at `plugins_loaded`. Idempotent.
	 */
	public function boot(): void {
		if ( $this->booted ) {
			return;
		}

		$this->booted = true;

		add_action(
			'init',
			static function (): void {
				load_plugin_textdomain( 'wp-phishing', false, dirname( plugin_basename( \Alltime\WPPhishing\WPP_PLUGIN_DIR . 'wp-phishing.php' ) ) . '/languages' );

				// Idempotent - run on every boot, not only activation, so a role or capability
				// added in a later update reaches an already-active install without requiring a
				// deactivate/reactivate cycle.
				Roles::register();
			},
			0
		);

		Migrator::maybe_upgrade();
		CustomerPlatformMigrator::maybe_upgrade();

		Roles::boot();

		// Registers the contact-service and organisation-service providers before any module
		// that might resolve them.
		( new CustomerPlatformBootstrap() )->boot();

		( new RestBootstrap() )->boot();
		( new VerificationBootstrap() )->boot();
		( new RecipientsBootstrap() )->boot();
		( new AuthBootstrap() )->boot();
		( new AdminBootstrap() )->boot();
		( new SendingBootstrap() )->boot();
		( new CampaignsBootstrap() )->boot();
		( new TrackingBootstrap() )->boot();
		( new ReportsBootstrap() )->boot();
		( new CommercialBootstrap() )->boot();
		( new RetentionBootstrap() )->boot();
		( new AntiAbuseBootstrap() )->boot();

		// Templates, Landing and Results have no cron sweep or public routes of their own (CRUD/
		// computation only, wired directly into RestBootstrap/AdminBootstrap) - no dedicated
		// Bootstrap class needed.

		// TODO(Phase 1): CliBootstrap.
		// Usage and Entitlements (Section 49/50) have no bootstrap of their own - they're shared
		// Alltime\CustomerPlatform contracts registered by CustomerPlatformBootstrap above, the
		// same way Organisation is; wp-phishing's own admin UI for them lives in AdminBootstrap.
		// HaloPSA pull/ack (Section 51) likewise has no bootstrap of its own - HaloController is
		// registered directly by RestBootstrap above, and this increment has no cron sweep of its
		// own (Halo initiates every pull; wp-phishing only responds).
		// Privacy requests (Section 53) likewise have no bootstrap - admin-initiated only, wired
		// directly into AdminBootstrap; PrivacyRequestService lives in Alltime\CustomerPlatform
		// since it operates on the shared Contact record, but is a plain concrete class, not a
		// discoverable contract (nothing needs to resolve it across a plugin boundary yet).
		// Emergency controls (Section 71/72) likewise have no bootstrap of their own - no cron
		// sweep or public route is needed, only the admin screen already wired into AdminBootstrap
		// and the read-only gates EmergencyControls exposes to DeliveryQueueService/TrackingService.
	}
}
