<?php
/**
 * Parses a persisted MySQL datetime string as explicit UTC. Every date this plugin writes is
 * written in UTC (`current_time('mysql', true)` always writes GMT), but PHP's ambient default
 * timezone is otherwise whatever the host is configured with - `new \DateTimeImmutable($value)`
 * with no explicit zone silently drifts by that host's offset. WPCS forbids
 * `date_default_timezone_set()` (WordPress has its own timezone concept, `wp_timezone()`, which
 * reflects the *site's configured* timezone, not the UTC this plugin actually stores), so this is
 * the shared call site every `from_row()` parsing a stored date should use instead of constructing
 * `\DateTimeImmutable` directly.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

final class Dates {

	public static function from_mysql( string $value ): \DateTimeImmutable {
		return new \DateTimeImmutable( $value, new \DateTimeZone( 'UTC' ) );
	}
}
