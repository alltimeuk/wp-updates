<?php
/**
 * Resolves which organisation(s) the current request's authenticated user may access, per
 * Section 65: `current authenticated identity -> canonical contact -> active organisation
 * membership -> appropriate organisation role -> requested object belongs to organisation`.
 *
 * An operator (holding {@see Capabilities::MANAGE_PHISHING}) may access every organisation; a
 * customer is confined to organisations they hold an *active* {@see OrganisationMembership} in,
 * resolved through the shared {@see OrganisationServiceInterface} - never trusted from request
 * parameters such as `organisation_id`/`organisation_uuid` (Section 65/70).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;
use Alltime\CustomerPlatform\OrganisationMembership;
use Alltime\CustomerPlatform\OrganisationPlatformDiscovery;
use Alltime\CustomerPlatform\OrganisationServiceInterface;

final class TenantGuard {

	public function __construct(
		private readonly ?OrganisationServiceInterface $organisations = null
	) {}

	public function is_operator(): bool {
		return current_user_can( Capabilities::MANAGE_PHISHING );
	}

	/**
	 * The current user's active membership in the given organisation, or null if they are not
	 * logged in, hold no membership there, or their membership is not Active (invited/suspended/
	 * revoked memberships never grant access).
	 */
	public function current_membership( string $organisation_uuid ): ?OrganisationMembership {
		if ( ! is_user_logged_in() ) {
			return null;
		}

		$membership = $this->organisation_service()->get_membership( $organisation_uuid, get_current_user_id() );

		return null !== $membership && MembershipStatus::Active === $membership->status ? $membership : null;
	}

	/**
	 * Whether the current user may access data belonging to the given organisation: true for any
	 * operator, or for a customer with an active membership there.
	 */
	public function can_access_organisation( string $organisation_uuid ): bool {
		if ( $this->is_operator() ) {
			return true;
		}

		return null !== $this->current_membership( $organisation_uuid );
	}

	/**
	 * Whether the current user may act with (at least) one of the given roles in the organisation:
	 * true for any operator, or for a customer whose active membership role is one of $roles.
	 * "At least" is deliberately the caller's job - Section 9 does not define a role hierarchy, so
	 * this never assumes e.g. Owner implies Administrator; pass every role the action accepts.
	 */
	public function has_role( string $organisation_uuid, MembershipRole ...$roles ): bool {
		if ( $this->is_operator() ) {
			return true;
		}

		$membership = $this->current_membership( $organisation_uuid );

		return null !== $membership && in_array( $membership->role, $roles, true );
	}

	/**
	 * Every organisation the current user holds an active membership in - the basis for "select
	 * an organisation" (Section 1) when a customer belongs to more than one.
	 *
	 * @return OrganisationMembership[]
	 */
	public function my_active_memberships(): array {
		if ( ! is_user_logged_in() ) {
			return array();
		}

		return array_values(
			array_filter(
				$this->organisation_service()->get_memberships_for_user( get_current_user_id() ),
				static fn ( OrganisationMembership $membership ): bool => MembershipStatus::Active === $membership->status
			)
		);
	}

	private function organisation_service(): OrganisationServiceInterface {
		$service = $this->organisations ?? OrganisationPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No organisation service is registered.' ) );
		}

		return $service;
	}
}
