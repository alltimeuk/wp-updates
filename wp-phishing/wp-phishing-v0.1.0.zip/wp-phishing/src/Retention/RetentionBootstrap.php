<?php
/**
 * Retention sweep bootstrap, per Section 54. Runs once daily via WordPress core's own built-in
 * `daily` cron schedule - no custom interval needed for a sweep this infrequent, unlike the
 * existing 2/5/30-minute sweeps elsewhere in this plugin.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Retention;

final class RetentionBootstrap {

	private const RUN_SWEEP_HOOK = 'wpp_run_retention_sweep';

	public function __construct(
		private readonly RetentionSweeper $sweeper = new RetentionSweeper()
	) {}

	public function boot(): void {
		add_action( self::RUN_SWEEP_HOOK, array( $this, 'run_sweep' ) );
		add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
	}

	public function ensure_sweep_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_SWEEP_HOOK ) ) {
			wp_schedule_event( time(), 'daily', self::RUN_SWEEP_HOOK );
		}
	}

	public function run_sweep(): void {
		$this->sweeper->run();
	}
}
