<?php
/**
 * Time-based automatic data retention, per Section 54. Wires up two pieces that already existed
 * as working code before this increment but were never called by anything:
 * {@see \Alltime\CustomerPlatform\RetentionSweeper::purge_old_interactions()} and
 * {@see \Alltime\WPPhishing\Support\AuditLogger::purge_older_than()}.
 *
 * Scoped to those two of Section 54's eight named categories (audit logs; cross-tool interaction
 * history) for this increment - the other six (recipient identity, delivery logs, tracking
 * events, named behavioural history, aggregate campaign results, reports, billing records) need a
 * real per-organisation policy design (Organisation.retention_policy, Section 8) this increment
 * does not attempt; see PLAN.md for the documented fast-follow.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Retention;

use Alltime\CustomerPlatform\RetentionSweeper as CustomerPlatformRetentionSweeper;
use Alltime\WPPhishing\Support\AuditLogger;

final class RetentionSweeper {

	public function __construct(
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly CustomerPlatformRetentionSweeper $customer_platform_sweeper = new CustomerPlatformRetentionSweeper()
	) {}

	/**
	 * Runs every configured sweep. A retention setting of 0 (the default, unless an administrator
	 * has explicitly configured one) means "keep forever" - nothing is ever deleted for a category
	 * that hasn't been deliberately opted into.
	 */
	public function run(): void {
		$audit_log_days = max( 0, (int) get_option( 'wpp_retention_audit_log_days', 0 ) );

		if ( $audit_log_days > 0 ) {
			$cutoff = ( new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) )->modify( "-{$audit_log_days} days" );
			$this->audit_logger->purge_older_than( $cutoff );
		}

		$interactions_days = max( 0, (int) get_option( 'wpp_retention_interactions_days', 0 ) );

		if ( $interactions_days > 0 ) {
			$this->customer_platform_sweeper->purge_old_interactions( $interactions_days );
		}
	}
}
