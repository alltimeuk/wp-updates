<?php
/**
 * Administrative interface bootstrap, per Section 67.
 *
 * Registers the "Phishing" admin menu with real screens for every module built so far
 * (organisations, recipients, groups, imports, domains, sender domains, suppressions, queue,
 * campaigns, templates, landing pages, reports, audit, settings) - every screen Section 67's
 * suggested menu structure names is now functional.
 *
 * Rendering here is deliberately plain inline HTML tables, in the same "functional end-to-end,
 * not a polished JS-driven list table" style WP-Reconnaissance's own AdminBootstrap establishes.
 *
 * Form submissions are handled on `admin_init` (before any admin chrome has been output), never
 * inside a render_* callback, since a callback registered via add_submenu_page() only runs after
 * WordPress has already started writing the page - a redirect from inside it would fail with
 * "headers already sent".
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Admin;

use Alltime\CustomerPlatform\EntitlementService;
use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;
use Alltime\CustomerPlatform\Enums\EntitlementType;
use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\OrganisationStatus;
use Alltime\CustomerPlatform\Enums\PrivacyRequestStatus;
use Alltime\CustomerPlatform\Enums\PrivacyRightType;
use Alltime\CustomerPlatform\OrganisationInput;
use Alltime\CustomerPlatform\PrivacyRequestService;
use Alltime\CustomerPlatform\Repositories\OrganisationDomainRepository;
use Alltime\CustomerPlatform\Repositories\OrganisationRepository;
use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\CampaignApprovalService;
use Alltime\WPPhishing\Campaigns\CampaignService;
use Alltime\WPPhishing\Campaigns\CampaignWave;
use Alltime\WPPhishing\Campaigns\Enums\ApprovalModel;
use Alltime\WPPhishing\Campaigns\Enums\CampaignStatus;
use Alltime\WPPhishing\Campaigns\Enums\ScheduleMode;
use Alltime\WPPhishing\Commercial\CommercialModelService;
use Alltime\WPPhishing\Commercial\Enums\ChargingBasis;
use Alltime\WPPhishing\Commercial\Enums\CommercialModelStatus;
use Alltime\WPPhishing\Delivery\Repositories\DeliveryRepository;
use Alltime\WPPhishing\Emergency\EmergencyControlsService;
use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Landing\Enums\LandingPageMode;
use Alltime\WPPhishing\Landing\Enums\LandingPageStatus;
use Alltime\WPPhishing\Landing\LandingPage;
use Alltime\WPPhishing\Landing\LandingPageService;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationStatus;
use Alltime\WPPhishing\MailIntegrations\MailIntegrationService;
use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\Repositories\RecipientGroupRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientImportRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientRepository;
use Alltime\WPPhishing\Recipients\Repositories\SuppressionRepository;
use Alltime\WPPhishing\Recipients\SuppressionService;
use Alltime\WPPhishing\Reports\DownloadTokenService;
use Alltime\WPPhishing\Reports\Enums\ReportVisibility;
use Alltime\WPPhishing\Reports\Report;
use Alltime\WPPhishing\Reports\ReportService;
use Alltime\WPPhishing\Reports\Support\HtmlRenderer;
use Alltime\WPPhishing\Reports\Support\ReportVisibilityPolicy;
use Alltime\WPPhishing\Results\Repositories\RiskWeightSetRepository;
use Alltime\WPPhishing\Sending\Enums\ScenarioClassification;
use Alltime\WPPhishing\Sending\Enums\SenderDeliveryMode;
use Alltime\WPPhishing\Sending\Enums\SenderIdentityStatus;
use Alltime\WPPhishing\Sending\SenderDomain;
use Alltime\WPPhishing\Sending\SenderDomainService;
use Alltime\WPPhishing\Sending\SenderIdentity;
use Alltime\WPPhishing\Sending\SenderIdentityService;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\FeatureFlags;
use Alltime\WPPhishing\Support\TenantGuard;
use Alltime\WPPhishing\Templates\Enums\Difficulty;
use Alltime\WPPhishing\Templates\Enums\Scenario;
use Alltime\WPPhishing\Templates\Enums\TemplateStatus;
use Alltime\WPPhishing\Templates\Template;
use Alltime\WPPhishing\Templates\TemplateService;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;
use Alltime\WPPhishing\Verification\DomainVerificationService;
use Alltime\WPPhishing\Verification\SchemaNotReadyException;

use const Alltime\WPPhishing\WPP_PRODUCT_ID;

final class AdminBootstrap {

	private const MENU_SLUG = 'wp-phishing';
	private const PER_PAGE  = 20;

	// A risk weight set is immutable once created (Section 38) - a bad value can never be
	// corrected, only superseded by a new set - so weights are clamped to a sane range up front
	// rather than trusted verbatim from $_POST.
	private const MIN_RISK_WEIGHT = -1000;
	private const MAX_RISK_WEIGHT = 1000;

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly RecipientRepository $recipients = new RecipientRepository(),
		private readonly RecipientGroupRepository $groups = new RecipientGroupRepository(),
		private readonly RecipientImportRepository $imports = new RecipientImportRepository(),
		private readonly SuppressionRepository $suppressions = new SuppressionRepository(),
		private readonly OrganisationDomainRepository $domains = new OrganisationDomainRepository(),
		private readonly DomainVerificationService $domain_verification = new DomainVerificationService(),
		private readonly SenderDomainService $sender_domains = new SenderDomainService(),
		private readonly SenderIdentityService $sender_identities = new SenderIdentityService(),
		private readonly DeliveryRepository $deliveries = new DeliveryRepository(),
		private readonly TemplateService $templates = new TemplateService(),
		private readonly LandingPageService $landing_pages = new LandingPageService(),
		private readonly CampaignService $campaigns = new CampaignService(),
		private readonly CampaignApprovalService $campaign_approvals = new CampaignApprovalService(),
		private readonly ReportService $reports = new ReportService(),
		private readonly DownloadTokenService $download_tokens = new DownloadTokenService(),
		private readonly RiskWeightSetRepository $risk_weight_sets = new RiskWeightSetRepository(),
		private readonly MailIntegrationService $mail_integrations = new MailIntegrationService(),
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly ReportVisibilityPolicy $report_visibility_policy = new ReportVisibilityPolicy(),
		private readonly EntitlementService $entitlements = new EntitlementService(),
		private readonly CommercialModelService $commercial_models = new CommercialModelService(),
		private readonly PrivacyRequestService $privacy_requests = new PrivacyRequestService(),
		private readonly EmergencyControlsService $emergency_controls = new EmergencyControlsService()
	) {}

	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'handle_form_submissions' ) );
	}

	public function register_menu(): void {
		add_menu_page(
			__( 'WP-Phishing', 'wp-phishing' ),
			__( 'Phishing', 'wp-phishing' ),
			Capabilities::MANAGE_PHISHING,
			self::MENU_SLUG,
			array( $this, 'render_overview' ),
			'dashicons-email-alt',
			58
		);

		$screens = array(
			array( 'overview', __( 'Dashboard', 'wp-phishing' ), Capabilities::MANAGE_PHISHING, 'render_overview' ),
			array( 'organisations', __( 'Organisations', 'wp-phishing' ), Capabilities::ALLTIME_MANAGE_ORGANISATIONS, 'render_organisations' ),
			array( 'domains', __( 'Domains', 'wp-phishing' ), Capabilities::MANAGE_SENDER_DOMAINS, 'render_domains' ),
			array( 'recipients', __( 'Recipients', 'wp-phishing' ), Capabilities::MANAGE_RECIPIENTS, 'render_recipients' ),
			array( 'groups', __( 'Groups', 'wp-phishing' ), Capabilities::MANAGE_GROUPS, 'render_groups' ),
			array( 'imports', __( 'Recipient Imports', 'wp-phishing' ), Capabilities::MANAGE_RECIPIENTS, 'render_imports' ),
			array( 'suppressions', __( 'Suppressions', 'wp-phishing' ), Capabilities::MANAGE_SUPPRESSIONS, 'render_suppressions' ),
			array( 'campaigns', __( 'Campaigns', 'wp-phishing' ), Capabilities::MANAGE_CAMPAIGNS, 'render_campaigns' ),
			array( 'templates', __( 'Templates', 'wp-phishing' ), Capabilities::MANAGE_TEMPLATES, 'render_templates' ),
			array( 'landing-pages', __( 'Landing Pages', 'wp-phishing' ), Capabilities::MANAGE_TEMPLATES, 'render_landing_pages' ),
			array( 'sender-domains', __( 'Sender Domains', 'wp-phishing' ), Capabilities::MANAGE_SENDER_DOMAINS, 'render_sender_domains' ),
			array( 'mail-integrations', __( 'Mail Integrations', 'wp-phishing' ), Capabilities::MANAGE_SENDER_DOMAINS, 'render_mail_integrations' ),
			array( 'entitlements', __( 'Entitlements', 'wp-phishing' ), Capabilities::MANAGE_ENTITLEMENTS, 'render_entitlements' ),
			array( 'commercial-models', __( 'Commercial Models', 'wp-phishing' ), Capabilities::ALLTIME_MANAGE_COMMERCIAL_MODELS, 'render_commercial_models' ),
			array( 'privacy-requests', __( 'Privacy Requests', 'wp-phishing' ), Capabilities::ALLTIME_MANAGE_CUSTOMER_PLATFORM, 'render_privacy_requests' ),
			array( 'emergency-controls', __( 'Emergency Controls', 'wp-phishing' ), Capabilities::MANAGE_EMERGENCY_CONTROLS, 'render_emergency_controls' ),
			array( 'reports', __( 'Reports', 'wp-phishing' ), Capabilities::VIEW_REPORTS, 'render_reports' ),
			array( 'queue', __( 'Queue', 'wp-phishing' ), Capabilities::MANAGE_PHISHING, 'render_queue' ),
			array( 'audit', __( 'Audit', 'wp-phishing' ), Capabilities::VIEW_AUDIT_LOG, 'render_audit_log' ),
			array( 'settings', __( 'Settings', 'wp-phishing' ), Capabilities::MANAGE_SETTINGS, 'render_settings' ),
		);

		foreach ( $screens as list( $slug, $label, $capability, $callback ) ) {
			add_submenu_page( self::MENU_SLUG, $label, $label, $capability, self::MENU_SLUG . '-' . $slug, array( $this, $callback ) );
		}

		remove_submenu_page( self::MENU_SLUG, self::MENU_SLUG );
	}

	// -----------------------------------------------------------------------------------
	// Form submission dispatch (admin_init - runs before any output)
	// -----------------------------------------------------------------------------------

	public function handle_form_submissions(): void {
		if ( ! isset( $_POST['wpp_admin_action'] ) || ! is_string( $_POST['wpp_admin_action'] ) ) {
			return;
		}

		$page = isset( $_GET['page'] ) && is_string( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only used to confine dispatch to this plugin's own admin pages; the actual authorisation is the nonce check + current_user_can() calls below.

		if ( ! str_starts_with( $page, self::MENU_SLUG ) ) {
			return;
		}

		$nonce          = isset( $_POST['_wpnonce'] ) && is_string( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
		$nonce_verified = wp_verify_nonce( $nonce, 'wpp_admin_action' );

		// wp_verify_nonce() returns 1 for a nonce in its first 12-hour "tick" and 2 for one in its
		// second - both are legitimately still valid; only `false` (or 0) means invalid/expired.
		if ( 1 !== $nonce_verified && 2 !== $nonce_verified ) {
			wp_die( esc_html__( 'Security check failed. Please try again.', 'wp-phishing' ) );
		}

		$action = sanitize_text_field( wp_unslash( $_POST['wpp_admin_action'] ) );

		match ( $action ) {
			'create_organisation' => $this->handle_create_organisation(),
			'update_organisation_status' => $this->handle_update_organisation_status(),
			'create_group' => $this->handle_create_group(),
			'delete_group' => $this->handle_delete_group(),
			'create_suppression' => $this->handle_create_suppression(),
			'override_domain_verification' => $this->handle_override_domain_verification(),
			'create_sender_domain' => $this->handle_create_sender_domain(),
			'check_sender_domain_health' => $this->handle_check_sender_domain_health(),
			'retire_sender_domain' => $this->handle_retire_sender_domain(),
			'create_sender_identity' => $this->handle_create_sender_identity(),
			'update_sender_identity_status' => $this->handle_update_sender_identity_status(),
			'update_mail_provider' => $this->handle_update_mail_provider(),
			'update_settings' => $this->handle_update_settings(),
			'create_template' => $this->handle_create_template(),
			'update_template_status' => $this->handle_update_template_status(),
			'create_landing_page' => $this->handle_create_landing_page(),
			'update_landing_page_status' => $this->handle_update_landing_page_status(),
			'create_campaign' => $this->handle_create_campaign(),
			'create_campaign_wave' => $this->handle_create_campaign_wave(),
			'submit_campaign' => $this->handle_submit_campaign(),
			'approve_campaign' => $this->handle_approve_campaign(),
			'cancel_campaign' => $this->handle_cancel_campaign(),
			'generate_report' => $this->handle_generate_report(),
			'issue_download_token' => $this->handle_issue_download_token(),
			'create_risk_weight_set' => $this->handle_create_risk_weight_set(),
			'initiate_mail_integration' => $this->handle_initiate_mail_integration(),
			'verify_mail_integration' => $this->handle_verify_mail_integration(),
			'revoke_mail_integration' => $this->handle_revoke_mail_integration(),
			'grant_entitlement' => $this->handle_grant_entitlement(),
			'revoke_entitlement' => $this->handle_revoke_entitlement(),
			'create_commercial_model' => $this->handle_create_commercial_model(),
			'archive_commercial_model' => $this->handle_archive_commercial_model(),
			'assign_commercial_model' => $this->handle_assign_commercial_model(),
			'log_privacy_request' => $this->handle_log_privacy_request(),
			'fulfil_privacy_request' => $this->handle_fulfil_privacy_request(),
			'reject_privacy_request' => $this->handle_reject_privacy_request(),
			'emergency_pause_sends' => $this->handle_emergency_pause_sends(),
			'emergency_resume_sends' => $this->handle_emergency_resume_sends(),
			'emergency_disable_tracking' => $this->handle_emergency_disable_tracking(),
			'emergency_enable_tracking' => $this->handle_emergency_enable_tracking(),
			'emergency_suspend_organisation' => $this->handle_emergency_suspend_organisation(),
			'emergency_suppress_recipient' => $this->handle_emergency_suppress_recipient(),
			'emergency_disable_sender_domain' => $this->handle_emergency_disable_sender_domain(),
			'emergency_cancel_campaign' => $this->handle_emergency_cancel_campaign(),
			default => null,
		};
	}

	private function handle_create_organisation(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_ORGANISATIONS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- the calling handle_form_submissions() already verified the wpp_admin_action nonce before dispatching here.
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';

		if ( '' !== $name ) {
			$organisation = $this->organisations->create( new OrganisationInput( name: $name ) );
			$this->audit_logger->log( 'organisation.created', 'organisation', $organisation->organisation_uuid, get_current_user_id(), source: 'admin', organisation_uuid: $organisation->organisation_uuid );
		}

		$this->redirect_to( 'organisations' );
	}

	private function handle_update_organisation_status(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_ORGANISATIONS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$uuid   = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$status = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$org = $this->organisations->find_by_uuid( $uuid );

		if ( null !== $org && null !== OrganisationStatus::tryFrom( $status ) ) {
			$this->organisations->update_status( $org->id, OrganisationStatus::from( $status ) );
			$this->audit_logger->log( 'organisation.status_changed', 'organisation', $uuid, get_current_user_id(), summary: $status, source: 'admin', organisation_uuid: $uuid );
		}

		$this->redirect_to( 'organisations' );
	}

	private function handle_create_group(): void {
		if ( ! current_user_can( Capabilities::MANAGE_GROUPS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$name              = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $organisation_uuid && '' !== $name ) {
			$group = $this->groups->create( $organisation_uuid, $name, null );
			$this->audit_logger->log( 'recipient_group.created', 'recipient_group', $group->group_uuid, get_current_user_id(), summary: $name, source: 'admin', organisation_uuid: $organisation_uuid );
		}

		$this->redirect_to( 'groups', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_delete_group(): void {
		if ( ! current_user_can( Capabilities::MANAGE_GROUPS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$group_uuid        = isset( $_POST['group_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['group_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$group = $this->groups->find_by_uuid( $organisation_uuid, $group_uuid );

		if ( null !== $group ) {
			$this->groups->delete( $group->id );
			$this->audit_logger->log( 'recipient_group.deleted', 'recipient_group', $group_uuid, get_current_user_id(), summary: $group->name, source: 'admin', organisation_uuid: $organisation_uuid );
		}

		$this->redirect_to( 'groups', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_create_suppression(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SUPPRESSIONS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$email             = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$reason            = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $organisation_uuid && is_email( $email ) && null !== SuppressionReason::tryFrom( $reason ) ) {
			( new SuppressionService( $this->suppressions ) )->suppress( $organisation_uuid, $email, SuppressionReason::from( $reason ), 'admin', null, get_current_user_id() );
		}

		$this->redirect_to( 'suppressions', array( 'wpp_org' => $organisation_uuid ) );
	}

	/**
	 * Section 11: administrative override, backed by documented authority. Distinct from the
	 * customer-portal DNS-driven verification path - only reachable here, gated on
	 * {@see Capabilities::MANAGE_SENDER_DOMAINS}, and always audited with the supplied reason.
	 */
	private function handle_override_domain_verification(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$domain_uuid       = isset( $_POST['domain_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['domain_uuid'] ) ) : '';
		$reason            = isset( $_POST['reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $domain_uuid && '' !== trim( $reason ) ) {
			try {
				$this->domain_verification->administrator_override( $domain_uuid, get_current_user_id(), $reason );
			} catch ( SchemaNotReadyException | \InvalidArgumentException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to( 'domains', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_create_sender_domain(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$domain            = isset( $_POST['domain'] ) ? sanitize_text_field( wp_unslash( $_POST['domain'] ) ) : '';
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$tracking_domain   = isset( $_POST['tracking_domain'] ) ? sanitize_text_field( wp_unslash( $_POST['tracking_domain'] ) ) : '';
		$landing_domain    = isset( $_POST['landing_domain'] ) ? sanitize_text_field( wp_unslash( $_POST['landing_domain'] ) ) : '';
		$delivery_mode     = isset( $_POST['delivery_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['delivery_mode'] ) ) : '';
		$mail_provider     = isset( $_POST['mail_provider'] ) ? sanitize_text_field( wp_unslash( $_POST['mail_provider'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== trim( $domain ) ) {
			try {
				$this->sender_domains->create(
					strtolower( trim( $domain ) ),
					'' !== $organisation_uuid ? $organisation_uuid : null,
					MailProviderId::tryFrom( $mail_provider ),
					'' !== $tracking_domain ? $tracking_domain : null,
					'' !== $landing_domain ? $landing_domain : null,
					get_current_user_id(),
					SenderDeliveryMode::tryFrom( $delivery_mode ) ?? SenderDeliveryMode::ApiSend
				);
			} catch ( \InvalidArgumentException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to( 'sender-domains' );
	}

	private function handle_check_sender_domain_health(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$domain_uuid = isset( $_POST['domain_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['domain_uuid'] ) ) : '';
		$domain      = $this->sender_domains->get( $domain_uuid );

		if ( null !== $domain ) {
			$this->sender_domains->check_health( $domain, get_current_user_id() );
		}

		$this->redirect_to( 'sender-domains' );
	}

	private function handle_retire_sender_domain(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$domain_uuid = isset( $_POST['domain_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['domain_uuid'] ) ) : '';
		$domain      = $this->sender_domains->get( $domain_uuid );

		if ( null !== $domain ) {
			$this->sender_domains->retire( $domain, get_current_user_id() );
		}

		$this->redirect_to( 'sender-domains' );
	}

	private function handle_create_sender_identity(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$domain_uuid  = isset( $_POST['domain_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['domain_uuid'] ) ) : '';
		$display_name = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
		$local_part   = isset( $_POST['local_part'] ) ? sanitize_text_field( wp_unslash( $_POST['local_part'] ) ) : '';
		$reply_to     = isset( $_POST['reply_to'] ) ? sanitize_email( wp_unslash( $_POST['reply_to'] ) ) : '';
		$scenario     = isset( $_POST['scenario_classification'] ) ? sanitize_text_field( wp_unslash( $_POST['scenario_classification'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$domain = $this->sender_domains->get( $domain_uuid );

		if ( null !== $domain && '' !== trim( $display_name ) && '' !== trim( $local_part ) ) {
			$this->sender_identities->create(
				$domain,
				$display_name,
				$local_part,
				'' !== $reply_to ? $reply_to : null,
				ScenarioClassification::tryFrom( $scenario ),
				get_current_user_id()
			);
		}

		$this->redirect_to( 'sender-domains', array( 'wpp_sender_domain' => $domain_uuid ) );
	}

	private function handle_update_sender_identity_status(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$domain_uuid   = isset( $_POST['domain_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['domain_uuid'] ) ) : '';
		$identity_uuid = isset( $_POST['identity_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['identity_uuid'] ) ) : '';
		$status        = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$domain   = $this->sender_domains->get( $domain_uuid );
		$identity = null !== $domain ? $this->find_identity( $domain, $identity_uuid ) : null;

		if ( null !== $identity && null !== SenderIdentityStatus::tryFrom( $status ) ) {
			$this->sender_identities->set_status( $identity, SenderIdentityStatus::from( $status ), get_current_user_id() );
		}

		$this->redirect_to( 'sender-domains', array( 'wpp_sender_domain' => $domain_uuid ) );
	}

	private function handle_update_mail_provider(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$provider = isset( $_POST['mail_provider'] ) ? sanitize_text_field( wp_unslash( $_POST['mail_provider'] ) ) : '';

		if ( '' === $provider || null !== MailProviderId::tryFrom( $provider ) ) {
			update_option( 'wpp_mail_provider', $provider );
		}

		$this->redirect_to( 'settings' );
	}

	private function handle_create_template(): void {
		if ( ! current_user_can( Capabilities::MANAGE_TEMPLATES ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$name              = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$scenario          = isset( $_POST['scenario'] ) ? sanitize_text_field( wp_unslash( $_POST['scenario'] ) ) : '';
		$difficulty        = isset( $_POST['difficulty'] ) ? sanitize_text_field( wp_unslash( $_POST['difficulty'] ) ) : '';
		$subject           = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$from_display_name = isset( $_POST['from_display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['from_display_name'] ) ) : '';
		$html_body         = isset( $_POST['html_body'] ) ? wp_kses_post( wp_unslash( $_POST['html_body'] ) ) : '';
		$text_body         = isset( $_POST['text_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text_body'] ) ) : '';
		$shared            = ! empty( $_POST['shared'] );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$scenario_enum = Scenario::tryFrom( $scenario );

		if ( '' !== trim( $name ) && null !== $scenario_enum && '' !== trim( $subject ) && '' !== trim( $from_display_name ) ) {
			$this->templates->create(
				$shared ? null : $organisation_uuid,
				$name,
				$scenario_enum,
				Difficulty::tryFrom( $difficulty ) ?? Difficulty::Moderate,
				array(),
				$subject,
				$from_display_name,
				'' !== $html_body ? $html_body : null,
				'' !== $text_body ? $text_body : null,
				null,
				get_current_user_id()
			);
		}

		$this->redirect_to( 'templates', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_update_template_status(): void {
		if ( ! current_user_can( Capabilities::MANAGE_TEMPLATES ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$template_uuid     = isset( $_POST['template_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['template_uuid'] ) ) : '';
		$status            = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$template    = $this->templates->get( $template_uuid );
		$status_enum = TemplateStatus::tryFrom( $status );

		if ( null !== $template && null !== $status_enum ) {
			$this->templates->update_status( $template, $status_enum, get_current_user_id() );
		}

		$this->redirect_to( 'templates', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_create_landing_page(): void {
		if ( ! current_user_can( Capabilities::MANAGE_TEMPLATES ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$name              = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$mode              = isset( $_POST['mode'] ) ? sanitize_text_field( wp_unslash( $_POST['mode'] ) ) : '';
		$html_body         = isset( $_POST['html_body'] ) ? wp_kses_post( wp_unslash( $_POST['html_body'] ) ) : '';
		$educational_html  = isset( $_POST['educational_html'] ) ? wp_kses_post( wp_unslash( $_POST['educational_html'] ) ) : '';
		$shared            = ! empty( $_POST['shared'] );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$mode_enum = LandingPageMode::tryFrom( $mode );

		if ( '' !== trim( $name ) && null !== $mode_enum ) {
			$this->landing_pages->create(
				$shared ? null : $organisation_uuid,
				$name,
				$mode_enum,
				$html_body,
				'' !== $educational_html ? $educational_html : null,
				get_current_user_id()
			);
		}

		$this->redirect_to( 'landing-pages', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_update_landing_page_status(): void {
		if ( ! current_user_can( Capabilities::MANAGE_TEMPLATES ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$landing_page_uuid = isset( $_POST['landing_page_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['landing_page_uuid'] ) ) : '';
		$status            = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$landing_page = $this->landing_pages->get( $landing_page_uuid );
		$status_enum  = LandingPageStatus::tryFrom( $status );

		if ( null !== $landing_page && null !== $status_enum ) {
			$this->landing_pages->update_status( $landing_page, $status_enum, get_current_user_id() );
		}

		$this->redirect_to( 'landing-pages', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_create_campaign(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CAMPAIGNS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$name              = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$approval_model    = isset( $_POST['approval_model'] ) ? sanitize_text_field( wp_unslash( $_POST['approval_model'] ) ) : '';
		$schedule_mode     = isset( $_POST['schedule_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['schedule_mode'] ) ) : '';
		$starts_at         = isset( $_POST['starts_at'] ) ? sanitize_text_field( wp_unslash( $_POST['starts_at'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			wp_die( esc_html__( 'You do not have permission to manage campaigns for this organisation.', 'wp-phishing' ) );
		}

		try {
			$this->campaigns->create(
				$organisation_uuid,
				$name,
				null,
				null,
				null,
				ApprovalModel::tryFrom( $approval_model ) ?? ApprovalModel::CustomerSelfApproval,
				ScheduleMode::tryFrom( $schedule_mode ) ?? ScheduleMode::Immediate,
				null,
				'' !== $starts_at ? new \DateTimeImmutable( $starts_at ) : null,
				null,
				get_current_user_id(),
				$this->tenant_guard->is_operator()
			);
		} catch ( \InvalidArgumentException $exception ) {
			wp_die( esc_html( $exception->getMessage() ) );
		}

		$this->redirect_to( 'campaigns', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_create_campaign_wave(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CAMPAIGNS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid       = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$campaign_uuid           = isset( $_POST['campaign_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_uuid'] ) ) : '';
		$name                    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$template_version_id     = isset( $_POST['template_version_id'] ) ? (int) $_POST['template_version_id'] : 0;
		$sender_identity_id      = isset( $_POST['sender_identity_id'] ) ? (int) $_POST['sender_identity_id'] : 0;
		$landing_page_version_id = ! empty( $_POST['landing_page_version_id'] ) ? (int) $_POST['landing_page_version_id'] : null;
		$recipient_group_id      = isset( $_POST['recipient_group_id'] ) ? (int) $_POST['recipient_group_id'] : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			wp_die( esc_html__( 'You do not have permission to manage campaigns for this organisation.', 'wp-phishing' ) );
		}

		$campaign = $this->campaigns->get( $organisation_uuid, $campaign_uuid );

		if ( null !== $campaign ) {
			try {
				$this->campaigns->create_wave( $campaign, $name, $template_version_id, $sender_identity_id, $landing_page_version_id, $recipient_group_id, null, null, get_current_user_id() );
			} catch ( \InvalidArgumentException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to(
			'campaigns',
			array(
				'wpp_org'      => $organisation_uuid,
				'wpp_campaign' => $campaign_uuid,
			)
		);
	}

	private function handle_submit_campaign(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CAMPAIGNS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$campaign_uuid     = isset( $_POST['campaign_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			wp_die( esc_html__( 'You do not have permission to manage campaigns for this organisation.', 'wp-phishing' ) );
		}

		$campaign = $this->campaigns->get( $organisation_uuid, $campaign_uuid );

		if ( null !== $campaign ) {
			try {
				$this->campaign_approvals->submit( $campaign, get_current_user_id() );
			} catch ( \InvalidArgumentException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to(
			'campaigns',
			array(
				'wpp_org'      => $organisation_uuid,
				'wpp_campaign' => $campaign_uuid,
			)
		);
	}

	private function handle_approve_campaign(): void {
		if ( ! current_user_can( Capabilities::APPROVE_CAMPAIGNS ) && ! current_user_can( Capabilities::MANAGE_CAMPAIGNS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$campaign_uuid     = isset( $_POST['campaign_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_uuid'] ) ) : '';
		$decision          = isset( $_POST['decision'] ) ? sanitize_text_field( wp_unslash( $_POST['decision'] ) ) : 'approved';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$is_operator = $this->tenant_guard->is_operator() && current_user_can( Capabilities::APPROVE_CAMPAIGNS );

		if ( ! $is_operator && ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			wp_die( esc_html__( 'You do not have permission to approve campaigns for this organisation.', 'wp-phishing' ) );
		}

		$campaign = $this->campaigns->get( $organisation_uuid, $campaign_uuid );

		if ( null !== $campaign ) {
			try {
				$this->campaign_approvals->decide( $campaign, get_current_user_id(), $is_operator ? 'alltime' : 'customer', 'rejected' !== $decision );
			} catch ( \InvalidArgumentException | \RuntimeException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to(
			'campaigns',
			array(
				'wpp_org'      => $organisation_uuid,
				'wpp_campaign' => $campaign_uuid,
			)
		);
	}

	private function handle_cancel_campaign(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CAMPAIGNS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$campaign_uuid     = isset( $_POST['campaign_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			wp_die( esc_html__( 'You do not have permission to manage campaigns for this organisation.', 'wp-phishing' ) );
		}

		$campaign = $this->campaigns->get( $organisation_uuid, $campaign_uuid );

		if ( null !== $campaign ) {
			try {
				$this->campaigns->cancel( $campaign, get_current_user_id() );
			} catch ( \InvalidArgumentException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to( 'campaigns', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_generate_report(): void {
		if ( ! current_user_can( Capabilities::VIEW_REPORTS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$campaign_uuid     = isset( $_POST['campaign_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_uuid'] ) ) : '';
		$visibility        = isset( $_POST['visibility'] ) ? sanitize_text_field( wp_unslash( $_POST['visibility'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator, MembershipRole::Analyst ) ) {
			wp_die( esc_html__( 'You do not have permission to generate reports for this organisation.', 'wp-phishing' ) );
		}

		$campaign = $this->campaigns->get( $organisation_uuid, $campaign_uuid );

		if ( null !== $campaign ) {
			$requested = ReportVisibility::tryFrom( $visibility ) ?? ReportVisibility::AggregateOnly;
			$permitted = $this->report_visibility_policy->permitted_for_generation( $requested, $organisation_uuid );

			try {
				$this->reports->generate( $campaign, null, $permitted, get_current_user_id() );
			} catch ( \RuntimeException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to(
			'reports',
			array(
				'wpp_org'      => $organisation_uuid,
				'wpp_campaign' => $campaign_uuid,
			)
		);
	}

	private function handle_issue_download_token(): void {
		if ( ! current_user_can( Capabilities::VIEW_REPORTS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$campaign_uuid     = isset( $_POST['campaign_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_uuid'] ) ) : '';
		$report_uuid       = isset( $_POST['report_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['report_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		// Every sibling handler in this file additionally scopes to the organisation named in the
		// request - VIEW_REPORTS alone (held by every operator, and the read-only integration role)
		// must not be sufficient to mint a token for an arbitrary organisation's report.
		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator, MembershipRole::Analyst ) ) {
			wp_die( esc_html__( 'You do not have permission to issue a download link for this organisation.', 'wp-phishing' ) );
		}

		$redirect_args = array(
			'wpp_org'      => $organisation_uuid,
			'wpp_campaign' => $campaign_uuid,
			'wpp_report'   => $report_uuid,
		);
		$report        = $this->reports->get( $organisation_uuid, $report_uuid );

		if ( null !== $report ) {
			// A token capable of retrieving named-recipient data may only be minted by someone
			// currently permitted to see it - the token itself becomes the sole authorisation for
			// whoever redeems it (Section 59), an anonymous bearer with no role to re-check.
			if ( ReportVisibility::AggregateOnly !== $report->visibility && ! $this->report_visibility_policy->may_view_named_results( $organisation_uuid ) ) {
				wp_die( esc_html__( 'You do not have permission to issue a download link for this report.', 'wp-phishing' ) );
			}

			// The raw token travels in this redirect's query string (visible in browser history)
			// rather than a session flash - a deliberate, documented trade-off for this
			// admin-only convenience link; the token remains expiring/use-limited/revocable
			// regardless (Section 59).
			$redirect_args['wpp_download_token'] = $this->download_tokens->issue( $report, created_by: get_current_user_id() );
		}

		$this->redirect_to( 'reports', $redirect_args );
	}

	private function handle_create_risk_weight_set(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$name       = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$is_default = ! empty( $_POST['is_default'] );
		$weights    = array();

		foreach ( TrackingEventType::cases() as $type ) {
			$field_name = 'weight_' . $type->value;

			if ( isset( $_POST[ $field_name ] ) ) {
				$weights[ $type->value ] = max( self::MIN_RISK_WEIGHT, min( self::MAX_RISK_WEIGHT, (int) $_POST[ $field_name ] ) );
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== trim( $name ) ) {
			$this->risk_weight_sets->create( $name, $weights, $is_default, get_current_user_id() );
		}

		$this->redirect_to( 'settings' );
	}

	private function handle_initiate_mail_integration(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$provider          = isset( $_POST['provider'] ) ? sanitize_text_field( wp_unslash( $_POST['provider'] ) ) : '';
		$capability        = isset( $_POST['capability'] ) ? sanitize_text_field( wp_unslash( $_POST['capability'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$provider_enum   = MailIntegrationProvider::tryFrom( $provider );
		$capability_enum = MailIntegrationCapability::tryFrom( $capability );

		if ( '' !== $organisation_uuid && null !== $provider_enum && null !== $capability_enum ) {
			$this->mail_integrations->initiate( $organisation_uuid, $provider_enum, $capability_enum, get_current_user_id() );
		}

		$this->redirect_to( 'mail-integrations', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_verify_mail_integration(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$integration_uuid  = isset( $_POST['integration_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['integration_uuid'] ) ) : '';
		$tenant_id         = isset( $_POST['tenant_id'] ) ? sanitize_text_field( wp_unslash( $_POST['tenant_id'] ) ) : '';
		$primary_domain    = isset( $_POST['primary_domain'] ) ? sanitize_text_field( wp_unslash( $_POST['primary_domain'] ) ) : '';
		$test_mailbox      = isset( $_POST['test_mailbox'] ) ? sanitize_text_field( wp_unslash( $_POST['test_mailbox'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$integration = $this->mail_integrations->get( $organisation_uuid, $integration_uuid );

		if ( null !== $integration ) {
			if ( MailIntegrationProvider::Microsoft365 === $integration->provider ) {
				$this->mail_integrations->verify_microsoft( $integration, $tenant_id );
			} else {
				$this->mail_integrations->verify_google( $integration, $primary_domain, $test_mailbox );
			}
		}

		$this->redirect_to( 'mail-integrations', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_revoke_mail_integration(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$integration_uuid  = isset( $_POST['integration_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['integration_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$integration = $this->mail_integrations->get( $organisation_uuid, $integration_uuid );

		if ( null !== $integration ) {
			$this->mail_integrations->revoke( $integration, get_current_user_id() );
		}

		$this->redirect_to( 'mail-integrations', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_grant_entitlement(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ENTITLEMENTS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid  = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$type               = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
		$allowance_quantity = isset( $_POST['allowance_quantity'] ) && '' !== $_POST['allowance_quantity'] ? max( 0, (int) $_POST['allowance_quantity'] ) : null;
		$reason             = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : null;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$type_enum = EntitlementType::tryFrom( $type );

		if ( '' !== $organisation_uuid && null !== $type_enum ) {
			$this->entitlements->grant( $organisation_uuid, WPP_PRODUCT_ID, $type_enum, $allowance_quantity, get_current_user_id(), $reason );
		}

		$this->redirect_to( 'entitlements', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_revoke_entitlement(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ENTITLEMENTS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$entitlement_uuid  = isset( $_POST['entitlement_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['entitlement_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $entitlement_uuid ) {
			$this->entitlements->revoke( $entitlement_uuid );
		}

		$this->redirect_to( 'entitlements', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_create_commercial_model(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_COMMERCIAL_MODELS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$name           = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$charging_basis = isset( $_POST['charging_basis'] ) ? sanitize_text_field( wp_unslash( $_POST['charging_basis'] ) ) : '';
		$currency       = isset( $_POST['currency'] ) ? sanitize_text_field( wp_unslash( $_POST['currency'] ) ) : 'GBP';
		$base_charge    = isset( $_POST['base_charge'] ) && '' !== $_POST['base_charge'] ? (float) $_POST['base_charge'] : null;
		$recipient_rate = isset( $_POST['recipient_rate'] ) && '' !== $_POST['recipient_rate'] ? (float) $_POST['recipient_rate'] : null;
		$message_rate   = isset( $_POST['message_rate'] ) && '' !== $_POST['message_rate'] ? (float) $_POST['message_rate'] : null;
		$campaign_rate  = isset( $_POST['campaign_rate'] ) && '' !== $_POST['campaign_rate'] ? (float) $_POST['campaign_rate'] : null;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$charging_basis_enum = ChargingBasis::tryFrom( $charging_basis );

		if ( '' !== trim( $name ) && null !== $charging_basis_enum ) {
			$this->commercial_models->create( $name, $charging_basis_enum, $currency, $base_charge, $recipient_rate, $message_rate, $campaign_rate );
		}

		$this->redirect_to( 'commercial-models' );
	}

	private function handle_archive_commercial_model(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_COMMERCIAL_MODELS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$commercial_model_uuid = isset( $_POST['commercial_model_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['commercial_model_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $commercial_model_uuid ) {
			$this->commercial_models->archive( $commercial_model_uuid );
		}

		$this->redirect_to( 'commercial-models' );
	}

	private function handle_assign_commercial_model(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_COMMERCIAL_MODELS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid     = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$commercial_model_uuid = isset( $_POST['commercial_model_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['commercial_model_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $organisation_uuid && '' !== $commercial_model_uuid ) {
			$this->commercial_models->assign_to_organisation( $organisation_uuid, $commercial_model_uuid, get_current_user_id() );
		}

		$this->redirect_to( 'entitlements', array( 'wpp_org' => $organisation_uuid ) );
	}

	private function handle_log_privacy_request(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_CUSTOMER_PLATFORM ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$email      = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$right_type = isset( $_POST['right_type'] ) ? sanitize_text_field( wp_unslash( $_POST['right_type'] ) ) : '';
		$channel    = isset( $_POST['channel'] ) ? sanitize_text_field( wp_unslash( $_POST['channel'] ) ) : '';
		$details    = isset( $_POST['details'] ) ? sanitize_textarea_field( wp_unslash( $_POST['details'] ) ) : null;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$right_type_enum = PrivacyRightType::tryFrom( $right_type );

		if ( is_email( $email ) && null !== $right_type_enum && '' !== trim( $channel ) ) {
			$this->privacy_requests->log_request( $email, $right_type_enum, $channel, $details );
		}

		$this->redirect_to( 'privacy-requests' );
	}

	/**
	 * Performs the underlying action for anonymisation/deletion requests before marking them
	 * complete - discovery/export/suppression requests are marked complete without any automatic
	 * action here (export is read via the request's own detail view; suppression is inherently
	 * organisation-scoped, so an operator completes that fulfilment on the existing per-organisation
	 * Suppressions screen and only marks the privacy request itself complete here).
	 */
	private function handle_fulfil_privacy_request(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_CUSTOMER_PLATFORM ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$request_uuid = isset( $_POST['request_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['request_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$request = '' !== $request_uuid ? $this->privacy_requests->get( $request_uuid ) : null;

		if ( null !== $request ) {
			if ( in_array( $request->right_type, array( PrivacyRightType::Anonymisation, PrivacyRightType::Deletion ), true ) ) {
				$this->privacy_requests->anonymise_by_email( $request->email );
			}

			$this->privacy_requests->complete( $request_uuid );
		}

		$this->redirect_to( 'privacy-requests' );
	}

	private function handle_reject_privacy_request(): void {
		if ( ! current_user_can( Capabilities::ALLTIME_MANAGE_CUSTOMER_PLATFORM ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$request_uuid = isset( $_POST['request_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['request_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $request_uuid ) {
			$this->privacy_requests->reject( $request_uuid );
		}

		$this->redirect_to( 'privacy-requests' );
	}

	private function handle_emergency_pause_sends(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		$this->emergency_controls->pause_all_sends( get_current_user_id() );

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_emergency_resume_sends(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		$this->emergency_controls->resume_all_sends( get_current_user_id() );

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_emergency_disable_tracking(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		$this->emergency_controls->disable_tracking( get_current_user_id() );

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_emergency_enable_tracking(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		$this->emergency_controls->enable_tracking( get_current_user_id() );

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_emergency_suspend_organisation(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $organisation_uuid ) {
			$this->emergency_controls->suspend_organisation( $organisation_uuid, get_current_user_id() );
		}

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_emergency_suppress_recipient(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$email             = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $organisation_uuid && is_email( $email ) ) {
			$this->emergency_controls->suppress_recipient( $organisation_uuid, $email, get_current_user_id() );
		}

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_emergency_disable_sender_domain(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$domain_uuid = isset( $_POST['domain_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['domain_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' !== $domain_uuid ) {
			$this->emergency_controls->disable_sender_domain( $domain_uuid, get_current_user_id() );
		}

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_emergency_cancel_campaign(): void {
		if ( ! current_user_can( Capabilities::MANAGE_EMERGENCY_CONTROLS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		$organisation_uuid = isset( $_POST['organisation_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['organisation_uuid'] ) ) : '';
		$campaign_uuid     = isset( $_POST['campaign_uuid'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_uuid'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$campaign = '' !== $organisation_uuid && '' !== $campaign_uuid ? $this->campaigns->get( $organisation_uuid, $campaign_uuid ) : null;

		if ( null !== $campaign ) {
			try {
				$this->emergency_controls->cancel_campaign( $campaign, get_current_user_id() );
			} catch ( \InvalidArgumentException $exception ) {
				wp_die( esc_html( $exception->getMessage() ) );
			}
		}

		$this->redirect_to( 'emergency-controls' );
	}

	private function handle_update_settings(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-phishing' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- see handle_create_organisation().
		update_option( 'wpp_remove_data_on_uninstall', ! empty( $_POST['remove_data_on_uninstall'] ) );

		// Retention (Section 54): 0 (the default, if left blank) means "keep forever" - the sweep
		// never deletes anything for a category an administrator hasn't explicitly configured a
		// period for. Only the two categories this increment actually sweeps are exposed here;
		// the remaining six named in Section 54 are a documented fast-follow (PLAN.md).
		update_option( 'wpp_retention_audit_log_days', isset( $_POST['retention_audit_log_days'] ) ? max( 0, (int) $_POST['retention_audit_log_days'] ) : 0 );
		update_option( 'wpp_retention_interactions_days', isset( $_POST['retention_interactions_days'] ) ? max( 0, (int) $_POST['retention_interactions_days'] ) : 0 );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$this->redirect_to( 'settings' );
	}

	/**
	 * @param array<string,string> $extra_query_args
	 */
	private function redirect_to( string $screen_slug, array $extra_query_args = array() ): void {
		$url = add_query_arg( array_merge( array( 'page' => self::MENU_SLUG . '-' . $screen_slug ), $extra_query_args ), admin_url( 'admin.php' ) );

		wp_safe_redirect( $url );
		exit;
	}

	// -----------------------------------------------------------------------------------
	// Screens
	// -----------------------------------------------------------------------------------

	public function render_overview(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'WP-Phishing', 'wp-phishing' ) . '</h1>';
		echo '<ul>';
		echo '<li>' . esc_html__( 'Organisations', 'wp-phishing' ) . ': ' . (int) $this->organisations->count_all() . '</li>';
		echo '<li>' . esc_html__( 'Suppressions recorded', 'wp-phishing' ) . ': ' . esc_html( $this->count_placeholder() ) . '</li>';
		echo '</ul></div>';
	}

	/**
	 * Total recipients/imports are organisation-scoped counts with no cross-organisation "count
	 * all" query built yet (Section 9's data model deliberately keeps every recipient query
	 * organisation-scoped) - the overview intentionally doesn't claim a number it can't cheaply
	 * produce yet, rather than running an unbounded cross-tenant COUNT(*) here.
	 */
	private function count_placeholder(): string {
		return __( 'see Suppressions screen per organisation', 'wp-phishing' );
	}

	public function render_organisations(): void {
		$organisations = $this->organisations->find_all( self::PER_PAGE, max( 1, (int) ( $_GET['paged'] ?? 1 ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.

		echo '<div class="wrap"><h1>' . esc_html__( 'Organisations', 'wp-phishing' ) . '</h1>';
		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Slug', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Created', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $organisations as $organisation ) {
			echo '<tr><td>' . esc_html( $organisation->name ) . '</td><td>' . esc_html( $organisation->slug ) . '</td><td>'
				. '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML (a hidden nonce input, optionally a referer field); this only re-echoes it as part of a larger concatenated string.
				. '<input type="hidden" name="wpp_admin_action" value="update_organisation_status">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
				. '<select name="status" onchange="this.form.submit()">';

			foreach ( OrganisationStatus::cases() as $status ) {
				echo '<option value="' . esc_attr( $status->value ) . '"' . selected( $status === $organisation->status, true, false ) . '>' . esc_html( $status->value ) . '</option>';
			}

			echo '</select></form></td><td>' . esc_html( $organisation->created_at->format( 'Y-m-d' ) ) . '</td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Create organisation', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML (a hidden nonce input, optionally a referer field); this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="wpp_admin_action" value="create_organisation">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create', 'wp-phishing' ) . '</button></p></form></div>';
	}

	public function render_domains(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Domains', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'domains' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built entirely from esc_*()-escaped fragments, see the method itself.

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Domain', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Method', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Verification status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Override', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $this->domains->find_all_for_organisation( $organisation->id ) as $domain ) {
			echo '<tr><td>' . esc_html( $domain->domain_ascii ) . '</td><td>' . esc_html( $domain->verification_method?->value ?? '' ) . '</td><td>' . esc_html( $domain->verification_status->value ) . '</td><td>';

			if ( DomainVerificationStatus::Verified !== $domain->verification_status ) {
				echo '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML (a hidden nonce input, optionally a referer field); this only re-echoes it as part of a larger concatenated string.
					. '<input type="hidden" name="wpp_admin_action" value="override_domain_verification">'
					. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
					. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
					. '<input type="text" name="reason" placeholder="' . esc_attr__( 'Documented authority / reason', 'wp-phishing' ) . '" required>'
					. ' <button type="submit" class="button">' . esc_html__( 'Mark verified', 'wp-phishing' ) . '</button></form>';
			}

			echo '</td></tr>';
		}

		echo '</tbody></table></div>';
	}

	public function render_recipients(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Recipients', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'recipients' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		$recipients = $this->recipients->find_all_for_organisation( $organisation->organisation_uuid, self::PER_PAGE, max( 1, (int) ( $_GET['paged'] ?? 1 ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$total_recipients = sprintf(
			/* translators: %d: recipient count */
			__( '%d recipient(s) total.', 'wp-phishing' ),
			$this->recipients->count_for_organisation( $organisation->organisation_uuid )
		);

		echo '<p>' . esc_html( $total_recipients ) . '</p>';

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Email', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Department', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $recipients as $recipient ) {
			echo '<tr><td>' . esc_html( $recipient->email ) . '</td><td>' . esc_html( trim( "{$recipient->given_name} {$recipient->family_name}" ) ) . '</td><td>' . esc_html( (string) $recipient->department ) . '</td><td>' . esc_html( $recipient->status->value ) . '</td></tr>';
		}

		echo '</tbody></table></div>';
	}

	public function render_groups(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Recipient Groups', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'groups' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Type', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Members', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->groups->find_all_for_organisation( $organisation->organisation_uuid ) as $group ) {
			echo '<tr><td>' . esc_html( $group->name ) . '</td><td>' . esc_html( $group->type->value ) . '</td><td>' . (int) $this->groups->count_members( $group->id ) . '</td><td>'
				. '<form method="post" onsubmit="return confirm(\'' . esc_js( __( 'Delete this group?', 'wp-phishing' ) ) . '\');">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML (a hidden nonce input, optionally a referer field); this only re-echoes it as part of a larger concatenated string.
				. '<input type="hidden" name="wpp_admin_action" value="delete_group">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
				. '<input type="hidden" name="group_uuid" value="' . esc_attr( $group->group_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Delete', 'wp-phishing' ) . '</button></form></td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Create group', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML (a hidden nonce input, optionally a referer field); this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="wpp_admin_action" value="create_group">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create', 'wp-phishing' ) . '</button></p></form></div>';
	}

	public function render_imports(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Recipient Imports', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'imports' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'File', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Valid', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Invalid', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Duplicate', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Suppressed', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Committed', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $this->imports->find_all_for_organisation( $organisation->organisation_uuid, self::PER_PAGE, 1 ) as $import ) {
			echo '<tr><td>' . esc_html( (string) $import->original_filename ) . '</td><td>' . esc_html( $import->status->value ) . '</td><td>' . (int) $import->valid_rows . '</td><td>' . (int) $import->invalid_rows . '</td><td>' . (int) $import->duplicate_rows . '</td><td>' . (int) $import->suppressed_rows . '</td><td>' . (int) $import->committed_rows . '</td></tr>';
		}

		echo '</tbody></table></div>';
	}

	public function render_suppressions(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Suppressions', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'suppressions' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Reason', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Source', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Active', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Created', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $this->suppressions->find_all_for_organisation( $organisation->organisation_uuid, self::PER_PAGE, 1 ) as $suppression ) {
			echo '<tr><td>' . esc_html( $suppression->reason->value ) . '</td><td>' . esc_html( $suppression->source ) . '</td><td>' . ( $suppression->is_active() ? esc_html__( 'Yes', 'wp-phishing' ) : esc_html__( 'No', 'wp-phishing' ) ) . '</td><td>' . esc_html( $suppression->created_at->format( 'Y-m-d' ) ) . '</td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Add suppression', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML (a hidden nonce input, optionally a referer field); this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="wpp_admin_action" value="create_suppression">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Email', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>'
			. '<p><label>' . esc_html__( 'Reason', 'wp-phishing' ) . '<br><select name="reason">';

		foreach ( SuppressionReason::cases() as $reason ) {
			echo '<option value="' . esc_attr( $reason->value ) . '">' . esc_html( $reason->value ) . '</option>';
		}

		echo '</select></label></p><p><button type="submit" class="button button-primary">' . esc_html__( 'Add', 'wp-phishing' ) . '</button></p></form></div>';
	}

	public function render_audit_log(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Audit Log', 'wp-phishing' ) . '</h1>';
		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Time', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Action', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Object', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Outcome', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Source', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $this->audit_logger->find_recent( 100 ) as $entry ) {
			echo '<tr><td>' . esc_html( (string) $entry['occurred_at'] ) . '</td><td>' . esc_html( (string) $entry['action'] ) . '</td><td>' . esc_html( $entry['object_type'] . ' ' . ( $entry['object_uuid'] ?? '' ) ) . '</td><td>' . esc_html( (string) $entry['outcome'] ) . '</td><td>' . esc_html( (string) $entry['source'] ) . '</td></tr>';
		}

		echo '</tbody></table></div>';
	}

	public function render_sender_domains(): void {
		$selected_uuid = isset( $_GET['wpp_sender_domain'] ) ? sanitize_text_field( wp_unslash( $_GET['wpp_sender_domain'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only selector state.

		echo '<div class="wrap"><h1>' . esc_html__( 'Sender Domains', 'wp-phishing' ) . '</h1>';
		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Domain', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Scope', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Health', 'wp-phishing' ) . '</th><th>' . esc_html__( 'SPF', 'wp-phishing' ) . '</th><th>' . esc_html__( 'DMARC', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		$domains = $this->sender_domains->list_all( 200, 1 );

		foreach ( $domains as $domain ) {
			$manage_url = add_query_arg(
				array(
					'page'              => self::MENU_SLUG . '-sender-domains',
					'wpp_sender_domain' => $domain->domain_uuid,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr><td><a href="' . esc_url( $manage_url ) . '">' . esc_html( $domain->domain ) . '</a></td>'
				. '<td>' . esc_html( $domain->organisation_uuid ?? __( 'Shared pool', 'wp-phishing' ) ) . '</td>'
				. '<td>' . esc_html( $domain->status->value ) . '</td>'
				. '<td>' . esc_html( $domain->health_status->value ) . '</td>'
				. '<td>' . esc_html( $domain->spf_status->value ) . '</td>'
				. '<td>' . esc_html( $domain->dmarc_status->value ) . '</td>'
				. '<td>'
				. '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
				. '<input type="hidden" name="wpp_admin_action" value="check_sender_domain_health">'
				. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Check health', 'wp-phishing' ) . '</button></form> '
				. '<form method="post" style="display:inline" onsubmit="return confirm(\'' . esc_js( __( 'Retire this sender domain?', 'wp-phishing' ) ) . '\');">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<input type="hidden" name="wpp_admin_action" value="retire_sender_domain">'
				. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Retire', 'wp-phishing' ) . '</button></form>'
				. '</td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Add sender domain', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="create_sender_domain">'
			. '<p><label>' . esc_html__( 'Domain', 'wp-phishing' ) . '<br><input type="text" name="domain" placeholder="phish-sim.example" required></label></p>'
			. '<p><label>' . esc_html__( 'Dedicated to organisation (leave blank for the shared pool; required for mailbox injection)', 'wp-phishing' ) . '<br><input type="text" name="organisation_uuid" placeholder="organisation UUID"></label></p>'
			. '<p><label>' . esc_html__( 'Delivery mode', 'wp-phishing' ) . '<br><select name="delivery_mode">';

		foreach ( SenderDeliveryMode::cases() as $mode ) {
			echo '<option value="' . esc_attr( $mode->value ) . '">' . esc_html( $mode->value ) . '</option>';
		}

		echo '</select></label> <small>' . esc_html__( 'Mailbox injection requires the organisation to already hold an active mail integration for the matching provider - see the Mail Integrations screen.', 'wp-phishing' ) . '</small></p>'
			. '<p><label>' . esc_html__( 'Mail provider override (leave blank to use the site-wide default; required for mailbox injection)', 'wp-phishing' ) . '<br><select name="mail_provider"><option value="">' . esc_html__( '- site default -', 'wp-phishing' ) . '</option>';

		foreach ( MailProviderId::cases() as $provider_id ) {
			echo '<option value="' . esc_attr( $provider_id->value ) . '">' . esc_html( $provider_id->value ) . '</option>';
		}

		echo '</select></label></p>'
			. '<p><label>' . esc_html__( 'Tracking hostname', 'wp-phishing' ) . '<br><input type="text" name="tracking_domain"></label></p>'
			. '<p><label>' . esc_html__( 'Landing hostname', 'wp-phishing' ) . '<br><input type="text" name="landing_domain"></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Add', 'wp-phishing' ) . '</button></p></form>';

		if ( '' !== $selected_uuid ) {
			$domain = $this->sender_domains->get( $selected_uuid );

			if ( null !== $domain ) {
				echo $this->render_sender_identities_section( $domain ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built entirely from esc_*()-escaped fragments, see the method itself.
			}
		}

		echo '</div>';
	}

	private function render_sender_identities_section( SenderDomain $domain ): string {
		$html = '<h2>' . sprintf(
			/* translators: %s: sender domain */
			esc_html__( 'Sender identities for %s', 'wp-phishing' ),
			esc_html( $domain->domain )
		) . '</h2><table class="widefat"><thead><tr><th>' . esc_html__( 'Address', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Display name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Scenario', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->sender_identities->list_for_domain( $domain ) as $identity ) {
			$next_status = SenderIdentityStatus::Active === $identity->status ? SenderIdentityStatus::Disabled : SenderIdentityStatus::Active;

			$html .= '<tr><td>' . esc_html( "{$identity->local_part}@{$domain->domain}" ) . '</td><td>' . esc_html( $identity->display_name ) . '</td><td>' . esc_html( $identity->scenario_classification?->value ?? '' ) . '</td><td>' . esc_html( $identity->status->value ) . '</td><td>'
				. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false )
				. '<input type="hidden" name="wpp_admin_action" value="update_sender_identity_status">'
				. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
				. '<input type="hidden" name="identity_uuid" value="' . esc_attr( $identity->identity_uuid ) . '">'
				. '<input type="hidden" name="status" value="' . esc_attr( $next_status->value ) . '">'
				. '<button type="submit" class="button">' . esc_html( SenderIdentityStatus::Active === $identity->status ? __( 'Disable', 'wp-phishing' ) : __( 'Enable', 'wp-phishing' ) ) . '</button></form></td></tr>';
		}

		$html .= '</tbody></table>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false )
			. '<input type="hidden" name="wpp_admin_action" value="create_sender_identity">'
			. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Local part', 'wp-phishing' ) . '<br><input type="text" name="local_part" placeholder="it-support" required></label></p>'
			. '<p><label>' . esc_html__( 'Display name', 'wp-phishing' ) . '<br><input type="text" name="display_name" placeholder="IT Support" required></label></p>'
			. '<p><label>' . esc_html__( 'Reply-to (optional)', 'wp-phishing' ) . '<br><input type="email" name="reply_to"></label></p>'
			. '<p><label>' . esc_html__( 'Scenario', 'wp-phishing' ) . '<br><select name="scenario_classification"><option value="">' . esc_html__( '- none -', 'wp-phishing' ) . '</option>';

		foreach ( ScenarioClassification::cases() as $scenario ) {
			$html .= '<option value="' . esc_attr( $scenario->value ) . '">' . esc_html( $scenario->value ) . '</option>';
		}

		return $html . '</select></label></p><p><button type="submit" class="button button-primary">' . esc_html__( 'Add identity', 'wp-phishing' ) . '</button></p></form>';
	}

	public function render_templates(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Templates', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'templates' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Scenario', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Difficulty', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Scope', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->templates->list_available_for_organisation( $organisation->organisation_uuid ) as $template ) {
			$next_status = TemplateStatus::Active === $template->status ? TemplateStatus::Archived : TemplateStatus::Active;

			echo '<tr><td>' . esc_html( $template->name ) . '</td><td>' . esc_html( $template->scenario->value ) . '</td><td>' . esc_html( $template->difficulty->value ) . '</td><td>' . esc_html( null === $template->organisation_uuid ? __( 'Shared library', 'wp-phishing' ) : __( 'This organisation', 'wp-phishing' ) ) . '</td><td>' . esc_html( $template->status->value ) . '</td><td>'
				. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
				. '<input type="hidden" name="wpp_admin_action" value="update_template_status">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
				. '<input type="hidden" name="template_uuid" value="' . esc_attr( $template->template_uuid ) . '">'
				. '<input type="hidden" name="status" value="' . esc_attr( $next_status->value ) . '">'
				. '<button type="submit" class="button">' . esc_html( TemplateStatus::Active === $template->status ? __( 'Archive', 'wp-phishing' ) : __( 'Activate', 'wp-phishing' ) ) . '</button></form></td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Create template', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="create_template">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><label>' . esc_html__( 'Scenario', 'wp-phishing' ) . '<br><select name="scenario">';

		foreach ( Scenario::cases() as $scenario ) {
			echo '<option value="' . esc_attr( $scenario->value ) . '">' . esc_html( $scenario->value ) . '</option>';
		}

		echo '</select></label></p><p><label>' . esc_html__( 'Difficulty', 'wp-phishing' ) . '<br><select name="difficulty">';

		foreach ( Difficulty::cases() as $difficulty ) {
			echo '<option value="' . esc_attr( $difficulty->value ) . '"' . selected( Difficulty::Moderate === $difficulty, true, false ) . '>' . esc_html( $difficulty->value ) . '</option>';
		}

		echo '</select></label></p>'
			. '<p><label>' . esc_html__( 'From display name', 'wp-phishing' ) . '<br><input type="text" name="from_display_name" placeholder="IT Support" required></label></p>'
			. '<p><label>' . esc_html__( 'Subject', 'wp-phishing' ) . '<br><input type="text" name="subject" style="width:100%" required></label></p>'
			. '<p><label>' . esc_html__( 'HTML body (may use {{given_name}}, {{family_name}}, {{organisation_name}}, {{department}}, {{campaign_token}})', 'wp-phishing' ) . '<br><textarea name="html_body" rows="8" style="width:100%"></textarea></label></p>'
			. '<p><label>' . esc_html__( 'Text body', 'wp-phishing' ) . '<br><textarea name="text_body" rows="4" style="width:100%"></textarea></label></p>'
			. '<p><label><input type="checkbox" name="shared" value="1"> ' . esc_html__( 'Add to the shared library (available to every organisation) instead of this one only', 'wp-phishing' ) . '</label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create', 'wp-phishing' ) . '</button></p></form></div>';
	}

	public function render_landing_pages(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Landing Pages', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'landing-pages' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Mode', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Scope', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->landing_pages->list_available_for_organisation( $organisation->organisation_uuid ) as $landing_page ) {
			$next_status = LandingPageStatus::Active === $landing_page->status ? LandingPageStatus::Archived : LandingPageStatus::Active;

			echo '<tr><td>' . esc_html( $landing_page->name ) . '</td><td>' . esc_html( $landing_page->mode->value ) . '</td><td>' . esc_html( null === $landing_page->organisation_uuid ? __( 'Shared library', 'wp-phishing' ) : __( 'This organisation', 'wp-phishing' ) ) . '</td><td>' . esc_html( $landing_page->status->value ) . '</td><td>'
				. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
				. '<input type="hidden" name="wpp_admin_action" value="update_landing_page_status">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
				. '<input type="hidden" name="landing_page_uuid" value="' . esc_attr( $landing_page->landing_page_uuid ) . '">'
				. '<input type="hidden" name="status" value="' . esc_attr( $next_status->value ) . '">'
				. '<button type="submit" class="button">' . esc_html( LandingPageStatus::Active === $landing_page->status ? __( 'Archive', 'wp-phishing' ) : __( 'Activate', 'wp-phishing' ) ) . '</button></form></td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Create landing page', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="create_landing_page">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><label>' . esc_html__( 'Mode', 'wp-phishing' ) . '<br><select name="mode">';

		foreach ( LandingPageMode::cases() as $mode ) {
			echo '<option value="' . esc_attr( $mode->value ) . '">' . esc_html( $mode->value ) . '</option>';
		}

		echo '</select></label></p>'
			. '<p><label>' . esc_html__( 'Page HTML (the simulated page itself - leave blank for click-only)', 'wp-phishing' ) . '<br><textarea name="html_body" rows="8" style="width:100%"></textarea></label></p>'
			. '<p><label>' . esc_html__( 'Educational content shown afterwards', 'wp-phishing' ) . '<br><textarea name="educational_html" rows="4" style="width:100%"></textarea></label></p>'
			. '<p><label><input type="checkbox" name="shared" value="1"> ' . esc_html__( 'Add to the shared library (available to every organisation) instead of this one only', 'wp-phishing' ) . '</label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create', 'wp-phishing' ) . '</button></p></form></div>';
	}

	public function render_campaigns(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Campaigns', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'campaigns' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Approval model', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Schedule', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Starts', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->campaigns->list_for_organisation( $organisation->organisation_uuid ) as $campaign ) {
			$manage_url = add_query_arg(
				array(
					'page'         => self::MENU_SLUG . '-campaigns',
					'wpp_org'      => $organisation->organisation_uuid,
					'wpp_campaign' => $campaign->campaign_uuid,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr><td><a href="' . esc_url( $manage_url ) . '">' . esc_html( $campaign->name ) . '</a></td>'
				. '<td>' . esc_html( $campaign->status->value ) . '</td>'
				. '<td>' . esc_html( $campaign->approval_model->value ) . '</td>'
				. '<td>' . esc_html( $campaign->schedule_mode->value ) . '</td>'
				. '<td>' . esc_html( $campaign->starts_at?->format( 'Y-m-d H:i' ) ?? '' ) . '</td>'
				. '<td></td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Create campaign', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="create_campaign">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><label>' . esc_html__( 'Approval model', 'wp-phishing' ) . '<br><select name="approval_model">';

		foreach ( ApprovalModel::cases() as $model ) {
			echo '<option value="' . esc_attr( $model->value ) . '">' . esc_html( $model->value ) . '</option>';
		}

		echo '</select></label></p><p><label>' . esc_html__( 'Schedule mode', 'wp-phishing' ) . '<br><select name="schedule_mode" onchange="document.getElementById(\'wpp-starts-at\').style.display = this.value === \'immediate\' ? \'none\' : \'block\';">';

		foreach ( ScheduleMode::cases() as $mode ) {
			echo '<option value="' . esc_attr( $mode->value ) . '">' . esc_html( $mode->value ) . '</option>';
		}

		echo '</select></label></p><p id="wpp-starts-at" style="display:none"><label>' . esc_html__( 'Starts at (required unless immediate)', 'wp-phishing' ) . '<br><input type="datetime-local" name="starts_at"></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create', 'wp-phishing' ) . '</button></p></form>';

		$selected_uuid = isset( $_GET['wpp_campaign'] ) ? sanitize_text_field( wp_unslash( $_GET['wpp_campaign'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only selector state.

		if ( '' !== $selected_uuid ) {
			$campaign = $this->campaigns->get( $organisation->organisation_uuid, $selected_uuid );

			if ( null !== $campaign ) {
				echo $this->render_campaign_detail( $campaign ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built entirely from esc_*()-escaped fragments, see the method itself.
			}
		}

		echo '</div>';
	}

	private function render_campaign_detail( Campaign $campaign ): string {
		$html = '<h2>' . sprintf( /* translators: %s: campaign name */ esc_html__( 'Campaign: %s', 'wp-phishing' ), esc_html( $campaign->name ) ) . '</h2>'
			. '<p>' . esc_html__( 'Status', 'wp-phishing' ) . ': ' . esc_html( $campaign->status->value ) . '</p>';

		$html .= '<p>';

		if ( CampaignStatus::Draft === $campaign->status ) {
			$html .= $this->campaign_action_form( $campaign, 'submit_campaign', __( 'Submit for approval', 'wp-phishing' ) );
		}

		if ( CampaignStatus::AwaitingApproval === $campaign->status ) {
			$html .= $this->campaign_action_form( $campaign, 'approve_campaign', __( 'Approve', 'wp-phishing' ), array( 'decision' => 'approved' ) );
			$html .= ' ' . $this->campaign_action_form( $campaign, 'approve_campaign', __( 'Reject', 'wp-phishing' ), array( 'decision' => 'rejected' ) );
		}

		if ( ! in_array( $campaign->status, array( CampaignStatus::Completed, CampaignStatus::Cancelled ), true ) ) {
			$html .= ' ' . $this->campaign_action_form( $campaign, 'cancel_campaign', __( 'Cancel campaign', 'wp-phishing' ), array(), true );
		}

		$html .= '</p>';

		$html .= '<h3>' . esc_html__( 'Waves', 'wp-phishing' ) . '</h3><table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Recipients', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		$waves = $this->campaigns->list_waves( $campaign );

		foreach ( $waves as $wave ) {
			$html .= '<tr><td>' . esc_html( $wave->name ) . '</td><td>' . esc_html( $wave->status->value ) . '</td><td>' . esc_html( (string) $wave->recipient_group_id ) . '</td></tr>';
		}

		$html .= '</tbody></table>';

		if ( array() === $waves && CampaignStatus::Draft === $campaign->status ) {
			$html .= '<h3>' . esc_html__( 'Add wave', 'wp-phishing' ) . '</h3>'
				. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false )
				. '<input type="hidden" name="wpp_admin_action" value="create_campaign_wave">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $campaign->organisation_uuid ) . '">'
				. '<input type="hidden" name="campaign_uuid" value="' . esc_attr( $campaign->campaign_uuid ) . '">'
				. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
				. '<p><label>' . esc_html__( 'Template version ID', 'wp-phishing' ) . '<br><input type="number" name="template_version_id" required></label>'
				. ' <small>' . esc_html__( 'Find this on the Templates screen after creating a template - each template starts at version 1.', 'wp-phishing' ) . '</small></p>'
				. '<p><label>' . esc_html__( 'Sender identity ID', 'wp-phishing' ) . '<br><input type="number" name="sender_identity_id" required></label>'
				. ' <small>' . esc_html__( 'Find this on the Sender Domains screen.', 'wp-phishing' ) . '</small></p>'
				. '<p><label>' . esc_html__( 'Landing page version ID (optional)', 'wp-phishing' ) . '<br><input type="number" name="landing_page_version_id"></label></p>'
				. '<p><label>' . esc_html__( 'Recipient group', 'wp-phishing' ) . '<br><select name="recipient_group_id">';

			foreach ( $this->groups->find_all_for_organisation( $campaign->organisation_uuid ) as $group ) {
				$html .= '<option value="' . esc_attr( (string) $group->id ) . '">' . esc_html( $group->name ) . ' (' . (int) $this->groups->count_members( $group->id ) . ')</option>';
			}

			$html .= '</select></label></p><p><button type="submit" class="button button-primary">' . esc_html__( 'Add wave', 'wp-phishing' ) . '</button></p></form>';
		}

		return $html;
	}

	/**
	 * @param array<string,string> $extra_fields
	 */
	private function campaign_action_form( Campaign $campaign, string $action, string $label, array $extra_fields = array(), bool $confirm = false ): string {
		$form = '<form method="post" style="display:inline"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( __( 'Are you sure?', 'wp-phishing' ) ) . '\');"' : '' ) . '>'
			. wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false )
			. '<input type="hidden" name="wpp_admin_action" value="' . esc_attr( $action ) . '">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $campaign->organisation_uuid ) . '">'
			. '<input type="hidden" name="campaign_uuid" value="' . esc_attr( $campaign->campaign_uuid ) . '">';

		foreach ( $extra_fields as $field_name => $field_value ) {
			$form .= '<input type="hidden" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $field_value ) . '">';
		}

		return $form . '<button type="submit" class="button">' . esc_html( $label ) . '</button></form>';
	}

	public function render_reports(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Reports', 'wp-phishing' ) . '</h1>';
		echo $this->render_organisation_selector( 'reports' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Campaign', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->campaigns->list_for_organisation( $organisation->organisation_uuid ) as $campaign ) {
			$manage_url = add_query_arg(
				array(
					'page'         => self::MENU_SLUG . '-reports',
					'wpp_org'      => $organisation->organisation_uuid,
					'wpp_campaign' => $campaign->campaign_uuid,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr><td><a href="' . esc_url( $manage_url ) . '">' . esc_html( $campaign->name ) . '</a></td><td>' . esc_html( $campaign->status->value ) . '</td><td></td></tr>';
		}

		echo '</tbody></table>';

		$selected_campaign_uuid = isset( $_GET['wpp_campaign'] ) ? sanitize_text_field( wp_unslash( $_GET['wpp_campaign'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only selector state.

		if ( '' !== $selected_campaign_uuid ) {
			$campaign = $this->campaigns->get( $organisation->organisation_uuid, $selected_campaign_uuid );

			if ( null !== $campaign ) {
				echo $this->render_reports_for_campaign( $campaign ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built entirely from esc_*()-escaped fragments and HtmlRenderer's own output, see the method itself.
			}
		}

		echo '</div>';
	}

	private function render_reports_for_campaign( Campaign $campaign ): string {
		$html = '<h2>' . sprintf( /* translators: %s: campaign name */ esc_html__( 'Reports for: %s', 'wp-phishing' ), esc_html( $campaign->name ) ) . '</h2>';

		$reports = $this->reports->list_for_campaign( $campaign );

		$html .= '<table class="widefat"><thead><tr><th>' . esc_html__( 'Generated', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Visibility', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $reports as $report ) {
			$view_url = add_query_arg(
				array(
					'page'         => self::MENU_SLUG . '-reports',
					'wpp_org'      => $campaign->organisation_uuid,
					'wpp_campaign' => $campaign->campaign_uuid,
					'wpp_report'   => $report->report_uuid,
				),
				admin_url( 'admin.php' )
			);

			$html .= '<tr><td><a href="' . esc_url( $view_url ) . '">' . esc_html( $report->generated_at->format( 'Y-m-d H:i' ) ) . '</a></td><td>' . esc_html( $report->visibility->value ) . '</td><td>'
				. '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false )
				. '<input type="hidden" name="wpp_admin_action" value="issue_download_token">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $campaign->organisation_uuid ) . '">'
				. '<input type="hidden" name="campaign_uuid" value="' . esc_attr( $campaign->campaign_uuid ) . '">'
				. '<input type="hidden" name="report_uuid" value="' . esc_attr( $report->report_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Get PDF download link', 'wp-phishing' ) . '</button></form></td></tr>';
		}

		$html .= '</tbody></table>';

		$download_token = isset( $_GET['wpp_download_token'] ) ? sanitize_text_field( wp_unslash( $_GET['wpp_download_token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, freshly-issued token display; the issuing POST itself was nonce-verified.

		if ( '' !== $download_token ) {
			$download_url = home_url( "/reports/download/{$download_token}/" );
			$html        .= '<p>' . esc_html__( 'Download link (expires in 7 days):', 'wp-phishing' ) . ' <a href="' . esc_url( $download_url ) . '">' . esc_html( $download_url ) . '</a></p>';
		}

		$html .= '<h3>' . esc_html__( 'Generate a new report', 'wp-phishing' ) . '</h3>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false )
			. '<input type="hidden" name="wpp_admin_action" value="generate_report">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $campaign->organisation_uuid ) . '">'
			. '<input type="hidden" name="campaign_uuid" value="' . esc_attr( $campaign->campaign_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Named-result visibility', 'wp-phishing' ) . '<br><select name="visibility">';

		foreach ( ReportVisibility::cases() as $visibility ) {
			$html .= '<option value="' . esc_attr( $visibility->value ) . '">' . esc_html( $visibility->value ) . '</option>';
		}

		$html .= '</select></label> <small>' . esc_html__( 'Downgraded automatically to aggregate-only unless you hold named-result permission and named reporting is enabled.', 'wp-phishing' ) . '</small></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Generate report', 'wp-phishing' ) . '</button></p></form>';

		$selected_report_uuid = isset( $_GET['wpp_report'] ) ? sanitize_text_field( wp_unslash( $_GET['wpp_report'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only selector state.

		if ( '' !== $selected_report_uuid ) {
			$report = $this->reports->get( $campaign->organisation_uuid, $selected_report_uuid );

			if ( null !== $report ) {
				// Re-checked at every view, not just at generation (Section 40) - a role change or
				// disabled feature flag must hide named results from a report that already has
				// them, the same guarantee the REST JSON view already provides.
				$visible_content = $this->report_visibility_policy->strip_named_results_if_unauthorised( $report->content, $report->visibility, $campaign->organisation_uuid );
				$html           .= ( new HtmlRenderer() )->render_content( $report, $visible_content );
			}
		}

		return $html;
	}

	public function render_mail_integrations(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Mail Integrations', 'wp-phishing' ) . '</h1>'
			. '<p>' . esc_html__( 'Grants a customer organisation makes to Alltime against their own Microsoft 365 or Google Workspace tenant, enabling mailbox-injection delivery (writing simulations directly into a mailbox) as an alternative to API-send. Each capability is authorised independently.', 'wp-phishing' ) . '</p>';
		echo $this->render_organisation_selector( 'mail-integrations' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Provider', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Capability', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Tenant', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->mail_integrations->list_for_organisation( $organisation->organisation_uuid ) as $integration ) {
			echo '<tr><td>' . esc_html( $integration->provider->value ) . '</td><td>' . esc_html( $integration->capability->value ) . '</td><td>' . esc_html( $integration->status->value ) . '</td><td>' . esc_html( (string) $integration->tenant_identifier ) . '</td><td>';

			if ( MailIntegrationStatus::Active !== $integration->status ) {
				echo '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
					. '<input type="hidden" name="wpp_admin_action" value="verify_mail_integration">'
					. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
					. '<input type="hidden" name="integration_uuid" value="' . esc_attr( $integration->integration_uuid ) . '">';

				echo MailIntegrationProvider::Microsoft365 === $integration->provider // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built entirely from esc_*()-escaped fragments.
					? '<input type="text" name="tenant_id" placeholder="' . esc_attr__( 'Customer Entra tenant ID', 'wp-phishing' ) . '" required>'
					: '<input type="text" name="primary_domain" placeholder="' . esc_attr__( 'Primary Workspace domain', 'wp-phishing' ) . '" required> <input type="email" name="test_mailbox" placeholder="' . esc_attr__( 'A real mailbox to test against', 'wp-phishing' ) . '" required>';

				echo ' <button type="submit" class="button">' . esc_html__( 'Verify', 'wp-phishing' ) . '</button></form> ';
			}

			echo '<form method="post" style="display:inline" onsubmit="return confirm(\'' . esc_js( __( 'Revoke this integration?', 'wp-phishing' ) ) . '\');">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<input type="hidden" name="wpp_admin_action" value="revoke_mail_integration">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
				. '<input type="hidden" name="integration_uuid" value="' . esc_attr( $integration->integration_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Revoke', 'wp-phishing' ) . '</button></form>';

			echo '</td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Initiate a new integration', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="initiate_mail_integration">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Provider', 'wp-phishing' ) . '<br><select name="provider">';

		foreach ( MailIntegrationProvider::cases() as $provider ) {
			echo '<option value="' . esc_attr( $provider->value ) . '">' . esc_html( $provider->value ) . '</option>';
		}

		echo '</select></label></p><p><label>' . esc_html__( 'Capability', 'wp-phishing' ) . '<br><select name="capability">';

		foreach ( MailIntegrationCapability::cases() as $capability ) {
			echo '<option value="' . esc_attr( $capability->value ) . '">' . esc_html( $capability->value ) . '</option>';
		}

		echo '</select></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Initiate', 'wp-phishing' ) . '</button></p></form>'
			. '<p><small>' . esc_html__( 'For Microsoft, initiating creates a pending grant; send the customer\'s tenant admin the consent URL generated via the REST API, then verify once they confirm. For Google, share the service account email and scope shown via the REST API for the customer to enter in their own Workspace Admin Console domain-wide delegation settings, then verify against a real mailbox.', 'wp-phishing' ) . '</small></p>';

		echo '</div>';
	}

	public function render_entitlements(): void {
		$organisation = $this->selected_organisation();

		echo '<div class="wrap"><h1>' . esc_html__( 'Entitlements', 'wp-phishing' ) . '</h1>'
			. '<p>' . esc_html__( 'What an organisation is currently allowed to use (Section 50) - campaign approval checks against these before a campaign may be scheduled.', 'wp-phishing' ) . '</p>';
		echo $this->render_organisation_selector( 'entitlements' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( null === $organisation ) {
			echo '</div>';
			return;
		}

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Type', 'wp-phishing' ) . '</th><th>' . esc_html__( 'State', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Allowance', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Consumed', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Expires', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->entitlements->find_all_for_organisation( $organisation->organisation_uuid, WPP_PRODUCT_ID ) as $entitlement ) {
			echo '<tr><td>' . esc_html( $entitlement->type->value ) . '</td><td>' . esc_html( $entitlement->state->value ) . '</td><td>' . esc_html( null !== $entitlement->allowance_quantity ? (string) $entitlement->allowance_quantity : __( 'Unlimited', 'wp-phishing' ) ) . '</td><td>' . (int) $entitlement->consumed_quantity . '</td><td>' . esc_html( $entitlement->expires_at?->format( 'Y-m-d' ) ?? '' ) . '</td><td>';

			if ( ! $entitlement->state->is_terminal() ) {
				echo '<form method="post" style="display:inline" onsubmit="return confirm(\'' . esc_js( __( 'Revoke this entitlement?', 'wp-phishing' ) ) . '\');">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
					. '<input type="hidden" name="wpp_admin_action" value="revoke_entitlement">'
					. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
					. '<input type="hidden" name="entitlement_uuid" value="' . esc_attr( $entitlement->entitlement_uuid ) . '">'
					. '<button type="submit" class="button">' . esc_html__( 'Revoke', 'wp-phishing' ) . '</button></form>';
			}

			echo '</td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Grant an entitlement', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="grant_entitlement">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Type', 'wp-phishing' ) . '<br><select name="type">';

		foreach ( EntitlementType::cases() as $type ) {
			echo '<option value="' . esc_attr( $type->value ) . '">' . esc_html( $type->value ) . '</option>';
		}

		echo '</select></label></p>'
			. '<p><label>' . esc_html__( 'Allowance quantity (leave blank for unlimited, or for a one-shot type)', 'wp-phishing' ) . '<br><input type="number" min="0" name="allowance_quantity"></label></p>'
			. '<p><label>' . esc_html__( 'Reason', 'wp-phishing' ) . '<br><input type="text" name="reason"></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Grant', 'wp-phishing' ) . '</button></p></form>';

		$assigned_model = $this->commercial_models->assigned_to( $organisation->organisation_uuid );

		echo '<h2>' . esc_html__( 'Commercial model', 'wp-phishing' ) . '</h2>'
			. '<p>' . esc_html( null !== $assigned_model ? $assigned_model->name . ' (' . $assigned_model->charging_basis->value . ')' : __( 'No commercial model assigned - unrestricted.', 'wp-phishing' ) ) . '</p>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="assign_commercial_model">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Assign', 'wp-phishing' ) . '<br><select name="commercial_model_uuid">';

		foreach ( $this->commercial_models->list_all() as $model ) {
			echo '<option value="' . esc_attr( $model->commercial_model_uuid ) . '">' . esc_html( $model->name ) . '</option>';
		}

		echo '</select></label> <button type="submit" class="button">' . esc_html__( 'Assign', 'wp-phishing' ) . '</button></p></form>';

		echo '</div>';
	}

	public function render_commercial_models(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Commercial Models', 'wp-phishing' ) . '</h1>'
			. '<p>' . esc_html__( 'Reusable charging-basis templates (Section 46-48) - assign one to an organisation from its Entitlements screen. The campaign engine never calculates a charge from these; they only publish accurate usage information for HaloPSA to consume.', 'wp-phishing' ) . '</p>';

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Charging basis', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->commercial_models->list_all() as $model ) {
			echo '<tr><td>' . esc_html( $model->name ) . '</td><td>' . esc_html( $model->charging_basis->value ) . '</td><td>' . esc_html( $model->status->value ) . '</td><td>';

			if ( CommercialModelStatus::Active === $model->status ) {
				echo '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
					. '<input type="hidden" name="wpp_admin_action" value="archive_commercial_model">'
					. '<input type="hidden" name="commercial_model_uuid" value="' . esc_attr( $model->commercial_model_uuid ) . '">'
					. '<button type="submit" class="button">' . esc_html__( 'Archive', 'wp-phishing' ) . '</button></form>';
			}

			echo '</td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Add commercial model', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="create_commercial_model">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><label>' . esc_html__( 'Charging basis', 'wp-phishing' ) . '<br><select name="charging_basis">';

		foreach ( ChargingBasis::cases() as $basis ) {
			echo '<option value="' . esc_attr( $basis->value ) . '">' . esc_html( $basis->value ) . '</option>';
		}

		echo '</select></label></p>'
			. '<p><label>' . esc_html__( 'Currency', 'wp-phishing' ) . '<br><input type="text" name="currency" value="GBP" maxlength="8"></label></p>'
			. '<p><label>' . esc_html__( 'Base charge', 'wp-phishing' ) . '<br><input type="number" step="0.01" name="base_charge"></label></p>'
			. '<p><label>' . esc_html__( 'Recipient rate', 'wp-phishing' ) . '<br><input type="number" step="0.0001" name="recipient_rate"></label></p>'
			. '<p><label>' . esc_html__( 'Message rate', 'wp-phishing' ) . '<br><input type="number" step="0.0001" name="message_rate"></label></p>'
			. '<p><label>' . esc_html__( 'Campaign rate', 'wp-phishing' ) . '<br><input type="number" step="0.01" name="campaign_rate"></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Add', 'wp-phishing' ) . '</button></p></form>';

		echo '</div>';
	}

	public function render_privacy_requests(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Privacy Requests', 'wp-phishing' ) . '</h1>'
			. '<p>' . esc_html__( 'Log a personal-data rights request received through any channel (Section 53), then fulfil it here. Admin-initiated only - there is no public self-service submission form.', 'wp-phishing' ) . '</p>';

		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Email', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Right', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Due', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->privacy_requests->list_all() as $request ) {
			echo '<tr><td>' . esc_html( $request->email ) . '</td><td>' . esc_html( $request->right_type->value ) . '</td><td>' . esc_html( $request->status->value ) . '</td><td>' . esc_html( $request->due_at->format( 'Y-m-d' ) ) . '</td><td>';

			if ( PrivacyRequestStatus::Received === $request->status || PrivacyRequestStatus::InProgress === $request->status ) {
				if ( in_array( $request->right_type, array( PrivacyRightType::Discovery, PrivacyRightType::Export ), true ) ) {
					$export = $this->privacy_requests->export_personal_data( $request->email );
					echo '<pre style="white-space:pre-wrap;max-width:400px;">' . esc_html( null !== $export ? wp_json_encode( $export, JSON_PRETTY_PRINT ) : __( 'No matching contact found.', 'wp-phishing' ) ) . '</pre>';
				}

				echo '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
					. '<input type="hidden" name="wpp_admin_action" value="fulfil_privacy_request">'
					. '<input type="hidden" name="request_uuid" value="' . esc_attr( $request->request_uuid ) . '">'
					. '<button type="submit" class="button">' . esc_html__( 'Mark fulfilled', 'wp-phishing' ) . '</button></form> '
					. '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					. '<input type="hidden" name="wpp_admin_action" value="reject_privacy_request">'
					. '<input type="hidden" name="request_uuid" value="' . esc_attr( $request->request_uuid ) . '">'
					. '<button type="submit" class="button">' . esc_html__( 'Reject', 'wp-phishing' ) . '</button></form>';
			}

			echo '</td></tr>';
		}

		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Log a new request', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="log_privacy_request">'
			. '<p><label>' . esc_html__( 'Email', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>'
			. '<p><label>' . esc_html__( 'Right', 'wp-phishing' ) . '<br><select name="right_type">';

		foreach ( PrivacyRightType::cases() as $right_type ) {
			echo '<option value="' . esc_attr( $right_type->value ) . '">' . esc_html( $right_type->value ) . '</option>';
		}

		echo '</select></label></p>'
			. '<p><label>' . esc_html__( 'Channel it arrived through', 'wp-phishing' ) . '<br><input type="text" name="channel" placeholder="email" required></label></p>'
			. '<p><label>' . esc_html__( 'Details', 'wp-phishing' ) . '<br><textarea name="details" rows="3"></textarea></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Log request', 'wp-phishing' ) . '</button></p></form>';

		echo '</div>';
	}

	public function render_emergency_controls(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Emergency Controls', 'wp-phishing' ) . '</h1>'
			. '<p>' . esc_html__( 'Section 71. Every action here is audited.', 'wp-phishing' ) . '</p>';

		$sends_paused      = $this->emergency_controls->sends_are_paused();
		$tracking_disabled = $this->emergency_controls->tracking_is_disabled();

		echo '<h2>' . esc_html__( 'Global sends', 'wp-phishing' ) . '</h2>'
			. '<p>' . esc_html( $sends_paused ? __( 'All sending is currently PAUSED.', 'wp-phishing' ) : __( 'Sending is currently active.', 'wp-phishing' ) ) . '</p>'
			. '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see render_organisations().
			. '<input type="hidden" name="wpp_admin_action" value="' . esc_attr( $sends_paused ? 'emergency_resume_sends' : 'emergency_pause_sends' ) . '">'
			. '<button type="submit" class="button button-primary">' . esc_html( $sends_paused ? __( 'Resume all sending', 'wp-phishing' ) : __( 'Pause all sending', 'wp-phishing' ) ) . '</button></form>';

		echo '<h2>' . esc_html__( 'Global tracking', 'wp-phishing' ) . '</h2>'
			. '<p>' . esc_html( $tracking_disabled ? __( 'Tracking is currently DISABLED - no new events are being recorded.', 'wp-phishing' ) : __( 'Tracking is currently active.', 'wp-phishing' ) ) . '</p>'
			. '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="' . esc_attr( $tracking_disabled ? 'emergency_enable_tracking' : 'emergency_disable_tracking' ) . '">'
			. '<button type="submit" class="button button-primary">' . esc_html( $tracking_disabled ? __( 'Re-enable tracking', 'wp-phishing' ) : __( 'Disable tracking', 'wp-phishing' ) ) . '</button></form>';

		echo '<h2>' . esc_html__( 'Suspend an organisation', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="emergency_suspend_organisation">'
			. '<p><label>' . esc_html__( 'Organisation UUID', 'wp-phishing' ) . '<br><input type="text" name="organisation_uuid" required></label></p>'
			. '<p><button type="submit" class="button">' . esc_html__( 'Suspend', 'wp-phishing' ) . '</button></p></form>';

		echo '<h2>' . esc_html__( 'Suppress a recipient', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="emergency_suppress_recipient">'
			. '<p><label>' . esc_html__( 'Organisation UUID', 'wp-phishing' ) . '<br><input type="text" name="organisation_uuid" required></label></p>'
			. '<p><label>' . esc_html__( 'Email', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>'
			. '<p><button type="submit" class="button">' . esc_html__( 'Suppress', 'wp-phishing' ) . '</button></p></form>';

		echo '<h2>' . esc_html__( 'Disable a sender domain', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="emergency_disable_sender_domain">'
			. '<p><label>' . esc_html__( 'Domain UUID', 'wp-phishing' ) . '<br><input type="text" name="domain_uuid" required></label></p>'
			. '<p><button type="submit" class="button">' . esc_html__( 'Disable', 'wp-phishing' ) . '</button></p></form>';

		echo '<h2>' . esc_html__( 'Cancel a campaign', 'wp-phishing' ) . '</h2>'
			. '<p>' . esc_html__( 'Unsent deliveries for this campaign become cancelled; already-delivered evidence remains (Section 72).', 'wp-phishing' ) . '</p>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="emergency_cancel_campaign">'
			. '<p><label>' . esc_html__( 'Organisation UUID', 'wp-phishing' ) . '<br><input type="text" name="organisation_uuid" required></label></p>'
			. '<p><label>' . esc_html__( 'Campaign UUID', 'wp-phishing' ) . '<br><input type="text" name="campaign_uuid" required></label></p>'
			. '<p><button type="submit" class="button">' . esc_html__( 'Cancel campaign', 'wp-phishing' ) . '</button></p></form>';

		echo '</div>';
	}

	public function render_queue(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Delivery Queue', 'wp-phishing' ) . '</h1>';
		echo '<table class="widefat"><thead><tr><th>' . esc_html__( 'Recipient', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Subject', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Provider', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Retries', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Last error', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Queued', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $this->deliveries->find_recent( 100 ) as $delivery ) {
			echo '<tr><td>' . esc_html( $delivery->recipient_email ) . '</td><td>' . esc_html( $delivery->rendered_subject ) . '</td><td>' . esc_html( $delivery->status->value ) . '</td><td>' . esc_html( $delivery->provider_id?->value ?? '' ) . '</td><td>' . (int) $delivery->retry_count . '</td><td>' . esc_html( (string) $delivery->last_error ) . '</td><td>' . esc_html( $delivery->queued_at?->format( 'Y-m-d H:i' ) ?? '' ) . '</td></tr>';
		}

		echo '</tbody></table></div>';
	}

	public function render_settings(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Settings', 'wp-phishing' ) . '</h1>';

		echo '<h2>' . esc_html__( 'Mail provider', 'wp-phishing' ) . '</h2>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML (a hidden nonce input, optionally a referer field); this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="wpp_admin_action" value="update_mail_provider">'
			. '<p><label>' . esc_html__( 'Site-wide default provider', 'wp-phishing' ) . '<br><select name="mail_provider"><option value="">' . esc_html__( '- none configured -', 'wp-phishing' ) . '</option>';

		foreach ( MailProviderId::cases() as $provider_id ) {
			echo '<option value="' . esc_attr( $provider_id->value ) . '"' . selected( $provider_id->value, (string) get_option( 'wpp_mail_provider', '' ), false ) . '>' . esc_html( $provider_id->value ) . '</option>';
		}

		echo '</select></label></p><p><button type="submit" class="button button-primary">' . esc_html__( 'Save', 'wp-phishing' ) . '</button></p></form>';

		echo '<h2>' . esc_html__( 'Risk weight sets', 'wp-phishing' ) . '</h2>'
			. '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Default', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Weights', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $this->risk_weight_sets->find_all() as $weight_set ) {
			$weights_summary = implode( ', ', array_map( static fn ( string $type, int $weight ): string => "{$type}={$weight}", array_keys( $weight_set->weights ), array_values( $weight_set->weights ) ) );

			echo '<tr><td>' . esc_html( $weight_set->name ) . '</td><td>' . ( $weight_set->is_default ? esc_html__( 'Yes', 'wp-phishing' ) : '' ) . '</td><td>' . esc_html( $weights_summary ) . '</td></tr>';
		}

		echo '</tbody></table>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="create_risk_weight_set">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>';

		foreach ( TrackingEventType::cases() as $type ) {
			echo '<p><label>' . esc_html( str_replace( '_', ' ', $type->value ) ) . '<br><input type="number" name="weight_' . esc_attr( $type->value ) . '" value="0"></label></p>';
		}

		echo '<p><label><input type="checkbox" name="is_default" value="1"> ' . esc_html__( 'Make this the default weight set for new reports', 'wp-phishing' ) . '</label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create weight set', 'wp-phishing' ) . '</button></p></form>';

		echo '<h2>' . esc_html__( 'Data retention', 'wp-phishing' ) . '</h2>'
			. '<p>' . esc_html__( 'A daily sweep permanently deletes data older than the configured number of days. Leave a field at 0 to keep that category forever - only these two of Section 54\'s eight retention categories are swept by this release; the rest are a documented fast-follow.', 'wp-phishing' ) . '</p>'
			. '<form method="post">' . wp_nonce_field( 'wpp_admin_action', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="wpp_admin_action" value="update_settings">'
			. '<p><label><input type="checkbox" name="remove_data_on_uninstall" value="1"' . checked( (bool) get_option( 'wpp_remove_data_on_uninstall', false ), true, false ) . '> '
			. esc_html__( 'Remove all plugin data when the plugin is deleted', 'wp-phishing' ) . '</label></p>'
			. '<p><label>' . esc_html__( 'Audit log retention (days, 0 = forever)', 'wp-phishing' ) . '<br><input type="number" min="0" name="retention_audit_log_days" value="' . esc_attr( (string) (int) get_option( 'wpp_retention_audit_log_days', 0 ) ) . '"></label></p>'
			. '<p><label>' . esc_html__( 'Cross-tool interaction history retention (days, 0 = forever)', 'wp-phishing' ) . '<br><input type="number" min="0" name="retention_interactions_days" value="' . esc_attr( (string) (int) get_option( 'wpp_retention_interactions_days', 0 ) ) . '"></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Save', 'wp-phishing' ) . '</button></p></form></div>';
	}

	// -----------------------------------------------------------------------------------
	// Shared helpers
	// -----------------------------------------------------------------------------------

	private function find_identity( SenderDomain $domain, string $identity_uuid ): ?SenderIdentity {
		foreach ( $this->sender_identities->list_for_domain( $domain ) as $identity ) {
			if ( $identity->identity_uuid === $identity_uuid ) {
				return $identity;
			}
		}

		return null;
	}

	private function selected_organisation(): ?\Alltime\CustomerPlatform\Organisation {
		$uuid = isset( $_GET['wpp_org'] ) ? sanitize_text_field( wp_unslash( $_GET['wpp_org'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only organisation-selector state.

		return '' !== $uuid ? $this->organisations->find_by_uuid( $uuid ) : null;
	}

	private function render_organisation_selector( string $screen_slug ): string {
		$organisations = $this->organisations->find_all( 200, 1 );
		$current       = isset( $_GET['wpp_org'] ) ? sanitize_text_field( wp_unslash( $_GET['wpp_org'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only.

		$html = '<form method="get"><input type="hidden" name="page" value="' . esc_attr( self::MENU_SLUG . '-' . $screen_slug ) . '">'
			. '<select name="wpp_org" onchange="this.form.submit()"><option value="">' . esc_html__( '- Select an organisation -', 'wp-phishing' ) . '</option>';

		foreach ( $organisations as $organisation ) {
			$html .= '<option value="' . esc_attr( $organisation->organisation_uuid ) . '"' . selected( $organisation->organisation_uuid, $current, false ) . '>' . esc_html( $organisation->name ) . '</option>';
		}

		return $html . '</select></form>';
	}
}
