<?php
/**
 * Table naming and dbDelta definitions for WP-Phishing's own (non-shared) tables.
 *
 * Deliberately separate from {@see \Alltime\CustomerPlatform\Schema}: tables here use the
 * `wpp_` prefix and belong to this plugin alone (Section 13's phishing-specific resources -
 * campaigns, recipients, deliveries, tracking, reports, and so on). Shared logical resources
 * (contacts, organisations) live in the Customer Platform's `atcp_` tables instead, per
 * Section 4 and Section 80.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Data;

final class Schema {

	/**
	 * @return array<string,string> Unprefixed table key => bare table name.
	 */
	public static function table_names(): array {
		return array(
			'audit_log'                      => 'wpp_audit_log',
			'recipients'                     => 'wpp_recipients',
			'recipient_groups'               => 'wpp_recipient_groups',
			'recipient_group_members'        => 'wpp_recipient_group_members',
			'recipient_imports'              => 'wpp_recipient_imports',
			'recipient_import_rows'          => 'wpp_recipient_import_rows',
			'suppressions'                   => 'wpp_suppressions',
			'auth_tokens'                    => 'wpp_auth_tokens',
			'sender_domains'                 => 'wpp_sender_domains',
			'sender_identities'              => 'wpp_sender_identities',
			'deliveries'                     => 'wpp_deliveries',
			'templates'                      => 'wpp_templates',
			'template_versions'              => 'wpp_template_versions',
			'landing_pages'                  => 'wpp_landing_pages',
			'landing_page_versions'          => 'wpp_landing_page_versions',
			'campaigns'                      => 'wpp_campaigns',
			'campaign_waves'                 => 'wpp_campaign_waves',
			'campaign_wave_recipients'       => 'wpp_campaign_wave_recipients',
			'campaign_approvals'             => 'wpp_campaign_approvals',
			'tracking_tokens'                => 'wpp_tracking_tokens',
			'tracking_events'                => 'wpp_tracking_events',
			'risk_weight_sets'               => 'wpp_risk_weight_sets',
			'reports'                        => 'wpp_reports',
			'download_tokens'                => 'wpp_download_tokens',
			'organisation_mail_integrations' => 'wpp_organisation_mail_integrations',
			'commercial_models'              => 'wpp_commercial_models',
			'organisation_commercial_models' => 'wpp_organisation_commercial_models',
			'rate_limits'                    => 'wpp_rate_limits',
		);
	}

	public static function table( string $key ): string {
		global $wpdb;

		$names = self::table_names();

		if ( ! isset( $names[ $key ] ) ) {
			throw new \InvalidArgumentException( esc_html( "Unknown WP-Phishing table key: {$key}" ) );
		}

		return $wpdb->prefix . $names[ $key ];
	}

	/**
	 * Schema version 1: the audit log (Section 61). Every later module's migration adds its own
	 * tables in a later version rather than reopening this one.
	 *
	 * @return string[]
	 */
	public static function version_1_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_audit_log (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				event_uuid VARCHAR(64) NOT NULL,
				actor_id BIGINT UNSIGNED NULL,
				organisation_uuid VARCHAR(64) NULL,
				action VARCHAR(128) NOT NULL,
				object_type VARCHAR(64) NOT NULL,
				object_uuid VARCHAR(64) NULL,
				outcome VARCHAR(16) NOT NULL DEFAULT 'success',
				summary TEXT NULL,
				source VARCHAR(32) NOT NULL DEFAULT 'admin',
				ip_address VARCHAR(45) NULL,
				metadata LONGTEXT NULL,
				occurred_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY event_uuid (event_uuid),
				KEY organisation_uuid (organisation_uuid),
				KEY actor_id (actor_id),
				KEY action (action),
				KEY object_type_uuid (object_type, object_uuid)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 2: the Recipients module (Section 13-17/55) - recipients, static groups,
	 * async import staging, and suppression. `organisation_uuid` is a plain VARCHAR column
	 * throughout, not a foreign key to the shared `atcp_organisations` table: these tables are
	 * physically owned by this plugin alone, and the organisation providing that UUID may be a
	 * different plugin entirely on a given install (Section 8/80) - every write validates the
	 * UUID through {@see \Alltime\CustomerPlatform\OrganisationPlatformDiscovery} first, never
	 * relying on a database-level constraint that could not span two plugins' tables anyway.
	 *
	 * @return string[]
	 */
	public static function version_2_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			// A phishing recipient is not automatically a canonical Alltime contact - contact_uuid
			// stays nullable (Section 14). email_hash is a SHA-256 of the normalised address, used
			// for the uniqueness constraint and for suppression lookups without a second join.
			"CREATE TABLE {$wpdb->prefix}wpp_recipients (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				recipient_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				contact_uuid VARCHAR(64) NULL,
				email VARCHAR(191) NOT NULL,
				email_hash VARCHAR(64) NOT NULL,
				given_name VARCHAR(191) NULL,
				family_name VARCHAR(191) NULL,
				job_title VARCHAR(191) NULL,
				department VARCHAR(191) NULL,
				team VARCHAR(191) NULL,
				location VARCHAR(191) NULL,
				manager_reference VARCHAR(191) NULL,
				employment_classification VARCHAR(64) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'active',
				source VARCHAR(32) NOT NULL,
				source_reference VARCHAR(191) NULL,
				metadata LONGTEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				deleted_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY recipient_uuid (recipient_uuid),
				UNIQUE KEY organisation_email (organisation_uuid, email_hash),
				KEY organisation_uuid (organisation_uuid),
				KEY contact_uuid (contact_uuid),
				KEY status (status)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpp_recipient_groups (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				group_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				name VARCHAR(191) NOT NULL,
				description TEXT NULL,
				type VARCHAR(16) NOT NULL DEFAULT 'static',
				rule_definition LONGTEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY group_uuid (group_uuid),
				UNIQUE KEY organisation_name (organisation_uuid, name),
				KEY organisation_uuid (organisation_uuid)
			) {$charset_collate};",
			// group_id/recipient_id are internal foreign keys - safe here because groups,
			// group_members and recipients all live in this same plugin's schema, unlike
			// organisation_uuid above.
			"CREATE TABLE {$wpdb->prefix}wpp_recipient_group_members (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				group_id BIGINT UNSIGNED NOT NULL,
				recipient_id BIGINT UNSIGNED NOT NULL,
				added_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY group_recipient (group_id, recipient_id),
				KEY recipient_id (recipient_id)
			) {$charset_collate};",
			// Section 15's async import pipeline: upload -> parse -> column mapping -> preview ->
			// validation -> duplicate/invalid/suppression detection -> confirmation -> commit.
			// target_group_uuid is optional - committed recipients are added to that group when set.
			"CREATE TABLE {$wpdb->prefix}wpp_recipient_imports (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				import_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'uploaded',
				source_format VARCHAR(16) NOT NULL,
				original_filename VARCHAR(191) NULL,
				target_group_uuid VARCHAR(64) NULL,
				column_mapping LONGTEXT NULL,
				total_rows INT UNSIGNED NOT NULL DEFAULT 0,
				valid_rows INT UNSIGNED NOT NULL DEFAULT 0,
				invalid_rows INT UNSIGNED NOT NULL DEFAULT 0,
				duplicate_rows INT UNSIGNED NOT NULL DEFAULT 0,
				suppressed_rows INT UNSIGNED NOT NULL DEFAULT 0,
				committed_rows INT UNSIGNED NOT NULL DEFAULT 0,
				next_unvalidated_row INT UNSIGNED NOT NULL DEFAULT 0,
				next_uncommitted_row INT UNSIGNED NOT NULL DEFAULT 0,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				committed_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY import_uuid (import_uuid),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status)
			) {$charset_collate};",
			// One row per staged import line, carrying it through validation and commit. import_id
			// is an internal foreign key (see group_members above).
			"CREATE TABLE {$wpdb->prefix}wpp_recipient_import_rows (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				import_id BIGINT UNSIGNED NOT NULL,
				row_number INT UNSIGNED NOT NULL,
				raw_data LONGTEXT NOT NULL,
				mapped_data LONGTEXT NULL,
				email_hash VARCHAR(64) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'pending',
				validation_errors LONGTEXT NULL,
				recipient_id BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY import_row (import_id, row_number),
				KEY status (status),
				KEY import_email (import_id, email_hash)
			) {$charset_collate};",
			// Section 55: suppression overrides campaign targeting and survives re-import. Multiple
			// rows per (organisation, email) are allowed deliberately - a hard bounce and a later
			// legal exclusion are independent facts, each with its own audit trail; "is this
			// address suppressed" is "does any non-expired row exist", not a single-row lookup.
			"CREATE TABLE {$wpdb->prefix}wpp_suppressions (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				suppression_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				email_hash VARCHAR(64) NOT NULL,
				reason VARCHAR(32) NOT NULL,
				source VARCHAR(32) NOT NULL,
				note TEXT NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				expires_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY suppression_uuid (suppression_uuid),
				KEY organisation_email (organisation_uuid, email_hash),
				KEY expires_at (expires_at)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 3: short-lived, single-use, hashed tokens for the customer portal's email
	 * verification and password reset (Section 12) - only the SHA-256 hash is ever persisted, the
	 * raw value exists only long enough to be embedded in the emailed link.
	 *
	 * @return string[]
	 */
	public static function version_3_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_auth_tokens (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				token_hash VARCHAR(64) NOT NULL,
				type VARCHAR(32) NOT NULL,
				expires_at DATETIME NOT NULL,
				used_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY user_id_type (user_id, type)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 4: the sending infrastructure (Section 22-26) - controlled sender domains
	 * and identities, and a campaign-agnostic delivery queue.
	 *
	 * `wpp_deliveries` deliberately carries no campaign/wave foreign key yet - Phase 4's Campaign
	 * engine does not exist. `source_object_type`/`source_object_uuid` are a polymorphic
	 * reference (the same pattern the Customer Platform's `atcp_interactions` table already
	 * uses) that a later module populates without this one needing to know what a campaign is;
	 * a delivery is otherwise a complete, self-contained unit of already-rendered content to send.
	 *
	 * `organisation_uuid` on `wpp_sender_domains` is nullable: null means a shared, Alltime-
	 * operated pool domain (the default); set means a domain dedicated to one customer "where
	 * explicitly authorised" (Section 22).
	 *
	 * @return string[]
	 */
	public static function version_4_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_sender_domains (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				domain_uuid VARCHAR(64) NOT NULL,
				domain VARCHAR(191) NOT NULL,
				organisation_uuid VARCHAR(64) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'active',
				mail_provider VARCHAR(32) NULL,
				tracking_domain VARCHAR(191) NULL,
				landing_domain VARCHAR(191) NULL,
				spf_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				dkim_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				dmarc_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				tls_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				health_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				last_health_check_at DATETIME NULL,
				reputation_notes TEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				retired_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY domain_uuid (domain_uuid),
				UNIQUE KEY domain (domain),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status)
			) {$charset_collate};",
			// sender_domain_id is an internal foreign key - safe here because domains and
			// identities live in this same plugin's schema.
			"CREATE TABLE {$wpdb->prefix}wpp_sender_identities (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				identity_uuid VARCHAR(64) NOT NULL,
				sender_domain_id BIGINT UNSIGNED NOT NULL,
				display_name VARCHAR(191) NOT NULL,
				local_part VARCHAR(191) NOT NULL,
				reply_to VARCHAR(191) NULL,
				scenario_classification VARCHAR(32) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'active',
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY identity_uuid (identity_uuid),
				UNIQUE KEY domain_local_part (sender_domain_id, local_part),
				KEY sender_domain_id (sender_domain_id)
			) {$charset_collate};",
			// sender_identity_id is an internal foreign key (see above). provider_id/
			// provider_message_id stay NULL until a send is actually attempted/accepted.
			"CREATE TABLE {$wpdb->prefix}wpp_deliveries (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				delivery_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				sender_identity_id BIGINT UNSIGNED NOT NULL,
				recipient_email VARCHAR(191) NOT NULL,
				recipient_email_hash VARCHAR(64) NOT NULL,
				rendered_subject VARCHAR(998) NOT NULL,
				rendered_html_body LONGTEXT NULL,
				rendered_text_body LONGTEXT NULL,
				source_object_type VARCHAR(64) NULL,
				source_object_uuid VARCHAR(64) NULL,
				idempotency_key VARCHAR(64) NOT NULL,
				provider_id VARCHAR(32) NULL,
				provider_message_id VARCHAR(191) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'planned',
				retry_count INT UNSIGNED NOT NULL DEFAULT 0,
				next_attempt_at DATETIME NULL,
				last_error VARCHAR(191) NULL,
				claim_token VARCHAR(64) NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				queued_at DATETIME NULL,
				sent_at DATETIME NULL,
				delivered_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY delivery_uuid (delivery_uuid),
				UNIQUE KEY idempotency_key (idempotency_key),
				KEY organisation_uuid (organisation_uuid),
				KEY sender_identity_id (sender_identity_id),
				KEY status (status),
				KEY source_object (source_object_type, source_object_uuid),
				KEY claim_token (claim_token)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 5: campaigns and delivery (Section 18-21/28-36) - single-wave MVP scope.
	 *
	 * Templates and landing pages are versioned (Section 28/31): `wpp_templates`/
	 * `wpp_landing_pages` hold identity and a `current_version_id` pointer; edits create a new
	 * immutable `_versions` row rather than mutating one in place, so a wave that locked in a
	 * specific `template_version_id`/`landing_page_version_id` keeps exactly what was sent even
	 * after the "current" version is later edited. `organisation_uuid` is nullable on both,
	 * matching `wpp_sender_domains`' shared-pool convention: null is a shared library
	 * item available to every organisation, set is organisation-authored content.
	 *
	 * MVP is single-wave only (spec Section 76 #11); `wpp_campaigns` therefore carries no
	 * `template_set_id`/`landing_template_id`/`sender_policy_id` of its own even though Section
	 * 18 lists them - Section 19 assigns template/sender identity/landing page/cohort/window at
	 * the *wave* level, which is where `wpp_campaign_waves` puts them. `commercial_model_id`
	 * (Section 18) is omitted entirely: commercial models are Phase 6 (Section 46) and do not
	 * exist yet. `campaign_type` (Section 18) has no defined vocabulary anywhere else in the
	 * spec, so it is kept as free-text metadata rather than an invented enum.
	 *
	 * `wpp_campaign_wave_recipients` is the frozen cohort + metadata snapshot Section 16/20
	 * requires ("dynamic selection rules shall be persisted when activated" /
	 * "historical campaign data shall retain metadata snapshots") - recipient fields are copied
	 * at wave-activation time, so a later recipient/org change never rewrites a historical
	 * report. `delivery_id` is filled in once the corresponding `wpp_deliveries` row exists
	 * (Section 26, added in schema version 4); the two tables are linked this way rather than the
	 * other way around because a delivery must already exist as a complete, self-contained unit
	 * before enqueueing per Phase 3's design.
	 *
	 * `wpp_tracking_tokens` follows the same "hash only" convention as `wpp_auth_tokens` (schema
	 * version 3): the raw, opaque, unguessable token (Section 32) is embedded directly into
	 * rendered delivery content and never itself persisted, only its SHA-256 hash. One token per
	 * delivery. `wpp_tracking_events` (Section 33) references `delivery_uuid` directly (not the
	 * token) because most events - `message_accepted` chief among them - are recorded internally
	 * by the queue, never via an incoming tracking-token request at all.
	 *
	 * @return string[]
	 */
	public static function version_5_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_templates (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				template_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NULL,
				name VARCHAR(191) NOT NULL,
				scenario VARCHAR(48) NOT NULL,
				difficulty VARCHAR(16) NOT NULL DEFAULT 'moderate',
				risk_tags LONGTEXT NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'draft',
				current_version_id BIGINT UNSIGNED NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY template_uuid (template_uuid),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status)
			) {$charset_collate};",
			// template_id is an internal foreign key - safe here because templates and their
			// versions live in this same plugin's schema.
			"CREATE TABLE {$wpdb->prefix}wpp_template_versions (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				template_id BIGINT UNSIGNED NOT NULL,
				version_number INT UNSIGNED NOT NULL,
				subject VARCHAR(998) NOT NULL,
				from_display_name VARCHAR(191) NOT NULL,
				html_body LONGTEXT NULL,
				text_body LONGTEXT NULL,
				learning_objective TEXT NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY template_version (template_id, version_number)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpp_landing_pages (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				landing_page_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NULL,
				name VARCHAR(191) NOT NULL,
				mode VARCHAR(32) NOT NULL DEFAULT 'click_only',
				status VARCHAR(16) NOT NULL DEFAULT 'draft',
				current_version_id BIGINT UNSIGNED NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY landing_page_uuid (landing_page_uuid),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status)
			) {$charset_collate};",
			// landing_page_id is an internal foreign key (see template_versions above).
			"CREATE TABLE {$wpdb->prefix}wpp_landing_page_versions (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				landing_page_id BIGINT UNSIGNED NOT NULL,
				version_number INT UNSIGNED NOT NULL,
				html_body LONGTEXT NOT NULL,
				educational_html LONGTEXT NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY landing_page_version (landing_page_id, version_number)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpp_campaigns (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				campaign_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				name VARCHAR(191) NOT NULL,
				description TEXT NULL,
				campaign_type VARCHAR(64) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'draft',
				objective TEXT NULL,
				approval_model VARCHAR(32) NOT NULL DEFAULT 'customer_self_approval',
				schedule_mode VARCHAR(16) NOT NULL DEFAULT 'immediate',
				timezone VARCHAR(64) NULL,
				starts_at DATETIME NULL,
				ends_at DATETIME NULL,
				expected_recipient_count INT UNSIGNED NOT NULL DEFAULT 0,
				expected_message_count INT UNSIGNED NOT NULL DEFAULT 0,
				created_by BIGINT UNSIGNED NULL,
				approved_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				approved_at DATETIME NULL,
				closed_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY campaign_uuid (campaign_uuid),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status)
			) {$charset_collate};",
			// campaign_id/sender_identity_id/recipient_group_id/template_version_id/
			// landing_page_version_id are internal foreign keys - all live in this same plugin's
			// schema (sender_identity_id and recipient_group_id were introduced in earlier schema
			// versions, this table only adds the reference).
			"CREATE TABLE {$wpdb->prefix}wpp_campaign_waves (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				wave_uuid VARCHAR(64) NOT NULL,
				campaign_id BIGINT UNSIGNED NOT NULL,
				name VARCHAR(191) NOT NULL,
				template_version_id BIGINT UNSIGNED NOT NULL,
				sender_identity_id BIGINT UNSIGNED NOT NULL,
				landing_page_version_id BIGINT UNSIGNED NULL,
				recipient_group_id BIGINT UNSIGNED NOT NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'draft',
				randomisation_policy VARCHAR(32) NOT NULL DEFAULT 'none',
				delivery_window_starts_at DATETIME NULL,
				delivery_window_ends_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				activated_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY wave_uuid (wave_uuid),
				KEY campaign_id (campaign_id),
				KEY status (status)
			) {$charset_collate};",
			// wave_id/recipient_id/delivery_id are internal foreign keys (see waves above).
			"CREATE TABLE {$wpdb->prefix}wpp_campaign_wave_recipients (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				wave_id BIGINT UNSIGNED NOT NULL,
				recipient_id BIGINT UNSIGNED NOT NULL,
				email VARCHAR(191) NOT NULL,
				email_hash VARCHAR(64) NOT NULL,
				given_name VARCHAR(191) NULL,
				family_name VARCHAR(191) NULL,
				department VARCHAR(191) NULL,
				team VARCHAR(191) NULL,
				location VARCHAR(191) NULL,
				job_title VARCHAR(191) NULL,
				metadata LONGTEXT NULL,
				delivery_id BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY wave_recipient (wave_id, recipient_id),
				KEY wave_id (wave_id),
				KEY delivery_id (delivery_id)
			) {$charset_collate};",
			// campaign_id is an internal foreign key (see waves above).
			"CREATE TABLE {$wpdb->prefix}wpp_campaign_approvals (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				approval_uuid VARCHAR(64) NOT NULL,
				campaign_id BIGINT UNSIGNED NOT NULL,
				approver_id BIGINT UNSIGNED NOT NULL,
				approver_role VARCHAR(16) NOT NULL,
				decision VARCHAR(16) NOT NULL,
				notes TEXT NULL,
				decided_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY approval_uuid (approval_uuid),
				KEY campaign_id (campaign_id)
			) {$charset_collate};",
			// delivery_id is an internal foreign key (Section 26, schema version 4). Only the
			// hash is stored (Section 32) - see the docblock above.
			"CREATE TABLE {$wpdb->prefix}wpp_tracking_tokens (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				token_hash VARCHAR(64) NOT NULL,
				delivery_id BIGINT UNSIGNED NOT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				UNIQUE KEY delivery_id (delivery_id)
			) {$charset_collate};",
			// delivery_uuid is deliberately not a foreign key to wpp_deliveries.id - see the
			// docblock above (most events reference the delivery by its public UUID, not the
			// internal id, and are recorded without ever looking the delivery row up first).
			"CREATE TABLE {$wpdb->prefix}wpp_tracking_events (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				event_uuid VARCHAR(64) NOT NULL,
				delivery_uuid VARCHAR(64) NOT NULL,
				event_type VARCHAR(48) NOT NULL,
				observed_at DATETIME NOT NULL,
				source VARCHAR(32) NOT NULL,
				confidence VARCHAR(16) NOT NULL DEFAULT 'unknown',
				metadata LONGTEXT NULL,
				deduplication_key VARCHAR(191) NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY event_uuid (event_uuid),
				UNIQUE KEY deduplication_key (deduplication_key),
				KEY delivery_uuid (delivery_uuid),
				KEY event_type (event_type)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 6: results, risk scoring and reporting (Section 37-45/59/62-63).
	 *
	 * Deliberately no `wpp_campaign_results` per-delivery table: Section 37's "do not reduce all
	 * results to a single pass/fail field" is satisfied by computing a recipient's result
	 * on-demand from `wpp_campaign_wave_recipients` + `wpp_deliveries` + `wpp_tracking_events`
	 * (already-immutable append-only sources) rather than maintaining a denormalised copy that
	 * could drift from them. A generated report, by contrast, genuinely must be a frozen artefact
	 * (Section 38: "weights shall be... retained with each report") - that immutability lives in
	 * `wpp_reports.content_json` instead.
	 *
	 * Risk weight sets (`wpp_risk_weight_sets`) are immutable once created - there is no "edit",
	 * only creating a new named set and optionally marking it the default - so a report's
	 * `risk_weight_set_id` reference is permanently meaningful.
	 *
	 * @return string[]
	 */
	public static function version_6_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_risk_weight_sets (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				weight_set_uuid VARCHAR(64) NOT NULL,
				name VARCHAR(191) NOT NULL,
				weights LONGTEXT NOT NULL,
				is_default TINYINT(1) NOT NULL DEFAULT 0,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY weight_set_uuid (weight_set_uuid)
			) {$charset_collate};",
			// campaign_id/risk_weight_set_id are internal foreign keys - both live in this same
			// plugin's schema.
			"CREATE TABLE {$wpdb->prefix}wpp_reports (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				report_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				campaign_id BIGINT UNSIGNED NOT NULL,
				risk_weight_set_id BIGINT UNSIGNED NOT NULL,
				visibility VARCHAR(32) NOT NULL DEFAULT 'aggregate_only',
				content_json LONGTEXT NOT NULL,
				pdf_relative_path VARCHAR(255) NULL,
				generated_by BIGINT UNSIGNED NULL,
				generated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY report_uuid (report_uuid),
				KEY organisation_uuid (organisation_uuid),
				KEY campaign_id (campaign_id)
			) {$charset_collate};",
			// report_id is an internal foreign key (see above). Only the hash is stored (Section
			// 59), matching wpp_tracking_tokens/wpp_auth_tokens' convention.
			"CREATE TABLE {$wpdb->prefix}wpp_download_tokens (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				token_hash VARCHAR(64) NOT NULL,
				report_id BIGINT UNSIGNED NOT NULL,
				purpose VARCHAR(32) NOT NULL DEFAULT 'report_pdf',
				max_uses INT UNSIGNED NULL,
				use_count INT UNSIGNED NOT NULL DEFAULT 0,
				expires_at DATETIME NOT NULL,
				revoked_at DATETIME NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY report_id (report_id)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 7: mailbox-injection delivery mode alongside API-send, per the "Multi-
	 * provider delivery modes" plan addition. Two changes:
	 *
	 * - `wpp_sender_domains` gains `delivery_mode` - the *full* desired table definition is
	 *   re-declared (not an ALTER TABLE), which is how dbDelta is meant to be driven: given a
	 *   complete CREATE TABLE for a table that already exists, it diffs column-by-column and adds
	 *   only what's missing, leaving existing data and columns untouched.
	 * - `wpp_organisation_mail_integrations` records per-organisation consent for the two
	 *   independently-grantable capabilities (mailbox injection, directory sync) against the two
	 *   providers (Microsoft 365, Google Workspace) - see PLAN.md's "Multi-provider delivery
	 *   modes" section for why these are modelled as independent (organisation_uuid, provider,
	 *   capability) grants rather than one row per organisation.
	 *
	 * @return string[]
	 */
	public static function version_7_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			// Re-declaration of the version-4 wpp_sender_domains table plus the new
			// delivery_mode column - see the docblock above for why this is a full re-declare,
			// not an ALTER TABLE.
			"CREATE TABLE {$wpdb->prefix}wpp_sender_domains (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				domain_uuid VARCHAR(64) NOT NULL,
				domain VARCHAR(191) NOT NULL,
				organisation_uuid VARCHAR(64) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'active',
				delivery_mode VARCHAR(32) NOT NULL DEFAULT 'api_send',
				mail_provider VARCHAR(32) NULL,
				tracking_domain VARCHAR(191) NULL,
				landing_domain VARCHAR(191) NULL,
				spf_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				dkim_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				dmarc_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				tls_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				health_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
				last_health_check_at DATETIME NULL,
				reputation_notes TEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				retired_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY domain_uuid (domain_uuid),
				UNIQUE KEY domain (domain),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status)
			) {$charset_collate};",
			// organisation_uuid is a plain VARCHAR, not a foreign key - same rationale as every
			// other wpp_* table referencing an organisation (Data\Schema's version 2 docblock):
			// physically owned by this plugin alone, validated through
			// OrganisationPlatformDiscovery on write, never a cross-plugin DB constraint.
			"CREATE TABLE {$wpdb->prefix}wpp_organisation_mail_integrations (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				integration_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				provider VARCHAR(32) NOT NULL,
				capability VARCHAR(32) NOT NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'pending',
				tenant_identifier VARCHAR(191) NULL,
				verified_at DATETIME NULL,
				revoked_at DATETIME NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY integration_uuid (integration_uuid),
				UNIQUE KEY organisation_provider_capability (organisation_uuid, provider, capability),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 8: commercial models (Section 46-48) - plugin-local, unlike Usage/
	 * Entitlements (Alltime\CustomerPlatform schema version 4), since a charging basis is a
	 * wp-phishing-specific concept the spec never declares a shared logical resource.
	 * `wpp_organisation_commercial_models` is a small mapping table rather than a column on the
	 * shared `atcp_organisations`, keeping that contract free of phishing-specific billing fields.
	 *
	 * @return string[]
	 */
	public static function version_8_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_commercial_models (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				commercial_model_uuid VARCHAR(64) NOT NULL,
				name VARCHAR(191) NOT NULL,
				charging_basis VARCHAR(32) NOT NULL,
				currency VARCHAR(8) NOT NULL DEFAULT 'GBP',
				base_charge DECIMAL(12,2) NULL,
				recipient_rate DECIMAL(12,4) NULL,
				message_rate DECIMAL(12,4) NULL,
				campaign_rate DECIMAL(12,2) NULL,
				included_recipients BIGINT UNSIGNED NULL,
				included_messages BIGINT UNSIGNED NULL,
				included_campaigns BIGINT UNSIGNED NULL,
				minimum_charge DECIMAL(12,2) NULL,
				maximum_charge DECIMAL(12,2) NULL,
				billing_period VARCHAR(32) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'active',
				configuration_json LONGTEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY commercial_model_uuid (commercial_model_uuid),
				KEY status (status)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpp_organisation_commercial_models (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				organisation_uuid VARCHAR(64) NOT NULL,
				commercial_model_id BIGINT UNSIGNED NOT NULL,
				assigned_by BIGINT UNSIGNED NULL,
				assigned_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY organisation_uuid (organisation_uuid),
				KEY commercial_model_id (commercial_model_id)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 9: HaloPSA pull/ack sync state (Section 51), bolted onto the existing
	 * wpp_campaigns table (WP-Questionnaires' own convention - columns on the primary resource,
	 * not a separate queue table) rather than an ALTER TABLE - full re-declaration, per this
	 * file's own established convention for adding a column to an existing table.
	 *
	 * @return string[]
	 */
	public static function version_9_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_campaigns (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				campaign_uuid VARCHAR(64) NOT NULL,
				organisation_uuid VARCHAR(64) NOT NULL,
				name VARCHAR(191) NOT NULL,
				description TEXT NULL,
				campaign_type VARCHAR(64) NULL,
				status VARCHAR(16) NOT NULL DEFAULT 'draft',
				objective TEXT NULL,
				approval_model VARCHAR(32) NOT NULL DEFAULT 'customer_self_approval',
				schedule_mode VARCHAR(16) NOT NULL DEFAULT 'immediate',
				timezone VARCHAR(64) NULL,
				starts_at DATETIME NULL,
				ends_at DATETIME NULL,
				expected_recipient_count INT UNSIGNED NOT NULL DEFAULT 0,
				expected_message_count INT UNSIGNED NOT NULL DEFAULT 0,
				created_by BIGINT UNSIGNED NULL,
				approved_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				approved_at DATETIME NULL,
				closed_at DATETIME NULL,
				halo_sync_status VARCHAR(16) NOT NULL DEFAULT 'pending',
				halo_synced_at DATETIME NULL,
				halo_last_attempted_at DATETIME NULL,
				halo_retry_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
				halo_sync_error TEXT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY campaign_uuid (campaign_uuid),
				KEY organisation_uuid (organisation_uuid),
				KEY status (status),
				KEY halo_sync_status (halo_sync_status)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 10: rate limiting (Section 57), ported from WP-Questionnaires'
	 * `wpq_rate_limits` shape. `bucket_key` is a SHA-256 hex digest over the endpoint plus one or
	 * two HMAC-hashed dimension values (see `AntiAbuse\RateLimiter`) - collapsing every dimension
	 * combination into one UNIQUE key is what makes a single atomic
	 * `INSERT ... ON DUPLICATE KEY UPDATE` per check possible. `client_hash`/`secondary_hash` are
	 * kept as their own columns (rather than only living inside `bucket_key`) purely for
	 * operator-facing inspection/debugging - they are never used to look a row up.
	 *
	 * @return string[]
	 */
	public static function version_10_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpp_rate_limits (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				bucket_key VARCHAR(64) NOT NULL,
				endpoint VARCHAR(64) NOT NULL,
				client_hash VARCHAR(64) NOT NULL,
				secondary_hash VARCHAR(64) NULL,
				window_start DATETIME NOT NULL,
				request_count INT UNSIGNED NOT NULL DEFAULT 0,
				expires_at DATETIME NOT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY bucket_key (bucket_key),
				KEY expires_at (expires_at)
			) {$charset_collate};",
		);
	}
}
