<?php
/**
 * A safe, coarse classification of a failed migration statement, derived from $wpdb->last_error's
 * text but never persisting or exposing that raw text itself - which could contain table/column
 * names, connection details, or other information not appropriate for an admin notice, Site
 * Health entry, or audit-log summary.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Data\Enums;

enum MigrationFailureClassification: string {
	case PermissionDenied          = 'permission_denied';
	case DuplicateOrConflict       = 'duplicate_or_conflict';
	case SyntaxOrDefinitionError   = 'syntax_or_definition_error';
	case ResourceOrConnectionLimit = 'resource_or_connection_limit';
	case Unknown                   = 'unknown';

	public static function classify_from_error( string $raw_error ): self {
		$error = strtolower( $raw_error );

		return match ( true ) {
			str_contains( $error, 'denied' ) || str_contains( $error, 'not allowed' ) || str_contains( $error, 'permission' ) => self::PermissionDenied,
			str_contains( $error, 'duplicate' ) || str_contains( $error, 'already exists' ) => self::DuplicateOrConflict,
			str_contains( $error, 'syntax' ) || str_contains( $error, "doesn't exist" ) || str_contains( $error, 'unknown column' ) => self::SyntaxOrDefinitionError,
			str_contains( $error, 'lock wait timeout' ) || str_contains( $error, 'too many connections' ) || str_contains( $error, 'max_user_connections' ) || str_contains( $error, 'disk full' ) || str_contains( $error, 'out of memory' ) => self::ResourceOrConnectionLimit,
			default => self::Unknown,
		};
	}
}
