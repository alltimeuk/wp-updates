<?php
/**
 * Schedules the recurring DNS domain-verification sweep, per Section 11.
 *
 * A dedicated bootstrap owning its own cron interval and hook, rather than folding into a
 * general maintenance sweep - matches the precedent set by WP-Reconnaissance's own
 * VerificationBootstrap.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Verification;

final class VerificationBootstrap {

	public const RUN_SWEEP_HOOK = 'wpp_run_domain_verification_sweep';

	private const INTERVAL_SLUG = 'wpp_thirty_minutes';

	public function boot(): void {
		add_filter( 'cron_schedules', array( $this, 'register_thirty_minute_interval' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 30 minutes is intentional, matching WP-Reconnaissance's own domain-verification sweep interval.
		add_action( self::RUN_SWEEP_HOOK, array( $this, 'run_sweep' ) );
		add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
	}

	/**
	 * @param array<string,array{interval:int,display:string}> $schedules
	 *
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function register_thirty_minute_interval( array $schedules ): array {
		$schedules[ self::INTERVAL_SLUG ] = array(
			'interval' => 30 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 30 minutes (WP-Phishing domain verification)', 'wp-phishing' ),
		);

		return $schedules;
	}

	/**
	 * Schedules the recurring sweep on first boot after activation. Idempotent: wp_next_scheduled()
	 * prevents piling up duplicate recurring schedules on every request.
	 */
	public function ensure_sweep_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_SWEEP_HOOK ) ) {
			wp_schedule_event( time(), self::INTERVAL_SLUG, self::RUN_SWEEP_HOOK );
		}
	}

	public function run_sweep(): void {
		( new DomainVerificationService() )->run_sweep();
	}
}
