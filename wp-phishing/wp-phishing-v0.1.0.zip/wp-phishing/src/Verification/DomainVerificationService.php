<?php
/**
 * DNS TXT domain-ownership verification, per Section 11.
 *
 * A customer or administrator generates a random per-challenge secret, publishes its SHA-256
 * hash as a `v=wpphishing h={hash} t={date}` TXT record on the domain itself, and this service
 * checks whether that record now resolves. A match marks the organisation domain Verified
 * through {@see \Alltime\CustomerPlatform\OrganisationServiceInterface::record_domain_verification()}
 * - the same shared contract every other consumer of organisation domains uses, so this stays a
 * verifiable *way to trigger* that write, not a parallel one.
 *
 * Administrative override is also supported for customers where Alltime already has documented
 * authority (Section 11): every override is audited, same as every DNS-verified transition.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Verification;

use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;
use Alltime\CustomerPlatform\OrganisationDomain;
use Alltime\CustomerPlatform\OrganisationPlatformDiscovery;
use Alltime\CustomerPlatform\OrganisationServiceInterface;
use Alltime\CustomerPlatform\Repositories\OrganisationDomainRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class DomainVerificationService {

	/**
	 * Fired by {@see check()} immediately after a domain is newly verified via DNS TXT, with the
	 * domain UUID as the sole argument. Mirrors the plugin's `wpp_*` action-hook surface so other
	 * modules (e.g. a future customer notification) can listen without this service knowing
	 * anything about what should happen downstream.
	 */
	public const VERIFIED_HOOK = 'wpp_organisation_domain_verified';

	/**
	 * The Customer Platform schema version that introduced the Organisation domain-verification
	 * columns this service depends on (Section 8/9/10, `atcp_organisation_domains`).
	 */
	private const REQUIRED_SCHEMA_VERSION = 3;

	/**
	 * How long a customer has to publish a matching DNS TXT record before their challenge is no
	 * longer worth a background sweep check - see {@see run_sweep()} and
	 * {@see is_verification_window_expired()}.
	 */
	private const VERIFICATION_WINDOW_HOURS = 24;

	/**
	 * @param callable(string,int):array<int,array<string,mixed>> $dns_query Defaults to
	 *        {@see Dns::query()}; overridable so tests can assert against deterministic TXT
	 *        responses instead of depending on public DNS.
	 */
	public function __construct(
		private readonly OrganisationDomainRepository $domains = new OrganisationDomainRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private $dns_query = array( Dns::class, 'query' )
	) {}

	/**
	 * Starts (or restarts) a DNS verification challenge for a domain. The returned hash is the
	 * value to publish - it is derived from a random secret discarded immediately after hashing;
	 * there is no raw secret to protect, since the hash itself is meant to be made public.
	 */
	public function generate_challenge( string $domain_uuid, int $requested_by, string $source ): string {
		self::assert_schema_ready();

		$domain = $this->domains->find_by_uuid( $domain_uuid );

		if ( null === $domain ) {
			throw new \InvalidArgumentException( esc_html( "Unknown organisation domain UUID: {$domain_uuid}" ) );
		}

		$hash = hash( 'sha256', bin2hex( random_bytes( 32 ) ) );

		$this->organisation_service()->record_domain_verification( $domain_uuid, DomainVerificationStatus::Pending, $hash, $requested_by );

		$this->audit_logger->log(
			'domain.verification_started',
			'organisation_domain',
			$domain_uuid,
			$requested_by,
			source: $source,
			organisation_uuid: $domain->organisation_uuid
		);

		return $hash;
	}

	/**
	 * The exact TXT record value to publish on the domain itself (never a subdomain).
	 */
	public function txt_record_value( string $hash, ?\DateTimeImmutable $requested_at = null ): string {
		return sprintf(
			'v=wpphishing h=%s t=%s',
			$hash,
			gmdate( 'Y-m-d', $requested_at?->getTimestamp() ?? time() )
		);
	}

	/**
	 * Runs one DNS TXT lookup against the domain and compares any `v=wpphishing h=...` record
	 * found to the domain's outstanding challenge hash. On a match, marks the domain Verified. On
	 * no match, the domain is left `pending` for a later check - not logged, since a recurring
	 * sweep re-checking every outstanding challenge would otherwise fill the audit log with
	 * non-events.
	 *
	 * @throws SchemaNotReadyException See {@see assert_schema_ready()}.
	 */
	public function check( OrganisationDomain $domain, string $source ): bool {
		self::assert_schema_ready();

		if ( DomainVerificationStatus::Pending !== $domain->verification_status || null === $domain->verification_reference ) {
			return false;
		}

		if ( ! $this->has_matching_txt_record( $domain->domain_ascii, $domain->verification_reference ) ) {
			return false;
		}

		$this->organisation_service()->record_domain_verification( $domain->domain_uuid, DomainVerificationStatus::Verified, $domain->verification_reference );

		$this->audit_logger->log(
			'domain.verified',
			'organisation_domain',
			$domain->domain_uuid,
			null,
			summary: 'DNS TXT verification',
			source: $source,
			organisation_uuid: $domain->organisation_uuid
		);

		do_action( self::VERIFIED_HOOK, $domain->domain_uuid ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- self::VERIFIED_HOOK is the literal, properly-prefixed 'wpp_organisation_domain_verified' constant declared above; the sniff can't see through the constant reference.

		return true;
	}

	/**
	 * Administrative override, per Section 11: "Administrative override shall also be supported
	 * for customers where Alltime already has documented authority. All override actions shall be
	 * audited." Unlike {@see check()}, this never touches DNS - $reason is the documented
	 * authority being relied on, and is always recorded.
	 */
	public function administrator_override( string $domain_uuid, int $admin_user_id, string $reason ): void {
		self::assert_schema_ready();

		$domain = $this->domains->find_by_uuid( $domain_uuid );

		if ( null === $domain ) {
			throw new \InvalidArgumentException( esc_html( "Unknown organisation domain UUID: {$domain_uuid}" ) );
		}

		$this->organisation_service()->record_domain_verification( $domain_uuid, DomainVerificationStatus::Verified, $domain->verification_reference, $admin_user_id );

		$this->audit_logger->log(
			'domain.verification_overridden',
			'organisation_domain',
			$domain_uuid,
			$admin_user_id,
			summary: $reason,
			source: 'admin',
			organisation_uuid: $domain->organisation_uuid
		);

		do_action( self::VERIFIED_HOOK, $domain_uuid ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- see check(), same literal constant.
	}

	/**
	 * The recurring sweep entry point: checks every domain with an outstanding challenge, capped
	 * per run so a large backlog can't turn one sweep into an unbounded batch of DNS lookups. A
	 * challenge older than {@see VERIFICATION_WINDOW_HOURS} is skipped - not treated as a
	 * permanent failure, just no longer worth a background DNS lookup for a likely-abandoned
	 * request. The customer can always restart it (a fresh "Generate verification code" resets the
	 * request timestamp) or trigger an immediate manual "Check now" past the window.
	 */
	public function run_sweep(): void {
		$max = (int) get_option( 'wpp_max_domain_verifications_per_sweep', 50 );

		foreach ( $this->domains->find_pending_verification( $max ) as $domain ) {
			if ( $this->is_verification_window_expired( $domain ) ) {
				continue;
			}

			try {
				$this->check( $domain, 'cron' );
			} catch ( \Throwable $e ) {
				$this->audit_logger->log(
					'domain.verification_check_failed',
					'organisation_domain',
					$domain->domain_uuid,
					null,
					outcome: 'failure',
					summary: $e->getMessage(),
					source: 'cron',
					organisation_uuid: $domain->organisation_uuid
				);
			}
		}
	}

	/**
	 * Whether a domain's outstanding DNS TXT challenge is older than the verification window -
	 * the customer/admin-facing "verification window expired, please regenerate" signal.
	 * Deliberately not a persisted status: it's a pure function of
	 * `verification_requested_at`'s age, computed at render/sweep time, so restarting the
	 * challenge (which resets that timestamp) immediately un-expires it with no separate status
	 * to reconcile.
	 */
	public function is_verification_window_expired( OrganisationDomain $domain ): bool {
		if ( DomainVerificationStatus::Pending !== $domain->verification_status || null === $domain->verification_requested_at ) {
			return false;
		}

		return $domain->verification_requested_at < ( new \DateTimeImmutable() )->modify( '-' . self::VERIFICATION_WINDOW_HOURS . ' hours' );
	}

	private function has_matching_txt_record( string $domain, string $expected_hash ): bool {
		foreach ( ( $this->dns_query )( $domain, DNS_TXT ) as $record ) {
			// A record that isn't itself an array is not a shape this format recognises - real
			// dns_get_record() never produces one, but $dns_query is an injectable callable, and
			// reconstruct_txt_value()'s `array $record` parameter would otherwise throw an
			// uncaught TypeError here instead of just not matching.
			if ( ! is_array( $record ) ) {
				continue;
			}

			$hash = $this->extract_hash( $this->reconstruct_txt_value( $record ) );

			if ( null !== $hash && hash_equals( $expected_hash, $hash ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * A single DNS TXT resource record can carry its value split across multiple <255-byte
	 * character-string fragments, joined back into one record on the wire - never across separate
	 * records, which {@see has_matching_txt_record()}'s per-record loop already keeps distinct.
	 * PHP's `dns_get_record()` already concatenates these into `txt` with no separator; `entries`
	 * is a defensive fallback if `txt` is ever absent while fragments are still present.
	 *
	 * @param array<string,mixed> $record
	 */
	private function reconstruct_txt_value( array $record ): string {
		$txt = $record['txt'] ?? '';

		if ( is_string( $txt ) && '' !== $txt ) {
			return $txt;
		}

		if ( isset( $record['entries'] ) && is_array( $record['entries'] ) ) {
			foreach ( $record['entries'] as $entry ) {
				if ( ! is_string( $entry ) ) {
					return '';
				}
			}

			return implode( '', $record['entries'] );
		}

		return '';
	}

	private function extract_hash( string $txt_value ): ?string {
		if ( 1 === preg_match( '/^v=wpphishing\s+h=([0-9a-f]{64})(?:\s+t=\S+)?$/', trim( $txt_value ), $matches ) ) {
			return $matches[1];
		}

		return null;
	}

	private function organisation_service(): OrganisationServiceInterface {
		$service = OrganisationPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No organisation service is registered.' ) );
		}

		return $service;
	}

	/**
	 * A stuck-at-an-earlier-version install is missing the columns this service depends on -
	 * without this guard, a lookup or write would fail with a raw, uncaught database error
	 * instead of this clear, safe message.
	 *
	 * @throws SchemaNotReadyException
	 */
	private static function assert_schema_ready(): void {
		if ( (int) get_option( 'atcp_db_schema_version', 0 ) < self::REQUIRED_SCHEMA_VERSION ) {
			throw new SchemaNotReadyException(
				esc_html__( 'Domain verification is temporarily unavailable while a required database upgrade completes.', 'wp-phishing' )
			);
		}
	}
}
