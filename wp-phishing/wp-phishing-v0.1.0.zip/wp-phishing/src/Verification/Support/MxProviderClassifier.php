<?php
/**
 * Classifies a domain's mail platform from its MX records, per the "Multi-provider delivery
 * modes" plan addition: the account dashboard and admin UI only offer a mailbox-injection consent
 * option matching what a customer's own domain actually runs on.
 *
 * Heuristic, not authoritative - a best-effort read of well-known MX hostname patterns, not a
 * security control. The real gate is whether a consent grant actually works (verified by
 * {@see \Alltime\WPPhishing\MailIntegrations\MailIntegrationService}'s token-fetch attempt); this
 * only decides which option is worth showing at all.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Verification\Support;

use Alltime\WPPhishing\Verification\Dns;
use Alltime\WPPhishing\Verification\Enums\MxProvider;

final class MxProviderClassifier {

	/**
	 * @param callable(string,int):array<int,array<string,mixed>> $dns_query Defaults to
	 *        {@see Dns::query()}; overridable so tests can assert against deterministic MX
	 *        responses instead of depending on public DNS.
	 */
	public function __construct(
		private $dns_query = array( Dns::class, 'query' )
	) {}

	public function classify( string $domain ): MxProvider {
		try {
			$records = ( $this->dns_query )( $domain, DNS_MX );
		} catch ( \Throwable $exception ) {
			return MxProvider::Unknown;
		}

		$hosts = array_map(
			static fn ( array $record ): string => strtolower( (string) ( $record['target'] ?? '' ) ),
			array_values( array_filter( $records, 'is_array' ) )
		);

		foreach ( $hosts as $host ) {
			if ( str_ends_with( $host, '.mail.protection.outlook.com' ) ) {
				return MxProvider::Microsoft365;
			}
		}

		foreach ( $hosts as $host ) {
			if ( str_ends_with( $host, '.l.google.com' ) || 'smtp.google.com' === $host ) {
				return MxProvider::GoogleWorkspace;
			}
		}

		return MxProvider::Unknown;
	}
}
