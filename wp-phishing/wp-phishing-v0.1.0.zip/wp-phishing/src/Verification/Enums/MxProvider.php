<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Verification\Enums;

enum MxProvider: string {
	case Microsoft365    = 'microsoft365';
	case GoogleWorkspace = 'google_workspace';
	case Unknown         = 'unknown';
}
