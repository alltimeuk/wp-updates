<?php
/**
 * Thin wrapper around PHP's built-in `dns_get_record()` so callers share one error-handling
 * convention: a genuine resolution error throws, while "no records of this type" returns an
 * empty array (never a merged "failed = absent" representation).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Verification;

final class Dns {

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public static function query( string $name, int $type ): array {
		// Not development/debug code - `dns_get_record()` signals a genuine resolution failure
		// with a raised E_WARNING rather than a catchable exception; this converts that into one
		// so the try/finally below can distinguish "no records of this type" from an actual
		// error, then always restores the previous handler.
		set_error_handler( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_set_error_handler
			static function ( int $errno, string $errstr ): bool {
				throw new \RuntimeException( esc_html( $errstr ) );
			}
		);

		try {
			// Trailing dot forces an absolute lookup against the domain itself, not expanded
			// through a local resolver's search-domain configuration.
			$records = dns_get_record( rtrim( $name, '.' ) . '.', $type );

			return false !== $records ? $records : array();
		} catch ( \RuntimeException $exception ) {
			if ( str_contains( $exception->getMessage(), 'DNS Query failed' ) ) {
				return array();
			}

			throw $exception;
		} finally {
			restore_error_handler();
		}
	}
}
