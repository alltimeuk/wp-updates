<?php
/**
 * Thrown when domain verification is invoked before the Customer Platform's Organisation
 * schema (version 3) has finished installing/upgrading.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Verification;

final class SchemaNotReadyException extends \RuntimeException {}
