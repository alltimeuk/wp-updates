<?php
/**
 * A single append-only tracking event, per Section 33.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Tracking;

use Alltime\WPPhishing\Support\Dates;
use Alltime\WPPhishing\Tracking\Enums\Confidence;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;

final class TrackingEvent {

	public function __construct(
		public readonly int $id,
		public readonly string $event_uuid,
		public readonly string $delivery_uuid,
		public readonly TrackingEventType $event_type,
		public readonly \DateTimeImmutable $observed_at,
		public readonly string $source,
		public readonly Confidence $confidence,
		/** @var array<string,mixed> */
		public readonly array $metadata,
		public readonly ?string $deduplication_key,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$metadata = ! empty( $row['metadata'] ) ? json_decode( (string) $row['metadata'], true ) : array();

		return new self(
			id: (int) $row['id'],
			event_uuid: (string) $row['event_uuid'],
			delivery_uuid: (string) $row['delivery_uuid'],
			event_type: TrackingEventType::from( (string) $row['event_type'] ),
			observed_at: Dates::from_mysql( (string) $row['observed_at'] ),
			source: (string) $row['source'],
			confidence: Confidence::from( (string) $row['confidence'] ),
			metadata: is_array( $metadata ) ? $metadata : array(),
			deduplication_key: ! empty( $row['deduplication_key'] ) ? (string) $row['deduplication_key'] : null,
			created_at: Dates::from_mysql( (string) $row['created_at'] )
		);
	}
}
