<?php
/**
 * Tracking event types, per Section 33. `MessageDelivered`/`MessageBounced` (provider bounce/
 * delivery feedback) and `TrainingViewed`/`TrainingCompleted` (no training content exists yet)
 * are deliberately unused this phase - the cases exist for schema/event-type completeness per the
 * spec's own list, and so a later phase can start emitting them without a migration.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Tracking\Enums;

enum TrackingEventType: string {
	case MessageAccepted               = 'message_accepted';
	case MessageDelivered              = 'message_delivered';
	case MessageBounced                = 'message_bounced';
	case MessageOpenObserved           = 'message_open_observed';
	case LinkClicked                   = 'link_clicked';
	case LandingViewed                 = 'landing_viewed';
	case InteractionStarted            = 'interaction_started';
	case CredentialSubmissionAttempted = 'credential_submission_attempted';
	case SimulationReported            = 'simulation_reported';
	case TrainingViewed                = 'training_viewed';
	case TrainingCompleted             = 'training_completed';
}
