<?php
/**
 * Automated-scanner-vs-human confidence classification, per Section 35. Every event recorded this
 * phase carries `Unknown` - the probabilistic classifier (UA/timing/network-range signals) is
 * Phase 2 (Section 77); `Unknown` here means "not yet classified", never "confirmed human", so
 * reporting must not silently count it as an employee failure (Section 35).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Tracking\Enums;

enum Confidence: string {
	case ProbableAutomated = 'probable_automated';
	case ProbableHuman     = 'probable_human';
	case Unknown           = 'unknown';
}
