<?php
/**
 * Tracking token issuance/resolution and event recording, per Section 32/33.
 *
 * Token issuance is deliberately two steps rather than one: {@see generate_raw_token()} is called
 * before the delivery it belongs to even exists (the raw token is embedded as `{{campaign_token}}`
 * in the delivery's rendered content, which is itself a required field when the delivery row is
 * created - Section 26), and {@see store_token()} persists the token's hash once the delivery's
 * id is known, right after. The raw value is never persisted, only its SHA-256 hash - the same
 * convention {@see \Alltime\WPPhishing\Auth\TokenService} already uses for auth tokens.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Tracking;

use Alltime\WPPhishing\Delivery\Delivery;
use Alltime\WPPhishing\Delivery\Repositories\DeliveryRepository;
use Alltime\WPPhishing\Emergency\EmergencyControls;
use Alltime\WPPhishing\Tracking\Enums\Confidence;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;
use Alltime\WPPhishing\Tracking\Repositories\TrackingEventRepository;
use Alltime\WPPhishing\Tracking\Repositories\TrackingTokenRepository;

final class TrackingService {

	public function __construct(
		private readonly TrackingTokenRepository $tokens = new TrackingTokenRepository(),
		private readonly TrackingEventRepository $events = new TrackingEventRepository(),
		private readonly DeliveryRepository $deliveries = new DeliveryRepository()
	) {}

	/**
	 * A 256-bit random, unguessable value (Section 32) - opaque, and carrying no email address,
	 * recipient id, campaign id, organisation id, or sequential identifier.
	 */
	public function generate_raw_token(): string {
		return bin2hex( random_bytes( 32 ) );
	}

	public function store_token( string $raw_token, int $delivery_id ): void {
		$this->tokens->create( $this->hash( $raw_token ), $delivery_id );
	}

	/**
	 * Resolves an incoming token (from a `/tracking/*` or `/simulation/*` request) back to its
	 * delivery server-side - the whole point of the token being opaque (Section 32).
	 */
	public function resolve_token( string $raw_token ): ?Delivery {
		if ( '' === $raw_token ) {
			return null;
		}

		$delivery_id = $this->tokens->find_delivery_id_by_hash( $this->hash( $raw_token ) );

		return null !== $delivery_id ? $this->deliveries->find( $delivery_id ) : null;
	}

	/**
	 * Section 71's "disable tracking if required" emergency control stops this at its single
	 * entry point - a genuinely global kill switch on every tracking event this plugin ever
	 * records, not only recipient-interaction events.
	 *
	 * @param array<string,mixed>|null $metadata
	 */
	public function record_event(
		string $delivery_uuid,
		TrackingEventType $event_type,
		string $source,
		Confidence $confidence = Confidence::Unknown,
		?array $metadata = null,
		?string $deduplication_key = null
	): void {
		if ( EmergencyControls::tracking_is_disabled() ) {
			return;
		}

		$this->events->record( $delivery_uuid, $event_type, $source, $confidence, $metadata, $deduplication_key );
	}

	private function hash( string $raw_token ): string {
		return hash( 'sha256', $raw_token );
	}
}
