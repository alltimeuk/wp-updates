<?php
/**
 * Persistence for tracking events, against `wpp_tracking_events`, per Section 33. Append-only:
 * this module never updates or deletes a row (privacy-driven deletion/anonymisation is a later,
 * separately reviewed Retention module concern - Section 54).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Tracking\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Tracking\Enums\Confidence;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;
use Alltime\WPPhishing\Tracking\TrackingEvent;

final class TrackingEventRepository {

	/**
	 * Records an event. When $deduplication_key is set, a second call with the same key is a
	 * silent no-op (INSERT IGNORE against the `deduplication_key` unique key) rather than an
	 * error or a duplicate row - callers that might legitimately be invoked twice for the same
	 * fact (e.g. a delivery-queue retry re-recording `message_accepted`) can call this
	 * unconditionally. A null key always inserts a new row - repeated opens/clicks are each their
	 * own event.
	 *
	 * @param array<string,mixed>|null $metadata
	 */
	public function record(
		string $delivery_uuid,
		TrackingEventType $event_type,
		string $source,
		Confidence $confidence = Confidence::Unknown,
		?array $metadata = null,
		?string $deduplication_key = null
	): void {
		global $wpdb;

		$table = Schema::table( 'tracking_events' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'event_uuid'        => wp_generate_uuid4(),
			'delivery_uuid'     => $delivery_uuid,
			'event_type'        => $event_type->value,
			'observed_at'       => $now,
			'source'            => $source,
			'confidence'        => $confidence->value,
			'metadata'          => null !== $metadata ? wp_json_encode( $metadata ) : null,
			'deduplication_key' => $deduplication_key,
			'created_at'        => $now,
		);

		if ( null === $deduplication_key ) {
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			return;
		}

		$columns      = implode( ', ', array_keys( $data ) );
		$placeholders = implode( ', ', array_fill( 0, count( $data ), '%s' ) );
		$query        = "INSERT IGNORE INTO `{$table}` ({$columns}) VALUES ({$placeholders})";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $query is this method's own fixed, parameterless query text (table/column names only, no user input); phpcs cannot see that statically.
		$wpdb->query( $wpdb->prepare( $query, array_values( $data ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.
	}

	/**
	 * @return TrackingEvent[]
	 */
	public function find_for_delivery( string $delivery_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'tracking_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE delivery_uuid = %s ORDER BY id ASC", $delivery_uuid ), ARRAY_A );

		return array_map( array( TrackingEvent::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Batch-fetches events for many deliveries in one query rather than one round-trip per
	 * delivery - used by result computation, which otherwise issues a separate query per wave
	 * recipient.
	 *
	 * @param string[] $delivery_uuids
	 *
	 * @return array<string,TrackingEvent[]> Keyed by delivery_uuid.
	 */
	public function find_for_deliveries( array $delivery_uuids ): array {
		global $wpdb;

		if ( array() === $delivery_uuids ) {
			return array();
		}

		$table        = Schema::table( 'tracking_events' );
		$placeholders = implode( ', ', array_fill( 0, count( $delivery_uuids ), '%s' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- $table/$placeholders are fixed, internally derived (table name, placeholder count matches count($delivery_uuids)), not user input; $wpdb->prepare() accepts an array as its second argument.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE delivery_uuid IN ({$placeholders}) ORDER BY id ASC", $delivery_uuids ), ARRAY_A );

		$grouped = array();

		foreach ( null !== $rows ? $rows : array() as $row ) {
			$event                              = TrackingEvent::from_row( $row );
			$grouped[ $event->delivery_uuid ][] = $event;
		}

		return $grouped;
	}

	/**
	 * The most recent events across every delivery - an admin "recent activity" view.
	 *
	 * @return TrackingEvent[]
	 */
	public function find_recent( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'tracking_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );

		return array_map( array( TrackingEvent::class, 'from_row' ), null !== $rows ? $rows : array() );
	}
}
