<?php
/**
 * Persistence for tracking tokens, against `wpp_tracking_tokens`, per Section 32. Only ever
 * queried by hash - the raw token exists in memory only, embedded in a delivery's rendered
 * content and never itself persisted (mirrors `Auth\TokenService`'s convention for auth tokens).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Tracking\Repositories;

use Alltime\WPPhishing\Data\Schema;

final class TrackingTokenRepository {

	public function create( string $token_hash, int $delivery_id ): void {
		global $wpdb;

		$table = Schema::table( 'tracking_tokens' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'token_hash'  => $token_hash,
				'delivery_id' => $delivery_id,
				'created_at'  => current_time( 'mysql', true ),
			)
		);
	}

	public function find_delivery_id_by_hash( string $token_hash ): ?int {
		global $wpdb;

		$table = Schema::table( 'tracking_tokens' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$delivery_id = $wpdb->get_var( $wpdb->prepare( "SELECT delivery_id FROM `{$table}` WHERE token_hash = %s", $token_hash ) );

		return null !== $delivery_id ? (int) $delivery_id : null;
	}
}
