<?php
/**
 * Public tracking/simulation route bootstrap, per Section 32: `/tracking/open/{token}`,
 * `/tracking/click/{token}`, `/simulation/{token}`. Mirrors {@see \Alltime\WPPhishing\Auth\AuthBootstrap}'s
 * rewrite-rule + query-var + template_redirect dispatch shape, but every route here is
 * unauthenticated and public by design - a recipient who received a simulation email is never a
 * logged-in WordPress user.
 *
 * Per this plugin's own documented deployment assumption (PLAN.md Section 9): tracking and
 * landing routes are served by this same WordPress install regardless of which configured
 * hostname (a sender domain's `tracking_domain`/`landing_domain`) the request arrived on - vhost/
 * domain-mapping is an infrastructure concern, not something this class resolves itself. The
 * click route therefore redirects to `/simulation/{token}` on whatever host WordPress considers
 * its own, not a hostname read from the request.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Tracking;

use Alltime\WPPhishing\Campaigns\Repositories\CampaignWaveRepository;
use Alltime\WPPhishing\Delivery\Delivery;
use Alltime\WPPhishing\Landing\Enums\LandingPageMode;
use Alltime\WPPhishing\Landing\LandingPageVersion;
use Alltime\WPPhishing\Landing\Repositories\LandingPageRepository;
use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\SuppressionService;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;

final class TrackingBootstrap {

	private const QUERY_VAR_ACTION = 'wpp_tracking_action';
	private const QUERY_VAR_TOKEN  = 'wpp_tracking_token';
	private const TOKEN_PATTERN    = '[0-9a-f]{64}';

	public function __construct(
		private readonly TrackingService $tracking = new TrackingService(),
		private readonly CampaignWaveRepository $waves = new CampaignWaveRepository(),
		private readonly LandingPageRepository $landing_pages = new LandingPageRepository(),
		private readonly SuppressionService $suppressions = new SuppressionService()
	) {}

	public function boot(): void {
		add_action( 'init', array( $this, 'register_rewrite_rules' ) );
		add_filter( 'query_vars', array( $this, 'register_query_vars' ) );
		add_action( 'template_redirect', array( $this, 'dispatch' ) );
	}

	public function register_rewrite_rules(): void {
		$token_group = '(' . self::TOKEN_PATTERN . ')';

		add_rewrite_rule( '^tracking/open/' . $token_group . '/?$', 'index.php?' . self::QUERY_VAR_ACTION . '=open&' . self::QUERY_VAR_TOKEN . '=$matches[1]', 'top' );
		add_rewrite_rule( '^tracking/click/' . $token_group . '/?$', 'index.php?' . self::QUERY_VAR_ACTION . '=click&' . self::QUERY_VAR_TOKEN . '=$matches[1]', 'top' );
		add_rewrite_rule( '^tracking/unsubscribe/' . $token_group . '/?$', 'index.php?' . self::QUERY_VAR_ACTION . '=unsubscribe&' . self::QUERY_VAR_TOKEN . '=$matches[1]', 'top' );
		add_rewrite_rule( '^simulation/' . $token_group . '/?$', 'index.php?' . self::QUERY_VAR_ACTION . '=simulation&' . self::QUERY_VAR_TOKEN . '=$matches[1]', 'top' );
	}

	/**
	 * @param string[] $vars
	 *
	 * @return string[]
	 */
	public function register_query_vars( array $vars ): array {
		$vars[] = self::QUERY_VAR_ACTION;
		$vars[] = self::QUERY_VAR_TOKEN;

		return $vars;
	}

	public function dispatch(): void {
		$action = get_query_var( self::QUERY_VAR_ACTION );
		$token  = get_query_var( self::QUERY_VAR_TOKEN );

		if ( ! is_string( $action ) || '' === $action || ! is_string( $token ) || 1 !== preg_match( '/^' . self::TOKEN_PATTERN . '$/', $token ) ) {
			return;
		}

		match ( $action ) {
			'open' => $this->handle_open( $token ),
			'click' => $this->handle_click( $token ),
			'unsubscribe' => $this->handle_unsubscribe( $token ),
			'simulation' => $this->handle_simulation( $token ),
			default => null,
		};
	}

	/**
	 * Always serves the same 1x1 transparent GIF regardless of whether the token resolved -
	 * response shape must never differ based on token validity (Section 32's opacity requirement
	 * would otherwise leak a validity oracle).
	 */
	private function handle_open( string $token ): void {
		$delivery = $this->tracking->resolve_token( $token );

		if ( null !== $delivery ) {
			$this->tracking->record_event( $delivery->delivery_uuid, TrackingEventType::MessageOpenObserved, source: 'tracking_pixel' );
		}

		$pixel = base64_decode( 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBTAA7' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding a fixed, hard-coded 1x1 transparent GIF literal, not obfuscating anything.

		status_header( 200 );
		nocache_headers();
		header( 'Content-Type: image/gif' );
		echo $pixel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- raw binary image bytes, not HTML/text output.
		exit;
	}

	private function handle_click( string $token ): void {
		$delivery = $this->tracking->resolve_token( $token );

		if ( null !== $delivery ) {
			$this->tracking->record_event( $delivery->delivery_uuid, TrackingEventType::LinkClicked, source: 'tracking_route' );
		}

		wp_safe_redirect( home_url( "/simulation/{$token}/" ) );
		exit;
	}

	/**
	 * GET renders a confirmation page rather than acting immediately, and POST performs the
	 * actual suppression - the same reason `/tracking/click/{token}` can't assume a GET means a
	 * human clicked it: corporate mail-security link-prescanners fetch every URL in an email,
	 * including this one, and a bare GET must never itself unsubscribe someone.
	 */
	private function handle_unsubscribe( string $token ): void {
		status_header( 200 );
		nocache_headers();

		$delivery = $this->tracking->resolve_token( $token );

		if ( null === $delivery ) {
			$this->render_page( __( 'Link no longer valid', 'wp-phishing' ), '<p>' . esc_html__( 'This link is no longer valid.', 'wp-phishing' ) . '</p>' );
			return;
		}

		$is_post = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];

		if ( ! $is_post ) {
			$body = '<p>' . esc_html__( 'Click below to be excluded from future security-awareness simulations sent to this address.', 'wp-phishing' ) . '</p>'
				. '<form method="post"><button type="submit">' . esc_html__( 'Exclude me', 'wp-phishing' ) . '</button></form>';

			$this->render_page( __( 'Manage security-awareness simulations', 'wp-phishing' ), $body );
			return;
		}

		$this->suppressions->suppress( $delivery->organisation_uuid, $delivery->recipient_email, SuppressionReason::RecipientOptOut, 'unsubscribe_link' );

		$this->render_page( __( 'Manage security-awareness simulations', 'wp-phishing' ), '<p>' . esc_html__( 'You have been excluded from future security-awareness simulations sent to this address.', 'wp-phishing' ) . '</p>' );
	}

	private function handle_simulation( string $token ): void {
		status_header( 200 );
		nocache_headers();

		$delivery = $this->tracking->resolve_token( $token );

		if ( null === $delivery ) {
			$this->render_page( __( 'Link no longer valid', 'wp-phishing' ), '<p>' . esc_html__( 'This link is no longer valid.', 'wp-phishing' ) . '</p>' );
			return;
		}

		$version = $this->resolve_landing_page_version( $delivery );

		$this->tracking->record_event( $delivery->delivery_uuid, TrackingEventType::LandingViewed, source: 'tracking_route' );

		if ( null === $version ) {
			$this->render_page( __( 'Simulated phishing exercise', 'wp-phishing' ), $this->educational_html( null ) );
			return;
		}

		$landing_page = $this->landing_pages->find( $version->landing_page_id );
		$mode         = $landing_page?->mode ?? LandingPageMode::ClickOnly;
		$is_post      = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];

		// Section 31.3: the submission is never read, not even for validation - only the fact
		// that a submission was attempted is recorded.
		if ( LandingPageMode::CredentialSimulation === $mode && $is_post ) {
			$this->tracking->record_event( $delivery->delivery_uuid, TrackingEventType::CredentialSubmissionAttempted, source: 'tracking_route', deduplication_key: "credential_submission_attempted:{$delivery->delivery_uuid}" );
			$this->render_page( __( 'Simulated phishing exercise', 'wp-phishing' ), $this->educational_html( $version ) );
			return;
		}

		if ( LandingPageMode::ClickOnly !== $mode ) {
			$this->tracking->record_event( $delivery->delivery_uuid, TrackingEventType::InteractionStarted, source: 'tracking_route', deduplication_key: "interaction_started:{$delivery->delivery_uuid}" );
		}

		$body = LandingPageMode::CredentialSimulation === $mode
			? $version->html_body
			: $version->html_body . $this->educational_html( $version );

		$this->render_page( __( 'Simulated phishing exercise', 'wp-phishing' ), $body );
	}

	private function resolve_landing_page_version( Delivery $delivery ): ?LandingPageVersion {
		if ( 'campaign_wave' !== $delivery->source_object_type || null === $delivery->source_object_uuid ) {
			return null;
		}

		$wave = $this->waves->find_by_uuid( $delivery->source_object_uuid );

		if ( null === $wave || null === $wave->landing_page_version_id ) {
			return null;
		}

		return $this->landing_pages->find_version( $wave->landing_page_version_id );
	}

	private function educational_html( ?LandingPageVersion $version ): string {
		return $version?->educational_html
			?? '<p>' . esc_html__( 'This was a simulated phishing exercise. If this had been a real message, you should have reported it to your IT/security team.', 'wp-phishing' ) . '</p>';
	}

	private function render_page( string $title, string $body ): void {
		echo '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html( $title ) . '</title></head><body>';
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $body is either author-supplied landing page markup (Section 31 - the whole point of a landing/behavioural-continuation page is to render markup, not escaped text) or built from esc_html()-escaped fragments by this class itself.
		echo '</body></html>';
		exit;
	}
}
