<?php
/**
 * Records usage facts and consumes the covering entitlement when a campaign completes, per
 * Section 46/49/50. Subscribes to the `wpp_campaign_completed` action rather than being called
 * directly from {@see \Alltime\WPPhishing\Campaigns\CampaignCompletionService} - the same
 * "just another subscriber, not a special case" pattern wp-reconnaissance's own entitlement
 * fulfilment uses, so completion detection itself never needs to know billing exists.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Commercial;

use Alltime\CustomerPlatform\EntitlementPlatformDiscovery;
use Alltime\CustomerPlatform\EntitlementServiceInterface;
use Alltime\CustomerPlatform\Enums\EntitlementType;
use Alltime\CustomerPlatform\Enums\UsageType;
use Alltime\CustomerPlatform\UsagePlatformDiscovery;
use Alltime\CustomerPlatform\UsageServiceInterface;
use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Results\Repositories\RiskWeightSetRepository;
use Alltime\WPPhishing\Results\ResultsService;

use const Alltime\WPPhishing\WPP_PRODUCT_ID;

final class UsageRecordingListener {

	public function __construct(
		private readonly ResultsService $results = new ResultsService(),
		private readonly RiskWeightSetRepository $weight_sets = new RiskWeightSetRepository(),
		private readonly ?UsageServiceInterface $usage = null,
		private readonly ?EntitlementServiceInterface $entitlements = null
	) {}

	public function boot(): void {
		add_action( 'wpp_campaign_completed', array( $this, 'record_usage' ) );
	}

	public function record_usage( Campaign $campaign ): void {
		$weight_set = $this->weight_sets->find_default();

		// Usage recording must never block completion processing over a missing weight set - risk
		// scoring is irrelevant to usage facts, this is purely how compute_campaign_results() is
		// already shaped to return delivery counts.
		if ( null === $weight_set ) {
			return;
		}

		$results = $this->results->compute_campaign_results( $campaign, $weight_set );
		$stats   = $this->results->delivery_statistics( $results );

		$usage = $this->usage_service();

		$usage->record( $campaign->organisation_uuid, WPP_PRODUCT_ID, UsageType::Campaign, 1, 'count', 'campaign', $campaign->campaign_uuid );
		$usage->record( $campaign->organisation_uuid, WPP_PRODUCT_ID, UsageType::UniqueRecipient, $stats['targeted'], 'count', 'campaign', $campaign->campaign_uuid );
		$usage->record( $campaign->organisation_uuid, WPP_PRODUCT_ID, UsageType::DeliveredMessage, $stats['delivered'], 'count', 'campaign', $campaign->campaign_uuid );

		$this->consume_covering_entitlement( $campaign, $stats );
	}

	/**
	 * @param array{targeted:int,attempted:int,accepted:int,delivered:int,measurable:int} $stats
	 */
	private function consume_covering_entitlement( Campaign $campaign, array $stats ): void {
		$entitlements = $this->entitlement_service();
		$decision     = $entitlements->check( $campaign->organisation_uuid, WPP_PRODUCT_ID, 0 );

		// No active entitlement to draw down against - this must not block completion. Approval
		// already gated on a valid entitlement existing at that time (CampaignApprovalService); if
		// it was revoked in between, that is a billing-reconciliation problem for an operator, not
		// a reason to leave the campaign's own completion processing incomplete.
		if ( null === $decision->entitlement ) {
			return;
		}

		$quantity = match ( $decision->entitlement->type ) {
			EntitlementType::RecipientAllowance => $stats['targeted'],
			EntitlementType::MessageAllowance => $stats['delivered'],
			default => 1,
		};

		if ( $quantity > 0 ) {
			$entitlements->consume( $decision->entitlement->entitlement_uuid, $quantity );
		}
	}

	private function usage_service(): UsageServiceInterface {
		$service = $this->usage ?? UsagePlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No usage-ledger service is registered.' ) );
		}

		return $service;
	}

	private function entitlement_service(): EntitlementServiceInterface {
		$service = $this->entitlements ?? EntitlementPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No entitlement service is registered.' ) );
		}

		return $service;
	}
}
