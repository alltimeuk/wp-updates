<?php
/**
 * Persistence for commercial models against `wpp_commercial_models`, per Section 48.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Commercial\Repositories;

use Alltime\WPPhishing\Commercial\CommercialModel;
use Alltime\WPPhishing\Commercial\Enums\ChargingBasis;
use Alltime\WPPhishing\Commercial\Enums\CommercialModelStatus;
use Alltime\WPPhishing\Data\Schema;

final class CommercialModelRepository {

	public function find( int $id ): ?CommercialModel {
		global $wpdb;

		$table = Schema::table( 'commercial_models' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? CommercialModel::from_row( $row ) : null;
	}

	public function find_by_uuid( string $commercial_model_uuid ): ?CommercialModel {
		global $wpdb;

		$table = Schema::table( 'commercial_models' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE commercial_model_uuid = %s", $commercial_model_uuid ), ARRAY_A );

		return null !== $row ? CommercialModel::from_row( $row ) : null;
	}

	/**
	 * @return CommercialModel[]
	 */
	public function find_all(): array {
		global $wpdb;

		$table = Schema::table( 'commercial_models' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( "SELECT * FROM `{$table}` ORDER BY id DESC", ARRAY_A );

		return array_map( array( CommercialModel::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @param array<string,mixed> $configuration
	 */
	public function create(
		string $name,
		ChargingBasis $charging_basis,
		string $currency,
		?float $base_charge,
		?float $recipient_rate,
		?float $message_rate,
		?float $campaign_rate,
		?int $included_recipients,
		?int $included_messages,
		?int $included_campaigns,
		?float $minimum_charge,
		?float $maximum_charge,
		?string $billing_period,
		array $configuration = array()
	): CommercialModel {
		global $wpdb;

		$table              = Schema::table( 'commercial_models' );
		$now                = current_time( 'mysql', true );
		$configuration_json = wp_json_encode( $configuration );

		if ( false === $configuration_json ) {
			throw new \RuntimeException( esc_html__( 'Commercial model configuration could not be encoded.', 'wp-phishing' ) );
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'commercial_model_uuid' => wp_generate_uuid4(),
				'name'                  => $name,
				'charging_basis'        => $charging_basis->value,
				'currency'              => $currency,
				'base_charge'           => $base_charge,
				'recipient_rate'        => $recipient_rate,
				'message_rate'          => $message_rate,
				'campaign_rate'         => $campaign_rate,
				'included_recipients'   => $included_recipients,
				'included_messages'     => $included_messages,
				'included_campaigns'    => $included_campaigns,
				'minimum_charge'        => $minimum_charge,
				'maximum_charge'        => $maximum_charge,
				'billing_period'        => $billing_period,
				'status'                => CommercialModelStatus::Active->value,
				'configuration_json'    => $configuration_json,
				'created_at'            => $now,
				'updated_at'            => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update_status( int $id, CommercialModelStatus $status ): CommercialModel {
		global $wpdb;

		$table = Schema::table( 'commercial_models' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	/**
	 * The commercial model currently assigned to $organisation_uuid, if any - `wpp_organisation_
	 * commercial_models` is a small mapping table rather than a column on the shared
	 * `atcp_organisations` (Section 8's contract stays free of phishing-specific billing concepts).
	 */
	public function find_assigned_to_organisation( string $organisation_uuid ): ?CommercialModel {
		global $wpdb;

		$assignments = Schema::table( 'organisation_commercial_models' );
		$models      = Schema::table( 'commercial_models' );

		$row = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $assignments/$models are fixed, internally derived identifiers, not user input.
				"SELECT m.* FROM `{$assignments}` a INNER JOIN `{$models}` m ON m.id = a.commercial_model_id WHERE a.organisation_uuid = %s",
				$organisation_uuid
			),
			ARRAY_A
		);

		return null !== $row ? CommercialModel::from_row( $row ) : null;
	}

	public function assign_to_organisation( string $organisation_uuid, int $commercial_model_id, ?int $assigned_by ): void {
		global $wpdb;

		$table = Schema::table( 'organisation_commercial_models' );
		$now   = current_time( 'mysql', true );

		$query = "INSERT INTO `{$table}` (organisation_uuid, commercial_model_id, assigned_by, assigned_at) VALUES (%s, %d, %d, %s)
			ON DUPLICATE KEY UPDATE commercial_model_id = VALUES(commercial_model_id), assigned_by = VALUES(assigned_by), assigned_at = VALUES(assigned_at)";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$wpdb->query( $wpdb->prepare( $query, $organisation_uuid, $commercial_model_id, $assigned_by, $now ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.
	}

	private function find_or_fail( int $id ): CommercialModel {
		$model = $this->find( $id );

		if ( null === $model ) {
			throw new \RuntimeException( esc_html( "Commercial model {$id} was expected to exist but could not be loaded." ) );
		}

		return $model;
	}
}
