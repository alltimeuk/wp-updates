<?php
/**
 * Commercial module bootstrap, per Section 46-50. No cron sweep or public routes of its own -
 * only wires the usage/entitlement completion listener.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Commercial;

final class CommercialBootstrap {

	public function __construct(
		private readonly UsageRecordingListener $usage_recording = new UsageRecordingListener()
	) {}

	public function boot(): void {
		$this->usage_recording->boot();
	}
}
