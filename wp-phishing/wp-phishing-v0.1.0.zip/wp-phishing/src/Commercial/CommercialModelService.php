<?php
/**
 * Commercial model management, per Section 46-48. Deliberately thin - this plugin only records
 * and assigns commercial models, it never calculates a charge from one (Section 51: "WP-Phishing
 * shall not contain Halo invoice-generation logic").
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Commercial;

use Alltime\WPPhishing\Commercial\Enums\ChargingBasis;
use Alltime\WPPhishing\Commercial\Enums\CommercialModelStatus;
use Alltime\WPPhishing\Commercial\Repositories\CommercialModelRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class CommercialModelService {

	public function __construct(
		private readonly CommercialModelRepository $models = new CommercialModelRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return CommercialModel[]
	 */
	public function list_all(): array {
		return $this->models->find_all();
	}

	public function get( string $commercial_model_uuid ): ?CommercialModel {
		return $this->models->find_by_uuid( $commercial_model_uuid );
	}

	/**
	 * @param array<string,mixed> $configuration
	 */
	public function create(
		string $name,
		ChargingBasis $charging_basis,
		string $currency,
		?float $base_charge = null,
		?float $recipient_rate = null,
		?float $message_rate = null,
		?float $campaign_rate = null,
		?int $included_recipients = null,
		?int $included_messages = null,
		?int $included_campaigns = null,
		?float $minimum_charge = null,
		?float $maximum_charge = null,
		?string $billing_period = null,
		array $configuration = array()
	): CommercialModel {
		$model = $this->models->create( $name, $charging_basis, $currency, $base_charge, $recipient_rate, $message_rate, $campaign_rate, $included_recipients, $included_messages, $included_campaigns, $minimum_charge, $maximum_charge, $billing_period, $configuration );

		$this->audit_logger->log( 'commercial_model.created', 'commercial_model', $model->commercial_model_uuid, get_current_user_id() );

		return $model;
	}

	public function archive( string $commercial_model_uuid ): void {
		$model = $this->models->find_by_uuid( $commercial_model_uuid );

		if ( null === $model ) {
			return;
		}

		$this->models->update_status( $model->id, CommercialModelStatus::Archived );

		$this->audit_logger->log( 'commercial_model.archived', 'commercial_model', $commercial_model_uuid, get_current_user_id() );
	}

	public function assign_to_organisation( string $organisation_uuid, string $commercial_model_uuid, ?int $assigned_by = null ): void {
		$model = $this->models->find_by_uuid( $commercial_model_uuid );

		if ( null === $model ) {
			throw new \InvalidArgumentException( esc_html( "Unknown commercial model UUID: {$commercial_model_uuid}" ) );
		}

		$this->models->assign_to_organisation( $organisation_uuid, $model->id, $assigned_by );

		$this->audit_logger->log( 'commercial_model.assigned', 'commercial_model', $commercial_model_uuid, $assigned_by, organisation_uuid: $organisation_uuid );
	}

	public function assigned_to( string $organisation_uuid ): ?CommercialModel {
		return $this->models->find_assigned_to_organisation( $organisation_uuid );
	}
}
