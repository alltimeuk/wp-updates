<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Commercial\Enums;

enum CommercialModelStatus: string {
	case Active   = 'active';
	case Archived = 'archived';
}
