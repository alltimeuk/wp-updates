<?php
/**
 * The eight commercial models an administrator may configure, per Section 47. The campaign
 * engine itself never hard-codes pricing (Section 46) - this only names which rate fields on
 * {@see \Alltime\WPPhishing\Commercial\CommercialModel} are meaningful for a given basis; the
 * actual charge calculation is a downstream billing concern this plugin deliberately does not
 * perform (Section 51: "WP-Phishing shall not contain Halo invoice-generation logic").
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Commercial\Enums;

enum ChargingBasis: string {
	case FlatEngagement   = 'flat_engagement';
	case PerCampaign      = 'per_campaign';
	case PerRecipient     = 'per_recipient';
	case PerMessage       = 'per_message';
	case OrganisationBand = 'organisation_band';
	case Subscription     = 'subscription';
	case Hybrid           = 'hybrid';
	case ManagedService   = 'managed_service';
}
