<?php
/**
 * A named, administrator-configured commercial model, per Section 48's schema (fields taken
 * verbatim). Plugin-local, unlike Usage/Entitlements - the spec never declares this a shared
 * logical resource, and a charging basis is inherently a wp-phishing-specific concept.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Commercial;

use Alltime\WPPhishing\Commercial\Enums\ChargingBasis;
use Alltime\WPPhishing\Commercial\Enums\CommercialModelStatus;

final class CommercialModel {

	public function __construct(
		public readonly int $id,
		public readonly string $commercial_model_uuid,
		public readonly string $name,
		public readonly ChargingBasis $charging_basis,
		public readonly string $currency,
		public readonly ?float $base_charge,
		public readonly ?float $recipient_rate,
		public readonly ?float $message_rate,
		public readonly ?float $campaign_rate,
		public readonly ?int $included_recipients,
		public readonly ?int $included_messages,
		public readonly ?int $included_campaigns,
		public readonly ?float $minimum_charge,
		public readonly ?float $maximum_charge,
		public readonly ?string $billing_period,
		public readonly CommercialModelStatus $status,
		/** @var array<string,mixed> */
		public readonly array $configuration,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$configuration = ! empty( $row['configuration_json'] ) ? json_decode( (string) $row['configuration_json'], true ) : array();

		return new self(
			id: (int) $row['id'],
			commercial_model_uuid: (string) $row['commercial_model_uuid'],
			name: (string) $row['name'],
			charging_basis: ChargingBasis::from( (string) $row['charging_basis'] ),
			currency: (string) $row['currency'],
			base_charge: null !== $row['base_charge'] ? (float) $row['base_charge'] : null,
			recipient_rate: null !== $row['recipient_rate'] ? (float) $row['recipient_rate'] : null,
			message_rate: null !== $row['message_rate'] ? (float) $row['message_rate'] : null,
			campaign_rate: null !== $row['campaign_rate'] ? (float) $row['campaign_rate'] : null,
			included_recipients: null !== $row['included_recipients'] ? (int) $row['included_recipients'] : null,
			included_messages: null !== $row['included_messages'] ? (int) $row['included_messages'] : null,
			included_campaigns: null !== $row['included_campaigns'] ? (int) $row['included_campaigns'] : null,
			minimum_charge: null !== $row['minimum_charge'] ? (float) $row['minimum_charge'] : null,
			maximum_charge: null !== $row['maximum_charge'] ? (float) $row['maximum_charge'] : null,
			billing_period: ! empty( $row['billing_period'] ) ? (string) $row['billing_period'] : null,
			status: CommercialModelStatus::from( (string) $row['status'] ),
			configuration: is_array( $configuration ) ? $configuration : array(),
			created_at: new \DateTimeImmutable( (string) $row['created_at'], new \DateTimeZone( 'UTC' ) ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'], new \DateTimeZone( 'UTC' ) )
		);
	}
}
