<?php
/**
 * Sender domain health validation, per Section 24: "Before campaign activation, validate where
 * applicable: DNS/SPF/DKIM/DMARC/TLS/tracking hostname/landing hostname/mail provider health/
 * sender enabled state. Campaign execution shall fail closed where required infrastructure
 * cannot be verified."
 *
 * DKIM verification needs a known selector (the `{selector}._domainkey.{domain}` TXT record) -
 * Section 22's minimum sender-domain model does not track one, and selectors vary by provider
 * and configuration. Rather than guess, DKIM is reported `Unknown` and deliberately excluded from
 * the pass/fail aggregate below - "not yet checkable" is not conflated with "checked and failed".
 * SPF/DMARC/a basic mail-routing check are always checkable and do participate in the aggregate.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Integrations\Mail\MailManager;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\Repositories\OrganisationMailIntegrationRepository;
use Alltime\WPPhishing\Sending\Enums\HealthStatus;
use Alltime\WPPhishing\Sending\Enums\SenderDeliveryMode;
use Alltime\WPPhishing\Sending\Enums\SenderDomainStatus;
use Alltime\WPPhishing\Sending\Repositories\SenderDomainRepository;
use Alltime\WPPhishing\Verification\Dns;

final class SenderHealthService {

	/**
	 * @param callable(string,int):array<int,array<string,mixed>> $dns_query Defaults to
	 *        {@see Dns::query()}; overridable so tests can assert against deterministic TXT/MX
	 *        responses instead of depending on public DNS.
	 */
	public function __construct(
		private readonly SenderDomainRepository $domains = new SenderDomainRepository(),
		private readonly MailManager $mail_manager = new MailManager(),
		private readonly OrganisationMailIntegrationRepository $mail_integrations = new OrganisationMailIntegrationRepository(),
		private $dns_query = array( Dns::class, 'query' )
	) {}

	/**
	 * Runs every check and persists the result - the customer/admin-triggered "check health now"
	 * action, and the background sweep's per-domain unit of work. A mailbox-injection domain has
	 * no real DNS to check (Section 24's SPF/DKIM/DMARC/TLS checks assume real transport, which
	 * this delivery mode deliberately has none of) - it is reported Healthy exactly when its
	 * organisation still holds an active mailbox-injection integration for the matching provider,
	 * checked fresh here rather than only at {@see is_ready_for_sending()} time.
	 */
	public function check( SenderDomain $domain ): SenderDomain {
		if ( SenderDeliveryMode::MailboxInjection === $domain->delivery_mode ) {
			$overall = $this->mailbox_injection_integration_active( $domain ) ? HealthStatus::Healthy : HealthStatus::Unhealthy;

			return $this->domains->record_health_check( $domain->id, HealthStatus::Unknown, HealthStatus::Unknown, HealthStatus::Unknown, HealthStatus::Unknown, $overall );
		}

		$spf   = $this->check_spf( $domain->domain );
		$dmarc = $this->check_dmarc( $domain->domain );
		$tls   = $this->check_mail_routing( $domain->domain );
		$dkim  = HealthStatus::Unknown; // See class docblock - not checkable without a tracked selector.

		$overall = $this->aggregate( $spf, $dmarc, $tls );

		return $this->domains->record_health_check( $domain->id, $spf, $dkim, $dmarc, $tls, $overall );
	}

	/**
	 * The fail-closed gate itself (Section 24/70): true only when the domain is Active, its last
	 * recorded health check was Healthy, and its resolved mail provider is both known and
	 * correctly configured. Never re-runs the DNS checks synchronously - it trusts the most
	 * recent {@see check()} result, so a caller wanting a fresh check must call that first.
	 */
	public function is_ready_for_sending( SenderDomain $domain ): bool {
		if ( SenderDomainStatus::Active !== $domain->status ) {
			return false;
		}

		if ( HealthStatus::Healthy !== $domain->health_status ) {
			return false;
		}

		if ( SenderDeliveryMode::MailboxInjection === $domain->delivery_mode && ! $this->mailbox_injection_integration_active( $domain ) ) {
			return false;
		}

		$provider = $this->mail_manager->resolve( $domain->mail_provider, $domain->organisation_uuid ?? '' );

		return null !== $provider && array() === $provider->validate_configuration();
	}

	/**
	 * A mailbox-injection domain always belongs to one organisation (enforced at creation by
	 * {@see \Alltime\WPPhishing\Sending\SenderDomainService::create()}) and always has an
	 * explicit `mail_provider` (chosen when the domain was created) identifying which of the two
	 * injection providers it uses - this checks that *specific* provider's integration, not
	 * "any" provider's.
	 */
	private function mailbox_injection_integration_active( SenderDomain $domain ): bool {
		if ( null === $domain->organisation_uuid ) {
			return false;
		}

		$integration_provider = match ( $domain->mail_provider ) {
			MailProviderId::GraphMailboxWrite => MailIntegrationProvider::Microsoft365,
			MailProviderId::GmailMailboxInsert => MailIntegrationProvider::GoogleWorkspace,
			default => null,
		};

		if ( null === $integration_provider ) {
			return false;
		}

		$integration = $this->mail_integrations->find_one( $domain->organisation_uuid, $integration_provider, MailIntegrationCapability::MailboxInjection );

		return null !== $integration && $integration->is_active();
	}

	private function check_spf( string $domain ): HealthStatus {
		return $this->has_txt_record_starting_with( $domain, 'v=spf1' ) ? HealthStatus::Healthy : HealthStatus::Unhealthy;
	}

	private function check_dmarc( string $domain ): HealthStatus {
		return $this->has_txt_record_starting_with( "_dmarc.{$domain}", 'v=DMARC1' ) ? HealthStatus::Healthy : HealthStatus::Unhealthy;
	}

	/**
	 * A full STARTTLS/cipher inspection needs a raw SMTP socket connection to the domain's MX
	 * host, which is out of scope here - the presence of at least one MX record is used as a
	 * basic "mail routing for this domain exists" proxy check instead.
	 */
	private function check_mail_routing( string $domain ): HealthStatus {
		try {
			$records = ( $this->dns_query )( $domain, DNS_MX );
		} catch ( \Throwable $exception ) {
			return HealthStatus::Unknown;
		}

		return array() !== $records ? HealthStatus::Healthy : HealthStatus::Unhealthy;
	}

	private function has_txt_record_starting_with( string $hostname, string $prefix ): bool {
		try {
			$records = ( $this->dns_query )( $hostname, DNS_TXT );
		} catch ( \Throwable $exception ) {
			return false;
		}

		foreach ( $records as $record ) {
			if ( ! is_array( $record ) ) {
				continue;
			}

			$txt = is_string( $record['txt'] ?? null ) ? $record['txt'] : '';

			if ( str_starts_with( $txt, $prefix ) ) {
				return true;
			}
		}

		return false;
	}

	private function aggregate( HealthStatus ...$required_checks ): HealthStatus {
		if ( in_array( HealthStatus::Unhealthy, $required_checks, true ) ) {
			return HealthStatus::Unhealthy;
		}

		if ( in_array( HealthStatus::Unknown, $required_checks, true ) ) {
			return HealthStatus::Degraded;
		}

		return HealthStatus::Healthy;
	}
}
