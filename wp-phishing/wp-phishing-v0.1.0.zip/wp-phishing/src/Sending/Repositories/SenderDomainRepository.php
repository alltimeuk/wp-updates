<?php
/**
 * Persistence for sender domains against `wpp_sender_domains`, per Section 22.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Sending\Enums\HealthStatus;
use Alltime\WPPhishing\Sending\Enums\SenderDeliveryMode;
use Alltime\WPPhishing\Sending\Enums\SenderDomainStatus;
use Alltime\WPPhishing\Sending\SenderDomain;

final class SenderDomainRepository {

	public function find( int $id ): ?SenderDomain {
		global $wpdb;

		$table = Schema::table( 'sender_domains' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? SenderDomain::from_row( $row ) : null;
	}

	public function find_by_uuid( string $domain_uuid ): ?SenderDomain {
		global $wpdb;

		$table = Schema::table( 'sender_domains' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE domain_uuid = %s", $domain_uuid ), ARRAY_A );

		return null !== $row ? SenderDomain::from_row( $row ) : null;
	}

	public function find_by_domain( string $domain ): ?SenderDomain {
		global $wpdb;

		$table = Schema::table( 'sender_domains' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE domain = %s", $domain ), ARRAY_A );

		return null !== $row ? SenderDomain::from_row( $row ) : null;
	}

	/**
	 * Every active sender domain available to the given organisation - the shared pool
	 * (`organisation_uuid IS NULL`) plus any domain dedicated to it specifically (Section 22).
	 *
	 * @return SenderDomain[]
	 */
	public function find_available_for_organisation( string $organisation_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'sender_domains' );
		$query = "SELECT * FROM `{$table}` WHERE status = 'active' AND (organisation_uuid IS NULL OR organisation_uuid = %s) ORDER BY id ASC";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, $organisation_uuid ), ARRAY_A );

		return array_map( array( SenderDomain::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return SenderDomain[]
	 */
	public function find_all( int $per_page, int $page ): array {
		global $wpdb;

		$table  = Schema::table( 'sender_domains' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A );

		return array_map( array( SenderDomain::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create( string $domain, ?string $organisation_uuid, ?MailProviderId $mail_provider, ?string $tracking_domain, ?string $landing_domain, SenderDeliveryMode $delivery_mode = SenderDeliveryMode::ApiSend ): SenderDomain {
		global $wpdb;

		$table = Schema::table( 'sender_domains' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'domain_uuid'       => wp_generate_uuid4(),
			'domain'            => $domain,
			'organisation_uuid' => $organisation_uuid,
			'status'            => SenderDomainStatus::Active->value,
			'delivery_mode'     => $delivery_mode->value,
			'mail_provider'     => $mail_provider?->value,
			'tracking_domain'   => $tracking_domain,
			'landing_domain'    => $landing_domain,
			'spf_status'        => HealthStatus::Unknown->value,
			'dkim_status'       => HealthStatus::Unknown->value,
			'dmarc_status'      => HealthStatus::Unknown->value,
			'tls_status'        => HealthStatus::Unknown->value,
			'health_status'     => HealthStatus::Unknown->value,
			'created_at'        => $now,
			'updated_at'        => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function record_health_check(
		int $id,
		HealthStatus $spf_status,
		HealthStatus $dkim_status,
		HealthStatus $dmarc_status,
		HealthStatus $tls_status,
		HealthStatus $overall_status
	): SenderDomain {
		global $wpdb;

		$table = Schema::table( 'sender_domains' );
		$now   = current_time( 'mysql', true );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'spf_status'           => $spf_status->value,
				'dkim_status'          => $dkim_status->value,
				'dmarc_status'         => $dmarc_status->value,
				'tls_status'           => $tls_status->value,
				'health_status'        => $overall_status->value,
				'last_health_check_at' => $now,
				'updated_at'           => $now,
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function retire( int $id ): SenderDomain {
		global $wpdb;

		$table = Schema::table( 'sender_domains' );
		$now   = current_time( 'mysql', true );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'     => SenderDomainStatus::Retired->value,
				'retired_at' => $now,
				'updated_at' => $now,
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): SenderDomain {
		$domain = $this->find( $id );

		if ( null === $domain ) {
			throw new \RuntimeException( esc_html( "Sender domain {$id} was expected to exist but could not be loaded." ) );
		}

		return $domain;
	}
}
