<?php
/**
 * Persistence for sender identities against `wpp_sender_identities`, per Section 23.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Sending\Enums\ScenarioClassification;
use Alltime\WPPhishing\Sending\Enums\SenderIdentityStatus;
use Alltime\WPPhishing\Sending\SenderIdentity;

final class SenderIdentityRepository {

	public function find( int $id ): ?SenderIdentity {
		global $wpdb;

		$table = Schema::table( 'sender_identities' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? SenderIdentity::from_row( $row ) : null;
	}

	public function find_by_uuid( string $identity_uuid ): ?SenderIdentity {
		global $wpdb;

		$table = Schema::table( 'sender_identities' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE identity_uuid = %s", $identity_uuid ), ARRAY_A );

		return null !== $row ? SenderIdentity::from_row( $row ) : null;
	}

	/**
	 * @return SenderIdentity[]
	 */
	public function find_all_for_domain( int $sender_domain_id ): array {
		global $wpdb;

		$table = Schema::table( 'sender_identities' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE sender_domain_id = %d ORDER BY id ASC", $sender_domain_id ), ARRAY_A );

		return array_map( array( SenderIdentity::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create(
		int $sender_domain_id,
		string $display_name,
		string $local_part,
		?string $reply_to,
		?ScenarioClassification $scenario_classification
	): SenderIdentity {
		global $wpdb;

		$table = Schema::table( 'sender_identities' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'identity_uuid'           => wp_generate_uuid4(),
			'sender_domain_id'        => $sender_domain_id,
			'display_name'            => $display_name,
			'local_part'              => $local_part,
			'reply_to'                => $reply_to,
			'scenario_classification' => $scenario_classification?->value,
			'status'                  => SenderIdentityStatus::Active->value,
			'created_at'              => $now,
			'updated_at'              => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update_status( int $id, SenderIdentityStatus $status ): SenderIdentity {
		global $wpdb;

		$table = Schema::table( 'sender_identities' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): SenderIdentity {
		$identity = $this->find( $id );

		if ( null === $identity ) {
			throw new \RuntimeException( esc_html( "Sender identity {$id} was expected to exist but could not be loaded." ) );
		}

		return $identity;
	}
}
