<?php
/**
 * Sender domain entity, per Section 22.
 *
 * Distinct from an {@see \Alltime\CustomerPlatform\OrganisationDomain}: that represents a
 * customer's own domain, verified for ownership (Section 10/11); this represents a controlled
 * domain WP-Phishing itself sends simulation mail from - separate from customer production
 * domains, normal Alltime corporate email, and transactional customer communications.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Sending\Enums\HealthStatus;
use Alltime\WPPhishing\Sending\Enums\SenderDeliveryMode;
use Alltime\WPPhishing\Sending\Enums\SenderDomainStatus;

final class SenderDomain {

	public function __construct(
		public readonly int $id,
		public readonly string $domain_uuid,
		public readonly string $domain,
		public readonly ?string $organisation_uuid,
		public readonly SenderDomainStatus $status,
		public readonly SenderDeliveryMode $delivery_mode,
		public readonly ?MailProviderId $mail_provider,
		public readonly ?string $tracking_domain,
		public readonly ?string $landing_domain,
		public readonly HealthStatus $spf_status,
		public readonly HealthStatus $dkim_status,
		public readonly HealthStatus $dmarc_status,
		public readonly HealthStatus $tls_status,
		public readonly HealthStatus $health_status,
		public readonly ?\DateTimeImmutable $last_health_check_at,
		public readonly ?string $reputation_notes,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at,
		public readonly ?\DateTimeImmutable $retired_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			domain_uuid: (string) $row['domain_uuid'],
			domain: (string) $row['domain'],
			organisation_uuid: ! empty( $row['organisation_uuid'] ) ? (string) $row['organisation_uuid'] : null,
			status: SenderDomainStatus::from( (string) $row['status'] ),
			delivery_mode: SenderDeliveryMode::from( (string) ( $row['delivery_mode'] ?? SenderDeliveryMode::ApiSend->value ) ),
			mail_provider: ! empty( $row['mail_provider'] ) ? MailProviderId::from( (string) $row['mail_provider'] ) : null,
			tracking_domain: ! empty( $row['tracking_domain'] ) ? (string) $row['tracking_domain'] : null,
			landing_domain: ! empty( $row['landing_domain'] ) ? (string) $row['landing_domain'] : null,
			spf_status: HealthStatus::from( (string) $row['spf_status'] ),
			dkim_status: HealthStatus::from( (string) $row['dkim_status'] ),
			dmarc_status: HealthStatus::from( (string) $row['dmarc_status'] ),
			tls_status: HealthStatus::from( (string) $row['tls_status'] ),
			health_status: HealthStatus::from( (string) $row['health_status'] ),
			last_health_check_at: ! empty( $row['last_health_check_at'] ) ? new \DateTimeImmutable( (string) $row['last_health_check_at'] ) : null,
			reputation_notes: ! empty( $row['reputation_notes'] ) ? (string) $row['reputation_notes'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] ),
			retired_at: ! empty( $row['retired_at'] ) ? new \DateTimeImmutable( (string) $row['retired_at'] ) : null
		);
	}
}
