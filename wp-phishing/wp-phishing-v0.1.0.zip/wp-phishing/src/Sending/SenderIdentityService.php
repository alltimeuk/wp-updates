<?php
/**
 * Sender identity service, per Section 23.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending;

use Alltime\WPPhishing\Sending\Enums\ScenarioClassification;
use Alltime\WPPhishing\Sending\Enums\SenderIdentityStatus;
use Alltime\WPPhishing\Sending\Repositories\SenderIdentityRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class SenderIdentityService {

	public function __construct(
		private readonly SenderIdentityRepository $identities = new SenderIdentityRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return SenderIdentity[]
	 */
	public function list_for_domain( SenderDomain $domain ): array {
		return $this->identities->find_all_for_domain( $domain->id );
	}

	public function create(
		SenderDomain $domain,
		string $display_name,
		string $local_part,
		?string $reply_to,
		?ScenarioClassification $scenario_classification,
		?int $created_by = null
	): SenderIdentity {
		$identity = $this->identities->create( $domain->id, $display_name, $local_part, $reply_to, $scenario_classification );

		$this->audit_logger->log( 'sender_identity.created', 'sender_identity', $identity->identity_uuid, $created_by, summary: "{$local_part}@{$domain->domain}", source: 'admin', organisation_uuid: $domain->organisation_uuid );

		return $identity;
	}

	public function set_status( SenderIdentity $identity, SenderIdentityStatus $status, ?int $updated_by = null ): SenderIdentity {
		$updated = $this->identities->update_status( $identity->id, $status );

		$this->audit_logger->log( 'sender_identity.status_changed', 'sender_identity', $identity->identity_uuid, $updated_by, summary: $status->value, source: 'admin' );

		return $updated;
	}
}
