<?php
/**
 * Sender identity entity, per Section 23. A sender domain may have multiple identities.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending;

use Alltime\WPPhishing\Sending\Enums\ScenarioClassification;
use Alltime\WPPhishing\Sending\Enums\SenderIdentityStatus;

final class SenderIdentity {

	public function __construct(
		public readonly int $id,
		public readonly string $identity_uuid,
		public readonly int $sender_domain_id,
		public readonly string $display_name,
		public readonly string $local_part,
		public readonly ?string $reply_to,
		public readonly ?ScenarioClassification $scenario_classification,
		public readonly SenderIdentityStatus $status,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			identity_uuid: (string) $row['identity_uuid'],
			sender_domain_id: (int) $row['sender_domain_id'],
			display_name: (string) $row['display_name'],
			local_part: (string) $row['local_part'],
			reply_to: ! empty( $row['reply_to'] ) ? (string) $row['reply_to'] : null,
			scenario_classification: ! empty( $row['scenario_classification'] ) ? ScenarioClassification::from( (string) $row['scenario_classification'] ) : null,
			status: SenderIdentityStatus::from( (string) $row['status'] ),
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
