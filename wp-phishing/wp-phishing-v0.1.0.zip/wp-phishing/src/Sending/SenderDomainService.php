<?php
/**
 * Sender domain service, per Section 22/24.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Sending\Enums\SenderDeliveryMode;
use Alltime\WPPhishing\Sending\Repositories\SenderDomainRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class SenderDomainService {

	public function __construct(
		private readonly SenderDomainRepository $domains = new SenderDomainRepository(),
		private readonly SenderHealthService $health = new SenderHealthService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return SenderDomain[]
	 */
	public function list_all( int $per_page = 50, int $page = 1 ): array {
		return $this->domains->find_all( $per_page, $page );
	}

	/**
	 * @return SenderDomain[]
	 */
	public function list_available_for_organisation( string $organisation_uuid ): array {
		return $this->domains->find_available_for_organisation( $organisation_uuid );
	}

	public function get( string $domain_uuid ): ?SenderDomain {
		return $this->domains->find_by_uuid( $domain_uuid );
	}

	public function create(
		string $domain,
		?string $organisation_uuid = null,
		?MailProviderId $mail_provider = null,
		?string $tracking_domain = null,
		?string $landing_domain = null,
		?int $created_by = null,
		SenderDeliveryMode $delivery_mode = SenderDeliveryMode::ApiSend
	): SenderDomain {
		// A mailbox-injection domain has no real DNS to control - it only makes sense bound to
		// one organisation's own tenant integration, never the shared pool.
		if ( SenderDeliveryMode::MailboxInjection === $delivery_mode && null === $organisation_uuid ) {
			throw new \InvalidArgumentException( esc_html__( 'A mailbox-injection sender domain must belong to a specific organisation.', 'wp-phishing' ) );
		}

		$sender_domain = $this->domains->create( $domain, $organisation_uuid, $mail_provider, $tracking_domain, $landing_domain, $delivery_mode );

		$this->audit_logger->log( 'sender_domain.created', 'sender_domain', $sender_domain->domain_uuid, $created_by, summary: $domain, source: 'admin', organisation_uuid: $organisation_uuid );

		return $sender_domain;
	}

	/**
	 * Runs and persists a fresh health check (Section 24) - the customer/admin "check now"
	 * action, and the background sweep's per-domain unit of work.
	 */
	public function check_health( SenderDomain $domain, ?int $checked_by = null ): SenderDomain {
		$updated = $this->health->check( $domain );

		$this->audit_logger->log(
			'sender_domain.health_checked',
			'sender_domain',
			$domain->domain_uuid,
			$checked_by,
			summary: $updated->health_status->value,
			source: null !== $checked_by ? 'admin' : 'cron',
			organisation_uuid: $domain->organisation_uuid
		);

		return $updated;
	}

	public function retire( SenderDomain $domain, ?int $retired_by = null ): SenderDomain {
		$updated = $this->domains->retire( $domain->id );

		$this->audit_logger->log( 'sender_domain.retired', 'sender_domain', $domain->domain_uuid, $retired_by, source: 'admin', organisation_uuid: $domain->organisation_uuid );

		return $updated;
	}
}
