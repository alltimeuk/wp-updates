<?php
/**
 * Schedules the recurring delivery-queue and sender-domain health-check sweeps, per Section
 * 24/26/27. Two separate intervals - the delivery queue needs to drain promptly, sender-domain
 * health does not need checking anywhere near as often.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending;

use Alltime\WPPhishing\Delivery\DeliveryQueueService;
use Alltime\WPPhishing\Sending\Repositories\SenderDomainRepository;

final class SendingBootstrap {

	public const RUN_DELIVERY_QUEUE_HOOK = 'wpp_run_delivery_queue';
	public const RUN_HEALTH_CHECK_HOOK   = 'wpp_run_sender_health_check';

	private const DELIVERY_INTERVAL_SLUG = 'wpp_two_minutes';
	private const HEALTH_INTERVAL_SLUG   = 'wpp_hourly';

	public function boot(): void {
		add_filter( 'cron_schedules', array( $this, 'register_intervals' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 2 minutes for the delivery queue is intentional: a queued simulation message should go out promptly, not wait for an hourly tick.

		add_action( self::RUN_DELIVERY_QUEUE_HOOK, array( $this, 'run_delivery_queue' ) );
		add_action( self::RUN_HEALTH_CHECK_HOOK, array( $this, 'run_health_checks' ) );
		add_action( 'init', array( $this, 'ensure_scheduled' ) );
	}

	/**
	 * @param array<string,array{interval:int,display:string}> $schedules
	 *
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function register_intervals( array $schedules ): array {
		$schedules[ self::DELIVERY_INTERVAL_SLUG ] = array(
			'interval' => 2 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 2 minutes (WP-Phishing delivery queue)', 'wp-phishing' ),
		);

		$schedules[ self::HEALTH_INTERVAL_SLUG ] = array(
			'interval' => HOUR_IN_SECONDS,
			'display'  => __( 'Hourly (WP-Phishing sender domain health)', 'wp-phishing' ),
		);

		return $schedules;
	}

	public function ensure_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_DELIVERY_QUEUE_HOOK ) ) {
			wp_schedule_event( time(), self::DELIVERY_INTERVAL_SLUG, self::RUN_DELIVERY_QUEUE_HOOK );
		}

		if ( false === wp_next_scheduled( self::RUN_HEALTH_CHECK_HOOK ) ) {
			wp_schedule_event( time(), self::HEALTH_INTERVAL_SLUG, self::RUN_HEALTH_CHECK_HOOK );
		}
	}

	public function run_delivery_queue(): void {
		( new DeliveryQueueService() )->process_batch();
	}

	public function run_health_checks(): void {
		$service = new SenderDomainService();

		foreach ( ( new SenderDomainRepository() )->find_all( 100, 1 ) as $domain ) {
			$service->check_health( $domain );
		}
	}
}
