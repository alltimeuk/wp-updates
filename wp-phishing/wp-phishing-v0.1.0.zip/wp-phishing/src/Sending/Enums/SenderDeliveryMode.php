<?php
/**
 * How a sender domain actually gets a message to a recipient, per the "Multi-provider delivery
 * modes" plan addition.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending\Enums;

enum SenderDeliveryMode: string {
	/** Real SMTP/API transport through an Alltime-controlled, SPF/DKIM/DMARC-authenticated domain. */
	case ApiSend = 'api_send';
	/**
	 * Writes directly into the recipient's own mailbox on the customer's tenant - no real
	 * transport exists to authenticate, so SPF/DKIM/DMARC/MX health checks do not apply; readiness
	 * instead depends on the organisation holding an active mail integration for the matching
	 * provider (see {@see \Alltime\WPPhishing\Sending\SenderHealthService}).
	 */
	case MailboxInjection = 'mailbox_injection';
}
