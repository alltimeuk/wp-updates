<?php
/**
 * Health status for a sender domain's DNS/SPF/DKIM/DMARC/TLS checks and their overall roll-up,
 * per Section 24. `Unknown` is the default until a check has actually run - never conflated with
 * `Unhealthy`, since campaign preflight (Section 24/70) must fail closed on "never checked", not
 * silently treat it as passing or as a confirmed failure.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending\Enums;

enum HealthStatus: string {
	case Unknown   = 'unknown';
	case Healthy   = 'healthy';
	case Degraded  = 'degraded';
	case Unhealthy = 'unhealthy';
}
