<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending\Enums;

enum SenderIdentityStatus: string {
	case Active   = 'active';
	case Disabled = 'disabled';
}
