<?php
/**
 * Sender identity scenario classification, per Section 23.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending\Enums;

enum ScenarioClassification: string {
	case InternalLooking     = 'internal-looking';
	case Supplier            = 'supplier';
	case DocumentSharing     = 'document-sharing';
	case Authentication      = 'authentication';
	case Finance             = 'finance';
	case Hr                  = 'HR';
	case Executive           = 'executive';
	case ServiceNotification = 'service-notification';
}
