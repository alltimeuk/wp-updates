<?php
/**
 * Sender domain lifecycle status, per Section 22.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Sending\Enums;

enum SenderDomainStatus: string {
	case Active  = 'active';
	case Retired = 'retired';
}
