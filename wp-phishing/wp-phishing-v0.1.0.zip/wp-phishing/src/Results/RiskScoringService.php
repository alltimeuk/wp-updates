<?php
/**
 * Risk scoring, per Section 38. Pure function of a delivery's distinct observed event types and
 * a weight set - never depends on how many times an event repeated, since a weight represents
 * "this kind of thing happened", not "how often".
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Results;

use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;

final class RiskScoringService {

	/**
	 * @param TrackingEventType[] $event_types Distinct event types observed for one delivery.
	 */
	public function score( array $event_types, RiskWeightSet $weight_set ): int {
		$score = 0;

		foreach ( $event_types as $event_type ) {
			$score += $weight_set->weight_for( $event_type->value );
		}

		return $score;
	}

	/**
	 * @param CampaignResult[] $results
	 */
	public function average_score( array $results ): float {
		$measurable = array_values( array_filter( $results, static fn ( CampaignResult $r ): bool => $r->is_measurable() ) );

		if ( array() === $measurable ) {
			return 0.0;
		}

		$total = array_sum( array_map( static fn ( CampaignResult $r ): int => $r->risk_score, $measurable ) );

		return $total / count( $measurable );
	}
}
