<?php
/**
 * Computes campaign results and their aggregations, per Section 37-39. Every method here reads
 * from already-persisted, immutable-in-practice sources (the frozen cohort snapshot, deliveries,
 * append-only tracking events) and returns a fresh computation - nothing here is itself stored.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Results;

use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\CampaignWave;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignWaveRepository;
use Alltime\WPPhishing\Delivery\Delivery;
use Alltime\WPPhishing\Delivery\Enums\DeliveryStatus;
use Alltime\WPPhishing\Delivery\Repositories\DeliveryRepository;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;
use Alltime\WPPhishing\Tracking\Repositories\TrackingEventRepository;
use Alltime\WPPhishing\Tracking\TrackingEvent;

final class ResultsService {

	public function __construct(
		private readonly CampaignWaveRepository $waves = new CampaignWaveRepository(),
		private readonly DeliveryRepository $deliveries = new DeliveryRepository(),
		private readonly TrackingEventRepository $events = new TrackingEventRepository(),
		private readonly RiskScoringService $scoring = new RiskScoringService()
	) {}

	/**
	 * @return CampaignResult[]
	 */
	public function compute_campaign_results( Campaign $campaign, RiskWeightSet $weight_set ): array {
		$results = array();

		foreach ( $this->waves->find_all_for_campaign( $campaign->id ) as $wave ) {
			array_push( $results, ...$this->compute_wave_results( $wave, $weight_set ) );
		}

		return $results;
	}

	/**
	 * Batch-fetches this wave's deliveries and their tracking events (two queries total,
	 * regardless of recipient count) rather than one round-trip per recipient - a campaign report
	 * previously issued `1 + 2N` queries for N recipients, and historical_comparison() then
	 * re-runs this same computation for up to 5 prior campaigns per report generated.
	 *
	 * @return CampaignResult[]
	 */
	public function compute_wave_results( CampaignWave $wave, RiskWeightSet $weight_set ): array {
		$wave_recipients = $this->waves->find_wave_recipients( $wave->id );

		$delivery_ids = array_values( array_unique( array_filter( array_map( static fn ( $wave_recipient ) => $wave_recipient->delivery_id, $wave_recipients ) ) ) );
		$deliveries   = $this->deliveries->find_all_by_ids( $delivery_ids );

		$delivery_uuids     = array_map( static fn ( Delivery $delivery ): string => $delivery->delivery_uuid, $deliveries );
		$events_by_delivery = $this->events->find_for_deliveries( array_values( $delivery_uuids ) );

		$results = array();

		foreach ( $wave_recipients as $wave_recipient ) {
			$status      = null;
			$event_types = array();
			$delivery    = null !== $wave_recipient->delivery_id ? ( $deliveries[ $wave_recipient->delivery_id ] ?? null ) : null;

			if ( null !== $delivery ) {
				$status      = $delivery->status;
				$event_types = $this->distinct_event_types( $events_by_delivery[ $delivery->delivery_uuid ] ?? array() );
			}

			$results[] = new CampaignResult(
				recipient_id: $wave_recipient->recipient_id,
				email: $wave_recipient->email,
				given_name: $wave_recipient->given_name,
				family_name: $wave_recipient->family_name,
				department: $wave_recipient->department,
				team: $wave_recipient->team,
				location: $wave_recipient->location,
				job_title: $wave_recipient->job_title,
				delivery_status: $status,
				event_types: $event_types,
				risk_score: $this->scoring->score( $event_types, $weight_set )
			);
		}

		return $results;
	}

	/**
	 * Section 36: targeted/attempted/accepted/delivered/measurable.
	 *
	 * @param CampaignResult[] $results
	 *
	 * @return array{targeted:int,attempted:int,accepted:int,delivered:int,measurable:int}
	 */
	public function delivery_statistics( array $results ): array {
		$not_attempted = array( DeliveryStatus::Queued, DeliveryStatus::Suppressed, DeliveryStatus::Cancelled, DeliveryStatus::Planned, DeliveryStatus::Reserved, DeliveryStatus::Sending );

		return array(
			'targeted'   => count( $results ),
			'attempted'  => count( array_filter( $results, static fn ( CampaignResult $r ): bool => null !== $r->delivery_status && ! in_array( $r->delivery_status, $not_attempted, true ) ) ),
			'accepted'   => count( array_filter( $results, static fn ( CampaignResult $r ): bool => $r->is_measurable() ) ),
			'delivered'  => count( array_filter( $results, static fn ( CampaignResult $r ): bool => DeliveryStatus::Delivered === $r->delivery_status ) ),
			'measurable' => count( array_filter( $results, static fn ( CampaignResult $r ): bool => $r->is_measurable() ) ),
		);
	}

	/**
	 * Aggregate counts of each observed event type across the campaign (Section 37).
	 *
	 * @param CampaignResult[] $results
	 *
	 * @return array<string,int>
	 */
	public function behavioural_results( array $results ): array {
		$counts = array();

		foreach ( TrackingEventType::cases() as $type ) {
			$counts[ $type->value ] = 0;
		}

		foreach ( $results as $result ) {
			foreach ( $result->event_types as $event_type ) {
				++$counts[ $event_type->value ];
			}
		}

		return $counts;
	}

	/**
	 * Groups measurable results by one recipient dimension (department/team/location/job_title -
	 * Section 39, restricted to dimensions available from a single campaign's own cohort
	 * snapshot; cross-campaign/time-period dimensions belong to longitudinal reporting, Section
	 * 41, which is Phase 2 per Section 77).
	 *
	 * @param CampaignResult[] $results
	 *
	 * @return array<int,array{label:string,count:int,click_rate:float,credential_rate:float,average_risk_score:float}>
	 */
	public function cohort_breakdown( array $results, string $dimension ): array {
		$groups = array();

		foreach ( $results as $result ) {
			if ( ! $result->is_measurable() ) {
				continue;
			}

			$label = match ( $dimension ) {
				'department' => $result->department,
				'team' => $result->team,
				'location' => $result->location,
				'job_title' => $result->job_title,
				default => null,
			} ?? __( 'Unspecified', 'wp-phishing' );

			$groups[ $label ][] = $result;
		}

		$breakdown = array();

		foreach ( $groups as $label => $group_results ) {
			$count = count( $group_results );

			$breakdown[] = array(
				'label'              => $label,
				'count'              => $count,
				'click_rate'         => $this->rate( $group_results, TrackingEventType::LinkClicked ),
				'credential_rate'    => $this->rate( $group_results, TrackingEventType::CredentialSubmissionAttempted ),
				'average_risk_score' => $this->scoring->average_score( $group_results ),
			);
		}

		return $breakdown;
	}

	/**
	 * @param CampaignResult[] $results
	 */
	private function rate( array $results, TrackingEventType $type ): float {
		if ( array() === $results ) {
			return 0.0;
		}

		return count( array_filter( $results, static fn ( CampaignResult $r ): bool => $r->has_event( $type ) ) ) / count( $results );
	}

	/**
	 * @param TrackingEvent[] $events
	 *
	 * @return TrackingEventType[]
	 */
	private function distinct_event_types( array $events ): array {
		$types = array();

		foreach ( $events as $event ) {
			$types[ $event->event_type->value ] = $event->event_type;
		}

		return array_values( $types );
	}
}
