<?php
/**
 * A named, immutable risk-weighting configuration, per Section 38: "Weights shall be
 * configurable, versioned, retained with each report." There is no "edit" - a change creates a
 * new set, so a report's reference to one stays permanently meaningful.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Results;

use Alltime\WPPhishing\Support\Dates;

final class RiskWeightSet {

	public function __construct(
		public readonly int $id,
		public readonly string $weight_set_uuid,
		public readonly string $name,
		/** @var array<string,int> Tracking\Enums\TrackingEventType value => weight. */
		public readonly array $weights,
		public readonly bool $is_default,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * The weight for a given event type, or 0 if this set does not mention it - an event type
	 * absent from the map (e.g. one added to {@see \Alltime\WPPhishing\Tracking\Enums\TrackingEventType}
	 * after this set was created) carries no risk weight rather than failing.
	 */
	public function weight_for( string $event_type_value ): int {
		return (int) ( $this->weights[ $event_type_value ] ?? 0 );
	}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$weights = json_decode( (string) $row['weights'], true );

		return new self(
			id: (int) $row['id'],
			weight_set_uuid: (string) $row['weight_set_uuid'],
			name: (string) $row['name'],
			weights: is_array( $weights ) ? $weights : array(),
			is_default: (bool) $row['is_default'],
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: Dates::from_mysql( (string) $row['created_at'] )
		);
	}
}
