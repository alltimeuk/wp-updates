<?php
/**
 * One recipient's evidence within a campaign wave, per Section 37: never reduced to a single
 * pass/fail field - the full set of observed event types is retained alongside the computed
 * risk score, computed fresh from {@see \Alltime\WPPhishing\Campaigns\CampaignWaveRecipient},
 * its {@see \Alltime\WPPhishing\Delivery\Delivery} and its {@see \Alltime\WPPhishing\Tracking\TrackingEvent}s
 * - never persisted as its own row.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Results;

use Alltime\WPPhishing\Delivery\Enums\DeliveryStatus;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;

final class CampaignResult {

	/**
	 * @param TrackingEventType[] $event_types Distinct event types observed for this delivery.
	 */
	public function __construct(
		public readonly int $recipient_id,
		public readonly string $email,
		public readonly ?string $given_name,
		public readonly ?string $family_name,
		public readonly ?string $department,
		public readonly ?string $team,
		public readonly ?string $location,
		public readonly ?string $job_title,
		public readonly ?DeliveryStatus $delivery_status,
		public readonly array $event_types,
		public readonly int $risk_score
	) {}

	public function has_event( TrackingEventType $type ): bool {
		return in_array( $type, $this->event_types, true );
	}

	/**
	 * Section 36: a message never successfully accepted by the provider was never delivered, so
	 * it must not be treated as having failed (or passed) the simulation.
	 */
	public function is_measurable(): bool {
		return null !== $this->delivery_status && in_array( $this->delivery_status, array( DeliveryStatus::Accepted, DeliveryStatus::Delivered ), true );
	}
}
