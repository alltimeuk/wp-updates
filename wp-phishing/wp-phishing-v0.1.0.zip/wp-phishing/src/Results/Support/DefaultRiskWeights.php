<?php
/**
 * Seeds the default risk weight set from Section 38's own example weighting, so report
 * generation works on a fresh install without a separate manual setup step.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Results\Support;

use Alltime\WPPhishing\Results\Repositories\RiskWeightSetRepository;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;

final class DefaultRiskWeights {

	/**
	 * @return array<string,int>
	 */
	public static function example_weights(): array {
		return array(
			TrackingEventType::MessageAccepted->value     => 0,
			TrackingEventType::MessageOpenObserved->value => 0,
			TrackingEventType::LinkClicked->value         => 2,
			TrackingEventType::LandingViewed->value       => 3,
			TrackingEventType::CredentialSubmissionAttempted->value => 5,
			TrackingEventType::SimulationReported->value  => -2,
		);
	}

	/**
	 * Idempotent: only inserts the seed set when no risk weight set exists at all, so this is
	 * safe to call on every migration run without ever overriding an administrator's own
	 * configuration.
	 */
	public static function ensure_seeded(): void {
		$repository = new RiskWeightSetRepository();

		if ( $repository->exists_any() ) {
			return;
		}

		$repository->create( __( 'Default weighting', 'wp-phishing' ), self::example_weights(), true, null );
	}
}
