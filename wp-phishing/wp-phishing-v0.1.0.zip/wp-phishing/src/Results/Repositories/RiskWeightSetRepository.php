<?php
/**
 * Persistence for risk weight sets, against `wpp_risk_weight_sets`, per Section 38.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Results\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Results\RiskWeightSet;

final class RiskWeightSetRepository {

	public function find( int $id ): ?RiskWeightSet {
		global $wpdb;

		$table = Schema::table( 'risk_weight_sets' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? RiskWeightSet::from_row( $row ) : null;
	}

	public function find_by_uuid( string $weight_set_uuid ): ?RiskWeightSet {
		global $wpdb;

		$table = Schema::table( 'risk_weight_sets' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE weight_set_uuid = %s", $weight_set_uuid ), ARRAY_A );

		return null !== $row ? RiskWeightSet::from_row( $row ) : null;
	}

	public function find_default(): ?RiskWeightSet {
		global $wpdb;

		$table = Schema::table( 'risk_weight_sets' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input; the rest of this query is a fixed literal with no dynamic values, so $wpdb->prepare() has nothing to bind.
		$row = $wpdb->get_row( "SELECT * FROM `{$table}` WHERE is_default = 1 ORDER BY id DESC LIMIT 1", ARRAY_A );

		return null !== $row ? RiskWeightSet::from_row( $row ) : null;
	}

	/**
	 * @return RiskWeightSet[]
	 */
	public function find_all(): array {
		global $wpdb;

		$table = Schema::table( 'risk_weight_sets' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( "SELECT * FROM `{$table}` ORDER BY id DESC", ARRAY_A );

		return array_map( array( RiskWeightSet::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function exists_any(): bool {
		global $wpdb;

		$table = Schema::table( 'risk_weight_sets' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return 0 < (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
	}

	/**
	 * @param array<string,int> $weights
	 */
	public function create( string $name, array $weights, bool $is_default, ?int $created_by ): RiskWeightSet {
		global $wpdb;

		$table        = Schema::table( 'risk_weight_sets' );
		$weights_json = wp_json_encode( $weights );

		if ( false === $weights_json ) {
			throw new \RuntimeException( esc_html__( 'Risk weights could not be encoded.', 'wp-phishing' ) );
		}

		$data = array(
			'weight_set_uuid' => wp_generate_uuid4(),
			'name'            => $name,
			'weights'         => $weights_json,
			'is_default'      => $is_default ? 1 : 0,
			'created_by'      => $created_by,
			'created_at'      => current_time( 'mysql', true ),
		);

		if ( ! $is_default ) {
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			return $this->find_or_fail( (int) $wpdb->insert_id );
		}

		// Clearing the previous default and inserting the new one must be atomic: two concurrent
		// "make this the default" submissions must never both clear before either inserts (leaving
		// two rows marked default), nor leave zero default rows if the insert fails after the clear
		// succeeds - the latter breaks ReportService::generate() for every subsequent call until an
		// operator manually creates a new one.
		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $table, array( 'is_default' => 0 ), array( 'is_default' => 1 ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$insert_id = (int) $wpdb->insert_id;

		if ( 0 === $insert_id ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			throw new \RuntimeException( esc_html__( 'The new default risk weight set could not be created.', 'wp-phishing' ) );
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $insert_id );
	}

	private function find_or_fail( int $id ): RiskWeightSet {
		$weight_set = $this->find( $id );

		if ( null === $weight_set ) {
			throw new \RuntimeException( esc_html( "Risk weight set {$id} was expected to exist but could not be loaded." ) );
		}

		return $weight_set;
	}
}
