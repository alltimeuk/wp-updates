<?php
/**
 * Simple, threshold-based remediation recommendations, per Section 43. Deliberately not a
 * scoring model of its own - every rule reads directly from {@see ResultsService}'s already-
 * computed aggregates, and every recommendation is phrased around what the evidence showed
 * (Section 42: avoid pejorative labels - these describe organisational risk, never individuals).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Results;

use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;

final class RecommendationEngine {

	private const ELEVATED_CLICK_RATE                     = 0.15;
	private const LOW_REPORTING_RATE                      = 0.05;
	private const MINIMUM_COHORT_SIZE                     = 3;
	private const MINIMUM_MEASURABLE_FOR_REPORTING_SIGNAL = 5;

	/**
	 * @param array<string,int>                                                                          $behavioural_results
	 * @param array{targeted:int,attempted:int,accepted:int,delivered:int,measurable:int}                 $delivery_statistics
	 * @param array<int,array{label:string,count:int,click_rate:float,credential_rate:float,average_risk_score:float}> $department_breakdown
	 *
	 * @return string[]
	 */
	public function generate( array $behavioural_results, array $delivery_statistics, array $department_breakdown ): array {
		$measurable = $delivery_statistics['measurable'];

		if ( 0 === $measurable ) {
			return array();
		}

		$recommendations  = array();
		$click_rate       = $behavioural_results[ TrackingEventType::LinkClicked->value ] / $measurable;
		$credential_count = $behavioural_results[ TrackingEventType::CredentialSubmissionAttempted->value ];
		$reported_count   = $behavioural_results[ TrackingEventType::SimulationReported->value ];

		if ( $credential_count > 0 ) {
			$recommendations[] = __( 'Review Microsoft 365 (or equivalent) impersonation protection - at least one recipient attempted a simulated credential submission.', 'wp-phishing' );
			$recommendations[] = __( 'Review anti-phishing policy and email security configuration.', 'wp-phishing' );
		}

		if ( $click_rate > self::ELEVATED_CLICK_RATE ) {
			$recommendations[] = sprintf(
				/* translators: %d: click rate as a whole-number percentage */
				__( 'Increase phishing-awareness training frequency - the confirmed click rate (%d%%) is above the organisation-wide benchmark this product tracks.', 'wp-phishing' ),
				(int) round( $click_rate * 100 )
			);
		}

		if ( $measurable >= self::MINIMUM_MEASURABLE_FOR_REPORTING_SIGNAL && ( $reported_count / $measurable ) < self::LOW_REPORTING_RATE ) {
			$recommendations[] = __( 'Improve suspicious-message reporting: reinforce how and where employees should report a suspected phishing message.', 'wp-phishing' );
		}

		$highest_risk_cohort = $this->highest_risk_cohort( $department_breakdown );

		if ( null !== $highest_risk_cohort ) {
			$recommendations[] = sprintf(
				/* translators: %s: department/cohort name */
				__( 'Consider targeted awareness training for %s, which showed the highest susceptibility of any department in this campaign.', 'wp-phishing' ),
				$highest_risk_cohort['label']
			);
		}

		return $recommendations;
	}

	/**
	 * @param array<int,array{label:string,count:int,click_rate:float,credential_rate:float,average_risk_score:float}> $department_breakdown
	 *
	 * @return array{label:string,count:int,click_rate:float,credential_rate:float,average_risk_score:float}|null
	 */
	private function highest_risk_cohort( array $department_breakdown ): ?array {
		$eligible = array_values( array_filter( $department_breakdown, static fn ( array $c ): bool => $c['count'] >= self::MINIMUM_COHORT_SIZE && $c['average_risk_score'] > 0 ) );

		if ( array() === $eligible ) {
			return null;
		}

		usort( $eligible, static fn ( array $a, array $b ): int => $b['average_risk_score'] <=> $a['average_risk_score'] );

		return $eligible[0];
	}
}
