<?php
/**
 * Campaign entity, per Section 18.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

use Alltime\WPPhishing\Campaigns\Enums\ApprovalModel;
use Alltime\WPPhishing\Campaigns\Enums\CampaignStatus;
use Alltime\WPPhishing\Campaigns\Enums\HaloSyncStatus;
use Alltime\WPPhishing\Campaigns\Enums\ScheduleMode;

final class Campaign {

	public function __construct(
		public readonly int $id,
		public readonly string $campaign_uuid,
		public readonly string $organisation_uuid,
		public readonly string $name,
		public readonly ?string $description,
		public readonly ?string $campaign_type,
		public readonly CampaignStatus $status,
		public readonly ?string $objective,
		public readonly ApprovalModel $approval_model,
		public readonly ScheduleMode $schedule_mode,
		public readonly ?string $timezone,
		public readonly ?\DateTimeImmutable $starts_at,
		public readonly ?\DateTimeImmutable $ends_at,
		public readonly int $expected_recipient_count,
		public readonly int $expected_message_count,
		public readonly ?int $created_by,
		public readonly ?int $approved_by,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at,
		public readonly ?\DateTimeImmutable $approved_at,
		public readonly ?\DateTimeImmutable $closed_at,
		public readonly HaloSyncStatus $halo_sync_status,
		public readonly ?\DateTimeImmutable $halo_synced_at,
		public readonly ?\DateTimeImmutable $halo_last_attempted_at,
		public readonly int $halo_retry_count,
		public readonly ?string $halo_sync_error
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			campaign_uuid: (string) $row['campaign_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			name: (string) $row['name'],
			description: ! empty( $row['description'] ) ? (string) $row['description'] : null,
			campaign_type: ! empty( $row['campaign_type'] ) ? (string) $row['campaign_type'] : null,
			status: CampaignStatus::from( (string) $row['status'] ),
			objective: ! empty( $row['objective'] ) ? (string) $row['objective'] : null,
			approval_model: ApprovalModel::from( (string) $row['approval_model'] ),
			schedule_mode: ScheduleMode::from( (string) $row['schedule_mode'] ),
			timezone: ! empty( $row['timezone'] ) ? (string) $row['timezone'] : null,
			starts_at: ! empty( $row['starts_at'] ) ? new \DateTimeImmutable( (string) $row['starts_at'] ) : null,
			ends_at: ! empty( $row['ends_at'] ) ? new \DateTimeImmutable( (string) $row['ends_at'] ) : null,
			expected_recipient_count: (int) $row['expected_recipient_count'],
			expected_message_count: (int) $row['expected_message_count'],
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			approved_by: ! empty( $row['approved_by'] ) ? (int) $row['approved_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] ),
			approved_at: ! empty( $row['approved_at'] ) ? new \DateTimeImmutable( (string) $row['approved_at'] ) : null,
			closed_at: ! empty( $row['closed_at'] ) ? new \DateTimeImmutable( (string) $row['closed_at'] ) : null,
			halo_sync_status: HaloSyncStatus::from( (string) ( $row['halo_sync_status'] ?? HaloSyncStatus::Pending->value ) ),
			halo_synced_at: ! empty( $row['halo_synced_at'] ) ? new \DateTimeImmutable( (string) $row['halo_synced_at'] ) : null,
			halo_last_attempted_at: ! empty( $row['halo_last_attempted_at'] ) ? new \DateTimeImmutable( (string) $row['halo_last_attempted_at'] ) : null,
			halo_retry_count: (int) ( $row['halo_retry_count'] ?? 0 ),
			halo_sync_error: ! empty( $row['halo_sync_error'] ) ? (string) $row['halo_sync_error'] : null
		);
	}
}
