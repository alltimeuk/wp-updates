<?php
/**
 * Campaign and wave creation/listing, per Section 18/19.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

use Alltime\WPPhishing\Campaigns\Enums\ApprovalModel;
use Alltime\WPPhishing\Campaigns\Enums\CampaignStatus;
use Alltime\WPPhishing\Campaigns\Enums\ScheduleMode;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignWaveRepository;
use Alltime\WPPhishing\Delivery\Repositories\DeliveryRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientGroupRepository;
use Alltime\WPPhishing\Sending\Repositories\SenderIdentityRepository;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Templates\Repositories\TemplateRepository;

final class CampaignService {

	public function __construct(
		private readonly CampaignRepository $campaigns = new CampaignRepository(),
		private readonly CampaignWaveRepository $waves = new CampaignWaveRepository(),
		private readonly TemplateRepository $templates = new TemplateRepository(),
		private readonly SenderIdentityRepository $sender_identities = new SenderIdentityRepository(),
		private readonly RecipientGroupRepository $recipient_groups = new RecipientGroupRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly DeliveryRepository $deliveries = new DeliveryRepository()
	) {}

	/**
	 * @return Campaign[]
	 */
	public function list_for_organisation( string $organisation_uuid ): array {
		return $this->campaigns->find_all_for_organisation( $organisation_uuid );
	}

	public function get( string $organisation_uuid, string $campaign_uuid ): ?Campaign {
		return $this->campaigns->find_by_uuid( $organisation_uuid, $campaign_uuid );
	}

	/**
	 * @return CampaignWave[]
	 */
	public function list_waves( Campaign $campaign ): array {
		return $this->waves->find_all_for_campaign( $campaign->id );
	}

	public function create(
		string $organisation_uuid,
		string $name,
		?string $description,
		?string $campaign_type,
		?string $objective,
		ApprovalModel $approval_model,
		ScheduleMode $schedule_mode,
		?string $timezone,
		?\DateTimeImmutable $starts_at,
		?\DateTimeImmutable $ends_at,
		?int $created_by = null,
		bool $created_by_operator = false
	): Campaign {
		if ( '' === trim( $name ) ) {
			throw new \InvalidArgumentException( esc_html__( 'A campaign name is required.', 'wp-phishing' ) );
		}

		if ( ScheduleMode::Immediate !== $schedule_mode && null === $starts_at ) {
			throw new \InvalidArgumentException( esc_html__( 'A start date/time is required for a scheduled or windowed campaign.', 'wp-phishing' ) );
		}

		// Section 21: managed_service_only means "no customer self-service" - a customer cannot
		// grant themselves that approval model on their own campaign.
		if ( ApprovalModel::ManagedServiceOnly === $approval_model && ! $created_by_operator ) {
			throw new \InvalidArgumentException( esc_html__( 'Only an Alltime operator may create a managed-service-only campaign.', 'wp-phishing' ) );
		}

		$campaign = $this->campaigns->create( $organisation_uuid, $name, $description, $campaign_type, $objective, $approval_model, $schedule_mode, $timezone, $starts_at, $ends_at, $created_by );

		$this->audit_logger->log( 'campaign.created', 'campaign', $campaign->campaign_uuid, $created_by, summary: $name, organisation_uuid: $organisation_uuid );

		return $campaign;
	}

	/**
	 * Adds a single wave to a still-draft campaign - single-wave only this phase (MVP #11);
	 * calling this twice on the same campaign is rejected rather than silently supported, since
	 * multi-wave orchestration (activation ordering across waves, combined completion) does not
	 * exist yet (Section 77).
	 */
	public function create_wave(
		Campaign $campaign,
		string $name,
		int $template_version_id,
		int $sender_identity_id,
		?int $landing_page_version_id,
		int $recipient_group_id,
		?\DateTimeImmutable $delivery_window_starts_at,
		?\DateTimeImmutable $delivery_window_ends_at,
		?int $created_by = null
	): CampaignWave {
		if ( CampaignStatus::Draft !== $campaign->status ) {
			throw new \InvalidArgumentException( esc_html__( 'Waves can only be added to a draft campaign.', 'wp-phishing' ) );
		}

		if ( array() !== $this->waves->find_all_for_campaign( $campaign->id ) ) {
			throw new \InvalidArgumentException( esc_html__( 'This campaign already has a wave; multi-wave campaigns are not yet supported.', 'wp-phishing' ) );
		}

		$template_version = $this->templates->find_version( $template_version_id );

		if ( null === $template_version ) {
			throw new \InvalidArgumentException( esc_html__( 'The selected template version was not found.', 'wp-phishing' ) );
		}

		if ( null === $this->sender_identities->find( $sender_identity_id ) ) {
			throw new \InvalidArgumentException( esc_html__( 'The selected sender identity was not found.', 'wp-phishing' ) );
		}

		$group = $this->recipient_groups->find( $recipient_group_id );

		if ( null === $group || $group->organisation_uuid !== $campaign->organisation_uuid ) {
			throw new \InvalidArgumentException( esc_html__( 'The selected recipient group was not found for this organisation.', 'wp-phishing' ) );
		}

		if ( 0 === $this->recipient_groups->count_members( $group->id ) ) {
			throw new \InvalidArgumentException( esc_html__( 'The selected recipient group has no members.', 'wp-phishing' ) );
		}

		$wave = $this->waves->create( $campaign->id, $name, $template_version->id, $sender_identity_id, $landing_page_version_id, $recipient_group_id, $delivery_window_starts_at, $delivery_window_ends_at );

		$this->campaigns->set_expected_counts( $campaign->id, $this->recipient_groups->count_members( $group->id ), $this->recipient_groups->count_members( $group->id ) );

		$this->audit_logger->log( 'campaign.wave_created', 'campaign', $campaign->campaign_uuid, $created_by, summary: $name, organisation_uuid: $campaign->organisation_uuid );

		return $wave;
	}

	/**
	 * Cancels the campaign and every one of its waves' still-unsent deliveries (Section 72: "when
	 * cancelled, unsent deliveries become cancelled; already-delivered evidence remains").
	 */
	public function cancel( Campaign $campaign, ?int $cancelled_by = null ): Campaign {
		if ( in_array( $campaign->status, array( CampaignStatus::Completed, CampaignStatus::Cancelled ), true ) ) {
			throw new \InvalidArgumentException( esc_html__( 'This campaign has already reached a final state.', 'wp-phishing' ) );
		}

		$updated = $this->campaigns->mark_cancelled( $campaign->id );

		foreach ( $this->waves->find_all_for_campaign( $campaign->id ) as $wave ) {
			foreach ( $this->deliveries->find_unsent_by_source_object( 'campaign_wave', $wave->wave_uuid ) as $delivery ) {
				$this->deliveries->mark_cancelled( $delivery->id );
			}
		}

		$this->audit_logger->log( 'campaign.cancelled', 'campaign', $campaign->campaign_uuid, $cancelled_by, source: 'admin', organisation_uuid: $campaign->organisation_uuid );

		return $updated;
	}

	/**
	 * Section 71's global kill switch, applied to one campaign - pause stops new sends without
	 * touching already-queued evidence or tracking (Section 72: "already-delivered campaign
	 * interactions may continue to be tracked"), unlike {@see cancel()} which is permanent.
	 */
	public function pause( Campaign $campaign ): Campaign {
		$updated = $this->campaigns->mark_paused( $campaign->id );

		$this->audit_logger->log( 'campaign.paused', 'campaign', $campaign->campaign_uuid, null, source: 'system', organisation_uuid: $campaign->organisation_uuid );

		return $updated;
	}

	public function resume( Campaign $campaign ): Campaign {
		$updated = $this->campaigns->mark_running( $campaign->id );

		$this->audit_logger->log( 'campaign.resumed', 'campaign', $campaign->campaign_uuid, null, source: 'system', organisation_uuid: $campaign->organisation_uuid );

		return $updated;
	}
}
