<?php
/**
 * Persistence for campaign waves and their frozen recipient cohort, against
 * `wpp_campaign_waves` and `wpp_campaign_wave_recipients`, per Section 16/19/20.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Repositories;

use Alltime\WPPhishing\Campaigns\CampaignWave;
use Alltime\WPPhishing\Campaigns\CampaignWaveRecipient;
use Alltime\WPPhishing\Campaigns\Enums\WaveStatus;
use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Delivery\Enums\DeliveryStatus;
use Alltime\WPPhishing\Recipients\Recipient;

final class CampaignWaveRepository {

	public function find( int $id ): ?CampaignWave {
		global $wpdb;

		$table = Schema::table( 'campaign_waves' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? CampaignWave::from_row( $row ) : null;
	}

	public function find_by_uuid( string $wave_uuid ): ?CampaignWave {
		global $wpdb;

		$table = Schema::table( 'campaign_waves' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE wave_uuid = %s", $wave_uuid ), ARRAY_A );

		return null !== $row ? CampaignWave::from_row( $row ) : null;
	}

	/**
	 * @return CampaignWave[]
	 */
	public function find_all_for_campaign( int $campaign_id ): array {
		global $wpdb;

		$table = Schema::table( 'campaign_waves' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE campaign_id = %d ORDER BY id ASC", $campaign_id ), ARRAY_A );

		return array_map( array( CampaignWave::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create(
		int $campaign_id,
		string $name,
		int $template_version_id,
		int $sender_identity_id,
		?int $landing_page_version_id,
		int $recipient_group_id,
		?\DateTimeImmutable $delivery_window_starts_at,
		?\DateTimeImmutable $delivery_window_ends_at
	): CampaignWave {
		global $wpdb;

		$table = Schema::table( 'campaign_waves' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'wave_uuid'                 => wp_generate_uuid4(),
			'campaign_id'               => $campaign_id,
			'name'                      => $name,
			'template_version_id'       => $template_version_id,
			'sender_identity_id'        => $sender_identity_id,
			'landing_page_version_id'   => $landing_page_version_id,
			'recipient_group_id'        => $recipient_group_id,
			'status'                    => WaveStatus::Draft->value,
			'randomisation_policy'      => 'none',
			'delivery_window_starts_at' => $delivery_window_starts_at?->format( 'Y-m-d H:i:s' ),
			'delivery_window_ends_at'   => $delivery_window_ends_at?->format( 'Y-m-d H:i:s' ),
			'created_at'                => $now,
			'updated_at'                => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function mark_status( int $id, WaveStatus $status ): CampaignWave {
		global $wpdb;

		$table = Schema::table( 'campaign_waves' );
		$data  = array(
			'status'     => $status->value,
			'updated_at' => current_time( 'mysql', true ),
		);

		if ( WaveStatus::Activated === $status ) {
			$data['activated_at'] = current_time( 'mysql', true );
		}

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	/**
	 * Freezes one recipient into the wave's cohort snapshot (Section 16/20). Idempotent via the
	 * `wave_recipient` unique key (INSERT IGNORE) - re-running activation after a partial
	 * failure never duplicates an already-frozen entry.
	 */
	public function freeze_recipient( int $wave_id, Recipient $recipient ): void {
		global $wpdb;

		$table = Schema::table( 'campaign_wave_recipients' );

		$data = array(
			'wave_id'      => $wave_id,
			'recipient_id' => $recipient->id,
			'email'        => $recipient->email,
			'email_hash'   => hash( 'sha256', strtolower( $recipient->email ) ),
			'given_name'   => $recipient->given_name,
			'family_name'  => $recipient->family_name,
			'department'   => $recipient->department,
			'team'         => $recipient->team,
			'location'     => $recipient->location,
			'job_title'    => $recipient->job_title,
			'metadata'     => array() !== $recipient->metadata ? wp_json_encode( $recipient->metadata ) : null,
			'created_at'   => current_time( 'mysql', true ),
		);

		$columns      = implode( ', ', array_keys( $data ) );
		$placeholders = implode( ', ', array_fill( 0, count( $data ), '%s' ) );
		$query        = "INSERT IGNORE INTO `{$table}` ({$columns}) VALUES ({$placeholders})";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $query is this method's own fixed, parameterless query text (table/column names only, no user input); phpcs cannot see that statically.
		$wpdb->query( $wpdb->prepare( $query, array_values( $data ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.
	}

	/**
	 * @return CampaignWaveRecipient[]
	 */
	public function find_wave_recipients( int $wave_id ): array {
		global $wpdb;

		$table = Schema::table( 'campaign_wave_recipients' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE wave_id = %d ORDER BY id ASC", $wave_id ), ARRAY_A );

		return array_map( array( CampaignWaveRecipient::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Wave recipients not yet linked to a delivery - what {@see \Alltime\WPPhishing\Campaigns\CampaignActivationService}
	 * still has to enqueue, so re-running activation after a partial failure only does the
	 * remaining work.
	 *
	 * @return CampaignWaveRecipient[]
	 */
	public function find_wave_recipients_without_delivery( int $wave_id ): array {
		global $wpdb;

		$table = Schema::table( 'campaign_wave_recipients' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE wave_id = %d AND delivery_id IS NULL ORDER BY id ASC", $wave_id ), ARRAY_A );

		return array_map( array( CampaignWaveRecipient::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function set_delivery_id( int $wave_recipient_id, int $delivery_id ): void {
		global $wpdb;

		$table = Schema::table( 'campaign_wave_recipients' );

		$wpdb->update( $table, array( 'delivery_id' => $delivery_id ), array( 'id' => $wave_recipient_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * True once every wave recipient either has no delivery at all (activation never reached it -
	 * treated as not-yet-complete, not skipped) or a delivery in a terminal
	 * {@see DeliveryStatus} - the completion sweep's readiness check (Section 21 "campaign
	 * completion").
	 */
	public function all_deliveries_terminal( int $wave_id ): bool {
		global $wpdb;

		$wave_recipients_table = Schema::table( 'campaign_wave_recipients' );
		$deliveries_table      = Schema::table( 'deliveries' );
		$terminal_statuses     = array_map( static fn ( DeliveryStatus $s ): string => $s->value, array_filter( DeliveryStatus::cases(), static fn ( DeliveryStatus $s ): bool => $s->is_terminal() ) );
		$placeholders          = implode( ', ', array_fill( 0, count( $terminal_statuses ), '%s' ) );

		$query = "SELECT COUNT(*) FROM `{$wave_recipients_table}` wr
			LEFT JOIN `{$deliveries_table}` d ON d.id = wr.delivery_id
			WHERE wr.wave_id = %d AND (wr.delivery_id IS NULL OR d.status NOT IN ({$placeholders}))";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table names/status placeholders only, no user input); phpcs cannot see that statically.
		$outstanding = (int) $wpdb->get_var( $wpdb->prepare( $query, array_merge( array( $wave_id ), $terminal_statuses ) ) );

		return 0 === $outstanding;
	}

	private function find_or_fail( int $id ): CampaignWave {
		$wave = $this->find( $id );

		if ( null === $wave ) {
			throw new \RuntimeException( esc_html( "Campaign wave {$id} was expected to exist but could not be loaded." ) );
		}

		return $wave;
	}
}
