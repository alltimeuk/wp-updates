<?php
/**
 * Persistence for campaigns, against `wpp_campaigns`, per Section 18.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Repositories;

use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\Enums\ApprovalModel;
use Alltime\WPPhishing\Campaigns\Enums\CampaignStatus;
use Alltime\WPPhishing\Campaigns\Enums\HaloSyncStatus;
use Alltime\WPPhishing\Campaigns\Enums\ScheduleMode;
use Alltime\WPPhishing\Data\Schema;

final class CampaignRepository {

	public function find( int $id ): ?Campaign {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Campaign::from_row( $row ) : null;
	}

	public function find_by_uuid( string $organisation_uuid, string $campaign_uuid ): ?Campaign {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE campaign_uuid = %s AND organisation_uuid = %s", $campaign_uuid, $organisation_uuid ), ARRAY_A );

		return null !== $row ? Campaign::from_row( $row ) : null;
	}

	/**
	 * @return Campaign[]
	 */
	public function find_all_for_organisation( string $organisation_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY id DESC", $organisation_uuid ), ARRAY_A );

		return array_map( array( Campaign::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Scheduled campaigns whose start has arrived - {@see \Alltime\WPPhishing\Campaigns\CampaignsBootstrap}'s
	 * activation sweep unit of work.
	 *
	 * @return Campaign[]
	 */
	public function find_due_for_activation(): array {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		$query = "SELECT * FROM `{$table}` WHERE status = %s AND starts_at IS NOT NULL AND starts_at <= %s ORDER BY starts_at ASC";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, CampaignStatus::Scheduled->value, current_time( 'mysql', true ) ), ARRAY_A );

		return array_map( array( Campaign::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Running campaigns - {@see \Alltime\WPPhishing\Campaigns\CampaignsBootstrap}'s completion
	 * sweep unit of work.
	 *
	 * @return Campaign[]
	 */
	public function find_running(): array {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE status = %s", CampaignStatus::Running->value ), ARRAY_A );

		return array_map( array( Campaign::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Looks up a campaign by UUID alone, with no organisation scoping - HaloPSA (Section 51) polls
	 * across every organisation's campaigns as Alltime's own PSA integration, unlike the
	 * customer-facing REST API which always scopes by (organisation_uuid, campaign_uuid).
	 */
	public function find_by_campaign_uuid( string $campaign_uuid ): ?Campaign {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE campaign_uuid = %s", $campaign_uuid ), ARRAY_A );

		return null !== $row ? Campaign::from_row( $row ) : null;
	}

	/**
	 * Completed campaigns not yet acknowledged by HaloPSA (Section 51's pull/ack lifecycle) -
	 * only completed campaigns have the final statistical data set Halo is meant to pull.
	 *
	 * @return Campaign[]
	 */
	public function find_pending_for_halo( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		$query = "SELECT * FROM `{$table}` WHERE status = %s AND halo_sync_status IN (%s, %s) ORDER BY closed_at ASC LIMIT %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, CampaignStatus::Completed->value, HaloSyncStatus::Pending->value, HaloSyncStatus::RetryPending->value, $limit ), ARRAY_A );

		return array_map( array( Campaign::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function mark_halo_processing( int $id ): Campaign {
		return $this->update(
			$id,
			array(
				'halo_sync_status'       => HaloSyncStatus::Processing->value,
				'halo_last_attempted_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function mark_halo_synced( int $id ): Campaign {
		return $this->update(
			$id,
			array(
				'halo_sync_status' => HaloSyncStatus::Synced->value,
				'halo_synced_at'   => current_time( 'mysql', true ),
			)
		);
	}

	public function mark_halo_failed( int $id, string $error, bool $retry ): Campaign {
		global $wpdb;

		$table = Schema::table( 'campaigns' );
		$now   = current_time( 'mysql', true );

		$query = "UPDATE `{$table}` SET halo_sync_status = %s, halo_sync_error = %s, halo_retry_count = halo_retry_count + 1, updated_at = %s WHERE id = %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$wpdb->query( $wpdb->prepare( $query, $retry ? HaloSyncStatus::RetryPending->value : HaloSyncStatus::Failed->value, $error, $now, $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.

		return $this->find_or_fail( $id );
	}

	public function create(
		string $organisation_uuid,
		string $name,
		?string $description,
		?string $campaign_type,
		?string $objective,
		ApprovalModel $approval_model,
		ScheduleMode $schedule_mode,
		?string $timezone,
		?\DateTimeImmutable $starts_at,
		?\DateTimeImmutable $ends_at,
		?int $created_by
	): Campaign {
		global $wpdb;

		$table = Schema::table( 'campaigns' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'campaign_uuid'     => wp_generate_uuid4(),
			'organisation_uuid' => $organisation_uuid,
			'name'              => $name,
			'description'       => $description,
			'campaign_type'     => $campaign_type,
			'status'            => CampaignStatus::Draft->value,
			'objective'         => $objective,
			'approval_model'    => $approval_model->value,
			'schedule_mode'     => $schedule_mode->value,
			'timezone'          => $timezone,
			'starts_at'         => $starts_at?->format( 'Y-m-d H:i:s' ),
			'ends_at'           => $ends_at?->format( 'Y-m-d H:i:s' ),
			'created_by'        => $created_by,
			'created_at'        => $now,
			'updated_at'        => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update_status( int $id, CampaignStatus $status ): Campaign {
		return $this->update( $id, array( 'status' => $status->value ) );
	}

	public function mark_awaiting_approval( int $id ): Campaign {
		return $this->update( $id, array( 'status' => CampaignStatus::AwaitingApproval->value ) );
	}

	public function mark_approved( int $id, int $approved_by ): Campaign {
		return $this->update(
			$id,
			array(
				'status'      => CampaignStatus::Approved->value,
				'approved_by' => $approved_by,
				'approved_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function mark_scheduled( int $id, \DateTimeImmutable $starts_at ): Campaign {
		return $this->update(
			$id,
			array(
				'status'    => CampaignStatus::Scheduled->value,
				'starts_at' => $starts_at->format( 'Y-m-d H:i:s' ),
			)
		);
	}

	public function mark_running( int $id ): Campaign {
		return $this->update( $id, array( 'status' => CampaignStatus::Running->value ) );
	}

	public function mark_paused( int $id ): Campaign {
		return $this->update( $id, array( 'status' => CampaignStatus::Paused->value ) );
	}

	/**
	 * Every currently-paused campaign - the basis for resuming all of them at once when the
	 * global emergency pause (Section 71) is lifted.
	 *
	 * @return Campaign[]
	 */
	public function find_paused(): array {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE status = %s", CampaignStatus::Paused->value ), ARRAY_A );

		return array_map( array( Campaign::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function mark_completed( int $id ): Campaign {
		return $this->update(
			$id,
			array(
				'status'    => CampaignStatus::Completed->value,
				'closed_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function mark_cancelled( int $id ): Campaign {
		return $this->update(
			$id,
			array(
				'status'    => CampaignStatus::Cancelled->value,
				'closed_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function set_expected_counts( int $id, int $recipient_count, int $message_count ): Campaign {
		return $this->update(
			$id,
			array(
				'expected_recipient_count' => $recipient_count,
				'expected_message_count'   => $message_count,
			)
		);
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function update( int $id, array $data ): Campaign {
		global $wpdb;

		$table = Schema::table( 'campaigns' );

		$data['updated_at'] = current_time( 'mysql', true );

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): Campaign {
		$campaign = $this->find( $id );

		if ( null === $campaign ) {
			throw new \RuntimeException( esc_html( "Campaign {$id} was expected to exist but could not be loaded." ) );
		}

		return $campaign;
	}
}
