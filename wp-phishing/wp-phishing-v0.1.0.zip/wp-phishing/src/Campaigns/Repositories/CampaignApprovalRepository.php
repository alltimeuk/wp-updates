<?php
/**
 * Persistence for recorded approval decisions, against `wpp_campaign_approvals`, per Section 21.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Repositories;

use Alltime\WPPhishing\Campaigns\CampaignApproval;
use Alltime\WPPhishing\Data\Schema;

final class CampaignApprovalRepository {

	/**
	 * @return CampaignApproval[]
	 */
	public function find_for_campaign( int $campaign_id ): array {
		global $wpdb;

		$table = Schema::table( 'campaign_approvals' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE campaign_id = %d ORDER BY id ASC", $campaign_id ), ARRAY_A );

		return array_map( array( CampaignApproval::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function record( int $campaign_id, int $approver_id, string $approver_role, string $decision, ?string $notes ): CampaignApproval {
		global $wpdb;

		$table = Schema::table( 'campaign_approvals' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'approval_uuid' => wp_generate_uuid4(),
				'campaign_id'   => $campaign_id,
				'approver_id'   => $approver_id,
				'approver_role' => $approver_role,
				'decision'      => $decision,
				'notes'         => $notes,
				'decided_at'    => $now,
			)
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", (int) $wpdb->insert_id ), ARRAY_A );

		return CampaignApproval::from_row( $row );
	}
}
