<?php
/**
 * One frozen cohort entry, per Section 16/20: a snapshot of a recipient's metadata taken at wave
 * activation time, so a later change to the live recipient record never rewrites this wave's
 * historical report. `delivery_id` is filled in once the corresponding delivery has been created.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

final class CampaignWaveRecipient {

	public function __construct(
		public readonly int $id,
		public readonly int $wave_id,
		public readonly int $recipient_id,
		public readonly string $email,
		public readonly string $email_hash,
		public readonly ?string $given_name,
		public readonly ?string $family_name,
		public readonly ?string $department,
		public readonly ?string $team,
		public readonly ?string $location,
		public readonly ?string $job_title,
		/** @var array<string,mixed> */
		public readonly array $metadata,
		public readonly ?int $delivery_id,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$metadata = ! empty( $row['metadata'] ) ? json_decode( (string) $row['metadata'], true ) : array();

		return new self(
			id: (int) $row['id'],
			wave_id: (int) $row['wave_id'],
			recipient_id: (int) $row['recipient_id'],
			email: (string) $row['email'],
			email_hash: (string) $row['email_hash'],
			given_name: ! empty( $row['given_name'] ) ? (string) $row['given_name'] : null,
			family_name: ! empty( $row['family_name'] ) ? (string) $row['family_name'] : null,
			department: ! empty( $row['department'] ) ? (string) $row['department'] : null,
			team: ! empty( $row['team'] ) ? (string) $row['team'] : null,
			location: ! empty( $row['location'] ) ? (string) $row['location'] : null,
			job_title: ! empty( $row['job_title'] ) ? (string) $row['job_title'] : null,
			metadata: is_array( $metadata ) ? $metadata : array(),
			delivery_id: ! empty( $row['delivery_id'] ) ? (int) $row['delivery_id'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] )
		);
	}
}
