<?php
/**
 * One recorded approval decision, per Section 21.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

final class CampaignApproval {

	public function __construct(
		public readonly int $id,
		public readonly string $approval_uuid,
		public readonly int $campaign_id,
		public readonly int $approver_id,
		public readonly string $approver_role,
		public readonly string $decision,
		public readonly ?string $notes,
		public readonly \DateTimeImmutable $decided_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			approval_uuid: (string) $row['approval_uuid'],
			campaign_id: (int) $row['campaign_id'],
			approver_id: (int) $row['approver_id'],
			approver_role: (string) $row['approver_role'],
			decision: (string) $row['decision'],
			notes: ! empty( $row['notes'] ) ? (string) $row['notes'] : null,
			decided_at: new \DateTimeImmutable( (string) $row['decided_at'] )
		);
	}
}
