<?php
/**
 * A single campaign wave, per Section 19: the template/sender identity/landing page/recipient
 * cohort/delivery window a specific batch of deliveries is generated from.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

use Alltime\WPPhishing\Campaigns\Enums\WaveStatus;

final class CampaignWave {

	public function __construct(
		public readonly int $id,
		public readonly string $wave_uuid,
		public readonly int $campaign_id,
		public readonly string $name,
		public readonly int $template_version_id,
		public readonly int $sender_identity_id,
		public readonly ?int $landing_page_version_id,
		public readonly int $recipient_group_id,
		public readonly WaveStatus $status,
		public readonly string $randomisation_policy,
		public readonly ?\DateTimeImmutable $delivery_window_starts_at,
		public readonly ?\DateTimeImmutable $delivery_window_ends_at,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at,
		public readonly ?\DateTimeImmutable $activated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			wave_uuid: (string) $row['wave_uuid'],
			campaign_id: (int) $row['campaign_id'],
			name: (string) $row['name'],
			template_version_id: (int) $row['template_version_id'],
			sender_identity_id: (int) $row['sender_identity_id'],
			landing_page_version_id: ! empty( $row['landing_page_version_id'] ) ? (int) $row['landing_page_version_id'] : null,
			recipient_group_id: (int) $row['recipient_group_id'],
			status: WaveStatus::from( (string) $row['status'] ),
			randomisation_policy: (string) $row['randomisation_policy'],
			delivery_window_starts_at: ! empty( $row['delivery_window_starts_at'] ) ? new \DateTimeImmutable( (string) $row['delivery_window_starts_at'] ) : null,
			delivery_window_ends_at: ! empty( $row['delivery_window_ends_at'] ) ? new \DateTimeImmutable( (string) $row['delivery_window_ends_at'] ) : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] ),
			activated_at: ! empty( $row['activated_at'] ) ? new \DateTimeImmutable( (string) $row['activated_at'] ) : null
		);
	}
}
