<?php
/**
 * Campaign completion detection, per Section 18/21: a running campaign transitions to Completed
 * once every wave it contains has reached a terminal state for every delivery in its cohort
 * (Section 26's {@see \Alltime\WPPhishing\Delivery\Enums\DeliveryStatus::is_terminal()}).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

use Alltime\WPPhishing\Campaigns\Enums\WaveStatus;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignWaveRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class CampaignCompletionService {

	public function __construct(
		private readonly CampaignRepository $campaigns = new CampaignRepository(),
		private readonly CampaignWaveRepository $waves = new CampaignWaveRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * Checks one running campaign and completes it if ready. Returns true if it was completed by
	 * this call.
	 */
	public function check_and_complete( Campaign $campaign ): bool {
		$waves = $this->waves->find_all_for_campaign( $campaign->id );

		if ( array() === $waves ) {
			return false;
		}

		foreach ( $waves as $wave ) {
			if ( WaveStatus::Activated !== $wave->status && WaveStatus::Completed !== $wave->status ) {
				return false;
			}

			if ( ! $this->waves->all_deliveries_terminal( $wave->id ) ) {
				return false;
			}
		}

		foreach ( $waves as $wave ) {
			if ( WaveStatus::Activated === $wave->status ) {
				$this->waves->mark_status( $wave->id, WaveStatus::Completed );
			}
		}

		$completed = $this->campaigns->mark_completed( $campaign->id );

		$this->audit_logger->log( 'campaign.completed', 'campaign', $campaign->campaign_uuid, null, source: 'system', organisation_uuid: $campaign->organisation_uuid );

		// Billing/usage concerns are handled by whoever subscribes to this action (see
		// Commercial\UsageRecordingListener) - completion detection itself never needs to know
		// they exist, the same "just another subscriber" pattern wp-reconnaissance's own
		// entitlement fulfilment uses for its job-completed hook.
		do_action( 'wpp_campaign_completed', $completed );

		return true;
	}
}
