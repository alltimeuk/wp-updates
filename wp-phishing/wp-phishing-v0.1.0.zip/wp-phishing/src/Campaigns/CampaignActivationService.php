<?php
/**
 * Wave activation, per Section 16/19/20/26/32: freezes the recipient cohort, renders each
 * recipient's message from the wave's locked template version, issues a tracking token per
 * delivery, and enqueues the delivery onto Phase 3's durable queue.
 *
 * Idempotent by design at the unit-of-work level (one recipient), not wrapped in a database
 * transaction (no part of this codebase uses one): {@see \Alltime\WPPhishing\Delivery\Repositories\DeliveryRepository::create()}
 * returns the existing delivery on a repeat idempotency key rather than duplicating it, so
 * re-running activation after a crash only creates what is still missing. The one narrow gap this
 * leaves is a crash between a delivery being created and its tracking token being stored, in
 * which case that single delivery's tracking link never resolves - an accepted, low-probability
 * risk consistent with how the rest of this codebase favours idempotent retries over transactions.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

use Alltime\CustomerPlatform\OrganisationPlatformDiscovery;
use Alltime\WPPhishing\Campaigns\Enums\CampaignStatus;
use Alltime\WPPhishing\Campaigns\Enums\WaveStatus;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignWaveRepository;
use Alltime\WPPhishing\Delivery\DeliveryQueueService;
use Alltime\WPPhishing\Recipients\Repositories\RecipientGroupRepository;
use Alltime\WPPhishing\Sending\Repositories\SenderDomainRepository;
use Alltime\WPPhishing\Sending\Repositories\SenderIdentityRepository;
use Alltime\WPPhishing\Sending\SenderDomain;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Templates\Repositories\TemplateRepository;
use Alltime\WPPhishing\Templates\Support\TemplateRenderer;
use Alltime\WPPhishing\Tracking\TrackingService;

final class CampaignActivationService {

	public function __construct(
		private readonly CampaignRepository $campaigns = new CampaignRepository(),
		private readonly CampaignWaveRepository $waves = new CampaignWaveRepository(),
		private readonly RecipientGroupRepository $recipient_groups = new RecipientGroupRepository(),
		private readonly TemplateRepository $templates = new TemplateRepository(),
		private readonly SenderIdentityRepository $sender_identities = new SenderIdentityRepository(),
		private readonly SenderDomainRepository $sender_domains = new SenderDomainRepository(),
		private readonly DeliveryQueueService $delivery_queue = new DeliveryQueueService(),
		private readonly TrackingService $tracking = new TrackingService(),
		private readonly TemplateRenderer $renderer = new TemplateRenderer(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	public function activate_campaign( Campaign $campaign ): Campaign {
		if ( CampaignStatus::Scheduled !== $campaign->status ) {
			throw new \InvalidArgumentException( esc_html__( 'Only a scheduled campaign can be activated.', 'wp-phishing' ) );
		}

		foreach ( $this->waves->find_all_for_campaign( $campaign->id ) as $wave ) {
			$this->activate_wave( $campaign, $wave );
		}

		$updated = $this->campaigns->mark_running( $campaign->id );

		$this->audit_logger->log( 'campaign.activated', 'campaign', $campaign->campaign_uuid, null, source: 'system', organisation_uuid: $campaign->organisation_uuid );

		return $updated;
	}

	private function activate_wave( Campaign $campaign, CampaignWave $wave ): void {
		if ( ! in_array( $wave->status, array( WaveStatus::Draft, WaveStatus::Scheduled ), true ) ) {
			return;
		}

		foreach ( $this->recipient_groups->find_members( $wave->recipient_group_id ) as $recipient ) {
			$this->waves->freeze_recipient( $wave->id, $recipient );
		}

		$template_version = $this->templates->find_version( $wave->template_version_id );
		$sender_identity  = $this->sender_identities->find( $wave->sender_identity_id );

		if ( null === $template_version || null === $sender_identity ) {
			throw new \RuntimeException( esc_html( "Wave {$wave->wave_uuid} references a template version or sender identity that no longer exists." ) );
		}

		$sender_domain = $this->sender_domains->find( $sender_identity->sender_domain_id );

		if ( null === $sender_domain ) {
			throw new \RuntimeException( esc_html( "Wave {$wave->wave_uuid}'s sender identity references a sender domain that no longer exists." ) );
		}

		$organisation_name = $this->organisation_name( $campaign->organisation_uuid );

		foreach ( $this->waves->find_wave_recipients_without_delivery( $wave->id ) as $wave_recipient ) {
			$raw_token       = $this->tracking->generate_raw_token();
			$click_url       = $this->tracking_url( $sender_domain, 'click', $raw_token );
			$unsubscribe_url = $this->tracking_url( $sender_domain, 'unsubscribe', $raw_token );

			// Section 14's manager_reference is a generic reference, not guaranteed to be a
			// display name - resolving it to a proper {{manager_name}} would require looking up
			// another recipient record by that reference, which this activation flow does not
			// do. Left blank rather than rendering a possibly-wrong raw reference into the email.
			$variables = array(
				'given_name'        => $wave_recipient->given_name ?? '',
				'family_name'       => $wave_recipient->family_name ?? '',
				'organisation_name' => $organisation_name ?? '',
				'department'        => $wave_recipient->department ?? '',
				'manager_name'      => '',
				'campaign_token'    => $click_url,
			);

			$subject   = $this->renderer->render_text( $template_version->subject, $variables );
			$html_body = null !== $template_version->html_body
				? $this->append_footer_html( $this->renderer->render_html( $template_version->html_body, $variables ), $this->tracking_url( $sender_domain, 'open', $raw_token ), $unsubscribe_url )
				: null;
			$text_body = null !== $template_version->text_body
				? $this->renderer->render_text( $template_version->text_body, $variables ) . $this->unsubscribe_footer_text( $unsubscribe_url )
				: null;

			$idempotency_key = hash( 'sha256', "{$wave->wave_uuid}:{$wave_recipient->recipient_id}" );

			$delivery = $this->delivery_queue->enqueue(
				$campaign->organisation_uuid,
				$sender_identity,
				$wave_recipient->email,
				$subject,
				$html_body,
				$text_body,
				$idempotency_key,
				source_object_type: 'campaign_wave',
				source_object_uuid: $wave->wave_uuid
			);

			$this->tracking->store_token( $raw_token, $delivery->id );
			$this->waves->set_delivery_id( $wave_recipient->id, $delivery->id );
		}

		$this->waves->mark_status( $wave->id, WaveStatus::Activated );
	}

	private function tracking_url( SenderDomain $domain, string $route, string $token ): string {
		$host = $domain->tracking_domain ?? $domain->domain;

		return "https://{$host}/tracking/{$route}/{$token}";
	}

	/**
	 * Every delivery always includes an unsubscribe link, regardless of what the template itself
	 * contains - never template-author-optional, the same way the open-tracking pixel isn't.
	 */
	private function append_footer_html( string $html, string $open_url, string $unsubscribe_url ): string {
		$pixel  = '<img src="' . esc_url( $open_url ) . '" width="1" height="1" alt="" style="display:none" />';
		$footer = '<p style="font-size:11px;color:#888;">' . esc_html__( 'To stop receiving security-awareness simulations at this address, ', 'wp-phishing' )
			. '<a href="' . esc_url( $unsubscribe_url ) . '">' . esc_html__( 'click here', 'wp-phishing' ) . '</a>.</p>'
			. $pixel;

		return str_contains( $html, '</body>' ) ? str_replace( '</body>', $footer . '</body>', $html ) : $html . $footer;
	}

	private function unsubscribe_footer_text( string $unsubscribe_url ): string {
		return "\n\n" . sprintf(
			/* translators: %s: unsubscribe URL */
			__( 'To stop receiving security-awareness simulations at this address, visit: %s', 'wp-phishing' ),
			$unsubscribe_url
		);
	}

	private function organisation_name( string $organisation_uuid ): ?string {
		$service = OrganisationPlatformDiscovery::resolve();

		return $service?->get_by_uuid( $organisation_uuid )?->name;
	}
}
