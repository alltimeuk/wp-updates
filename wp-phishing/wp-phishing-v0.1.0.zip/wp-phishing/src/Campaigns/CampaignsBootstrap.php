<?php
/**
 * Schedules the recurring campaign activation and completion sweeps, per Section 20/21/26.
 * Mirrors {@see \Alltime\WPPhishing\Recipients\RecipientsBootstrap}'s shape - a dedicated, short
 * cron interval owned by this module alone, since a scheduled campaign should start promptly once
 * its time arrives rather than waiting for an hourly tick.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;

final class CampaignsBootstrap {

	public const RUN_SWEEP_HOOK = 'wpp_run_campaign_sweep';

	private const INTERVAL_SLUG = 'wpp_campaign_five_minutes';

	public function boot(): void {
		add_filter( 'cron_schedules', array( $this, 'register_five_minute_interval' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 5 minutes is intentional: a scheduled campaign should start promptly, not wait for an hourly tick.
		add_action( self::RUN_SWEEP_HOOK, array( $this, 'run_sweep' ) );
		add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
	}

	/**
	 * @param array<string,array{interval:int,display:string}> $schedules
	 *
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function register_five_minute_interval( array $schedules ): array {
		$schedules[ self::INTERVAL_SLUG ] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 5 minutes (WP-Phishing campaign sweep)', 'wp-phishing' ),
		);

		return $schedules;
	}

	public function ensure_sweep_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_SWEEP_HOOK ) ) {
			wp_schedule_event( time(), self::INTERVAL_SLUG, self::RUN_SWEEP_HOOK );
		}
	}

	public function run_sweep(): void {
		$campaigns  = new CampaignRepository();
		$activation = new CampaignActivationService();
		$completion = new CampaignCompletionService();

		foreach ( $campaigns->find_due_for_activation() as $campaign ) {
			$activation->activate_campaign( $campaign );
		}

		foreach ( $campaigns->find_running() as $campaign ) {
			$completion->check_and_complete( $campaign );
		}
	}
}
