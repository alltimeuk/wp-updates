<?php
/**
 * A campaign's sync state against HaloPSA's pull/acknowledge lifecycle, per Section 51: "A
 * compatible integration shall expose: pending, processing, synced, retry_pending, failed,
 * ignored." Mirrors WP-Questionnaires' own `halopsa_sync_status` states, applied here to
 * campaigns instead of form submissions.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Enums;

enum HaloSyncStatus: string {
	case Pending      = 'pending';
	case Processing   = 'processing';
	case Synced       = 'synced';
	case RetryPending = 'retry_pending';
	case Failed       = 'failed';
	case Ignored      = 'ignored';

	public function is_terminal(): bool {
		return in_array( $this, array( self::Synced, self::Ignored ), true );
	}
}
