<?php
/**
 * Supported campaign approval models, per Section 21.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Enums;

enum ApprovalModel: string {
	/** The organisation's own Owner/Administrator may approve. */
	case CustomerSelfApproval = 'customer_self_approval';
	/** Only an Alltime operator may approve. */
	case AlltimeApprovalRequired = 'alltime_approval_required';
	/** Both a customer approver and an Alltime operator must approve independently. */
	case DualApproval = 'dual_approval';
	/** Only an Alltime operator may create or approve - no customer self-service. */
	case ManagedServiceOnly = 'managed_service_only';
}
