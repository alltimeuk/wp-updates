<?php
/**
 * Campaign scheduling mode, per Section 20. `RandomisedWindow`, `Recurring` and `MultiWave` are
 * explicitly Phase 2 (Section 77) and are not included as cases here - a wave has no recurrence
 * fields yet, so adding those cases now would advertise support that does not exist.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Enums;

enum ScheduleMode: string {
	case Immediate = 'immediate';
	case Scheduled = 'scheduled';
	case Window    = 'window';
}
