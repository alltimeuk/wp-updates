<?php
/**
 * Campaign lifecycle status, per Section 18. `Paused` and `Archived` are schema-complete but have
 * no service-level transition yet this phase: `Paused` needs the same delivery-queue gating
 * mechanism as Section 71's global kill switch (Phase 6), so building it half-way now would be
 * misleading; `Archived` is a simple post-completion housekeeping state with no functional
 * behaviour riding on it yet. `Failed` is reserved for a future automated-failure detector.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Enums;

enum CampaignStatus: string {
	case Draft            = 'draft';
	case AwaitingApproval = 'awaiting_approval';
	case Approved         = 'approved';
	case Scheduled        = 'scheduled';
	case Running          = 'running';
	case Paused           = 'paused';
	case Completed        = 'completed';
	case Cancelled        = 'cancelled';
	case Failed           = 'failed';
	case Archived         = 'archived';
}
