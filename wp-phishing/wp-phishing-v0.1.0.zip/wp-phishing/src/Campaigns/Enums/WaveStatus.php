<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns\Enums;

enum WaveStatus: string {
	case Draft     = 'draft';
	case Scheduled = 'scheduled';
	case Activated = 'activated';
	case Completed = 'completed';
	case Cancelled = 'cancelled';
}
