<?php
/**
 * Campaign approval workflow, per Section 21: a campaign must not send until it has been through
 * the approval its `approval_model` requires. `$approver_role` ('customer' or 'alltime') is
 * supplied by the caller, which already knows via {@see \Alltime\WPPhishing\Support\TenantGuard}
 * whether the current actor is an Alltime operator or an organisation member - this service does
 * not make that authorisation decision itself, only records and reacts to it.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Campaigns;

use Alltime\CustomerPlatform\EntitlementPlatformDiscovery;
use Alltime\CustomerPlatform\EntitlementServiceInterface;
use Alltime\WPPhishing\Campaigns\Enums\ApprovalModel;
use Alltime\WPPhishing\Campaigns\Enums\CampaignStatus;
use Alltime\WPPhishing\Campaigns\Enums\ScheduleMode;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignApprovalRepository;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;
use Alltime\WPPhishing\Support\AuditLogger;

use const Alltime\WPPhishing\WPP_PRODUCT_ID;

final class CampaignApprovalService {

	public function __construct(
		private readonly CampaignRepository $campaigns = new CampaignRepository(),
		private readonly CampaignApprovalRepository $approvals = new CampaignApprovalRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly ?EntitlementServiceInterface $entitlements = null
	) {}

	/**
	 * @return CampaignApproval[]
	 */
	public function list_decisions( Campaign $campaign ): array {
		return $this->approvals->find_for_campaign( $campaign->id );
	}

	public function submit( Campaign $campaign, ?int $submitted_by = null ): Campaign {
		if ( CampaignStatus::Draft !== $campaign->status ) {
			throw new \InvalidArgumentException( esc_html__( 'Only a draft campaign can be submitted for approval.', 'wp-phishing' ) );
		}

		if ( null === $this->campaigns->find( $campaign->id ) ) {
			throw new \InvalidArgumentException( esc_html__( 'Campaign not found.', 'wp-phishing' ) );
		}

		$updated = $this->campaigns->mark_awaiting_approval( $campaign->id );

		$this->audit_logger->log( 'campaign.submitted_for_approval', 'campaign', $campaign->campaign_uuid, $submitted_by, organisation_uuid: $campaign->organisation_uuid );

		return $updated;
	}

	/**
	 * Records one approval decision. Once the campaign's approval_model's requirements are
	 * satisfied by the decisions on record, the campaign transitions to Approved; a rejection
	 * always returns the campaign to Draft so it can be revised and resubmitted.
	 */
	public function decide( Campaign $campaign, int $approver_id, string $approver_role, bool $approved, ?string $notes = null ): Campaign {
		if ( CampaignStatus::AwaitingApproval !== $campaign->status ) {
			throw new \InvalidArgumentException( esc_html__( 'This campaign is not awaiting approval.', 'wp-phishing' ) );
		}

		$this->approvals->record( $campaign->id, $approver_id, $approver_role, $approved ? 'approved' : 'rejected', $notes );

		if ( ! $approved ) {
			$this->audit_logger->log( 'campaign.approval_rejected', 'campaign', $campaign->campaign_uuid, $approver_id, outcome: 'failure', organisation_uuid: $campaign->organisation_uuid );

			return $this->campaigns->update_status( $campaign->id, CampaignStatus::Draft );
		}

		$this->audit_logger->log( 'campaign.approval_recorded', 'campaign', $campaign->campaign_uuid, $approver_id, summary: $approver_role, organisation_uuid: $campaign->organisation_uuid );

		if ( ! $this->requirements_satisfied( $campaign ) ) {
			return $campaign;
		}

		// Section 21: "Valid product entitlement" is a mandatory campaign-approval gate, checked
		// (not consumed - that happens at completion, see UsageRecordingListener) only once every
		// human decision the approval_model requires is already in, so a campaign that will
		// ultimately be rejected for lack of budget doesn't first collect approvals for nothing.
		if ( ! $this->entitlement_service()->check( $campaign->organisation_uuid, WPP_PRODUCT_ID )->allowed ) {
			throw new \InvalidArgumentException( esc_html__( 'This organisation does not currently hold a valid entitlement to run this campaign.', 'wp-phishing' ) );
		}

		$approved = $this->campaigns->mark_approved( $campaign->id, $approver_id );

		$this->audit_logger->log( 'campaign.approved', 'campaign', $campaign->campaign_uuid, $approver_id, organisation_uuid: $campaign->organisation_uuid );

		// A campaign that just cleared its approval requirements is immediately scheduled - for
		// Immediate mode that means "now"; for Scheduled/Window mode, starts_at was already fixed
		// at creation time and this only flips the status that governs the activation sweep.
		$starts_at = ScheduleMode::Immediate === $approved->schedule_mode ? new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) : $approved->starts_at;

		if ( null === $starts_at ) {
			throw new \RuntimeException( esc_html( "Campaign {$approved->campaign_uuid} has no start time to schedule against." ) );
		}

		$scheduled = $this->campaigns->mark_scheduled( $approved->id, $starts_at );

		$this->audit_logger->log( 'campaign.scheduled', 'campaign', $campaign->campaign_uuid, $approver_id, organisation_uuid: $campaign->organisation_uuid );

		return $scheduled;
	}

	private function requirements_satisfied( Campaign $campaign ): bool {
		return match ( $campaign->approval_model ) {
			// A decision was just recorded above (the caller's `decide()` call), and any actor
			// permitted to reach this point at all is, by definition, someone with authority
			// under self-approval - one recorded approval always suffices.
			ApprovalModel::CustomerSelfApproval => true,
			ApprovalModel::AlltimeApprovalRequired, ApprovalModel::ManagedServiceOnly => $this->has_recorded_role( $campaign->id, 'alltime' ),
			ApprovalModel::DualApproval => $this->has_recorded_role( $campaign->id, 'customer' ) && $this->has_recorded_role( $campaign->id, 'alltime' ),
		};
	}

	private function has_recorded_role( int $campaign_id, string $role ): bool {
		foreach ( $this->approvals->find_for_campaign( $campaign_id ) as $approval ) {
			if ( $role === $approval->approver_role && 'approved' === $approval->decision ) {
				return true;
			}
		}

		return false;
	}

	private function entitlement_service(): EntitlementServiceInterface {
		$service = $this->entitlements ?? EntitlementPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No entitlement service is registered.' ) );
		}

		return $service;
	}
}
