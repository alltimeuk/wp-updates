<?php
/**
 * Read-only checks for Section 71's global emergency flags. Deliberately separate from
 * {@see EmergencyControlsService} (which performs the actions and owns the repositories/audit
 * logging that flip these flags) - a cheap, dependency-free static check is what
 * {@see \Alltime\WPPhishing\Delivery\DeliveryQueueService} and
 * {@see \Alltime\WPPhishing\Tracking\TrackingService} actually need, the same way
 * {@see \Alltime\WPPhishing\Support\FeatureFlags::is_enabled()} is used as a static utility
 * throughout this codebase rather than requiring dependency injection at every call site.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Emergency;

final class EmergencyControls {

	public const SENDS_PAUSED_OPTION      = 'wpp_emergency_sends_paused';
	public const TRACKING_DISABLED_OPTION = 'wpp_emergency_tracking_disabled';

	public static function sends_are_paused(): bool {
		return (bool) get_option( self::SENDS_PAUSED_OPTION, false );
	}

	public static function tracking_is_disabled(): bool {
		return (bool) get_option( self::TRACKING_DISABLED_OPTION, false );
	}
}
