<?php
/**
 * The six emergency actions, per Section 71: pause all campaigns, disable sender domain, suspend
 * organisation, suppress recipient, cancel unsent campaign deliveries, disable tracking. Every
 * action is audited (Section 71's own requirement).
 *
 * Directly reuses existing infrastructure rather than inventing parallel mechanisms:
 * {@see \Alltime\WPPhishing\Campaigns\CampaignService::cancel()}/{@see \Alltime\WPPhishing\Campaigns\CampaignService::pause()}/
 * {@see \Alltime\WPPhishing\Campaigns\CampaignService::resume()} for campaign-level actions,
 * {@see \Alltime\WPPhishing\Sending\SenderDomainService::retire()} for disabling a sender domain,
 * {@see \Alltime\WPPhishing\Recipients\SuppressionService::suppress()} for recipient suppression.
 * The two genuinely new mechanisms - the global send-pause and the global tracking-disable flag -
 * are exposed read-only via {@see EmergencyControls} for
 * {@see \Alltime\WPPhishing\Delivery\DeliveryQueueService}/{@see \Alltime\WPPhishing\Tracking\TrackingService}
 * to check without depending on this whole service.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Emergency;

use Alltime\CustomerPlatform\Enums\OrganisationStatus;
use Alltime\CustomerPlatform\Repositories\OrganisationRepository;
use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\CampaignService;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;
use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\SuppressionService;
use Alltime\WPPhishing\Sending\SenderDomainService;
use Alltime\WPPhishing\Support\AuditLogger;

final class EmergencyControlsService {

	public function __construct(
		private readonly CampaignRepository $campaigns = new CampaignRepository(),
		private readonly CampaignService $campaign_service = new CampaignService(),
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly SenderDomainService $sender_domains = new SenderDomainService(),
		private readonly SuppressionService $suppressions = new SuppressionService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	public function sends_are_paused(): bool {
		return EmergencyControls::sends_are_paused();
	}

	public function tracking_is_disabled(): bool {
		return EmergencyControls::tracking_is_disabled();
	}

	/**
	 * Global, not per-organisation (Section 71 lists this first, unqualified) - flips every
	 * currently-running campaign to Paused for visibility, but the actual enforcement is the flag
	 * itself: {@see \Alltime\WPPhishing\Delivery\DeliveryQueueService::process_batch()} checks it
	 * on every invocation, so a campaign that starts running after the pause was set is stopped
	 * too, not just the ones already running when this was called.
	 */
	public function pause_all_sends( ?int $actor_id = null ): void {
		update_option( EmergencyControls::SENDS_PAUSED_OPTION, true, true );

		foreach ( $this->campaigns->find_running() as $campaign ) {
			$this->campaign_service->pause( $campaign );
		}

		$this->audit_logger->log( 'emergency.sends_paused', 'system', null, $actor_id, source: 'admin' );
	}

	public function resume_all_sends( ?int $actor_id = null ): void {
		update_option( EmergencyControls::SENDS_PAUSED_OPTION, false, true );

		foreach ( $this->campaigns->find_paused() as $campaign ) {
			$this->campaign_service->resume( $campaign );
		}

		$this->audit_logger->log( 'emergency.sends_resumed', 'system', null, $actor_id, source: 'admin' );
	}

	public function disable_tracking( ?int $actor_id = null ): void {
		update_option( EmergencyControls::TRACKING_DISABLED_OPTION, true, true );

		$this->audit_logger->log( 'emergency.tracking_disabled', 'system', null, $actor_id, source: 'admin' );
	}

	public function enable_tracking( ?int $actor_id = null ): void {
		update_option( EmergencyControls::TRACKING_DISABLED_OPTION, false, true );

		$this->audit_logger->log( 'emergency.tracking_enabled', 'system', null, $actor_id, source: 'admin' );
	}

	public function suspend_organisation( string $organisation_uuid, ?int $actor_id = null ): void {
		$organisation = $this->organisations->find_by_uuid( $organisation_uuid );

		if ( null === $organisation ) {
			return;
		}

		$this->organisations->update_status( $organisation->id, OrganisationStatus::Suspended );

		$this->audit_logger->log( 'emergency.organisation_suspended', 'organisation', $organisation_uuid, $actor_id, source: 'admin', organisation_uuid: $organisation_uuid );
	}

	public function suppress_recipient( string $organisation_uuid, string $email, ?int $actor_id = null ): void {
		$this->suppressions->suppress( $organisation_uuid, $email, SuppressionReason::LegalExclusion, 'emergency_controls', created_by: $actor_id );

		$this->audit_logger->log( 'emergency.recipient_suppressed', 'suppression', $email, $actor_id, source: 'admin', organisation_uuid: $organisation_uuid );
	}

	public function disable_sender_domain( string $domain_uuid, ?int $actor_id = null ): void {
		$domain = $this->sender_domains->get( $domain_uuid );

		if ( null === $domain ) {
			return;
		}

		$this->sender_domains->retire( $domain, $actor_id );

		$this->audit_logger->log( 'emergency.sender_domain_disabled', 'sender_domain', $domain_uuid, $actor_id, source: 'admin' );
	}

	public function cancel_campaign( Campaign $campaign, ?int $actor_id = null ): void {
		$this->campaign_service->cancel( $campaign, $actor_id );

		$this->audit_logger->log( 'emergency.campaign_cancelled', 'campaign', $campaign->campaign_uuid, $actor_id, source: 'admin', organisation_uuid: $campaign->organisation_uuid );
	}
}
