<?php
/**
 * Delivery queue worker, per Section 26: reserve -> send -> record provider message id, with a
 * retry that never re-sends after provider acceptance (Section 26's idempotency requirement) and
 * a fail-closed sender preflight before every attempt (Section 24/70).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Delivery;

use Alltime\WPPhishing\Delivery\Repositories\DeliveryRepository;
use Alltime\WPPhishing\Emergency\EmergencyControls;
use Alltime\WPPhishing\Integrations\Mail\Exceptions\MailDeliveryException;
use Alltime\WPPhishing\Integrations\Mail\MailManager;
use Alltime\WPPhishing\Integrations\Mail\QueuedMessage;
use Alltime\WPPhishing\Recipients\Repositories\SuppressionRepository;
use Alltime\WPPhishing\Sending\Repositories\SenderDomainRepository;
use Alltime\WPPhishing\Sending\Repositories\SenderIdentityRepository;
use Alltime\WPPhishing\Sending\SenderHealthService;
use Alltime\WPPhishing\Sending\SenderIdentity;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;
use Alltime\WPPhishing\Tracking\TrackingService;

final class DeliveryQueueService {

	private const BATCH_SIZE           = 50;
	private const MAX_RETRIES          = 5;
	private const BASE_BACKOFF_SECONDS = 60;

	public function __construct(
		private readonly DeliveryRepository $deliveries = new DeliveryRepository(),
		private readonly SenderIdentityRepository $sender_identities = new SenderIdentityRepository(),
		private readonly SenderDomainRepository $sender_domains = new SenderDomainRepository(),
		private readonly SuppressionRepository $suppressions = new SuppressionRepository(),
		private readonly MailManager $mail_manager = new MailManager(),
		private readonly SenderHealthService $health = new SenderHealthService(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly TrackingService $tracking = new TrackingService()
	) {}

	/**
	 * Queues a message for delivery. Idempotent via `$idempotency_key` -
	 * {@see DeliveryRepository::create()} returns the existing delivery on a repeat call rather
	 * than creating a duplicate.
	 */
	public function enqueue(
		string $organisation_uuid,
		SenderIdentity $sender_identity,
		string $recipient_email,
		string $subject,
		?string $html_body,
		?string $text_body,
		string $idempotency_key,
		?string $source_object_type = null,
		?string $source_object_uuid = null
	): Delivery {
		return $this->deliveries->create(
			$organisation_uuid,
			$sender_identity->id,
			$recipient_email,
			$subject,
			$html_body,
			$text_body,
			$idempotency_key,
			$source_object_type,
			$source_object_uuid
		);
	}

	/**
	 * Processes one bounded batch of due deliveries - the background sweep's unit of work.
	 * Section 71's global kill switch stops this at its single entry point rather than needing
	 * every caller of {@see enqueue()} to know the plugin might currently be paused - a delivery
	 * already queued stays queued, claimable again the moment the pause is lifted.
	 *
	 * @return int How many deliveries were attempted.
	 */
	public function process_batch( int $limit = self::BATCH_SIZE ): int {
		if ( EmergencyControls::sends_are_paused() ) {
			return 0;
		}

		$claimed = $this->deliveries->claim_batch( $limit );

		foreach ( $claimed as $delivery ) {
			$this->attempt( $delivery );
		}

		return count( $claimed );
	}

	private function attempt( Delivery $delivery ): void {
		// Checked again at send time, not only at enqueue time (Section 55: suppression
		// overrides targeting) - a recipient suppressed after being queued (e.g. a bounce or
		// complaint recorded in the meantime) must still never receive the message.
		if ( $this->suppressions->is_suppressed( $delivery->organisation_uuid, $delivery->recipient_email ) ) {
			$this->deliveries->mark_suppressed( $delivery->id );
			$this->audit_logger->log( 'delivery.suppressed', 'delivery', $delivery->delivery_uuid, null, source: 'system', organisation_uuid: $delivery->organisation_uuid );
			return;
		}

		$identity = $this->sender_identities->find( $delivery->sender_identity_id );

		if ( null === $identity ) {
			$this->deliveries->record_attempt_failure( $delivery->id, 'Sender identity no longer exists.', null );
			return;
		}

		$domain = $this->sender_domains->find( $identity->sender_domain_id );

		if ( null === $domain ) {
			$this->deliveries->record_attempt_failure( $delivery->id, 'Sender domain no longer exists.', null );
			return;
		}

		// Fail closed (Section 24/70): never attempt a send through infrastructure that hasn't
		// been positively verified healthy.
		if ( ! $this->health->is_ready_for_sending( $domain ) ) {
			$this->deliveries->record_attempt_failure( $delivery->id, 'Sender domain failed pre-flight health checks.', $this->next_retry_at( $delivery->retry_count ) );
			return;
		}

		$provider = $this->mail_manager->resolve( $domain->mail_provider, $delivery->organisation_uuid );

		if ( null === $provider ) {
			$this->deliveries->record_attempt_failure( $delivery->id, 'No mail provider is configured.', null );
			return;
		}

		$this->deliveries->mark_sending( $delivery->id );

		$message = new QueuedMessage(
			idempotency_key: $delivery->idempotency_key,
			from_address: "{$identity->local_part}@{$domain->domain}",
			from_display_name: $identity->display_name,
			to_address: $delivery->recipient_email,
			subject: $delivery->rendered_subject,
			html_body: $delivery->rendered_html_body,
			text_body: $delivery->rendered_text_body,
			reply_to: $identity->reply_to
		);

		try {
			$result = $provider->send( $message );
		} catch ( MailDeliveryException $exception ) {
			$this->handle_send_failure( $delivery, $exception );
			return;
		}

		$this->deliveries->mark_accepted( $delivery->id, $result->provider_id, $result->provider_message_id );

		$this->audit_logger->log( 'delivery.accepted', 'delivery', $delivery->delivery_uuid, null, source: 'system', organisation_uuid: $delivery->organisation_uuid );

		// Section 36: record provider events where available. Deduplicated per delivery so a
		// worker retry after a crash between mark_accepted() and here can never double-record it.
		$this->tracking->record_event( $delivery->delivery_uuid, TrackingEventType::MessageAccepted, source: 'queue', deduplication_key: "accepted:{$delivery->delivery_uuid}" );
	}

	private function handle_send_failure( Delivery $delivery, MailDeliveryException $exception ): void {
		$next_retry = $exception->is_retryable && $delivery->retry_count < self::MAX_RETRIES
			? $this->next_retry_at( $delivery->retry_count )
			: null;

		// Every provider constructs MailDeliveryException messages from fixed text plus, at most,
		// an HTTP status code - never a raw response body - so truncating is a length safeguard,
		// not the only redaction; the length cap matches Data\Schema's audit_log.summary size.
		$summary = substr( $exception->getMessage(), 0, 190 );

		$this->deliveries->record_attempt_failure( $delivery->id, $summary, $next_retry );

		$this->audit_logger->log(
			null === $next_retry ? 'delivery.failed' : 'delivery.deferred',
			'delivery',
			$delivery->delivery_uuid,
			null,
			outcome: 'failure',
			summary: $summary,
			source: 'system',
			organisation_uuid: $delivery->organisation_uuid
		);
	}

	private function next_retry_at( int $retry_count ): \DateTimeImmutable {
		$delay_seconds = self::BASE_BACKOFF_SECONDS * ( 2 ** $retry_count );

		return ( new \DateTimeImmutable() )->modify( "+{$delay_seconds} seconds" );
	}
}
