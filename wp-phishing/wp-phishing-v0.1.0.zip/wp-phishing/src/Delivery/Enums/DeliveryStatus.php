<?php
/**
 * Delivery lifecycle status, per Section 26.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Delivery\Enums;

enum DeliveryStatus: string {
	case Planned    = 'planned';
	case Queued     = 'queued';
	case Reserved   = 'reserved';
	case Sending    = 'sending';
	case Accepted   = 'accepted';
	case Delivered  = 'delivered';
	case Deferred   = 'deferred';
	case Bounced    = 'bounced';
	case Rejected   = 'rejected';
	case Suppressed = 'suppressed';
	case Cancelled  = 'cancelled';
	case Failed     = 'failed';

	/**
	 * Once a delivery reaches one of these, {@see \Alltime\WPPhishing\Delivery\DeliveryQueueService}
	 * never attempts it again - Section 26: "Retrying a worker shall not send a duplicate message
	 * after provider acceptance."
	 */
	public function is_terminal(): bool {
		return in_array(
			$this,
			array( self::Accepted, self::Delivered, self::Bounced, self::Rejected, self::Suppressed, self::Cancelled, self::Failed ),
			true
		);
	}
}
