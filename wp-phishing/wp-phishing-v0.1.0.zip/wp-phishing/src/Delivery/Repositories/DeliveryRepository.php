<?php
/**
 * Persistence for deliveries against `wpp_deliveries`, per Section 26.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Delivery\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Delivery\Delivery;
use Alltime\WPPhishing\Delivery\Enums\DeliveryStatus;
use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Recipients\Support\EmailNormaliser;

final class DeliveryRepository {

	public function find( int $id ): ?Delivery {
		global $wpdb;

		$table = Schema::table( 'deliveries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Delivery::from_row( $row ) : null;
	}

	public function find_by_uuid( string $delivery_uuid ): ?Delivery {
		global $wpdb;

		$table = Schema::table( 'deliveries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE delivery_uuid = %s", $delivery_uuid ), ARRAY_A );

		return null !== $row ? Delivery::from_row( $row ) : null;
	}

	public function find_by_idempotency_key( string $idempotency_key ): ?Delivery {
		global $wpdb;

		$table = Schema::table( 'deliveries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE idempotency_key = %s", $idempotency_key ), ARRAY_A );

		return null !== $row ? Delivery::from_row( $row ) : null;
	}

	/**
	 * Batch-fetches deliveries by id in one query rather than one round-trip per id - used by
	 * result computation, which otherwise issues a separate query per wave recipient.
	 *
	 * @param int[] $ids
	 *
	 * @return array<int,Delivery> Keyed by delivery id.
	 */
	public function find_all_by_ids( array $ids ): array {
		global $wpdb;

		if ( array() === $ids ) {
			return array();
		}

		$table        = Schema::table( 'deliveries' );
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- $table/$placeholders are fixed, internally derived (table name, placeholder count matches count($ids)), not user input; $wpdb->prepare() accepts an array as its second argument.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id IN ({$placeholders})", $ids ), ARRAY_A );

		$deliveries = array();

		foreach ( null !== $rows ? $rows : array() as $row ) {
			$delivery                    = Delivery::from_row( $row );
			$deliveries[ $delivery->id ] = $delivery;
		}

		return $deliveries;
	}

	/**
	 * Every not-yet-terminal delivery for one polymorphic source object (Section 26's
	 * `source_object_type`/`source_object_uuid` pair - e.g. `'campaign_wave'` +
	 * a wave's UUID) - the basis for cancelling a campaign's still-unsent deliveries
	 * (Section 72/71) without needing this repository to know what a campaign or wave is.
	 *
	 * @return Delivery[]
	 */
	public function find_unsent_by_source_object( string $source_object_type, string $source_object_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'deliveries' );

		$terminal_statuses = array_filter( DeliveryStatus::cases(), static fn ( DeliveryStatus $status ): bool => $status->is_terminal() );
		$terminal_values   = array_map( static fn ( DeliveryStatus $status ): string => $status->value, $terminal_statuses );
		$placeholders      = implode( ', ', array_fill( 0, count( $terminal_values ), '%s' ) );

		$query = "SELECT * FROM `{$table}` WHERE source_object_type = %s AND source_object_uuid = %s AND status NOT IN ({$placeholders})";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- $table/$placeholders are fixed, internally derived (table name, placeholder count matches count($terminal_values)), not user input; $wpdb->prepare() accepts an array as its second argument via array_merge() below.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, array_merge( array( $source_object_type, $source_object_uuid ), $terminal_values ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above.

		return array_map( array( Delivery::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * The most recent deliveries across every organisation - the Alltime-staff admin "Queue"
	 * screen's unfiltered view (Section 67).
	 *
	 * @return Delivery[]
	 */
	public function find_recent( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'deliveries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );

		return array_map( array( Delivery::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Creates a new delivery, already Queued. Idempotent by `idempotency_key`: a second call with
	 * a key already on file returns the existing delivery rather than erroring or creating a
	 * duplicate - callers (e.g. a campaign re-processing the same wave/recipient pairing after a
	 * partial failure) can call this unconditionally.
	 */
	public function create(
		string $organisation_uuid,
		int $sender_identity_id,
		string $recipient_email,
		string $rendered_subject,
		?string $rendered_html_body,
		?string $rendered_text_body,
		string $idempotency_key,
		?string $source_object_type = null,
		?string $source_object_uuid = null
	): Delivery {
		$existing = $this->find_by_idempotency_key( $idempotency_key );

		if ( null !== $existing ) {
			return $existing;
		}

		global $wpdb;

		$table = Schema::table( 'deliveries' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'delivery_uuid'        => wp_generate_uuid4(),
			'organisation_uuid'    => $organisation_uuid,
			'sender_identity_id'   => $sender_identity_id,
			'recipient_email'      => EmailNormaliser::normalise( $recipient_email ),
			'recipient_email_hash' => EmailNormaliser::hash( $recipient_email ),
			'rendered_subject'     => $rendered_subject,
			'rendered_html_body'   => $rendered_html_body,
			'rendered_text_body'   => $rendered_text_body,
			'source_object_type'   => $source_object_type,
			'source_object_uuid'   => $source_object_uuid,
			'idempotency_key'      => $idempotency_key,
			'status'               => DeliveryStatus::Queued->value,
			'created_at'           => $now,
			'updated_at'           => $now,
			'queued_at'            => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Atomically claims up to $limit due deliveries (Queued, or Deferred whose retry backoff has
	 * elapsed) by stamping them with a fresh, single-use claim token in one UPDATE - the unit of
	 * work one worker invocation processes. Two concurrent callers can never claim the same row:
	 * MySQL's per-row locking during the UPDATE guarantees each row is claimed by exactly one of
	 * them, even though neither caller can see the other's claim token in advance.
	 *
	 * @return Delivery[]
	 */
	public function claim_batch( int $limit ): array {
		global $wpdb;

		$table       = Schema::table( 'deliveries' );
		$claim_token = wp_generate_uuid4();
		$now         = current_time( 'mysql', true );

		$claim_query = "UPDATE `{$table}` SET status = %s, claim_token = %s, updated_at = %s
			WHERE status IN (%s, %s) AND (next_attempt_at IS NULL OR next_attempt_at <= %s)
			ORDER BY created_at ASC LIMIT %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $claim_query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$wpdb->query( $wpdb->prepare( $claim_query, DeliveryStatus::Reserved->value, $claim_token, $now, DeliveryStatus::Queued->value, DeliveryStatus::Deferred->value, $now, $limit ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.

		$select_query = "SELECT * FROM `{$table}` WHERE claim_token = %s ORDER BY created_at ASC";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- see above.
		$rows = $wpdb->get_results( $wpdb->prepare( $select_query, $claim_token ), ARRAY_A );

		return array_map( array( Delivery::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function mark_sending( int $id ): Delivery {
		return $this->update( $id, array( 'status' => DeliveryStatus::Sending->value ) );
	}

	public function mark_accepted( int $id, MailProviderId $provider_id, string $provider_message_id ): Delivery {
		return $this->update(
			$id,
			array(
				'status'              => DeliveryStatus::Accepted->value,
				'provider_id'         => $provider_id->value,
				'provider_message_id' => $provider_message_id,
				'sent_at'             => current_time( 'mysql', true ),
				'claim_token'         => null,
			)
		);
	}

	public function mark_suppressed( int $id ): Delivery {
		return $this->update(
			$id,
			array(
				'status'      => DeliveryStatus::Suppressed->value,
				'claim_token' => null,
			)
		);
	}

	public function mark_cancelled( int $id ): Delivery {
		return $this->update(
			$id,
			array(
				'status'      => DeliveryStatus::Cancelled->value,
				'claim_token' => null,
			)
		);
	}

	/**
	 * Records a failed send attempt. $next_attempt_at null means no further retry is scheduled -
	 * the caller has decided this delivery has exhausted its retries and moves it to Failed
	 * instead of Deferred.
	 */
	public function record_attempt_failure( int $id, string $last_error, ?\DateTimeImmutable $next_attempt_at ): Delivery {
		global $wpdb;

		$table = Schema::table( 'deliveries' );

		$status = null !== $next_attempt_at ? DeliveryStatus::Deferred : DeliveryStatus::Failed;

		$query = "UPDATE `{$table}` SET status = %s, retry_count = retry_count + 1, last_error = %s, next_attempt_at = %s, claim_token = NULL, updated_at = %s WHERE id = %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$wpdb->query( $wpdb->prepare( $query, $status->value, $last_error, $next_attempt_at?->format( 'Y-m-d H:i:s' ), current_time( 'mysql', true ), $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.

		return $this->find_or_fail( $id );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function update( int $id, array $data ): Delivery {
		global $wpdb;

		$table = Schema::table( 'deliveries' );

		if ( ! isset( $data['updated_at'] ) ) {
			$data['updated_at'] = current_time( 'mysql', true );
		}

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): Delivery {
		$delivery = $this->find( $id );

		if ( null === $delivery ) {
			throw new \RuntimeException( esc_html( "Delivery {$id} was expected to exist but could not be loaded." ) );
		}

		return $delivery;
	}
}
