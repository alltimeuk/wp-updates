<?php
/**
 * Delivery entity, per Section 26.
 *
 * Deliberately campaign-agnostic: `source_object_type`/`source_object_uuid` are a polymorphic
 * reference a later module (Phase 4's Campaign engine) populates without this one needing to
 * know what a campaign is - the same pattern the Customer Platform's `atcp_interactions` table
 * already uses. A delivery is otherwise a complete, self-contained unit of already-rendered
 * content to send.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Delivery;

use Alltime\WPPhishing\Delivery\Enums\DeliveryStatus;
use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Support\Dates;

final class Delivery {

	public function __construct(
		public readonly int $id,
		public readonly string $delivery_uuid,
		public readonly string $organisation_uuid,
		public readonly int $sender_identity_id,
		public readonly string $recipient_email,
		public readonly string $rendered_subject,
		public readonly ?string $rendered_html_body,
		public readonly ?string $rendered_text_body,
		public readonly ?string $source_object_type,
		public readonly ?string $source_object_uuid,
		public readonly string $idempotency_key,
		public readonly ?MailProviderId $provider_id,
		public readonly ?string $provider_message_id,
		public readonly DeliveryStatus $status,
		public readonly int $retry_count,
		public readonly ?\DateTimeImmutable $next_attempt_at,
		public readonly ?string $last_error,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at,
		public readonly ?\DateTimeImmutable $queued_at,
		public readonly ?\DateTimeImmutable $sent_at,
		public readonly ?\DateTimeImmutable $delivered_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			delivery_uuid: (string) $row['delivery_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			sender_identity_id: (int) $row['sender_identity_id'],
			recipient_email: (string) $row['recipient_email'],
			rendered_subject: (string) $row['rendered_subject'],
			rendered_html_body: ! empty( $row['rendered_html_body'] ) ? (string) $row['rendered_html_body'] : null,
			rendered_text_body: ! empty( $row['rendered_text_body'] ) ? (string) $row['rendered_text_body'] : null,
			source_object_type: ! empty( $row['source_object_type'] ) ? (string) $row['source_object_type'] : null,
			source_object_uuid: ! empty( $row['source_object_uuid'] ) ? (string) $row['source_object_uuid'] : null,
			idempotency_key: (string) $row['idempotency_key'],
			provider_id: ! empty( $row['provider_id'] ) ? MailProviderId::from( (string) $row['provider_id'] ) : null,
			provider_message_id: ! empty( $row['provider_message_id'] ) ? (string) $row['provider_message_id'] : null,
			status: DeliveryStatus::from( (string) $row['status'] ),
			retry_count: (int) $row['retry_count'],
			next_attempt_at: ! empty( $row['next_attempt_at'] ) ? Dates::from_mysql( (string) $row['next_attempt_at'] ) : null,
			last_error: ! empty( $row['last_error'] ) ? (string) $row['last_error'] : null,
			created_at: Dates::from_mysql( (string) $row['created_at'] ),
			updated_at: Dates::from_mysql( (string) $row['updated_at'] ),
			queued_at: ! empty( $row['queued_at'] ) ? Dates::from_mysql( (string) $row['queued_at'] ) : null,
			sent_at: ! empty( $row['sent_at'] ) ? Dates::from_mysql( (string) $row['sent_at'] ) : null,
			delivered_at: ! empty( $row['delivered_at'] ) ? Dates::from_mysql( (string) $row['delivered_at'] ) : null
		);
	}
}
