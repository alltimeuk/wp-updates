<?php
/**
 * Persistence for contact identities against `atcp_contact_identities`.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\ContactIdentity;
use Alltime\CustomerPlatform\Enums\IdentityType;
use Alltime\CustomerPlatform\Schema;

final class ContactIdentityRepository {

	/**
	 * Looks up an identity by its normalised value - the basis for
	 * {@see \Alltime\CustomerPlatform\ContactService::create_or_update_contact()}'s dedup check:
	 * a second registration with the same email must resolve to the same contact, never create a
	 * duplicate.
	 */
	public function find_by_value( IdentityType $type, string $normalised_value ): ?ContactIdentity {
		global $wpdb;

		$table = Schema::table( 'contact_identities' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE identity_type = %s AND normalised_value = %s", $type->value, $normalised_value ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return null !== $row ? ContactIdentity::from_row( $row ) : null;
	}

	public function create( int $contact_id, IdentityType $type, string $normalised_value, bool $is_primary, string $source ): ContactIdentity {
		global $wpdb;

		$table = Schema::table( 'contact_identities' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'contact_id'          => $contact_id,
			'identity_type'       => $type->value,
			'normalised_value'    => $normalised_value,
			'is_primary'          => $is_primary ? 1 : 0,
			'verification_status' => 'unverified',
			'source'              => $source,
			'first_observed_at'   => $now,
			'last_observed_at'    => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return ContactIdentity::from_row( array_merge( $data, array( 'id' => $wpdb->insert_id ) ) );
	}

	public function mark_verified( int $id ): void {
		global $wpdb;

		$table = Schema::table( 'contact_identities' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'verification_status' => 'verified',
				'verified_at'         => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);
	}

	/**
	 * @return ContactIdentity[]
	 */
	public function find_all_for_contact( int $contact_id ): array {
		global $wpdb;

		$table = Schema::table( 'contact_identities' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE contact_id = %d", $contact_id ), ARRAY_A );

		return array_map( array( ContactIdentity::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Erasure (Section 53): identities are deleted outright rather than anonymised in place - the
	 * identifying value itself (an email address or phone number) is exactly the thing erasure
	 * must remove, and the `(identity_type, normalised_value)` unique key would make writing a
	 * per-contact sentinel value here more complex than simply removing the row.
	 */
	public function delete_for_contact( int $contact_id ): void {
		global $wpdb;

		$table = Schema::table( 'contact_identities' );

		$wpdb->delete( $table, array( 'contact_id' => $contact_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}
