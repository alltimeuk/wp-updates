<?php
/**
 * Persistence for entitlements against `atcp_entitlements`, per Section 50.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Entitlement;
use Alltime\CustomerPlatform\Enums\EntitlementState;
use Alltime\CustomerPlatform\Enums\EntitlementType;
use Alltime\CustomerPlatform\Schema;

final class EntitlementRepository {

	public function find( int $id ): ?Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Entitlement::from_row( $row ) : null;
	}

	public function find_by_uuid( string $entitlement_uuid ): ?Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE entitlement_uuid = %s", $entitlement_uuid ), ARRAY_A );

		return null !== $row ? Entitlement::from_row( $row ) : null;
	}

	/**
	 * Every entitlement currently held for one organisation/product, most recently created first -
	 * {@see \Alltime\CustomerPlatform\EntitlementPolicy::decide()}'s input.
	 *
	 * @return Entitlement[]
	 */
	public function find_history( string $organisation_uuid, string $product_id ): array {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
				"SELECT * FROM `{$table}` WHERE organisation_uuid = %s AND product_id = %s ORDER BY id DESC",
				$organisation_uuid,
				$product_id
			),
			ARRAY_A
		);

		return array_map( array( Entitlement::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return Entitlement[] Most recent first.
	 */
	public function find_all_for_organisation( string $organisation_uuid, ?string $product_id ): array {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		if ( null !== $product_id ) {
			return $this->find_history( $organisation_uuid, $product_id );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY id DESC", $organisation_uuid ), ARRAY_A );

		return array_map( array( Entitlement::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function grant(
		string $organisation_uuid,
		string $product_id,
		EntitlementType $type,
		?int $allowance_quantity,
		?int $granted_by,
		?string $reason,
		?\DateTimeImmutable $expires_at
	): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'entitlement_uuid'   => wp_generate_uuid4(),
				'organisation_uuid'  => $organisation_uuid,
				'product_id'         => $product_id,
				'type'               => $type->value,
				'state'              => EntitlementState::Reserved->value,
				'allowance_quantity' => $allowance_quantity,
				'consumed_quantity'  => 0,
				'granted_by'         => $granted_by,
				'reason'             => $reason,
				'expires_at'         => $expires_at?->format( 'Y-m-d H:i:s' ),
				'created_at'         => $now,
				'updated_at'         => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Atomically draws $quantity down: the state transition (Reserved/PartiallyConsumed →
	 * PartiallyConsumed or Consumed) is derived from the *stored* allowance/consumed values in the
	 * same statement, not from a possibly-stale in-memory object, closing the same
	 * check-then-write race this codebase has already fixed once this session (findings.md §2.1).
	 */
	public function consume( string $entitlement_uuid, int $quantity ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$query = "UPDATE `{$table}` SET
			consumed_quantity = consumed_quantity + %d,
			state = CASE
				WHEN allowance_quantity IS NOT NULL AND consumed_quantity + %d >= allowance_quantity THEN %s
				WHEN allowance_quantity IS NOT NULL THEN %s
				ELSE state
			END,
			updated_at = %s
			WHERE entitlement_uuid = %s";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$wpdb->query( $wpdb->prepare( $query, $quantity, $quantity, EntitlementState::Consumed->value, EntitlementState::PartiallyConsumed->value, current_time( 'mysql', true ), $entitlement_uuid ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.

		return $this->find_by_uuid_or_fail( $entitlement_uuid );
	}

	public function revoke( string $entitlement_uuid ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'state'      => EntitlementState::Revoked->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'entitlement_uuid' => $entitlement_uuid )
		);

		return $this->find_by_uuid_or_fail( $entitlement_uuid );
	}

	private function find_or_fail( int $id ): Entitlement {
		$entitlement = $this->find( $id );

		if ( null === $entitlement ) {
			throw new \RuntimeException( esc_html( "Entitlement {$id} was expected to exist but could not be loaded." ) );
		}

		return $entitlement;
	}

	private function find_by_uuid_or_fail( string $entitlement_uuid ): Entitlement {
		$entitlement = $this->find_by_uuid( $entitlement_uuid );

		if ( null === $entitlement ) {
			throw new \RuntimeException( esc_html( "Entitlement {$entitlement_uuid} was expected to exist but could not be loaded." ) );
		}

		return $entitlement;
	}
}
