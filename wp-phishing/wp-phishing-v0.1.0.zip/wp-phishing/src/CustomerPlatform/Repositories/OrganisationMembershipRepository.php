<?php
/**
 * Persistence for organisation membership against `atcp_organisation_members`.
 *
 * Every read joins against `atcp_organisations` (and `atcp_contacts` where a member is linked
 * to a contact) so callers only ever see the stable `organisation_uuid`/`contact_uuid`
 * identifiers, never the internal numeric foreign keys this table actually stores.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;
use Alltime\CustomerPlatform\OrganisationMembership;
use Alltime\CustomerPlatform\Schema;

final class OrganisationMembershipRepository {

	private function select_with_joins(): string {
		$members       = Schema::table( 'organisation_members' );
		$organisations = Schema::table( 'organisations' );
		$contacts      = Schema::table( 'contacts' );

		return "SELECT m.*, o.organisation_uuid AS organisation_uuid, c.contact_uuid AS contact_uuid
			FROM `{$members}` m
			INNER JOIN `{$organisations}` o ON o.id = m.organisation_id
			LEFT JOIN `{$contacts}` c ON c.id = m.contact_id";
	}

	public function find( int $id ): ?OrganisationMembership {
		global $wpdb;

		$select = $this->select_with_joins();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $select is this class's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$row = $wpdb->get_row( $wpdb->prepare( $select . ' WHERE m.id = %d', $id ), ARRAY_A );

		return null !== $row ? OrganisationMembership::from_row( $row ) : null;
	}

	public function find_for_user( int $organisation_id, int $wordpress_user_id ): ?OrganisationMembership {
		global $wpdb;

		$select = $this->select_with_joins();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $select is this class's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$row = $wpdb->get_row( $wpdb->prepare( $select . ' WHERE m.organisation_id = %d AND m.wordpress_user_id = %d', $organisation_id, $wordpress_user_id ), ARRAY_A );

		return null !== $row ? OrganisationMembership::from_row( $row ) : null;
	}

	/**
	 * @return OrganisationMembership[]
	 */
	public function find_all_for_user( int $wordpress_user_id ): array {
		global $wpdb;

		$select = $this->select_with_joins();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $select is this class's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $select . ' WHERE m.wordpress_user_id = %d ORDER BY m.id ASC', $wordpress_user_id ), ARRAY_A );

		return array_map( array( OrganisationMembership::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create(
		int $organisation_id,
		int $wordpress_user_id,
		MembershipRole $role,
		?int $contact_id,
		?int $invited_by
	): OrganisationMembership {
		global $wpdb;

		$table = Schema::table( 'organisation_members' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'organisation_id'   => $organisation_id,
			'contact_id'        => $contact_id,
			'wordpress_user_id' => $wordpress_user_id,
			'role'              => $role->value,
			'status'            => MembershipStatus::Invited->value,
			'invited_by'        => $invited_by,
			'invited_at'        => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update_status( int $id, MembershipStatus $status ): OrganisationMembership {
		global $wpdb;

		$table = Schema::table( 'organisation_members' );
		$now   = current_time( 'mysql', true );

		$data = array( 'status' => $status->value );

		if ( MembershipStatus::Active === $status ) {
			$data['accepted_at'] = $now;
		} elseif ( MembershipStatus::Revoked === $status ) {
			$data['revoked_at'] = $now;
		}

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	public function update_role( int $id, MembershipRole $role ): OrganisationMembership {
		global $wpdb;

		$table = Schema::table( 'organisation_members' );

		$wpdb->update( $table, array( 'role' => $role->value ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): OrganisationMembership {
		$membership = $this->find( $id );

		if ( null === $membership ) {
			throw new \RuntimeException( esc_html( "Organisation membership {$id} was expected to exist but could not be loaded." ) );
		}

		return $membership;
	}
}
