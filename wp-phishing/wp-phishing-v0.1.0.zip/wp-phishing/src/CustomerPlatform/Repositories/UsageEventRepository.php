<?php
/**
 * Persistence for usage events against `atcp_usage_events`, per Section 49.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Enums\UsageBillingStatus;
use Alltime\CustomerPlatform\Enums\UsageType;
use Alltime\CustomerPlatform\Schema;
use Alltime\CustomerPlatform\UsageEvent;

final class UsageEventRepository {

	public function find( int $id ): ?UsageEvent {
		global $wpdb;

		$table = Schema::table( 'usage_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? UsageEvent::from_row( $row ) : null;
	}

	public function find_by_uuid( string $usage_uuid ): ?UsageEvent {
		global $wpdb;

		$table = Schema::table( 'usage_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE usage_uuid = %s", $usage_uuid ), ARRAY_A );

		return null !== $row ? UsageEvent::from_row( $row ) : null;
	}

	/**
	 * @return UsageEvent[] Most recent first.
	 */
	public function find_for_organisation( string $organisation_uuid, ?string $product_id ): array {
		global $wpdb;

		$table = Schema::table( 'usage_events' );

		if ( null !== $product_id ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
					"SELECT * FROM `{$table}` WHERE organisation_uuid = %s AND product_id = %s ORDER BY id DESC",
					$organisation_uuid,
					$product_id
				),
				ARRAY_A
			);
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY id DESC", $organisation_uuid ), ARRAY_A );
		}

		return array_map( array( UsageEvent::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return UsageEvent[] Most recent first.
	 */
	public function find_pending( string $product_id ): array {
		global $wpdb;

		$table = Schema::table( 'usage_events' );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
				"SELECT * FROM `{$table}` WHERE product_id = %s AND billing_status = %s ORDER BY id ASC",
				$product_id,
				UsageBillingStatus::Pending->value
			),
			ARRAY_A
		);

		return array_map( array( UsageEvent::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @param array<string,mixed>|null $metadata
	 */
	public function create(
		string $organisation_uuid,
		string $product_id,
		UsageType $usage_type,
		int $quantity,
		string $unit,
		?string $source_object_type,
		?string $source_object_uuid,
		?array $metadata
	): UsageEvent {
		global $wpdb;

		$table = Schema::table( 'usage_events' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'usage_uuid'         => wp_generate_uuid4(),
				'organisation_uuid'  => $organisation_uuid,
				'product_id'         => $product_id,
				'source_object_type' => $source_object_type,
				'source_object_uuid' => $source_object_uuid,
				'usage_type'         => $usage_type->value,
				'quantity'           => $quantity,
				'unit'               => $unit,
				'occurred_at'        => current_time( 'mysql', true ),
				'billing_status'     => UsageBillingStatus::Pending->value,
				'metadata_json'      => null !== $metadata ? wp_json_encode( $metadata ) : null,
				'created_at'         => current_time( 'mysql', true ),
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function mark_acknowledged( string $usage_uuid, string $halo_reference ): UsageEvent {
		global $wpdb;

		$table = Schema::table( 'usage_events' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'halo_reference' => $halo_reference,
				'billing_status' => UsageBillingStatus::Invoiced->value,
			),
			array( 'usage_uuid' => $usage_uuid )
		);

		return $this->find_by_uuid_or_fail( $usage_uuid );
	}

	private function find_or_fail( int $id ): UsageEvent {
		$event = $this->find( $id );

		if ( null === $event ) {
			throw new \RuntimeException( esc_html( "Usage event {$id} was expected to exist but could not be loaded." ) );
		}

		return $event;
	}

	private function find_by_uuid_or_fail( string $usage_uuid ): UsageEvent {
		$event = $this->find_by_uuid( $usage_uuid );

		if ( null === $event ) {
			throw new \RuntimeException( esc_html( "Usage event {$usage_uuid} was expected to exist but could not be loaded." ) );
		}

		return $event;
	}
}
