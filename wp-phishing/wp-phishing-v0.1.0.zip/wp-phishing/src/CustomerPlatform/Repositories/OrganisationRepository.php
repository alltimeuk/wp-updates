<?php
/**
 * Persistence for organisations against `atcp_organisations`.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Enums\OrganisationStatus;
use Alltime\CustomerPlatform\Organisation;
use Alltime\CustomerPlatform\OrganisationInput;
use Alltime\CustomerPlatform\Schema;

final class OrganisationRepository {

	public function find( int $id ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	public function find_by_uuid( string $organisation_uuid ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s", $organisation_uuid ), ARRAY_A );

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	public function find_by_slug( string $slug ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE slug = %s", $slug ), ARRAY_A );

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	/**
	 * Every organisation, newest first - the Alltime-staff admin listing (Section 67), which
	 * (unlike a customer's own view) is never scoped to a single organisation.
	 *
	 * @return Organisation[]
	 */
	public function find_all( int $per_page, int $page ): array {
		global $wpdb;

		$table  = Schema::table( 'organisations' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A );

		return array_map( array( Organisation::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function count_all(): int {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input; no bindable parameters exist for this query, so there is nothing to pass through prepare().
	}

	public function create( OrganisationInput $input ): Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );
		$now   = current_time( 'mysql', true );
		$slug  = $this->unique_slug( $input->slug ?? $input->name );

		$data = array(
			'organisation_uuid'    => wp_generate_uuid4(),
			'name'                 => $input->name,
			'slug'                 => $slug,
			'status'               => OrganisationStatus::Prospect->value,
			'primary_contact_uuid' => $input->primary_contact_uuid,
			'timezone'             => $input->timezone,
			'retention_policy'     => $input->retention_policy,
			'halo_client_id'       => $input->halo_client_id,
			'created_at'           => $now,
			'updated_at'           => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update_details( int $id, OrganisationInput $input ): Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'name'                 => $input->name,
				'primary_contact_uuid' => $input->primary_contact_uuid,
				'timezone'             => $input->timezone,
				'retention_policy'     => $input->retention_policy,
				'halo_client_id'       => $input->halo_client_id,
				'updated_at'           => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function update_status( int $id, OrganisationStatus $status ): Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	/**
	 * Appends a numeric suffix until the slug is unique. Organisation slugs are a customer-facing
	 * identifier (Section 8) but never the cross-product reference - that's always the UUID - so
	 * a suffixed fallback here has no correctness impact outside this table.
	 */
	private function unique_slug( string $seed ): string {
		$base = sanitize_title( $seed );
		$base = '' !== $base ? $base : 'organisation';
		$slug = $base;
		$i    = 1;

		while ( null !== $this->find_by_slug( $slug ) ) {
			++$i;
			$slug = "{$base}-{$i}";
		}

		return $slug;
	}

	private function find_or_fail( int $id ): Organisation {
		$organisation = $this->find( $id );

		if ( null === $organisation ) {
			throw new \RuntimeException( esc_html( "Organisation {$id} was expected to exist but could not be loaded." ) );
		}

		return $organisation;
	}
}
