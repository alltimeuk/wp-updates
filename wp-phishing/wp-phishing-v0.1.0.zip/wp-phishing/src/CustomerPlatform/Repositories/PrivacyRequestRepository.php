<?php
/**
 * Persistence for privacy requests against `atcp_privacy_requests`, per Section 53. The table
 * itself has existed since this schema's version 2 - this is its first repository.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Enums\PrivacyRequestStatus;
use Alltime\CustomerPlatform\Enums\PrivacyRightType;
use Alltime\CustomerPlatform\PrivacyRequest;
use Alltime\CustomerPlatform\Schema;

final class PrivacyRequestRepository {

	private const DEFAULT_RESPONSE_WINDOW_DAYS = 30;

	public function find( int $id ): ?PrivacyRequest {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? PrivacyRequest::from_row( $row ) : null;
	}

	public function find_by_uuid( string $request_uuid ): ?PrivacyRequest {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE request_uuid = %s", $request_uuid ), ARRAY_A );

		return null !== $row ? PrivacyRequest::from_row( $row ) : null;
	}

	/**
	 * @return PrivacyRequest[] Most recent first.
	 */
	public function find_all( int $limit = 200 ): array {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );

		return array_map( array( PrivacyRequest::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create( string $email, PrivacyRightType $right_type, string $channel, ?string $details ): PrivacyRequest {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );
		$now   = current_time( 'mysql', true );
		$due   = ( new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) )->modify( '+' . self::DEFAULT_RESPONSE_WINDOW_DAYS . ' days' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'request_uuid' => wp_generate_uuid4(),
				'email'        => $email,
				'right_type'   => $right_type->value,
				'status'       => PrivacyRequestStatus::Received->value,
				'channel'      => $channel,
				'details'      => $details,
				'due_at'       => $due->format( 'Y-m-d H:i:s' ),
				'created_at'   => $now,
				'updated_at'   => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update_status( int $id, PrivacyRequestStatus $status ): PrivacyRequest {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );
		$data  = array(
			'status'     => $status->value,
			'updated_at' => current_time( 'mysql', true ),
		);

		if ( PrivacyRequestStatus::Completed === $status ) {
			$data['completed_at'] = current_time( 'mysql', true );
		}

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): PrivacyRequest {
		$request = $this->find( $id );

		if ( null === $request ) {
			throw new \RuntimeException( esc_html( "Privacy request {$id} was expected to exist but could not be loaded." ) );
		}

		return $request;
	}
}
