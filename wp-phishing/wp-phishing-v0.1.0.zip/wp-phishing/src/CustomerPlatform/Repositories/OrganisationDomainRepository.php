<?php
/**
 * Persistence for organisation domains against `atcp_organisation_domains`.
 *
 * Every read joins against `atcp_organisations` so callers only ever see the stable
 * `organisation_uuid`, never the internal `organisation_id` foreign key this table stores.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Enums\DomainStatus;
use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;
use Alltime\CustomerPlatform\OrganisationDomain;
use Alltime\CustomerPlatform\Schema;

final class OrganisationDomainRepository {

	private function select_with_joins(): string {
		$domains       = Schema::table( 'organisation_domains' );
		$organisations = Schema::table( 'organisations' );

		return "SELECT d.*, o.organisation_uuid AS organisation_uuid
			FROM `{$domains}` d
			INNER JOIN `{$organisations}` o ON o.id = d.organisation_id";
	}

	public function find_by_uuid( string $domain_uuid ): ?OrganisationDomain {
		global $wpdb;

		$select = $this->select_with_joins();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $select is this class's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$row = $wpdb->get_row( $wpdb->prepare( $select . ' WHERE d.domain_uuid = %s', $domain_uuid ), ARRAY_A );

		return null !== $row ? OrganisationDomain::from_row( $row ) : null;
	}

	public function find_by_ascii( string $domain_ascii ): ?OrganisationDomain {
		global $wpdb;

		$select = $this->select_with_joins();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $select is this class's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$row = $wpdb->get_row( $wpdb->prepare( $select . ' WHERE d.domain_ascii = %s', $domain_ascii ), ARRAY_A );

		return null !== $row ? OrganisationDomain::from_row( $row ) : null;
	}

	/**
	 * Every domain with an outstanding DNS TXT challenge, oldest request first, capped at
	 * $limit - the background verification sweep's entry point. Not part of
	 * {@see \Alltime\CustomerPlatform\OrganisationServiceInterface}: it is a bulk, cross-
	 * organisation operational query, not a per-organisation lookup a cross-product consumer
	 * would ever need, so it stays a repository-only helper.
	 *
	 * @return OrganisationDomain[]
	 */
	public function find_pending_verification( int $limit ): array {
		global $wpdb;

		$select = $this->select_with_joins();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $select is this class's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $select . " WHERE d.verification_status = 'pending' AND d.verification_reference IS NOT NULL ORDER BY d.verification_requested_at ASC LIMIT %d", $limit ), ARRAY_A );

		return array_map( array( OrganisationDomain::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return OrganisationDomain[]
	 */
	public function find_all_for_organisation( int $organisation_id ): array {
		global $wpdb;

		$select = $this->select_with_joins();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $select is this class's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $select . ' WHERE d.organisation_id = %d ORDER BY d.id ASC', $organisation_id ), ARRAY_A );

		return array_map( array( OrganisationDomain::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create(
		int $organisation_id,
		string $domain_ascii,
		string $domain_display,
		?string $registrable_domain,
		DomainVerificationMethod $verification_method
	): OrganisationDomain {
		global $wpdb;

		$table = Schema::table( 'organisation_domains' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'domain_uuid'         => wp_generate_uuid4(),
			'organisation_id'     => $organisation_id,
			'domain_ascii'        => $domain_ascii,
			'domain_display'      => $domain_display,
			'registrable_domain'  => $registrable_domain,
			'status'              => DomainStatus::Active->value,
			'verification_method' => $verification_method->value,
			'verification_status' => DomainVerificationStatus::Pending->value,
			'created_at'          => $now,
			'updated_at'          => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail_by_uuid( (string) $data['domain_uuid'] );
	}

	public function record_verification(
		string $domain_uuid,
		DomainVerificationStatus $status,
		?string $verification_reference,
		?int $requested_by = null
	): OrganisationDomain {
		global $wpdb;

		$table = Schema::table( 'organisation_domains' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'verification_status'    => $status->value,
			'verification_reference' => $verification_reference,
			'updated_at'             => $now,
		);

		if ( DomainVerificationStatus::Verified === $status ) {
			$data['verified_at'] = $now;
		} elseif ( DomainVerificationStatus::Pending === $status ) {
			// A (re)started DNS TXT challenge - see DomainVerificationService::generate_challenge().
			$data['verification_requested_at'] = $now;
			$data['verification_requested_by'] = $requested_by;
		}

		$wpdb->update( $table, $data, array( 'domain_uuid' => $domain_uuid ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail_by_uuid( $domain_uuid );
	}

	private function find_or_fail_by_uuid( string $domain_uuid ): OrganisationDomain {
		$domain = $this->find_by_uuid( $domain_uuid );

		if ( null === $domain ) {
			throw new \RuntimeException( esc_html( "Organisation domain {$domain_uuid} was expected to exist but could not be loaded." ) );
		}

		return $domain;
	}
}
