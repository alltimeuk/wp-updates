<?php
/**
 * The result of {@see EntitlementPolicy::decide()}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class EntitlementDecision {

	public function __construct(
		public readonly bool $allowed,
		public readonly string $reason,
		public readonly ?Entitlement $entitlement = null
	) {}
}
