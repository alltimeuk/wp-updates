<?php
/**
 * The concrete {@see UsageServiceInterface} implementation currently shipped inside WP-Phishing.
 * Never instantiated directly by consuming code - always go through
 * {@see UsagePlatformDiscovery::resolve()}, exactly as an external plugin would once this becomes
 * its own component (Section 81).
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\UsageType;
use Alltime\CustomerPlatform\Repositories\UsageEventRepository;

final class UsageService implements UsageServiceInterface {

	public function __construct(
		private readonly UsageEventRepository $events = new UsageEventRepository()
	) {}

	public function record(
		string $organisation_uuid,
		string $product_id,
		UsageType $usage_type,
		int $quantity,
		string $unit,
		?string $source_object_type = null,
		?string $source_object_uuid = null,
		?array $metadata = null
	): UsageEvent {
		$event = $this->events->create( $organisation_uuid, $product_id, $usage_type, $quantity, $unit, $source_object_type, $source_object_uuid, $metadata );

		do_action( 'alltime_usage_recorded', $organisation_uuid, $product_id, $usage_type->value, $quantity );

		return $event;
	}

	public function find_for_organisation( string $organisation_uuid, ?string $product_id = null ): array {
		return $this->events->find_for_organisation( $organisation_uuid, $product_id );
	}

	public function find_pending( string $product_id ): array {
		return $this->events->find_pending( $product_id );
	}

	public function mark_acknowledged( string $usage_uuid, string $halo_reference ): UsageEvent {
		$event = $this->events->mark_acknowledged( $usage_uuid, $halo_reference );

		do_action( 'alltime_usage_acknowledged', $event->organisation_uuid, $event->product_id, $usage_uuid, $halo_reference );

		return $event;
	}
}
