<?php
/**
 * One immutable, objective usage fact, per Section 49: "Commercial usage is a shared logical
 * resource. Each repository may implement the contract independently." Never updated after
 * creation - a correction is a new row, not an edit, matching this codebase's established
 * "frozen artefact" convention elsewhere (e.g. campaign reports).
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\UsageBillingStatus;
use Alltime\CustomerPlatform\Enums\UsageType;

final class UsageEvent {

	public function __construct(
		public readonly int $id,
		public readonly string $usage_uuid,
		public readonly string $organisation_uuid,
		public readonly string $product_id,
		public readonly ?string $source_object_type,
		public readonly ?string $source_object_uuid,
		public readonly UsageType $usage_type,
		public readonly int $quantity,
		public readonly string $unit,
		public readonly \DateTimeImmutable $occurred_at,
		public readonly UsageBillingStatus $billing_status,
		public readonly ?string $halo_reference,
		/** @var array<string,mixed> */
		public readonly array $metadata,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$metadata = ! empty( $row['metadata_json'] ) ? json_decode( (string) $row['metadata_json'], true ) : array();

		return new self(
			id: (int) $row['id'],
			usage_uuid: (string) $row['usage_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			product_id: (string) $row['product_id'],
			source_object_type: ! empty( $row['source_object_type'] ) ? (string) $row['source_object_type'] : null,
			source_object_uuid: ! empty( $row['source_object_uuid'] ) ? (string) $row['source_object_uuid'] : null,
			usage_type: UsageType::from( (string) $row['usage_type'] ),
			quantity: (int) $row['quantity'],
			unit: (string) $row['unit'],
			occurred_at: new \DateTimeImmutable( (string) $row['occurred_at'], new \DateTimeZone( 'UTC' ) ),
			billing_status: UsageBillingStatus::from( (string) $row['billing_status'] ),
			halo_reference: ! empty( $row['halo_reference'] ) ? (string) $row['halo_reference'] : null,
			metadata: is_array( $metadata ) ? $metadata : array(),
			created_at: new \DateTimeImmutable( (string) $row['created_at'], new \DateTimeZone( 'UTC' ) )
		);
	}
}
