<?php
/**
 * Canonical organisation entity, per Section 8.
 *
 * A shared logical resource, not owned conceptually by a single product (Section 4/80).
 * {@see Organisation::$organisation_uuid} is the immutable, public-safe cross-product
 * identifier; {@see Organisation::$id} is the internal numeric one, meaningful only to
 * whichever provider's tables are authoritative on this install.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\OrganisationStatus;

final class Organisation {

	public function __construct(
		public readonly int $id,
		public readonly string $organisation_uuid,
		public readonly string $name,
		public readonly string $slug,
		public readonly OrganisationStatus $status,
		public readonly ?string $primary_contact_uuid,
		public readonly string $timezone,
		public readonly ?string $retention_policy,
		public readonly ?string $halo_client_id,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			organisation_uuid: (string) $row['organisation_uuid'],
			name: (string) $row['name'],
			slug: (string) $row['slug'],
			status: OrganisationStatus::from( (string) $row['status'] ),
			primary_contact_uuid: ! empty( $row['primary_contact_uuid'] ) ? (string) $row['primary_contact_uuid'] : null,
			timezone: (string) $row['timezone'],
			retention_policy: ! empty( $row['retention_policy'] ) ? (string) $row['retention_policy'] : null,
			halo_client_id: ! empty( $row['halo_client_id'] ) ? (string) $row['halo_client_id'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
