<?php
/**
 * The concrete {@see OrganisationServiceInterface} implementation currently shipped inside
 * WP-Phishing. Never instantiated directly by consuming code - always go through
 * {@see OrganisationPlatformDiscovery::resolve()}, exactly as an external plugin would once
 * this becomes its own component (Section 81).
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;
use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;
use Alltime\CustomerPlatform\Enums\OrganisationStatus;
use Alltime\CustomerPlatform\Repositories\ContactRepository;
use Alltime\CustomerPlatform\Repositories\OrganisationDomainRepository;
use Alltime\CustomerPlatform\Repositories\OrganisationMembershipRepository;
use Alltime\CustomerPlatform\Repositories\OrganisationRepository;

final class OrganisationService implements OrganisationServiceInterface {

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly OrganisationMembershipRepository $members = new OrganisationMembershipRepository(),
		private readonly OrganisationDomainRepository $domains = new OrganisationDomainRepository(),
		private readonly ContactRepository $contacts = new ContactRepository()
	) {}

	public function create_or_update_organisation( OrganisationInput $input ): OrganisationResult {
		if ( null !== $input->primary_contact_uuid ) {
			$existing = $this->find_by_primary_contact( $input->primary_contact_uuid );

			if ( null !== $existing ) {
				$updated = $this->organisations->update_details( $existing->id, $input );

				do_action( 'alltime_organisation_updated', $updated->organisation_uuid, $input );

				return new OrganisationResult( $updated, false );
			}
		}

		$organisation = $this->organisations->create( $input );

		do_action( 'alltime_organisation_created', $organisation->organisation_uuid, $input );

		return new OrganisationResult( $organisation, true );
	}

	public function get_by_uuid( string $organisation_uuid ): ?Organisation {
		return $this->organisations->find_by_uuid( $organisation_uuid );
	}

	public function get_membership( string $organisation_uuid, int $wordpress_user_id ): ?OrganisationMembership {
		$organisation = $this->organisations->find_by_uuid( $organisation_uuid );

		if ( null === $organisation ) {
			return null;
		}

		return $this->members->find_for_user( $organisation->id, $wordpress_user_id );
	}

	public function get_memberships_for_user( int $wordpress_user_id ): array {
		return $this->members->find_all_for_user( $wordpress_user_id );
	}

	public function add_member(
		string $organisation_uuid,
		int $wordpress_user_id,
		MembershipRole $role,
		?string $contact_uuid = null,
		?int $invited_by = null
	): OrganisationMembership {
		$organisation = $this->organisations->find_by_uuid( $organisation_uuid );

		if ( null === $organisation ) {
			throw new \InvalidArgumentException( esc_html( "Unknown organisation UUID: {$organisation_uuid}" ) );
		}

		$contact_id = null !== $contact_uuid ? $this->contacts->find_by_uuid( $contact_uuid )?->id : null;

		$membership = $this->members->create( $organisation->id, $wordpress_user_id, $role, $contact_id, $invited_by );

		do_action( 'alltime_organisation_member_added', $organisation_uuid, $wordpress_user_id, $role->value );

		return $membership;
	}

	public function update_member_status( int $membership_id, MembershipStatus $status ): void {
		$membership = $this->members->update_status( $membership_id, $status );

		do_action( 'alltime_organisation_member_status_changed', $membership->organisation_uuid, $membership->wordpress_user_id, $status->value );
	}

	public function update_member_role( int $membership_id, MembershipRole $role ): void {
		$membership = $this->members->update_role( $membership_id, $role );

		do_action( 'alltime_organisation_member_role_changed', $membership->organisation_uuid, $membership->wordpress_user_id, $role->value );
	}

	public function add_domain(
		string $organisation_uuid,
		string $domain_ascii,
		DomainVerificationMethod $verification_method
	): OrganisationDomain {
		$organisation = $this->organisations->find_by_uuid( $organisation_uuid );

		if ( null === $organisation ) {
			throw new \InvalidArgumentException( esc_html( "Unknown organisation UUID: {$organisation_uuid}" ) );
		}

		$normalised = $this->normalise_domain( $domain_ascii );

		// Registrable-domain resolution against a public suffix list is the Verification
		// module's responsibility (Section 11, Phase 1) - it owns the jeremykendall/php-domain-
		// parser wiring. This contract only records what it's given.
		$domain = $this->domains->create( $organisation->id, $normalised, $domain_ascii, null, $verification_method );

		do_action( 'alltime_organisation_domain_added', $organisation_uuid, $domain->domain_uuid );

		return $domain;
	}

	public function get_domains( string $organisation_uuid ): array {
		$organisation = $this->organisations->find_by_uuid( $organisation_uuid );

		if ( null === $organisation ) {
			return array();
		}

		return $this->domains->find_all_for_organisation( $organisation->id );
	}

	public function get_domain( string $domain_uuid ): ?OrganisationDomain {
		return $this->domains->find_by_uuid( $domain_uuid );
	}

	public function find_domain_by_ascii( string $domain_ascii ): ?OrganisationDomain {
		return $this->domains->find_by_ascii( $this->normalise_domain( $domain_ascii ) );
	}

	public function record_domain_verification(
		string $domain_uuid,
		DomainVerificationStatus $status,
		?string $verification_reference = null,
		?int $requested_by = null
	): void {
		$domain = $this->domains->record_verification( $domain_uuid, $status, $verification_reference, $requested_by );

		do_action( 'alltime_organisation_domain_verification_changed', $domain->organisation_uuid, $domain_uuid, $status->value );
	}

	private function normalise_domain( string $domain ): string {
		return strtolower( trim( $domain ) );
	}

	private function find_by_primary_contact( string $contact_uuid ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE primary_contact_uuid = %s", $contact_uuid ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return null !== $row ? Organisation::from_row( $row ) : null;
	}
}
