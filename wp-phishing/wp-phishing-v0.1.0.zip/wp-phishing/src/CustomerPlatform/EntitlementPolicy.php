<?php
/**
 * Pure entitlement decision logic, per Section 50 and Section 6.1.1's "pure decision logic /
 * I/O" split (the same shape wp-reconnaissance's own entitlement service already uses).
 * Deliberately separate from {@see EntitlementService} (which does the actual database reads/
 * writes) so the decision itself is fully unit-tested without a database: given an organisation's
 * entitlement history for one product, is a campaign of the given size currently coverable, and by
 * which entitlement?
 *
 * Scoped for this increment: the first non-terminal, non-expired, sufficiently-capacious
 * entitlement in $history wins - callers are responsible for ordering $history by whatever
 * priority they want honoured (e.g. soonest-expiring first), since a real commercial model may
 * eventually want a specific priority between simultaneously-held entitlement types; that ordering
 * policy is deliberately left to the caller rather than hard-coded here.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class EntitlementPolicy {

	/**
	 * @param Entitlement[] $history Every current entitlement for this organisation/product, in
	 *                                 the caller's preferred priority order. Empty means none held.
	 */
	public function decide( array $history, int $requested_quantity = 1, ?\DateTimeImmutable $now = null ): EntitlementDecision {
		$now = $now ?? new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );

		foreach ( $history as $entitlement ) {
			if ( $entitlement->state->is_terminal() ) {
				continue;
			}

			if ( $entitlement->is_expired( $now ) ) {
				continue;
			}

			if ( ! $entitlement->has_capacity_for( $requested_quantity ) ) {
				continue;
			}

			return new EntitlementDecision( true, 'entitlement_available', $entitlement );
		}

		return new EntitlementDecision( false, 'no_valid_entitlement' );
	}
}
