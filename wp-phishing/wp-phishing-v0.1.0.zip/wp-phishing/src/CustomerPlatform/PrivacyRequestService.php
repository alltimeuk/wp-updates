<?php
/**
 * Privacy rights request lifecycle, per Section 53. Admin-initiated only for this increment (an
 * operator receives a request through an external channel - email, a form, a phone call - and
 * logs it here); the spec does not require self-service submission, and building a public-facing
 * verification-of-identity flow is materially more scope than logging and fulfilling requests an
 * operator already knows are genuine.
 *
 * Deliberately a plain concrete class, not a discoverable `*ServiceInterface` contract like
 * {@see OrganisationService}/{@see UsageService}/{@see EntitlementService} - nothing in this
 * session's scope needs another plugin to resolve this cross-boundary, and `atcp_privacy_requests`
 * has lived in this shared schema since version 2 regardless.
 *
 * "Deletion" is implemented as anonymisation, not a literal row DELETE across every table a
 * contact is referenced from - Section 53 itself permits this ("aggregate statistics may remain
 * after personal identifiers are anonymised"), and a true cascading hard-delete would need to
 * reason about every product's own evidence/audit retention obligations, which this service
 * cannot know about from inside the shared platform layer.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\IdentityType;
use Alltime\CustomerPlatform\Enums\PrivacyRequestStatus;
use Alltime\CustomerPlatform\Enums\PrivacyRightType;
use Alltime\CustomerPlatform\Repositories\ContactIdentityRepository;
use Alltime\CustomerPlatform\Repositories\ContactRepository;
use Alltime\CustomerPlatform\Repositories\PrivacyRequestRepository;

final class PrivacyRequestService {

	public function __construct(
		private readonly PrivacyRequestRepository $requests = new PrivacyRequestRepository(),
		private readonly ContactRepository $contacts = new ContactRepository(),
		private readonly ContactIdentityRepository $identities = new ContactIdentityRepository()
	) {}

	public function log_request( string $email, PrivacyRightType $right_type, string $channel, ?string $details = null ): PrivacyRequest {
		return $this->requests->create( strtolower( trim( $email ) ), $right_type, $channel, $details );
	}

	/**
	 * @return PrivacyRequest[]
	 */
	public function list_all(): array {
		return $this->requests->find_all();
	}

	public function get( string $request_uuid ): ?PrivacyRequest {
		return $this->requests->find_by_uuid( $request_uuid );
	}

	public function mark_in_progress( string $request_uuid ): void {
		$request = $this->requests->find_by_uuid( $request_uuid );

		if ( null !== $request ) {
			$this->requests->update_status( $request->id, PrivacyRequestStatus::InProgress );
		}
	}

	public function reject( string $request_uuid ): void {
		$request = $this->requests->find_by_uuid( $request_uuid );

		if ( null !== $request ) {
			$this->requests->update_status( $request->id, PrivacyRequestStatus::Rejected );
		}
	}

	/**
	 * Fulfils discovery/export: every record this shared platform holds against $email. Callers
	 * needing product-specific data (e.g. wp-phishing's own recipient/delivery history) must
	 * gather that separately - this only covers what `Alltime\CustomerPlatform` itself owns.
	 *
	 * @return array<string,mixed>|null Null if no contact is found for this email at all.
	 */
	public function export_personal_data( string $email ): ?array {
		$contact = $this->find_contact_by_email( $email );

		if ( null === $contact ) {
			return null;
		}

		return array(
			'contact_uuid'     => $contact->contact_uuid,
			'given_name'       => $contact->given_name,
			'family_name'      => $contact->family_name,
			'lifecycle_status' => $contact->lifecycle_status->value,
			'created_at'       => $contact->created_at->format( DATE_ATOM ),
			'verified_at'      => $contact->verified_at?->format( DATE_ATOM ),
			'identities'       => array_map(
				static fn ( ContactIdentity $identity ): array => array(
					'type'        => $identity->identity_type->value,
					'value'       => $identity->normalised_value,
					'is_primary'  => $identity->is_primary,
					'is_verified' => $identity->is_verified,
				),
				$this->identities->find_all_for_contact( $contact->id )
			),
		);
	}

	/**
	 * Fulfils anonymisation/deletion: overwrites the contact's own PII and removes every identity
	 * (email/telephone) that could otherwise still resolve back to them. Returns false if no
	 * contact exists for this email - callers must not treat that as an error, an already-anonymised
	 * or never-registered email is a legitimate outcome.
	 */
	public function anonymise_by_email( string $email ): bool {
		$contact = $this->find_contact_by_email( $email );

		if ( null === $contact ) {
			return false;
		}

		$this->identities->delete_for_contact( $contact->id );
		$this->contacts->anonymise( $contact->id );

		return true;
	}

	public function complete( string $request_uuid ): void {
		$request = $this->requests->find_by_uuid( $request_uuid );

		if ( null !== $request ) {
			$this->requests->update_status( $request->id, PrivacyRequestStatus::Completed );
		}
	}

	private function find_contact_by_email( string $email ): ?Contact {
		$identity = $this->identities->find_by_value( IdentityType::Email, strtolower( trim( $email ) ) );

		return null !== $identity ? $this->contacts->find( $identity->contact_id ) : null;
	}
}
