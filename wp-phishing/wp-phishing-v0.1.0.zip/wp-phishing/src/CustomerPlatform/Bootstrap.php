<?php
/**
 * The Customer Platform's own bootstrap: registers itself as the contact-service, visitor-
 * context-service, organisation-service, usage-service and entitlement-service provider.
 *
 * Runs before any module that might resolve {@see ContactPlatformDiscovery::resolve()},
 * {@see OrganisationPlatformDiscovery::resolve()}, {@see UsagePlatformDiscovery::resolve()} or
 * {@see EntitlementPlatformDiscovery::resolve()} - see call order in
 * {@see \Alltime\WPPhishing\Support\Plugin::boot()}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class Bootstrap {

	public function boot(): void {
		ContactPlatformDiscovery::provide( new ContactService() );
		VisitorContextPlatformDiscovery::provide( new VisitorContextService() );
		OrganisationPlatformDiscovery::provide( new OrganisationService() );
		UsagePlatformDiscovery::provide( new UsageService() );
		EntitlementPlatformDiscovery::provide( new EntitlementService() );
	}
}
