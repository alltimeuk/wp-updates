<?php
/**
 * Organisation domain entity, per Section 10.
 *
 * A shared logical resource usable by WP-Reconnaissance, WP-Phishing and future Alltime
 * products (Section 10). `domain_uuid` is the public-safe cross-product identifier.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\DomainStatus;
use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;

final class OrganisationDomain {

	public function __construct(
		public readonly int $id,
		public readonly string $domain_uuid,
		public readonly string $organisation_uuid,
		public readonly string $domain_ascii,
		public readonly string $domain_display,
		public readonly ?string $registrable_domain,
		public readonly DomainStatus $status,
		public readonly ?DomainVerificationMethod $verification_method,
		public readonly DomainVerificationStatus $verification_status,
		public readonly ?string $verification_reference,
		public readonly ?\DateTimeImmutable $verification_requested_at,
		public readonly ?int $verification_requested_by,
		public readonly ?\DateTimeImmutable $verified_at,
		public readonly ?\DateTimeImmutable $verification_expires_at,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by a join against atcp_organisations.
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			domain_uuid: (string) $row['domain_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			domain_ascii: (string) $row['domain_ascii'],
			domain_display: (string) $row['domain_display'],
			registrable_domain: ! empty( $row['registrable_domain'] ) ? (string) $row['registrable_domain'] : null,
			status: DomainStatus::from( (string) $row['status'] ),
			verification_method: ! empty( $row['verification_method'] ) ? DomainVerificationMethod::from( (string) $row['verification_method'] ) : null,
			verification_status: DomainVerificationStatus::from( (string) $row['verification_status'] ),
			verification_reference: ! empty( $row['verification_reference'] ) ? (string) $row['verification_reference'] : null,
			verification_requested_at: ! empty( $row['verification_requested_at'] ) ? new \DateTimeImmutable( (string) $row['verification_requested_at'] ) : null,
			verification_requested_by: ! empty( $row['verification_requested_by'] ) ? (int) $row['verification_requested_by'] : null,
			verified_at: ! empty( $row['verified_at'] ) ? new \DateTimeImmutable( (string) $row['verified_at'] ) : null,
			verification_expires_at: ! empty( $row['verification_expires_at'] ) ? new \DateTimeImmutable( (string) $row['verification_expires_at'] ) : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
