<?php
/**
 * Where one usage event stands in the (deliberately product-agnostic) billing lifecycle,
 * per Section 46: "Campaign execution shall produce objective usage facts. Billing rules shall be
 * separate." This plugin never sets anything beyond Pending itself - Invoiced/Waived are set by
 * whatever downstream billing process consumes the ledger (Section 51: HaloPSA, or an operator).
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum UsageBillingStatus: string {
	case Pending  = 'pending';
	case Invoiced = 'invoiced';
	case Waived   = 'waived';
}
