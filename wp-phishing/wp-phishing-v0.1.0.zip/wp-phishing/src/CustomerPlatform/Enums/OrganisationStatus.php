<?php
/**
 * Organisation lifecycle status, per Section 8.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum OrganisationStatus: string {
	case Prospect  = 'prospect';
	case Active    = 'active';
	case Suspended = 'suspended';
	case Closed    = 'closed';
	case Merged    = 'merged';
}
