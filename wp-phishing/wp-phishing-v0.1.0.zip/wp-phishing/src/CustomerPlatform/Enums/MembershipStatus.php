<?php
/**
 * Organisation membership status, per Section 9's invited_at/accepted_at/revoked_at lifecycle.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum MembershipStatus: string {
	case Invited   = 'invited';
	case Active    = 'active';
	case Suspended = 'suspended';
	case Revoked   = 'revoked';
}
