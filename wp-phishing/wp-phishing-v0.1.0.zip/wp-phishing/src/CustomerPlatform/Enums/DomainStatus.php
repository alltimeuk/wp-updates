<?php
/**
 * Organisation domain lifecycle status, per Section 10.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum DomainStatus: string {
	case Active  = 'active';
	case Retired = 'retired';
}
