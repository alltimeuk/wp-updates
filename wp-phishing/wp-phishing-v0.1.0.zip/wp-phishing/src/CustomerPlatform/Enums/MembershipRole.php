<?php
/**
 * Organisation membership role, per Section 9. Deliberately coarse and shared across every
 * Alltime product - a product's own capability model (e.g. WP-Phishing's `wpp_*` capabilities,
 * Section 66) further restricts what a given role may do inside that product.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum MembershipRole: string {
	case Owner           = 'owner';
	case Administrator   = 'administrator';
	case CampaignManager = 'campaign_manager';
	case Analyst         = 'analyst';
	case Viewer          = 'viewer';
	case Billing         = 'billing';
}
