<?php
/**
 * The kind of billable fact one usage event records, per Section 49's worked examples
 * (`wp-phishing / campaign / 1`, `wp-phishing / unique_recipient / 500`,
 * `wp-phishing / delivered_message / 1500`).
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum UsageType: string {
	case Campaign         = 'campaign';
	case UniqueRecipient  = 'unique_recipient';
	case DeliveredMessage = 'delivered_message';
}
