<?php
/**
 * What kind of allowance or grant an entitlement represents, per Section 50's supported types:
 * "trial, single_campaign, campaign_bundle, recipient_allowance, message_allowance, subscription,
 * managed_service, administrator_grant, unlimited_internal."
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum EntitlementType: string {
	case Trial              = 'trial';
	case SingleCampaign     = 'single_campaign';
	case CampaignBundle     = 'campaign_bundle';
	case RecipientAllowance = 'recipient_allowance';
	case MessageAllowance   = 'message_allowance';
	case Subscription       = 'subscription';
	case ManagedService     = 'managed_service';
	case AdministratorGrant = 'administrator_grant';
	case UnlimitedInternal  = 'unlimited_internal';

	/**
	 * Whether this type is a fixed capacity pool that quantity is drawn down against
	 * ({@see EntitlementState::PartiallyConsumed} is only ever reachable for these). The others
	 * are one-shot (single_campaign) or unbounded (managed_service, unlimited_internal) - a null
	 * `allowance_quantity` on the entitlement row is what actually encodes "unbounded" at runtime;
	 * this only describes which types are expected to carry a real allowance.
	 */
	public function is_quantity_based(): bool {
		return in_array( $this, array( self::CampaignBundle, self::RecipientAllowance, self::MessageAllowance, self::Subscription ), true );
	}
}
