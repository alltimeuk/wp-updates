<?php
/**
 * Which personal-data right a privacy request exercises, per Section 53: "discovery, export,
 * anonymisation, deletion, suppression." Retention processing and audit-of-privacy-actions from
 * the same section are cross-cutting guarantees, not individually-requestable rights, so they
 * have no case here.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum PrivacyRightType: string {
	case Discovery     = 'discovery';
	case Export        = 'export';
	case Anonymisation = 'anonymisation';
	case Deletion      = 'deletion';
	case Suppression   = 'suppression';
}
