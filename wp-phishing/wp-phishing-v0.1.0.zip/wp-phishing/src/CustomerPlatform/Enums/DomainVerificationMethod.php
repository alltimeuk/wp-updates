<?php
/**
 * Organisation domain verification method, per Section 10.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum DomainVerificationMethod: string {
	case DnsTxt                   = 'dns_txt';
	case AdministratorOverride    = 'administrator_override';
	case ContractualAuthority     = 'contractual_authority';
	case ManagedCustomer          = 'managed_customer';
	case OtherDocumentedAuthority = 'other_documented_authority';
}
