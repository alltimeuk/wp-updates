<?php
/**
 * Entitlement lifecycle state, per Section 50: "available, reserved, partially_consumed,
 * consumed, expired, revoked, suspended."
 *
 * "Available" has no row of its own - the absence of any active entitlement record for an
 * organisation/product/type combination *is* the available state, mirroring the same convention
 * already established for wp-reconnaissance's own (simpler, one-shot) entitlement model. Every
 * other state is represented by a row.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum EntitlementState: string {
	case Reserved          = 'reserved';
	case PartiallyConsumed = 'partially_consumed';
	case Consumed          = 'consumed';
	case Expired           = 'expired';
	case Revoked           = 'revoked';
	case Suspended         = 'suspended';

	/**
	 * States that no longer grant any capacity - a history search for "the active entitlement"
	 * must skip these regardless of how much allowance they were originally granted.
	 */
	public function is_terminal(): bool {
		return in_array( $this, array( self::Expired, self::Revoked, self::Suspended ), true );
	}
}
