<?php
/**
 * Organisation domain verification status, per Section 10/11.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum DomainVerificationStatus: string {
	case Pending  = 'pending';
	case Verified = 'verified';
	case Failed   = 'failed';
	case Expired  = 'expired';
}
