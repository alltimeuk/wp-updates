<?php
/**
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum PrivacyRequestStatus: string {
	case Received   = 'received';
	case InProgress = 'in_progress';
	case Completed  = 'completed';
	case Rejected   = 'rejected';
}
