<?php
/**
 * Service discovery for the shared usage ledger, per Section 49/80. Mirrors
 * {@see OrganisationPlatformDiscovery} exactly - a WordPress filter is the discovery mechanism
 * precisely because it works the same way whether the provider and consumer are the same plugin
 * (today) or two independent ones (once this is extracted).
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class UsagePlatformDiscovery {

	private const FILTER = 'alltime_customer_platform_usage_service';

	/**
	 * The contract version this class of provider satisfies. Bump the major segment only for a
	 * breaking change to {@see UsageServiceInterface} - {@see resolve()} checks the major segment
	 * only, so minor/patch bumps stay compatible with existing consumers.
	 */
	public const CONTRACT_VERSION = '1.0.0';

	/**
	 * Registers a service instance as the platform's usage-ledger provider. Idempotent by
	 * WordPress filter semantics: the first registration wins, later ones are ignored - only one
	 * plugin should ever own this data.
	 */
	public static function provide( UsageServiceInterface $service, string $version = self::CONTRACT_VERSION ): void {
		add_filter(
			self::FILTER,
			static fn ( mixed $current ): mixed => $current ?? array(
				'service' => $service,
				'version' => $version,
			)
		);
	}

	/**
	 * Resolves the registered usage service, or null if none is registered or the registered
	 * provider's major version does not satisfy $required_major_version. Callers must treat a null
	 * return as "the platform is unavailable" and degrade gracefully - never assume the service
	 * exists.
	 */
	public static function resolve( string $required_major_version = '1' ): ?UsageServiceInterface {
		$registration = apply_filters( self::FILTER, null );

		if ( ! is_array( $registration ) || ! ( $registration['service'] ?? null ) instanceof UsageServiceInterface ) {
			return null;
		}

		$provided_version = (string) ( $registration['version'] ?? '' );

		if ( ! str_starts_with( $provided_version, $required_major_version . '.' ) ) {
			return null;
		}

		return $registration['service'];
	}
}
