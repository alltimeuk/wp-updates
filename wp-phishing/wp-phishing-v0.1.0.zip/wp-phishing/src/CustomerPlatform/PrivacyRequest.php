<?php
/**
 * A logged personal-data rights request, per Section 53. Backed by `atcp_privacy_requests`, a
 * table that has existed since this schema's version 2 (Section 18.1.1/18.1.4) but carried no
 * repository, service or admin surface until now.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\PrivacyRequestStatus;
use Alltime\CustomerPlatform\Enums\PrivacyRightType;

final class PrivacyRequest {

	public function __construct(
		public readonly int $id,
		public readonly string $request_uuid,
		public readonly string $email,
		public readonly PrivacyRightType $right_type,
		public readonly PrivacyRequestStatus $status,
		public readonly string $channel,
		public readonly ?string $details,
		public readonly \DateTimeImmutable $due_at,
		public readonly ?\DateTimeImmutable $completed_at,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			request_uuid: (string) $row['request_uuid'],
			email: (string) $row['email'],
			right_type: PrivacyRightType::from( (string) $row['right_type'] ),
			status: PrivacyRequestStatus::from( (string) $row['status'] ),
			channel: (string) $row['channel'],
			details: ! empty( $row['details'] ) ? (string) $row['details'] : null,
			due_at: new \DateTimeImmutable( (string) $row['due_at'], new \DateTimeZone( 'UTC' ) ),
			completed_at: ! empty( $row['completed_at'] ) ? new \DateTimeImmutable( (string) $row['completed_at'], new \DateTimeZone( 'UTC' ) ) : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'], new \DateTimeZone( 'UTC' ) ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'], new \DateTimeZone( 'UTC' ) )
		);
	}
}
