<?php
/**
 * Organisation membership entity, per Section 9.
 *
 * Explicit membership model - an organisation may have multiple customer users, so this is
 * deliberately not just an `organisation_id` column on a WordPress user. `contact_uuid` and
 * `organisation_uuid` are resolved joins over the internal `contact_id`/`organisation_id`
 * foreign keys, exposed here so any consumer - in this plugin or another - only ever handles
 * the stable cross-product identifiers.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;

final class OrganisationMembership {

	public function __construct(
		public readonly int $id,
		public readonly string $organisation_uuid,
		public readonly ?string $contact_uuid,
		public readonly int $wordpress_user_id,
		public readonly MembershipRole $role,
		public readonly MembershipStatus $status,
		public readonly ?int $invited_by,
		public readonly \DateTimeImmutable $invited_at,
		public readonly ?\DateTimeImmutable $accepted_at,
		public readonly ?\DateTimeImmutable $revoked_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by a join against atcp_organisations and
	 *                                 atcp_contacts (see OrganisationMembershipRepository).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			organisation_uuid: (string) $row['organisation_uuid'],
			contact_uuid: ! empty( $row['contact_uuid'] ) ? (string) $row['contact_uuid'] : null,
			wordpress_user_id: (int) $row['wordpress_user_id'],
			role: MembershipRole::from( (string) $row['role'] ),
			status: MembershipStatus::from( (string) $row['status'] ),
			invited_by: ! empty( $row['invited_by'] ) ? (int) $row['invited_by'] : null,
			invited_at: new \DateTimeImmutable( (string) $row['invited_at'] ),
			accepted_at: ! empty( $row['accepted_at'] ) ? new \DateTimeImmutable( (string) $row['accepted_at'] ) : null,
			revoked_at: ! empty( $row['revoked_at'] ) ? new \DateTimeImmutable( (string) $row['revoked_at'] ) : null
		);
	}
}
