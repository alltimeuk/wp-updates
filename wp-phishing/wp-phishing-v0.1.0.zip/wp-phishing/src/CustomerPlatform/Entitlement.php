<?php
/**
 * An entitlement record, per Section 50. Unlike wp-reconnaissance's simpler, one-shot,
 * per-contact entitlement (one free report per account/domain), wp-phishing's entitlements gate a
 * whole organisation's campaign activity against a quantity-based allowance where the type calls
 * for one ({@see \Alltime\CustomerPlatform\Enums\EntitlementType::is_quantity_based()}) - `null`
 * `allowance_quantity` means unbounded (managed_service, unlimited_internal), never "zero".
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\EntitlementState;
use Alltime\CustomerPlatform\Enums\EntitlementType;

final class Entitlement {

	public function __construct(
		public readonly int $id,
		public readonly string $entitlement_uuid,
		public readonly string $organisation_uuid,
		public readonly string $product_id,
		public readonly EntitlementType $type,
		public readonly EntitlementState $state,
		public readonly ?int $allowance_quantity,
		public readonly int $consumed_quantity,
		public readonly ?int $granted_by,
		public readonly ?string $reason,
		public readonly ?\DateTimeImmutable $expires_at,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * Remaining capacity, or null if this entitlement is unbounded.
	 */
	public function remaining_quantity(): ?int {
		return null !== $this->allowance_quantity ? max( 0, $this->allowance_quantity - $this->consumed_quantity ) : null;
	}

	public function has_capacity_for( int $quantity ): bool {
		$remaining = $this->remaining_quantity();

		return null === $remaining || $remaining >= $quantity;
	}

	public function is_expired( \DateTimeImmutable $now ): bool {
		return null !== $this->expires_at && $now > $this->expires_at;
	}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			entitlement_uuid: (string) $row['entitlement_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			product_id: (string) $row['product_id'],
			type: EntitlementType::from( (string) $row['type'] ),
			state: EntitlementState::from( (string) $row['state'] ),
			allowance_quantity: null !== $row['allowance_quantity'] ? (int) $row['allowance_quantity'] : null,
			consumed_quantity: (int) $row['consumed_quantity'],
			granted_by: ! empty( $row['granted_by'] ) ? (int) $row['granted_by'] : null,
			reason: ! empty( $row['reason'] ) ? (string) $row['reason'] : null,
			expires_at: ! empty( $row['expires_at'] ) ? new \DateTimeImmutable( (string) $row['expires_at'], new \DateTimeZone( 'UTC' ) ) : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'], new \DateTimeZone( 'UTC' ) ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'], new \DateTimeZone( 'UTC' ) )
		);
	}
}
