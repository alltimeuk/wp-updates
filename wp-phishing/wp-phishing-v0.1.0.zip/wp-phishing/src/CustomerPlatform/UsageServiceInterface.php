<?php
/**
 * Shared usage-ledger contract, per Section 49: "Commercial usage is a shared logical resource.
 * Each repository may implement the contract independently." Mirrors
 * {@see OrganisationServiceInterface}'s shape exactly: a product resolves the canonical provider
 * through {@see UsagePlatformDiscovery::resolve()} rather than instantiating an implementation
 * directly.
 *
 * `$product_id` on every method distinguishes which Alltime product recorded or is querying a
 * usage fact (e.g. `'wp-phishing'`) - one physical shared table serves every installed product,
 * not one table per product.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\UsageType;

interface UsageServiceInterface {

	/**
	 * Records one objective usage fact. Never updates an existing row - a correction is a new
	 * event, not an edit (Section 46: "the campaign engine shall not contain hard-coded pricing";
	 * this only records the fact, never a derived charge).
	 *
	 * @param array<string,mixed>|null $metadata
	 */
	public function record(
		string $organisation_uuid,
		string $product_id,
		UsageType $usage_type,
		int $quantity,
		string $unit,
		?string $source_object_type = null,
		?string $source_object_uuid = null,
		?array $metadata = null
	): UsageEvent;

	/**
	 * @return UsageEvent[] Most recent first.
	 */
	public function find_for_organisation( string $organisation_uuid, ?string $product_id = null ): array;

	/**
	 * Events not yet acknowledged by a downstream billing/PSA consumer (Section 51's
	 * pending/start/acknowledge/fail lifecycle, applied to usage rather than a plugin-specific
	 * resource).
	 *
	 * @return UsageEvent[]
	 */
	public function find_pending( string $product_id ): array;

	public function mark_acknowledged( string $usage_uuid, string $halo_reference ): UsageEvent;
}
