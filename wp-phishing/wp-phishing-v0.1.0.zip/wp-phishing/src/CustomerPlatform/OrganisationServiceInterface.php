<?php
/**
 * Shared organisation-service contract, per Section 8/9/10.
 *
 * Organisation is a shared logical resource and shall not be owned conceptually by a single
 * product (Section 4/8). This mirrors {@see ContactServiceInterface}'s shape: a product
 * resolves the canonical provider through {@see OrganisationPlatformDiscovery::resolve()}
 * rather than instantiating an implementation directly, so the same contract keeps working
 * whether the provider and consumer are the same plugin (today) or two independent ones (once
 * this is extracted, per Section 81).
 *
 * Every method that crosses a product boundary takes or returns the organisation/domain UUID,
 * never an internal numeric ID - the ID is only ever meaningful to whichever plugin's tables
 * are currently authoritative on a given install.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;
use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;

interface OrganisationServiceInterface {

	public function create_or_update_organisation( OrganisationInput $input ): OrganisationResult;

	public function get_by_uuid( string $organisation_uuid ): ?Organisation;

	/**
	 * Section 9: an organisation may have multiple customer users - this is never derived from a
	 * single `organisation_id` column on a WordPress user.
	 */
	public function get_membership( string $organisation_uuid, int $wordpress_user_id ): ?OrganisationMembership;

	/**
	 * Every organisation a given WordPress user belongs to, active or not - callers filter by
	 * {@see OrganisationMembership::$status} for their own purposes (e.g. Section 65's tenant
	 * resolution only ever honours an Active membership).
	 *
	 * @return OrganisationMembership[]
	 */
	public function get_memberships_for_user( int $wordpress_user_id ): array;

	public function add_member(
		string $organisation_uuid,
		int $wordpress_user_id,
		MembershipRole $role,
		?string $contact_uuid = null,
		?int $invited_by = null
	): OrganisationMembership;

	public function update_member_status( int $membership_id, MembershipStatus $status ): void;

	public function update_member_role( int $membership_id, MembershipRole $role ): void;

	/**
	 * Section 10: domains are also a shared logical resource, usable by WP-Reconnaissance,
	 * WP-Phishing and future Alltime products.
	 */
	public function add_domain(
		string $organisation_uuid,
		string $domain_ascii,
		DomainVerificationMethod $verification_method
	): OrganisationDomain;

	/**
	 * @return OrganisationDomain[]
	 */
	public function get_domains( string $organisation_uuid ): array;

	public function get_domain( string $domain_uuid ): ?OrganisationDomain;

	/**
	 * Resolves a domain regardless of which organisation owns it - the starting point for
	 * anything that receives a bare hostname (e.g. an inbound tracking or landing request) and
	 * needs to find its tenant.
	 */
	public function find_domain_by_ascii( string $domain_ascii ): ?OrganisationDomain;

	/**
	 * Records a verification state transition for a domain - starting a DNS TXT challenge
	 * (Pending, with the challenge hash as `$verification_reference`), completing one (Verified),
	 * or any other transition (Failed/Expired). `$requested_by` is only meaningful when starting
	 * or restarting a challenge; pass it whenever the caller has an acting WordPress user id.
	 */
	public function record_domain_verification(
		string $domain_uuid,
		DomainVerificationStatus $status,
		?string $verification_reference = null,
		?int $requested_by = null
	): void;
}
