<?php
/**
 * Result of {@see OrganisationServiceInterface::create_or_update_organisation()}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class OrganisationResult {

	public function __construct(
		public readonly Organisation $organisation,
		public readonly bool $was_created
	) {}
}
