<?php
/**
 * Service discovery for the shared organisation platform, per Section 8/80.
 *
 * Mirrors {@see ContactPlatformDiscovery} exactly: a WordPress filter is the discovery
 * mechanism precisely because it works the same way whether the provider and consumer are the
 * same plugin (today) or two independent ones (once this is extracted). Whichever plugin
 * registers the filter first wins, and every consumer resolves through this class rather than
 * ever constructing {@see OrganisationService} directly.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class OrganisationPlatformDiscovery {

	private const FILTER = 'alltime_customer_platform_organisation_service';

	/**
	 * The contract version this class of provider satisfies. Bump the major segment only for a
	 * breaking change to {@see OrganisationServiceInterface} - {@see resolve()} checks the major
	 * segment only, so minor/patch bumps stay compatible with existing consumers.
	 */
	public const CONTRACT_VERSION = '1.0.0';

	/**
	 * Registers a service instance as the platform's organisation-service provider. Idempotent
	 * by WordPress filter semantics: the first registration wins, later ones are ignored - only
	 * one plugin should ever own this data.
	 */
	public static function provide( OrganisationServiceInterface $service, string $version = self::CONTRACT_VERSION ): void {
		add_filter(
			self::FILTER,
			static fn ( mixed $current ): mixed => $current ?? array(
				'service' => $service,
				'version' => $version,
			)
		);
	}

	/**
	 * Resolves the registered organisation service, or null if none is registered or the
	 * registered provider's major version does not satisfy $required_major_version. Callers
	 * must treat a null return as "the platform is unavailable" and degrade gracefully - never
	 * assume the service exists.
	 */
	public static function resolve( string $required_major_version = '1' ): ?OrganisationServiceInterface {
		$registration = apply_filters( self::FILTER, null );

		if ( ! is_array( $registration ) || ! ( $registration['service'] ?? null ) instanceof OrganisationServiceInterface ) {
			return null;
		}

		$provided_version = (string) ( $registration['version'] ?? '' );

		if ( ! str_starts_with( $provided_version, $required_major_version . '.' ) ) {
			return null;
		}

		return $registration['service'];
	}
}
