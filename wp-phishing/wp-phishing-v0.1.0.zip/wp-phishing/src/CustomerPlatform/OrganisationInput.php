<?php
/**
 * Input to {@see OrganisationServiceInterface::create_or_update_organisation()}, per Section 8.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class OrganisationInput {

	public function __construct(
		public readonly string $name,
		public readonly ?string $slug = null,
		public readonly ?string $primary_contact_uuid = null,
		public readonly string $timezone = 'UTC',
		public readonly ?string $retention_policy = null,
		public readonly ?string $halo_client_id = null
	) {}
}
