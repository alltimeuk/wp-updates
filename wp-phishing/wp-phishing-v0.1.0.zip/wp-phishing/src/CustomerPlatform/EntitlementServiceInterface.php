<?php
/**
 * Shared entitlement contract, per Section 50: "Entitlements are a shared logical resource."
 * Mirrors {@see OrganisationServiceInterface}'s shape exactly: a product resolves the canonical
 * provider through {@see EntitlementPlatformDiscovery::resolve()} rather than instantiating an
 * implementation directly.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\EntitlementType;

interface EntitlementServiceInterface {

	/**
	 * Whether $organisation_uuid currently holds a valid $product_id entitlement with enough
	 * remaining capacity to cover $requested_quantity (Section 21: "Valid product entitlement" is
	 * a campaign-approval gate) - never consumes anything itself, callers must {@see consume()}
	 * separately once the covered activity has actually happened.
	 */
	public function check( string $organisation_uuid, string $product_id, int $requested_quantity = 1 ): EntitlementDecision;

	/**
	 * Draws $quantity down from whichever entitlement {@see check()} last identified as covering
	 * it. Transitions the entitlement to Consumed once its full allowance is drawn down, or
	 * PartiallyConsumed while capacity remains. Unbounded entitlements (null allowance_quantity)
	 * never transition away from Reserved purely from consumption.
	 */
	public function consume( string $entitlement_uuid, int $quantity = 1 ): Entitlement;

	/**
	 * Administrator-issued grant (Section 50's `administrator_grant`/`trial`/etc. types) or the
	 * record of a purchased allowance - $allowance_quantity null means unbounded.
	 */
	public function grant(
		string $organisation_uuid,
		string $product_id,
		EntitlementType $type,
		?int $allowance_quantity,
		?int $granted_by = null,
		?string $reason = null,
		?\DateTimeImmutable $expires_at = null
	): Entitlement;

	public function revoke( string $entitlement_uuid ): Entitlement;

	/**
	 * @return Entitlement[] Most recent first.
	 */
	public function find_all_for_organisation( string $organisation_uuid, ?string $product_id = null ): array;
}
