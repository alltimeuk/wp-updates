<?php
/**
 * The concrete {@see EntitlementServiceInterface} implementation currently shipped inside
 * WP-Phishing. Never instantiated directly by consuming code - always go through
 * {@see EntitlementPlatformDiscovery::resolve()}, exactly as an external plugin would once this
 * becomes its own component (Section 81). Designed the same way as
 * {@see OrganisationService}/{@see UsageService}: pure decision logic in
 * {@see EntitlementPolicy}, I/O here.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\EntitlementType;
use Alltime\CustomerPlatform\Repositories\EntitlementRepository;

final class EntitlementService implements EntitlementServiceInterface {

	public function __construct(
		private readonly EntitlementRepository $entitlements = new EntitlementRepository(),
		private readonly EntitlementPolicy $policy = new EntitlementPolicy()
	) {}

	public function check( string $organisation_uuid, string $product_id, int $requested_quantity = 1 ): EntitlementDecision {
		$history = $this->entitlements->find_history( $organisation_uuid, $product_id );

		return $this->policy->decide( $history, $requested_quantity );
	}

	public function consume( string $entitlement_uuid, int $quantity = 1 ): Entitlement {
		$entitlement = $this->entitlements->consume( $entitlement_uuid, $quantity );

		do_action( 'alltime_entitlement_consumed', $entitlement->organisation_uuid, $entitlement->product_id, $entitlement_uuid, $quantity );

		return $entitlement;
	}

	public function grant(
		string $organisation_uuid,
		string $product_id,
		EntitlementType $type,
		?int $allowance_quantity,
		?int $granted_by = null,
		?string $reason = null,
		?\DateTimeImmutable $expires_at = null
	): Entitlement {
		$entitlement = $this->entitlements->grant( $organisation_uuid, $product_id, $type, $allowance_quantity, $granted_by, $reason, $expires_at );

		do_action( 'alltime_entitlement_granted', $organisation_uuid, $product_id, $entitlement->entitlement_uuid, $type->value );

		return $entitlement;
	}

	public function revoke( string $entitlement_uuid ): Entitlement {
		$entitlement = $this->entitlements->revoke( $entitlement_uuid );

		do_action( 'alltime_entitlement_revoked', $entitlement->organisation_uuid, $entitlement->product_id, $entitlement_uuid );

		return $entitlement;
	}

	public function find_all_for_organisation( string $organisation_uuid, ?string $product_id = null ): array {
		return $this->entitlements->find_all_for_organisation( $organisation_uuid, $product_id );
	}
}
