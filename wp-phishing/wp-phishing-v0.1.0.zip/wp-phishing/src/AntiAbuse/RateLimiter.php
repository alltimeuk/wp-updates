<?php
/**
 * Table-backed, HMAC-hashed, multi-dimensional rate limiting, per Section 57 - the full mechanism
 * `Auth\RateLimiter`'s own docblock deferred to. Ported from WP-Questionnaires' `wpq_rate_limits`
 * pattern, with two deliberate fixes for gaps found in that implementation rather than reproduced:
 * a second dimension is actually populated where one exists cheaply (e.g. an email address
 * alongside the client IP on registration/login), and {@see \Alltime\WPPhishing\AntiAbuse\AntiAbuseBootstrap}
 * runs a recurring sweep to delete expired buckets, which WP-Questionnaires' own implementation
 * never did.
 *
 * IP and email are never stored raw - both are HMAC'd with `wp_salt('auth')` before touching the
 * database, matching every other hashed-identifier convention in this codebase
 * (`EmailNormaliser::hash()`, `wpp_auth_tokens.token_hash`, and so on).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\AntiAbuse;

use Alltime\WPPhishing\AntiAbuse\Repositories\RateLimitRepository;

final class RateLimiter {

	public function __construct(
		private readonly RateLimitRepository $repository = new RateLimitRepository()
	) {}

	/**
	 * @param string      $endpoint              A short, stable name for the thing being limited (e.g. 'register', 'login').
	 * @param string      $primary_identifier    Always present - typically the client IP.
	 * @param string|null $secondary_identifier  A second dimension where one exists cheaply (e.g. the submitted email address) - omitted collapses to IP+endpoint only.
	 */
	public function allow( string $endpoint, string $primary_identifier, int $max_attempts, int $window_seconds, ?string $secondary_identifier = null ): bool {
		$client_hash    = self::hash( $primary_identifier );
		$secondary_hash = null !== $secondary_identifier && '' !== trim( $secondary_identifier ) ? self::hash( $secondary_identifier ) : null;
		$bucket_key     = self::bucket_key( $endpoint, $client_hash, $secondary_hash );

		$count = $this->repository->increment( $bucket_key, $endpoint, $client_hash, $secondary_hash, $window_seconds );

		return $count <= $max_attempts;
	}

	private static function hash( string $value ): string {
		return hash_hmac( 'sha256', strtolower( trim( $value ) ), wp_salt( 'auth' ) );
	}

	private static function bucket_key( string $endpoint, string $client_hash, ?string $secondary_hash ): string {
		return hash( 'sha256', implode( '|', array( $endpoint, $client_hash, $secondary_hash ?? '' ) ) );
	}
}
