<?php
/**
 * Cloudflare Turnstile verification, per Section 58: "Support Cloudflare Turnstile through the
 * same general mechanism used by WP-Questionnaires." Ported near-verbatim from `WPQ_Turnstile` -
 * the fail-open design is the whole point: unconfigured means skip silently, and an unreachable
 * or erroring Cloudflare means allow through, since an outage on their side is not the genuine
 * customer's fault. The only two fail-closed cases are an empty token (a bot skipped the widget)
 * or an explicit `success:false` verdict - both are the mechanism actually working, not errors.
 *
 * Applied only where Section 58 says: registration, password recovery, "other abuse-sensitive
 * public forms" - explicitly never campaign-recipient simulation interactions (tracking/landing
 * routes), per that same section's own carve-out.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\AntiAbuse;

use Alltime\WPPhishing\Support\Secrets;

final class Turnstile {

	private const VERIFY_URL       = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
	private const REQUEST_TIMEOUT  = 10;
	public const WIDGET_SCRIPT_URL = 'https://challenges.cloudflare.com/turnstile/v0/api.js';

	public static function configured(): bool {
		return Secrets::turnstile_site_key()['present'] && Secrets::turnstile_secret_key()['present'];
	}

	public static function site_key(): string {
		return Secrets::turnstile_site_key()['value'];
	}

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post Injectable for testing.
	 */
	public static function verify( string $token, string $remote_ip = '', $http_post = 'wp_remote_post' ): bool {
		if ( ! self::configured() ) {
			return true; // Fail open: nothing to verify against.
		}

		if ( '' === trim( $token ) ) {
			return false; // A properly configured widget always supplies a token; a bot skipping it does not.
		}

		$payload = array(
			'secret'   => Secrets::turnstile_secret_key()['value'],
			'response' => $token,
		);

		if ( '' !== $remote_ip ) {
			$payload['remoteip'] = $remote_ip;
		}

		$response = $http_post(
			self::VERIFY_URL,
			array(
				'timeout' => self::REQUEST_TIMEOUT,
				'body'    => $payload,
			)
		);

		if ( is_wp_error( $response ) ) {
			return true; // Fail open: cannot reach Cloudflare, do not block a genuine customer for it.
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( $status < 200 || $status >= 300 || ! is_array( $body ) ) {
			return true; // Fail open: an outage on Cloudflare's side is not the customer's fault.
		}

		return ! empty( $body['success'] );
	}
}
