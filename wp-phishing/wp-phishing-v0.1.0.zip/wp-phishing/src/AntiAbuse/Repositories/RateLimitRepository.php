<?php
/**
 * Persistence for `wpp_rate_limits`, per Section 57. Ported from WP-Questionnaires'
 * `wpq_rate_limits` convention: one collapsed, HMAC-hashed `bucket_key` per (endpoint, dimensions)
 * combination, enforced UNIQUE, so a single atomic `INSERT ... ON DUPLICATE KEY UPDATE` both
 * creates the counter on first sight and increments/resets it on every later hit - no read-then-
 * write race between two concurrent requests hitting the same bucket.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\AntiAbuse\Repositories;

use Alltime\WPPhishing\Data\Schema;

final class RateLimitRepository {

	/**
	 * Atomically records one hit against $bucket_key and returns the resulting count for the
	 * current window. A window that has already expired is collapsed back to a fresh count of 1
	 * rather than accumulating forever - this is what makes it a *fixed*-window counter.
	 */
	public function increment( string $bucket_key, string $endpoint, string $client_hash, ?string $secondary_hash, int $window_seconds ): int {
		global $wpdb;

		$table      = Schema::table( 'rate_limits' );
		$now        = current_time( 'mysql', true );
		$expires_at = gmdate( 'Y-m-d H:i:s', time() + $window_seconds );

		$query = "INSERT INTO `{$table}`
				(bucket_key, endpoint, client_hash, secondary_hash, window_start, request_count, expires_at, created_at, updated_at)
			VALUES (%s, %s, %s, %s, %s, 1, %s, %s, %s)
			ON DUPLICATE KEY UPDATE
				request_count = IF( expires_at < %s, 1, request_count + 1 ),
				window_start  = IF( expires_at < %s, %s, window_start ),
				expires_at    = IF( expires_at < %s, %s, expires_at ),
				updated_at    = %s";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table/$query are fixed, internally derived (table name only), not user input.
		$wpdb->query( $wpdb->prepare( $query, $bucket_key, $endpoint, $client_hash, $secondary_hash, $now, $expires_at, $now, $now, $now, $now, $now, $now, $expires_at, $now ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above.

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- see above.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT request_count FROM `{$table}` WHERE bucket_key = %s", $bucket_key ), ARRAY_A );

		return null !== $row ? (int) $row['request_count'] : 1;
	}

	/**
	 * The cleanup half of the gap WP-Questionnaires' own `wpq_rate_limits` never closed - without
	 * this, expired buckets accumulate in the table forever. Safe to run at any time: a bucket's
	 * row is only ever read by comparing `expires_at` to "now", so deleting an already-expired one
	 * changes no in-flight decision.
	 */
	public function delete_expired(): int {
		global $wpdb;

		$table = Schema::table( 'rate_limits' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE expires_at < %s", $now ) );
	}
}
