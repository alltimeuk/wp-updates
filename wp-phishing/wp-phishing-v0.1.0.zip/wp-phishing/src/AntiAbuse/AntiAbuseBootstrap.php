<?php
/**
 * Schedules the recurring `wpp_rate_limits` cleanup sweep, per Section 57. A short interval is
 * intentional - unlike Retention's once-daily sweep, expired rate-limit buckets are created
 * continuously by ordinary traffic and should not accumulate for a full day before being cleared.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\AntiAbuse;

use Alltime\WPPhishing\AntiAbuse\Repositories\RateLimitRepository;

final class AntiAbuseBootstrap {

	public const RUN_SWEEP_HOOK = 'wpp_run_rate_limit_sweep';

	private const INTERVAL_SLUG = 'wpp_hourly';

	public function __construct(
		private readonly RateLimitRepository $repository = new RateLimitRepository()
	) {}

	public function boot(): void {
		add_filter( 'cron_schedules', array( $this, 'register_hourly_interval' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- hourly is intentional for clearing expired rate-limit buckets; see docblock.
		add_action( self::RUN_SWEEP_HOOK, array( $this, 'run_sweep' ) );
		add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
	}

	/**
	 * @param array<string,array{interval:int,display:string}> $schedules
	 *
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function register_hourly_interval( array $schedules ): array {
		$schedules[ self::INTERVAL_SLUG ] = array(
			'interval' => HOUR_IN_SECONDS,
			'display'  => __( 'Hourly (WP-Phishing rate limit cleanup)', 'wp-phishing' ),
		);

		return $schedules;
	}

	public function ensure_sweep_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_SWEEP_HOOK ) ) {
			wp_schedule_event( time(), self::INTERVAL_SLUG, self::RUN_SWEEP_HOOK );
		}
	}

	public function run_sweep(): void {
		$this->repository->delete_expired();
	}
}
