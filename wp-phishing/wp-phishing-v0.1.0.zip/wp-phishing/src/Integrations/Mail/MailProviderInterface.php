<?php
/**
 * Mail-provider abstraction, per Section 25. Administrators select a preferred provider
 * globally, optionally overridden per sender domain (Section 22's `mail_provider` column) -
 * messages already queued retain their provider identity even if the active preference later
 * changes (Section 26).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Integrations\Mail\Exceptions\MailDeliveryException;

interface MailProviderInterface {

	public function id(): MailProviderId;

	/**
	 * Validates the provider's current configuration without sending anything.
	 *
	 * @return string[] Validation errors; empty when configuration is valid.
	 */
	public function validate_configuration(): array;

	/**
	 * Sends a single message. Implementations must be idempotent with respect to
	 * {@see QueuedMessage::$idempotency_key} where the provider's own API supports it - never a
	 * substitute for {@see \Alltime\WPPhishing\Delivery\DeliveryQueueService}'s own atomic
	 * claim-before-send guarantee (Section 26), only a second layer of protection.
	 *
	 * @throws MailDeliveryException On any failure to submit the message to the provider.
	 */
	public function send( QueuedMessage $message ): MailSendResult;
}
