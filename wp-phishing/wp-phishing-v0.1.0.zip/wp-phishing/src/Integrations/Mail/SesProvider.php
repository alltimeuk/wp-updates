<?php
/**
 * Amazon SES v2 mail provider, per Section 25. Calls the SES v2 `SendEmail` REST API directly
 * (SigV4-signed via {@see AwsSignatureV4}) rather than depending on the AWS SDK for PHP - SES's
 * JSON API is simple enough that pulling in the full SDK (and its dependency footprint) for one
 * endpoint isn't justified.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Integrations\Mail\Exceptions\MailDeliveryException;
use Alltime\WPPhishing\Integrations\Mail\Support\AwsSignatureV4;
use Alltime\WPPhishing\Support\Secrets;

final class SesProvider implements MailProviderInterface {

	private const SERVICE = 'ses';

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post
	 *        Defaults to `wp_remote_post()`; overridable so tests can assert against a
	 *        deterministic response instead of making a real HTTPS request.
	 */
	public function __construct(
		private $http_post = 'wp_remote_post'
	) {}

	public function id(): MailProviderId {
		return MailProviderId::Ses;
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( ! Secrets::ses_region()['valid'] ) {
			$errors[] = 'Amazon SES region is not configured.';
		}

		if ( ! Secrets::ses_access_key_id()['present'] ) {
			$errors[] = 'Amazon SES access key ID is not configured.';
		}

		if ( ! Secrets::ses_secret_access_key()['present'] ) {
			$errors[] = 'Amazon SES secret access key is not configured.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$region     = Secrets::ses_region()['value'];
		$access_key = Secrets::ses_access_key_id()['value'];
		$secret_key = Secrets::ses_secret_access_key()['value'];

		if ( '' === $region || '' === $access_key || '' === $secret_key ) {
			throw new MailDeliveryException( 'Amazon SES is not configured.', is_retryable: false );
		}

		$host    = "email.{$region}.amazonaws.com";
		$uri     = '/v2/email/outbound-emails';
		$payload = wp_json_encode( $this->build_payload( $message ) );

		if ( false === $payload ) {
			throw new MailDeliveryException( 'Failed to encode the SES request payload.', is_retryable: false );
		}

		$headers = AwsSignatureV4::sign_json_post( $host, $uri, $region, self::SERVICE, $access_key, $secret_key, $payload, new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) );

		$response = ( $this->http_post )(
			"https://{$host}{$uri}",
			array(
				'headers' => $headers,
				'body'    => $payload,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Amazon SES request failed: could not reach the SES endpoint.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status ) {
			// A 4xx (other than throttling) is not worth retrying; 5xx/429 are.
			$retryable = 429 === $status || $status >= 500;
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: $retryable is the named is_retryable argument, not exception output; the message text below is already escaped via esc_html().
			throw new MailDeliveryException( esc_html( "Amazon SES rejected the message (HTTP {$status})." ), is_retryable: $retryable );
		}

		$message_id = is_array( $body ) ? (string) ( $body['MessageId'] ?? '' ) : '';

		if ( '' === $message_id ) {
			throw new MailDeliveryException( 'Amazon SES accepted the request but returned no message ID.' );
		}

		return new MailSendResult( MailProviderId::Ses, $message_id );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function build_payload( QueuedMessage $message ): array {
		$body = array(
			'Subject' => array(
				'Data'    => $message->subject,
				'Charset' => 'UTF-8',
			),
			'Body'    => array(),
		);

		if ( null !== $message->html_body ) {
			$body['Body']['Html'] = array(
				'Data'    => $message->html_body,
				'Charset' => 'UTF-8',
			);
		}

		if ( null !== $message->text_body ) {
			$body['Body']['Text'] = array(
				'Data'    => $message->text_body,
				'Charset' => 'UTF-8',
			);
		}

		$payload = array(
			'FromEmailAddress' => "{$message->from_display_name} <{$message->from_address}>",
			'Destination'      => array( 'ToAddresses' => array( $message->to_address ) ),
			'Content'          => array( 'Simple' => $body ),
		);

		if ( null !== $message->reply_to ) {
			$payload['ReplyToAddresses'] = array( $message->reply_to );
		}

		return $payload;
	}
}
