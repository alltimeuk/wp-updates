<?php
/**
 * A single message handed to a mail provider, per Section 26.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

final class QueuedMessage {

	public function __construct(
		public readonly string $idempotency_key,
		public readonly string $from_address,
		public readonly string $from_display_name,
		public readonly string $to_address,
		public readonly string $subject,
		public readonly ?string $html_body,
		public readonly ?string $text_body,
		public readonly ?string $reply_to = null
	) {}
}
