<?php
/**
 * Microsoft Graph mail provider, per Section 25. Authenticates via an Entra app registration's
 * client-credentials OAuth2 flow (application permission `Mail.Send`), then calls Graph's
 * `sendMail` action for the configured sender mailbox.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Integrations\Mail\Exceptions\MailDeliveryException;
use Alltime\WPPhishing\Support\Secrets;

final class MicrosoftGraphProvider implements MailProviderInterface {

	private const TOKEN_CACHE_KEY_PREFIX = 'wpp_graph_token_';

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post
	 *        Defaults to `wp_remote_post()`; overridable so tests can assert against a
	 *        deterministic response instead of making a real HTTPS request. Used for both the
	 *        token endpoint and the sendMail call.
	 */
	public function __construct(
		private $http_post = 'wp_remote_post'
	) {}

	public function id(): MailProviderId {
		return MailProviderId::MicrosoftGraph;
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( ! Secrets::graph_tenant_id()['present'] ) {
			$errors[] = 'Microsoft Graph tenant ID is not configured.';
		}

		if ( ! Secrets::graph_client_id()['present'] ) {
			$errors[] = 'Microsoft Graph client ID is not configured.';
		}

		if ( ! Secrets::graph_client_secret()['present'] ) {
			$errors[] = 'Microsoft Graph client secret is not configured.';
		}

		if ( ! Secrets::graph_sender_address()['valid'] ) {
			$errors[] = 'Microsoft Graph sender address is not configured.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$tenant        = Secrets::graph_tenant_id()['value'];
		$client_id     = Secrets::graph_client_id()['value'];
		$client_secret = Secrets::graph_client_secret()['value'];
		$sender        = Secrets::graph_sender_address()['value'];

		if ( '' === $tenant || '' === $client_id || '' === $client_secret || '' === $sender ) {
			throw new MailDeliveryException( 'Microsoft Graph is not configured.', is_retryable: false );
		}

		$token   = $this->access_token( $tenant, $client_id, $client_secret );
		$payload = wp_json_encode( $this->build_payload( $message ) );

		if ( false === $payload ) {
			throw new MailDeliveryException( 'Failed to encode the Graph sendMail payload.', is_retryable: false );
		}

		$response = ( $this->http_post )(
			'https://graph.microsoft.com/v1.0/users/' . rawurlencode( $sender ) . '/sendMail',
			array(
				'headers' => array(
					'Authorization' => "Bearer {$token}",
					'Content-Type'  => 'application/json',
				),
				'body'    => $payload,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Microsoft Graph request failed: could not reach the Graph endpoint.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );

		if ( 202 !== $status ) {
			$retryable = 429 === $status || $status >= 500;
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: $retryable is the named is_retryable argument, not exception output; the message text below is already escaped via esc_html().
			throw new MailDeliveryException( esc_html( "Microsoft Graph rejected the message (HTTP {$status})." ), is_retryable: $retryable );
		}

		// sendMail's 202 response carries no message ID - unlike the createMessage+send pair,
		// this single-call endpoint never exposes one (a known Graph API limitation). The
		// delivery's own idempotency key is the only stable identifier available for this
		// provider.
		return new MailSendResult( MailProviderId::MicrosoftGraph, $message->idempotency_key );
	}

	private function access_token( string $tenant, string $client_id, string $client_secret ): string {
		$cache_key = self::TOKEN_CACHE_KEY_PREFIX . md5( "{$tenant}:{$client_id}" );
		$cached    = get_transient( $cache_key );

		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$response = ( $this->http_post )(
			"https://login.microsoftonline.com/{$tenant}/oauth2/v2.0/token",
			array(
				'body'    => array(
					'client_id'     => $client_id,
					'client_secret' => $client_secret,
					'scope'         => 'https://graph.microsoft.com/.default',
					'grant_type'    => 'client_credentials',
				),
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Unable to obtain a Microsoft Graph access token.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status || ! is_array( $body ) || empty( $body['access_token'] ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: the second argument is the named is_retryable bool, not exception output; the message text below is already escaped via esc_html().
			throw new MailDeliveryException( esc_html( "Microsoft Graph token request failed (HTTP {$status})." ), is_retryable: 429 === $status || $status >= 500 );
		}

		$token = (string) $body['access_token'];
		$ttl   = max( 60, (int) ( $body['expires_in'] ?? 3600 ) - 60 ); // Refresh a minute early.

		set_transient( $cache_key, $token, $ttl );

		return $token;
	}

	/**
	 * @return array<string,mixed>
	 */
	private function build_payload( QueuedMessage $message ): array {
		$body = null !== $message->html_body
			? array(
				'contentType' => 'HTML',
				'content'     => $message->html_body,
			)
			: array(
				'contentType' => 'Text',
				'content'     => (string) $message->text_body,
			);

		$mail = array(
			'subject'      => $message->subject,
			'body'         => $body,
			'toRecipients' => array( array( 'emailAddress' => array( 'address' => $message->to_address ) ) ),
			'from'         => array(
				'emailAddress' => array(
					'address' => $message->from_address,
					'name'    => $message->from_display_name,
				),
			),
		);

		if ( null !== $message->reply_to ) {
			$mail['replyTo'] = array( array( 'emailAddress' => array( 'address' => $message->reply_to ) ) );
		}

		return array(
			'message'         => $mail,
			'saveToSentItems' => false,
		);
	}
}
