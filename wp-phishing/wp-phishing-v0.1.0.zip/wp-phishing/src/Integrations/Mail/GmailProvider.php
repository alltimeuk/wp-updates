<?php
/**
 * Gmail API mail provider, per Section 25. Authenticates via a stored OAuth2 refresh token
 * (exchanged for a short-lived access token, cached), then submits a raw RFC 2822 message
 * through `users.messages.send` - Gmail's API has no separate "simple" send endpoint the way
 * SES/Graph do, only this raw-message form.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Integrations\Mail\Exceptions\MailDeliveryException;
use Alltime\WPPhishing\Support\Secrets;

final class GmailProvider implements MailProviderInterface {

	private const TOKEN_CACHE_KEY_PREFIX = 'wpp_gmail_token_';

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post
	 *        Defaults to `wp_remote_post()`; overridable so tests can assert against a
	 *        deterministic response instead of making a real HTTPS request. Used for both the
	 *        token endpoint and the messages.send call.
	 */
	public function __construct(
		private $http_post = 'wp_remote_post'
	) {}

	public function id(): MailProviderId {
		return MailProviderId::Gmail;
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( ! Secrets::gmail_oauth_client_id()['present'] ) {
			$errors[] = 'Gmail OAuth client ID is not configured.';
		}

		if ( ! Secrets::gmail_oauth_client_secret()['present'] ) {
			$errors[] = 'Gmail OAuth client secret is not configured.';
		}

		if ( ! Secrets::gmail_refresh_token()['present'] ) {
			$errors[] = 'Gmail OAuth refresh token is not configured.';
		}

		if ( ! Secrets::gmail_sender_address()['valid'] ) {
			$errors[] = 'Gmail sender address is not configured.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$client_id     = Secrets::gmail_oauth_client_id()['value'];
		$client_secret = Secrets::gmail_oauth_client_secret()['value'];
		$refresh_token = Secrets::gmail_refresh_token()['value'];

		if ( '' === $client_id || '' === $client_secret || '' === $refresh_token ) {
			throw new MailDeliveryException( 'Gmail is not configured.', is_retryable: false );
		}

		$token   = $this->access_token( $client_id, $client_secret, $refresh_token );
		$raw     = $this->build_raw_message( $message );
		$payload = wp_json_encode( array( 'raw' => $raw ) );

		if ( false === $payload ) {
			throw new MailDeliveryException( 'Failed to encode the Gmail send payload.', is_retryable: false );
		}

		$response = ( $this->http_post )(
			'https://gmail.googleapis.com/gmail/v1/users/me/messages/send',
			array(
				'headers' => array(
					'Authorization' => "Bearer {$token}",
					'Content-Type'  => 'application/json',
				),
				'body'    => $payload,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Gmail request failed: could not reach the Gmail API endpoint.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status ) {
			$retryable = 429 === $status || $status >= 500;
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: $retryable is the named is_retryable argument, not exception output; the message text below is already escaped via esc_html().
			throw new MailDeliveryException( esc_html( "Gmail rejected the message (HTTP {$status})." ), is_retryable: $retryable );
		}

		$message_id = is_array( $body ) ? (string) ( $body['id'] ?? '' ) : '';

		if ( '' === $message_id ) {
			throw new MailDeliveryException( 'Gmail accepted the request but returned no message ID.' );
		}

		return new MailSendResult( MailProviderId::Gmail, $message_id );
	}

	private function access_token( string $client_id, string $client_secret, string $refresh_token ): string {
		$cache_key = self::TOKEN_CACHE_KEY_PREFIX . md5( "{$client_id}:{$refresh_token}" );
		$cached    = get_transient( $cache_key );

		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$response = ( $this->http_post )(
			'https://oauth2.googleapis.com/token',
			array(
				'body'    => array(
					'client_id'     => $client_id,
					'client_secret' => $client_secret,
					'refresh_token' => $refresh_token,
					'grant_type'    => 'refresh_token',
				),
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Unable to obtain a Gmail access token.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status || ! is_array( $body ) || empty( $body['access_token'] ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: the second argument is the named is_retryable bool, not exception output; the message text below is already escaped via esc_html().
			throw new MailDeliveryException( esc_html( "Gmail token request failed (HTTP {$status})." ), is_retryable: 429 === $status || $status >= 500 );
		}

		$token = (string) $body['access_token'];
		$ttl   = max( 60, (int) ( $body['expires_in'] ?? 3600 ) - 60 ); // Refresh a minute early.

		set_transient( $cache_key, $token, $ttl );

		return $token;
	}

	/**
	 * Builds a raw RFC 2822 message and base64url-encodes it, as `users.messages.send` requires -
	 * Gmail's API has no structured "simple message" form the way SES/Graph do.
	 */
	private function build_raw_message( QueuedMessage $message ): string {
		$from    = sprintf( '%s <%s>', $this->encode_header( $message->from_display_name ), $message->from_address );
		$subject = $this->encode_header( $message->subject );

		$headers = array(
			"From: {$from}",
			"To: {$message->to_address}",
			"Subject: {$subject}",
			'MIME-Version: 1.0',
		);

		if ( null !== $message->reply_to ) {
			$headers[] = "Reply-To: {$message->reply_to}";
		}

		if ( null !== $message->html_body && null !== $message->text_body ) {
			$boundary  = 'wpp_' . bin2hex( random_bytes( 16 ) );
			$headers[] = "Content-Type: multipart/alternative; boundary=\"{$boundary}\"";

			$raw_message = implode( "\r\n", $headers ) . "\r\n\r\n"
				. "--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n{$message->text_body}\r\n\r\n"
				. "--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n{$message->html_body}\r\n\r\n"
				. "--{$boundary}--";
		} else {
			$is_html      = null !== $message->html_body;
			$body         = $is_html ? $message->html_body : $message->text_body;
			$content_type = $is_html ? 'text/html' : 'text/plain';
			$headers[]    = "Content-Type: {$content_type}; charset=UTF-8";

			$raw_message = implode( "\r\n", $headers ) . "\r\n\r\n" . $body;
		}

		return rtrim( strtr( base64_encode( $raw_message ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64url-encoding the raw MIME message, as required by Gmail's users.messages.send API; not code obfuscation.
	}

	private function encode_header( string $value ): string {
		if ( 1 === preg_match( '/^[\x20-\x7E]*$/', $value ) ) {
			return $value;
		}

		return function_exists( 'mb_encode_mimeheader' )
			? mb_encode_mimeheader( $value, 'UTF-8', 'B', "\r\n" )
			: $value;
	}
}
