<?php
/**
 * Result of a provider send attempt, per Section 25/26.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;

final class MailSendResult {

	public function __construct(
		public readonly MailProviderId $provider_id,
		public readonly string $provider_message_id
	) {}
}
