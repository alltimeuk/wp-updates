<?php
/**
 * Resolves the active mail provider, per Section 25: a global administrator-selected preference,
 * overridable per sender domain (Section 22's `mail_provider` column).
 *
 * Organisation-aware since the "Multi-provider delivery modes" plan addition: the two mailbox-
 * injection providers need the *calling organisation's own* consented tenant, not a global
 * secret, so resolving one looks up that organisation's active
 * {@see \Alltime\WPPhishing\MailIntegrations\OrganisationMailIntegration} and constructs the
 * provider with it already bound. Injection providers are therefore never eligible as the
 * site-wide default preference (Section 25's API-send providers only) - only a sender domain
 * explicitly configured for mailbox-injection delivery resolves one, via $domain_override.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\Repositories\OrganisationMailIntegrationRepository;

final class MailManager {

	public function __construct(
		private readonly OrganisationMailIntegrationRepository $mail_integrations = new OrganisationMailIntegrationRepository()
	) {}

	/**
	 * @return array<string,MailProviderInterface>
	 */
	public function available_providers(): array {
		$providers = array( new SesProvider(), new MicrosoftGraphProvider(), new GmailProvider() );

		return array_combine( array_map( static fn ( MailProviderInterface $provider ): string => $provider->id()->value, $providers ), $providers );
	}

	/**
	 * Resolves the provider a send should use: $domain_override when set (a sender domain's own
	 * `mail_provider` column), otherwise the site-wide preference. Returns null if neither
	 * resolves to a known, usable provider - callers must treat that as "sending is not
	 * configured", never fall back to a default silently.
	 */
	public function resolve( ?MailProviderId $domain_override, string $organisation_uuid ): ?MailProviderInterface {
		$preferred = $domain_override ?? $this->global_preference();

		if ( null === $preferred ) {
			return null;
		}

		if ( in_array( $preferred, array( MailProviderId::GraphMailboxWrite, MailProviderId::GmailMailboxInsert ), true ) ) {
			return $this->resolve_mailbox_injection_provider( $preferred, $organisation_uuid );
		}

		return $this->available_providers()[ $preferred->value ] ?? null;
	}

	public function global_preference(): ?MailProviderId {
		return MailProviderId::tryFrom( (string) get_option( 'wpp_mail_provider', '' ) );
	}

	private function resolve_mailbox_injection_provider( MailProviderId $provider_id, string $organisation_uuid ): ?MailProviderInterface {
		$integration_provider = MailProviderId::GraphMailboxWrite === $provider_id
			? MailIntegrationProvider::Microsoft365
			: MailIntegrationProvider::GoogleWorkspace;

		$integration = $this->mail_integrations->find_one( $organisation_uuid, $integration_provider, MailIntegrationCapability::MailboxInjection );

		if ( null === $integration || ! $integration->is_active() || null === $integration->tenant_identifier ) {
			return null;
		}

		return MailProviderId::GraphMailboxWrite === $provider_id
			? new GraphMailboxWriteProvider( $integration->tenant_identifier )
			: new GmailMailboxInsertProvider();
	}
}
