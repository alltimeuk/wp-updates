<?php
/**
 * Mailbox-injection delivery via the Gmail API, per the "Multi-provider delivery modes" plan
 * addition: `users.messages.insert` (not `.send`) "directly inserts a message into only this
 * user's mailbox similar to IMAP APPEND, bypassing most scanning and classification" (Google's
 * own description) - authenticated via the service-account JWT-bearer flow with domain-wide
 * delegation, impersonating the recipient directly (the `sub` claim), which is what makes writing
 * into an arbitrary mailbox on the customer's Workspace tenant possible at all.
 *
 * Deliberately separate from {@see GmailProvider}, which sends via `messages.send` using a
 * refresh token for one fixed sender mailbox - no per-recipient impersonation, no customer
 * consent. The raw-message-building logic below intentionally duplicates (rather than shares)
 * that class's own private `build_raw_message()`: the two are similar but not identical (this one
 * adds the simulation header set), and refactoring a tested, shipped Phase 3 class to share it
 * carries more risk than the duplication costs.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Integrations\Mail\Exceptions\MailDeliveryException;
use Alltime\WPPhishing\Integrations\Mail\Support\GoogleServiceAccountToken;
use Alltime\WPPhishing\Integrations\Mail\Support\SimulationHeaders;
use Alltime\WPPhishing\Support\Secrets;

final class GmailMailboxInsertProvider implements MailProviderInterface {

	private const SCOPE = 'https://www.googleapis.com/auth/gmail.insert';

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post
	 *        Defaults to `wp_remote_post()`; overridable so tests can assert against a
	 *        deterministic response instead of making a real HTTPS request.
	 */
	public function __construct(
		private $http_post = 'wp_remote_post',
		private readonly GoogleServiceAccountToken $token_fetcher = new GoogleServiceAccountToken()
	) {}

	public function id(): MailProviderId {
		return MailProviderId::GmailMailboxInsert;
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( ! Secrets::google_workspace_client_email()['present'] ) {
			$errors[] = 'Google Workspace service account email is not configured.';
		}

		if ( ! Secrets::google_workspace_private_key()['present'] ) {
			$errors[] = 'Google Workspace service account private key is not configured.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$client_email = Secrets::google_workspace_client_email()['value'];
		$private_key  = Secrets::google_workspace_private_key()['value'];

		if ( '' === $client_email || '' === $private_key ) {
			throw new MailDeliveryException( 'Mailbox injection is not configured.', is_retryable: false );
		}

		try {
			// Domain-wide delegation impersonates the recipient directly - there is no separate
			// "sender" identity for an insert into someone else's mailbox.
			$token = $this->token_fetcher->fetch( $client_email, $private_key, self::SCOPE, $message->to_address );
		} catch ( \RuntimeException $exception ) {
			throw new MailDeliveryException( esc_html( $exception->getMessage() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- $exception's message is a fixed string built by GoogleServiceAccountToken, never a raw response body; esc_html() applied above regardless.
		}

		$raw     = $this->build_raw_message( $message );
		$payload = wp_json_encode( array( 'raw' => $raw ) );

		if ( false === $payload ) {
			throw new MailDeliveryException( 'Failed to encode the mailbox-injection payload.', is_retryable: false );
		}

		$response = ( $this->http_post )(
			'https://gmail.googleapis.com/gmail/v1/users/me/messages',
			array(
				'headers' => array(
					'Authorization' => "Bearer {$token}",
					'Content-Type'  => 'application/json',
				),
				'body'    => $payload,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Mailbox injection failed: could not reach the Gmail API endpoint.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status ) {
			$retryable = 429 === $status || $status >= 500;
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: $retryable is the named is_retryable argument, not exception output; the message text below is already escaped via esc_html().
			throw new MailDeliveryException( esc_html( "Mailbox injection was rejected (HTTP {$status})." ), is_retryable: $retryable );
		}

		$message_id = is_array( $body ) ? (string) ( $body['id'] ?? '' ) : '';

		if ( '' === $message_id ) {
			throw new MailDeliveryException( 'Mailbox injection succeeded but returned no message ID.' );
		}

		return new MailSendResult( MailProviderId::GmailMailboxInsert, $message_id );
	}

	/**
	 * Builds a raw RFC 2822 message and base64url-encodes it, matching {@see GmailProvider}'s own
	 * convention - plus the simulation header set this delivery mode always adds.
	 */
	private function build_raw_message( QueuedMessage $message ): string {
		$from    = sprintf( '%s <%s>', $this->encode_header( $message->from_display_name ), $message->from_address );
		$subject = $this->encode_header( $message->subject );

		$headers = array(
			"From: {$from}",
			"To: {$message->to_address}",
			"Subject: {$subject}",
			'MIME-Version: 1.0',
		);

		foreach ( SimulationHeaders::headers() as $name => $value ) {
			$headers[] = "{$name}: {$value}";
		}

		if ( null !== $message->reply_to ) {
			$headers[] = "Reply-To: {$message->reply_to}";
		}

		if ( null !== $message->html_body && null !== $message->text_body ) {
			$boundary  = 'wpp_' . bin2hex( random_bytes( 16 ) );
			$headers[] = "Content-Type: multipart/alternative; boundary=\"{$boundary}\"";

			$raw_message = implode( "\r\n", $headers ) . "\r\n\r\n"
				. "--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n{$message->text_body}\r\n\r\n"
				. "--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n{$message->html_body}\r\n\r\n"
				. "--{$boundary}--";
		} else {
			$is_html      = null !== $message->html_body;
			$body         = $is_html ? $message->html_body : $message->text_body;
			$content_type = $is_html ? 'text/html' : 'text/plain';
			$headers[]    = "Content-Type: {$content_type}; charset=UTF-8";

			$raw_message = implode( "\r\n", $headers ) . "\r\n\r\n" . $body;
		}

		return rtrim( strtr( base64_encode( $raw_message ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64url-encoding the raw MIME message, as required by the Gmail API; not code obfuscation.
	}

	private function encode_header( string $value ): string {
		if ( 1 === preg_match( '/^[\x20-\x7E]*$/', $value ) ) {
			return $value;
		}

		return function_exists( 'mb_encode_mimeheader' )
			? mb_encode_mimeheader( $value, 'UTF-8', 'B', "\r\n" )
			: $value;
	}
}
