<?php
/**
 * Thrown when a mail provider rejects or fails to accept a message. The message text must never
 * contain the provider's raw response body (which can include recipient addresses or account
 * identifiers) - callers logging this exception classify it first
 * ({@see \Alltime\WPPhishing\Delivery\DeliveryQueueService}), never persist `getMessage()` as-is.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail\Exceptions;

final class MailDeliveryException extends \RuntimeException {

	public function __construct(
		string $message,
		public readonly bool $is_retryable = true
	) {
		parent::__construct( $message );
	}
}
