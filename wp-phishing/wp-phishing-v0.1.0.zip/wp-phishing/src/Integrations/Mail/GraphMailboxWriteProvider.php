<?php
/**
 * Mailbox-injection delivery via Microsoft Graph, per the "Multi-provider delivery modes" plan
 * addition: creates the message directly in the recipient's own mailbox (on the *customer's*
 * tenant, per the "WP-Phishing Mailbox Access" app registration the customer has consented to)
 * then moves it into the Inbox folder. Both steps are mailbox object operations, not a send - the
 * message never passes through the tenant's mail flow/anti-spam pipeline, which is the entire
 * point of this delivery mode (see PLAN.md).
 *
 * Deliberately separate from {@see MicrosoftGraphProvider}, which sends from Alltime's own
 * mailbox via Alltime's own tenant using the Section 25 Mail.Send app - no customer consent
 * involved there at all.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail;

use Alltime\WPPhishing\Integrations\Mail\Enums\MailProviderId;
use Alltime\WPPhishing\Integrations\Mail\Exceptions\MailDeliveryException;
use Alltime\WPPhishing\Integrations\Mail\Support\GraphAppOnlyToken;
use Alltime\WPPhishing\Integrations\Mail\Support\SimulationHeaders;
use Alltime\WPPhishing\Support\Secrets;

final class GraphMailboxWriteProvider implements MailProviderInterface {

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post
	 *        Defaults to `wp_remote_post()`; overridable so tests can assert against a
	 *        deterministic response instead of making a real HTTPS request.
	 */
	public function __construct(
		private readonly string $tenant_id,
		private $http_post = 'wp_remote_post',
		private readonly GraphAppOnlyToken $token_fetcher = new GraphAppOnlyToken()
	) {}

	public function id(): MailProviderId {
		return MailProviderId::GraphMailboxWrite;
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( ! Secrets::graph_mailbox_access_client_id()['present'] ) {
			$errors[] = 'Microsoft Graph mailbox-access client ID is not configured.';
		}

		if ( ! Secrets::graph_mailbox_access_client_secret()['present'] ) {
			$errors[] = 'Microsoft Graph mailbox-access client secret is not configured.';
		}

		if ( '' === $this->tenant_id ) {
			$errors[] = 'No customer tenant is configured for mailbox injection.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$client_id     = Secrets::graph_mailbox_access_client_id()['value'];
		$client_secret = Secrets::graph_mailbox_access_client_secret()['value'];

		if ( '' === $client_id || '' === $client_secret || '' === $this->tenant_id ) {
			throw new MailDeliveryException( 'Mailbox injection is not configured.', is_retryable: false );
		}

		try {
			$token = $this->token_fetcher->fetch( $this->tenant_id, $client_id, $client_secret );
		} catch ( \RuntimeException $exception ) {
			throw new MailDeliveryException( esc_html( $exception->getMessage() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- $exception's message is a fixed string built by GraphAppOnlyToken, never a raw response body; esc_html() applied above regardless.
		}

		$mailbox = rawurlencode( $message->to_address );
		$payload = wp_json_encode( $this->build_payload( $message ) );

		if ( false === $payload ) {
			throw new MailDeliveryException( 'Failed to encode the mailbox-injection payload.', is_retryable: false );
		}

		$message_id = $this->create_draft( $token, $mailbox, $payload );

		return new MailSendResult( MailProviderId::GraphMailboxWrite, $this->move_to_inbox( $token, $mailbox, $message_id ) );
	}

	private function create_draft( string $token, string $mailbox, string $payload ): string {
		$response = ( $this->http_post )(
			"https://graph.microsoft.com/v1.0/users/{$mailbox}/messages",
			array(
				'headers' => array(
					'Authorization' => "Bearer {$token}",
					'Content-Type'  => 'application/json',
				),
				'body'    => $payload,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Mailbox injection failed: could not reach the Graph endpoint.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 201 !== $status || ! is_array( $body ) || empty( $body['id'] ) ) {
			$retryable = 429 === $status || $status >= 500;
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: $retryable is the named is_retryable argument, not exception output; the message text below is already escaped via esc_html().
			throw new MailDeliveryException( esc_html( "Mailbox injection was rejected (HTTP {$status})." ), is_retryable: $retryable );
		}

		return (string) $body['id'];
	}

	/**
	 * Moving a message to another folder is itself a Graph "create" of the moved copy - it
	 * returns a *new* id for the message now sitting in the Inbox, which is what's actually worth
	 * keeping as this delivery's provider_message_id, not the transient draft id.
	 */
	private function move_to_inbox( string $token, string $mailbox, string $draft_message_id ): string {
		$response = ( $this->http_post )(
			"https://graph.microsoft.com/v1.0/users/{$mailbox}/messages/{$draft_message_id}/move",
			array(
				'headers' => array(
					'Authorization' => "Bearer {$token}",
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( array( 'destinationId' => 'inbox' ) ),
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( 'Mailbox injection failed: could not move the message into the Inbox.' );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 201 !== $status ) {
			$retryable = 429 === $status || $status >= 500;
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- see create_draft() above.
			throw new MailDeliveryException( esc_html( "Mailbox injection could not move the message into the Inbox (HTTP {$status})." ), is_retryable: $retryable );
		}

		return is_array( $body ) && ! empty( $body['id'] ) ? (string) $body['id'] : $draft_message_id;
	}

	/**
	 * @return array<string,mixed>
	 */
	private function build_payload( QueuedMessage $message ): array {
		$body = null !== $message->html_body
			? array(
				'contentType' => 'HTML',
				'content'     => $message->html_body,
			)
			: array(
				'contentType' => 'Text',
				'content'     => (string) $message->text_body,
			);

		$headers = array();

		foreach ( SimulationHeaders::headers() as $name => $value ) {
			$headers[] = array(
				'name'  => $name,
				'value' => $value,
			);
		}

		return array(
			'subject'                => $message->subject,
			'body'                   => $body,
			'from'                   => array(
				'emailAddress' => array(
					'address' => $message->from_address,
					'name'    => $message->from_display_name,
				),
			),
			'toRecipients'           => array( array( 'emailAddress' => array( 'address' => $message->to_address ) ) ),
			'internetMessageHeaders' => $headers,
		);
	}
}
