<?php
/**
 * Stable mail provider identifiers, per Section 25.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail\Enums;

enum MailProviderId: string {
	case Ses            = 'ses';
	case MicrosoftGraph = 'microsoft_graph';
	case Gmail          = 'gmail';
	/** Mailbox injection via Microsoft Graph against the customer's own tenant - see PLAN.md's "Multi-provider delivery modes". */
	case GraphMailboxWrite = 'graph_mailbox_write';
	/** Mailbox injection via the Gmail API against the customer's own Workspace tenant. */
	case GmailMailboxInsert = 'gmail_mailbox_insert';
}
