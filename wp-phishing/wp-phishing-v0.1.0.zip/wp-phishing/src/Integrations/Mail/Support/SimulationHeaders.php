<?php
/**
 * Headers added to mailbox-injected simulation mail, per the "Multi-provider delivery modes" plan
 * addition: injection has no real transport to authenticate, so rather than forge a plausible-
 * looking (and therefore misleading) header set, these honestly disclose what actually happened -
 * visible in raw source/"View Original", never rendered in a normal mail client. Every name is
 * deliberately `X-`-prefixed: Microsoft Graph's `internetMessageHeaders` API only accepts custom
 * header names starting with "X-", so both mailbox-injection providers share this one set rather
 * than each inventing its own header shape.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail\Support;

final class SimulationHeaders {

	/**
	 * @return array<string,string> Header name => value.
	 */
	public static function headers(): array {
		return array(
			'X-WPP-Simulation'             => 'true',
			'X-WPP-Authentication-Results' => 'spf=none; dkim=none; dmarc=none (simulation - written directly into the mailbox; no real mail transport occurred)',
		);
	}
}
