<?php
/**
 * Fetches a Google access token via the service-account JWT-bearer flow with domain-wide
 * delegation (`sub` claim impersonating a specific Workspace user) - pure PHP, no Google API
 * client library, matching this codebase's existing "no vendor SDK for one endpoint" convention
 * (see {@see \Alltime\WPPhishing\Integrations\Mail\Support\AwsSignatureV4}).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail\Support;

final class GoogleServiceAccountToken {

	private const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
	private const GRANT_TYPE     = 'urn:ietf:params:oauth:grant-type:jwt-bearer';

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post
	 */
	public function __construct(
		private $http_post = 'wp_remote_post'
	) {}

	/**
	 * @throws \RuntimeException on a malformed private key, a signing failure, or a rejected/
	 *                            unreachable token request (e.g. domain-wide delegation not
	 *                            actually configured for this scope+user).
	 */
	public function fetch( string $client_email, string $private_key_pem, string $scope, string $impersonate_user, int $ttl_seconds = 3600 ): string {
		$jwt = $this->build_signed_jwt( $client_email, $private_key_pem, $scope, $impersonate_user, $ttl_seconds );

		$response = ( $this->http_post )(
			self::TOKEN_ENDPOINT,
			array(
				'body'    => array(
					'grant_type' => self::GRANT_TYPE,
					'assertion'  => $jwt,
				),
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new \RuntimeException( esc_html( 'Unable to obtain a Google access token: could not reach the token endpoint.' ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status || ! is_array( $body ) || empty( $body['access_token'] ) ) {
			throw new \RuntimeException( esc_html( "Google token request failed for {$impersonate_user} (HTTP {$status})." ) );
		}

		return (string) $body['access_token'];
	}

	private function build_signed_jwt( string $client_email, string $private_key_pem, string $scope, string $impersonate_user, int $ttl_seconds ): string {
		$now = time();

		$segments   = array();
		$segments[] = $this->base64url_encode(
			(string) wp_json_encode(
				array(
					'alg' => 'RS256',
					'typ' => 'JWT',
				)
			)
		);
		$segments[] = $this->base64url_encode(
			(string) wp_json_encode(
				array(
					'iss'   => $client_email,
					'scope' => $scope,
					'aud'   => self::TOKEN_ENDPOINT,
					'iat'   => $now,
					'exp'   => $now + $ttl_seconds,
					'sub'   => $impersonate_user,
				)
			)
		);

		$signing_input = implode( '.', $segments );
		$private_key   = openssl_pkey_get_private( $private_key_pem );

		if ( false === $private_key ) {
			throw new \RuntimeException( esc_html( 'The configured Google service account private key is not valid.' ) );
		}

		$signature = '';
		$signed    = openssl_sign( $signing_input, $signature, $private_key, OPENSSL_ALGO_SHA256 );

		if ( ! $signed ) {
			throw new \RuntimeException( esc_html( 'Failed to sign the Google service account JWT.' ) );
		}

		$segments[] = $this->base64url_encode( $signature );

		return implode( '.', $segments );
	}

	private function base64url_encode( string $data ): string {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64url-encoding JWT segments per RFC 7519, not obfuscating anything.
	}
}
