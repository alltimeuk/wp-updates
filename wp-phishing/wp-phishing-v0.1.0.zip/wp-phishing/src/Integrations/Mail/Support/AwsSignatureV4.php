<?php
/**
 * AWS Signature Version 4 request signing, implemented directly against the published algorithm
 * (https://docs.aws.amazon.com/IAM/latest/UserGuide/create-signed-request.html) rather than
 * pulling in the full AWS SDK for PHP just to sign one JSON POST request to SES v2.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail\Support;

final class AwsSignatureV4 {

	private const ALGORITHM = 'AWS4-HMAC-SHA256';

	/**
	 * Signs a single POST request with an empty query string and a JSON body, signing exactly
	 * the `content-type`, `host` and `x-amz-date` headers - sufficient for SES v2's JSON API,
	 * which needs no other signed headers.
	 *
	 * @return array<string,string> Header name => value, to merge into the request headers
	 *                                (Authorization, X-Amz-Date, Content-Type, Host).
	 */
	public static function sign_json_post(
		string $host,
		string $uri,
		string $region,
		string $service,
		string $access_key_id,
		string $secret_access_key,
		string $payload,
		\DateTimeImmutable $now
	): array {
		$amz_date     = $now->format( 'Ymd\THis\Z' );
		$date_stamp   = $now->format( 'Ymd' );
		$content_type = 'application/json';

		$canonical_headers = "content-type:{$content_type}\nhost:{$host}\nx-amz-date:{$amz_date}\n";
		$signed_headers    = 'content-type;host;x-amz-date';
		$payload_hash      = hash( 'sha256', $payload );

		$canonical_request = "POST\n{$uri}\n\n{$canonical_headers}\n{$signed_headers}\n{$payload_hash}";

		$credential_scope = "{$date_stamp}/{$region}/{$service}/aws4_request";
		$string_to_sign   = self::ALGORITHM . "\n{$amz_date}\n{$credential_scope}\n" . hash( 'sha256', $canonical_request );

		$signing_key = self::derive_signing_key( $secret_access_key, $date_stamp, $region, $service );
		$signature   = hash_hmac( 'sha256', $string_to_sign, $signing_key );

		$authorization = self::ALGORITHM . " Credential={$access_key_id}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

		return array(
			'Authorization' => $authorization,
			'X-Amz-Date'    => $amz_date,
			'Content-Type'  => $content_type,
			'Host'          => $host,
		);
	}

	/**
	 * The four-step HMAC key-derivation chain every SigV4 signature is built on: a date-scoped
	 * key, further scoped to region, then service, then finally to "aws4_request" - never the
	 * raw secret access key itself.
	 */
	private static function derive_signing_key( string $secret_access_key, string $date_stamp, string $region, string $service ): string {
		$k_date    = hash_hmac( 'sha256', $date_stamp, 'AWS4' . $secret_access_key, true );
		$k_region  = hash_hmac( 'sha256', $region, $k_date, true );
		$k_service = hash_hmac( 'sha256', $service, $k_region, true );

		return hash_hmac( 'sha256', 'aws4_request', $k_service, true );
	}
}
