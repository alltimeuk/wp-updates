<?php
/**
 * Fetches a Microsoft Graph app-only (client-credentials) access token for an arbitrary tenant.
 *
 * Deliberately separate from {@see \Alltime\WPPhishing\Integrations\Mail\MicrosoftGraphProvider}'s
 * own inline token fetch: that class always authenticates against Alltime's own tenant with
 * Alltime's own Mail.Send app (Section 25, no customer consent needed). This helper authenticates
 * against a *customer's* tenant, using whichever of Alltime's other app registrations
 * (Mailbox Access, Directory Sync) that customer has consented to - the tenant and app
 * credentials are both parameters, not fixed secrets, because who's being called varies per
 * organisation.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Integrations\Mail\Support;

final class GraphAppOnlyToken {

	/**
	 * @param callable(string,array<string,mixed>):(array<string,mixed>|\WP_Error) $http_post
	 *        Defaults to `wp_remote_post()`; overridable so tests can assert against a
	 *        deterministic response instead of making a real HTTPS request.
	 */
	public function __construct(
		private $http_post = 'wp_remote_post'
	) {}

	/**
	 * @throws \RuntimeException if the token request fails or the tenant hasn't actually granted
	 *                            consent to this app (both surfaced identically to the caller -
	 *                            distinguishing "network error" from "consent missing" isn't this
	 *                            class's job, see {@see \Alltime\WPPhishing\MailIntegrations\MailIntegrationService}).
	 */
	public function fetch( string $tenant_id, string $client_id, string $client_secret, string $scope = 'https://graph.microsoft.com/.default' ): string {
		$response = ( $this->http_post )(
			"https://login.microsoftonline.com/{$tenant_id}/oauth2/v2.0/token",
			array(
				'body'    => array(
					'client_id'     => $client_id,
					'client_secret' => $client_secret,
					'scope'         => $scope,
					'grant_type'    => 'client_credentials',
				),
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new \RuntimeException( esc_html( 'Unable to obtain a Microsoft Graph access token: could not reach the token endpoint.' ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status || ! is_array( $body ) || empty( $body['access_token'] ) ) {
			throw new \RuntimeException( esc_html( "Microsoft Graph token request failed for tenant {$tenant_id} (HTTP {$status})." ) );
		}

		return (string) $body['access_token'];
	}
}
