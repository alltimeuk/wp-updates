<?php
/**
 * Schedules the recurring recipient-import continuation sweep, per Section 15: "Large imports
 * shall run asynchronously." Mirrors {@see \Alltime\WPPhishing\Verification\VerificationBootstrap}'s
 * shape exactly - a dedicated, short cron interval owned by this module alone.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

final class RecipientsBootstrap {

	public const RUN_SWEEP_HOOK = 'wpp_run_recipient_import_sweep';

	private const INTERVAL_SLUG = 'wpp_five_minutes';

	public function boot(): void {
		add_filter( 'cron_schedules', array( $this, 'register_five_minute_interval' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 5 minutes is intentional: an in-progress import should resume promptly, not wait for an hourly tick.
		add_action( self::RUN_SWEEP_HOOK, array( $this, 'run_sweep' ) );
		add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
	}

	/**
	 * @param array<string,array{interval:int,display:string}> $schedules
	 *
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function register_five_minute_interval( array $schedules ): array {
		$schedules[ self::INTERVAL_SLUG ] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 5 minutes (WP-Phishing recipient import continuation)', 'wp-phishing' ),
		);

		return $schedules;
	}

	public function ensure_sweep_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_SWEEP_HOOK ) ) {
			wp_schedule_event( time(), self::INTERVAL_SLUG, self::RUN_SWEEP_HOOK );
		}
	}

	public function run_sweep(): void {
		( new RecipientImportService() )->run_sweep();
	}
}
