<?php
/**
 * Recipient import entity, per Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Enums\ImportSourceFormat;
use Alltime\WPPhishing\Recipients\Enums\ImportStatus;

final class RecipientImport {

	public function __construct(
		public readonly int $id,
		public readonly string $import_uuid,
		public readonly string $organisation_uuid,
		public readonly ImportStatus $status,
		public readonly ImportSourceFormat $source_format,
		public readonly ?string $original_filename,
		public readonly ?string $target_group_uuid,
		/** @var array<string,string>|null Uploaded column header => canonical field key. */
		public readonly ?array $column_mapping,
		public readonly int $total_rows,
		public readonly int $valid_rows,
		public readonly int $invalid_rows,
		public readonly int $duplicate_rows,
		public readonly int $suppressed_rows,
		public readonly int $committed_rows,
		public readonly int $next_unvalidated_row,
		public readonly int $next_uncommitted_row,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at,
		public readonly ?\DateTimeImmutable $committed_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$mapping = ! empty( $row['column_mapping'] ) ? json_decode( (string) $row['column_mapping'], true ) : null;

		return new self(
			id: (int) $row['id'],
			import_uuid: (string) $row['import_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			status: ImportStatus::from( (string) $row['status'] ),
			source_format: ImportSourceFormat::from( (string) $row['source_format'] ),
			original_filename: ! empty( $row['original_filename'] ) ? (string) $row['original_filename'] : null,
			target_group_uuid: ! empty( $row['target_group_uuid'] ) ? (string) $row['target_group_uuid'] : null,
			column_mapping: is_array( $mapping ) ? $mapping : null,
			total_rows: (int) $row['total_rows'],
			valid_rows: (int) $row['valid_rows'],
			invalid_rows: (int) $row['invalid_rows'],
			duplicate_rows: (int) $row['duplicate_rows'],
			suppressed_rows: (int) $row['suppressed_rows'],
			committed_rows: (int) $row['committed_rows'],
			next_unvalidated_row: (int) $row['next_unvalidated_row'],
			next_uncommitted_row: (int) $row['next_uncommitted_row'],
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] ),
			committed_at: ! empty( $row['committed_at'] ) ? new \DateTimeImmutable( (string) $row['committed_at'] ) : null
		);
	}
}
