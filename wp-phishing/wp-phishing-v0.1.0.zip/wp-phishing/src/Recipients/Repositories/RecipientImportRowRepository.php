<?php
/**
 * Persistence for staged recipient import rows against `wpp_recipient_import_rows`, per
 * Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Recipients\Enums\ImportRowStatus;
use Alltime\WPPhishing\Recipients\RecipientImportRow;

final class RecipientImportRowRepository {

	/**
	 * Rows are inserted in chunks of this size via one multi-VALUES INSERT each, rather than one
	 * INSERT per row - the difference between ~3 queries and ~500 for the spec's own 500-recipient
	 * example (Section 75).
	 */
	private const INSERT_CHUNK_SIZE = 200;

	/**
	 * @param array<int,array<string,string>> $rows Row number (1-based) => raw column data.
	 */
	public function create_batch( int $import_id, array $rows ): void {
		global $wpdb;

		$table = Schema::table( 'recipient_import_rows' );
		$now   = current_time( 'mysql', true );

		foreach ( array_chunk( $rows, self::INSERT_CHUNK_SIZE, true ) as $chunk ) {
			$placeholders = array();
			$values       = array();

			foreach ( $chunk as $row_number => $raw_data ) {
				$placeholders[] = '(%d, %d, %s, %s, %s)';
				array_push( $values, $import_id, $row_number, wp_json_encode( $raw_data ), ImportRowStatus::Pending->value, $now );
			}

			$sql = "INSERT INTO `{$table}` (import_id, row_number, raw_data, status, created_at) VALUES " . implode( ', ', $placeholders );

			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $table/$placeholders are fixed, internally derived identifiers (a closed %d/%s placeholder list built from a constant count), never user input; $values are passed through prepare()'s own escaping.
			$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}
	}

	/**
	 * The next batch of rows still needing validation, in row-number order - the unit of work a
	 * single validate() pass (synchronous or cron-continued) processes.
	 *
	 * @return RecipientImportRow[]
	 */
	public function find_batch_from( int $import_id, int $from_row_number, int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'recipient_import_rows' );
		$query = "SELECT * FROM `{$table}` WHERE import_id = %d AND row_number >= %d ORDER BY row_number ASC LIMIT %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, $import_id, $from_row_number, $limit ), ARRAY_A );

		return array_map( array( RecipientImportRow::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return RecipientImportRow[]
	 */
	public function find_all_for_import( int $import_id, int $per_page, int $page, ?ImportRowStatus $status = null ): array {
		global $wpdb;

		$table  = Schema::table( 'recipient_import_rows' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		if ( null !== $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE import_id = %d AND status = %s ORDER BY row_number ASC LIMIT %d OFFSET %d", $import_id, $status->value, $per_page, $offset ), ARRAY_A );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE import_id = %d ORDER BY row_number ASC LIMIT %d OFFSET %d", $import_id, $per_page, $offset ), ARRAY_A );
		}

		return array_map( array( RecipientImportRow::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function count_total( int $import_id ): int {
		global $wpdb;

		$table = Schema::table( 'recipient_import_rows' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE import_id = %d", $import_id ) );
	}

	/**
	 * Whether a row earlier in this same import (by row_number) already resolved to the same
	 * email and passed validation - the cross-batch, resumable duplicate check that lets
	 * validation proceed in bounded batches (Section 15) without needing all prior rows loaded
	 * into memory. Only rows that themselves passed (Valid or already Committed) count - a row
	 * an earlier batch rejected as Invalid must never cause a *later*, otherwise-good row to be
	 * flagged as its duplicate.
	 */
	public function has_earlier_valid_row_with_email( int $import_id, string $email_hash, int $before_row_number ): bool {
		global $wpdb;

		$table = Schema::table( 'recipient_import_rows' );
		$query = "SELECT COUNT(*) FROM `{$table}`
			WHERE import_id = %d AND email_hash = %s AND row_number < %d
			AND status IN ('valid', 'committed')";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		return 0 < (int) $wpdb->get_var( $wpdb->prepare( $query, $import_id, $email_hash, $before_row_number ) );
	}

	/**
	 * @param array<string,mixed> $mapped_data
	 * @param string[]|null $validation_errors
	 */
	public function record_validation_result( int $row_id, array $mapped_data, ImportRowStatus $status, ?array $validation_errors, ?string $email_hash = null ): void {
		global $wpdb;

		$table = Schema::table( 'recipient_import_rows' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'mapped_data'       => wp_json_encode( $mapped_data ),
				'email_hash'        => $email_hash,
				'status'            => $status->value,
				'validation_errors' => null !== $validation_errors && array() !== $validation_errors ? wp_json_encode( $validation_errors ) : null,
			),
			array( 'id' => $row_id )
		);
	}

	public function record_commit_result( int $row_id, int $recipient_id ): void {
		global $wpdb;

		$table = Schema::table( 'recipient_import_rows' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'       => ImportRowStatus::Committed->value,
				'recipient_id' => $recipient_id,
			),
			array( 'id' => $row_id )
		);
	}
}
