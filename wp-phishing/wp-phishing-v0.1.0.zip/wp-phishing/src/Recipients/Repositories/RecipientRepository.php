<?php
/**
 * Persistence for recipients against `wpp_recipients`.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Recipients\Enums\RecipientSource;
use Alltime\WPPhishing\Recipients\Enums\RecipientStatus;
use Alltime\WPPhishing\Recipients\Recipient;
use Alltime\WPPhishing\Recipients\RecipientInput;
use Alltime\WPPhishing\Recipients\Support\EmailNormaliser;

final class RecipientRepository {

	public function find( int $id ): ?Recipient {
		global $wpdb;

		$table = Schema::table( 'recipients' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d AND deleted_at IS NULL", $id ), ARRAY_A );

		return null !== $row ? Recipient::from_row( $row ) : null;
	}

	public function find_by_uuid( string $organisation_uuid, string $recipient_uuid ): ?Recipient {
		global $wpdb;

		$table = Schema::table( 'recipients' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE recipient_uuid = %s AND organisation_uuid = %s AND deleted_at IS NULL", $recipient_uuid, $organisation_uuid ), ARRAY_A );

		return null !== $row ? Recipient::from_row( $row ) : null;
	}

	public function find_by_email( string $organisation_uuid, string $email ): ?Recipient {
		global $wpdb;

		$table = Schema::table( 'recipients' );
		$hash  = EmailNormaliser::hash( $email );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s AND email_hash = %s AND deleted_at IS NULL", $organisation_uuid, $hash ), ARRAY_A );

		return null !== $row ? Recipient::from_row( $row ) : null;
	}

	/**
	 * @return Recipient[]
	 */
	public function find_all_for_organisation( string $organisation_uuid, int $per_page, int $page, ?RecipientStatus $status = null ): array {
		global $wpdb;

		$table  = Schema::table( 'recipients' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		if ( null !== $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s AND status = %s AND deleted_at IS NULL ORDER BY id ASC LIMIT %d OFFSET %d", $organisation_uuid, $status->value, $per_page, $offset ), ARRAY_A );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s AND deleted_at IS NULL ORDER BY id ASC LIMIT %d OFFSET %d", $organisation_uuid, $per_page, $offset ), ARRAY_A );
		}

		return array_map( array( Recipient::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function count_for_organisation( string $organisation_uuid ): int {
		global $wpdb;

		$table = Schema::table( 'recipients' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE organisation_uuid = %s AND deleted_at IS NULL", $organisation_uuid ) );
	}

	public function create(
		string $organisation_uuid,
		RecipientInput $input,
		RecipientSource $source,
		?string $source_reference,
		?string $contact_uuid = null
	): Recipient {
		global $wpdb;

		$table = Schema::table( 'recipients' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'recipient_uuid'            => wp_generate_uuid4(),
			'organisation_uuid'         => $organisation_uuid,
			'contact_uuid'              => $contact_uuid,
			'email'                     => EmailNormaliser::normalise( $input->email ),
			'email_hash'                => EmailNormaliser::hash( $input->email ),
			'given_name'                => $input->given_name,
			'family_name'               => $input->family_name,
			'job_title'                 => $input->job_title,
			'department'                => $input->department,
			'team'                      => $input->team,
			'location'                  => $input->location,
			'manager_reference'         => $input->manager_reference,
			'employment_classification' => $input->employment_classification,
			'status'                    => RecipientStatus::Active->value,
			'source'                    => $source->value,
			'source_reference'          => $source_reference,
			'metadata'                  => array() !== $input->metadata ? wp_json_encode( $input->metadata ) : null,
			'created_at'                => $now,
			'updated_at'                => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Re-imported data for an already-known recipient (matched by email within the organisation)
	 * updates their current fields - never their identity or history, and never touches
	 * `status`/`source` (Section 55: a suppressed recipient must not be reactivated simply
	 * because a later import contains them).
	 */
	public function update_fields( int $id, RecipientInput $input ): Recipient {
		global $wpdb;

		$table = Schema::table( 'recipients' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'given_name'                => $input->given_name,
				'family_name'               => $input->family_name,
				'job_title'                 => $input->job_title,
				'department'                => $input->department,
				'team'                      => $input->team,
				'location'                  => $input->location,
				'manager_reference'         => $input->manager_reference,
				'employment_classification' => $input->employment_classification,
				'metadata'                  => array() !== $input->metadata ? wp_json_encode( $input->metadata ) : null,
				'updated_at'                => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function update_status( int $id, RecipientStatus $status ): Recipient {
		global $wpdb;

		$table = Schema::table( 'recipients' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function soft_delete( int $id ): void {
		global $wpdb;

		$table = Schema::table( 'recipients' );
		$now   = current_time( 'mysql', true );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'     => RecipientStatus::Removed->value,
				'deleted_at' => $now,
				'updated_at' => $now,
			),
			array( 'id' => $id )
		);
	}

	private function find_or_fail( int $id ): Recipient {
		$recipient = $this->find( $id );

		if ( null === $recipient ) {
			throw new \RuntimeException( esc_html( "Recipient {$id} was expected to exist but could not be loaded." ) );
		}

		return $recipient;
	}
}
