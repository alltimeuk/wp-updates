<?php
/**
 * Persistence for recipient imports against `wpp_recipient_imports`, per Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Recipients\Enums\ImportSourceFormat;
use Alltime\WPPhishing\Recipients\Enums\ImportStatus;
use Alltime\WPPhishing\Recipients\RecipientImport;

final class RecipientImportRepository {

	public function find( int $id ): ?RecipientImport {
		global $wpdb;

		$table = Schema::table( 'recipient_imports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? RecipientImport::from_row( $row ) : null;
	}

	/**
	 * Looks up an import by UUID alone, without knowing its organisation in advance - the import
	 * item REST routes (Section 69) are addressed by import UUID only, so callers resolve the
	 * owning organisation from the returned import and enforce access against *that*
	 * ({@see \Alltime\WPPhishing\Support\TenantGuard}) rather than trusting a UUID's mere
	 * existence.
	 */
	public function find_by_uuid_in_any_organisation( string $import_uuid ): ?RecipientImport {
		global $wpdb;

		$table = Schema::table( 'recipient_imports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE import_uuid = %s", $import_uuid ), ARRAY_A );

		return null !== $row ? RecipientImport::from_row( $row ) : null;
	}

	public function find_by_uuid( string $organisation_uuid, string $import_uuid ): ?RecipientImport {
		global $wpdb;

		$table = Schema::table( 'recipient_imports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE import_uuid = %s AND organisation_uuid = %s", $import_uuid, $organisation_uuid ), ARRAY_A );

		return null !== $row ? RecipientImport::from_row( $row ) : null;
	}

	/**
	 * @return RecipientImport[]
	 */
	public function find_all_for_organisation( string $organisation_uuid, int $per_page, int $page ): array {
		global $wpdb;

		$table  = Schema::table( 'recipient_imports' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY id DESC LIMIT %d OFFSET %d", $organisation_uuid, $per_page, $offset ), ARRAY_A );

		return array_map( array( RecipientImport::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Every import with an outstanding batch of work (validation or commit), oldest first -
	 * background continuation's entry point. Not organisation-scoped: a sweep processes across
	 * every organisation, same shape as DomainVerificationService::run_sweep().
	 *
	 * @return RecipientImport[]
	 */
	public function find_in_progress( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'recipient_imports' );
		$query = "SELECT * FROM `{$table}` WHERE status IN ('validating', 'committing') ORDER BY updated_at ASC LIMIT %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, $limit ), ARRAY_A );

		return array_map( array( RecipientImport::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create( string $organisation_uuid, ImportSourceFormat $source_format, ?string $original_filename, ?int $created_by ): RecipientImport {
		global $wpdb;

		$table = Schema::table( 'recipient_imports' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'import_uuid'       => wp_generate_uuid4(),
			'organisation_uuid' => $organisation_uuid,
			'status'            => ImportStatus::Uploaded->value,
			'source_format'     => $source_format->value,
			'original_filename' => $original_filename,
			'created_by'        => $created_by,
			'created_at'        => $now,
			'updated_at'        => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function set_total_rows( int $id, int $total_rows ): RecipientImport {
		return $this->update( $id, array( 'total_rows' => $total_rows ) );
	}

	/**
	 * @param array<string,string> $mapping Uploaded column header => canonical field key.
	 */
	public function set_column_mapping( int $id, array $mapping, ?string $target_group_uuid ): RecipientImport {
		return $this->update(
			$id,
			array(
				'column_mapping'    => wp_json_encode( $mapping ),
				'target_group_uuid' => $target_group_uuid,
				'status'            => ImportStatus::Mapped->value,
			)
		);
	}

	public function update_status( int $id, ImportStatus $status ): RecipientImport {
		$data = array( 'status' => $status->value );

		if ( ImportStatus::Committed === $status ) {
			$data['committed_at'] = current_time( 'mysql', true );
		}

		return $this->update( $id, $data );
	}

	/**
	 * @param array{valid?:int,invalid?:int,duplicate?:int,suppressed?:int,committed?:int} $deltas
	 *        Amounts to add to each counter - never absolute values, since batched processing
	 *        (Section 15: "Large imports shall run asynchronously") updates counts incrementally
	 *        across many calls, not in one pass.
	 */
	public function increment_counts( int $id, array $deltas ): RecipientImport {
		global $wpdb;

		$table   = Schema::table( 'recipient_imports' );
		$columns = array(
			'valid'      => 'valid_rows',
			'invalid'    => 'invalid_rows',
			'duplicate'  => 'duplicate_rows',
			'suppressed' => 'suppressed_rows',
			'committed'  => 'committed_rows',
		);

		$sets = array( 'updated_at = %s' );
		$args = array( current_time( 'mysql', true ) );

		foreach ( $columns as $key => $column ) {
			if ( isset( $deltas[ $key ] ) && 0 !== $deltas[ $key ] ) {
				$sets[] = "{$column} = {$column} + %d";
				$args[] = $deltas[ $key ];
			}
		}

		$args[] = $id;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $table/$sets are fixed, internally derived identifiers built from a closed column allowlist above, never user input.
		$wpdb->query( $wpdb->prepare( "UPDATE `{$table}` SET " . implode( ', ', $sets ) . ' WHERE id = %d', ...$args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	public function advance_validation_cursor( int $id, int $next_row ): void {
		$this->update( $id, array( 'next_unvalidated_row' => $next_row ) );
	}

	public function advance_commit_cursor( int $id, int $next_row ): void {
		$this->update( $id, array( 'next_uncommitted_row' => $next_row ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function update( int $id, array $data ): RecipientImport {
		global $wpdb;

		$table = Schema::table( 'recipient_imports' );

		if ( ! isset( $data['updated_at'] ) ) {
			$data['updated_at'] = current_time( 'mysql', true );
		}

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): RecipientImport {
		$import = $this->find( $id );

		if ( null === $import ) {
			throw new \RuntimeException( esc_html( "Recipient import {$id} was expected to exist but could not be loaded." ) );
		}

		return $import;
	}
}
