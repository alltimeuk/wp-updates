<?php
/**
 * Persistence for recipient groups and their membership, against `wpp_recipient_groups` and
 * `wpp_recipient_group_members`.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Recipients\Enums\GroupType;
use Alltime\WPPhishing\Recipients\Recipient;
use Alltime\WPPhishing\Recipients\RecipientGroup;

final class RecipientGroupRepository {

	public function find( int $id ): ?RecipientGroup {
		global $wpdb;

		$table = Schema::table( 'recipient_groups' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? RecipientGroup::from_row( $row ) : null;
	}

	public function find_by_uuid( string $organisation_uuid, string $group_uuid ): ?RecipientGroup {
		global $wpdb;

		$table = Schema::table( 'recipient_groups' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE group_uuid = %s AND organisation_uuid = %s", $group_uuid, $organisation_uuid ), ARRAY_A );

		return null !== $row ? RecipientGroup::from_row( $row ) : null;
	}

	/**
	 * @return RecipientGroup[]
	 */
	public function find_all_for_organisation( string $organisation_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'recipient_groups' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY name ASC", $organisation_uuid ), ARRAY_A );

		return array_map( array( RecipientGroup::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create( string $organisation_uuid, string $name, ?string $description, GroupType $type = GroupType::Static ): RecipientGroup {
		global $wpdb;

		$table = Schema::table( 'recipient_groups' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'group_uuid'        => wp_generate_uuid4(),
			'organisation_uuid' => $organisation_uuid,
			'name'              => $name,
			'description'       => $description,
			'type'              => $type->value,
			'created_at'        => $now,
			'updated_at'        => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function delete( int $id ): void {
		global $wpdb;

		$members_table = Schema::table( 'recipient_group_members' );
		$groups_table  = Schema::table( 'recipient_groups' );

		$wpdb->delete( $members_table, array( 'group_id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $groups_table, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Idempotent: adding a recipient already in the group is a silent no-op (INSERT IGNORE),
	 * relying on the `group_recipient` unique key rather than a pre-check-then-insert race.
	 */
	public function add_member( int $group_id, int $recipient_id ): void {
		global $wpdb;

		$table = Schema::table( 'recipient_group_members' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO `{$table}` (group_id, recipient_id, added_at) VALUES (%d, %d, %s)", $group_id, $recipient_id, current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public function remove_member( int $group_id, int $recipient_id ): void {
		global $wpdb;

		$table = Schema::table( 'recipient_group_members' );

		$wpdb->delete(
			$table,
			array(
				'group_id'     => $group_id,
				'recipient_id' => $recipient_id,
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.Arrays.MultipleStatementAlignment.DoubleArrowNotAligned
	}

	/**
	 * @return Recipient[]
	 */
	public function find_members( int $group_id ): array {
		global $wpdb;

		$members_table    = Schema::table( 'recipient_group_members' );
		$recipients_table = Schema::table( 'recipients' );

		$query = "SELECT r.* FROM `{$recipients_table}` r
			INNER JOIN `{$members_table}` m ON m.recipient_id = r.id
			WHERE m.group_id = %d AND r.deleted_at IS NULL
			ORDER BY r.id ASC";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, $group_id ), ARRAY_A );

		return array_map( array( Recipient::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function count_members( int $group_id ): int {
		global $wpdb;

		$table = Schema::table( 'recipient_group_members' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE group_id = %d", $group_id ) );
	}

	private function find_or_fail( int $id ): RecipientGroup {
		$group = $this->find( $id );

		if ( null === $group ) {
			throw new \RuntimeException( esc_html( "Recipient group {$id} was expected to exist but could not be loaded." ) );
		}

		return $group;
	}
}
