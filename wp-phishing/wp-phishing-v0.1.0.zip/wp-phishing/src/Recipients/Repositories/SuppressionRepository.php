<?php
/**
 * Persistence for suppression records against `wpp_suppressions`, per Section 55.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\Support\EmailNormaliser;
use Alltime\WPPhishing\Recipients\Suppression;

final class SuppressionRepository {

	/**
	 * Whether any currently-active (non-expired) suppression exists for this address in this
	 * organisation - the fast-path check used throughout import validation and campaign
	 * targeting, without loading full suppression rows.
	 */
	public function is_suppressed( string $organisation_uuid, string $email ): bool {
		global $wpdb;

		$table = Schema::table( 'suppressions' );
		$hash  = EmailNormaliser::hash( $email );
		$now   = current_time( 'mysql', true );

		$query = "SELECT COUNT(*) FROM `{$table}`
			WHERE organisation_uuid = %s AND email_hash = %s
			AND (expires_at IS NULL OR expires_at > %s)";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table names only, no user input); phpcs cannot see that statically.
		return 0 < (int) $wpdb->get_var( $wpdb->prepare( $query, $organisation_uuid, $hash, $now ) );
	}

	/**
	 * @return Suppression[]
	 */
	public function find_all_for_organisation( string $organisation_uuid, int $per_page, int $page ): array {
		global $wpdb;

		$table  = Schema::table( 'suppressions' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_uuid = %s ORDER BY id DESC LIMIT %d OFFSET %d", $organisation_uuid, $per_page, $offset ), ARRAY_A );

		return array_map( array( Suppression::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create(
		string $organisation_uuid,
		string $email,
		SuppressionReason $reason,
		string $source,
		?string $note = null,
		?int $created_by = null,
		?\DateTimeImmutable $expires_at = null
	): Suppression {
		global $wpdb;

		$table = Schema::table( 'suppressions' );

		$data = array(
			'suppression_uuid'  => wp_generate_uuid4(),
			'organisation_uuid' => $organisation_uuid,
			'email_hash'        => EmailNormaliser::hash( $email ),
			'reason'            => $reason->value,
			'source'            => $source,
			'note'              => $note,
			'created_by'        => $created_by,
			'created_at'        => current_time( 'mysql', true ),
			'expires_at'        => $expires_at?->format( 'Y-m-d H:i:s' ),
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function find( int $id ): ?Suppression {
		global $wpdb;

		$table = Schema::table( 'suppressions' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Suppression::from_row( $row ) : null;
	}

	private function find_or_fail( int $id ): Suppression {
		$suppression = $this->find( $id );

		if ( null === $suppression ) {
			throw new \RuntimeException( esc_html( "Suppression {$id} was expected to exist but could not be loaded." ) );
		}

		return $suppression;
	}
}
