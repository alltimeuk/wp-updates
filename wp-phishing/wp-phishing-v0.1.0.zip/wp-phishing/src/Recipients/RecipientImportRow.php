<?php
/**
 * A single staged row within a recipient import, per Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Enums\ImportRowStatus;

final class RecipientImportRow {

	/**
	 * @param array<string,string> $raw_data The row exactly as parsed: uploaded column header => value.
	 * @param array<string,mixed>|null $mapped_data Canonical field key => value, once a mapping is applied.
	 * @param string[]|null $validation_errors
	 */
	public function __construct(
		public readonly int $id,
		public readonly int $import_id,
		public readonly int $row_number,
		public readonly array $raw_data,
		public readonly ?array $mapped_data,
		public readonly ?string $email_hash,
		public readonly ImportRowStatus $status,
		public readonly ?array $validation_errors,
		public readonly ?int $recipient_id,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$raw    = ! empty( $row['raw_data'] ) ? json_decode( (string) $row['raw_data'], true ) : array();
		$mapped = ! empty( $row['mapped_data'] ) ? json_decode( (string) $row['mapped_data'], true ) : null;
		$errors = ! empty( $row['validation_errors'] ) ? json_decode( (string) $row['validation_errors'], true ) : null;

		return new self(
			id: (int) $row['id'],
			import_id: (int) $row['import_id'],
			row_number: (int) $row['row_number'],
			raw_data: is_array( $raw ) ? $raw : array(),
			mapped_data: is_array( $mapped ) ? $mapped : null,
			email_hash: ! empty( $row['email_hash'] ) ? (string) $row['email_hash'] : null,
			status: ImportRowStatus::from( (string) $row['status'] ),
			validation_errors: is_array( $errors ) ? $errors : null,
			recipient_id: ! empty( $row['recipient_id'] ) ? (int) $row['recipient_id'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] )
		);
	}
}
