<?php
/**
 * Recipient entity, per Section 14.
 *
 * A phishing recipient is not automatically a canonical Alltime contact - {@see $contact_uuid}
 * stays nullable deliberately; an imported employee never automatically becomes a CRM lead,
 * marketing contact, customer user, or newsletter subscriber (Section 14/79).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Enums\RecipientSource;
use Alltime\WPPhishing\Recipients\Enums\RecipientStatus;

final class Recipient {

	public function __construct(
		public readonly int $id,
		public readonly string $recipient_uuid,
		public readonly string $organisation_uuid,
		public readonly ?string $contact_uuid,
		public readonly string $email,
		public readonly ?string $given_name,
		public readonly ?string $family_name,
		public readonly ?string $job_title,
		public readonly ?string $department,
		public readonly ?string $team,
		public readonly ?string $location,
		public readonly ?string $manager_reference,
		public readonly ?string $employment_classification,
		public readonly RecipientStatus $status,
		public readonly RecipientSource $source,
		public readonly ?string $source_reference,
		/** @var array<string,mixed> */
		public readonly array $metadata,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at,
		public readonly ?\DateTimeImmutable $deleted_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$metadata = ! empty( $row['metadata'] ) ? json_decode( (string) $row['metadata'], true ) : array();

		return new self(
			id: (int) $row['id'],
			recipient_uuid: (string) $row['recipient_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			contact_uuid: ! empty( $row['contact_uuid'] ) ? (string) $row['contact_uuid'] : null,
			email: (string) $row['email'],
			given_name: ! empty( $row['given_name'] ) ? (string) $row['given_name'] : null,
			family_name: ! empty( $row['family_name'] ) ? (string) $row['family_name'] : null,
			job_title: ! empty( $row['job_title'] ) ? (string) $row['job_title'] : null,
			department: ! empty( $row['department'] ) ? (string) $row['department'] : null,
			team: ! empty( $row['team'] ) ? (string) $row['team'] : null,
			location: ! empty( $row['location'] ) ? (string) $row['location'] : null,
			manager_reference: ! empty( $row['manager_reference'] ) ? (string) $row['manager_reference'] : null,
			employment_classification: ! empty( $row['employment_classification'] ) ? (string) $row['employment_classification'] : null,
			status: RecipientStatus::from( (string) $row['status'] ),
			source: RecipientSource::from( (string) $row['source'] ),
			source_reference: ! empty( $row['source_reference'] ) ? (string) $row['source_reference'] : null,
			metadata: is_array( $metadata ) ? $metadata : array(),
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] ),
			deleted_at: ! empty( $row['deleted_at'] ) ? new \DateTimeImmutable( (string) $row['deleted_at'] ) : null
		);
	}
}
