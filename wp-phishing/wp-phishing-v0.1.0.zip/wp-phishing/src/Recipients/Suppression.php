<?php
/**
 * Suppression record, per Section 55.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;

final class Suppression {

	public function __construct(
		public readonly int $id,
		public readonly string $suppression_uuid,
		public readonly string $organisation_uuid,
		public readonly string $email_hash,
		public readonly SuppressionReason $reason,
		public readonly string $source,
		public readonly ?string $note,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at,
		public readonly ?\DateTimeImmutable $expires_at
	) {}

	public function is_active( ?\DateTimeImmutable $now = null ): bool {
		if ( null === $this->expires_at ) {
			return true;
		}

		return $this->expires_at > ( $now ?? new \DateTimeImmutable() );
	}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			suppression_uuid: (string) $row['suppression_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			email_hash: (string) $row['email_hash'],
			reason: SuppressionReason::from( (string) $row['reason'] ),
			source: (string) $row['source'],
			note: ! empty( $row['note'] ) ? (string) $row['note'] : null,
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			expires_at: ! empty( $row['expires_at'] ) ? new \DateTimeImmutable( (string) $row['expires_at'] ) : null
		);
	}
}
