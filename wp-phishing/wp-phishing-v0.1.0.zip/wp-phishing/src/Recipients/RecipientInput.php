<?php
/**
 * Canonical mapped recipient fields, per Section 14/16 - the shape both direct recipient
 * creation and a validated import row's `mapped_data` conform to.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

final class RecipientInput {

	/**
	 * @param array<string,mixed> $metadata Custom fields beyond the fixed set below (Section 16).
	 */
	public function __construct(
		public readonly string $email,
		public readonly ?string $given_name = null,
		public readonly ?string $family_name = null,
		public readonly ?string $job_title = null,
		public readonly ?string $department = null,
		public readonly ?string $team = null,
		public readonly ?string $location = null,
		public readonly ?string $manager_reference = null,
		public readonly ?string $employment_classification = null,
		public readonly array $metadata = array()
	) {}
}
