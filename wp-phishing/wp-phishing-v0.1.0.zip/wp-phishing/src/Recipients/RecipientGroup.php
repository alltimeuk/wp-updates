<?php
/**
 * Recipient group entity, per Section 17.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Enums\GroupType;

final class RecipientGroup {

	public function __construct(
		public readonly int $id,
		public readonly string $group_uuid,
		public readonly string $organisation_uuid,
		public readonly string $name,
		public readonly ?string $description,
		public readonly GroupType $type,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			group_uuid: (string) $row['group_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			name: (string) $row['name'],
			description: ! empty( $row['description'] ) ? (string) $row['description'] : null,
			type: GroupType::from( (string) $row['type'] ),
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
