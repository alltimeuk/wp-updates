<?php
/**
 * Recipient import pipeline, per Section 15: upload -> parsing -> column mapping -> preview ->
 * validation -> duplicate detection -> invalid-address detection -> suppression checks ->
 * confirmation -> commit -> audit logging.
 *
 * Validation and commit are processed in bounded batches ({@see validate_batch()},
 * {@see commit_batch()}), each a unit of work small enough to run inline in a single request or
 * be continued by a background sweep - the "large imports run asynchronously" requirement,
 * satisfied the same way {@see \Alltime\WPPhishing\Verification\DomainVerificationService}
 * satisfies its own background continuation, without introducing a new job-queue mechanism.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Enums\ImportRowStatus;
use Alltime\WPPhishing\Recipients\Enums\ImportSourceFormat;
use Alltime\WPPhishing\Recipients\Enums\ImportStatus;
use Alltime\WPPhishing\Recipients\Enums\RecipientSource;
use Alltime\WPPhishing\Recipients\Repositories\RecipientGroupRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientImportRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientImportRowRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientRepository;
use Alltime\WPPhishing\Recipients\Repositories\SuppressionRepository;
use Alltime\WPPhishing\Recipients\Support\CanonicalFields;
use Alltime\WPPhishing\Recipients\Support\ColumnMapper;
use Alltime\WPPhishing\Recipients\Support\CsvParser;
use Alltime\WPPhishing\Recipients\Support\EmailNormaliser;
use Alltime\WPPhishing\Recipients\Support\TabularParserInterface;
use Alltime\WPPhishing\Recipients\Support\XlsxParser;
use Alltime\WPPhishing\Support\AuditLogger;

final class RecipientImportService {

	private const VALIDATION_BATCH_SIZE = 200;
	private const COMMIT_BATCH_SIZE     = 200;

	public function __construct(
		private readonly RecipientImportRepository $imports = new RecipientImportRepository(),
		private readonly RecipientImportRowRepository $rows = new RecipientImportRowRepository(),
		private readonly RecipientRepository $recipients = new RecipientRepository(),
		private readonly RecipientGroupRepository $groups = new RecipientGroupRepository(),
		private readonly SuppressionRepository $suppressions = new SuppressionRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly CsvParser $csv_parser = new CsvParser(),
		private readonly XlsxParser $xlsx_parser = new XlsxParser()
	) {}

	/**
	 * Steps 1-2: upload + parse. Stages every parsed row up front so later steps (mapping,
	 * validation, commit) are pure database operations, never re-reading the uploaded file.
	 */
	public function start_import(
		string $organisation_uuid,
		ImportSourceFormat $source_format,
		string $file_path,
		?string $original_filename,
		?int $created_by
	): RecipientImport {
		$parsed = $this->parser_for( $source_format )->parse( $file_path );

		$import = $this->imports->create( $organisation_uuid, $source_format, $original_filename, $created_by );
		$this->rows->create_batch( $import->id, $parsed['rows'] );
		$import = $this->imports->set_total_rows( $import->id, count( $parsed['rows'] ) );

		$this->audit_logger->log(
			'recipient_import.uploaded',
			'recipient_import',
			$import->import_uuid,
			$created_by,
			source: 'admin',
			organisation_uuid: $organisation_uuid,
			metadata: array(
				'total_rows' => $import->total_rows,
				'headers'    => $parsed['headers'],
			)
		);

		return $import;
	}

	/**
	 * The uploaded column headers, for the mapping UI - derived from the first staged row rather
	 * than stored separately, since every row's `raw_data` already carries them as keys.
	 *
	 * @return string[]
	 */
	public function detected_headers( RecipientImport $import ): array {
		$first = $this->rows->find_batch_from( $import->id, 1, 1 );

		return array() !== $first ? array_keys( $first[0]->raw_data ) : array();
	}

	/**
	 * Step 3: column mapping.
	 *
	 * @param array<string,string> $mapping
	 *
	 * @throws \InvalidArgumentException If the mapping is invalid (see {@see ColumnMapper::validate()}).
	 */
	public function set_column_mapping( RecipientImport $import, array $mapping, ?string $target_group_uuid = null ): RecipientImport {
		$errors = ColumnMapper::validate( $mapping );

		if ( array() !== $errors ) {
			throw new \InvalidArgumentException( esc_html( implode( ' ', $errors ) ) );
		}

		return $this->imports->set_column_mapping( $import->id, $mapping, $target_group_uuid );
	}

	/**
	 * Steps 4-8: preview / validation / duplicate detection / invalid-address detection /
	 * suppression checks - one bounded batch. Returns the refreshed import; call again while
	 * `status` is still Validating to continue.
	 */
	public function validate_batch( RecipientImport $import ): RecipientImport {
		if ( null === $import->column_mapping ) {
			throw new \RuntimeException( esc_html( 'A column mapping must be set before an import can be validated.' ) );
		}

		if ( ImportStatus::Validating !== $import->status ) {
			$import = $this->imports->update_status( $import->id, ImportStatus::Validating );
		}

		$from  = max( 1, $import->next_unvalidated_row );
		$batch = $this->rows->find_batch_from( $import->id, $from, self::VALIDATION_BATCH_SIZE );

		$last_row_number = $from - 1;

		foreach ( $batch as $row ) {
			$this->validate_row( $import, $row );
			$last_row_number = $row->row_number;
		}

		if ( count( $batch ) < self::VALIDATION_BATCH_SIZE ) {
			$import = $this->imports->update_status( $import->id, ImportStatus::Validated );

			$this->audit_logger->log(
				'recipient_import.validated',
				'recipient_import',
				$import->import_uuid,
				null,
				source: 'system',
				organisation_uuid: $import->organisation_uuid,
				metadata: array(
					'valid'      => $import->valid_rows,
					'invalid'    => $import->invalid_rows,
					'duplicate'  => $import->duplicate_rows,
					'suppressed' => $import->suppressed_rows,
				)
			);

			return $import;
		}

		$this->imports->advance_validation_cursor( $import->id, $last_row_number + 1 );

		return $this->imports->find( $import->id ) ?? $import;
	}

	/**
	 * @return RecipientImportRow[]
	 */
	public function preview( RecipientImport $import, int $per_page, int $page, ?ImportRowStatus $status = null ): array {
		return $this->rows->find_all_for_import( $import->id, $per_page, $page, $status );
	}

	/**
	 * Steps 9-11: confirmation / commit / audit logging - one bounded batch. Only rows left
	 * `valid` by validation are ever committed; invalid/duplicate/suppressed rows are skipped
	 * permanently. Returns the refreshed import; call again while `status` is still Committing.
	 */
	public function commit_batch( RecipientImport $import, ?int $committed_by = null ): RecipientImport {
		if ( ImportStatus::Validated !== $import->status && ImportStatus::Committing !== $import->status ) {
			throw new \RuntimeException( esc_html( 'An import must be fully validated before it can be committed.' ) );
		}

		if ( ImportStatus::Committing !== $import->status ) {
			$import = $this->imports->update_status( $import->id, ImportStatus::Committing );
		}

		$target_group = null !== $import->target_group_uuid
			? $this->groups->find_by_uuid( $import->organisation_uuid, $import->target_group_uuid )
			: null;

		$from  = max( 1, $import->next_uncommitted_row );
		$batch = $this->rows->find_batch_from( $import->id, $from, self::COMMIT_BATCH_SIZE );

		$last_row_number = $from - 1;
		$committed_count = 0;

		foreach ( $batch as $row ) {
			$last_row_number = $row->row_number;

			if ( ImportRowStatus::Valid !== $row->status ) {
				continue;
			}

			$input    = $this->recipient_input_from_mapped( $row->mapped_data ?? array() );
			$existing = $this->recipients->find_by_email( $import->organisation_uuid, $input->email );

			$recipient = null !== $existing
				? $this->recipients->update_fields( $existing->id, $input )
				: $this->recipients->create( $import->organisation_uuid, $input, $this->recipient_source_for( $import->source_format ), $import->import_uuid );

			if ( null !== $target_group ) {
				$this->groups->add_member( $target_group->id, $recipient->id );
			}

			$this->rows->record_commit_result( $row->id, $recipient->id );
			++$committed_count;
		}

		if ( $committed_count > 0 ) {
			$this->imports->increment_counts( $import->id, array( 'committed' => $committed_count ) );
		}

		if ( count( $batch ) < self::COMMIT_BATCH_SIZE ) {
			$import = $this->imports->update_status( $import->id, ImportStatus::Committed );

			$this->audit_logger->log(
				'recipient_import.committed',
				'recipient_import',
				$import->import_uuid,
				$committed_by,
				source: 'admin',
				organisation_uuid: $import->organisation_uuid,
				metadata: array( 'committed_rows' => $import->committed_rows )
			);

			return $import;
		}

		$this->imports->advance_commit_cursor( $import->id, $last_row_number + 1 );

		return $this->imports->find( $import->id ) ?? $import;
	}

	public function cancel( RecipientImport $import, ?int $cancelled_by = null ): RecipientImport {
		if ( $import->status->is_terminal() ) {
			throw new \RuntimeException( esc_html( 'This import has already reached a terminal state and cannot be cancelled.' ) );
		}

		$import = $this->imports->update_status( $import->id, ImportStatus::Cancelled );

		$this->audit_logger->log( 'recipient_import.cancelled', 'recipient_import', $import->import_uuid, $cancelled_by, source: 'admin', organisation_uuid: $import->organisation_uuid );

		return $import;
	}

	/**
	 * The background sweep's entry point: continues every import still mid-validation or
	 * mid-commit, one batch each, per tick - mirrors
	 * {@see \Alltime\WPPhishing\Verification\DomainVerificationService::run_sweep()}.
	 */
	public function run_sweep(): void {
		foreach ( $this->imports->find_in_progress( 20 ) as $import ) {
			try {
				if ( ImportStatus::Validating === $import->status ) {
					$this->validate_batch( $import );
				} elseif ( ImportStatus::Committing === $import->status ) {
					$this->commit_batch( $import );
				}
			} catch ( \Throwable $e ) {
				$this->audit_logger->log(
					'recipient_import.batch_failed',
					'recipient_import',
					$import->import_uuid,
					null,
					outcome: 'failure',
					summary: $e->getMessage(),
					source: 'cron',
					organisation_uuid: $import->organisation_uuid
				);
			}
		}
	}

	private function validate_row( RecipientImport $import, RecipientImportRow $row ): void {
		$mapped = ColumnMapper::apply( $import->column_mapping ?? array(), $row->raw_data );
		$email  = (string) ( $mapped[ CanonicalFields::EMAIL ] ?? '' );

		if ( '' === $email || ! EmailNormaliser::is_valid( $email ) ) {
			$this->rows->record_validation_result( $row->id, $mapped, ImportRowStatus::Invalid, array( 'Invalid or missing email address.' ) );
			$this->imports->increment_counts( $import->id, array( 'invalid' => 1 ) );
			return;
		}

		$email_hash = EmailNormaliser::hash( $email );

		if ( $this->rows->has_earlier_valid_row_with_email( $import->id, $email_hash, $row->row_number ) ) {
			$this->rows->record_validation_result( $row->id, $mapped, ImportRowStatus::Duplicate, array( 'Duplicate of an earlier row in this import.' ), $email_hash );
			$this->imports->increment_counts( $import->id, array( 'duplicate' => 1 ) );
			return;
		}

		if ( $this->suppressions->is_suppressed( $import->organisation_uuid, $email ) ) {
			$this->rows->record_validation_result( $row->id, $mapped, ImportRowStatus::Suppressed, array( 'This address is suppressed for this organisation.' ), $email_hash );
			$this->imports->increment_counts( $import->id, array( 'suppressed' => 1 ) );
			return;
		}

		$this->rows->record_validation_result( $row->id, $mapped, ImportRowStatus::Valid, null, $email_hash );
		$this->imports->increment_counts( $import->id, array( 'valid' => 1 ) );
	}

	/**
	 * @param array<string,mixed> $mapped
	 */
	private function recipient_input_from_mapped( array $mapped ): RecipientInput {
		$metadata = $mapped['metadata'] ?? array();

		return new RecipientInput(
			email: (string) ( $mapped[ CanonicalFields::EMAIL ] ?? '' ),
			given_name: isset( $mapped[ CanonicalFields::GIVEN_NAME ] ) ? (string) $mapped[ CanonicalFields::GIVEN_NAME ] : null,
			family_name: isset( $mapped[ CanonicalFields::FAMILY_NAME ] ) ? (string) $mapped[ CanonicalFields::FAMILY_NAME ] : null,
			job_title: isset( $mapped[ CanonicalFields::JOB_TITLE ] ) ? (string) $mapped[ CanonicalFields::JOB_TITLE ] : null,
			department: isset( $mapped[ CanonicalFields::DEPARTMENT ] ) ? (string) $mapped[ CanonicalFields::DEPARTMENT ] : null,
			team: isset( $mapped[ CanonicalFields::TEAM ] ) ? (string) $mapped[ CanonicalFields::TEAM ] : null,
			location: isset( $mapped[ CanonicalFields::LOCATION ] ) ? (string) $mapped[ CanonicalFields::LOCATION ] : null,
			manager_reference: isset( $mapped[ CanonicalFields::MANAGER_REFERENCE ] ) ? (string) $mapped[ CanonicalFields::MANAGER_REFERENCE ] : null,
			employment_classification: isset( $mapped[ CanonicalFields::EMPLOYMENT_CLASSIFICATION ] ) ? (string) $mapped[ CanonicalFields::EMPLOYMENT_CLASSIFICATION ] : null,
			metadata: is_array( $metadata ) ? $metadata : array()
		);
	}

	private function parser_for( ImportSourceFormat $format ): TabularParserInterface {
		return match ( $format ) {
			ImportSourceFormat::Csv => $this->csv_parser,
			ImportSourceFormat::Xlsx => $this->xlsx_parser,
			ImportSourceFormat::Manual, ImportSourceFormat::Pasted => throw new \InvalidArgumentException(
				esc_html( "{$format->value} imports are staged directly, not parsed from a file." )
			),
		};
	}

	private function recipient_source_for( ImportSourceFormat $format ): RecipientSource {
		return match ( $format ) {
			ImportSourceFormat::Csv => RecipientSource::CsvImport,
			ImportSourceFormat::Xlsx => RecipientSource::XlsxImport,
			ImportSourceFormat::Manual => RecipientSource::ManualEntry,
			ImportSourceFormat::Pasted => RecipientSource::Pasted,
		};
	}
}
