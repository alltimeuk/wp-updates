<?php
/**
 * Recipient group service, per Section 17. Static groups only - dynamic selection rules are a
 * Phase 2 (spec Section 77) capability (see {@see \Alltime\WPPhishing\Recipients\Enums\GroupType}).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Repositories\RecipientGroupRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class RecipientGroupService {

	public function __construct(
		private readonly RecipientGroupRepository $groups = new RecipientGroupRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return RecipientGroup[]
	 */
	public function list_for_organisation( string $organisation_uuid ): array {
		return $this->groups->find_all_for_organisation( $organisation_uuid );
	}

	public function get( string $organisation_uuid, string $group_uuid ): ?RecipientGroup {
		return $this->groups->find_by_uuid( $organisation_uuid, $group_uuid );
	}

	public function create( string $organisation_uuid, string $name, ?string $description, ?int $created_by = null ): RecipientGroup {
		$group = $this->groups->create( $organisation_uuid, $name, $description );

		$this->audit_logger->log( 'recipient_group.created', 'recipient_group', $group->group_uuid, $created_by, summary: $name, organisation_uuid: $organisation_uuid );

		return $group;
	}

	public function delete( RecipientGroup $group, ?int $deleted_by = null ): void {
		$this->groups->delete( $group->id );

		$this->audit_logger->log( 'recipient_group.deleted', 'recipient_group', $group->group_uuid, $deleted_by, summary: $group->name, organisation_uuid: $group->organisation_uuid );
	}

	/**
	 * @return Recipient[]
	 */
	public function list_members( RecipientGroup $group ): array {
		return $this->groups->find_members( $group->id );
	}

	public function count_members( RecipientGroup $group ): int {
		return $this->groups->count_members( $group->id );
	}

	public function add_member( RecipientGroup $group, Recipient $recipient, ?int $added_by = null ): void {
		$this->groups->add_member( $group->id, $recipient->id );

		$this->audit_logger->log( 'recipient_group.member_added', 'recipient_group', $group->group_uuid, $added_by, summary: $recipient->recipient_uuid, organisation_uuid: $group->organisation_uuid );
	}

	public function remove_member( RecipientGroup $group, Recipient $recipient, ?int $removed_by = null ): void {
		$this->groups->remove_member( $group->id, $recipient->id );

		$this->audit_logger->log( 'recipient_group.member_removed', 'recipient_group', $group->group_uuid, $removed_by, summary: $recipient->recipient_uuid, organisation_uuid: $group->organisation_uuid );
	}
}
