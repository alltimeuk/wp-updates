<?php
/**
 * XLSX recipient file parser, per Section 15. Reads only the active worksheet's first
 * contiguous data - multi-sheet workbooks are not otherwise supported.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Support;

use PhpOffice\PhpSpreadsheet\IOFactory;

final class XlsxParser implements TabularParserInterface {

	public function parse( string $file_path ): array {
		try {
			// createReader('Xlsx')->load(), not the lenient auto-detecting IOFactory::load() -
			// this class exists specifically for XLSX uploads (Section 15), and format
			// auto-detection can silently accept non-XLSX content (e.g. plain text falls back to
			// the CSV reader) instead of rejecting it with a clear error.
			$spreadsheet = IOFactory::createReader( 'Xlsx' )->load( $file_path );
		} catch ( \Throwable $exception ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- false positive: $exception here is the previous-exception constructor argument (for exception chaining), never output; the actual message text is already escaped above.
			throw new \RuntimeException( esc_html( 'Unable to read the uploaded XLSX file: ' . $exception->getMessage() ), 0, $exception );
		}

		$sheet         = $spreadsheet->getActiveSheet();
		$headers       = array();
		$rows          = array();
		$is_header_row = true;
		$row_number    = 1;

		foreach ( $sheet->getRowIterator() as $sheet_row ) {
			$cell_iterator = $sheet_row->getCellIterator();
			$cell_iterator->setIterateOnlyExistingCells( false );

			$values = array();

			foreach ( $cell_iterator as $cell ) {
				$values[] = trim( (string) $cell->getFormattedValue() );
			}

			if ( $is_header_row ) {
				$headers       = $values;
				$is_header_row = false;
				continue;
			}

			if ( 0 === count( array_filter( $values, static fn ( string $v ): bool => '' !== $v ) ) ) {
				continue;
			}

			$row = array();

			foreach ( $headers as $index => $header ) {
				$row[ $header ] = $values[ $index ] ?? '';
			}

			$rows[ $row_number ] = $row;
			++$row_number;
		}

		return array(
			'headers' => $headers,
			'rows'    => $rows,
		);
	}
}
