<?php
/**
 * Single source of truth for email normalisation/hashing across the Recipients module -
 * recipient creation, suppression checks, and import validation all need the *identical*
 * normalisation, since a mismatch here would let a suppressed address slip back in under a
 * differently-cased or padded form.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Support;

final class EmailNormaliser {

	public static function normalise( string $email ): string {
		return strtolower( trim( $email ) );
	}

	public static function hash( string $email ): string {
		return hash( 'sha256', self::normalise( $email ) );
	}

	public static function is_valid( string $email ): bool {
		return false !== filter_var( self::normalise( $email ), FILTER_VALIDATE_EMAIL );
	}
}
