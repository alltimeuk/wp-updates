<?php
/**
 * Parses an uploaded recipient file into a header row and data rows, per Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Support;

interface TabularParserInterface {

	/**
	 * @return array{headers: string[], rows: array<int,array<string,string>>} `rows` is keyed
	 *         by 1-based data-row number (the header row is never included as data).
	 */
	public function parse( string $file_path ): array;
}
