<?php
/**
 * The recipient fields an import column mapping may target, per Section 14. Every uploaded
 * column not mapped to one of these is collected into the recipient's free-form `metadata` bag
 * instead (Section 16: "Custom metadata fields may be supported").
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Support;

final class CanonicalFields {

	public const EMAIL                     = 'email';
	public const GIVEN_NAME                = 'given_name';
	public const FAMILY_NAME               = 'family_name';
	public const JOB_TITLE                 = 'job_title';
	public const DEPARTMENT                = 'department';
	public const TEAM                      = 'team';
	public const LOCATION                  = 'location';
	public const MANAGER_REFERENCE         = 'manager_reference';
	public const EMPLOYMENT_CLASSIFICATION = 'employment_classification';

	/**
	 * @return string[]
	 */
	public static function all(): array {
		return array(
			self::EMAIL,
			self::GIVEN_NAME,
			self::FAMILY_NAME,
			self::JOB_TITLE,
			self::DEPARTMENT,
			self::TEAM,
			self::LOCATION,
			self::MANAGER_REFERENCE,
			self::EMPLOYMENT_CLASSIFICATION,
		);
	}

	public static function is_known( string $field ): bool {
		return in_array( $field, self::all(), true );
	}
}
