<?php
/**
 * Applies an import's column mapping to one raw parsed row, per Section 15.
 *
 * A mapping is `uploaded column header => target`, where target is one of:
 *  - a canonical field key from {@see CanonicalFields::all()};
 *  - `metadata:{key}` to collect the column into the recipient's custom metadata bag
 *    (Section 16) under `{key}`;
 *  - absent entirely, to ignore that column.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Support;

final class ColumnMapper {

	private const METADATA_PREFIX = 'metadata:';

	/**
	 * @param array<string,string> $mapping  Uploaded column header => target.
	 * @param array<string,string> $raw_row  Uploaded column header => value.
	 *
	 * @return array<string,mixed> Canonical field keys plus a `metadata` sub-array.
	 */
	public static function apply( array $mapping, array $raw_row ): array {
		$mapped   = array();
		$metadata = array();

		foreach ( $mapping as $header => $target ) {
			if ( ! array_key_exists( $header, $raw_row ) ) {
				continue;
			}

			$value = trim( (string) $raw_row[ $header ] );

			if ( '' === $value ) {
				continue;
			}

			if ( str_starts_with( $target, self::METADATA_PREFIX ) ) {
				$key = substr( $target, strlen( self::METADATA_PREFIX ) );

				if ( '' !== $key ) {
					$metadata[ $key ] = $value;
				}

				continue;
			}

			if ( CanonicalFields::is_known( $target ) ) {
				$mapped[ $target ] = $value;
			}
		}

		$mapped['metadata'] = $metadata;

		return $mapped;
	}

	/**
	 * Validates a proposed mapping before it is stored: every target must be a known canonical
	 * field or a well-formed `metadata:{key}`, and {@see CanonicalFields::EMAIL} must be mapped
	 * from exactly one column - Section 14 makes email the one field every recipient must have.
	 *
	 * @param array<string,string> $mapping
	 *
	 * @return string[] Validation errors; empty when the mapping is valid.
	 */
	public static function validate( array $mapping ): array {
		$errors        = array();
		$email_targets = 0;

		foreach ( $mapping as $target ) {
			if ( CanonicalFields::EMAIL === $target ) {
				++$email_targets;
				continue;
			}

			if ( str_starts_with( $target, self::METADATA_PREFIX ) ) {
				if ( '' === substr( $target, strlen( self::METADATA_PREFIX ) ) ) {
					$errors[] = "Metadata mapping target \"{$target}\" has an empty key.";
				}
				continue;
			}

			if ( ! CanonicalFields::is_known( $target ) ) {
				$errors[] = "Unknown mapping target \"{$target}\".";
			}
		}

		if ( 0 === $email_targets ) {
			$errors[] = 'Exactly one column must be mapped to "email".';
		} elseif ( $email_targets > 1 ) {
			$errors[] = 'More than one column is mapped to "email".';
		}

		return $errors;
	}
}
