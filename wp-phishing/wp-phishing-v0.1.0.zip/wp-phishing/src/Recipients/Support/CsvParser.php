<?php
/**
 * CSV recipient file parser, per Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Support;

final class CsvParser implements TabularParserInterface {

	public function parse( string $file_path ): array {
		// Checked before fopen() rather than relying on its false return alone - fopen() also
		// raises an E_WARNING on failure, which a strict error handler (this codebase's own test
		// bootstrap included) can turn into an uncaught exception before the false-check below
		// ever runs.
		if ( ! is_readable( $file_path ) ) {
			throw new \RuntimeException( esc_html( "Unable to open CSV file: {$file_path}" ) );
		}

		$handle = fopen( $file_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- reading a plugin-managed temporary upload, not a user-supplied path; no WP_Filesystem context is available in this async-processable service.

		if ( false === $handle ) {
			throw new \RuntimeException( esc_html( "Unable to open CSV file: {$file_path}" ) );
		}

		try {
			$header_line = fgetcsv( $handle );

			if ( false === $header_line ) {
				return array(
					'headers' => array(),
					'rows'    => array(),
				);
			}

			// Strip a UTF-8 byte-order mark from the first header, if present - common in files
			// exported from Excel on Windows.
			if ( isset( $header_line[0] ) ) {
				$header_line[0] = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $header_line[0] ) ?? $header_line[0];
			}

			$headers = array_map( static fn ( mixed $h ): string => trim( (string) $h ), $header_line );

			$rows       = array();
			$row_number = 1;

			while ( false !== ( $line = fgetcsv( $handle ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition -- reading fgetcsv() one line at a time until EOF is the idiomatic pattern; hoisting the assignment out would just duplicate the call.
				if ( self::is_blank_row( $line ) ) {
					continue;
				}

				$row = array();

				foreach ( $headers as $index => $header ) {
					$row[ $header ] = isset( $line[ $index ] ) ? trim( (string) $line[ $index ] ) : '';
				}

				$rows[ $row_number ] = $row;
				++$row_number;
			}

			return array(
				'headers' => $headers,
				'rows'    => $rows,
			);
		} finally {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- see the fopen() call above.
		}
	}

	/**
	 * @param array<int,mixed>|null $line
	 */
	private static function is_blank_row( ?array $line ): bool {
		if ( null === $line ) {
			return true;
		}

		// PHP's fgetcsv() represents a genuinely empty line as [null], not [].
		return array( null ) === $line || 0 === count( array_filter( $line, static fn ( mixed $v ): bool => '' !== trim( (string) $v ) ) );
	}
}
