<?php
/**
 * Per-row status within a recipient import, per Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Enums;

enum ImportRowStatus: string {
	case Pending    = 'pending';
	case Valid      = 'valid';
	case Invalid    = 'invalid';
	case Duplicate  = 'duplicate';
	case Suppressed = 'suppressed';
	case Committed  = 'committed';
}
