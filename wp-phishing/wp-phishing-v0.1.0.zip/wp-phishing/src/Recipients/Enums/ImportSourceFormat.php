<?php
/**
 * The uploaded/submitted format of a recipient import, per Section 15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Enums;

enum ImportSourceFormat: string {
	case Csv    = 'csv';
	case Xlsx   = 'xlsx';
	case Manual = 'manual';
	case Pasted = 'pasted';
}
