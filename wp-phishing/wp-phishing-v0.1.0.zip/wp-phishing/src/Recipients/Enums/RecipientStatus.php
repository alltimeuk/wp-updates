<?php
/**
 * Recipient lifecycle status, per Section 14.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Enums;

enum RecipientStatus: string {
	case Active     = 'active';
	case Suppressed = 'suppressed';
	case Removed    = 'removed';
}
