<?php
/**
 * Recipient import lifecycle status, per Section 15's pipeline: upload -> parsing -> column
 * mapping -> preview -> validation -> duplicate/invalid/suppression detection -> confirmation ->
 * commit -> audit logging.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Enums;

enum ImportStatus: string {
	case Uploaded   = 'uploaded';
	case Mapped     = 'mapped';
	case Validating = 'validating';
	case Validated  = 'validated';
	case Committing = 'committing';
	case Committed  = 'committed';
	case Failed     = 'failed';
	case Cancelled  = 'cancelled';

	public function is_terminal(): bool {
		return in_array( $this, array( self::Committed, self::Failed, self::Cancelled ), true );
	}
}
