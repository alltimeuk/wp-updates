<?php
/**
 * Recipient group type, per Section 17. Dynamic groups (rule-evaluated membership) are a Phase 2
 * (spec Section 77) capability - the column and enum case exist now so the schema does not need
 * to change when that lands, but nothing in this module evaluates `rule_definition` yet.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Enums;

enum GroupType: string {
	case Static  = 'static';
	case Dynamic = 'dynamic';
}
