<?php
/**
 * Suppression reason, per Section 55.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Enums;

enum SuppressionReason: string {
	case HardBounce         = 'hard_bounce';
	case Complaint          = 'complaint';
	case CustomerExclusion  = 'customer_exclusion';
	case LegalExclusion     = 'legal_exclusion';
	case TestExclusion      = 'test_exclusion';
	case ExecutiveExclusion = 'executive_exclusion';
	case TemporaryExclusion = 'temporary_exclusion';
	/** The recipient themself used the unsubscribe link every delivery includes. */
	case RecipientOptOut = 'recipient_opt_out';
}
