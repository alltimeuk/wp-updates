<?php
/**
 * How a recipient entered the system, per Section 14/15.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Enums;

enum RecipientSource: string {
	case CsvImport   = 'csv_import';
	case XlsxImport  = 'xlsx_import';
	case ManualEntry = 'manual_entry';
	case Pasted      = 'pasted';
}
