<?php
/**
 * Issues and consumes short-lived, single-use, hashed tokens for email verification and
 * password reset, per Section 12.
 *
 * Only the SHA-256 hash of a token is ever persisted; the raw value exists only in memory long
 * enough to be embedded in the verification/reset link.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

use Alltime\WPPhishing\Auth\Enums\TokenType;
use Alltime\WPPhishing\Data\Schema;

final class TokenService {

	private const RAW_TOKEN_BYTES = 32;

	/**
	 * @return string The raw token. Callers must embed this in a URL/email immediately - it
	 *                 cannot be recovered once this call returns.
	 */
	public function issue( int $user_id, TokenType $type, int $ttl_seconds ): string {
		global $wpdb;

		$raw  = bin2hex( random_bytes( self::RAW_TOKEN_BYTES ) );
		$hash = hash( 'sha256', $raw );

		// Invalidate any outstanding tokens of this type for this user - only the most recently
		// issued token should ever be usable.
		$this->invalidate_outstanding( $user_id, $type );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'auth_tokens' ),
			array(
				'user_id'    => $user_id,
				'token_hash' => $hash,
				'type'       => $type->value,
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + $ttl_seconds ),
				'created_at' => current_time( 'mysql', true ),
			)
		);

		return $raw;
	}

	/**
	 * Validates and consumes a raw token. Returns the associated user ID once, and only once - a
	 * second call with the same token always returns null, even if it races the first call: the
	 * check (unused, right type, not expired) and the transition to used happen in one atomic
	 * conditional UPDATE, not a SELECT followed by a separate UPDATE.
	 */
	public function consume( string $raw_token, TokenType $type ): ?int {
		global $wpdb;

		$table = Schema::table( 'auth_tokens' );
		$hash  = hash( 'sha256', $raw_token );
		$now   = gmdate( 'Y-m-d H:i:s' );

		$query = "UPDATE `{$table}` SET used_at = %s WHERE token_hash = %s AND type = %s AND used_at IS NULL AND expires_at >= %s";

		$claimed = $wpdb->query( $wpdb->prepare( $query, $now, $hash, $type->value, $now ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.

		if ( ! $claimed ) {
			return null;
		}

		// Safe to read now without a race: this token is already marked used above, so no
		// concurrent caller can still be mid-flight expecting to win the same claim.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT user_id FROM `{$table}` WHERE token_hash = %s AND type = %s LIMIT 1", $hash, $type->value ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return null !== $row ? (int) $row['user_id'] : null;
	}

	private function invalidate_outstanding( int $user_id, TokenType $type ): void {
		global $wpdb;

		$table = Schema::table( 'auth_tokens' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array( 'used_at' => current_time( 'mysql', true ) ),
			array(
				'user_id' => $user_id,
				'type'    => $type->value,
			)
		);
	}
}
