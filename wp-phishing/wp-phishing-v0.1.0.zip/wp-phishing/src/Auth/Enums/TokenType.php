<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth\Enums;

enum TokenType: string {
	case EmailVerification = 'email_verification';
	case PasswordReset     = 'password_reset';
}
