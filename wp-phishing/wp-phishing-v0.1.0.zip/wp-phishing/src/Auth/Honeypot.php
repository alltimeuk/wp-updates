<?php
/**
 * A minimal bot deterrent for public customer-portal forms (registration, forgot-password): a
 * hidden field a human never fills in, plus a minimum time-to-submit check. This is not the
 * pluggable Turnstile/CAPTCHA adapter Section 58 describes - that remains separate, larger
 * AntiAbuse-module work (PLAN.md Phase 6); this is the same cheap, zero-infrastructure class of
 * protection as WP-Reconnaissance's `HoneypotCaptchaAdapter`, kept as a single static helper
 * rather than a full adapter interface since no second implementation exists yet to justify one.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

final class Honeypot {

	private const FIELD_NAME      = 'wpp_hp_website';
	private const TIMESTAMP_FIELD = 'wpp_hp_ts';
	private const MINIMUM_SECONDS = 3;

	public static function render(): string {
		return '<div style="position:absolute;left:-9999px;top:-9999px" aria-hidden="true">'
			. '<label>' . esc_html__( 'Leave this field blank', 'wp-phishing' ) . '<input type="text" name="' . esc_attr( self::FIELD_NAME ) . '" value="" tabindex="-1" autocomplete="off"></label>'
			. '</div>'
			. '<input type="hidden" name="' . esc_attr( self::TIMESTAMP_FIELD ) . '" value="' . esc_attr( (string) time() ) . '">';
	}

	/**
	 * True when the current POST request looks human: the honeypot field is empty and at least
	 * {@see MINIMUM_SECONDS} elapsed since the form was rendered.
	 */
	public static function passes(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- this check is the honeypot/timing signal itself, independent of (and in addition to) the form's own wp_verify_nonce() check performed separately by the caller.
		$field_value = isset( $_POST[ self::FIELD_NAME ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::FIELD_NAME ] ) ) : '';

		if ( '' !== $field_value ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
		$submitted_at = isset( $_POST[ self::TIMESTAMP_FIELD ] ) ? (int) $_POST[ self::TIMESTAMP_FIELD ] : 0;

		return $submitted_at > 0 && ( time() - $submitted_at ) >= self::MINIMUM_SECONDS;
	}
}
