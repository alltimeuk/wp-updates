<?php
/**
 * Thrown for genuine input-validation failures during registration (missing fields, password
 * mismatch, terms not accepted). Never thrown for "this email is already registered" - that case
 * is handled as a soft success to avoid account enumeration (Section 12).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth\Exceptions;

final class RegistrationException extends \RuntimeException {}
