<?php
/**
 * Dedicated customer authentication and account route bootstrap, per Section 12.
 *
 * Customers never register, sign in, reset passwords or manage their account through the native
 * wp-login.php presentation. The underlying identity records remain ordinary WordPress users
 * (core password hashing and session handling are retained via wp_insert_user(), wp_signon(),
 * wp_set_password()); this class owns the public `/customer/*` routes, form handling, validation
 * messages and redirections.
 *
 * Rendering here is deliberately minimal inline HTML, not a branded template layer - it exists so
 * the routes are genuinely functional end-to-end; a themed presentation is later work.
 *
 * Every route/handler builds its screen as a {@see CustomerPageResult} rather than echoing a full
 * document itself - {@see dispatch()} is the one place that wraps a result in the bare
 * `<!doctype html>` document these routes render.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;
use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;
use Alltime\CustomerPlatform\OrganisationInput;
use Alltime\CustomerPlatform\OrganisationMembership;
use Alltime\CustomerPlatform\OrganisationPlatformDiscovery;
use Alltime\CustomerPlatform\OrganisationServiceInterface;
use Alltime\WPPhishing\AntiAbuse\Turnstile;
use Alltime\WPPhishing\Auth\Enums\TokenType;
use Alltime\WPPhishing\Auth\Exceptions\RegistrationException;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Support\Roles;
use Alltime\WPPhishing\Support\TenantGuard;
use Alltime\WPPhishing\Verification\DomainVerificationService;
use Alltime\WPPhishing\Verification\SchemaNotReadyException;

final class AuthBootstrap {

	private const QUERY_VAR = 'wpp_customer_route';

	/** @var string[] */
	private const ROUTES = array( 'register', 'verify-email', 'login', 'logout', 'forgot-password', 'reset-password', 'account' );

	private RateLimiter $rate_limiter;

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly DomainVerificationService $domain_verification = new DomainVerificationService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {
		$this->rate_limiter = new RateLimiter();
	}

	public function boot(): void {
		add_action( 'init', array( $this, 'register_rewrite_rules' ) );
		add_filter( 'query_vars', array( $this, 'register_query_var' ) );
		add_action( 'template_redirect', array( $this, 'dispatch' ) );
	}

	public function register_rewrite_rules(): void {
		foreach ( self::ROUTES as $slug ) {
			add_rewrite_rule( '^customer/' . preg_quote( $slug, '/' ) . '/?$', 'index.php?' . self::QUERY_VAR . '=' . $slug, 'top' );
		}
	}

	/**
	 * @param string[] $vars
	 *
	 * @return string[]
	 */
	public function register_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	public function dispatch(): void {
		$route = get_query_var( self::QUERY_VAR );

		if ( ! is_string( $route ) || '' === $route || ! in_array( $route, self::ROUTES, true ) ) {
			return;
		}

		status_header( 200 );
		nocache_headers();

		$result = match ( $route ) {
			'register' => $this->handle_register(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->handle_login(),
			'logout' => $this->handle_logout(),
			'forgot-password' => $this->handle_forgot_password(),
			'reset-password' => $this->handle_reset_password(),
			'account' => $this->handle_account(),
		};

		echo '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html( $result->title ) . '</title></head><body>';
		echo '<h1>' . esc_html( $result->title ) . '</h1>';
		echo $result->body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $result->body is assembled from esc_html()/esc_attr()/esc_url()-escaped fragments and wp_nonce_field() by every caller.
		echo '</body></html>';

		exit;
	}

	// -----------------------------------------------------------------------------------
	// Registration
	// -----------------------------------------------------------------------------------

	private function handle_register(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_register_form();
		}

		if ( ! $this->verify_nonce( 'wpp_register' ) || ! Honeypot::passes() ) {
			return $this->render_register_form( __( 'Please try again.', 'wp-phishing' ) );
		}

		if ( ! $this->rate_limiter->allow( 'register', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS, $this->post_field( 'email' ) ) ) {
			return $this->render_register_form( __( 'Please try again in a little while.', 'wp-phishing' ) );
		}

		if ( ! Turnstile::verify( $this->post_field( 'cf-turnstile-response' ), $this->rate_limiter->client_ip() ) ) {
			return $this->render_register_form( __( 'Please try again.', 'wp-phishing' ) );
		}

		try {
			$result = ( new RegistrationService() )->register(
				$this->post_field( 'given_name' ),
				$this->post_field( 'family_name' ),
				$this->post_field( 'email' ),
				$this->post_field( 'password' ),
				$this->post_field( 'password_confirmation' ),
				$this->post_checked( 'terms_accepted' ),
				$this->post_checked( 'privacy_acknowledged' ),
				$this->post_checked( 'marketing_consent' )
			);
		} catch ( RegistrationException $exception ) {
			return $this->render_register_form( $exception->getMessage() );
		}

		// Section 12: identical response whether or not the address was already registered.
		if ( $result->is_new && null !== $result->user_id && null !== $result->verification_token ) {
			$this->send_verification_email( $result->user_id, $result->verification_token );
		}

		return $this->render_result(
			__( 'Check your email', 'wp-phishing' ),
			'<p>' . esc_html__( 'If your details were accepted, we have sent a verification link to the email address you provided. Follow it to activate your account.', 'wp-phishing' ) . '</p>'
		);
	}

	private function render_register_form( ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpp_register', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Given name', 'wp-phishing' ) . '<br><input type="text" name="given_name" required></label></p>
				<p><label>' . esc_html__( 'Family name', 'wp-phishing' ) . '<br><input type="text" name="family_name" required></label></p>
				<p><label>' . esc_html__( 'Email address', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Password', 'wp-phishing' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm password', 'wp-phishing' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><label><input type="checkbox" name="terms_accepted" value="1" required> ' . esc_html__( 'I accept the service terms.', 'wp-phishing' ) . '</label></p>
				<p><label><input type="checkbox" name="privacy_acknowledged" value="1" required> ' . esc_html__( 'I acknowledge the privacy notice.', 'wp-phishing' ) . '</label></p>
				<p><label><input type="checkbox" name="marketing_consent" value="1"> ' . esc_html__( 'I would like to receive occasional marketing updates (optional).', 'wp-phishing' ) . '</label></p>
				' . Honeypot::render() . '
				' . $this->turnstile_widget_html() . '
				<p><button type="submit">' . esc_html__( 'Create account', 'wp-phishing' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Already have an account? Sign in.', 'wp-phishing' ) . '</a></p>';

		return $this->render_result( __( 'Create your account', 'wp-phishing' ), $body );
	}

	private function send_verification_email( int $user_id, string $token ): void {
		$user = get_userdata( $user_id );

		if ( false === $user ) {
			return;
		}

		$link = add_query_arg( 'token', $token, home_url( '/customer/verify-email/' ) );

		// A single, low-volume transactional email - deliberately plain wp_mail(), not the
		// multi-provider queue (Section 25) that governs bulk phishing-simulation delivery.
		wp_mail( // phpcs:ignore WordPress.WP.AlternativeFunctions.wp_mail_wp_mail -- transactional account email, not campaign simulation delivery; see docblock.
			$user->user_email,
			__( 'Verify your email address', 'wp-phishing' ),
			sprintf(
				/* translators: %s: verification link */
				__( "Please verify your email address by visiting the following link:\n\n%s", 'wp-phishing' ),
				esc_url_raw( $link )
			)
		);
	}

	// -----------------------------------------------------------------------------------
	// Email verification
	// -----------------------------------------------------------------------------------

	private function handle_verify_email(): CustomerPageResult {
		$token = $this->get_field( 'token' );

		if ( '' === $token ) {
			return $this->render_result( __( 'Verify your email', 'wp-phishing' ), '<p>' . esc_html__( 'No verification token was supplied.', 'wp-phishing' ) . '</p>' );
		}

		$user_id = ( new TokenService() )->consume( $token, TokenType::EmailVerification );

		if ( null === $user_id ) {
			return $this->render_result( __( 'Verify your email', 'wp-phishing' ), '<p>' . esc_html__( 'This verification link is invalid or has expired.', 'wp-phishing' ) . '</p>' );
		}

		update_user_meta( $user_id, RegistrationService::EMAIL_VERIFIED_META_KEY, true );

		$this->audit_logger->log( 'registration.email_verified', 'user', (string) $user_id, $user_id, source: 'customer_portal' );

		return $this->render_result(
			__( 'Verify your email', 'wp-phishing' ),
			'<p>' . esc_html__( 'Your email address has been verified. You can now sign in.', 'wp-phishing' ) . '</p><p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Sign in', 'wp-phishing' ) . '</a></p>'
		);
	}

	// -----------------------------------------------------------------------------------
	// Login / logout
	// -----------------------------------------------------------------------------------

	private function handle_login(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_login_form();
		}

		if ( ! $this->verify_nonce( 'wpp_login' ) || ! $this->rate_limiter->allow( 'login', $this->rate_limiter->client_ip(), 10, 15 * MINUTE_IN_SECONDS, $this->post_field( 'email' ) ) ) {
			return $this->render_login_form( __( 'Too many attempts. Please try again shortly.', 'wp-phishing' ) );
		}

		$generic_error = __( 'Incorrect email address or password.', 'wp-phishing' );

		$user = wp_signon(
			array(
				'user_login'    => $this->post_field( 'email' ),
				'user_password' => $this->post_field( 'password' ),
				'remember'      => true,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			return $this->render_login_form( $generic_error );
		}

		if ( ! in_array( Roles::CUSTOMER_ROLE, (array) $user->roles, true ) ) {
			wp_logout();
			return $this->render_login_form( $generic_error );
		}

		if ( ! (bool) get_user_meta( $user->ID, RegistrationService::EMAIL_VERIFIED_META_KEY, true ) ) {
			wp_logout();
			return $this->render_login_form( __( 'Please verify your email address before signing in.', 'wp-phishing' ) );
		}

		wp_safe_redirect( home_url( '/customer/account/' ) );
		exit;
	}

	private function render_login_form( ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpp_login', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Email address', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Password', 'wp-phishing' ) . '<br><input type="password" name="password" required></label></p>
				<p><button type="submit">' . esc_html__( 'Sign in', 'wp-phishing' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( home_url( '/customer/forgot-password/' ) ) . '">' . esc_html__( 'Forgotten your password?', 'wp-phishing' ) . '</a></p>
			<p><a href="' . esc_url( home_url( '/customer/register/' ) ) . '">' . esc_html__( 'Create an account', 'wp-phishing' ) . '</a></p>';

		return $this->render_result( __( 'Sign in', 'wp-phishing' ), $body );
	}

	private function handle_logout(): CustomerPageResult {
		wp_logout();
		wp_safe_redirect( home_url( '/customer/login/' ) );
		exit;
	}

	// -----------------------------------------------------------------------------------
	// Forgot / reset password
	// -----------------------------------------------------------------------------------

	private function handle_forgot_password(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_forgot_password_form();
		}

		$generic_notice = __( 'If an account exists for that address, we have sent password reset instructions.', 'wp-phishing' );

		if ( ! $this->verify_nonce( 'wpp_forgot_password' ) || ! Honeypot::passes() || ! $this->rate_limiter->allow( 'forgot_password', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS, $this->post_field( 'email' ) ) ) {
			return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
		}

		if ( ! Turnstile::verify( $this->post_field( 'cf-turnstile-response' ), $this->rate_limiter->client_ip() ) ) {
			return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
		}

		$user = get_user_by( 'email', $this->post_field( 'email' ) );

		if ( false !== $user && in_array( Roles::CUSTOMER_ROLE, (array) $user->roles, true ) ) {
			$token = ( new TokenService() )->issue( $user->ID, TokenType::PasswordReset, HOUR_IN_SECONDS );
			$link  = add_query_arg( 'token', $token, home_url( '/customer/reset-password/' ) );

			wp_mail( // phpcs:ignore WordPress.WP.AlternativeFunctions.wp_mail_wp_mail -- transactional account email, not campaign simulation delivery.
				$user->user_email,
				__( 'Reset your password', 'wp-phishing' ),
				sprintf(
					/* translators: %s: reset link */
					__( "Reset your password by visiting the following link (valid for one hour):\n\n%s", 'wp-phishing' ),
					esc_url_raw( $link )
				)
			);

			$this->audit_logger->log( 'password_reset.requested', 'user', (string) $user->ID, $user->ID, source: 'customer_portal' );
		}

		// Identical response whether or not the address matched an account (Section 12).
		return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
	}

	private function render_forgot_password_form(): CustomerPageResult {
		$body = '<form method="post">
			' . wp_nonce_field( 'wpp_forgot_password', '_wpnonce', true, false ) . '
			<p><label>' . esc_html__( 'Email address', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>
			' . Honeypot::render() . '
			' . $this->turnstile_widget_html() . '
			<p><button type="submit">' . esc_html__( 'Send reset instructions', 'wp-phishing' ) . '</button></p>
		</form>';

		return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), $body );
	}

	private function handle_reset_password(): CustomerPageResult {
		$token = $this->is_post() ? $this->post_field( 'token' ) : $this->get_field( 'token' );

		if ( '' === $token ) {
			return $this->render_result( __( 'Reset password', 'wp-phishing' ), '<p>' . esc_html__( 'No reset token was supplied.', 'wp-phishing' ) . '</p>' );
		}

		if ( ! $this->is_post() ) {
			return $this->render_reset_password_form( $token );
		}

		if ( ! $this->verify_nonce( 'wpp_reset_password' ) ) {
			return $this->render_reset_password_form( $token, __( 'Please try again.', 'wp-phishing' ) );
		}

		$password              = $this->post_field( 'password' );
		$password_confirmation = $this->post_field( 'password_confirmation' );

		if ( strlen( $password ) < 12 ) {
			return $this->render_reset_password_form( $token, __( 'Password must be at least 12 characters long.', 'wp-phishing' ) );
		}

		if ( $password !== $password_confirmation ) {
			return $this->render_reset_password_form( $token, __( 'Password and confirmation do not match.', 'wp-phishing' ) );
		}

		$user_id = ( new TokenService() )->consume( $token, TokenType::PasswordReset );

		if ( null === $user_id ) {
			return $this->render_result( __( 'Reset password', 'wp-phishing' ), '<p>' . esc_html__( 'This reset link is invalid or has expired.', 'wp-phishing' ) . '</p>' );
		}

		reset_password( get_userdata( $user_id ), $password );

		$this->audit_logger->log( 'password_reset.completed', 'user', (string) $user_id, $user_id, source: 'customer_portal' );

		return $this->render_result(
			__( 'Reset password', 'wp-phishing' ),
			'<p>' . esc_html__( 'Your password has been reset. You can now sign in.', 'wp-phishing' ) . '</p><p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Sign in', 'wp-phishing' ) . '</a></p>'
		);
	}

	private function render_reset_password_form( string $token, ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpp_reset_password', '_wpnonce', true, false ) . '
				<input type="hidden" name="token" value="' . esc_attr( $token ) . '">
				<p><label>' . esc_html__( 'New password', 'wp-phishing' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm new password', 'wp-phishing' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><button type="submit">' . esc_html__( 'Reset password', 'wp-phishing' ) . '</button></p>
			</form>';

		return $this->render_result( __( 'Reset password', 'wp-phishing' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Account dashboard
	// -----------------------------------------------------------------------------------

	private function handle_account(): CustomerPageResult {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/customer/login/' ) );
			exit;
		}

		$notice = null;

		if ( $this->is_post() && $this->verify_nonce( 'wpp_account_action' ) ) {
			$notice = $this->handle_account_action();
		}

		return $this->render_account_page( $notice );
	}

	/**
	 * @return string|null An error message to show, or null on success (a success banner is
	 *                       shown instead, distinguished by {@see render_account_page()}'s
	 *                       `$notice` handling being purely informational either way here).
	 */
	private function handle_account_action(): ?string {
		$user_id = get_current_user_id();
		$action  = $this->post_field( 'wpp_account_action' );

		return match ( $action ) {
			'create_organisation' => $this->handle_create_organisation( $user_id ),
			'add_domain' => $this->handle_add_domain(),
			'start_verification' => $this->handle_start_verification( $user_id ),
			'check_verification' => $this->handle_check_verification(),
			'accept_invitation' => $this->handle_accept_invitation( $user_id ),
			default => __( 'Unrecognised action.', 'wp-phishing' ),
		};
	}

	private function handle_create_organisation( int $user_id ): ?string {
		$name = $this->post_field( 'name' );

		if ( '' === trim( $name ) ) {
			return __( 'An organisation name is required.', 'wp-phishing' );
		}

		$service = $this->organisation_service();
		$result  = $service->create_or_update_organisation( new OrganisationInput( name: $name ) );

		$membership = $service->add_member( $result->organisation->organisation_uuid, $user_id, MembershipRole::Owner );
		$service->update_member_status( $membership->id, MembershipStatus::Active );

		return null;
	}

	private function handle_add_domain(): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$domain            = strtolower( trim( $this->post_field( 'domain' ) ) );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage domains for this organisation.', 'wp-phishing' );
		}

		if ( '' === $domain || ! preg_match( '/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/', $domain ) ) {
			return __( 'A valid domain name is required.', 'wp-phishing' );
		}

		$service = $this->organisation_service();

		if ( null !== $service->find_domain_by_ascii( $domain ) ) {
			return __( 'This domain is already registered to an organisation.', 'wp-phishing' );
		}

		$service->add_domain( $organisation_uuid, $domain, DomainVerificationMethod::DnsTxt );

		return null;
	}

	private function handle_start_verification( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$domain_uuid       = $this->post_field( 'domain_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage domains for this organisation.', 'wp-phishing' );
		}

		try {
			$this->domain_verification->generate_challenge( $domain_uuid, $user_id, 'customer_portal' );
		} catch ( SchemaNotReadyException | \InvalidArgumentException $exception ) {
			return $exception->getMessage(); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- rendered via esc_html() in error_html() below.
		}

		return null;
	}

	private function handle_check_verification(): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$domain_uuid       = $this->post_field( 'domain_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage domains for this organisation.', 'wp-phishing' );
		}

		$domain = $this->organisation_service()->get_domain( $domain_uuid );

		if ( null === $domain || $domain->organisation_uuid !== $organisation_uuid ) {
			return __( 'Domain not found.', 'wp-phishing' );
		}

		$verified = $this->domain_verification->check( $domain, 'customer_portal' );

		return $verified ? null : __( 'The verification record was not found yet. DNS changes can take time to propagate - try again shortly.', 'wp-phishing' );
	}

	private function handle_accept_invitation( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$service           = $this->organisation_service();
		$membership        = $service->get_membership( $organisation_uuid, $user_id );

		if ( null === $membership || MembershipStatus::Invited !== $membership->status ) {
			return __( 'This invitation is no longer available.', 'wp-phishing' );
		}

		$service->update_member_status( $membership->id, MembershipStatus::Active );

		$this->audit_logger->log( 'organisation.invitation_accepted', 'organisation', $organisation_uuid, $user_id, source: 'customer_portal', organisation_uuid: $organisation_uuid );

		return null;
	}

	private function render_account_page( ?string $notice ): CustomerPageResult {
		$user_id     = get_current_user_id();
		$user        = wp_get_current_user();
		$service     = $this->organisation_service();
		$memberships = $service->get_memberships_for_user( $user_id );

		$active_memberships  = array_values( array_filter( $memberships, static fn ( OrganisationMembership $m ): bool => MembershipStatus::Active === $m->status ) );
		$pending_invitations = array_values( array_filter( $memberships, static fn ( OrganisationMembership $m ): bool => MembershipStatus::Invited === $m->status ) );

		$body = $this->error_html( $notice );

		$body .= '<p>' . sprintf(
			/* translators: %s: display name */
			esc_html__( 'Signed in as %s.', 'wp-phishing' ),
			esc_html( $user->display_name )
		) . ' <a href="' . esc_url( home_url( '/customer/logout/' ) ) . '">' . esc_html__( 'Sign out', 'wp-phishing' ) . '</a></p>';

		if ( array() !== $pending_invitations ) {
			$body .= '<h2>' . esc_html__( 'Pending invitations', 'wp-phishing' ) . '</h2>';

			foreach ( $pending_invitations as $membership ) {
				$organisation = $service->get_by_uuid( $membership->organisation_uuid );

				if ( null === $organisation ) {
					continue;
				}

				$body .= '<form method="post" style="display:inline">'
					. wp_nonce_field( 'wpp_account_action', '_wpnonce', true, false )
					. '<input type="hidden" name="wpp_account_action" value="accept_invitation">'
					. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
					. '<p>' . esc_html( $organisation->name ) . ' (' . esc_html( $membership->role->value ) . ') '
					. '<button type="submit">' . esc_html__( 'Accept invitation', 'wp-phishing' ) . '</button></p>'
					. '</form>';
			}
		}

		$body .= '<h2>' . esc_html__( 'Your organisations', 'wp-phishing' ) . '</h2>';

		if ( array() === $active_memberships ) {
			$body .= '<p>' . esc_html__( 'You do not belong to any organisation yet.', 'wp-phishing' ) . '</p>';
		}

		foreach ( $active_memberships as $membership ) {
			$organisation = $service->get_by_uuid( $membership->organisation_uuid );

			if ( null === $organisation ) {
				continue;
			}

			$body .= $this->render_organisation_section( $organisation->organisation_uuid, $organisation->name, $membership->role );
		}

		$body .= '<h3>' . esc_html__( 'Establish a new organisation', 'wp-phishing' ) . '</h3>'
			. '<form method="post">'
			. wp_nonce_field( 'wpp_account_action', '_wpnonce', true, false )
			. '<input type="hidden" name="wpp_account_action" value="create_organisation">'
			. '<p><label>' . esc_html__( 'Organisation name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><button type="submit">' . esc_html__( 'Create organisation', 'wp-phishing' ) . '</button></p>'
			. '</form>';

		return new CustomerPageResult( __( 'My account', 'wp-phishing' ), $body );
	}

	private function render_organisation_section( string $organisation_uuid, string $name, MembershipRole $role ): string {
		$can_manage = in_array( $role, array( MembershipRole::Owner, MembershipRole::Administrator ), true );
		$service    = $this->organisation_service();

		$section = '<h3>' . esc_html( $name ) . ' <small>(' . esc_html( $role->value ) . ')</small></h3>';

		if ( ! $can_manage ) {
			return $section;
		}

		$section .= '<h4>' . esc_html__( 'Domains', 'wp-phishing' ) . '</h4><ul>';

		foreach ( $service->get_domains( $organisation_uuid ) as $domain ) {
			$section .= '<li>' . esc_html( $domain->domain_ascii ) . ' - ' . esc_html( $domain->verification_status->value );

			if ( DomainVerificationMethod::DnsTxt === $domain->verification_method ) {
				if ( DomainVerificationStatus::Pending === $domain->verification_status && null !== $domain->verification_reference ) {
					$section .= '<br>' . esc_html__( 'Publish this DNS TXT record on the domain itself:', 'wp-phishing' )
						. ' <code>' . esc_html( $this->domain_verification->txt_record_value( $domain->verification_reference, $domain->verification_requested_at ) ) . '</code>'
						. '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_account_action', '_wpnonce', true, false )
						. '<input type="hidden" name="wpp_account_action" value="check_verification">'
						. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
						. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
						. '<button type="submit">' . esc_html__( 'Check now', 'wp-phishing' ) . '</button></form>';
				} elseif ( DomainVerificationStatus::Verified !== $domain->verification_status ) {
					$section .= '<form method="post" style="display:inline">' . wp_nonce_field( 'wpp_account_action', '_wpnonce', true, false )
						. '<input type="hidden" name="wpp_account_action" value="start_verification">'
						. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
						. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
						. '<button type="submit">' . esc_html__( 'Get verification code', 'wp-phishing' ) . '</button></form>';
				}
			}

			$section .= '</li>';
		}

		$section .= '</ul>'
			. '<form method="post">' . wp_nonce_field( 'wpp_account_action', '_wpnonce', true, false )
			. '<input type="hidden" name="wpp_account_action" value="add_domain">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Add a domain', 'wp-phishing' ) . '<br><input type="text" name="domain" placeholder="example.com" required></label> '
			. '<button type="submit">' . esc_html__( 'Add', 'wp-phishing' ) . '</button></p>'
			. '</form>';

		return $section;
	}

	// -----------------------------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------------------------

	private function organisation_service(): OrganisationServiceInterface {
		$service = OrganisationPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No organisation service is registered.' ) );
		}

		return $service;
	}

	private function is_post(): bool {
		return isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
	}

	private function post_field( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- every caller verifies the relevant action nonce itself (see verify_nonce()) before reading any field.
		return isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : '';
	}

	private function post_checked( string $name ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see post_field().
		return ! empty( $_POST[ $name ] );
	}

	private function get_field( string $name ): string {
		return isset( $_GET[ $name ] ) && is_string( $_GET[ $name ] ) ? sanitize_text_field( wp_unslash( $_GET[ $name ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only token lookup (email verification / password reset links), not a state-changing action.
	}

	private function verify_nonce( string $action ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- this method *is* the nonce verification.
		$nonce  = isset( $_POST['_wpnonce'] ) && is_string( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
		$result = wp_verify_nonce( $nonce, $action );

		// wp_verify_nonce() returns 1 for a nonce in its first 12-hour "tick" and 2 for one in its
		// second - both are legitimately still valid; only `false` (or 0) means invalid/expired.
		return 1 === $result || 2 === $result;
	}

	private function error_html( ?string $message ): string {
		return null !== $message ? '<p style="color:red">' . esc_html( $message ) . '</p>' : '';
	}

	/**
	 * Empty when Turnstile is unconfigured - {@see Turnstile::verify()} fails open in that case
	 * too, so omitting the widget here is purely cosmetic (no point showing a challenge that
	 * verification would never actually check).
	 */
	private function turnstile_widget_html(): string {
		if ( ! Turnstile::configured() ) {
			return '';
		}

		wp_enqueue_script( 'wpp-turnstile', Turnstile::WIDGET_SCRIPT_URL, array(), null, array( 'strategy' => 'async' ) ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Cloudflare serves this URL unversioned by design (their own embed snippet never appends one); Cloudflare's own CDN handles cache-busting.

		ob_start();
		wp_print_scripts( array( 'wpp-turnstile' ) );
		$script_tag = ob_get_clean();

		return ( false !== $script_tag ? $script_tag : '' ) . '<div class="cf-turnstile" data-sitekey="' . esc_attr( Turnstile::site_key() ) . '"></div>';
	}

	private function render_result( string $title, string $body ): CustomerPageResult {
		return new CustomerPageResult( $title, $body );
	}
}
