<?php
/**
 * A rendered customer-portal screen: the plain page title (for a route's <title> tag) and its
 * body HTML (already escaped by whichever render_/handle_ method in {@see AuthBootstrap} built
 * it). Kept apart rather than pre-joined into one HTML string so {@see AuthBootstrap::dispatch()}
 * is the one place that wraps a result in a document, leaving room for a themed/shortcode
 * rendering path later without touching any handler.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

final class CustomerPageResult {

	public function __construct(
		public readonly string $title,
		public readonly string $body
	) {}
}
