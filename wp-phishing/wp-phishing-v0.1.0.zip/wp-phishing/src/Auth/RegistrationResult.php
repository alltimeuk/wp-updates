<?php
/**
 * Outcome of a registration attempt. `is_new` is deliberately not exposed to the visitor - the
 * front-end controller shows the same generic message regardless, per Section 12's implicit
 * anti-enumeration requirement (never confirm whether an address is already registered).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

final class RegistrationResult {

	public function __construct(
		public readonly bool $is_new,
		public readonly ?int $user_id,
		public readonly ?string $verification_token
	) {}
}
