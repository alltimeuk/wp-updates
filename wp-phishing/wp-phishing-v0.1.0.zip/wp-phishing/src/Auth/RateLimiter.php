<?php
/**
 * Per-IP (and, where cheaply available, per-email) throttle for the public customer-portal
 * endpoints (registration, login, password reset), per Section 57.
 *
 * Delegates to {@see \Alltime\WPPhishing\AntiAbuse\RateLimiter}, the table-backed, HMAC-hashed,
 * multi-dimensional mechanism Section 57 actually describes (mirroring WP-Questionnaires'
 * `wpq_rate_limits` convention, with two gaps in that implementation fixed rather than
 * reproduced - see that class's own docblock). This class keeps its own public signature stable
 * so `AuthBootstrap`'s call sites did not need to change shape, only to start passing a second
 * identifier where one is cheaply available.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

use Alltime\WPPhishing\AntiAbuse\RateLimiter as AntiAbuseRateLimiter;

final class RateLimiter {

	private AntiAbuseRateLimiter $rate_limiter;

	public function __construct() {
		$this->rate_limiter = new AntiAbuseRateLimiter();
	}

	public function allow( string $action, string $identifier, int $max_attempts, int $window_seconds, ?string $secondary_identifier = null ): bool {
		return $this->rate_limiter->allow( $action, $identifier, $max_attempts, $window_seconds, $secondary_identifier );
	}

	public function client_ip(): string {
		$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
		return is_string( $ip ) ? $ip : '0.0.0.0';
	}
}
