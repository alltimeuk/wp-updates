<?php
/**
 * Handles new customer registration, per Section 12.
 *
 * Deliberately does not create an organisation as part of registration - unlike a single-purpose
 * registration flow tied to one domain/assessment, Section 1 frames "establish or select an
 * organisation" as the customer's own next step once they hold an account, and the REST API
 * ({@see \Alltime\WPPhishing\Api\OrganisationsController}) and this module's own account page
 * already cover that step. Registration's only job is to create the WordPress account and link
 * the canonical Customer Platform contact.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

use Alltime\CustomerPlatform\ConsentInput;
use Alltime\CustomerPlatform\ContactInput;
use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\Enums\ConsentState;
use Alltime\CustomerPlatform\InteractionInput;
use Alltime\CustomerPlatform\PurposeContext;
use Alltime\WPPhishing\Auth\Enums\TokenType;
use Alltime\WPPhishing\Auth\Exceptions\RegistrationException;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Support\Roles;

final class RegistrationService {

	private const MINIMUM_PASSWORD_LENGTH       = 12;
	public const EMAIL_VERIFICATION_TTL_SECONDS = 24 * HOUR_IN_SECONDS;

	/** User meta key: bool, whether the account has completed email verification. */
	public const EMAIL_VERIFIED_META_KEY = 'wpp_email_verified';

	/** User meta key: bool, direct-marketing-email consent captured at registration (Section 52). */
	public const MARKETING_CONSENT_META_KEY = 'wpp_marketing_consent';

	public function __construct(
		private readonly TokenService $tokens = new TokenService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @throws RegistrationException When the submitted input itself is invalid. Never thrown for
	 *                                 an email address that is already registered (Section 12:
	 *                                 no confirmation of an existing account).
	 */
	public function register(
		string $given_name,
		string $family_name,
		string $email,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged,
		bool $marketing_consent
	): RegistrationResult {
		$this->validate( $given_name, $family_name, $email, $password, $password_confirmation, $terms_accepted, $privacy_acknowledged );

		if ( email_exists( $email ) ) {
			$this->audit_logger->log( 'registration.duplicate_attempt', 'user', null, null, outcome: 'rejected', source: 'customer_portal' );

			return new RegistrationResult( is_new: false, user_id: null, verification_token: null );
		}

		$user_id = wp_insert_user(
			array(
				'user_login'   => $email,
				'user_email'   => $email,
				'user_pass'    => $password,
				'first_name'   => $given_name,
				'last_name'    => $family_name,
				'display_name' => trim( "{$given_name} {$family_name}" ),
				'role'         => Roles::CUSTOMER_ROLE,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			throw new RegistrationException( esc_html( $user_id->get_error_message() ) );
		}

		update_user_meta( $user_id, self::EMAIL_VERIFIED_META_KEY, false );
		update_user_meta( $user_id, self::MARKETING_CONSENT_META_KEY, $marketing_consent );

		$this->audit_logger->log( 'registration.created', 'user', (string) $user_id, $user_id, source: 'customer_portal' );

		// Deliberately outside any transaction and never allowed to fail registration itself -
		// the Customer Platform contact service (Section 6) is explicitly designed to remain
		// usable even when unavailable; a lost contact-platform sync is recoverable, a WordPress
		// account that failed to register is a worse outcome for the customer.
		try {
			$this->record_contact_platform_registration( $given_name, $family_name, $email, $user_id, $marketing_consent );
		} catch ( \Throwable $exception ) {
			$this->audit_logger->log( 'registration.contact_platform_sync_failed', 'user', (string) $user_id, $user_id, outcome: 'failure', summary: $exception->getMessage(), source: 'customer_portal' );
		}

		$verification_token = $this->tokens->issue( $user_id, TokenType::EmailVerification, self::EMAIL_VERIFICATION_TTL_SECONDS );

		return new RegistrationResult( is_new: true, user_id: $user_id, verification_token: $verification_token );
	}

	private function record_contact_platform_registration( string $given_name, string $family_name, string $email, int $user_id, bool $marketing_consent ): void {
		$contact_service = ContactPlatformDiscovery::resolve();

		if ( null === $contact_service ) {
			return;
		}

		$purpose = new PurposeContext( 'wp-phishing', 'customer_registration' );
		$result  = $contact_service->create_or_update_contact( new ContactInput( $given_name, $family_name, $email ), $purpose );

		$contact_service->link_wordpress_user( $result->contact->id, $user_id );

		$contact_service->record_interaction(
			$result->contact->id,
			new InteractionInput(
				product_id: 'wp-phishing',
				interaction_type: 'registration_completed',
				source_object_type: 'user',
				source_object_id: $user_id
			)
		);

		$contact_service->record_consent(
			$result->contact->id,
			new ConsentInput(
				purpose: 'direct_marketing_email',
				state: $marketing_consent ? ConsentState::Granted : ConsentState::Withdrawn,
				source: 'registration_form'
			)
		);
	}

	private function validate(
		string $given_name,
		string $family_name,
		string $email,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged
	): void {
		if ( '' === trim( $given_name ) || '' === trim( $family_name ) ) {
			throw new RegistrationException( 'Given name and family name are required.' );
		}

		if ( ! is_email( $email ) ) {
			throw new RegistrationException( 'A valid email address is required.' );
		}

		if ( strlen( $password ) < self::MINIMUM_PASSWORD_LENGTH ) {
			throw new RegistrationException( 'Password must be at least ' . self::MINIMUM_PASSWORD_LENGTH . ' characters long.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- an exception message is not browser output; AuthBootstrap escapes it via esc_html() when rendering it.
		}

		if ( $password !== $password_confirmation ) {
			throw new RegistrationException( 'Password and confirmation do not match.' );
		}

		if ( ! $terms_accepted ) {
			throw new RegistrationException( 'You must accept the service terms to register.' );
		}

		if ( ! $privacy_acknowledged ) {
			throw new RegistrationException( 'You must acknowledge the privacy notice to register.' );
		}
	}
}
