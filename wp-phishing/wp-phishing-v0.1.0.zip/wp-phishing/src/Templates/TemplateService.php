<?php
/**
 * Template service, per Section 28.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates;

use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Templates\Enums\Difficulty;
use Alltime\WPPhishing\Templates\Enums\Scenario;
use Alltime\WPPhishing\Templates\Enums\TemplateStatus;
use Alltime\WPPhishing\Templates\Repositories\TemplateRepository;

final class TemplateService {

	public function __construct(
		private readonly TemplateRepository $templates = new TemplateRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return Template[]
	 */
	public function list_available_for_organisation( string $organisation_uuid ): array {
		return $this->templates->find_available_for_organisation( $organisation_uuid );
	}

	public function get( string $template_uuid ): ?Template {
		return $this->templates->find_by_uuid( $template_uuid );
	}

	public function current_version( Template $template ): ?TemplateVersion {
		return null !== $template->current_version_id ? $this->templates->find_version( $template->current_version_id ) : null;
	}

	/**
	 * @return TemplateVersion[]
	 */
	public function list_versions( Template $template ): array {
		return $this->templates->find_versions( $template->id );
	}

	/**
	 * @param string[] $risk_tags
	 */
	public function create(
		?string $organisation_uuid,
		string $name,
		Scenario $scenario,
		Difficulty $difficulty,
		array $risk_tags,
		string $subject,
		string $from_display_name,
		?string $html_body,
		?string $text_body,
		?string $learning_objective,
		?int $created_by = null
	): Template {
		$template = $this->templates->create( $organisation_uuid, $name, $scenario, $difficulty, $risk_tags, $created_by );

		$this->templates->create_version( $template->id, $subject, $from_display_name, $html_body, $text_body, $learning_objective, $created_by );

		$this->audit_logger->log( 'template.created', 'template', $template->template_uuid, $created_by, summary: $name, organisation_uuid: $organisation_uuid );

		// Re-fetch: create_version() above set current_version_id/updated_at on the row, which
		// the $template value already in hand does not reflect.
		return $this->templates->find( $template->id ) ?? $template;
	}

	public function create_new_version(
		Template $template,
		string $subject,
		string $from_display_name,
		?string $html_body,
		?string $text_body,
		?string $learning_objective,
		?int $created_by = null
	): TemplateVersion {
		$version = $this->templates->create_version( $template->id, $subject, $from_display_name, $html_body, $text_body, $learning_objective, $created_by );

		$this->audit_logger->log( 'template.new_version', 'template', $template->template_uuid, $created_by, summary: "version {$version->version_number}", organisation_uuid: $template->organisation_uuid );

		return $version;
	}

	public function update_status( Template $template, TemplateStatus $status, ?int $updated_by = null ): Template {
		$updated = $this->templates->update_status( $template->id, $status );

		$this->audit_logger->log( 'template.status_updated', 'template', $template->template_uuid, $updated_by, summary: $status->value, organisation_uuid: $template->organisation_uuid );

		return $updated;
	}
}
