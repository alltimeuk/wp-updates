<?php
/**
 * One immutable version of a template's content, per Section 28. A campaign wave locks in a
 * specific version so a later edit to the template never rewrites what was actually sent.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates;

final class TemplateVersion {

	public function __construct(
		public readonly int $id,
		public readonly int $template_id,
		public readonly int $version_number,
		public readonly string $subject,
		public readonly string $from_display_name,
		public readonly ?string $html_body,
		public readonly ?string $text_body,
		public readonly ?string $learning_objective,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			template_id: (int) $row['template_id'],
			version_number: (int) $row['version_number'],
			subject: (string) $row['subject'],
			from_display_name: (string) $row['from_display_name'],
			html_body: ! empty( $row['html_body'] ) ? (string) $row['html_body'] : null,
			text_body: ! empty( $row['text_body'] ) ? (string) $row['text_body'] : null,
			learning_objective: ! empty( $row['learning_objective'] ) ? (string) $row['learning_objective'] : null,
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] )
		);
	}
}
