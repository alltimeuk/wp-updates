<?php
/**
 * Persistence for templates and their versions, against `wpp_templates` and
 * `wpp_template_versions`, per Section 28.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Templates\Enums\Difficulty;
use Alltime\WPPhishing\Templates\Enums\Scenario;
use Alltime\WPPhishing\Templates\Enums\TemplateStatus;
use Alltime\WPPhishing\Templates\Template;
use Alltime\WPPhishing\Templates\TemplateVersion;

final class TemplateRepository {

	public function find( int $id ): ?Template {
		global $wpdb;

		$table = Schema::table( 'templates' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Template::from_row( $row ) : null;
	}

	public function find_by_uuid( string $template_uuid ): ?Template {
		global $wpdb;

		$table = Schema::table( 'templates' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE template_uuid = %s", $template_uuid ), ARRAY_A );

		return null !== $row ? Template::from_row( $row ) : null;
	}

	/**
	 * Every template available to the organisation: its own plus the shared library
	 * (`organisation_uuid IS NULL`), per Section 28/29.
	 *
	 * @return Template[]
	 */
	public function find_available_for_organisation( string $organisation_uuid ): array {
		global $wpdb;

		$table = Schema::table( 'templates' );

		$query = "SELECT * FROM `{$table}` WHERE (organisation_uuid = %s OR organisation_uuid IS NULL) AND status = %s ORDER BY name ASC";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$rows = $wpdb->get_results( $wpdb->prepare( $query, $organisation_uuid, TemplateStatus::Active->value ), ARRAY_A );

		return array_map( array( Template::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function find_version( int $id ): ?TemplateVersion {
		global $wpdb;

		$table = Schema::table( 'template_versions' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? TemplateVersion::from_row( $row ) : null;
	}

	/**
	 * @return TemplateVersion[]
	 */
	public function find_versions( int $template_id ): array {
		global $wpdb;

		$table = Schema::table( 'template_versions' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE template_id = %d ORDER BY version_number DESC", $template_id ), ARRAY_A );

		return array_map( array( TemplateVersion::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create( ?string $organisation_uuid, string $name, Scenario $scenario, Difficulty $difficulty, array $risk_tags, ?int $created_by ): Template {
		global $wpdb;

		$table = Schema::table( 'templates' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'template_uuid'     => wp_generate_uuid4(),
			'organisation_uuid' => $organisation_uuid,
			'name'              => $name,
			'scenario'          => $scenario->value,
			'difficulty'        => $difficulty->value,
			'risk_tags'         => array() !== $risk_tags ? wp_json_encode( array_values( $risk_tags ) ) : null,
			'status'            => TemplateStatus::Draft->value,
			'created_by'        => $created_by,
			'created_at'        => $now,
			'updated_at'        => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Creates a new immutable version and points the template's `current_version_id` at it -
	 * editing a template never mutates a version already locked into a campaign wave.
	 */
	public function create_version(
		int $template_id,
		string $subject,
		string $from_display_name,
		?string $html_body,
		?string $text_body,
		?string $learning_objective,
		?int $created_by
	): TemplateVersion {
		global $wpdb;

		$versions_table  = Schema::table( 'template_versions' );
		$templates_table = Schema::table( 'templates' );
		$now             = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $versions_table is a fixed, internally derived identifier, not user input.
		$next_version = 1 + (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(version_number) FROM `{$versions_table}` WHERE template_id = %d", $template_id ) );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$versions_table,
			array(
				'template_id'        => $template_id,
				'version_number'     => $next_version,
				'subject'            => $subject,
				'from_display_name'  => $from_display_name,
				'html_body'          => $html_body,
				'text_body'          => $text_body,
				'learning_objective' => $learning_objective,
				'created_by'         => $created_by,
				'created_at'         => $now,
			)
		);

		$version_id = (int) $wpdb->insert_id;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$templates_table,
			array(
				'current_version_id' => $version_id,
				'updated_at'         => $now,
			),
			array( 'id' => $template_id )
		);

		return $this->find_version_or_fail( $version_id );
	}

	public function update_status( int $template_id, TemplateStatus $status ): Template {
		global $wpdb;

		$table = Schema::table( 'templates' );

		$wpdb->update(
			$table,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $template_id )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.Arrays.MultipleStatementAlignment.DoubleArrowNotAligned

		return $this->find_or_fail( $template_id );
	}

	private function find_or_fail( int $id ): Template {
		$template = $this->find( $id );

		if ( null === $template ) {
			throw new \RuntimeException( esc_html( "Template {$id} was expected to exist but could not be loaded." ) );
		}

		return $template;
	}

	private function find_version_or_fail( int $id ): TemplateVersion {
		$version = $this->find_version( $id );

		if ( null === $version ) {
			throw new \RuntimeException( esc_html( "Template version {$id} was expected to exist but could not be loaded." ) );
		}

		return $version;
	}
}
