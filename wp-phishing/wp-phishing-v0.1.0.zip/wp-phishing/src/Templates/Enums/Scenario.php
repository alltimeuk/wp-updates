<?php
/**
 * Initial scenario library, per Section 29. "Expandable without database redesign" is satisfied
 * by the underlying column being a plain string - adding a case here is a code change, not a
 * schema migration.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates\Enums;

enum Scenario: string {
	case AccountPasswordExpiry      = 'account_password_expiry';
	case Microsoft365Authentication = 'microsoft365_authentication';
	case DocumentSharing            = 'document_sharing';
	case InvoicePayment             = 'invoice_payment';
	case DeliveryNotification       = 'delivery_notification';
	case HrCommunication            = 'hr_communication';
	case Payroll                    = 'payroll';
	case ExecutiveRequest           = 'executive_request';
	case SupplierCommunication      = 'supplier_communication';
	case SecurityWarning            = 'security_warning';
	case Voicemail                  = 'voicemail';
	case MeetingInvitation          = 'meeting_invitation';
}
