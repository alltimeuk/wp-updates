<?php
/**
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates\Enums;

enum TemplateStatus: string {
	case Draft    = 'draft';
	case Active   = 'active';
	case Archived = 'archived';
}
