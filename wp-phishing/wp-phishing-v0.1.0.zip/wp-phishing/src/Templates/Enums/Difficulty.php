<?php
/**
 * Template difficulty classification, per Section 30. Campaign metadata only - must never be
 * presented as proof an employee should necessarily have identified the simulation.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates\Enums;

enum Difficulty: string {
	case Obvious  = 'obvious';
	case Basic    = 'basic';
	case Moderate = 'moderate';
	case Advanced = 'advanced';
	case Targeted = 'targeted';
}
