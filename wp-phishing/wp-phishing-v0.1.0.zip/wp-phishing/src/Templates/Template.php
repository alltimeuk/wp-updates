<?php
/**
 * Template identity, per Section 28. `organisation_uuid` is nullable: null is a shared library
 * template available to every organisation, set is one an organisation authored for itself -
 * mirroring `Sending\SenderDomain`'s shared-pool convention.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates;

use Alltime\WPPhishing\Templates\Enums\Difficulty;
use Alltime\WPPhishing\Templates\Enums\Scenario;
use Alltime\WPPhishing\Templates\Enums\TemplateStatus;

final class Template {

	public function __construct(
		public readonly int $id,
		public readonly string $template_uuid,
		public readonly ?string $organisation_uuid,
		public readonly string $name,
		public readonly Scenario $scenario,
		public readonly Difficulty $difficulty,
		/** @var string[] */
		public readonly array $risk_tags,
		public readonly TemplateStatus $status,
		public readonly ?int $current_version_id,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$risk_tags = ! empty( $row['risk_tags'] ) ? json_decode( (string) $row['risk_tags'], true ) : array();

		return new self(
			id: (int) $row['id'],
			template_uuid: (string) $row['template_uuid'],
			organisation_uuid: ! empty( $row['organisation_uuid'] ) ? (string) $row['organisation_uuid'] : null,
			name: (string) $row['name'],
			scenario: Scenario::from( (string) $row['scenario'] ),
			difficulty: Difficulty::from( (string) $row['difficulty'] ),
			risk_tags: is_array( $risk_tags ) ? $risk_tags : array(),
			status: TemplateStatus::from( (string) $row['status'] ),
			current_version_id: ! empty( $row['current_version_id'] ) ? (int) $row['current_version_id'] : null,
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
