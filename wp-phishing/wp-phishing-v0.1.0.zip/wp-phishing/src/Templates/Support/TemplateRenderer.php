<?php
/**
 * Whitelisted `{{variable}}` substitution for rendering a template version against a specific
 * delivery, per Section 28. Arbitrary PHP execution is never permitted (Section 28/70): this is a
 * plain string substitution over a fixed, named variable set, never `eval()`/`extract()`, and any
 * `{{token}}` outside that set is left untouched rather than resolved.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Templates\Support;

final class TemplateRenderer {

	/** @var string[] */
	private const ALLOWED_VARIABLES = array(
		'given_name',
		'family_name',
		'organisation_name',
		'department',
		'manager_name',
		'campaign_token',
	);

	/**
	 * Renders into an HTML context: each substituted value is passed through `esc_html()` first,
	 * since variable values (a recipient's name/department, for instance) are data, not markup.
	 *
	 * @param array<string,string> $variables
	 */
	public function render_html( string $content, array $variables ): string {
		return $this->substitute( $content, $variables, escape: true );
	}

	/**
	 * Renders into a plain-text context (the text body, or the subject line) - no HTML escaping.
	 *
	 * @param array<string,string> $variables
	 */
	public function render_text( string $content, array $variables ): string {
		return $this->substitute( $content, $variables, escape: false );
	}

	/**
	 * @param array<string,string> $variables
	 */
	private function substitute( string $content, array $variables, bool $escape ): string {
		$replaced = preg_replace_callback(
			'/\{\{\s*([a-zA-Z_]+)\s*\}\}/',
			static function ( array $matches ) use ( $variables, $escape ): string {
				$name = $matches[1];

				if ( ! in_array( $name, self::ALLOWED_VARIABLES, true ) || ! isset( $variables[ $name ] ) ) {
					return $matches[0];
				}

				return $escape ? esc_html( $variables[ $name ] ) : $variables[ $name ];
			},
			$content
		);

		return null !== $replaced ? $replaced : $content;
	}
}
