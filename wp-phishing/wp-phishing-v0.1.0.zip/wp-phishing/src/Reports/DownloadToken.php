<?php
/**
 * A secure, revocable download token, per Section 59: stored hashed, purpose-scoped, expiring,
 * use-limited where appropriate, revocable, referencing its authorised resource server-side.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports;

use Alltime\WPPhishing\Support\Dates;

final class DownloadToken {

	public function __construct(
		public readonly int $id,
		public readonly int $report_id,
		public readonly string $purpose,
		public readonly ?int $max_uses,
		public readonly int $use_count,
		public readonly \DateTimeImmutable $expires_at,
		public readonly ?\DateTimeImmutable $revoked_at,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at
	) {}

	public function is_valid(): bool {
		if ( null !== $this->revoked_at ) {
			return false;
		}

		if ( $this->expires_at < new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) ) {
			return false;
		}

		return null === $this->max_uses || $this->use_count < $this->max_uses;
	}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			report_id: (int) $row['report_id'],
			purpose: (string) $row['purpose'],
			max_uses: null !== $row['max_uses'] ? (int) $row['max_uses'] : null,
			use_count: (int) $row['use_count'],
			expires_at: Dates::from_mysql( (string) $row['expires_at'] ),
			revoked_at: ! empty( $row['revoked_at'] ) ? Dates::from_mysql( (string) $row['revoked_at'] ) : null,
			created_by: ! empty( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: Dates::from_mysql( (string) $row['created_at'] )
		);
	}
}
