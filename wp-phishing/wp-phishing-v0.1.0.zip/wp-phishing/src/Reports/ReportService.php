<?php
/**
 * Generates a campaign report, per Section 44: a frozen artefact assembled from
 * {@see \Alltime\WPPhishing\Results\ResultsService}'s live computation at the moment of
 * generation. Regenerating a report never edits an earlier one - the risk weights and evidence
 * of a report already shared/downloaded must never change under the reader (Section 38).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports;

use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\Enums\CampaignStatus;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignWaveRepository;
use Alltime\WPPhishing\Reports\Enums\ReportVisibility;
use Alltime\WPPhishing\Reports\Repositories\ReportRepository;
use Alltime\WPPhishing\Reports\Support\PdfRenderer;
use Alltime\WPPhishing\Reports\Support\ProtectedStorage;
use Alltime\WPPhishing\Results\CampaignResult;
use Alltime\WPPhishing\Results\RecommendationEngine;
use Alltime\WPPhishing\Results\Repositories\RiskWeightSetRepository;
use Alltime\WPPhishing\Results\ResultsService;
use Alltime\WPPhishing\Results\RiskScoringService;
use Alltime\WPPhishing\Results\RiskWeightSet;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Templates\Repositories\TemplateRepository;
use Alltime\WPPhishing\Tracking\Enums\TrackingEventType;

final class ReportService {

	private const COHORT_DIMENSIONS       = array( 'department', 'team', 'location' );
	private const PREVIOUS_CAMPAIGN_LIMIT = 5;

	public function __construct(
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly CampaignRepository $campaigns = new CampaignRepository(),
		private readonly CampaignWaveRepository $waves = new CampaignWaveRepository(),
		private readonly TemplateRepository $templates = new TemplateRepository(),
		private readonly RiskWeightSetRepository $weight_sets = new RiskWeightSetRepository(),
		private readonly ResultsService $results = new ResultsService(),
		private readonly RiskScoringService $scoring = new RiskScoringService(),
		private readonly RecommendationEngine $recommendations = new RecommendationEngine(),
		private readonly PdfRenderer $pdf_renderer = new PdfRenderer(),
		private readonly ProtectedStorage $storage = new ProtectedStorage(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @return Report[]
	 */
	public function list_for_campaign( Campaign $campaign ): array {
		return $this->reports->find_all_for_campaign( $campaign->id );
	}

	public function get( string $organisation_uuid, string $report_uuid ): ?Report {
		return $this->reports->find_by_uuid( $organisation_uuid, $report_uuid );
	}

	/**
	 * Renders (on first request) and caches $report's PDF in protected storage, returning its
	 * raw bytes. Returns null - fail closed, per Section 62 - if protected storage is not
	 * available, rather than ever falling back to an unprotected location.
	 *
	 * A report containing named-recipient data is never cached to disk: a permanently cached PDF
	 * would keep serving that data to any still-valid download token holder forever, even after
	 * named-results access is later revoked - the download route is anonymous (the token itself is
	 * the authorisation, Section 59), so there is no per-download viewer identity to re-check
	 * against a cached file the way the REST JSON view re-checks on every request. Aggregate-only
	 * reports carry no such risk and are cached as before.
	 */
	public function pdf_bytes( Report $report ): ?string {
		if ( ReportVisibility::AggregateOnly !== $report->visibility ) {
			return $this->pdf_renderer->render( $report );
		}

		if ( null !== $report->pdf_relative_path ) {
			$cached = $this->storage->read( $report->pdf_relative_path );

			if ( null !== $cached ) {
				return $cached;
			}
		}

		if ( ! $this->storage->is_available() ) {
			return null;
		}

		$pdf_bytes     = $this->pdf_renderer->render( $report );
		$relative_path = "reports/{$report->report_uuid}.pdf";
		$written_path  = $this->storage->write( $relative_path, $pdf_bytes );

		if ( null === $written_path ) {
			return null;
		}

		$this->reports->set_pdf_relative_path( $report->id, $written_path );

		return $pdf_bytes;
	}

	public function generate( Campaign $campaign, ?RiskWeightSet $weight_set = null, ReportVisibility $visibility = ReportVisibility::AggregateOnly, ?int $generated_by = null ): Report {
		$weight_set ??= $this->weight_sets->find_default();

		if ( null === $weight_set ) {
			throw new \RuntimeException( esc_html__( 'No risk weight set is configured.', 'wp-phishing' ) );
		}

		$results              = $this->results->compute_campaign_results( $campaign, $weight_set );
		$delivery_statistics  = $this->results->delivery_statistics( $results );
		$behavioural_results  = $this->results->behavioural_results( $results );
		$cohort_breakdown     = $this->cohort_breakdown_by_dimension( $results );
		$department_breakdown = $cohort_breakdown['department'] ?? array();

		$content = array(
			'executive_summary'     => $this->executive_summary( $campaign, $delivery_statistics, $behavioural_results ),
			'campaign'              => $this->campaign_scope( $campaign ),
			'scenario'              => $this->scenario_description( $campaign ),
			'recipient_population'  => array( 'targeted' => $delivery_statistics['targeted'] ),
			'delivery_statistics'   => $delivery_statistics,
			'behavioural_results'   => $behavioural_results,
			'cohort_breakdown'      => $cohort_breakdown,
			'risk'                  => array(
				'weight_set_name' => $weight_set->name,
				'weights'         => $weight_set->weights,
				'average_score'   => $this->scoring->average_score( $results ),
			),
			'risk_concentrations'   => $this->risk_concentrations( $cohort_breakdown ),
			'historical_comparison' => $this->historical_comparison( $campaign, $weight_set ),
			'named_results'         => $this->named_results( $results, $visibility ),
			'recommendations'       => $this->recommendations->generate( $behavioural_results, $delivery_statistics, $department_breakdown ),
			'methodology'           => __( 'Results are computed from delivery status and tracking events recorded for each recipient in this campaign. A recipient whose message was never accepted by the mail provider is excluded from behavioural and risk figures (it was never delivered, so it cannot evidence a pass or fail). Risk scores sum the configured weight for each distinct event type observed for a delivery.', 'wp-phishing' ),
			'limitations'           => __( 'Message open observations are not proof a person opened the message (automated systems may retrieve tracking pixels) and carry lower evidential weight than confirmed clicks or landing-page interaction. Automated link-scanner classification is not yet implemented, so all interaction is currently weighted as if human; a future release will distinguish probable automated activity. Longitudinal trend analysis across more than a handful of prior campaigns is not yet implemented.', 'wp-phishing' ),
		);

		$report = $this->reports->create( $campaign->organisation_uuid, $campaign->id, $weight_set->id, $visibility, $content, $generated_by );

		$this->audit_logger->log( 'report.generated', 'report', $report->report_uuid, $generated_by, summary: $campaign->name, organisation_uuid: $campaign->organisation_uuid );

		// Aggregate-only reports are cacheable (pdf_bytes() never caches named-result reports, see
		// its own docblock) - rendering now, off the public download route, means the first click
		// on a freshly-issued link doesn't block that request on Dompdf rendering. A failure here
		// is not fatal to generation: the first download simply renders on demand instead.
		if ( ReportVisibility::AggregateOnly === $visibility && null !== $this->pdf_bytes( $report ) ) {
			$report = $this->reports->find( $report->id ) ?? $report;
		}

		return $report;
	}

	private function executive_summary( Campaign $campaign, array $delivery_statistics, array $behavioural_results ): string {
		$measurable       = $delivery_statistics['measurable'];
		$click_rate       = $measurable > 0 ? round( 100 * $behavioural_results[ TrackingEventType::LinkClicked->value ] / $measurable ) : 0;
		$credential_count = $behavioural_results[ TrackingEventType::CredentialSubmissionAttempted->value ];

		return sprintf(
			/* translators: 1: campaign name, 2: targeted recipient count, 3: measurable delivery count, 4: confirmed click rate percentage, 5: credential submission attempt count */
			__( 'The campaign "%1$s" targeted %2$d recipient(s), of which %3$d message(s) were confirmed accepted for delivery and are measurable. The confirmed click rate among measurable deliveries was %4$d%%, with %5$d simulated credential submission attempt(s) recorded.', 'wp-phishing' ),
			$campaign->name,
			$delivery_statistics['targeted'],
			$measurable,
			$click_rate,
			$credential_count
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private function campaign_scope( Campaign $campaign ): array {
		return array(
			'name'      => $campaign->name,
			'objective' => $campaign->objective,
			'status'    => $campaign->status->value,
			'starts_at' => $campaign->starts_at?->format( DATE_ATOM ),
			'closed_at' => $campaign->closed_at?->format( DATE_ATOM ),
		);
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	private function scenario_description( Campaign $campaign ): array {
		$descriptions = array();

		foreach ( $this->waves->find_all_for_campaign( $campaign->id ) as $wave ) {
			$version  = $this->templates->find_version( $wave->template_version_id );
			$template = null !== $version ? $this->templates->find( $version->template_id ) : null;

			if ( null === $template ) {
				continue;
			}

			$descriptions[] = array(
				'wave_name'  => $wave->name,
				'scenario'   => $template->scenario->value,
				'difficulty' => $template->difficulty->value,
			);
		}

		return $descriptions;
	}

	/**
	 * @param CampaignResult[] $results
	 *
	 * @return array<string,array<int,array{label:string,count:int,click_rate:float,credential_rate:float,average_risk_score:float}>>
	 */
	private function cohort_breakdown_by_dimension( array $results ): array {
		$breakdown = array();

		foreach ( self::COHORT_DIMENSIONS as $dimension ) {
			$breakdown[ $dimension ] = $this->results->cohort_breakdown( $results, $dimension );
		}

		return $breakdown;
	}

	/**
	 * The highest-risk cohort per dimension (Section 39's "identification of concentrated risk"),
	 * not every cohort - a report reader needs the standout figures, not a full re-derivation of
	 * the breakdown tables already included elsewhere in the report.
	 *
	 * @param array<string,array<int,array{label:string,count:int,click_rate:float,credential_rate:float,average_risk_score:float}>> $cohort_breakdown
	 *
	 * @return array<int,array{dimension:string,label:string,average_risk_score:float}>
	 */
	private function risk_concentrations( array $cohort_breakdown ): array {
		$concentrations = array();

		foreach ( $cohort_breakdown as $dimension => $cohorts ) {
			if ( array() === $cohorts ) {
				continue;
			}

			usort( $cohorts, static fn ( array $a, array $b ): int => $b['average_risk_score'] <=> $a['average_risk_score'] );

			if ( $cohorts[0]['average_risk_score'] > 0 ) {
				$concentrations[] = array(
					'dimension'          => $dimension,
					'label'              => $cohorts[0]['label'],
					'average_risk_score' => $cohorts[0]['average_risk_score'],
				);
			}
		}

		return $concentrations;
	}

	/**
	 * A light-weight version of Section 41's longitudinal reporting - full trend analysis
	 * (baseline/rolling trend/repeat-risk population) is Phase 2 (Section 77); this compares
	 * against the organisation's other completed campaigns only.
	 *
	 * @return array<int,array{name:string,click_rate:float,closed_at:?string}>
	 */
	private function historical_comparison( Campaign $campaign, RiskWeightSet $weight_set ): array {
		$comparisons = array();

		foreach ( $this->campaigns->find_all_for_organisation( $campaign->organisation_uuid ) as $other ) {
			if ( $other->id === $campaign->id || CampaignStatus::Completed !== $other->status ) {
				continue;
			}

			// $weight_set only affects each result's risk_score, which this comparison does not
			// read - reused here purely to avoid computing results twice with two different
			// (irrelevant, for this purpose) weight sets.
			$other_results = $this->results->compute_campaign_results( $other, $weight_set );
			$stats         = $this->results->delivery_statistics( $other_results );
			$behavioural   = $this->results->behavioural_results( $other_results );

			$comparisons[] = array(
				'name'       => $other->name,
				'click_rate' => $stats['measurable'] > 0 ? $behavioural[ TrackingEventType::LinkClicked->value ] / $stats['measurable'] : 0.0,
				'closed_at'  => $other->closed_at?->format( DATE_ATOM ),
			);

			if ( count( $comparisons ) >= self::PREVIOUS_CAMPAIGN_LIMIT ) {
				break;
			}
		}

		return $comparisons;
	}

	/**
	 * Every targeted recipient appears under full NamedResults visibility, including one never
	 * successfully delivered - a recipient's absence from the table must never be mistaken for
	 * "wasn't targeted." RestrictedNamedResults stays narrower (only confirmed credential
	 * submissions), which already excludes non-measurable recipients since one can never have that
	 * event.
	 *
	 * @param CampaignResult[] $results
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function named_results( array $results, ReportVisibility $visibility ): array {
		if ( ReportVisibility::AggregateOnly === $visibility ) {
			return array();
		}

		$named = array();

		foreach ( $results as $result ) {
			if ( ReportVisibility::RestrictedNamedResults === $visibility && ! $result->has_event( TrackingEventType::CredentialSubmissionAttempted ) ) {
				continue;
			}

			$named[] = array(
				'email'       => $result->email,
				'given_name'  => $result->given_name,
				'family_name' => $result->family_name,
				'department'  => $result->department,
				'risk_score'  => $result->risk_score,
				'delivered'   => $result->is_measurable(),
				'events'      => array_map( static fn ( TrackingEventType $t ): string => $t->value, $result->event_types ),
			);
		}

		return $named;
	}
}
