<?php
/**
 * Issues and resolves download tokens, per Section 59. Follows the same hash-only-persisted
 * convention as {@see \Alltime\WPPhishing\Auth\TokenService} and {@see \Alltime\WPPhishing\Tracking\TrackingService}.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports;

use Alltime\WPPhishing\Reports\Repositories\DownloadTokenRepository;
use Alltime\WPPhishing\Reports\Repositories\ReportRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class DownloadTokenService {

	private const DEFAULT_TTL_SECONDS = 7 * DAY_IN_SECONDS;

	public function __construct(
		private readonly DownloadTokenRepository $tokens = new DownloadTokenRepository(),
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * Issues a new token for $report, returning the raw value - only its hash is persisted.
	 */
	public function issue( Report $report, string $purpose = 'report_pdf', int $ttl_seconds = self::DEFAULT_TTL_SECONDS, ?int $max_uses = null, ?int $created_by = null ): string {
		$raw_token  = bin2hex( random_bytes( 32 ) );
		$expires_at = ( new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) )->modify( "+{$ttl_seconds} seconds" );

		$this->tokens->create( $this->hash( $raw_token ), $report->id, $purpose, $max_uses, $expires_at, $created_by );

		$this->audit_logger->log( 'report.download_token_issued', 'report', $report->report_uuid, $created_by, organisation_uuid: $report->organisation_uuid );

		return $raw_token;
	}

	/**
	 * Resolves a raw token to its report, without recording a use - callers must call
	 * record_successful_use() themselves, and only once they have actually served the resource
	 * (Section 59). Returns null for anything invalid, expired, revoked, or use-exhausted - the
	 * caller must treat every null the same way regardless of which of those applied, so an
	 * invalid token never reveals why.
	 */
	public function resolve( string $raw_token ): ?Report {
		if ( '' === $raw_token ) {
			return null;
		}

		$token = $this->tokens->find_by_hash( $this->hash( $raw_token ) );

		if ( null === $token || ! $token->is_valid() ) {
			return null;
		}

		return $this->reports->find( $token->report_id );
	}

	/**
	 * Atomically records a use against $raw_token - call only after the resource it authorises has
	 * actually been served, so a transient downstream failure (e.g. protected storage being
	 * unavailable) never burns a single-use token's only use for nothing. Returns false if the
	 * token can no longer accept a use (it may have expired, been revoked, or been exhausted by a
	 * concurrent request since resolve() was called) - the caller must treat that the same as an
	 * invalid token.
	 */
	public function record_successful_use( string $raw_token ): bool {
		return $this->tokens->claim_use( $this->hash( $raw_token ) );
	}

	public function revoke( DownloadToken $token, ?int $revoked_by = null ): void {
		$this->tokens->revoke( $token->id );

		$this->audit_logger->log( 'report.download_token_revoked', 'download_token', (string) $token->id, $revoked_by );
	}

	private function hash( string $raw_token ): string {
		return hash( 'sha256', $raw_token );
	}
}
