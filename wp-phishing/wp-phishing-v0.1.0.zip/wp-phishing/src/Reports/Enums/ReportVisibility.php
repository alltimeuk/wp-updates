<?php
/**
 * Customer-configurable named-result visibility, per Section 40. Chosen when a report is
 * generated and frozen into it - viewing named results within an already-generated report is
 * still separately gated by role at view time (Section 40: "shall require an appropriately
 * privileged organisation role").
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports\Enums;

enum ReportVisibility: string {
	/** No recipient-identifying data in the report; only aggregate/cohort figures. */
	case AggregateOnly = 'aggregate_only';
	/** Every recipient's result is named. */
	case NamedResults = 'named_results';
	/** Only recipients who triggered a high-risk event (credential submission) are named. */
	case RestrictedNamedResults = 'restricted_named_results';
}
