<?php
/**
 * Renders a report to PDF via Dompdf, per Section 63. Reuses {@see HtmlRenderer}'s markup so the
 * HTML and PDF exports never diverge in content - only presentation.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports\Support;

use Alltime\WPPhishing\Reports\Report;
use Dompdf\Dompdf;
use Dompdf\Options;

final class PdfRenderer {

	public function __construct(
		private readonly HtmlRenderer $html_renderer = new HtmlRenderer()
	) {}

	public function render( Report $report ): string {
		$options = new Options();
		$options->setIsRemoteEnabled( false );
		$options->setIsHtml5ParserEnabled( true );

		$dompdf = new Dompdf( $options );
		$dompdf->loadHtml( '<!doctype html><html><head><meta charset="utf-8"></head><body>' . $this->html_renderer->render( $report ) . '</body></html>' );
		$dompdf->setPaper( 'A4' );
		$dompdf->render();

		return $dompdf->output();
	}
}
