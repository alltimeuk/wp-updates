<?php
/**
 * Fail-closed storage for generated report artefacts (PDFs), per Section 62: "Storage protection
 * should fail closed if the application cannot positively establish that sensitive output is
 * protected."
 *
 * A location genuinely outside the public document root isn't reliably available on ordinary
 * WordPress hosting (the actual filesystem layout outside `wp-content/uploads` is unknown to a
 * plugin), so this uses the documented fallback instead: a dedicated directory under the uploads
 * base, protected by both an Apache `.htaccess` deny rule and a blank `index.php` (defence in
 * depth against a misconfigured or Nginx/IIS server that ignores `.htaccess`). Every write/read
 * verifies both protection files are actually present on disk before touching the real content -
 * never assumed from having created them once.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports\Support;

final class ProtectedStorage {

	private const DIRECTORY_NAME = 'wpp-protected';

	public function is_available(): bool {
		return null !== $this->protected_directory();
	}

	/**
	 * Writes $contents to $relative_path within the protected directory, returning the relative
	 * path written on success or null - fail closed - if protection cannot be established or the
	 * write itself fails.
	 */
	public function write( string $relative_path, string $contents ): ?string {
		$full_path = $this->resolve_path( $relative_path );

		if ( null === $full_path ) {
			return null;
		}

		wp_mkdir_p( dirname( $full_path ) );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- writing a plugin-generated PDF into this plugin's own protected uploads subdirectory; no WP_Filesystem context is available in this WP-Cron/REST-triggered service.
		$written = file_put_contents( $full_path, $contents );

		return false !== $written ? $relative_path : null;
	}

	public function read( string $relative_path ): ?string {
		$full_path = $this->resolve_path( $relative_path );

		if ( null === $full_path || ! is_readable( $full_path ) ) {
			return null;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- reading a plugin-generated PDF back out of this plugin's own protected uploads subdirectory; no WP_Filesystem context is available in this WP-Cron/REST-triggered service.
		$contents = file_get_contents( $full_path );

		return false !== $contents ? $contents : null;
	}

	/**
	 * Resolves $relative_path against the protected directory, rejecting anything that could
	 * escape it (no directory traversal) and returning null - fail closed - if the directory's
	 * protection cannot be positively confirmed.
	 */
	private function resolve_path( string $relative_path ): ?string {
		$base = $this->protected_directory();

		if ( null === $base ) {
			return null;
		}

		$normalised = ltrim( str_replace( '\\', '/', $relative_path ), '/' );

		if ( '' === $normalised || str_contains( $normalised, '..' ) ) {
			return null;
		}

		return $base . '/' . $normalised;
	}

	/**
	 * The protected base directory, creating and re-verifying its deny protections on every call
	 * - returns null (fail closed) whenever they cannot be confirmed in place, rather than ever
	 * assuming a previous run's protection still holds.
	 */
	private function protected_directory(): ?string {
		$uploads = wp_upload_dir();

		if ( ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) ) {
			return null;
		}

		$base = rtrim( (string) $uploads['basedir'], '/' ) . '/' . self::DIRECTORY_NAME;

		if ( ! wp_mkdir_p( $base ) || ! $this->deny_protections_in_place( $base ) ) {
			return null;
		}

		return $base;
	}

	private function deny_protections_in_place( string $base ): bool {
		$htaccess_path    = $base . '/.htaccess';
		$index_path       = $base . '/index.php';
		$htaccess_present = file_exists( $htaccess_path );
		$index_present    = file_exists( $index_path );

		if ( ! $htaccess_present ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- writing this plugin's own deny-all protection file into its own protected uploads subdirectory.
			$htaccess_present = false !== file_put_contents( $htaccess_path, "# Silence is golden.\nRequire all denied\nDeny from all\n" );
		}

		if ( ! $index_present ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- see above.
			$index_present = false !== file_put_contents( $index_path, "<?php\n// Silence is golden.\n" );
		}

		return $htaccess_present && $index_present;
	}
}
