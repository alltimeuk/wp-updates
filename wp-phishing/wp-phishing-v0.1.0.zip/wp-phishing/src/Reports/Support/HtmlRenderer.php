<?php
/**
 * Renders a generated report into the HTML export format, per Section 44. Covers all 13 minimum
 * sections. This is also the source markup {@see PdfRenderer} feeds to Dompdf, so the HTML and
 * PDF exports are always identical in content.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports\Support;

use Alltime\WPPhishing\Reports\Report;

final class HtmlRenderer {

	public function render( Report $report ): string {
		return $this->render_content( $report, $report->content );
	}

	/**
	 * Renders $report with an explicitly supplied $content array rather than $report->content
	 * itself - used by the WP-Admin view to render already visibility-stripped content
	 * ({@see \Alltime\WPPhishing\Reports\Support\ReportVisibilityPolicy}) without needing a second,
	 * mutated Report instance just to carry it.
	 *
	 * @param array<string,mixed> $content
	 */
	public function render_content( Report $report, array $content ): string {
		$html  = '<div class="wpp-report">';
		$html .= '<h1>' . esc_html__( 'Campaign Report', 'wp-phishing' ) . '</h1>';
		$html .= '<p><em>' . sprintf( /* translators: %s: generation date/time */ esc_html__( 'Generated %s', 'wp-phishing' ), esc_html( $report->generated_at->format( 'Y-m-d H:i' ) ) ) . '</em></p>';

		$html .= $this->section( __( '1. Executive Summary', 'wp-phishing' ), '<p>' . esc_html( (string) ( $content['executive_summary'] ?? '' ) ) . '</p>' );
		$html .= $this->section( __( '2. Campaign Scope', 'wp-phishing' ), $this->campaign_scope_html( $content['campaign'] ?? array() ) );
		$html .= $this->section( __( '3. Recipient Population', 'wp-phishing' ), '<p>' . sprintf( /* translators: %d: recipient count */ esc_html__( '%d recipient(s) targeted.', 'wp-phishing' ), (int) ( $content['recipient_population']['targeted'] ?? 0 ) ) . '</p>' );
		$html .= $this->section( __( '4. Cohort Breakdown', 'wp-phishing' ), $this->cohort_breakdown_html( $content['cohort_breakdown'] ?? array() ) );
		$html .= $this->section( __( '5. Scenario Description', 'wp-phishing' ), $this->scenario_html( $content['scenario'] ?? array() ) );
		$html .= $this->section( __( '6. Delivery Statistics', 'wp-phishing' ), $this->delivery_statistics_html( $content['delivery_statistics'] ?? array() ) );
		$html .= $this->section( __( '7. Behavioural Results', 'wp-phishing' ), $this->behavioural_results_html( $content['behavioural_results'] ?? array() ) );
		$html .= $this->section( __( '8. Risk Concentrations', 'wp-phishing' ), $this->risk_concentrations_html( $content['risk_concentrations'] ?? array() ) );
		$html .= $this->section( __( '9. Historical Comparison', 'wp-phishing' ), $this->historical_comparison_html( $content['historical_comparison'] ?? array() ) );
		$html .= $this->section( __( '10. Named Results', 'wp-phishing' ), $this->named_results_html( $content['named_results'] ?? array() ) );
		$html .= $this->section( __( '11. Recommendations', 'wp-phishing' ), $this->list_html( $content['recommendations'] ?? array() ) );
		$html .= $this->section( __( '12. Methodology', 'wp-phishing' ), '<p>' . esc_html( (string) ( $content['methodology'] ?? '' ) ) . '</p>' );
		$html .= $this->section( __( '13. Limitations', 'wp-phishing' ), '<p>' . esc_html( (string) ( $content['limitations'] ?? '' ) ) . '</p>' );

		return $html . '</div>';
	}

	private function section( string $title, string $body ): string {
		return '<h2>' . esc_html( $title ) . '</h2>' . $body;
	}

	/**
	 * @param array<string,mixed> $scope
	 */
	private function campaign_scope_html( array $scope ): string {
		return '<p>' . esc_html( (string) ( $scope['name'] ?? '' ) ) . ' - ' . esc_html( (string) ( $scope['status'] ?? '' ) ) . '<br>'
			. esc_html( (string) ( $scope['objective'] ?? '' ) ) . '</p>';
	}

	/**
	 * @param array<string,array<int,array{label:string,count:int,click_rate:float,credential_rate:float,average_risk_score:float}>> $breakdown
	 */
	private function cohort_breakdown_html( array $breakdown ): string {
		if ( array() === $breakdown ) {
			return '<p>' . esc_html__( 'No cohort data available.', 'wp-phishing' ) . '</p>';
		}

		$html = '';

		foreach ( $breakdown as $dimension => $cohorts ) {
			if ( array() === $cohorts ) {
				continue;
			}

			$html .= '<h3>' . esc_html( ucfirst( (string) $dimension ) ) . '</h3><table border="1" cellpadding="4"><thead><tr><th>' . esc_html__( 'Cohort', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Recipients', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Click rate', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Credential rate', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Average risk score', 'wp-phishing' ) . '</th></tr></thead><tbody>';

			foreach ( $cohorts as $cohort ) {
				$html .= '<tr><td>' . esc_html( $cohort['label'] ) . '</td><td>' . (int) $cohort['count'] . '</td><td>' . esc_html( $this->percentage( $cohort['click_rate'] ) ) . '</td><td>' . esc_html( $this->percentage( $cohort['credential_rate'] ) ) . '</td><td>' . esc_html( number_format( $cohort['average_risk_score'], 1 ) ) . '</td></tr>';
			}

			$html .= '</tbody></table>';
		}

		return $html;
	}

	/**
	 * @param array<int,array<string,mixed>> $scenarios
	 */
	private function scenario_html( array $scenarios ): string {
		if ( array() === $scenarios ) {
			return '<p>' . esc_html__( 'No scenario data available.', 'wp-phishing' ) . '</p>';
		}

		$html = '<ul>';

		foreach ( $scenarios as $scenario ) {
			$html .= '<li>' . esc_html( (string) ( $scenario['wave_name'] ?? '' ) ) . ': ' . esc_html( (string) ( $scenario['scenario'] ?? '' ) ) . ' (' . esc_html( (string) ( $scenario['difficulty'] ?? '' ) ) . ')</li>';
		}

		return $html . '</ul>';
	}

	/**
	 * @param array{targeted?:int,attempted?:int,accepted?:int,delivered?:int,measurable?:int} $stats
	 */
	private function delivery_statistics_html( array $stats ): string {
		$html = '<ul>';

		foreach ( array( 'targeted', 'attempted', 'accepted', 'delivered', 'measurable' ) as $key ) {
			$html .= '<li>' . esc_html( ucfirst( $key ) ) . ': ' . (int) ( $stats[ $key ] ?? 0 ) . '</li>';
		}

		return $html . '</ul>';
	}

	/**
	 * @param array<string,int> $results
	 */
	private function behavioural_results_html( array $results ): string {
		if ( array() === $results ) {
			return '<p>' . esc_html__( 'No behavioural data available.', 'wp-phishing' ) . '</p>';
		}

		$html = '<ul>';

		foreach ( $results as $event_type => $count ) {
			$html .= '<li>' . esc_html( str_replace( '_', ' ', (string) $event_type ) ) . ': ' . (int) $count . '</li>';
		}

		return $html . '</ul>';
	}

	/**
	 * @param array<int,array{dimension:string,label:string,average_risk_score:float}> $concentrations
	 */
	private function risk_concentrations_html( array $concentrations ): string {
		if ( array() === $concentrations ) {
			return '<p>' . esc_html__( 'No concentrated risk identified.', 'wp-phishing' ) . '</p>';
		}

		$html = '<ul>';

		foreach ( $concentrations as $concentration ) {
			$html .= '<li>' . sprintf(
				/* translators: 1: cohort label, 2: dimension name, 3: average risk score */
				esc_html__( '%1$s (by %2$s) - average risk score %3$s', 'wp-phishing' ),
				esc_html( $concentration['label'] ),
				esc_html( $concentration['dimension'] ),
				esc_html( number_format( $concentration['average_risk_score'], 1 ) )
			) . '</li>';
		}

		return $html . '</ul>';
	}

	/**
	 * @param array<int,array{name:string,click_rate:float,closed_at:?string}> $comparisons
	 */
	private function historical_comparison_html( array $comparisons ): string {
		if ( array() === $comparisons ) {
			return '<p>' . esc_html__( 'No prior completed campaigns are available for this organisation yet.', 'wp-phishing' ) . '</p>';
		}

		$html = '<table border="1" cellpadding="4"><thead><tr><th>' . esc_html__( 'Campaign', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Click rate', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Completed', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $comparisons as $comparison ) {
			$html .= '<tr><td>' . esc_html( $comparison['name'] ) . '</td><td>' . esc_html( $this->percentage( $comparison['click_rate'] ) ) . '</td><td>' . esc_html( (string) ( $comparison['closed_at'] ?? '' ) ) . '</td></tr>';
		}

		return $html . '</tbody></table>';
	}

	/**
	 * @param array<int,array<string,mixed>> $named_results
	 */
	private function named_results_html( array $named_results ): string {
		if ( array() === $named_results ) {
			return '<p>' . esc_html__( 'Named results are not included in this report.', 'wp-phishing' ) . '</p>';
		}

		$html = '<table border="1" cellpadding="4"><thead><tr><th>' . esc_html__( 'Recipient', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Department', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Risk score', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Events', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $named_results as $result ) {
			$name      = trim( ( $result['given_name'] ?? '' ) . ' ' . ( $result['family_name'] ?? '' ) );
			$delivered = $result['delivered'] ?? true;

			$html .= '<tr><td>' . esc_html( '' !== $name ? $name : (string) $result['email'] ) . '</td><td>' . esc_html( (string) ( $result['department'] ?? '' ) ) . '</td><td>'
				. esc_html( $delivered ? __( 'Delivered', 'wp-phishing' ) : __( 'Not delivered', 'wp-phishing' ) ) . '</td><td>' . (int) $result['risk_score'] . '</td><td>'
				. esc_html( $delivered ? implode( ', ', array_map( 'strval', $result['events'] ?? array() ) ) : '-' ) . '</td></tr>';
		}

		return $html . '</tbody></table>';
	}

	/**
	 * @param string[] $items
	 */
	private function list_html( array $items ): string {
		if ( array() === $items ) {
			return '<p>' . esc_html__( 'No specific recommendations from this campaign\'s evidence.', 'wp-phishing' ) . '</p>';
		}

		$html = '<ul>';

		foreach ( $items as $item ) {
			$html .= '<li>' . esc_html( $item ) . '</li>';
		}

		return $html . '</ul>';
	}

	private function percentage( float $rate ): string {
		return number_format( $rate * 100, 1 ) . '%';
	}
}
