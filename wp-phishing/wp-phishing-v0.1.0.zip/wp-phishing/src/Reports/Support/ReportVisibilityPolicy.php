<?php
/**
 * Single source of truth for named-results visibility (Section 40): whether the current actor
 * may see named-recipient data for a given organisation, right now. Generation, the REST JSON
 * view, the WP-Admin HTML view, and download-token issuance all call this instead of each
 * hand-copying the same feature-flag/capability/tenant-role check - a prior audit found those
 * copies had already diverged (one omitted the tenant-role check entirely).
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports\Support;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\Reports\Enums\ReportVisibility;
use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\FeatureFlags;
use Alltime\WPPhishing\Support\TenantGuard;

final class ReportVisibilityPolicy {

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard()
	) {}

	/**
	 * Whether the current actor may currently see named-recipient data for $organisation_uuid -
	 * the feature flag, the capability, and the tenant role must all agree.
	 */
	public function may_view_named_results( string $organisation_uuid ): bool {
		return FeatureFlags::is_enabled( FeatureFlags::NAMED_REPORTING )
			&& current_user_can( Capabilities::VIEW_NAMED_RESULTS )
			&& $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator, MembershipRole::Analyst );
	}

	/**
	 * Downgrades $requested to aggregate-only whenever the current actor isn't currently permitted
	 * to see named results - never errors, since "aggregate is always safe" beats refusing to
	 * generate a report at all.
	 */
	public function permitted_for_generation( ReportVisibility $requested, string $organisation_uuid ): ReportVisibility {
		if ( ReportVisibility::AggregateOnly === $requested ) {
			return ReportVisibility::AggregateOnly;
		}

		return $this->may_view_named_results( $organisation_uuid ) ? $requested : ReportVisibility::AggregateOnly;
	}

	/**
	 * Strips named-recipient data from an already-generated report's content when the current
	 * actor isn't currently permitted to see it - re-enforced every time content is viewed, not
	 * just at generation, so a later role change or disabled feature flag hides named results from
	 * a report that already has them. Always sets the key to an empty array rather than unsetting
	 * it, matching generation's own representation of "no named data" (Section 40).
	 *
	 * @param array<string,mixed> $content
	 *
	 * @return array<string,mixed>
	 */
	public function strip_named_results_if_unauthorised( array $content, ReportVisibility $report_visibility, string $organisation_uuid ): array {
		if ( ReportVisibility::AggregateOnly !== $report_visibility && ! $this->may_view_named_results( $organisation_uuid ) ) {
			$content['named_results'] = array();
		}

		return $content;
	}
}
