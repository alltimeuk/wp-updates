<?php
/**
 * Persistence for download tokens, against `wpp_download_tokens`, per Section 59.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Reports\DownloadToken;

final class DownloadTokenRepository {

	public function find( int $id ): ?DownloadToken {
		global $wpdb;

		$table = Schema::table( 'download_tokens' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? DownloadToken::from_row( $row ) : null;
	}

	public function find_by_hash( string $token_hash ): ?DownloadToken {
		global $wpdb;

		$table = Schema::table( 'download_tokens' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE token_hash = %s", $token_hash ), ARRAY_A );

		return null !== $row ? DownloadToken::from_row( $row ) : null;
	}

	public function create( string $token_hash, int $report_id, string $purpose, ?int $max_uses, \DateTimeImmutable $expires_at, ?int $created_by ): DownloadToken {
		global $wpdb;

		$table = Schema::table( 'download_tokens' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'token_hash' => $token_hash,
				'report_id'  => $report_id,
				'purpose'    => $purpose,
				'max_uses'   => $max_uses,
				'use_count'  => 0,
				'expires_at' => $expires_at->format( 'Y-m-d H:i:s' ),
				'created_by' => $created_by,
				'created_at' => current_time( 'mysql', true ),
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Atomically claims one use against the token identified by $token_hash in a single
	 * conditional UPDATE, mirroring {@see \Alltime\WPPhishing\Auth\TokenService::consume()} - the
	 * validity check and the increment happen in one statement, so two concurrent requests near a
	 * token's max_uses boundary can never both pass. Returns false if the token cannot accept a use
	 * right now (revoked, expired, or already exhausted) - the caller must treat that the same as
	 * an invalid token.
	 */
	public function claim_use( string $token_hash ): bool {
		global $wpdb;

		$table = Schema::table( 'download_tokens' );
		$now   = current_time( 'mysql', true );

		$query = "UPDATE `{$table}` SET use_count = use_count + 1
			WHERE token_hash = %s AND revoked_at IS NULL AND expires_at >= %s AND (max_uses IS NULL OR use_count < max_uses)";

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $query is this method's own fixed, parameterless query text (table name only, no user input); phpcs cannot see that statically.
		$claimed = $wpdb->query( $wpdb->prepare( $query, $token_hash, $now ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- see leading comment above; a trailing ignore is required for NotPrepared specifically.

		return (bool) $claimed;
	}

	public function revoke( int $id ): void {
		global $wpdb;

		$table = Schema::table( 'download_tokens' );

		$wpdb->update( $table, array( 'revoked_at' => current_time( 'mysql', true ) ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	private function find_or_fail( int $id ): DownloadToken {
		$token = $this->find( $id );

		if ( null === $token ) {
			throw new \RuntimeException( esc_html( "Download token {$id} was expected to exist but could not be loaded." ) );
		}

		return $token;
	}
}
