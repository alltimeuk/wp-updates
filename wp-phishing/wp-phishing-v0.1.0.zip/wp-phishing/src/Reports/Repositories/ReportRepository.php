<?php
/**
 * Persistence for generated reports, against `wpp_reports`, per Section 44.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports\Repositories;

use Alltime\WPPhishing\Data\Schema;
use Alltime\WPPhishing\Reports\Enums\ReportVisibility;
use Alltime\WPPhishing\Reports\Report;

final class ReportRepository {

	public function find( int $id ): ?Report {
		global $wpdb;

		$table = Schema::table( 'reports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Report::from_row( $row ) : null;
	}

	public function find_by_uuid( string $organisation_uuid, string $report_uuid ): ?Report {
		global $wpdb;

		$table = Schema::table( 'reports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE report_uuid = %s AND organisation_uuid = %s", $report_uuid, $organisation_uuid ), ARRAY_A );

		return null !== $row ? Report::from_row( $row ) : null;
	}

	/**
	 * @return Report[]
	 */
	public function find_all_for_campaign( int $campaign_id ): array {
		global $wpdb;

		$table = Schema::table( 'reports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE campaign_id = %d ORDER BY id DESC", $campaign_id ), ARRAY_A );

		return array_map( array( Report::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @param array<string,mixed> $content
	 */
	public function create(
		string $organisation_uuid,
		int $campaign_id,
		int $risk_weight_set_id,
		ReportVisibility $visibility,
		array $content,
		?int $generated_by
	): Report {
		global $wpdb;

		$table        = Schema::table( 'reports' );
		$content_json = wp_json_encode( $content );

		if ( false === $content_json ) {
			throw new \RuntimeException( esc_html__( 'Report content could not be encoded.', 'wp-phishing' ) );
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'report_uuid'        => wp_generate_uuid4(),
				'organisation_uuid'  => $organisation_uuid,
				'campaign_id'        => $campaign_id,
				'risk_weight_set_id' => $risk_weight_set_id,
				'visibility'         => $visibility->value,
				'content_json'       => $content_json,
				'generated_by'       => $generated_by,
				'generated_at'       => current_time( 'mysql', true ),
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function set_pdf_relative_path( int $id, string $relative_path ): Report {
		global $wpdb;

		$table = Schema::table( 'reports' );

		$wpdb->update( $table, array( 'pdf_relative_path' => $relative_path ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): Report {
		$report = $this->find( $id );

		if ( null === $report ) {
			throw new \RuntimeException( esc_html( "Report {$id} was expected to exist but could not be loaded." ) );
		}

		return $report;
	}
}
