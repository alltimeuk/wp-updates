<?php
/**
 * A generated campaign report, per Section 44: a frozen, point-in-time artefact - regenerating a
 * report creates a new row rather than overwriting one, so an earlier report stays exactly what
 * was shared/downloaded at the time.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports;

use Alltime\WPPhishing\Reports\Enums\ReportVisibility;
use Alltime\WPPhishing\Support\Dates;

final class Report {

	public function __construct(
		public readonly int $id,
		public readonly string $report_uuid,
		public readonly string $organisation_uuid,
		public readonly int $campaign_id,
		public readonly int $risk_weight_set_id,
		public readonly ReportVisibility $visibility,
		/** @var array<string,mixed> */
		public readonly array $content,
		public readonly ?string $pdf_relative_path,
		public readonly ?int $generated_by,
		public readonly \DateTimeImmutable $generated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		$content = json_decode( (string) $row['content_json'], true );

		return new self(
			id: (int) $row['id'],
			report_uuid: (string) $row['report_uuid'],
			organisation_uuid: (string) $row['organisation_uuid'],
			campaign_id: (int) $row['campaign_id'],
			risk_weight_set_id: (int) $row['risk_weight_set_id'],
			visibility: ReportVisibility::from( (string) $row['visibility'] ),
			content: is_array( $content ) ? $content : array(),
			pdf_relative_path: ! empty( $row['pdf_relative_path'] ) ? (string) $row['pdf_relative_path'] : null,
			generated_by: ! empty( $row['generated_by'] ) ? (int) $row['generated_by'] : null,
			generated_at: Dates::from_mysql( (string) $row['generated_at'] )
		);
	}
}
