<?php
/**
 * Public report-download route bootstrap, per Section 59: `/reports/download/{token}`. Mirrors
 * {@see \Alltime\WPPhishing\Tracking\TrackingBootstrap}'s rewrite-rule + query-var +
 * template_redirect dispatch shape - the token itself is the authorisation (Section 59: "a token
 * shall reference the authorised resource server-side"), so this route is deliberately
 * unauthenticated, the same way a signed download link from any other product would be.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Reports;

final class ReportsBootstrap {

	private const QUERY_VAR     = 'wpp_report_download_token';
	private const TOKEN_PATTERN = '[0-9a-f]{64}';

	public function __construct(
		private readonly DownloadTokenService $download_tokens = new DownloadTokenService(),
		private readonly ReportService $reports = new ReportService()
	) {}

	public function boot(): void {
		add_action( 'init', array( $this, 'register_rewrite_rules' ) );
		add_filter( 'query_vars', array( $this, 'register_query_var' ) );
		add_action( 'template_redirect', array( $this, 'dispatch' ) );
	}

	public function register_rewrite_rules(): void {
		add_rewrite_rule( '^reports/download/(' . self::TOKEN_PATTERN . ')/?$', 'index.php?' . self::QUERY_VAR . '=$matches[1]', 'top' );
	}

	/**
	 * @param string[] $vars
	 *
	 * @return string[]
	 */
	public function register_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	public function dispatch(): void {
		$token = get_query_var( self::QUERY_VAR );

		if ( ! is_string( $token ) || '' === $token || 1 !== preg_match( '/^' . self::TOKEN_PATTERN . '$/', $token ) ) {
			return;
		}

		$report = $this->download_tokens->resolve( $token );

		if ( null === $report ) {
			status_header( 404 );
			nocache_headers();
			echo esc_html__( 'This download link is invalid, expired or has been revoked.', 'wp-phishing' );
			exit;
		}

		$pdf_bytes = $this->reports->pdf_bytes( $report );

		if ( null === $pdf_bytes ) {
			status_header( 503 );
			nocache_headers();
			echo esc_html__( 'This report is temporarily unavailable. Please try again shortly.', 'wp-phishing' );
			exit;
		}

		// The use is recorded only now that the PDF has actually been produced - a token must
		// never be burned by a transient rendering/storage failure that leaves the client with
		// nothing (Section 59).
		if ( ! $this->download_tokens->record_successful_use( $token ) ) {
			status_header( 404 );
			nocache_headers();
			echo esc_html__( 'This download link is invalid, expired or has been revoked.', 'wp-phishing' );
			exit;
		}

		status_header( 200 );
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="report-' . $report->report_uuid . '.pdf"' );
		header( 'Content-Length: ' . strlen( $pdf_bytes ) );
		echo $pdf_bytes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- raw PDF binary bytes, not HTML/text output.
		exit;
	}
}
