<?php
/**
 * REST resource controller for landing pages, per Section 31/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\WPPhishing\Landing\Enums\LandingPageMode;
use Alltime\WPPhishing\Landing\Enums\LandingPageStatus;
use Alltime\WPPhishing\Landing\LandingPage;
use Alltime\WPPhishing\Landing\LandingPageService;
use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\TenantGuard;

final class LandingPagesController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly LandingPageService $landing_pages = new LandingPageService()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/landing-pages',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/landing-pages/(?P<landing_page_uuid>' . self::UUID_PATTERN . ')/status',
			array(
				'methods'             => \WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'update_status' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);
	}

	public function can_read( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function can_manage( \WP_REST_Request $request ): bool {
		return current_user_can( Capabilities::MANAGE_TEMPLATES ) && $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );

		return new \WP_REST_Response( array( 'items' => array_map( array( $this, 'to_array' ), $this->landing_pages->list_available_for_organisation( $organisation_uuid ) ) ) );
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$mode = LandingPageMode::tryFrom( (string) $request->get_param( 'mode' ) );

		if ( null === $mode ) {
			return new \WP_Error( 'wpp_invalid_mode', __( 'A valid landing page mode is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$organisation_only = (bool) $request->get_param( 'organisation_only' );

		$landing_page = $this->landing_pages->create(
			$organisation_only ? (string) $request->get_param( 'organisation_uuid' ) : null,
			(string) $request->get_param( 'name' ),
			$mode,
			(string) $request->get_param( 'html_body' ),
			$request->get_param( 'educational_html' ),
			get_current_user_id()
		);

		return new \WP_REST_Response( $this->to_array( $landing_page ), 201 );
	}

	public function update_status( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$landing_page = $this->landing_pages->get( (string) $request->get_param( 'landing_page_uuid' ) );
		$status       = LandingPageStatus::tryFrom( (string) $request->get_param( 'status' ) );

		if ( null === $landing_page ) {
			return new \WP_Error( 'wpp_not_found', __( 'Landing page not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		if ( null === $status ) {
			return new \WP_Error( 'wpp_invalid_status', __( 'A valid status is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$updated = $this->landing_pages->update_status( $landing_page, $status, get_current_user_id() );

		return new \WP_REST_Response( $this->to_array( $updated ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function to_array( LandingPage $landing_page ): array {
		return array(
			'uuid'               => $landing_page->landing_page_uuid,
			'organisation_uuid'  => $landing_page->organisation_uuid,
			'name'               => $landing_page->name,
			'mode'               => $landing_page->mode->value,
			'status'             => $landing_page->status->value,
			'current_version_id' => $landing_page->current_version_id,
		);
	}
}
