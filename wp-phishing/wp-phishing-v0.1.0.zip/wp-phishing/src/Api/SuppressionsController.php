<?php
/**
 * REST resource controller for suppressions, per Section 55/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\Suppression;
use Alltime\WPPhishing\Recipients\SuppressionService;
use Alltime\WPPhishing\Support\TenantGuard;

final class SuppressionsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly SuppressionService $service = new SuppressionService()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/suppressions',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'page'              => array(
							'type'    => 'integer',
							'default' => 1,
							'minimum' => 1,
						),
						'per_page'          => array(
							'type'    => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 100,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'email'             => array(
							'type'     => 'string',
							'required' => true,
						),
						'reason'            => array(
							'type'     => 'string',
							'required' => true,
							'enum'     => array_map( static fn ( SuppressionReason $r ): string => $r->value, SuppressionReason::cases() ),
						),
						'note'              => array( 'type' => 'string' ),
						'expires_at'        => array( 'type' => 'string' ),
					),
				),
			)
		);
	}

	public function can_read( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function can_manage( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator
		);
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );

		$items = $this->service->list_for_organisation( (string) $request->get_param( 'organisation_uuid' ), $per_page, $page );

		return new \WP_REST_Response( array( 'items' => array_map( array( self::class, 'to_array' ), $items ) ) );
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$email = (string) $request->get_param( 'email' );

		if ( '' === trim( $email ) || ! is_email( $email ) ) {
			return new \WP_Error( 'wpp_invalid_email', __( 'A valid email address is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$expires_param = $request->get_param( 'expires_at' );
		$expires_at    = null;

		if ( is_string( $expires_param ) && '' !== $expires_param ) {
			try {
				$expires_at = new \DateTimeImmutable( $expires_param );
			} catch ( \Exception $exception ) {
				return new \WP_Error( 'wpp_invalid_expiry', __( 'expires_at could not be parsed as a date.', 'wp-phishing' ), array( 'status' => 400 ) );
			}
		}

		$suppression = $this->service->suppress(
			(string) $request->get_param( 'organisation_uuid' ),
			$email,
			SuppressionReason::from( (string) $request->get_param( 'reason' ) ),
			'admin',
			$request->get_param( 'note' ) ? (string) $request->get_param( 'note' ) : null,
			get_current_user_id(),
			$expires_at
		);

		return new \WP_REST_Response( self::to_array( $suppression ), 201 );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Suppression $suppression ): array {
		return array(
			'uuid'       => $suppression->suppression_uuid,
			'reason'     => $suppression->reason->value,
			'source'     => $suppression->source,
			'note'       => $suppression->note,
			'is_active'  => $suppression->is_active(),
			'created_at' => $suppression->created_at->format( DATE_ATOM ),
			'expires_at' => $suppression->expires_at?->format( DATE_ATOM ),
		);
	}
}
