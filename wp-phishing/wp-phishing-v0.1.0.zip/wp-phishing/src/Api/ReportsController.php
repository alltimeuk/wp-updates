<?php
/**
 * REST resource controller for campaign reports, per Section 44/59/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\CampaignService;
use Alltime\WPPhishing\Reports\DownloadTokenService;
use Alltime\WPPhishing\Reports\Enums\ReportVisibility;
use Alltime\WPPhishing\Reports\Report;
use Alltime\WPPhishing\Reports\ReportService;
use Alltime\WPPhishing\Reports\Support\ReportVisibilityPolicy;
use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\TenantGuard;

final class ReportsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly CampaignService $campaigns = new CampaignService(),
		private readonly ReportService $reports = new ReportService(),
		private readonly DownloadTokenService $download_tokens = new DownloadTokenService(),
		private readonly ReportVisibilityPolicy $visibility_policy = new ReportVisibilityPolicy()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/reports',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_view' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'generate' ),
					'permission_callback' => array( $this, 'can_generate' ),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/reports/(?P<report_uuid>' . self::UUID_PATTERN . ')',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => array( $this, 'can_view' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/reports/(?P<report_uuid>' . self::UUID_PATTERN . ')/download-token',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'issue_download_token' ),
				'permission_callback' => array( $this, 'can_view' ),
			)
		);
	}

	/**
	 * Alltime operators (VIEW_REPORTS) or an Owner/Administrator/Analyst of the organisation itself
	 * may view its reports - a Viewer-role member cannot. Capability OR tenant-scoped role, not
	 * capability AND tenant scope: every customer account is a `wpp_customer`, never holds
	 * VIEW_REPORTS at all, so an AND here would make this endpoint unreachable by any customer
	 * regardless of their organisation role.
	 */
	public function can_view( \WP_REST_Request $request ): bool {
		return current_user_can( Capabilities::VIEW_REPORTS ) || $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator,
			MembershipRole::Analyst
		);
	}

	/**
	 * Report generation requires the same bar as viewing (Section 40) - named-results visibility
	 * itself is separately, additionally gated by {@see ReportVisibilityPolicy}.
	 */
	public function can_generate( \WP_REST_Request $request ): bool {
		return $this->can_view( $request );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response( array( 'items' => array_map( array( $this, 'to_array' ), $this->reports->list_for_campaign( $campaign ) ) ) );
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$report = $this->find_report( $request );

		if ( null === $report ) {
			return new \WP_Error( 'wpp_not_found', __( 'Report not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$data            = $this->to_array( $report );
		$data['content'] = $this->visible_content( $report, $request );

		return new \WP_REST_Response( $data );
	}

	public function generate( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$requested_visibility = ReportVisibility::tryFrom( (string) $request->get_param( 'visibility' ) ) ?? ReportVisibility::AggregateOnly;
		$visibility           = $this->visibility_policy->permitted_for_generation( $requested_visibility, (string) $request->get_param( 'organisation_uuid' ) );

		try {
			$report = $this->reports->generate( $campaign, null, $visibility, get_current_user_id() );
		} catch ( \RuntimeException $exception ) {
			return new \WP_Error( 'wpp_report_generation_failed', $exception->getMessage(), array( 'status' => 409 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- ReportService's messages are fixed, translated strings, never user input.
		}

		return new \WP_REST_Response( $this->to_array( $report ), 201 );
	}

	public function issue_download_token( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$report = $this->find_report( $request );

		if ( null === $report ) {
			return new \WP_Error( 'wpp_not_found', __( 'Report not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		// A token capable of retrieving named-recipient data may only be minted by someone
		// currently permitted to see it - the token itself becomes the sole authorisation for
		// whoever redeems it (Section 59), an anonymous bearer with no role to re-check.
		if ( ReportVisibility::AggregateOnly !== $report->visibility && ! $this->visibility_policy->may_view_named_results( $report->organisation_uuid ) ) {
			return new \WP_Error( 'wpp_forbidden', __( 'You do not have permission to issue a download link for this report.', 'wp-phishing' ), array( 'status' => 403 ) );
		}

		$raw_token = $this->download_tokens->issue( $report, created_by: get_current_user_id() );

		return new \WP_REST_Response( array( 'download_url' => home_url( "/reports/download/{$raw_token}/" ) ), 201 );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function visible_content( Report $report, \WP_REST_Request $request ): array {
		return $this->visibility_policy->strip_named_results_if_unauthorised( $report->content, $report->visibility, (string) $request->get_param( 'organisation_uuid' ) );
	}

	private function find_campaign( \WP_REST_Request $request ): ?Campaign {
		return $this->campaigns->get( (string) $request->get_param( 'organisation_uuid' ), (string) $request->get_param( 'campaign_uuid' ) );
	}

	/**
	 * Verifies the report actually belongs to the campaign named in the URL path, not merely the
	 * same organisation - without this, a request naming the wrong campaign_uuid (same org,
	 * different campaign) would still return a report that exists for that org.
	 */
	private function find_report( \WP_REST_Request $request ): ?Report {
		$report = $this->reports->get( (string) $request->get_param( 'organisation_uuid' ), (string) $request->get_param( 'report_uuid' ) );

		if ( null === $report ) {
			return null;
		}

		$campaign = $this->find_campaign( $request );

		return null !== $campaign && $campaign->id === $report->campaign_id ? $report : null;
	}

	/**
	 * @return array<string,mixed>
	 */
	private function to_array( Report $report ): array {
		return array(
			'uuid'         => $report->report_uuid,
			'visibility'   => $report->visibility->value,
			'has_pdf'      => null !== $report->pdf_relative_path,
			'generated_at' => $report->generated_at->format( DATE_ATOM ),
		);
	}
}
