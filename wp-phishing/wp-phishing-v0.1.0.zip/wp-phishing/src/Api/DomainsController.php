<?php
/**
 * REST resource controller for organisation domains and their DNS TXT verification, per
 * Section 10/11/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\OrganisationDomain;
use Alltime\CustomerPlatform\OrganisationPlatformDiscovery;
use Alltime\CustomerPlatform\OrganisationServiceInterface;
use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\TenantGuard;
use Alltime\WPPhishing\Verification\DomainVerificationService;
use Alltime\WPPhishing\Verification\SchemaNotReadyException;

final class DomainsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly DomainVerificationService $verification = new DomainVerificationService()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/domains',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
					'args'                => array(
						'organisation_uuid'   => array(
							'type'     => 'string',
							'required' => true,
						),
						'domain'              => array(
							'type'     => 'string',
							'required' => true,
						),
						'verification_method' => array(
							'type'    => 'string',
							'default' => DomainVerificationMethod::DnsTxt->value,
							'enum'    => array_map( static fn ( DomainVerificationMethod $m ): string => $m->value, DomainVerificationMethod::cases() ),
						),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/domains/(?P<domain_uuid>' . self::UUID_PATTERN . ')/verification',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'start_verification' ),
					'permission_callback' => array( $this, 'can_manage' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'domain_uuid'       => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'check_verification' ),
					'permission_callback' => array( $this, 'can_manage' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'domain_uuid'       => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/domains/(?P<domain_uuid>' . self::UUID_PATTERN . ')/verification/override',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'override_verification' ),
				// Section 11: administrative override is an Alltime-staff action, backed by
				// documented authority - never available to a customer role, regardless of theirs
				// organisation role.
				'permission_callback' => static fn (): bool => current_user_can( Capabilities::MANAGE_SENDER_DOMAINS ),
				'args'                => array(
					'organisation_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
					'domain_uuid'       => array(
						'type'     => 'string',
						'required' => true,
					),
					'reason'            => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	public function can_read( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	/**
	 * Domain management requires an organisation-level Owner/Administrator role (or Alltime
	 * operator status) - a Viewer or Analyst membership grants read access only (Section 9:
	 * "Product capabilities may further restrict access").
	 */
	public function can_manage( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator
		);
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );

		return new \WP_REST_Response(
			array(
				'items' => array_map( array( self::class, 'to_array' ), $this->organisation_service()->get_domains( $organisation_uuid ) ),
			)
		);
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );
		$domain            = strtolower( trim( (string) $request->get_param( 'domain' ) ) );
		$method            = DomainVerificationMethod::from( (string) $request->get_param( 'verification_method' ) );

		if ( '' === $domain || ! preg_match( '/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/', $domain ) ) {
			return new \WP_Error( 'wpp_invalid_domain', __( 'A valid domain name is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		if ( null !== $this->organisation_service()->find_domain_by_ascii( $domain ) ) {
			return new \WP_Error( 'wpp_domain_already_registered', __( 'This domain is already registered to an organisation.', 'wp-phishing' ), array( 'status' => 409 ) );
		}

		$organisation_domain = $this->organisation_service()->add_domain( $organisation_uuid, $domain, $method );

		return new \WP_REST_Response( self::to_array( $organisation_domain ), 201 );
	}

	public function start_verification( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$domain_uuid = (string) $request->get_param( 'domain_uuid' );

		try {
			$hash = $this->verification->generate_challenge( $domain_uuid, get_current_user_id(), 'customer_portal' );
		} catch ( SchemaNotReadyException $exception ) {
			return new \WP_Error( 'wpp_schema_not_ready', $exception->getMessage(), array( 'status' => 503 ) );
		} catch ( \InvalidArgumentException $exception ) {
			return new \WP_Error( 'wpp_not_found', $exception->getMessage(), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response(
			array(
				'challenge_hash'   => $hash,
				'txt_record_value' => $this->verification->txt_record_value( $hash ),
			),
			201
		);
	}

	public function check_verification( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$domain_uuid = (string) $request->get_param( 'domain_uuid' );
		$domain      = $this->organisation_service()->get_domain( $domain_uuid );

		if ( null === $domain || $domain->organisation_uuid !== (string) $request->get_param( 'organisation_uuid' ) ) {
			return new \WP_Error( 'wpp_not_found', __( 'Domain not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		try {
			$verified = $this->verification->check( $domain, 'customer_portal' );
		} catch ( SchemaNotReadyException $exception ) {
			return new \WP_Error( 'wpp_schema_not_ready', $exception->getMessage(), array( 'status' => 503 ) );
		}

		return new \WP_REST_Response(
			array(
				'verified'       => $verified,
				'window_expired' => $this->verification->is_verification_window_expired( $domain ),
			)
		);
	}

	public function override_verification( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$domain_uuid = (string) $request->get_param( 'domain_uuid' );
		$reason      = (string) $request->get_param( 'reason' );

		if ( '' === trim( $reason ) ) {
			return new \WP_Error( 'wpp_reason_required', __( 'A documented reason is required to override domain verification.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		try {
			$this->verification->administrator_override( $domain_uuid, get_current_user_id(), $reason );
		} catch ( SchemaNotReadyException $exception ) {
			return new \WP_Error( 'wpp_schema_not_ready', $exception->getMessage(), array( 'status' => 503 ) );
		} catch ( \InvalidArgumentException $exception ) {
			return new \WP_Error( 'wpp_not_found', $exception->getMessage(), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response( array( 'overridden' => true ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( OrganisationDomain $domain ): array {
		return array(
			'uuid'                      => $domain->domain_uuid,
			'domain_ascii'              => $domain->domain_ascii,
			'domain_display'            => $domain->domain_display,
			'status'                    => $domain->status->value,
			'verification_method'       => $domain->verification_method?->value,
			'verification_status'       => $domain->verification_status->value,
			'verification_requested_at' => $domain->verification_requested_at?->format( DATE_ATOM ),
			'verified_at'               => $domain->verified_at?->format( DATE_ATOM ),
		);
	}

	private function organisation_service(): OrganisationServiceInterface {
		$service = OrganisationPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No organisation service is registered.' ) );
		}

		return $service;
	}
}
