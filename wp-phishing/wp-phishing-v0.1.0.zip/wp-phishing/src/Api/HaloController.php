<?php
/**
 * HaloPSA pull/acknowledge REST API, per Section 51: "WP-Phishing shall follow the established
 * HaloPSA pull/acknowledgement model used by WP-Questionnaires." Scoped to campaigns and their
 * aggregate statistical data only for this increment - the full §51 list (organisations,
 * contacts, product interactions, usage, chargeable units) is a deliberate, narrower-than-spec
 * fast-follow once this slice is proven (see PLAN.md).
 *
 * Authentication is exactly WP-Questionnaires' own convention: WordPress Application Passwords
 * over HTTP Basic (no custom auth code - `is_user_logged_in()` resolves an Application Password
 * the same way as an interactive login), gated on {@see Capabilities::HALO_API}, a capability
 * deliberately never granted to the operator role - only {@see Roles::INTEGRATION_ROLE}.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\Repositories\CampaignRepository;
use Alltime\WPPhishing\Results\Repositories\RiskWeightSetRepository;
use Alltime\WPPhishing\Results\ResultsService;
use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\FeatureFlags;

final class HaloController {

	private const UUID_PATTERN  = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';
	private const DEFAULT_LIMIT = 50;
	private const MAX_LIMIT     = 100;

	public function __construct(
		private readonly CampaignRepository $campaigns = new CampaignRepository(),
		private readonly ResultsService $results = new ResultsService(),
		private readonly RiskWeightSetRepository $weight_sets = new RiskWeightSetRepository()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/halo/campaigns/pending',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'pending' ),
				'permission_callback' => array( $this, 'can_access' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/halo/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'detail' ),
				'permission_callback' => array( $this, 'can_access' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/halo/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/start',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'start' ),
				'permission_callback' => array( $this, 'can_access' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/halo/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/acknowledge',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'acknowledge' ),
				'permission_callback' => array( $this, 'can_access' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/halo/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/fail',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'fail' ),
				'permission_callback' => array( $this, 'can_access' ),
			)
		);
	}

	public function can_access(): bool {
		return FeatureFlags::is_enabled( FeatureFlags::HALO_INTEGRATION )
			&& is_user_logged_in()
			&& current_user_can( Capabilities::HALO_API );
	}

	public function pending( \WP_REST_Request $request ): \WP_REST_Response {
		$requested_limit = (int) $request->get_param( 'limit' );
		$limit           = min( self::MAX_LIMIT, max( 1, 0 !== $requested_limit ? $requested_limit : self::DEFAULT_LIMIT ) );

		return new \WP_REST_Response(
			array( 'campaigns' => array_map( array( $this, 'summary' ), $this->campaigns->find_pending_for_halo( $limit ) ) )
		);
	}

	public function detail( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return $this->not_found();
		}

		return new \WP_REST_Response( $this->detail_payload( $campaign ) );
	}

	public function start( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return $this->not_found();
		}

		if ( $campaign->halo_sync_status->is_terminal() ) {
			return new \WP_Error( 'wpp_invalid_transition', __( 'This campaign has already been synced or is being ignored.', 'wp-phishing' ), array( 'status' => 409 ) );
		}

		$updated = $this->campaigns->mark_halo_processing( $campaign->id );

		return new \WP_REST_Response(
			array(
				'campaign_uuid'    => $updated->campaign_uuid,
				'halo_sync_status' => $updated->halo_sync_status->value,
			)
		);
	}

	public function acknowledge( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return $this->not_found();
		}

		$updated = $this->campaigns->mark_halo_synced( $campaign->id );

		return new \WP_REST_Response(
			array(
				'campaign_uuid'    => $updated->campaign_uuid,
				'halo_sync_status' => $updated->halo_sync_status->value,
			)
		);
	}

	public function fail( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return $this->not_found();
		}

		$error_message = (string) $request->get_param( 'error_message' );

		if ( '' === trim( $error_message ) ) {
			return new \WP_Error( 'wpp_invalid_payload', __( 'error_message is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$retry   = (bool) $request->get_param( 'retry' );
		$updated = $this->campaigns->mark_halo_failed( $campaign->id, $error_message, $retry );

		return new \WP_REST_Response(
			array(
				'campaign_uuid'    => $updated->campaign_uuid,
				'halo_sync_status' => $updated->halo_sync_status->value,
				'halo_retry_count' => $updated->halo_retry_count,
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private function summary( Campaign $campaign ): array {
		return array(
			'campaign_uuid'     => $campaign->campaign_uuid,
			'organisation_uuid' => $campaign->organisation_uuid,
			'name'              => $campaign->name,
			'status'            => $campaign->status->value,
			'halo_sync_status'  => $campaign->halo_sync_status->value,
			'closed_at'         => $campaign->closed_at?->format( DATE_ATOM ),
		);
	}

	/**
	 * The campaign plus its statistical data set - always aggregate-only, regardless of any
	 * report generated against this campaign and whatever visibility that report was given.
	 * HaloPSA is an external system; named-recipient data must never reach it via this route.
	 *
	 * @return array<string,mixed>
	 */
	private function detail_payload( Campaign $campaign ): array {
		$payload = $this->summary( $campaign );

		$weight_set = $this->weight_sets->find_default();

		if ( null === $weight_set ) {
			return $payload;
		}

		$results               = $this->results->compute_campaign_results( $campaign, $weight_set );
		$payload['statistics'] = array(
			'delivery_statistics' => $this->results->delivery_statistics( $results ),
			'behavioural_results' => $this->results->behavioural_results( $results ),
		);

		return $payload;
	}

	private function find_campaign( \WP_REST_Request $request ): ?Campaign {
		return $this->campaigns->find_by_campaign_uuid( (string) $request->get_param( 'campaign_uuid' ) );
	}

	private function not_found(): \WP_Error {
		return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
	}
}
