<?php
/**
 * REST resource controller for organisations, per Section 69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;
use Alltime\CustomerPlatform\Organisation;
use Alltime\CustomerPlatform\OrganisationInput;
use Alltime\CustomerPlatform\OrganisationPlatformDiscovery;
use Alltime\CustomerPlatform\OrganisationServiceInterface;
use Alltime\WPPhishing\Support\TenantGuard;

final class OrganisationsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => static fn (): bool => is_user_logged_in(),
					'args'                => array(),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => static fn (): bool => is_user_logged_in(),
					'args'                => array(
						'name'     => array(
							'type'     => 'string',
							'required' => true,
						),
						'timezone' => array(
							'type'    => 'string',
							'default' => 'UTC',
						),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<uuid>' . self::UUID_PATTERN . ')',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'can_access' ),
					'args'                => array(
						'uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
			)
		);
	}

	public function can_access( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'uuid' ) );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		unset( $request );

		$memberships = $this->tenant_guard->my_active_memberships();
		$service     = $this->organisation_service();

		$items = array();

		foreach ( $memberships as $membership ) {
			$organisation = $service->get_by_uuid( $membership->organisation_uuid );

			if ( null !== $organisation ) {
				$items[] = self::to_array( $organisation, $membership->role );
			}
		}

		return new \WP_REST_Response(
			array(
				'items' => $items,
				'total' => count( $items ),
			)
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$uuid         = (string) $request->get_param( 'uuid' );
		$organisation = $this->organisation_service()->get_by_uuid( $uuid );

		if ( null === $organisation ) {
			return new \WP_Error( 'wpp_not_found', __( 'Organisation not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$membership = $this->tenant_guard->current_membership( $uuid );

		return new \WP_REST_Response( self::to_array( $organisation, $membership?->role ) );
	}

	/**
	 * Section 1: "establish or select an organisation". Any authenticated user may create one -
	 * they become its Owner. There is deliberately no plan/entitlement check yet (Section 50,
	 * Phase 6) and no bot-protection gate yet (Section 58, Phase 6) - this endpoint is not
	 * reachable by an unauthenticated request, only by an already-logged-in WordPress user.
	 */
	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$name     = (string) $request->get_param( 'name' );
		$timezone = (string) ( $request->get_param( 'timezone' ) ?? 'UTC' );

		if ( '' === trim( $name ) ) {
			return new \WP_Error( 'wpp_invalid_name', __( 'An organisation name is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$service = $this->organisation_service();
		$result  = $service->create_or_update_organisation( new OrganisationInput( name: $name, timezone: $timezone ) );

		// The creator becomes Owner immediately - there is no separate inviter to accept on their
		// behalf, unlike add_member()'s ordinary invited-then-accepted flow (Section 9).
		$membership = $service->add_member( $result->organisation->organisation_uuid, get_current_user_id(), MembershipRole::Owner );
		$service->update_member_status( $membership->id, MembershipStatus::Active );

		return new \WP_REST_Response( self::to_array( $result->organisation, MembershipRole::Owner ), 201 );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Organisation $organisation, ?MembershipRole $my_role = null ): array {
		return array(
			'uuid'       => $organisation->organisation_uuid,
			'name'       => $organisation->name,
			'slug'       => $organisation->slug,
			'status'     => $organisation->status->value,
			'timezone'   => $organisation->timezone,
			'my_role'    => $my_role?->value,
			'created_at' => $organisation->created_at->format( DATE_ATOM ),
			'updated_at' => $organisation->updated_at->format( DATE_ATOM ),
		);
	}

	private function organisation_service(): OrganisationServiceInterface {
		$service = OrganisationPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No organisation service is registered.' ) );
		}

		return $service;
	}
}
