<?php
/**
 * REST resource controller for templates, per Section 28/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\TenantGuard;
use Alltime\WPPhishing\Templates\Enums\Difficulty;
use Alltime\WPPhishing\Templates\Enums\Scenario;
use Alltime\WPPhishing\Templates\Enums\TemplateStatus;
use Alltime\WPPhishing\Templates\Template;
use Alltime\WPPhishing\Templates\TemplateService;

final class TemplatesController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly TemplateService $templates = new TemplateService()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/templates',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/templates/(?P<template_uuid>' . self::UUID_PATTERN . ')/versions',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_versions' ),
					'permission_callback' => array( $this, 'can_read' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_version' ),
					'permission_callback' => array( $this, 'can_manage' ),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/templates/(?P<template_uuid>' . self::UUID_PATTERN . ')/status',
			array(
				'methods'             => \WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'update_status' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);
	}

	public function can_read( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function can_manage( \WP_REST_Request $request ): bool {
		return current_user_can( Capabilities::MANAGE_TEMPLATES ) && $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );

		return new \WP_REST_Response( array( 'items' => array_map( array( $this, 'to_array' ), $this->templates->list_available_for_organisation( $organisation_uuid ) ) ) );
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$scenario   = Scenario::tryFrom( (string) $request->get_param( 'scenario' ) );
		$difficulty = Difficulty::tryFrom( (string) $request->get_param( 'difficulty' ) ) ?? Difficulty::Moderate;

		if ( null === $scenario ) {
			return new \WP_Error( 'wpp_invalid_scenario', __( 'A valid scenario is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$organisation_only = (bool) $request->get_param( 'organisation_only' );

		$template = $this->templates->create(
			$organisation_only ? (string) $request->get_param( 'organisation_uuid' ) : null,
			(string) $request->get_param( 'name' ),
			$scenario,
			$difficulty,
			array_map( 'sanitize_text_field', (array) $request->get_param( 'risk_tags' ) ),
			(string) $request->get_param( 'subject' ),
			(string) $request->get_param( 'from_display_name' ),
			$request->get_param( 'html_body' ),
			$request->get_param( 'text_body' ),
			$request->get_param( 'learning_objective' ),
			get_current_user_id()
		);

		return new \WP_REST_Response( $this->to_array( $template ), 201 );
	}

	public function list_versions( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$template = $this->templates->get( (string) $request->get_param( 'template_uuid' ) );

		if ( null === $template ) {
			return new \WP_Error( 'wpp_not_found', __( 'Template not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response(
			array(
				'items' => array_map(
					static fn ( $version ): array => array(
						'id'                 => $version->id,
						'version_number'     => $version->version_number,
						'subject'            => $version->subject,
						'from_display_name'  => $version->from_display_name,
						'html_body'          => $version->html_body,
						'text_body'          => $version->text_body,
						'learning_objective' => $version->learning_objective,
						'created_at'         => $version->created_at->format( DATE_ATOM ),
					),
					$this->templates->list_versions( $template )
				),
			)
		);
	}

	public function create_version( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$template = $this->templates->get( (string) $request->get_param( 'template_uuid' ) );

		if ( null === $template ) {
			return new \WP_Error( 'wpp_not_found', __( 'Template not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$version = $this->templates->create_new_version(
			$template,
			(string) $request->get_param( 'subject' ),
			(string) $request->get_param( 'from_display_name' ),
			$request->get_param( 'html_body' ),
			$request->get_param( 'text_body' ),
			$request->get_param( 'learning_objective' ),
			get_current_user_id()
		);

		return new \WP_REST_Response(
			array(
				'id'             => $version->id,
				'version_number' => $version->version_number,
			),
			201
		);
	}

	public function update_status( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$template = $this->templates->get( (string) $request->get_param( 'template_uuid' ) );
		$status   = TemplateStatus::tryFrom( (string) $request->get_param( 'status' ) );

		if ( null === $template ) {
			return new \WP_Error( 'wpp_not_found', __( 'Template not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		if ( null === $status ) {
			return new \WP_Error( 'wpp_invalid_status', __( 'A valid status is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$updated = $this->templates->update_status( $template, $status, get_current_user_id() );

		return new \WP_REST_Response( $this->to_array( $updated ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function to_array( Template $template ): array {
		return array(
			'uuid'               => $template->template_uuid,
			'organisation_uuid'  => $template->organisation_uuid,
			'name'               => $template->name,
			'scenario'           => $template->scenario->value,
			'difficulty'         => $template->difficulty->value,
			'risk_tags'          => $template->risk_tags,
			'status'             => $template->status->value,
			'current_version_id' => $template->current_version_id,
		);
	}
}
