<?php
/**
 * REST resource controller for campaigns, per Section 18-21/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\Campaigns\Campaign;
use Alltime\WPPhishing\Campaigns\CampaignApprovalService;
use Alltime\WPPhishing\Campaigns\CampaignService;
use Alltime\WPPhishing\Campaigns\CampaignWave;
use Alltime\WPPhishing\Campaigns\Enums\ApprovalModel;
use Alltime\WPPhishing\Campaigns\Enums\ScheduleMode;
use Alltime\WPPhishing\Support\Capabilities;
use Alltime\WPPhishing\Support\TenantGuard;

final class CampaignsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly CampaignService $campaigns = new CampaignService(),
		private readonly CampaignApprovalService $approvals = new CampaignApprovalService()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => array( $this, 'can_read' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/waves',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_wave' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/submit',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'submit' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/approve',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'approve' ),
				'permission_callback' => array( $this, 'can_approve' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/campaigns/(?P<campaign_uuid>' . self::UUID_PATTERN . ')/cancel',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'cancel' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);
	}

	public function can_read( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function can_manage( \WP_REST_Request $request ): bool {
		return current_user_can( Capabilities::MANAGE_CAMPAIGNS ) && $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator
		);
	}

	/**
	 * Approval requires either Alltime operator status (with the dedicated capability) or an
	 * organisation-level Owner/Administrator role - {@see approve()} decides which role the
	 * decision is recorded under based on which of these actually applied.
	 */
	public function can_approve( \WP_REST_Request $request ): bool {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );

		return ( $this->tenant_guard->is_operator() && current_user_can( Capabilities::APPROVE_CAMPAIGNS ) )
			|| $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );

		return new \WP_REST_Response( array( 'items' => array_map( array( $this, 'to_array' ), $this->campaigns->list_for_organisation( $organisation_uuid ) ) ) );
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$data          = $this->to_array( $campaign );
		$data['waves'] = array_map( array( $this, 'wave_to_array' ), $this->campaigns->list_waves( $campaign ) );

		return new \WP_REST_Response( $data );
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );
		$approval_model    = ApprovalModel::tryFrom( (string) $request->get_param( 'approval_model' ) ) ?? ApprovalModel::CustomerSelfApproval;
		$schedule_mode     = ScheduleMode::tryFrom( (string) $request->get_param( 'schedule_mode' ) ) ?? ScheduleMode::Immediate;
		$starts_at         = $request->get_param( 'starts_at' );

		try {
			$campaign = $this->campaigns->create(
				$organisation_uuid,
				(string) $request->get_param( 'name' ),
				$request->get_param( 'description' ),
				$request->get_param( 'campaign_type' ),
				$request->get_param( 'objective' ),
				$approval_model,
				$schedule_mode,
				$request->get_param( 'timezone' ),
				null !== $starts_at ? new \DateTimeImmutable( (string) $starts_at ) : null,
				null,
				get_current_user_id(),
				$this->tenant_guard->is_operator()
			);
		} catch ( \InvalidArgumentException $exception ) {
			return new \WP_Error( 'wpp_invalid_campaign', $exception->getMessage(), array( 'status' => 400 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- CampaignService's messages are fixed, translated strings, never user input.
		}

		return new \WP_REST_Response( $this->to_array( $campaign ), 201 );
	}

	public function create_wave( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$delivery_window_starts_at = $request->get_param( 'delivery_window_starts_at' );
		$delivery_window_ends_at   = $request->get_param( 'delivery_window_ends_at' );

		try {
			$wave = $this->campaigns->create_wave(
				$campaign,
				(string) $request->get_param( 'name' ),
				(int) $request->get_param( 'template_version_id' ),
				(int) $request->get_param( 'sender_identity_id' ),
				null !== $request->get_param( 'landing_page_version_id' ) ? (int) $request->get_param( 'landing_page_version_id' ) : null,
				(int) $request->get_param( 'recipient_group_id' ),
				null !== $delivery_window_starts_at ? new \DateTimeImmutable( (string) $delivery_window_starts_at ) : null,
				null !== $delivery_window_ends_at ? new \DateTimeImmutable( (string) $delivery_window_ends_at ) : null,
				get_current_user_id()
			);
		} catch ( \InvalidArgumentException $exception ) {
			return new \WP_Error( 'wpp_invalid_wave', $exception->getMessage(), array( 'status' => 400 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- CampaignService's messages are fixed, translated strings, never user input.
		}

		return new \WP_REST_Response( $this->wave_to_array( $wave ), 201 );
	}

	public function submit( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		try {
			$updated = $this->approvals->submit( $campaign, get_current_user_id() );
		} catch ( \InvalidArgumentException $exception ) {
			return new \WP_Error( 'wpp_invalid_transition', $exception->getMessage(), array( 'status' => 409 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- fixed, translated strings, never user input.
		}

		return new \WP_REST_Response( $this->to_array( $updated ) );
	}

	public function approve( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$role     = $this->tenant_guard->is_operator() && current_user_can( Capabilities::APPROVE_CAMPAIGNS ) ? 'alltime' : 'customer';
		$approved = 'rejected' !== (string) $request->get_param( 'decision' );

		try {
			$updated = $this->approvals->decide( $campaign, get_current_user_id(), $role, $approved, $request->get_param( 'notes' ) );
		} catch ( \InvalidArgumentException | \RuntimeException $exception ) {
			return new \WP_Error( 'wpp_invalid_transition', $exception->getMessage(), array( 'status' => 409 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- fixed, translated strings, never user input.
		}

		return new \WP_REST_Response( $this->to_array( $updated ) );
	}

	public function cancel( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$campaign = $this->find_campaign( $request );

		if ( null === $campaign ) {
			return new \WP_Error( 'wpp_not_found', __( 'Campaign not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		try {
			$updated = $this->campaigns->cancel( $campaign, get_current_user_id() );
		} catch ( \InvalidArgumentException $exception ) {
			return new \WP_Error( 'wpp_invalid_transition', $exception->getMessage(), array( 'status' => 409 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- fixed, translated strings, never user input.
		}

		return new \WP_REST_Response( $this->to_array( $updated ) );
	}

	private function find_campaign( \WP_REST_Request $request ): ?Campaign {
		return $this->campaigns->get( (string) $request->get_param( 'organisation_uuid' ), (string) $request->get_param( 'campaign_uuid' ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function to_array( Campaign $campaign ): array {
		return array(
			'uuid'                     => $campaign->campaign_uuid,
			'name'                     => $campaign->name,
			'description'              => $campaign->description,
			'campaign_type'            => $campaign->campaign_type,
			'status'                   => $campaign->status->value,
			'objective'                => $campaign->objective,
			'approval_model'           => $campaign->approval_model->value,
			'schedule_mode'            => $campaign->schedule_mode->value,
			'timezone'                 => $campaign->timezone,
			'starts_at'                => $campaign->starts_at?->format( DATE_ATOM ),
			'ends_at'                  => $campaign->ends_at?->format( DATE_ATOM ),
			'expected_recipient_count' => $campaign->expected_recipient_count,
			'expected_message_count'   => $campaign->expected_message_count,
			'approved_at'              => $campaign->approved_at?->format( DATE_ATOM ),
			'closed_at'                => $campaign->closed_at?->format( DATE_ATOM ),
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private function wave_to_array( CampaignWave $wave ): array {
		return array(
			'uuid'                      => $wave->wave_uuid,
			'name'                      => $wave->name,
			'status'                    => $wave->status->value,
			'template_version_id'       => $wave->template_version_id,
			'sender_identity_id'        => $wave->sender_identity_id,
			'landing_page_version_id'   => $wave->landing_page_version_id,
			'recipient_group_id'        => $wave->recipient_group_id,
			'delivery_window_starts_at' => $wave->delivery_window_starts_at?->format( DATE_ATOM ),
			'delivery_window_ends_at'   => $wave->delivery_window_ends_at?->format( DATE_ATOM ),
			'activated_at'              => $wave->activated_at?->format( DATE_ATOM ),
		);
	}
}
