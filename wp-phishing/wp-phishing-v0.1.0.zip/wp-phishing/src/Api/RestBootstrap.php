<?php
/**
 * REST API bootstrap, per Section 69.
 *
 * Registers the versioned `wpp/v1` namespace. Every route must define a
 * `permission_callback` that resolves through {@see \Alltime\WPPhishing\Support\TenantGuard} for
 * anything organisation-scoped (Section 65/70) - request parameters such as `organisation_uuid`
 * are never trusted on their own.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use const Alltime\WPPhishing\WPP_SCHEMA_VERSION;
use const Alltime\WPPhishing\WPP_VERSION;

final class RestBootstrap {

	public const NAMESPACE_V1 = 'wpp/v1';

	public function boot(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			self::NAMESPACE_V1,
			'/status',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_status' ),
				'permission_callback' => static fn (): bool => is_user_logged_in(),
				'args'                => array(),
			)
		);

		( new OrganisationsController() )->register_routes();
		( new DomainsController() )->register_routes();
		( new RecipientsController() )->register_routes();
		( new RecipientGroupsController() )->register_routes();
		( new RecipientImportsController() )->register_routes();
		( new SuppressionsController() )->register_routes();
		( new TemplatesController() )->register_routes();
		( new LandingPagesController() )->register_routes();
		( new CampaignsController() )->register_routes();
		( new ReportsController() )->register_routes();
		( new MailIntegrationsController() )->register_routes();
		( new HaloController() )->register_routes();
	}

	public function get_status( \WP_REST_Request $request ): \WP_REST_Response {
		unset( $request );

		return new \WP_REST_Response(
			array(
				'plugin_version' => WPP_VERSION,
				'schema_version' => WPP_SCHEMA_VERSION,
			)
		);
	}
}
