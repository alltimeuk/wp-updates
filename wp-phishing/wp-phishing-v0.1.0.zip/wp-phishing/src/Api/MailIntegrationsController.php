<?php
/**
 * REST resource controller for per-organisation mail integrations, per the "Multi-provider
 * delivery modes" plan addition.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\MailIntegrationService;
use Alltime\WPPhishing\MailIntegrations\OrganisationMailIntegration;
use Alltime\WPPhishing\Support\TenantGuard;
use Alltime\WPPhishing\Verification\Support\MxProviderClassifier;

final class MailIntegrationsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly MailIntegrationService $integrations = new MailIntegrationService(),
		private readonly MxProviderClassifier $mx_classifier = new MxProviderClassifier()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/mail-integrations/mx-provider',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'classify_domain' ),
				'permission_callback' => static fn (): bool => is_user_logged_in(),
				'args'                => array(
					'domain' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/mail-integrations',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_manage' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'initiate' ),
					'permission_callback' => array( $this, 'can_manage' ),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/mail-integrations/(?P<integration_uuid>' . self::UUID_PATTERN . ')/verify',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'verify' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/mail-integrations/(?P<integration_uuid>' . self::UUID_PATTERN . ')/revoke',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'revoke' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);
	}

	/**
	 * Managing an organisation's own mail integrations is an organisation-authority decision
	 * (Section 9's Owner/Administrator), not a read-only "view" action - the same bar
	 * `DomainsController::can_manage()` applies to adding/verifying a domain.
	 */
	public function can_manage( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator
		);
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );

		return new \WP_REST_Response( array( 'items' => array_map( array( $this, 'to_array' ), $this->integrations->list_for_organisation( $organisation_uuid ) ) ) );
	}

	public function initiate( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$provider   = MailIntegrationProvider::tryFrom( (string) $request->get_param( 'provider' ) );
		$capability = MailIntegrationCapability::tryFrom( (string) $request->get_param( 'capability' ) );

		if ( null === $provider || null === $capability ) {
			return new \WP_Error( 'wpp_invalid_integration', __( 'A valid provider and capability are required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$integration = $this->integrations->initiate( (string) $request->get_param( 'organisation_uuid' ), $provider, $capability, get_current_user_id() );

		$data = $this->to_array( $integration );

		if ( MailIntegrationProvider::Microsoft365 === $provider ) {
			$data['consent_url'] = $this->integrations->microsoft_consent_url( $capability, (string) $request->get_param( 'redirect_uri' ) );
		} else {
			$data['delegation_instructions'] = $this->integrations->google_delegation_instructions( $capability );
		}

		return new \WP_REST_Response( $data, 201 );
	}

	public function verify( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$integration = $this->find_integration( $request );

		if ( null === $integration ) {
			return new \WP_Error( 'wpp_not_found', __( 'Mail integration not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$updated = MailIntegrationProvider::Microsoft365 === $integration->provider
			? $this->integrations->verify_microsoft( $integration, (string) $request->get_param( 'tenant_id' ) )
			: $this->integrations->verify_google( $integration, (string) $request->get_param( 'primary_domain' ), (string) $request->get_param( 'test_mailbox' ) );

		return new \WP_REST_Response( $this->to_array( $updated ) );
	}

	public function revoke( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$integration = $this->find_integration( $request );

		if ( null === $integration ) {
			return new \WP_Error( 'wpp_not_found', __( 'Mail integration not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response( $this->to_array( $this->integrations->revoke( $integration, get_current_user_id() ) ) );
	}

	/**
	 * Classifies a domain's MX records so a customer-facing UI only offers the consent option
	 * matching what the domain actually runs on - not itself organisation-scoped, so any
	 * authenticated request may call it.
	 */
	public function classify_domain( \WP_REST_Request $request ): \WP_REST_Response {
		return new \WP_REST_Response( array( 'mx_provider' => $this->mx_classifier->classify( (string) $request->get_param( 'domain' ) )->value ) );
	}

	private function find_integration( \WP_REST_Request $request ): ?OrganisationMailIntegration {
		return $this->integrations->get( (string) $request->get_param( 'organisation_uuid' ), (string) $request->get_param( 'integration_uuid' ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function to_array( OrganisationMailIntegration $integration ): array {
		return array(
			'uuid'              => $integration->integration_uuid,
			'provider'          => $integration->provider->value,
			'capability'        => $integration->capability->value,
			'status'            => $integration->status->value,
			'tenant_identifier' => $integration->tenant_identifier,
			'verified_at'       => $integration->verified_at?->format( DATE_ATOM ),
		);
	}
}
