<?php
/**
 * REST resource controller for recipient imports, per Section 15/69.
 *
 * Validation and commit each process one bounded batch per request
 * ({@see \Alltime\WPPhishing\Recipients\RecipientImportService}) - a client polls the
 * corresponding endpoint (or simply waits for the background sweep) until the import's `status`
 * reaches a terminal state. This keeps every request bounded regardless of import size (Section
 * 15: "Large imports shall run asynchronously").
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\Recipients\Enums\ImportRowStatus;
use Alltime\WPPhishing\Recipients\Enums\ImportSourceFormat;
use Alltime\WPPhishing\Recipients\RecipientImport;
use Alltime\WPPhishing\Recipients\RecipientImportRow;
use Alltime\WPPhishing\Recipients\RecipientImportService;
use Alltime\WPPhishing\Recipients\Repositories\RecipientImportRepository;
use Alltime\WPPhishing\Support\TenantGuard;

final class RecipientImportsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	/**
	 * A generous but bounded ceiling on the uploaded file itself - large legitimate imports stay
	 * well under this; it exists to reject something pathological before it's ever parsed.
	 */
	private const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly RecipientImportService $service = new RecipientImportService(),
		private readonly RecipientImportRepository $imports = new RecipientImportRepository()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/recipient-imports',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_manage_by_org_param' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_manage_by_org_param' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'source_format'     => array(
							'type'     => 'string',
							'required' => true,
							'enum'     => array( ImportSourceFormat::Csv->value, ImportSourceFormat::Xlsx->value ),
						),
					),
				),
			)
		);

		$item_route = '/recipient-imports/(?P<import_uuid>' . self::UUID_PATTERN . ')';

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			$item_route,
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => array( $this, 'can_manage_by_loaded_import' ),
				'args'                => array(
					'import_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			$item_route . '/mapping',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'set_mapping' ),
				'permission_callback' => array( $this, 'can_manage_by_loaded_import' ),
				'args'                => array(
					'import_uuid'       => array(
						'type'     => 'string',
						'required' => true,
					),
					'mapping'           => array(
						'type'     => 'object',
						'required' => true,
					),
					'target_group_uuid' => array( 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			$item_route . '/validate',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'validate_batch' ),
				'permission_callback' => array( $this, 'can_manage_by_loaded_import' ),
				'args'                => array(
					'import_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			$item_route . '/rows',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_rows' ),
				'permission_callback' => array( $this, 'can_manage_by_loaded_import' ),
				'args'                => array(
					'import_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
					'status'      => array(
						'type' => 'string',
						'enum' => array_map( static fn ( ImportRowStatus $s ): string => $s->value, ImportRowStatus::cases() ),
					),
					'page'        => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'per_page'    => array(
						'type'    => 'integer',
						'default' => 50,
						'minimum' => 1,
						'maximum' => 200,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			$item_route . '/commit',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'commit_batch' ),
				'permission_callback' => array( $this, 'can_manage_by_loaded_import' ),
				'args'                => array(
					'import_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			$item_route . '/cancel',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'cancel_item' ),
				'permission_callback' => array( $this, 'can_manage_by_loaded_import' ),
				'args'                => array(
					'import_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	public function can_manage_by_org_param( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator
		);
	}

	/**
	 * Import item routes carry only `import_uuid`, not `organisation_uuid` - the organisation is
	 * looked up from the import itself, then checked, so a caller cannot probe for the existence
	 * of an import UUID from outside its owning organisation.
	 */
	public function can_manage_by_loaded_import( \WP_REST_Request $request ): bool {
		$import = $this->imports->find_by_uuid_in_any_organisation( (string) $request->get_param( 'import_uuid' ) );

		if ( null === $import ) {
			// No import to leak the existence of either way; let the callback's own 404 handle it.
			return true;
		}

		return $this->tenant_guard->has_role( $import->organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$items = $this->imports->find_all_for_organisation( (string) $request->get_param( 'organisation_uuid' ), 20, 1 );

		return new \WP_REST_Response( array( 'items' => array_map( array( self::class, 'to_array' ), $items ) ) );
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$files = $request->get_file_params();

		if ( empty( $files['file'] ) || UPLOAD_ERR_OK !== ( $files['file']['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			return new \WP_Error( 'wpp_upload_missing', __( 'No file was uploaded.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$file = $files['file'];

		if ( (int) $file['size'] > self::MAX_UPLOAD_BYTES ) {
			return new \WP_Error( 'wpp_upload_too_large', __( 'The uploaded file exceeds the maximum allowed size.', 'wp-phishing' ), array( 'status' => 413 ) );
		}

		if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new \WP_Error( 'wpp_upload_invalid', __( 'The uploaded file could not be verified.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$source_format = ImportSourceFormat::from( (string) $request->get_param( 'source_format' ) );

		try {
			$import = $this->service->start_import(
				(string) $request->get_param( 'organisation_uuid' ),
				$source_format,
				$file['tmp_name'],
				sanitize_file_name( (string) $file['name'] ),
				get_current_user_id()
			);
		} catch ( \Throwable $exception ) {
			return new \WP_Error( 'wpp_import_parse_failed', $exception->getMessage(), array( 'status' => 422 ) );
		}

		return new \WP_REST_Response(
			array_merge(
				self::to_array( $import ),
				array( 'detected_headers' => $this->service->detected_headers( $import ) )
			),
			201
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$import = $this->find_import_or_404( $request );

		if ( $import instanceof \WP_Error ) {
			return $import;
		}

		return new \WP_REST_Response( self::to_array( $import ) );
	}

	public function set_mapping( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$import = $this->find_import_or_404( $request );

		if ( $import instanceof \WP_Error ) {
			return $import;
		}

		$mapping_param = $request->get_param( 'mapping' );

		if ( ! is_array( $mapping_param ) ) {
			return new \WP_Error( 'wpp_invalid_mapping', __( 'mapping must be an object of column header to target field.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		/** @var array<string,string> $mapping */
		$mapping = array_map( 'strval', $mapping_param );

		try {
			$import = $this->service->set_column_mapping(
				$import,
				$mapping,
				$request->get_param( 'target_group_uuid' ) ? (string) $request->get_param( 'target_group_uuid' ) : null
			);
		} catch ( \InvalidArgumentException $exception ) {
			return new \WP_Error( 'wpp_invalid_mapping', $exception->getMessage(), array( 'status' => 400 ) );
		}

		return new \WP_REST_Response( self::to_array( $import ) );
	}

	public function validate_batch( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$import = $this->find_import_or_404( $request );

		if ( $import instanceof \WP_Error ) {
			return $import;
		}

		try {
			$import = $this->service->validate_batch( $import );
		} catch ( \RuntimeException $exception ) {
			return new \WP_Error( 'wpp_validate_failed', $exception->getMessage(), array( 'status' => 409 ) );
		}

		return new \WP_REST_Response( self::to_array( $import ) );
	}

	public function list_rows( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$import = $this->find_import_or_404( $request );

		if ( $import instanceof \WP_Error ) {
			return $import;
		}

		$status_param = $request->get_param( 'status' );
		$status       = is_string( $status_param ) && '' !== $status_param ? ImportRowStatus::from( $status_param ) : null;
		$page         = max( 1, (int) $request->get_param( 'page' ) );
		$per_page     = min( 200, max( 1, (int) $request->get_param( 'per_page' ) ) );

		$rows = $this->service->preview( $import, $per_page, $page, $status );

		return new \WP_REST_Response( array( 'items' => array_map( array( self::class, 'row_to_array' ), $rows ) ) );
	}

	public function commit_batch( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$import = $this->find_import_or_404( $request );

		if ( $import instanceof \WP_Error ) {
			return $import;
		}

		try {
			$import = $this->service->commit_batch( $import, get_current_user_id() );
		} catch ( \RuntimeException $exception ) {
			return new \WP_Error( 'wpp_commit_failed', $exception->getMessage(), array( 'status' => 409 ) );
		}

		return new \WP_REST_Response( self::to_array( $import ) );
	}

	public function cancel_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$import = $this->find_import_or_404( $request );

		if ( $import instanceof \WP_Error ) {
			return $import;
		}

		try {
			$import = $this->service->cancel( $import, get_current_user_id() );
		} catch ( \RuntimeException $exception ) {
			return new \WP_Error( 'wpp_cancel_failed', $exception->getMessage(), array( 'status' => 409 ) );
		}

		return new \WP_REST_Response( self::to_array( $import ) );
	}

	private function find_import_or_404( \WP_REST_Request $request ): RecipientImport|\WP_Error {
		$import = $this->imports->find_by_uuid_in_any_organisation( (string) $request->get_param( 'import_uuid' ) );

		if ( null === $import ) {
			return new \WP_Error( 'wpp_not_found', __( 'Recipient import not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		return $import;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( RecipientImport $import ): array {
		return array(
			'uuid'              => $import->import_uuid,
			'status'            => $import->status->value,
			'source_format'     => $import->source_format->value,
			'original_filename' => $import->original_filename,
			'target_group_uuid' => $import->target_group_uuid,
			'column_mapping'    => $import->column_mapping,
			'total_rows'        => $import->total_rows,
			'valid_rows'        => $import->valid_rows,
			'invalid_rows'      => $import->invalid_rows,
			'duplicate_rows'    => $import->duplicate_rows,
			'suppressed_rows'   => $import->suppressed_rows,
			'committed_rows'    => $import->committed_rows,
			'created_at'        => $import->created_at->format( DATE_ATOM ),
			'updated_at'        => $import->updated_at->format( DATE_ATOM ),
			'committed_at'      => $import->committed_at?->format( DATE_ATOM ),
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function row_to_array( RecipientImportRow $row ): array {
		return array(
			'row_number'        => $row->row_number,
			'raw_data'          => $row->raw_data,
			'mapped_data'       => $row->mapped_data,
			'status'            => $row->status->value,
			'validation_errors' => $row->validation_errors,
		);
	}
}
