<?php
/**
 * REST resource controller for recipients, per Section 14/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\Recipients\Recipient;
use Alltime\WPPhishing\Recipients\Repositories\RecipientRepository;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Support\TenantGuard;

final class RecipientsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly RecipientRepository $recipients = new RecipientRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/recipients',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_items' ),
				'permission_callback' => array( $this, 'can_read' ),
				'args'                => array(
					'organisation_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
					'page'              => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'per_page'          => array(
						'type'    => 'integer',
						'default' => 50,
						'minimum' => 1,
						'maximum' => 200,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/recipients/(?P<recipient_uuid>' . self::UUID_PATTERN . ')',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'can_read' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'recipient_uuid'    => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'recipient_uuid'    => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
			)
		);
	}

	public function can_read( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function can_manage( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator
		);
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );
		$page              = max( 1, (int) $request->get_param( 'page' ) );
		$per_page          = min( 200, max( 1, (int) $request->get_param( 'per_page' ) ) );

		return new \WP_REST_Response(
			array(
				'items' => array_map( array( self::class, 'to_array' ), $this->recipients->find_all_for_organisation( $organisation_uuid, $per_page, $page ) ),
				'total' => $this->recipients->count_for_organisation( $organisation_uuid ),
				'page'  => $page,
			)
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$recipient = $this->recipients->find_by_uuid( (string) $request->get_param( 'organisation_uuid' ), (string) $request->get_param( 'recipient_uuid' ) );

		if ( null === $recipient ) {
			return new \WP_Error( 'wpp_not_found', __( 'Recipient not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response( self::to_array( $recipient ) );
	}

	public function delete_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$recipient = $this->recipients->find_by_uuid( (string) $request->get_param( 'organisation_uuid' ), (string) $request->get_param( 'recipient_uuid' ) );

		if ( null === $recipient ) {
			return new \WP_Error( 'wpp_not_found', __( 'Recipient not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$this->recipients->soft_delete( $recipient->id );

		$this->audit_logger->log( 'recipient.removed', 'recipient', $recipient->recipient_uuid, get_current_user_id(), organisation_uuid: $recipient->organisation_uuid );

		return new \WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Recipient $recipient ): array {
		return array(
			'uuid'                      => $recipient->recipient_uuid,
			'email'                     => $recipient->email,
			'given_name'                => $recipient->given_name,
			'family_name'               => $recipient->family_name,
			'job_title'                 => $recipient->job_title,
			'department'                => $recipient->department,
			'team'                      => $recipient->team,
			'location'                  => $recipient->location,
			'manager_reference'         => $recipient->manager_reference,
			'employment_classification' => $recipient->employment_classification,
			'status'                    => $recipient->status->value,
			'source'                    => $recipient->source->value,
			'metadata'                  => $recipient->metadata,
			'created_at'                => $recipient->created_at->format( DATE_ATOM ),
			'updated_at'                => $recipient->updated_at->format( DATE_ATOM ),
		);
	}
}
