<?php
/**
 * REST resource controller for recipient groups, per Section 17/69.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Api;

use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\WPPhishing\Recipients\RecipientGroup;
use Alltime\WPPhishing\Recipients\RecipientGroupService;
use Alltime\WPPhishing\Recipients\Repositories\RecipientRepository;
use Alltime\WPPhishing\Support\TenantGuard;

final class RecipientGroupsController {

	private const UUID_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly RecipientGroupService $service = new RecipientGroupService(),
		private readonly RecipientRepository $recipients = new RecipientRepository()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/recipient-groups',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'name'              => array(
							'type'     => 'string',
							'required' => true,
						),
						'description'       => array( 'type' => 'string' ),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/recipient-groups/(?P<group_uuid>' . self::UUID_PATTERN . ')',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'can_read' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'group_uuid'        => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'can_manage' ),
					'args'                => array(
						'organisation_uuid' => array(
							'type'     => 'string',
							'required' => true,
						),
						'group_uuid'        => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/recipient-groups/(?P<group_uuid>' . self::UUID_PATTERN . ')/members',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'add_member' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(
					'organisation_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
					'group_uuid'        => array(
						'type'     => 'string',
						'required' => true,
					),
					'recipient_uuid'    => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_uuid>' . self::UUID_PATTERN . ')/recipient-groups/(?P<group_uuid>' . self::UUID_PATTERN . ')/members/(?P<recipient_uuid>' . self::UUID_PATTERN . ')',
			array(
				'methods'             => \WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'remove_member' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(
					'organisation_uuid' => array(
						'type'     => 'string',
						'required' => true,
					),
					'group_uuid'        => array(
						'type'     => 'string',
						'required' => true,
					),
					'recipient_uuid'    => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	public function can_read( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->can_access_organisation( (string) $request->get_param( 'organisation_uuid' ) );
	}

	public function can_manage( \WP_REST_Request $request ): bool {
		return $this->tenant_guard->has_role(
			(string) $request->get_param( 'organisation_uuid' ),
			MembershipRole::Owner,
			MembershipRole::Administrator
		);
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_uuid = (string) $request->get_param( 'organisation_uuid' );

		$items = array_map(
			fn ( RecipientGroup $group ): array => self::to_array( $group, $this->service->count_members( $group ) ),
			$this->service->list_for_organisation( $organisation_uuid )
		);

		return new \WP_REST_Response( array( 'items' => $items ) );
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$name = (string) $request->get_param( 'name' );

		if ( '' === trim( $name ) ) {
			return new \WP_Error( 'wpp_invalid_name', __( 'A group name is required.', 'wp-phishing' ), array( 'status' => 400 ) );
		}

		$group = $this->service->create(
			(string) $request->get_param( 'organisation_uuid' ),
			$name,
			$request->get_param( 'description' ) ? (string) $request->get_param( 'description' ) : null,
			get_current_user_id()
		);

		return new \WP_REST_Response( self::to_array( $group, 0 ), 201 );
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$group = $this->find_group_or_404( $request );

		if ( $group instanceof \WP_Error ) {
			return $group;
		}

		return new \WP_REST_Response( self::to_array( $group, $this->service->count_members( $group ) ) );
	}

	public function delete_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$group = $this->find_group_or_404( $request );

		if ( $group instanceof \WP_Error ) {
			return $group;
		}

		$this->service->delete( $group, get_current_user_id() );

		return new \WP_REST_Response( array( 'deleted' => true ) );
	}

	public function add_member( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$group = $this->find_group_or_404( $request );

		if ( $group instanceof \WP_Error ) {
			return $group;
		}

		$recipient = $this->recipients->find_by_uuid( $group->organisation_uuid, (string) $request->get_param( 'recipient_uuid' ) );

		if ( null === $recipient ) {
			return new \WP_Error( 'wpp_not_found', __( 'Recipient not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$this->service->add_member( $group, $recipient, get_current_user_id() );

		return new \WP_REST_Response( array( 'added' => true ) );
	}

	public function remove_member( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$group = $this->find_group_or_404( $request );

		if ( $group instanceof \WP_Error ) {
			return $group;
		}

		$recipient = $this->recipients->find_by_uuid( $group->organisation_uuid, (string) $request->get_param( 'recipient_uuid' ) );

		if ( null === $recipient ) {
			return new \WP_Error( 'wpp_not_found', __( 'Recipient not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		$this->service->remove_member( $group, $recipient, get_current_user_id() );

		return new \WP_REST_Response( array( 'removed' => true ) );
	}

	private function find_group_or_404( \WP_REST_Request $request ): RecipientGroup|\WP_Error {
		$group = $this->service->get( (string) $request->get_param( 'organisation_uuid' ), (string) $request->get_param( 'group_uuid' ) );

		if ( null === $group ) {
			return new \WP_Error( 'wpp_not_found', __( 'Recipient group not found.', 'wp-phishing' ), array( 'status' => 404 ) );
		}

		return $group;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( RecipientGroup $group, int $member_count ): array {
		return array(
			'uuid'         => $group->group_uuid,
			'name'         => $group->name,
			'description'  => $group->description,
			'type'         => $group->type->value,
			'member_count' => $member_count,
			'created_at'   => $group->created_at->format( DATE_ATOM ),
			'updated_at'   => $group->updated_at->format( DATE_ATOM ),
		);
	}
}
