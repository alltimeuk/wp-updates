# WP-Phishing

Self-service and consultant-operated phishing simulation and human-risk assessment platform for
WordPress, built by Alltime Technologies Ltd.

See [`wp-phishing-requirements-specification.md`](wp-phishing-requirements-specification.md) for
the product/technical requirements and [`PLAN.md`](PLAN.md) for the implementation plan and
delivery sequence.

## Development

```bash
composer install
composer lint       # phpcs
composer analyse    # phpstan
composer test       # phpunit unit suite
composer test:integration
```

## Related repositories

- `alltimeuk/wp-questionnaires`
- `alltimeuk/wp-reconnaissance`

Each product remains independently deployable; where installed together they interoperate
through compatible shared Alltime service contracts (see PLAN.md Section 2).
