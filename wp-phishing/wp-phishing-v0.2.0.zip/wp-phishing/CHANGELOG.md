# Changelog

## 0.2.0 - 2026-09-15

Admin visual refresh - Companies workspace & Settings:

- Brings the visual language of a design reference built in Claude Design (an instrument-panel
  console treatment - a teal accent, status pills, tighter table typography) into the actual
  Companies workspace and Settings screens - the two screens that reference covered. Not a redesign
  of every admin screen in this plugin, and not a new component library - a scoped CSS + markup
  pass on top of the existing WP-admin structure.
- New `Support\StatusPill::render( $label, $tone )` - a small shared helper (`good`/`warn`/`bad`/
  `muted`) used everywhere a table cell is fundamentally a state rather than plain data: domain
  verification status, recipient status, a suppression flag, import status, mail-integration
  status, a suppression's Domain/Email scope and Active flag, a risk-weight set's Default flag, and
  an audit-log entry's Outcome. `CompanyWorkspaceRenderer::status_tone()` maps the four domain
  enums that share this vocabulary (`DomainVerificationStatus`, `ImportStatus`,
  `MailIntegrationStatus`, `RecipientStatus`) to a tone in one place, since their case names happen
  to carry the same meaning consistently (every one of these enums' "failed"/"pending" means the
  same thing tone-wise).
- `assets/admin/admin.css` gains the `.wpp-admin-wrap` design-token scope (every wp-phishing admin
  screen's own `<div class="wrap">` now also carries this class) and the `.wpp-pill` component,
  plus table/tab-bar/primary-button polish. Deliberately no external font loading - this is
  production wp-admin, not the design artifact itself, and a security/compliance-focused product
  pulling in a third-party font CDN inside its own admin screens would be an odd thing to ship;
  system font stacks carry the same intent instead. Scoped to `.wpp-admin-wrap` rather than styling
  `.wrap`/`.widefat`/`.button` globally, since those are shared WP-admin classes every other plugin
  and WordPress core itself also use.
- `CompanyWorkspaceRenderer` is shared with the customer portal, so its new pill markup reaches
  `/phishing/*` too - `AuthBootstrap`'s bare, intentionally-unstyled raw-route document now carries
  a small inline `<style>` copy of just the `.wpp-pill` rules (not the whole admin stylesheet, which
  has no enqueue mechanism there), so a pill doesn't render as an unstyled, broken-looking dot on
  the one route with genuinely zero other styling. A themed `[wpp_customer_*]` shortcode page still
  gets its styling entirely from the theme, unchanged.

Themed customer portal 1/N - `CustomerPortalUrls`:

- New `Auth\CustomerPortalUrls::url( $route, $query_args = [] )` - the single place that resolves a
  customer-portal route to a URL, preferring a themed WordPress Page an admin has mapped to that
  route (a later slice adds the Settings > Portal Pages screen that writes the mapping) over the
  plugin's own raw `/phishing/<route>/` route. Every hardcoded `home_url('/phishing/...')` call in
  `AuthBootstrap` and `Roles::block_wp_admin_for_customers()` now goes through it, so a themed page
  (once one is mapped) is used everywhere this plugin links to its own customer-portal screens -
  verification/reset emails, cross-links between screens, the post-login redirect - not just at the
  URL the visitor happened to arrive from. Filterable via `wpp_customer_portal_url`. Ported from
  `alltimeuk/wp-reconnaissance`'s own `CustomerPortalUrls`.
- New `AuthBootstrap::SHORTCODE_ROUTES` (public) and `route_labels()` - the authoritative list a
  later slice's shortcode registration and Portal Pages admin screen both iterate, rather than
  duplicating it. Deliberately excludes `logout`: signing out must always hit its own raw route
  regardless of any mapping, since reloading a mapped Account/Company page after logging out has no
  way to reflect the just-ended session - matches wp-reconnaissance's own documented exception.
- `tests/bootstrap.php` gains `add_query_arg()`/`get_post_status()`/`get_post_type()`/
  `get_permalink()` polyfills (none of the unit suite's WordPress-function stubs covered these
  before), plus 9 new unit tests for `CustomerPortalUrls` covering the raw-route fallback, a mapped
  published Page, an unpublished or wrong-post-type mapping falling back correctly, query-arg
  appending on both paths, per-request memoization, and the filter override.

First slice of the themed customer-portal work: bringing wp-reconnaissance's
`[wpr_customer_*]`-shortcode-embedding pattern into wp-phishing, so `/phishing/*` can render inside
an ordinary themed WordPress Page instead of only its own bare document.

Themed customer portal 2/N - shortcode dispatch infrastructure:

- `AuthBootstrap` gains everything a `[wpp_customer_*]` shortcode (registered in the next slice)
  needs to actually render and handle its own forms: `dispatch_shortcode_post()` (a second
  `template_redirect` dispatcher, page-agnostic - it recognises a shortcode form's POST from a
  hidden `wpp_shortcode_route` field rather than the URL, since an embedded page has no dedicated
  route of its own; guarded so a request can never fire both dispatchers), `render_customer_shortcode()`
  (the GET-only counterpart - body only, no `<!doctype html>`/`<h1>` wrapper, since the theme's own
  page provides that), and `maybe_send_no_cache_headers_for_shortcode_page()` (scans the current
  page's content for any customer-portal shortcode and sends no-cache headers if found - without
  this, a page-cache plugin could serve one visitor's signed-in account page to the next visitor of
  the same URL).
- `handle_login()`'s post-login redirect now honours an optional hidden `wpp_login_redirect` field
  (re-validated via `wp_validate_redirect()`, never trusted as-is) so
  `[wpp_customer_login redirect="..."]` can send a visitor somewhere other than the Account page -
  deliberately not a generic referer bounce, since a shortcode-embedded login form's referer is the
  login page itself.
- `render_reset_password_screen()` and `requested_company()`/`render_company_shortcode()` are new,
  small extractions from `handle_reset_password()`/`handle_company()` - both already had the
  GET-only rendering they needed close at hand (`render_account_page()`/`render_company_page()`
  already existed as pure, notice-taking render methods from the Companies Workspace's own customer
  slice), so this port needed far less restructuring than wp-reconnaissance's original did.
- Notably absent, on purpose: wp-reconnaissance's generic `$shortcode_context`/`redirect_target()`
  mechanism. None of wp-phishing's account/company write actions (group/suppression/import/mail-
  integration management) redirect on success - they always redisplay the same page with an inline
  notice - so the only place a shortcode-aware redirect override was actually needed is `login`'s,
  handled directly via the hidden field above. Porting the generic mechanism anyway would have been
  copying a shape wp-phishing's own architecture doesn't call for.

Themed customer portal 3/N - `Shortcodes\CustomerPortalShortcodes`:

- New `[wpp_customer_register]`, `[wpp_customer_verify_email]`, `[wpp_customer_login]`,
  `[wpp_customer_forgot_password]`, `[wpp_customer_reset_password]`, `[wpp_customer_account]`, and
  `[wpp_customer_company]` shortcodes - one per `AuthBootstrap::SHORTCODE_ROUTES` entry (`logout`
  deliberately has none). A site can now build an ordinary themed WordPress Page and drop the
  matching shortcode into it to get the same screen the raw `/phishing/*` route renders, with the
  active theme's real header/footer/branding around it. Purely presentational - every nonce/rate-
  limit/ownership check and every byte of form markup stays in `AuthBootstrap`, which already owns
  all of it for the raw-route path; this class only registers the tags and forwards each one's
  `$atts` into `AuthBootstrap::render_customer_shortcode()`. Wired into `Support\Plugin::boot()`.
  Ported from `alltimeuk/wp-reconnaissance`'s own class of the same name.

Themed customer portal 4/N - Settings > Portal Pages admin screen:

- New 5th Settings tab, gated on `Capabilities::MANAGE_SETTINGS` like the other settings-proper
  tabs: a `wp_dropdown_pages()` per `AuthBootstrap::SHORTCODE_ROUTES` entry, letting an admin map
  each customer-portal route to a themed WordPress Page built with its matching `[wpp_customer_*]`
  shortcode. Writes `wpp_customer_page_<route>` options - `CustomerPortalUrls::resolve_base()` (from
  slice 1) already reads these, so this is the mapping's first actual writer; before this slice
  every customer-portal link still resolved to its raw `/phishing/<route>/` route regardless, since
  no option was ever set. A non-blocking warning shows against a mapped page that doesn't actually
  contain the matching shortcode yet - most likely picked before the shortcode was added to it, or
  the wrong page entirely. Ported from `alltimeuk/wp-reconnaissance`'s own Settings > Portal Pages
  screen.

**Breaking:** the customer portal's raw URL routes moved from `/customer/*` to `/phishing/*` (e.g.
`/customer/login/` is now `/phishing/login/`) - a deliberate hard break with no redirect, matching
`alltimeuk/wp-reconnaissance`'s own `/customer/*` -> `/recon/*` rename (its 0.1.17 release). Two
products co-installed on the same site would otherwise both register a WordPress rewrite rule for
the identical `^customer/<slug>/?$` pattern - the rewrite table has no per-plugin namespacing, so
whichever plugin's `init` callback ran last silently won and made the other's customer portal
unreachable. Nothing else changed: the `wpp_customer_route` query var, `CustomerPageResult`,
`wpp_account_action` nonce/field name, capability/role names, and every class name stay exactly as
they are - none of those are URL path segments. `AuthBootstrap` now self-heals its rewrite rules on
every version change (`maybe_flush_rewrite_rules()`, ported from wp-reconnaissance's own method of
the same name), so an existing install picks up the new routes automatically on its next request
after upgrading rather than 404ing until an administrator manually re-saves Settings > Permalinks.
Any bookmarked, emailed, or externally-linked `/customer/*` URL will 404 after this update.

Companies Workspace 1/8 - shared admin UI infrastructure + tabbed Settings (Audit folded in):

- New `assets/admin/admin.{css,js}` (wp-phishing's first admin assets) - ports
  `alltimeuk/wp-reconnaissance`'s own `nav-tab-wrapper`/`data-tab`/`wpp-hidden` tab mechanism
  (server-rendered panels, client-side visibility toggle, `?tab=` deep-linking via
  `history.replaceState`), scoped per `.wpp-tab-container` so more than one tab bar can coexist on
  a page later. Enqueued on every wp-phishing screen via a new `admin_enqueue_scripts` hook.
- `render_notices()`/`redirect_with_notice()`/`post_field()` ported from
  `alltimeuk/wp-reconnaissance` - `AdminBootstrap`'s `redirect_to()` had no user-feedback mechanism
  at all until now.
- Settings is now tabbed (Mail Provider / Risk Weight Sets / Retention / Audit Log) instead of one
  long vertical page. Audit's standalone top-level menu item is removed - its content is now the
  Audit Log tab. The Settings submenu's own capability gate is now `VIEW_AUDIT_LOG` (the broader of
  the two the screen needs) with the three Settings-proper tabs individually re-checking
  `MANAGE_SETTINGS`, so a viewer holding only `VIEW_AUDIT_LOG` keeps the same access the old
  standalone Audit item gave them.

First of eight sequential slices building a Companies workspace (per-company tabbed Domains/
Groups/Recipients/Import/Suppressions/Mail-Integrations, admin and customer portal) - see PLAN.md.

Companies Workspace 2/8 - workspace scaffold + Companies table (admin):

- "Organisations" renamed to "Companies" in the UI only - the data/schema layer stays
  `Organisation`/`organisation_uuid` throughout, since that's the shared cross-product
  `Alltime\CustomerPlatform` contract.
- New `src/Workspace/{WorkspaceContext,CompanyWorkspaceRenderer}.php` - the rendering layer the
  admin and (later) customer-portal company views both call, one method per tab
  (`render_domains_tab()`, `render_groups_tab()`, `render_recipients_tab()`, `render_import_tab()`,
  `render_suppressions_tab()`, `render_mail_integrations_tab()`), each a placeholder until its own
  dedicated slice.
- Each Companies-table row now links into a per-company detail view
  (`?page=wp-phishing-organisations&action=view&organisation_uuid=X&tab=domains`), reusing
  `alltimeuk/wp-reconnaissance`'s own `?action=edit&id=` branching-inside-one-callback precedent.
  The tab bar here is real navigation (WordPress's native `nav-tab-wrapper`, no JS toggle) rather
  than Settings' render-every-panel-and-hide approach - a company's Recipients/Import/etc. tabs can
  each be data-heavy, so only the selected tab is ever rendered or queried for.

Companies Workspace 3/8 - Domains tab + domain-level suppression:

- New domain-level suppression (Section 55 extended): `wpp_suppressions` gains a nullable
  `domain_hash` column (`Data\Schema` version 11) alongside the existing `email_hash` - a row is
  either email-scoped or domain-scoped, never both. `SuppressionRepository::is_suppressed()` now
  also matches on domain, so suppressing `evilcorp.com` covers every recipient at that domain
  without a row per address. New `EmailNormaliser::domain_hash()` (hashes either a full email's
  domain portion or a bare domain string - the single source of truth both the suppression check
  and the new "suppress this domain" action use), `SuppressionRepository::create_domain_suppression()`,
  `SuppressionService::suppress_domain()`.
- New `RecipientRepository::find_domains_for_organisation()` (SQL `GROUP BY` on the domain portion
  of each recipient's email - recipients are stored with cleartext addresses, so this needs no new
  column), `find_by_domain_for_organisation()`, `count_by_domain_for_organisation()`.
- The Domains tab (`CompanyWorkspaceRenderer::render_domains_tab()`) is now real: recipients
  grouped by email domain, each group expandable to its own recipient list with a suppression-flag
  badge per row (or a one-click "Suppress" action if not yet suppressed), and a "Suppress domain"
  action per group. Two new admin actions, `workspace_suppress_recipient`/`workspace_suppress_domain`,
  return to the same workspace tab they were submitted from rather than the standalone Suppressions
  screen.
- Verified directly against a real MariaDB 10.11 instance (not just phpunit) - both the raw
  `CREATE TABLE` statement and the `is_suppressed()` matching query, following the same discipline
  that caught the v0.1.1 hotfix's reserved-word bug.

Companies Workspace 4/8 - Groups + Recipients tabs:

- Both tabs ported into `CompanyWorkspaceRenderer` from the old standalone Groups/Recipients
  screens, unchanged in behaviour: Groups lists name/type/member-count with delete + create-group
  forms; Recipients lists email/name/department/status with a running total. Recipients gains real
  prev/next pagination (the old standalone screen read `$_GET['paged']` but never rendered pager
  links, so page 2+ was unreachable).
- `create_group`/`delete_group` now return to the Companies workspace's Groups tab instead of the
  old standalone Groups screen - the workspace is the intended home for these actions going
  forward; the standalone screens themselves are removed in slice 6 once every tab has migrated.

Companies Workspace 5/8 - Recipient Import tab:

- Section 15's full upload -> parse -> column-mapping -> validate -> commit pipeline
  (`RecipientImportService`) gets its first wp-admin entry point - previously only the REST API
  (`Api\RecipientImportsController`) could ever start an import. Upload validation mirrors that
  REST endpoint exactly (`UPLOAD_ERR_OK`, a 20MB size cap, `is_uploaded_file()`).
- The Import tab lists every import for the company with its current status and row counts; each
  row's available action depends on that status - "Map columns" (expands an inline mapping form
  showing every detected column against a canonical-field dropdown, defaulting a column already
  named like a canonical field), "Validate"/"Continue validating", "Commit"/"Continue committing",
  and "Cancel" for anything not yet terminal.
- Validation and commit each run up to 10 batches (2,000 rows) inline per click - enough to finish
  most imports in one action; a larger import simply stays `Validating`/`Committing` and is either
  continued with another click or picked up by the existing background sweep
  (`RecipientImportService::run_sweep()`), which was already built but, until now, could only ever
  be reached by an import that started through the REST API.

Companies Workspace 6/8 - Suppressions + Mail Integrations tabs, old standalone screens removed:

- Both tabs ported into `CompanyWorkspaceRenderer`: Suppressions lists every suppression (scope
  column shows Domain or Email via `Suppression::is_domain_scoped()`) with an "Add suppression"
  form; Mail Integrations is a verbatim port of the old standalone screen. `create_suppression`/
  `initiate_mail_integration`/`verify_mail_integration`/`revoke_mail_integration` now return to the
  Companies workspace instead of the standalone screens they used to serve.
- The six now-redundant standalone top-level screens (Domains, Recipients, Groups, Recipient
  Imports, Suppressions, Mail Integrations) are removed - every one of them is now a tab under a
  company's own detail view in the Companies workspace. `sender-domains` stays a standalone
  screen (this plugin's own outbound-sending infrastructure, a distinct concept from a company's
  domains).
- While removing the old Domains screen, found it also carried an unrelated concept the workspace's
  own Domains tab (recipient-email-domain grouping, added in slice 3) didn't cover: a company's own
  verified sending/tracking/landing domains (`Alltime\CustomerPlatform`'s `OrganisationDomain`) and
  the operator-only "mark verified" override (Section 11). Restored as a "Sending domains" section
  at the top of the same Domains tab, with the override form gated to an admin `WorkspaceContext` so
  a customer can never mark their own domain verified without completing real DNS proof. Also fixed
  `handle_override_domain_verification()`'s redirect, which still pointed at the now-removed
  standalone Domains screen.

Companies Workspace 7/8 - customer-portal workspace:

- New `/customer/company/?organisation_uuid=X&tab=Y` route (`AuthBootstrap::handle_company()`)
  reuses every `CompanyWorkspaceRenderer` tab method the admin Companies workspace does, with a
  customer-side `WorkspaceContext` (`is_admin: false`). Read access is gated on
  `TenantGuard::can_access_organisation()` (any active membership, any role); each write action is
  independently gated on `TenantGuard::has_role(Owner, Administrator)` inside its own handler,
  matching the pattern the pre-existing `add_domain`/`start_verification` handlers already used.
- New customer-side equivalents of every admin workspace write action - `create_group`/
  `delete_group`, `create_suppression`/`workspace_suppress_recipient`/`workspace_suppress_domain`,
  `workspace_start_import`/`workspace_set_import_mapping`/`workspace_validate_import`/
  `workspace_commit_import`/`workspace_cancel_import`, `initiate_mail_integration`/
  `verify_mail_integration`/`revoke_mail_integration` - calling the same underlying services as
  their admin counterparts, sourced from `'customer_portal'` in the audit log rather than `'admin'`.
  Each returns an error message (or null on success) rather than redirecting, since this route
  always redisplays the same tab it was submitted from - no `redirect_with_notice()`-style PRG
  needed here.
- The Domains tab's "Sending domains" section (slice 6) now also carries the customer's own
  DNS-driven domain verification flow (add a domain, get a verification code, check now), ported
  from `/customer/account/`'s old inline per-organisation section - `render_sending_domains()`
  shows the operator-only override form for an admin context and this flow for a customer context,
  never both.
- `/customer/account/`'s per-organisation section is now a one-line link into the company
  workspace instead of inlining every organisation's domains on the account page itself - it was
  already unusable once a customer belonged to more than a couple of organisations, and everything
  it used to render inline now lives in the workspace.

Companies Workspace 8/8 - final cross-cutting pass:

- Full phpcs/phpstan/phpunit/`bin/check-versions.sh` across the complete 7-slice stack together
  pass clean. Manually cross-checked (not tool-catchable): `CompanyWorkspaceRenderer::TABS` matches
  both hosts' tab-dispatch `match()` exactly; no remaining reference anywhere to the six removed
  standalone admin screens; every remaining `wpp_org` selector usage belongs to one of the five
  screens still legitimately standalone; the tab-toggle JS is scoped so it cannot intercept the
  Companies workspace's genuine full-page tab navigation.
- **Not done**: this session has no local WordPress environment to click through either workspace,
  so live functional/UI verification of both hosts has not been performed and should happen before
  this initiative is considered ready to merge - flagged explicitly in PLAN.md section 10 rather
  than silently skipped.

This closes the 8-slice Companies Workspace initiative (PLAN.md section 10): "Organisations"
renamed to "Companies" in the UI, six top-level screens (Domains, Recipients, Groups, Recipient
Imports, Suppressions, Mail Integrations) consolidated into tabs under one per-company workspace, a
new domain-level suppression concept, and - per explicit user choice - the same workspace shared
between the admin and customer-portal hosts.

## 0.1.1 - 2026-09-08

Hotfix: v0.1.0's activation failed outright on real MySQL 8.0+/MariaDB 10.2+ - the very first
real-world install (this plugin's schema had never been run against genuine MySQL before; the
project's own integration test harness runs against a SQLite shim, not MySQL, so this was
invisible until now):

- `wpp_recipient_import_rows`' `row_number` column is renamed to `row_index`. `ROW_NUMBER` became
  a reserved word once MySQL 8.0/MariaDB 10.2 added window functions, and dbDelta does not
  reliably support backtick-quoted column names, so an unquoted `row_number` column failed the
  `CREATE TABLE` statement outright with a syntax error, which stopped schema installation at
  version 2 and left every later table (versions 3-10) never created. No existing installs are
  affected by the rename itself - the table was never successfully created anywhere prior to this
  fix, so there is no data to migrate.
- Verified directly against real MariaDB 10.11 (not just the project's own SQLite-backed
  integration tests): every one of this plugin's 41 tables, across all 10 `Data\Schema` versions
  and all 4 `Alltime\CustomerPlatform\Schema` versions, now creates cleanly from a fresh database.

## 0.1.0 - 2026-09-06

Phase 6.6 (Commercial & integration, per PLAN.md) - AntiAbuse: rate limiting and Cloudflare
Turnstile (Section 57/58), the last of the six Phase 6 sub-phases. Ports WP-Questionnaires'
`wpq_rate_limits`/`WPQ_Turnstile` mechanisms near-verbatim, fixing two gaps found in that
implementation rather than reproducing them:

- New `AntiAbuse\RateLimiter`/`Repositories\RateLimitRepository` backed by a new `wpp_rate_limits`
  table (schema version 10): a single collapsed, HMAC-hashed `bucket_key` per (endpoint,
  dimensions) combination, enforced `UNIQUE`, with one atomic `INSERT ... ON DUPLICATE KEY UPDATE`
  per check. IP and email are HMAC'd with `wp_salt('auth')` before storage, never raw.
- **Fixed a gap in WP-Questionnaires' own implementation**: a second dimension is now actually
  populated - `Auth\RateLimiter`'s register/login/forgot-password calls pass the submitted email
  address alongside the client IP, rather than degrading to IP+endpoint only.
- **Fixed another gap**: a new hourly `AntiAbuseBootstrap` cron sweep deletes expired rate-limit
  buckets, which WP-Questionnaires' own table never had.
- New `AntiAbuse\Turnstile`, ported near-verbatim from `WPQ_Turnstile` - fails open on
  unconfigured/unreachable/erroring/unparsable responses, fails closed only on an empty token or an
  explicit `success:false`. Wired into registration and forgot-password only (not login, per
  Section 58). New `Secrets::turnstile_site_key()`/`turnstile_secret_key()`.

Phase 6.5 (Commercial & integration, per PLAN.md) - emergency controls (Section 71's six actions,
all audited), directly reusing existing infrastructure rather than inventing parallel mechanisms:

- New global send-pause and tracking-disable flags (`Emergency\EmergencyControls`), checked at the
  single respective entry points in `DeliveryQueueService::process_batch()` and
  `TrackingService::record_event()`.
- "Pause all campaigns" also flips every running campaign to a new `Paused` status for visibility;
  "cancel unsent deliveries", "disable sender domain", "suspend organisation" and "suppress
  recipient" reuse existing services directly.
- **Fixed a pre-existing gap**: `CampaignService::cancel()` never actually cancelled the campaign's
  own unsent deliveries, contradicting Section 72's own requirement - `DeliveryRepository::mark_cancelled()`
  had been unwired dead code since Phase 3. Fixed via a new polymorphic-source-object query rather
  than a campaign-specific one.
- New `Capabilities::MANAGE_EMERGENCY_CONTROLS` (operator-only) and a WP-admin Emergency Controls
  screen.

Phase 6.4 (Commercial & integration, per PLAN.md) - privacy requests and retention. Both wire up
pieces that already existed since earlier phases with zero callers: `atcp_privacy_requests` (a
table with no repository since schema version 2) and
`CustomerPlatform\RetentionSweeper::purge_old_interactions()`/`AuditLogger::purge_older_than()`
(working methods nothing ever invoked):

- New `CustomerPlatform\PrivacyRequestService` logs and fulfils discovery/export/anonymisation/
  deletion/suppression requests (§53), admin-initiated only. Deletion is implemented as
  anonymisation (PII overwritten, every contact identity removed outright), not a cascading
  cross-table delete.
- New daily retention sweep, scoped to audit logs and cross-tool interaction history for this
  release (2 of §54's 8 named categories) - configurable per-category in Settings, defaulting to
  "keep forever" until an administrator opts in.
- New WP-admin Privacy Requests screen (log/view export/fulfil/reject).

Phase 6.3 (Commercial & integration, per PLAN.md) - HaloPSA pull/ack (Data\Schema version 9),
scoped to campaigns and their aggregate statistics for this increment:

- New `Api\HaloController` (`wpp/v1/halo/campaigns/...`) ports WP-Questionnaires' pull/acknowledge
  REST lifecycle (pending/detail/start/acknowledge/fail) near-verbatim, including its WordPress
  Application Passwords + HTTP Basic auth convention and sync-state-columns-on-the-primary-table
  pattern (`halo_sync_status` and friends, added to `wpp_campaigns`).
- New `Capabilities::HALO_API`, deliberately excluded from the operator role's auto-grant list -
  matches WP-Questionnaires' own convention of keeping this capability off ordinary admins,
  granted only to the pre-existing `wpp_integration` role.
- The campaign detail response is always aggregate-only, computed fresh regardless of any report's
  own visibility setting - named-recipient data never reaches this external-facing route.

Phase 6.2 (Commercial & integration, per PLAN.md) - commercial models and campaign integration
(Data\Schema version 8):

- New `wpp_commercial_models`/`wpp_organisation_commercial_models` tables (§46-48): reusable
  charging-basis templates (all 8 bases from §47), assigned to an organisation via a mapping
  table rather than a column on the shared Organisation contract. Deliberately never calculates
  an actual charge - only records and assigns (§51: no Halo invoice-generation logic here).
- Campaign approval now gates on the organisation holding a valid entitlement (§21); campaign
  completion now records usage facts and consumes the covering entitlement, via a new
  `wpp_campaign_completed` action other listeners can also subscribe to.

Phase 6.1 (Commercial & integration, per PLAN.md) - the shared Usage and Entitlement contracts:

- Usage ledger (§49) and Entitlements (§50) elevated into the shared `Alltime\CustomerPlatform`
  layer as discovered services (`UsagePlatformDiscovery`/`EntitlementPlatformDiscovery`), the same
  pattern already established for Organisation - both are explicitly declared "a shared logical
  resource" by the requirements spec. New `atcp_usage_events` (append-only usage facts) and
  `atcp_entitlements` tables, `Alltime\CustomerPlatform\Schema` version 4.
- Entitlements are keyed by organisation + product (not contact + tool + domain, unlike
  wp-reconnaissance's simpler one-shot model), with `allowance_quantity`/`consumed_quantity`
  supporting a real capacity pool drawn down over multiple campaigns (`partially_consumed`).
  `EntitlementPolicy` is pure decision logic with no I/O, fully unit-tested without a database -
  the same split wp-reconnaissance's own entitlement service uses.
- New WP-admin Entitlements screen (list/grant/revoke per organisation).

Phase 5 findings remediation - fixes from a multi-angle code review of the Phase 5 diff
(`findings.md`):

- Fixed a cross-tenant PDF download-token issuance gap in the WP-Admin reports screen (a missing
  tenant-role check every sibling handler already had).
- Consolidated named-results visibility policy into one class (`Reports\Support\ReportVisibilityPolicy`),
  closing a gap where the WP-Admin HTML report view had no re-check at all, and fixing the Reports
  REST API being unreachable by any customer account regardless of organisation role.
- PDFs containing named-recipient data are no longer cached (the anonymous public download route
  has no per-request identity to re-check access against); aggregate-only PDFs are now pre-rendered
  at generation time instead of on first download.
- Every targeted recipient now appears under full named-results visibility, including one never
  delivered (marked "Not delivered"), matching that visibility level's documented guarantee.
- Download tokens are claimed atomically (fixing a use-limit race) and a use is no longer recorded
  until the PDF has actually been produced (fixing a transient-failure burning a single-use token).
- `RiskWeightSetRepository::create()`'s default-clearing is now transactional; a default-weight-set
  seeding failure during migration is caught and logged instead of fataling every page load.
- Fixed an N+1 query pattern in campaign result computation via two new batched repository methods.
- Added `Support\Dates::from_mysql()` for explicit-UTC datetime parsing (WPCS forbids
  `date_default_timezone_set()`), applied to the Reports/Results/Delivery/Tracking entities this
  batch touches; risk weights are now clamped to a sane range before being frozen into an immutable
  weight set; a `max_uses = 0` download token no longer misreads as unlimited.

Multi-provider delivery modes (ahead of Phase 6, per PLAN.md) - a customer-facing choice between
API-send (existing) and direct mailbox injection into the customer's own M365/Google Workspace
tenant, addressing a real gap where a customer's own mail security correctly quarantining a
simulation before an employee ever sees it defeats the test:

- `Sending\SenderDomain` gains a `delivery_mode` column (Data\Schema version 7): `api_send`
  (default, unchanged) or `mailbox_injection`, which requires an `organisation_uuid` and is backed
  by a customer tenant integration rather than DNS-authenticated transport.
- Two new providers behind the existing `MailProviderInterface`: `GraphMailboxWriteProvider`
  (create-then-move-to-Inbox via Microsoft Graph, bypassing Exchange Online Protection/mail flow)
  and `GmailMailboxInsertProvider` (`users.messages.insert`, per Google's own docs "bypasses most
  scanning and classification"). Both require the customer's own tenant admin to consent -
  Alltime writes into the customer's tenant, never sends from it.
- `wpp_organisation_mail_integrations` (new table, unique per organisation/provider/capability)
  tracks per-customer consent state; `MailManager::resolve()` is now organisation-aware so it can
  construct an injection provider with the calling organisation's own tenant/credential context.
  `SenderHealthService` branches on `delivery_mode`, substituting "does the org hold an active
  matching integration" for the SPF/DKIM/DMARC/MX checks that don't apply to a mode with no real
  transport to authenticate.
- Two separate Entra app registrations for Microsoft (`Mail.ReadWrite` only; directory-sync scopes
  only), since a single app's admin-consent grant is all-or-nothing; one Google service account
  suffices, since Workspace domain-wide delegation is independently curatable per scope from a
  single client ID. `Verification\Support\MxProviderClassifier` gates which consent option a
  customer is offered by their own domain's MX records.
- Injected mail carries honest, self-disclosing simulation headers (`Support\SimulationHeaders`) -
  a genuine `Authentication-Results` reflecting no real check occurred, plus `X-WPP-Simulation` -
  visible in raw source/"View Original" for a security-aware reviewer, never forged-plausible.
- Every delivery, regardless of provider, now includes an unsubscribe path: a new
  `SuppressionReason::RecipientOptOut` case and a `/tracking/unsubscribe/{token}` route (GET
  confirms, POST suppresses, mirroring the existing click-tracking scanner-avoidance pattern);
  `CampaignActivationService` auto-appends the unsubscribe footer to every rendered delivery.

Phase 5 (results & reporting, per PLAN.md), scoped to aggregate reporting, named reporting with
access controls, and PDF reporting - longitudinal reporting and repeat-risk analysis remain
Phase 2:

- Risk scoring and results (`wpp_risk_weight_sets`, Data\Schema version 6, Section 37-39/43):
  results are computed on demand from delivery status and tracking events rather than stored
  denormalised, so evidence and score can never drift apart. Risk weight sets are named,
  immutable, versioned configurations (a default seeds automatically from the spec's own example
  weighting); cohort breakdown covers department/team/location; a simple threshold-based
  recommendation engine reads the same aggregates.
- Campaign reports (`wpp_reports`/`wpp_download_tokens`, Section 44/59/62/63): a formal report
  covering all 13 minimum sections (executive summary through limitations), generated as a frozen,
  regenerable-but-never-edited artefact, exportable as HTML, PDF (via Dompdf) or JSON from one
  stored structure. PDFs are cached in fail-closed protected storage (an uploads subdirectory
  behind both `.htaccess` and a blank `index.php`, re-verified on every access) and served only
  through hashed, expiring, use-limited, revocable download tokens via a new public
  `/reports/download/{token}` route.
- Named-result visibility (aggregate-only / named / restricted-named) is chosen when a report is
  generated and re-enforced against the current viewer's role every time that report is viewed
  afterwards - a role change or disabled feature flag hides named results from a report that
  already has them, without needing to regenerate it.
- WP-admin: a real Reports screen (generate, view, issue PDF download links) and risk-weight-set
  management under Settings - every screen the spec's admin menu structure names is now
  functional.

Phase 4 (campaigns & delivery, per PLAN.md), scoped to single-wave/scheduled campaigns only -
multi-wave, randomised windows, recurring schedules and scanner classification remain Phase 2:

- Versioned templates and landing pages (`wpp_templates`/`wpp_template_versions`,
  `wpp_landing_pages`/`wpp_landing_page_versions`, Data\Schema version 5, Section 28/29/30/31):
  editing creates a new immutable version rather than mutating one already locked into a campaign
  wave. A whitelisted `{{variable}}` renderer (no PHP execution) covers every documented
  template variable. Landing pages support click-only, behavioural-continuation and credential-
  simulation modes; educational content is shown after any mode's interaction, not a separate
  mode.
- Campaigns (`wpp_campaigns`/`wpp_campaign_waves`/`wpp_campaign_wave_recipients`/
  `wpp_campaign_approvals`, Section 18-21): full approval workflow (customer self-approval,
  Alltime-required, dual, managed-service-only), auto-scheduling once approval requirements are
  met, a 5-minute cron sweep that activates due campaigns and detects completion, and
  cancellation that marks unsent deliveries cancelled while preserving delivered evidence
  (Section 72). Wave activation freezes the recipient cohort and metadata snapshot (Section
  16/20) before rendering and enqueueing each delivery through Phase 3's queue.
- Tracking (`wpp_tracking_tokens`/`wpp_tracking_events`, Section 32-36): opaque 256-bit tokens
  (hash-only persisted), public `/tracking/open/{token}`, `/tracking/click/{token}` and
  `/simulation/{token}` routes, and append-only events. The credential-simulation submission
  handler never reads `$_POST` - only that a submission was attempted is recorded (Section
  31.3). The delivery queue now also records a `message_accepted` event (Section 36).
- WP-admin: real Campaigns, Templates and Landing Pages screens, replacing three more "coming
  soon" placeholders.

Phase 3 (sending infrastructure, per PLAN.md):

- Sender domains and identities (`wpp_sender_domains`, `wpp_sender_identities`, Data\Schema
  version 4, Section 22): domains may be shared-pool or organisation-dedicated; identities are
  scoped to a domain. `SenderHealthService` runs DNS-based health checks (SPF, DMARC, mail
  routing/MX) - DKIM is reported `Unknown` rather than pass/fail since no selector is tracked yet.
- Three-provider mail abstraction (`Integrations\Mail`, Section 25), each provider built against
  real request/response shapes with no AWS/Google/Microsoft SDK dependency: Amazon SES v2
  `SendEmail`, signed with a from-scratch pure-PHP AWS Signature V4 implementation
  (`Support\AwsSignatureV4`); Microsoft Graph `sendMail` via an Entra app registration's
  client-credentials OAuth2 flow (`Mail.Send` application permission, cached access token); Gmail
  `users.messages.send` via a stored OAuth2 refresh token and a hand-built, base64url-encoded raw
  RFC 2822 message. `MailManager` resolves the active provider from a per-sender-domain override
  or a site-wide administrator preference, never a silent default. All three accept an injectable
  HTTP transport for testing instead of making live calls.
- Durable, idempotent delivery queue (`wpp_deliveries`, `Delivery\DeliveryQueueService`, Section
  26): enqueue is idempotent by key; a WP-Cron worker claims a batch atomically (a `claim_token`
  stamped in one `UPDATE ... LIMIT`, then read back) so concurrent workers never double-process a
  row; sends re-check suppression at send time, enforce `SenderHealthService`'s fail-closed
  preflight, and retry transient failures with exponential backoff up to a fixed ceiling.
  Deliveries reference their source via a polymorphic `source_object_type`/`source_object_uuid`
  pair so Phase 4's Campaign engine can populate them later without this phase needing to know
  what a campaign is.
- WP-admin: real "Sender Domains" (create, health-check, retire, manage identities) and "Queue"
  (recent deliveries) screens, plus a mail-provider preference selector on Settings.

Customer portal + admin UI (circling back to Phase 1's deferred scope, per PLAN.md):

- Customer-facing `/customer/*` routes (`Auth\AuthBootstrap`): self-service registration (email
  verification required before login), login/logout, forgot/reset password, and an account
  dashboard covering Section 1's core journey end-to-end - create/select an organisation,
  add and DNS-verify a domain, accept a pending invitation. Deliberately open self-service
  registration (per explicit decision), with low-cost protections that don't require the full
  Phase 6 AntiAbuse module: a transient-based per-IP rate limiter, a honeypot + minimum-fill-time
  check, and hashed single-use tokens for email verification/password reset.
- WP-admin "Phishing" menu (`Admin\AdminBootstrap`, Section 67): real screens for organisations,
  domains (including audited administrator override), recipients, groups, recipient imports,
  suppressions, audit log, and settings; placeholder "coming soon" screens for the modules the
  spec's menu structure names but later phases haven't built yet (campaigns, templates, sender
  domains, reports, queue).
- REST namespace `wpp/v1` in place since the previous entry; no further change here.

Phase 2 (recipients, per PLAN.md):

- Recipient data model (`wpp_recipients`, contact_uuid nullable per Section 14), static
  recipient groups (`wpp_recipient_groups`/`wpp_recipient_group_members`, Section 17), and
  suppression (`wpp_suppressions`, Section 55 - multiple independent reasons per address,
  survives re-import).
- Full async recipient-import pipeline (Section 15): CSV and XLSX upload, column mapping
  (`Recipients\Support\ColumnMapper`, canonical fields + custom metadata), bounded-batch
  validation (invalid-address detection, within-file duplicate detection, suppression checks)
  and commit, each resumable via `RecipientsBootstrap`'s 5-minute cron sweep - "large imports
  shall run asynchronously" without a new job-queue dependency.
- REST API: `RecipientsController`, `RecipientGroupsController`, `RecipientImportsController`,
  `SuppressionsController` - all `TenantGuard`-gated, UUID-addressed.
- New dependency: `phpoffice/phpspreadsheet` (XLSX reading), plus `ext-zip`/`ext-fileinfo`/
  `ext-gd` declared as real requirements it needs.
- REST namespace corrected from `wp-phishing/v1` to `wpp/v1`, matching this plugin's own
  abbreviation used everywhere else (`WPP_VERSION`, `wpp_*` tables/capabilities).

Phase 1 (tenancy & identity, partial - see PLAN.md):

- DNS TXT domain-ownership verification (`Verification\DomainVerificationService` +
  `VerificationBootstrap`), per Section 11: challenge generation, DNS TXT matching, a 30-minute
  background sweep, and audited administrator override.
- `Support\TenantGuard`: resolves organisation access from the authenticated identity's active
  organisation membership (Section 65) - never trusted from request parameters.
- REST API (`wpp/v1`): organisations (self-service create, list mine, get one) and
  organisation domains (add, list, start/check/override DNS verification), all permission-gated
  through `TenantGuard`.
- `OrganisationServiceInterface::get_domain()` and `record_domain_verification()`'s
  `$requested_by` parameter added to the shared Organisation contract.

Initial scaffold (Phase 0 of PLAN.md):

- Plugin bootstrap, activation/deactivation, self-hosted updater.
- Database schema/migration framework (`wpp_audit_log`).
- Secrets resolution (constant → environment → option), feature flags, capabilities and roles.
- Shared `Alltime\CustomerPlatform` layer copied from `alltimeuk/wp-reconnaissance` (contacts,
  consent, interactions, visitor context).
- New shared Organisation contract (`OrganisationServiceInterface` +
  `OrganisationPlatformDiscovery`) added to `Alltime\CustomerPlatform`: organisations,
  membership and domains, per the design specification's Sections 8/9/10/80.
