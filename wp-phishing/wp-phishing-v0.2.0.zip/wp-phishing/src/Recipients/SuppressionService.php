<?php
/**
 * Suppression service, per Section 55.
 *
 * Suppression overrides campaign targeting - every other module that resolves a delivery
 * audience must consult {@see is_suppressed()} before including a recipient. A suppressed
 * recipient is never reintroduced simply because a later import contains them (Section 55) -
 * {@see \Alltime\WPPhishing\Recipients\Repositories\RecipientRepository::update_fields()} never
 * touches status, and the import pipeline checks suppression on every row regardless of whether
 * the recipient already exists.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients;

use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\Repositories\SuppressionRepository;
use Alltime\WPPhishing\Support\AuditLogger;

final class SuppressionService {

	public function __construct(
		private readonly SuppressionRepository $suppressions = new SuppressionRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	public function is_suppressed( string $organisation_uuid, string $email ): bool {
		return $this->suppressions->is_suppressed( $organisation_uuid, $email );
	}

	public function suppress(
		string $organisation_uuid,
		string $email,
		SuppressionReason $reason,
		string $source,
		?string $note = null,
		?int $created_by = null,
		?\DateTimeImmutable $expires_at = null
	): Suppression {
		$suppression = $this->suppressions->create( $organisation_uuid, $email, $reason, $source, $note, $created_by, $expires_at );

		$this->audit_logger->log(
			'suppression.created',
			'suppression',
			$suppression->suppression_uuid,
			$created_by,
			summary: $reason->value,
			source: $source,
			organisation_uuid: $organisation_uuid
		);

		return $suppression;
	}

	public function suppress_domain(
		string $organisation_uuid,
		string $domain,
		SuppressionReason $reason,
		string $source,
		?string $note = null,
		?int $created_by = null,
		?\DateTimeImmutable $expires_at = null
	): Suppression {
		$suppression = $this->suppressions->create_domain_suppression( $organisation_uuid, $domain, $reason, $source, $note, $created_by, $expires_at );

		$this->audit_logger->log(
			'suppression.domain_created',
			'suppression',
			$suppression->suppression_uuid,
			$created_by,
			summary: $reason->value,
			source: $source,
			organisation_uuid: $organisation_uuid
		);

		return $suppression;
	}

	/**
	 * @return Suppression[]
	 */
	public function list_for_organisation( string $organisation_uuid, int $per_page = 20, int $page = 1 ): array {
		return $this->suppressions->find_all_for_organisation( $organisation_uuid, $per_page, $page );
	}
}
