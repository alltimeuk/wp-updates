<?php
/**
 * Single source of truth for email normalisation/hashing across the Recipients module -
 * recipient creation, suppression checks, and import validation all need the *identical*
 * normalisation, since a mismatch here would let a suppressed address slip back in under a
 * differently-cased or padded form.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Recipients\Support;

final class EmailNormaliser {

	public static function normalise( string $email ): string {
		return strtolower( trim( $email ) );
	}

	public static function hash( string $email ): string {
		return hash( 'sha256', self::normalise( $email ) );
	}

	/**
	 * Hash of the domain portion only - accepts either a full email address (the domain after the
	 * last "@" is used) or a bare domain string (used as-is), so the same method both hashes a
	 * candidate recipient's email for a suppression-check and hashes an operator-entered domain
	 * when creating a domain-level suppression. Domain suppression cannot reuse hash() - hashing
	 * the full address destroys the ability to match every address sharing one domain.
	 */
	public static function domain_hash( string $email_or_domain ): string {
		$normalised  = self::normalise( $email_or_domain );
		$at_position = strrpos( $normalised, '@' );
		$domain      = false !== $at_position ? substr( $normalised, $at_position + 1 ) : $normalised;

		return hash( 'sha256', $domain );
	}

	public static function is_valid( string $email ): bool {
		return false !== filter_var( self::normalise( $email ), FILTER_VALIDATE_EMAIL );
	}
}
