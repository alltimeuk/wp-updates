<?php
/**
 * Incremental, idempotent schema migrations driven by `dbDelta()`.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Data;

use Alltime\WPPhishing\Data\Enums\MigrationFailureClassification;
use Alltime\WPPhishing\Support\AuditLogger;

use const Alltime\WPPhishing\WPP_SCHEMA_VERSION;

/**
 * Installs and upgrades the plugin's database schema.
 *
 * Each schema version is a self-contained, additive step. Steps never drop columns or tables;
 * destructive changes belong to an explicit, separately reviewed later migration.
 */
final class Migrator {

	private const SCHEMA_VERSION_OPTION = 'wpp_db_schema_version';

	/**
	 * Absence means healthy. Present only while a version step has failed; cleared the moment a
	 * later boot's retry reaches WPP_SCHEMA_VERSION. Never contains $wpdb->last_error's raw text -
	 * only a safe MigrationFailureClassification value - see record_failure().
	 */
	private const FAILURE_OPTION = 'wpp_migration_failure';

	/**
	 * Runs on activation. Applies every migration step up to the current schema version.
	 */
	public static function install(): void {
		self::maybe_upgrade();
	}

	/**
	 * Runs on every boot; a no-op unless the stored schema version is behind the current one,
	 * which covers plugin upgrades without a re-activation step.
	 */
	public static function maybe_upgrade(): void {
		global $wpdb;

		$current = (int) get_option( self::SCHEMA_VERSION_OPTION, 0 );

		if ( $current >= WPP_SCHEMA_VERSION ) {
			self::maybe_clear_failure_state();
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		for ( $version = $current + 1; $version <= WPP_SCHEMA_VERSION; $version++ ) {
			$method = "apply_version_{$version}";

			if ( method_exists( self::class, $method ) && ! self::$method() ) {
				// Captured before anything else touches $wpdb (including get_option() below, which
				// resets last_error on its own success) - stop here rather than advancing past a
				// step that didn't actually complete. This version (and anything after it) is
				// retried on the next boot once the underlying issue is fixed - the loop never runs
				// update_option() for it.
				self::record_failure( $version, $current, (string) $wpdb->last_error );
				add_action( 'admin_notices', array( self::class, 'render_admin_notice' ) );
				return;
			}

			update_option( self::SCHEMA_VERSION_OPTION, $version, true );
		}

		self::maybe_clear_failure_state();
	}

	/**
	 * Always records the attempt (refreshing last_seen_at/occurrences, cheap and idempotent), but
	 * only writes a new wpp_audit_log row when the failing target version is new - a still-broken
	 * site retries on every boot, and logging identically on every one of those would grow the
	 * audit log without bound for a single ongoing problem.
	 */
	private static function record_failure( int $target_version, int $current_version, string $raw_error ): void {
		$classification = MigrationFailureClassification::classify_from_error( $raw_error );
		$now            = current_time( 'mysql', true );
		$existing       = get_option( self::FAILURE_OPTION, null );
		$is_new_failure = ! is_array( $existing ) || ( $existing['target_version'] ?? null ) !== $target_version;

		update_option(
			self::FAILURE_OPTION,
			array(
				'target_version'  => $target_version,
				'current_version' => $current_version,
				'classification'  => $classification->value,
				'first_seen_at'   => $is_new_failure ? $now : ( $existing['first_seen_at'] ?? $now ),
				'last_seen_at'    => $now,
				'occurrences'     => $is_new_failure ? 1 : ( (int) ( $existing['occurrences'] ?? 0 ) + 1 ),
			),
			true
		);

		if ( $is_new_failure ) {
			( new AuditLogger() )->log(
				'migration.upgrade_failed',
				'schema',
				null,
				null,
				outcome: 'failure',
				summary: sprintf( 'Schema upgrade to version %d failed (%s).', $target_version, $classification->value )
			);
		}
	}

	/**
	 * Called from both of maybe_upgrade()'s "the schema is current" exits - the early return for an
	 * already-current install, and falling through the loop after every step succeeds. A normal
	 * install where get_option() returns null here is the common case and does nothing.
	 */
	private static function maybe_clear_failure_state(): void {
		if ( ! is_array( get_option( self::FAILURE_OPTION, null ) ) ) {
			return;
		}

		delete_option( self::FAILURE_OPTION );

		( new AuditLogger() )->log(
			'migration.recovered',
			'schema',
			null,
			null,
			summary: sprintf( 'Schema upgrade recovered; stored version is now %d.', WPP_SCHEMA_VERSION )
		);
	}

	/**
	 * Registered on admin_notices only while a failure is on record (see maybe_upgrade()) - never
	 * shows the underlying error, only that something needs attention.
	 */
	public static function render_admin_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			esc_html__( 'WP-Phishing\'s database schema failed to upgrade; some functionality may not work correctly until this is resolved. It will keep retrying automatically.', 'wp-phishing' )
		);
	}

	/**
	 * Runs each statement through dbDelta(), stopping at (and reporting) the first one whose own
	 * SQL failed. dbDelta() never throws on a failing statement, so `$wpdb->last_error` - reset
	 * immediately before each individual statement, not once for the whole batch - is the only
	 * signal available.
	 *
	 * @param string[] $statements
	 */
	private static function run_statements( array $statements ): bool {
		global $wpdb;

		foreach ( $statements as $statement ) {
			$wpdb->last_error = '';

			dbDelta( $statement );

			if ( '' !== $wpdb->last_error ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Removes plugin tables and options. Only invoked from uninstall.php after an explicit
	 * administrator opt-in via the "wpp_remove_data_on_uninstall" option.
	 */
	public static function uninstall(): void {
		global $wpdb;

		$drop_order = array( 'rate_limits', 'organisation_commercial_models', 'commercial_models', 'organisation_mail_integrations', 'download_tokens', 'reports', 'risk_weight_sets', 'tracking_events', 'tracking_tokens', 'campaign_approvals', 'campaign_wave_recipients', 'campaign_waves', 'campaigns', 'landing_page_versions', 'landing_pages', 'template_versions', 'templates', 'deliveries', 'sender_identities', 'sender_domains', 'auth_tokens', 'suppressions', 'recipient_import_rows', 'recipient_imports', 'recipient_group_members', 'recipient_groups', 'recipients', 'audit_log' );

		foreach ( $drop_order as $key ) {
			$table = Schema::table( $key );
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier (Schema::table()), never user input.
		}

		delete_option( self::SCHEMA_VERSION_OPTION );
		delete_option( self::FAILURE_OPTION );
		delete_option( 'wpp_local_adapter_enabled' );
		delete_option( 'wpp_remove_data_on_uninstall' );

		// Mail-provider credentials (Section 25) - secrets must not survive uninstall.
		delete_option( 'wpp_mail_provider' );
		delete_option( 'wpp_ses_region' );
		delete_option( 'wpp_ses_access_key_id' );
		delete_option( 'wpp_ses_secret_access_key' );
		delete_option( 'wpp_ses_sender_address' );
		delete_option( 'wpp_graph_tenant_id' );
		delete_option( 'wpp_graph_client_id' );
		delete_option( 'wpp_graph_client_secret' );
		delete_option( 'wpp_graph_sender_address' );
		delete_option( 'wpp_gmail_oauth_client_id' );
		delete_option( 'wpp_gmail_oauth_client_secret' );
		delete_option( 'wpp_gmail_sender_address' );
		delete_option( 'wpp_gmail_refresh_token' );
		delete_option( 'wpp_halo_api_key' );
		delete_option( 'wpp_halo_client_secret' );
		delete_option( 'wpp_turnstile_site_key' );
		delete_option( 'wpp_turnstile_secret_key' );
	}

	/**
	 * Schema version 1: the audit log (Section 61).
	 */
	private static function apply_version_1(): bool {
		return self::run_statements( Schema::version_1_statements() );
	}

	/**
	 * Schema version 2: the Recipients module (Section 13-17/55).
	 */
	private static function apply_version_2(): bool {
		return self::run_statements( Schema::version_2_statements() );
	}

	/**
	 * Schema version 3: customer-portal auth tokens (Section 12).
	 */
	private static function apply_version_3(): bool {
		return self::run_statements( Schema::version_3_statements() );
	}

	/**
	 * Schema version 4: the sending infrastructure (Section 22-26).
	 */
	private static function apply_version_4(): bool {
		return self::run_statements( Schema::version_4_statements() );
	}

	/**
	 * Schema version 5: campaigns and delivery (Section 18-21/28-36).
	 */
	private static function apply_version_5(): bool {
		return self::run_statements( Schema::version_5_statements() );
	}

	/**
	 * Schema version 6: results, risk scoring and reporting (Section 37-45/59/62-63). Also seeds
	 * the default risk weight set (Section 38's own example weighting) so report generation works
	 * on a fresh install without a separate manual setup step.
	 */
	private static function apply_version_6(): bool {
		if ( ! self::run_statements( Schema::version_6_statements() ) ) {
			return false;
		}

		// Every other apply_version_N() only ever returns bool, letting a failure flow through
		// run_statements()'s existing graceful retry/admin-notice path. Seeding the default weight
		// set can throw (RiskWeightSetRepository::create()'s json-encode/transaction guards) - that
		// must never propagate out of Plugin::boot() and fatal every page load; an administrator
		// can always create a risk weight set manually, but a schema version left unbumped by an
		// uncaught exception here cannot easily be recovered from.
		try {
			\Alltime\WPPhishing\Results\Support\DefaultRiskWeights::ensure_seeded();
		} catch ( \RuntimeException $exception ) {
			error_log( 'wp-phishing: failed to seed the default risk weight set: ' . $exception->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- this runs during migration, before any admin-notice/audit-log infrastructure can be relied on; a site-wide fatal is the alternative.
		}

		return true;
	}

	/**
	 * Schema version 7: mailbox-injection delivery mode alongside API-send (PLAN.md's
	 * "Multi-provider delivery modes" addition).
	 */
	private static function apply_version_7(): bool {
		return self::run_statements( Schema::version_7_statements() );
	}

	/**
	 * Schema version 8: commercial models (Section 46-48, Phase 6.2).
	 */
	private static function apply_version_8(): bool {
		return self::run_statements( Schema::version_8_statements() );
	}

	/**
	 * Schema version 9: HaloPSA pull/ack sync state on wpp_campaigns (Section 51, Phase 6.3).
	 */
	private static function apply_version_9(): bool {
		return self::run_statements( Schema::version_9_statements() );
	}

	/**
	 * Schema version 10: rate limiting (Section 57, Phase 6.6).
	 */
	private static function apply_version_10(): bool {
		return self::run_statements( Schema::version_10_statements() );
	}

	/**
	 * Schema version 11: domain-level suppression (Companies Workspace, PLAN.md section 10).
	 */
	private static function apply_version_11(): bool {
		return self::run_statements( Schema::version_11_statements() );
	}
}
