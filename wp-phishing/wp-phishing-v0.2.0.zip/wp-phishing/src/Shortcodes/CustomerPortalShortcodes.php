<?php
/**
 * `[wpp_customer_*]`: themed-page-compatible equivalents of the customer portal's raw
 * `/phishing/*` routes, so a site can embed the same register/login/account/company screens
 * inside ordinary WordPress Pages - real navigation, theme header/footer, styling - instead of
 * only reaching them via the plugin's own unthemed routes. Both mechanisms work permanently side
 * by side; this class adds the shortcode side without changing anything about the raw routes.
 * Ported from `alltimeuk/wp-reconnaissance`'s own class of the same name.
 *
 * Purely presentational: every actual nonce/rate-limit/ownership check and every byte of form
 * markup lives in {@see \Alltime\WPPhishing\Auth\AuthBootstrap}, which already owns all of it for
 * the raw-route path. This class only registers the shortcode tags and forwards each one's
 * `$atts` into {@see \Alltime\WPPhishing\Auth\AuthBootstrap::render_customer_shortcode()}, without
 * duplicating or fragmenting any security-sensitive logic out of `AuthBootstrap`.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Shortcodes;

use Alltime\WPPhishing\Auth\AuthBootstrap;

final class CustomerPortalShortcodes {

	/**
	 * Shortcode tag => the AuthBootstrap route slug it renders. One per
	 * {@see AuthBootstrap::SHORTCODE_ROUTES} entry - `logout` deliberately has none, see that
	 * constant's own docblock.
	 *
	 * @var array<string,string>
	 */
	private const ROUTES_BY_TAG = array(
		'wpp_customer_register'        => 'register',
		'wpp_customer_verify_email'    => 'verify-email',
		'wpp_customer_login'           => 'login',
		'wpp_customer_forgot_password' => 'forgot-password',
		'wpp_customer_reset_password'  => 'reset-password',
		'wpp_customer_account'         => 'account',
		'wpp_customer_company'         => 'company',
	);

	public function __construct(
		private readonly AuthBootstrap $auth_bootstrap = new AuthBootstrap()
	) {}

	public function boot(): void {
		foreach ( self::ROUTES_BY_TAG as $tag => $route ) {
			add_shortcode( $tag, array( $this, 'render' ) );
		}
	}

	/**
	 * @param array<string,mixed>|string $atts
	 */
	public function render( $atts, ?string $content = null, string $tag = '' ): string {
		$route = self::ROUTES_BY_TAG[ $tag ] ?? '';

		if ( '' === $route ) {
			return '';
		}

		return $this->auth_bootstrap->render_customer_shortcode( $route, (array) $atts );
	}
}
