<?php
/**
 * Renders the per-company tab content shared by the admin Companies workspace
 * ({@see \Alltime\WPPhishing\Admin\AdminBootstrap}) and the customer-portal company view
 * ({@see \Alltime\WPPhishing\Auth\AuthBootstrap}) - one method per tab, each returning an HTML
 * fragment and never echoing directly, so both hosts can wrap it in their own chrome.
 *
 * Deliberately carries no permission logic of its own beyond what a tab's own write actions
 * require - which tabs are shown to a given viewer at all is the caller's decision (an operator
 * sees every company via `Capabilities::ALLTIME_MANAGE_ORGANISATIONS`; a customer's access is
 * already resolved by {@see \Alltime\WPPhishing\Support\TenantGuard} before this class is ever
 * reached), matching this plugin's existing convention of authorising at the call site rather
 * than inside a shared renderer.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Workspace;

use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\DomainVerificationStatus;
use Alltime\CustomerPlatform\Organisation;
use Alltime\CustomerPlatform\OrganisationDomain;
use Alltime\CustomerPlatform\Repositories\OrganisationDomainRepository;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationStatus;
use Alltime\WPPhishing\MailIntegrations\MailIntegrationService;
use Alltime\WPPhishing\Recipients\Enums\ImportSourceFormat;
use Alltime\WPPhishing\Recipients\Enums\ImportStatus;
use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\Recipient;
use Alltime\WPPhishing\Recipients\RecipientImport;
use Alltime\WPPhishing\Recipients\RecipientImportService;
use Alltime\WPPhishing\Recipients\Repositories\RecipientGroupRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientImportRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientRepository;
use Alltime\WPPhishing\Recipients\Support\CanonicalFields;
use Alltime\WPPhishing\Recipients\SuppressionService;
use Alltime\WPPhishing\Support\StatusPill;
use Alltime\WPPhishing\Verification\DomainVerificationService;

final class CompanyWorkspaceRenderer {

	private const DOMAIN_RECIPIENTS_PER_PAGE = 50;
	private const RECIPIENTS_PER_PAGE        = 20;
	private const IMPORTS_PER_PAGE           = 20;
	private const SUPPRESSIONS_PER_PAGE      = 20;

	/**
	 * Tab slug => label, in display order. A `match` on these slugs is how each caller decides
	 * which render_*_tab() method backs a given tab.
	 *
	 * @var array<string,string>
	 */
	public const TABS = array(
		'domains'           => 'Domains',
		'groups'            => 'Groups',
		'recipients'        => 'Recipients',
		'import'            => 'Recipient Import',
		'suppressions'      => 'Suppressions',
		'mail-integrations' => 'Mail Integrations',
	);

	public function __construct(
		private readonly RecipientRepository $recipients = new RecipientRepository(),
		private readonly RecipientGroupRepository $groups = new RecipientGroupRepository(),
		private readonly RecipientImportRepository $imports = new RecipientImportRepository(),
		private readonly RecipientImportService $import_service = new RecipientImportService(),
		private readonly SuppressionService $suppression_service = new SuppressionService(),
		private readonly MailIntegrationService $mail_integrations = new MailIntegrationService(),
		private readonly OrganisationDomainRepository $domains = new OrganisationDomainRepository(),
		private readonly DomainVerificationService $domain_verification = new DomainVerificationService()
	) {}

	/**
	 * Recipients grouped by the domain portion of their email address (not to be confused with
	 * `Alltime\CustomerPlatform`'s `OrganisationDomain` - this organisation's own verified
	 * sending/tracking/landing domains, a completely different concept). Each group can be
	 * expanded to list its recipients (each showing a suppression-flag badge) and suppressed as a
	 * whole via a new domain-level suppression row (PLAN.md section 10).
	 */
	public function render_domains_tab( Organisation $organisation, WorkspaceContext $context ): string {
		$html = '<h3>' . esc_html__( 'Sending domains', 'wp-phishing' ) . '</h3>' . $this->render_sending_domains( $organisation, $context );

		$html .= '<h3>' . esc_html__( 'Recipient domains', 'wp-phishing' ) . '</h3>';

		$domain_groups = $this->recipients->find_domains_for_organisation( $organisation->organisation_uuid );

		if ( array() === $domain_groups ) {
			return $html . '<p>' . esc_html__( 'No recipients have been imported for this company yet.', 'wp-phishing' ) . '</p>';
		}

		$known_domains   = array_column( $domain_groups, 'domain' );
		$expanded_domain = $this->requested_domain( $known_domains );

		$html .= '<table class="widefat"><thead><tr><th>' . esc_html__( 'Domain', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Recipients', 'wp-phishing' ) . '</th><th></th><th></th></tr></thead><tbody>';

		foreach ( $domain_groups as $group ) {
			$domain     = $group['domain'];
			$is_open    = $domain === $expanded_domain;
			$toggle_url = $context->url( 'domains', $is_open ? array() : array( 'domain' => $domain ) );

			$html .= '<tr><td>' . esc_html( $domain ) . '</td><td>' . (int) $group['recipient_count'] . '</td>'
				. '<td><a href="' . esc_url( $toggle_url ) . '">' . ( $is_open ? esc_html__( 'Hide recipients', 'wp-phishing' ) : esc_html__( 'View recipients', 'wp-phishing' ) ) . '</a></td>'
				. '<td>' . $this->render_suppress_domain_form( $organisation->organisation_uuid, $domain, $context ) . '</td></tr>';

			if ( $is_open ) {
				$html .= '<tr><td colspan="4">' . $this->render_domain_recipients( $organisation->organisation_uuid, $domain, $context ) . '</td></tr>';
			}
		}

		return $html . '</tbody></table>';
	}

	/**
	 * This organisation's own verified sending/tracking/landing domains
	 * (`Alltime\CustomerPlatform`'s `OrganisationDomain` contract) - a completely different concept
	 * from the recipient-email-domain groups below, see the class-level disambiguation note.
	 *
	 * Two entirely separate write paths share this one read view: an operator's "mark verified"
	 * override (Section 11, backed by a documented reason - a customer marking their own domain
	 * verified without completing real DNS proof would defeat the point of verification, so it only
	 * renders for an admin context), and a customer's own DNS-driven verification flow (ported here
	 * from the old `/phishing/account/` inline per-organisation section so a company's domains live
	 * in one place), which only renders for a customer context.
	 */
	private function render_sending_domains( Organisation $organisation, WorkspaceContext $context ): string {
		$domains = $this->domains->find_all_for_organisation( $organisation->id );
		$html    = '';

		if ( array() === $domains ) {
			$html .= '<p>' . esc_html__( 'No sending domains have been added for this company yet.', 'wp-phishing' ) . '</p>';
		} else {
			$html .= '<table class="widefat"><thead><tr><th>' . esc_html__( 'Domain', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Method', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Verification status', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

			foreach ( $domains as $domain ) {
				$html .= '<tr><td>' . esc_html( $domain->domain_ascii ) . '</td><td>' . esc_html( $domain->verification_method?->value ?? '' ) . '</td><td>' . StatusPill::render( $domain->verification_status->value, self::status_tone( $domain->verification_status->value ) ) . '</td><td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- StatusPill::render() escapes both its arguments internally.

				$html .= $context->is_admin
					? ( DomainVerificationStatus::Verified !== $domain->verification_status ? $this->render_override_verification_form( $organisation->organisation_uuid, $domain->domain_uuid, $context ) : '' )
					: $this->render_customer_verification_action( $organisation->organisation_uuid, $domain, $context );

				$html .= '</td></tr>';
			}

			$html .= '</tbody></table>';
		}

		if ( ! $context->is_admin ) {
			$html .= $this->render_add_domain_form( $organisation->organisation_uuid, $context );
		}

		return $html;
	}

	private function render_override_verification_form( string $organisation_uuid, string $domain_uuid, WorkspaceContext $context ): string {
		return '<form method="post">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="override_domain_verification">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain_uuid ) . '">'
			. '<input type="text" name="reason" placeholder="' . esc_attr__( 'Documented authority / reason', 'wp-phishing' ) . '" required>'
			. ' <button type="submit" class="button">' . esc_html__( 'Mark verified', 'wp-phishing' ) . '</button></form>';
	}

	private function render_customer_verification_action( string $organisation_uuid, OrganisationDomain $domain, WorkspaceContext $context ): string {
		if ( DomainVerificationMethod::DnsTxt !== $domain->verification_method ) {
			return '';
		}

		if ( DomainVerificationStatus::Pending === $domain->verification_status && null !== $domain->verification_reference ) {
			return esc_html__( 'Publish this DNS TXT record on the domain itself:', 'wp-phishing' )
				. ' <code>' . esc_html( $this->domain_verification->txt_record_value( $domain->verification_reference, $domain->verification_requested_at ) ) . '</code> '
				. '<form method="post" style="display:inline">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
				. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="check_verification">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
				. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Check now', 'wp-phishing' ) . '</button></form>';
		}

		if ( DomainVerificationStatus::Verified !== $domain->verification_status ) {
			return '<form method="post" style="display:inline">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see above.
				. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="start_verification">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
				. '<input type="hidden" name="domain_uuid" value="' . esc_attr( $domain->domain_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Get verification code', 'wp-phishing' ) . '</button></form>';
		}

		return '';
	}

	private function render_add_domain_form( string $organisation_uuid, WorkspaceContext $context ): string {
		return '<h4>' . esc_html__( 'Add a domain', 'wp-phishing' ) . '</h4>'
			. '<form method="post">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="add_domain">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<p><input type="text" name="domain" placeholder="example.com" required> '
			. '<button type="submit" class="button">' . esc_html__( 'Add', 'wp-phishing' ) . '</button></p></form>';
	}

	/**
	 * @param string[] $known_domains
	 */
	private function requested_domain( array $known_domains ): ?string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only expand/collapse state for a list already scoped by the caller's own organisation-access check.
		$requested = isset( $_GET['domain'] ) ? sanitize_text_field( wp_unslash( $_GET['domain'] ) ) : '';

		return in_array( $requested, $known_domains, true ) ? $requested : null;
	}

	private function render_domain_recipients( string $organisation_uuid, string $domain, WorkspaceContext $context ): string {
		$recipients = $this->recipients->find_by_domain_for_organisation( $organisation_uuid, $domain, self::DOMAIN_RECIPIENTS_PER_PAGE, 1 );

		if ( array() === $recipients ) {
			return '<p>' . esc_html__( 'No recipients found for this domain.', 'wp-phishing' ) . '</p>';
		}

		$html = '<table class="widefat"><thead><tr><th>' . esc_html__( 'Email', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Suppressed', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $recipients as $recipient ) {
			$html .= '<tr><td>' . esc_html( $recipient->email ) . '</td>'
				. '<td>' . esc_html( trim( ( $recipient->given_name ?? '' ) . ' ' . ( $recipient->family_name ?? '' ) ) ) . '</td>'
				. '<td>' . StatusPill::render( $recipient->status->value, self::status_tone( $recipient->status->value ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- StatusPill::render() escapes both its arguments internally.
				. '</td><td>' . $this->render_suppression_flag( $organisation_uuid, $recipient, $context ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_suppression_flag() only emits esc_*()-escaped fragments or StatusPill::render()'s own escaped output.
		}

		return $html . '</tbody></table>';
	}

	private function render_suppression_flag( string $organisation_uuid, Recipient $recipient, WorkspaceContext $context ): string {
		if ( $this->suppression_service->is_suppressed( $organisation_uuid, $recipient->email ) ) {
			return StatusPill::render( __( 'Suppressed', 'wp-phishing' ), StatusPill::BAD );
		}

		return $this->render_suppress_recipient_form( $organisation_uuid, $recipient->email, $context );
	}

	private function render_suppress_recipient_form( string $organisation_uuid, string $email, WorkspaceContext $context ): string {
		$html = '<form method="post" style="display:inline">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="workspace_suppress_recipient">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<input type="hidden" name="email" value="' . esc_attr( $email ) . '">'
			. '<select name="reason">';

		foreach ( SuppressionReason::cases() as $reason ) {
			$html .= '<option value="' . esc_attr( $reason->value ) . '">' . esc_html( $reason->value ) . '</option>';
		}

		return $html . '</select> <button type="submit" class="button">' . esc_html__( 'Suppress', 'wp-phishing' ) . '</button></form>';
	}

	private function render_suppress_domain_form( string $organisation_uuid, string $domain, WorkspaceContext $context ): string {
		$html = '<form method="post" style="display:inline" onsubmit="return confirm(\'' . esc_js( __( 'Suppress every recipient at this domain?', 'wp-phishing' ) ) . '\');">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="workspace_suppress_domain">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<input type="hidden" name="domain" value="' . esc_attr( $domain ) . '">'
			. '<select name="reason">';

		foreach ( SuppressionReason::cases() as $reason ) {
			$html .= '<option value="' . esc_attr( $reason->value ) . '">' . esc_html( $reason->value ) . '</option>';
		}

		return $html . '</select> <button type="submit" class="button">' . esc_html__( 'Suppress domain', 'wp-phishing' ) . '</button></form>';
	}

	/**
	 * Maps a status/verification enum's raw value to one of {@see StatusPill}'s four semantic
	 * tones. One shared mapping across every status-like field this class renders
	 * (`DomainVerificationStatus`, `ImportStatus`, `MailIntegrationStatus`, `RecipientStatus`)
	 * rather than one `match()` per enum, since their case names happen to carry the same meaning
	 * consistently here (e.g. every one of these enums' "failed"/"pending" means the same thing
	 * tone-wise).
	 */
	private static function status_tone( string $value ): string {
		return match ( $value ) {
			'verified', 'active', 'committed', 'validated' => StatusPill::GOOD,
			'pending', 'validating', 'committing' => StatusPill::WARN,
			'failed', 'expired', 'suppressed' => StatusPill::BAD,
			default => StatusPill::MUTED,
		};
	}

	public function render_groups_tab( Organisation $organisation, WorkspaceContext $context ): string {
		$html = '<table class="widefat"><thead><tr><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Type', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Members', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->groups->find_all_for_organisation( $organisation->organisation_uuid ) as $group ) {
			$html .= '<tr><td>' . esc_html( $group->name ) . '</td><td>' . esc_html( $group->type->value ) . '</td><td>' . (int) $this->groups->count_members( $group->id ) . '</td><td>'
				. '<form method="post" onsubmit="return confirm(\'' . esc_js( __( 'Delete this group?', 'wp-phishing' ) ) . '\');">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
				. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="delete_group">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
				. '<input type="hidden" name="group_uuid" value="' . esc_attr( $group->group_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Delete', 'wp-phishing' ) . '</button></form></td></tr>';
		}

		$html .= '</tbody></table>';

		return $html . '<h3>' . esc_html__( 'Create group', 'wp-phishing' ) . '</h3>'
			. '<form method="post">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="create_group">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create', 'wp-phishing' ) . '</button></p></form>';
	}

	public function render_recipients_tab( Organisation $organisation, WorkspaceContext $context ): string {
		$page  = $this->current_page();
		$total = $this->recipients->count_for_organisation( $organisation->organisation_uuid );

		$recipients = $this->recipients->find_all_for_organisation( $organisation->organisation_uuid, self::RECIPIENTS_PER_PAGE, $page );

		$html = '<p>' . esc_html(
			sprintf(
				/* translators: %d: recipient count */
				__( '%d recipient(s) total.', 'wp-phishing' ),
				$total
			)
		) . '</p>';

		$html .= '<table class="widefat"><thead><tr><th>' . esc_html__( 'Email', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Name', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Department', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $recipients as $recipient ) {
			$html .= '<tr><td>' . esc_html( $recipient->email ) . '</td><td>' . esc_html( trim( ( $recipient->given_name ?? '' ) . ' ' . ( $recipient->family_name ?? '' ) ) ) . '</td><td>' . esc_html( (string) $recipient->department ) . '</td><td>' . StatusPill::render( $recipient->status->value, self::status_tone( $recipient->status->value ) ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- StatusPill::render() escapes both its arguments internally.
		}

		$html .= '</tbody></table>';

		return $html . $this->render_pager( $page, (int) ceil( $total / self::RECIPIENTS_PER_PAGE ), $context, 'recipients' );
	}

	private function current_page(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination state.
		return max( 1, (int) ( $_GET['paged'] ?? 1 ) );
	}

	private function render_pager( int $page, int $total_pages, WorkspaceContext $context, string $tab ): string {
		if ( $total_pages <= 1 ) {
			return '';
		}

		$html = '<p class="tablenav-pages">';

		if ( $page > 1 ) {
			$html .= '<a class="button" href="' . esc_url( $context->url( $tab, array( 'paged' => (string) ( $page - 1 ) ) ) ) . '">' . esc_html__( '&laquo; Previous', 'wp-phishing' ) . '</a> ';
		}

		$html .= esc_html(
			sprintf(
				/* translators: 1: current page, 2: total pages */
				__( 'Page %1$d of %2$d', 'wp-phishing' ),
				$page,
				$total_pages
			)
		);

		if ( $page < $total_pages ) {
			$html .= ' <a class="button" href="' . esc_url( $context->url( $tab, array( 'paged' => (string) ( $page + 1 ) ) ) ) . '">' . esc_html__( 'Next &raquo;', 'wp-phishing' ) . '</a>';
		}

		return $html . '</p>';
	}

	/**
	 * Section 15's upload -> parse -> column mapping -> validate -> commit pipeline
	 * ({@see RecipientImportService}) is fully built but had no wp-admin entry point before this
	 * tab - only the REST API (`Api\RecipientImportsController`) could ever start one. Each row's
	 * available action depends on the import's own current `ImportStatus`.
	 */
	public function render_import_tab( Organisation $organisation, WorkspaceContext $context ): string {
		$imports = $this->imports->find_all_for_organisation( $organisation->organisation_uuid, self::IMPORTS_PER_PAGE, $this->current_page() );

		$expanded_uuid = $this->requested_import_uuid( $imports );

		$html = '<table class="widefat"><thead><tr><th>' . esc_html__( 'File', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Rows', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Valid', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Invalid', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Duplicate', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Suppressed', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Committed', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $imports as $import ) {
			$html .= '<tr><td>' . esc_html( (string) $import->original_filename ) . '</td><td>' . StatusPill::render( $import->status->value, self::status_tone( $import->status->value ) ) . '</td><td>' . (int) $import->total_rows . '</td><td>' . (int) $import->valid_rows . '</td><td>' . (int) $import->invalid_rows . '</td><td>' . (int) $import->duplicate_rows . '</td><td>' . (int) $import->suppressed_rows . '</td><td>' . (int) $import->committed_rows . '</td>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- StatusPill::render() escapes both its arguments internally.
				. '<td>' . $this->render_import_row_actions( $organisation->organisation_uuid, $import, $context ) . '</td></tr>';

			if ( $import->import_uuid === $expanded_uuid ) {
				$html .= '<tr><td colspan="9">' . $this->render_import_mapping_form( $organisation->organisation_uuid, $import, $context ) . '</td></tr>';
			}
		}

		$html .= '</tbody></table>';

		return $html . $this->render_start_import_form( $organisation->organisation_uuid, $context );
	}

	/**
	 * @param RecipientImport[] $imports
	 */
	private function requested_import_uuid( array $imports ): ?string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only expand state for a list already scoped by the caller's own organisation-access check.
		$requested = isset( $_GET['import'] ) ? sanitize_text_field( wp_unslash( $_GET['import'] ) ) : '';

		foreach ( $imports as $import ) {
			if ( $import->import_uuid === $requested ) {
				return $requested;
			}
		}

		return null;
	}

	private function render_import_row_actions( string $organisation_uuid, RecipientImport $import, WorkspaceContext $context ): string {
		$actions = '';

		if ( ImportStatus::Uploaded === $import->status ) {
			$actions .= '<a href="' . esc_url( $context->url( 'import', array( 'import' => $import->import_uuid ) ) ) . '">' . esc_html__( 'Map columns', 'wp-phishing' ) . '</a> ';
		}

		if ( in_array( $import->status, array( ImportStatus::Mapped, ImportStatus::Validating ), true ) ) {
			$actions .= $this->render_import_action_form( $organisation_uuid, $import->import_uuid, 'workspace_validate_import', __( 'Validate', 'wp-phishing' ), $context );
		}

		if ( ImportStatus::Validated === $import->status ) {
			$actions .= $this->render_import_action_form( $organisation_uuid, $import->import_uuid, 'workspace_commit_import', __( 'Commit', 'wp-phishing' ), $context );
		}

		if ( ImportStatus::Committing === $import->status ) {
			$actions .= $this->render_import_action_form( $organisation_uuid, $import->import_uuid, 'workspace_commit_import', __( 'Continue committing', 'wp-phishing' ), $context );
		}

		if ( ! $import->status->is_terminal() ) {
			$actions .= $this->render_import_action_form( $organisation_uuid, $import->import_uuid, 'workspace_cancel_import', __( 'Cancel', 'wp-phishing' ), $context, true );
		}

		return $actions;
	}

	private function render_import_action_form( string $organisation_uuid, string $import_uuid, string $action, string $label, WorkspaceContext $context, bool $confirm = false ): string {
		$confirm_attr = $confirm ? ' onsubmit="return confirm(\'' . esc_js( __( 'Are you sure?', 'wp-phishing' ) ) . '\');"' : '';

		return '<form method="post" style="display:inline"' . $confirm_attr . '>' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="' . esc_attr( $action ) . '">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<input type="hidden" name="import_uuid" value="' . esc_attr( $import_uuid ) . '">'
			. '<button type="submit" class="button">' . esc_html( $label ) . '</button></form> ';
	}

	private function render_import_mapping_form( string $organisation_uuid, RecipientImport $import, WorkspaceContext $context ): string {
		if ( ImportStatus::Uploaded !== $import->status ) {
			return '';
		}

		$headers = $this->import_service->detected_headers( $import );

		if ( array() === $headers ) {
			return '<p>' . esc_html__( 'This file has no detected columns to map.', 'wp-phishing' ) . '</p>';
		}

		$html = '<form method="post">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="workspace_set_import_mapping">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<input type="hidden" name="import_uuid" value="' . esc_attr( $import->import_uuid ) . '">'
			. '<table class="widefat"><thead><tr><th>' . esc_html__( 'Uploaded column', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Maps to', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $headers as $header ) {
			$html .= '<tr><td>' . esc_html( $header ) . '</td><td><select name="mapping[' . esc_attr( $header ) . ']"><option value="">' . esc_html__( '- Ignore -', 'wp-phishing' ) . '</option>';

			foreach ( CanonicalFields::all() as $field ) {
				$html .= '<option value="' . esc_attr( $field ) . '"' . selected( self::guess_field_from_header( $header ), $field, false ) . '>' . esc_html( $field ) . '</option>';
			}

			$html .= '</select></td></tr>';
		}

		return $html . '</tbody></table><p><button type="submit" class="button button-primary">' . esc_html__( 'Save mapping and validate', 'wp-phishing' ) . '</button></p></form>';
	}

	/**
	 * A cheap default so the common case (an uploaded header already named exactly like a
	 * canonical field, e.g. "email") doesn't require the admin to re-select it manually - purely a
	 * pre-selected default, never silently applied; the admin still submits the form themselves.
	 */
	private static function guess_field_from_header( string $header ): string {
		$normalised = strtolower( trim( $header ) );

		return CanonicalFields::is_known( $normalised ) ? $normalised : '';
	}

	private function render_start_import_form( string $organisation_uuid, WorkspaceContext $context ): string {
		$html = '<h3>' . esc_html__( 'Upload a recipient file', 'wp-phishing' ) . '</h3>'
			. '<form method="post" enctype="multipart/form-data">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="workspace_start_import">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'File (CSV or XLSX)', 'wp-phishing' ) . '<br><input type="file" name="file" accept=".csv,.xlsx" required></label></p>'
			. '<p><label>' . esc_html__( 'Format', 'wp-phishing' ) . '<br><select name="source_format">';

		foreach ( array( ImportSourceFormat::Csv, ImportSourceFormat::Xlsx ) as $format ) {
			$html .= '<option value="' . esc_attr( $format->value ) . '">' . esc_html( strtoupper( $format->value ) ) . '</option>';
		}

		return $html . '</select></label></p><p><button type="submit" class="button button-primary">' . esc_html__( 'Upload', 'wp-phishing' ) . '</button></p></form>';
	}

	/**
	 * Lists both email-scoped and domain-scoped suppressions (`Suppression::is_domain_scoped()`,
	 * added alongside the domain-suppression feature) in one table - the Domains tab's own
	 * per-recipient/per-domain "Suppress" actions and this tab's "Add suppression" form write to
	 * the same underlying list.
	 */
	public function render_suppressions_tab( Organisation $organisation, WorkspaceContext $context ): string {
		$html = '<table class="widefat"><thead><tr><th>' . esc_html__( 'Scope', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Reason', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Source', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Active', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Created', 'wp-phishing' ) . '</th></tr></thead><tbody>';

		foreach ( $this->suppression_service->list_for_organisation( $organisation->organisation_uuid, self::SUPPRESSIONS_PER_PAGE, $this->current_page() ) as $suppression ) {
			$html .= '<tr><td>' . StatusPill::render( $suppression->is_domain_scoped() ? __( 'Domain', 'wp-phishing' ) : __( 'Email', 'wp-phishing' ), StatusPill::MUTED ) . '</td><td>' . esc_html( $suppression->reason->value ) . '</td><td>' . esc_html( $suppression->source ) . '</td><td>' . ( $suppression->is_active() ? StatusPill::render( __( 'Active', 'wp-phishing' ), StatusPill::GOOD ) : StatusPill::render( __( 'Inactive', 'wp-phishing' ), StatusPill::MUTED ) ) . '</td><td>' . esc_html( $suppression->created_at->format( 'Y-m-d' ) ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- StatusPill::render() escapes both its arguments internally.
		}

		$html .= '</tbody></table>';

		$html .= '<h3>' . esc_html__( 'Add suppression', 'wp-phishing' ) . '</h3>'
			. '<form method="post">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field()'s own return value is already safe, internally-escaped HTML; this only re-echoes it as part of a larger concatenated string.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="create_suppression">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Email', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>'
			. '<p><label>' . esc_html__( 'Reason', 'wp-phishing' ) . '<br><select name="reason">';

		foreach ( SuppressionReason::cases() as $reason ) {
			$html .= '<option value="' . esc_attr( $reason->value ) . '">' . esc_html( $reason->value ) . '</option>';
		}

		return $html . '</select></label></p><p><button type="submit" class="button button-primary">' . esc_html__( 'Add', 'wp-phishing' ) . '</button></p></form>';
	}

	public function render_mail_integrations_tab( Organisation $organisation, WorkspaceContext $context ): string {
		$html = '<p>' . esc_html__( 'Grants this company makes to Alltime against their own Microsoft 365 or Google Workspace tenant, enabling mailbox-injection delivery (writing simulations directly into a mailbox) as an alternative to API-send. Each capability is authorised independently.', 'wp-phishing' ) . '</p>';

		$html .= '<table class="widefat"><thead><tr><th>' . esc_html__( 'Provider', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Capability', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Status', 'wp-phishing' ) . '</th><th>' . esc_html__( 'Tenant', 'wp-phishing' ) . '</th><th></th></tr></thead><tbody>';

		foreach ( $this->mail_integrations->list_for_organisation( $organisation->organisation_uuid ) as $integration ) {
			$html .= '<tr><td>' . esc_html( $integration->provider->value ) . '</td><td>' . esc_html( $integration->capability->value ) . '</td><td>' . StatusPill::render( $integration->status->value, self::status_tone( $integration->status->value ) ) . '</td><td>' . esc_html( (string) $integration->tenant_identifier ) . '</td><td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- StatusPill::render() escapes both its arguments internally.

			if ( MailIntegrationStatus::Active !== $integration->status ) {
				$html .= '<form method="post" style="display:inline">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see above.
					. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="verify_mail_integration">'
					. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
					. '<input type="hidden" name="integration_uuid" value="' . esc_attr( $integration->integration_uuid ) . '">';

				$html .= MailIntegrationProvider::Microsoft365 === $integration->provider
					? '<input type="text" name="tenant_id" placeholder="' . esc_attr__( 'Customer Entra tenant ID', 'wp-phishing' ) . '" required>'
					: '<input type="text" name="primary_domain" placeholder="' . esc_attr__( 'Primary Workspace domain', 'wp-phishing' ) . '" required> <input type="email" name="test_mailbox" placeholder="' . esc_attr__( 'A real mailbox to test against', 'wp-phishing' ) . '" required>';

				$html .= ' <button type="submit" class="button">' . esc_html__( 'Verify', 'wp-phishing' ) . '</button></form> ';
			}

			$html .= '<form method="post" style="display:inline" onsubmit="return confirm(\'' . esc_js( __( 'Revoke this integration?', 'wp-phishing' ) ) . '\');">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see above.
				. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="revoke_mail_integration">'
				. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
				. '<input type="hidden" name="integration_uuid" value="' . esc_attr( $integration->integration_uuid ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Revoke', 'wp-phishing' ) . '</button></form>';

			$html .= '</td></tr>';
		}

		$html .= '</tbody></table>';

		$html .= '<h3>' . esc_html__( 'Initiate a new integration', 'wp-phishing' ) . '</h3>'
			. '<form method="post">' . wp_nonce_field( $context->nonce_action, '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- see above.
			. '<input type="hidden" name="' . esc_attr( $context->action_field_name ) . '" value="initiate_mail_integration">'
			. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
			. '<p><label>' . esc_html__( 'Provider', 'wp-phishing' ) . '<br><select name="provider">';

		foreach ( MailIntegrationProvider::cases() as $provider ) {
			$html .= '<option value="' . esc_attr( $provider->value ) . '">' . esc_html( $provider->value ) . '</option>';
		}

		$html .= '</select></label></p><p><label>' . esc_html__( 'Capability', 'wp-phishing' ) . '<br><select name="capability">';

		foreach ( MailIntegrationCapability::cases() as $capability ) {
			$html .= '<option value="' . esc_attr( $capability->value ) . '">' . esc_html( $capability->value ) . '</option>';
		}

		return $html . '</select></label></p>'
			. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Initiate', 'wp-phishing' ) . '</button></p></form>'
			. '<p><small>' . esc_html__( 'For Microsoft, initiating creates a pending grant; send the customer\'s tenant admin the consent URL generated via the REST API, then verify once they confirm. For Google, share the service account email and scope shown via the REST API for the customer to enter in their own Workspace Admin Console domain-wide delegation settings, then verify against a real mailbox.', 'wp-phishing' ) . '</small></p>';
	}
}
