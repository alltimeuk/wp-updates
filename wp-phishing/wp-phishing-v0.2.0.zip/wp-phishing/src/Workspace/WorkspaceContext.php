<?php
/**
 * Carries what differs between the two hosts a {@see CompanyWorkspaceRenderer} tab can be
 * rendered from - WP-admin (an operator, WP-admin chrome, `admin.php` URLs) or the customer
 * portal (a tenant member, bare-document chrome, `/phishing/company/` URLs) - so tab-content
 * methods never need to branch on which host is calling them.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Workspace;

final class WorkspaceContext {

	/**
	 * @param \Closure(string,array<string,string>):string $url_for Builds the URL for another tab
	 *   of the same company workspace - `fn(string $tab, array $extra = []): string`.
	 */
	public function __construct(
		public readonly bool $is_admin,
		public readonly string $nonce_action,
		public readonly string $action_field_name,
		private readonly \Closure $url_for
	) {}

	/**
	 * @param array<string,string> $extra
	 */
	public function url( string $tab, array $extra = array() ): string {
		return ( $this->url_for )( $tab, $extra );
	}
}
