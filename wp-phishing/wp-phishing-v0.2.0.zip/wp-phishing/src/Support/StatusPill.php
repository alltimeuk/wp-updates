<?php
/**
 * Renders the small colored status indicator ("pill") used consistently for anything that's
 * fundamentally a state - active/suspended, verified/pending, suppressed/not - across the admin
 * Companies workspace and Settings screens. A shared helper (rather than each call site inventing
 * its own markup) so the same four semantic tones are used consistently; `CompanyWorkspaceRenderer`
 * is itself shared between the admin and customer-portal hosts, so this keeps pill markup identical
 * on both regardless of which host is rendering.
 *
 * The tones are deliberately generic (good/warn/bad/muted), not tied to any one domain concept
 * (verification, suppression, import status) - the caller decides which tone a given state maps to.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Support;

final class StatusPill {

	public const GOOD  = 'good';
	public const WARN  = 'warn';
	public const BAD   = 'bad';
	public const MUTED = 'muted';

	public static function render( string $label, string $tone ): string {
		return '<span class="wpp-pill wpp-pill--' . esc_attr( $tone ) . '">' . esc_html( $label ) . '</span>';
	}
}
