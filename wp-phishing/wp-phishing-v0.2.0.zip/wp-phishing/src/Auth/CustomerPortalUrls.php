<?php
/**
 * Resolves the URL for one of the customer portal's routes (see {@see AuthBootstrap::ROUTES}),
 * preferring a themed WordPress Page an admin has mapped to that route (via Settings > Portal
 * Pages) over the plugin's own raw, unstyled `/phishing/<route>/` URL.
 *
 * Every link this plugin generates to one of its own customer-portal screens - verification and
 * password-reset emails, cross-links between screens, the post-login redirect - previously
 * hardcoded the raw route regardless of whether an admin had built a themed `[wpp_customer_*]`
 * shortcode page instead, so even a fully themed portal still bounced a visitor through unstyled
 * pages at those specific moments. This is the single place that decision now gets made, so every
 * call site agrees. Ported from `alltimeuk/wp-reconnaissance`'s own `CustomerPortalUrls`.
 *
 * Deliberately static-only, never instantiating {@see AuthBootstrap}: its constructor pulls in
 * several other services that a caller resolving one URL - {@see \Alltime\WPPhishing\Support\Roles},
 * a queued email - shouldn't have to drag in just for that.
 *
 * `logout` is deliberately never resolved through here - see
 * {@see AuthBootstrap::SHORTCODE_ROUTES}'s docblock for why.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

final class CustomerPortalUrls {

	/**
	 * Per-request memoization: several render loops (the company workspace's own tab links, the
	 * account page's per-organisation links) resolve the same route once per row - no need to
	 * re-run get_option()/get_permalink()/get_post_status() every time when only the query args
	 * differ.
	 *
	 * @var array<string,string>
	 */
	private static array $cache = array();

	/**
	 * @param array<string,mixed> $query_args
	 */
	public static function url( string $route, array $query_args = array() ): string {
		$base = self::$cache[ $route ] ??= self::resolve_base( $route );
		$url  = array() !== $query_args ? add_query_arg( $query_args, $base ) : $base;

		/**
		 * Filters the resolved URL for a customer-portal route - a developer-level override that
		 * doesn't require going through wp-admin, matching this codebase's existing hook-based
		 * extensibility precedent (litespeed_control_set_nocache-style third-party integration
		 * points).
		 *
		 * @param string              $url        The resolved URL.
		 * @param string              $route      The route slug (see AuthBootstrap::ROUTES).
		 * @param array<string,mixed> $query_args Query args that were appended, if any.
		 */
		return (string) apply_filters( 'wpp_customer_portal_url', $url, $route, $query_args ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- 'wpp_' is this plugin's own established hook prefix (see wp-phishing.php's own constants), the sniff just doesn't recognise it as a "prefix" pattern here.
	}

	/**
	 * Test-only: clears the per-request memoization cache - not reached by WordPress's own
	 * per-test database rollback, since it isn't database state, so without this a route mapping
	 * one test resolves (and therefore caches) could leak into a later, unrelated test sharing the
	 * same PHPUnit process.
	 */
	public static function reset_cache_for_tests(): void {
		self::$cache = array();
	}

	private static function resolve_base( string $route ): string {
		$page_id = (int) get_option( 'wpp_customer_page_' . str_replace( '-', '_', $route ), 0 );

		if ( $page_id > 0
			&& 'publish' === get_post_status( $page_id )
			&& 'page' === get_post_type( $page_id )
		) {
			$permalink = get_permalink( $page_id );

			if ( false !== $permalink ) {
				return $permalink;
			}
		}

		return home_url( '/phishing/' . $route . '/' );
	}
}
