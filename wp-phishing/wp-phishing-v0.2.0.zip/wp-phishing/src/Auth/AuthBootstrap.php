<?php
/**
 * Dedicated customer authentication and account route bootstrap, per Section 12.
 *
 * Customers never register, sign in, reset passwords or manage their account through the native
 * wp-login.php presentation. The underlying identity records remain ordinary WordPress users
 * (core password hashing and session handling are retained via wp_insert_user(), wp_signon(),
 * wp_set_password()); this class owns the public `/phishing/*` routes, form handling, validation
 * messages and redirections.
 *
 * Routes live under `/phishing/*`, not a shared `/customer/*` prefix, matching
 * alltimeuk/wp-reconnaissance's own `/recon/*` precedent (its 0.1.17 rename, #106): two products
 * co-installed on one site would otherwise both register a rewrite rule for the identical
 * `^customer/<slug>/?$` pattern, and WordPress's rewrite table has no per-plugin namespacing -
 * whichever plugin's `init` callback ran last would silently win, making the other's customer
 * portal unreachable. `QUERY_VAR` keeps its `wpp_customer_route` name regardless - it's an internal
 * identifier, not a URL path segment, so it never collided with recon's own `wpr_customer_route`.
 *
 * Rendering here is deliberately minimal inline HTML, not a branded template layer - it exists so
 * the routes are genuinely functional end-to-end; a themed presentation is later work.
 *
 * Every route/handler builds its screen as a {@see CustomerPageResult} rather than echoing a full
 * document itself - {@see dispatch()} is the one place that wraps a result in the bare
 * `<!doctype html>` document these routes render.
 *
 * @package Alltime\WPPhishing
 */

declare( strict_types = 1 );

namespace Alltime\WPPhishing\Auth;

use Alltime\CustomerPlatform\Enums\DomainVerificationMethod;
use Alltime\CustomerPlatform\Enums\MembershipRole;
use Alltime\CustomerPlatform\Enums\MembershipStatus;
use Alltime\CustomerPlatform\Organisation;
use Alltime\CustomerPlatform\OrganisationInput;
use Alltime\CustomerPlatform\OrganisationMembership;
use Alltime\CustomerPlatform\OrganisationPlatformDiscovery;
use Alltime\CustomerPlatform\OrganisationServiceInterface;
use Alltime\WPPhishing\AntiAbuse\Turnstile;
use Alltime\WPPhishing\Auth\Enums\TokenType;
use Alltime\WPPhishing\Auth\Exceptions\RegistrationException;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationCapability;
use Alltime\WPPhishing\MailIntegrations\Enums\MailIntegrationProvider;
use Alltime\WPPhishing\MailIntegrations\MailIntegrationService;
use Alltime\WPPhishing\Recipients\Enums\ImportSourceFormat;
use Alltime\WPPhishing\Recipients\Enums\ImportStatus;
use Alltime\WPPhishing\Recipients\Enums\SuppressionReason;
use Alltime\WPPhishing\Recipients\RecipientImportService;
use Alltime\WPPhishing\Recipients\Repositories\RecipientGroupRepository;
use Alltime\WPPhishing\Recipients\Repositories\RecipientImportRepository;
use Alltime\WPPhishing\Recipients\SuppressionService;
use Alltime\WPPhishing\Support\AuditLogger;
use Alltime\WPPhishing\Support\Roles;
use Alltime\WPPhishing\Support\TenantGuard;
use Alltime\WPPhishing\Verification\DomainVerificationService;
use Alltime\WPPhishing\Verification\SchemaNotReadyException;
use Alltime\WPPhishing\Workspace\CompanyWorkspaceRenderer;
use Alltime\WPPhishing\Workspace\WorkspaceContext;

use const Alltime\WPPhishing\WPP_VERSION;

final class AuthBootstrap {

	private const QUERY_VAR = 'wpp_customer_route';

	/** @var string[] */
	private const ROUTES = array( 'register', 'verify-email', 'login', 'logout', 'forgot-password', 'reset-password', 'account', 'company' );

	/**
	 * The subset of ROUTES eligible for shortcode-embedding ({@see \Alltime\WPPhishing\Shortcodes\CustomerPortalShortcodes})
	 * and Settings > Portal Pages mapping ({@see CustomerPortalUrls}). Deliberately excludes
	 * 'logout': signing out must always hit its own raw route regardless of any mapping - a themed
	 * Account/Company page reloaded after logout has no way to reflect the just-ended session, so
	 * it would render as if still signed in. Matches wp-reconnaissance's own documented exception
	 * for the same route (there, logout isn't a standalone route at all).
	 *
	 * Public so both {@see \Alltime\WPPhishing\Shortcodes\CustomerPortalShortcodes} and the admin
	 * Settings > Portal Pages tab can iterate the authoritative list rather than duplicating it.
	 *
	 * @var string[]
	 */
	public const SHORTCODE_ROUTES = array( 'register', 'verify-email', 'login', 'forgot-password', 'reset-password', 'account', 'company' );

	/**
	 * Routes that require a signed-in customer, for both the raw route (which redirects to login)
	 * and the shortcode render path (which shows {@see sign_in_prompt_fragment()} instead, since a
	 * shortcode's render callback runs during `the_content()` - well after a theme has already
	 * started writing output - where a redirect would either warn and do nothing or corrupt the
	 * page).
	 *
	 * @var string[]
	 */
	private const GATED_SHORTCODE_ROUTES = array( 'account', 'company' );

	/**
	 * The hidden field a shortcode-rendered form carries to identify which route its POST is for,
	 * read by {@see dispatch_shortcode_post()} - independent of which page/URL the POST actually
	 * arrives at, unlike the raw-route dispatch which keys off {@see QUERY_VAR}.
	 */
	private const SHORTCODE_ROUTE_FIELD = 'wpp_shortcode_route';

	/**
	 * A minimal, self-contained copy of `assets/admin/admin.css`'s `.wpp-pill` rules (not the
	 * whole stylesheet - this route has no enqueue mechanism, and never will: it's the bare,
	 * intentionally unstyled fallback route, see this class's own docblock). Without this,
	 * `CompanyWorkspaceRenderer`'s status pills (shared with the admin Companies workspace) would
	 * render here as a naked dot-plus-text with no colour at all, reading as a rendering bug rather
	 * than "no theme yet". A themed `[wpp_customer_*]` shortcode page gets its styling from the
	 * theme instead, per this file's own established convention - this constant is only echoed by
	 * {@see dispatch()}'s raw-route document head, never by {@see render_customer_shortcode()}.
	 */
	private const PILL_STYLE_TAG = '<style>.wpp-pill{display:inline-flex;align-items:center;gap:5px;padding:2px 8px 2px 6px;border-radius:100px;font-size:11px;font-weight:600;line-height:1.6;white-space:nowrap}.wpp-pill::before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor;flex:none}.wpp-pill--good{background:#e4f4ea;color:#3f8f5f}.wpp-pill--warn{background:#f7edd9;color:#a3701f}.wpp-pill--bad{background:#f8e6e3;color:#b14a3d}.wpp-pill--muted{background:#f0f0f1;color:#646970}</style>';

	/**
	 * The hidden field {@see render_login_form()} embeds when rendered with a non-empty
	 * `$redirect_path` (the `[wpp_customer_login redirect="..."]` shortcode attribute), read by
	 * {@see handle_login()}'s success path in place of its hardcoded default.
	 */
	private const LOGIN_REDIRECT_FIELD = 'wpp_login_redirect';

	/**
	 * Populated by {@see dispatch_shortcode_post()} when a shortcode-originated POST produces a
	 * result instead of redirecting (e.g. "wrong password", or a workspace action's inline notice)
	 * - consumed by {@see render_customer_shortcode()} so that result reaches the same request's
	 * page render instead of being discarded. Static, not instance-scoped: {@see \Alltime\WPPhishing\Support\Plugin::boot()}
	 * and {@see \Alltime\WPPhishing\Shortcodes\CustomerPortalShortcodes} each hold their own
	 * separate `AuthBootstrap` instance, so an instance property here wouldn't be visible to both.
	 *
	 * @var array<string,CustomerPageResult>
	 */
	private static array $pending_shortcode_render = array();

	// Matches Admin\AdminBootstrap's own constants of the same name - the same limits, enforced at
	// this customer-portal entry point too.
	private const MAX_IMPORT_UPLOAD_BYTES   = 20 * 1024 * 1024;
	private const MAX_INLINE_IMPORT_BATCHES = 10;

	private RateLimiter $rate_limiter;

	public function __construct(
		private readonly TenantGuard $tenant_guard = new TenantGuard(),
		private readonly DomainVerificationService $domain_verification = new DomainVerificationService(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly RecipientGroupRepository $groups = new RecipientGroupRepository(),
		private readonly RecipientImportRepository $imports = new RecipientImportRepository(),
		private readonly RecipientImportService $import_service = new RecipientImportService(),
		private readonly SuppressionService $suppression_service = new SuppressionService(),
		private readonly MailIntegrationService $mail_integrations = new MailIntegrationService(),
		private readonly CompanyWorkspaceRenderer $workspace = new CompanyWorkspaceRenderer()
	) {
		$this->rate_limiter = new RateLimiter();
	}

	public function boot(): void {
		add_action( 'init', array( $this, 'register_rewrite_rules' ) );
		add_filter( 'query_vars', array( $this, 'register_query_var' ) );
		add_action( 'template_redirect', array( $this, 'dispatch' ) );
		add_action( 'template_redirect', array( $this, 'dispatch_shortcode_post' ) );
		add_action( 'template_redirect', array( $this, 'maybe_send_no_cache_headers_for_shortcode_page' ) );
		add_action( 'wp_loaded', array( $this, 'maybe_flush_rewrite_rules' ) );
	}

	public function register_rewrite_rules(): void {
		foreach ( self::ROUTES as $slug ) {
			add_rewrite_rule( '^phishing/' . preg_quote( $slug, '/' ) . '/?$', 'index.php?' . self::QUERY_VAR . '=' . $slug, 'top' );
		}
	}

	/**
	 * Self-healing companion to {@see \Alltime\WPPhishing\Support\Plugin::activate()}'s one-time
	 * `flush_rewrite_rules()` call, which WordPress never re-runs on a plugin *update* - only a
	 * fresh activation triggers `register_activation_hook()`'s callback. Without this, every one of
	 * these routes would 404 after any update that changes the registered rule set (such as this
	 * very `/customer/*` -> `/phishing/*` rename) until an administrator happened to notice and
	 * manually re-save Settings > Permalinks. Ported from wp-reconnaissance's own
	 * `AuthBootstrap::maybe_flush_rewrite_rules()`, added there for the identical reason.
	 *
	 * Runs on every request (`wp_loaded`, after {@see register_rewrite_rules()} has already fired on
	 * `init` and re-registered the current rule set) but the check itself is a single cheap
	 * `get_option()` call - the actual flush only happens the first request after `WPP_VERSION`
	 * changes, and this remembers that version so it doesn't repeat the flush on every subsequent
	 * request.
	 */
	public function maybe_flush_rewrite_rules(): void {
		if ( WPP_VERSION === get_option( 'wpp_rewrite_rules_version', '' ) ) {
			return;
		}

		flush_rewrite_rules();
		update_option( 'wpp_rewrite_rules_version', WPP_VERSION );
	}

	/**
	 * @param string[] $vars
	 *
	 * @return string[]
	 */
	public function register_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	/**
	 * Human-readable label per shortcode-eligible route, for the Settings > Portal Pages admin
	 * screen - a method rather than a `const` so labels stay translatable like every other
	 * user-facing string in this codebase (a `const` can only ever hold a literal, not a `__()`
	 * call).
	 *
	 * @return array<string,string>
	 */
	public static function route_labels(): array {
		return array(
			'register'        => __( 'Register', 'wp-phishing' ),
			'verify-email'    => __( 'Verify Email', 'wp-phishing' ),
			'login'           => __( 'Sign In', 'wp-phishing' ),
			'forgot-password' => __( 'Forgot Password', 'wp-phishing' ),
			'reset-password'  => __( 'Reset Password', 'wp-phishing' ),
			'account'         => __( 'Account', 'wp-phishing' ),
			'company'         => __( 'Company', 'wp-phishing' ),
		);
	}

	public function dispatch(): void {
		$route = get_query_var( self::QUERY_VAR );

		if ( ! is_string( $route ) || '' === $route || ! in_array( $route, self::ROUTES, true ) ) {
			return;
		}

		status_header( 200 );
		nocache_headers();

		$result = match ( $route ) {
			'register' => $this->handle_register(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->handle_login(),
			'logout' => $this->handle_logout(),
			'forgot-password' => $this->handle_forgot_password(),
			'reset-password' => $this->handle_reset_password(),
			'account' => $this->handle_account(),
			'company' => $this->handle_company(),
		};

		echo '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html( $result->title ) . '</title>' . self::PILL_STYLE_TAG . '</head><body>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- PILL_STYLE_TAG is a fixed string literal, not built from any request input.
		echo '<h1>' . esc_html( $result->title ) . '</h1>';
		echo $result->body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $result->body is assembled from esc_html()/esc_attr()/esc_url()-escaped fragments and wp_nonce_field() by every caller.
		echo '</body></html>';

		exit;
	}

	/**
	 * The page-agnostic counterpart to {@see dispatch()}: recognises a shortcode-rendered form's
	 * POST purely from {@see SHORTCODE_ROUTE_FIELD}, regardless of which page/URL it was submitted
	 * to, so the same handler logic works whether a screen is reached via its raw `/phishing/*`
	 * route or embedded as a shortcode on an ordinary themed page. Hooked on the same
	 * `template_redirect` action as {@see dispatch()} (fires before any theme output, well before
	 * `the_content()`/`do_shortcode()` - safe to `wp_safe_redirect()` from here exactly as
	 * `dispatch()` already does, which `handle_login()`'s and `handle_account()`'s/
	 * `handle_company()`'s own not-logged-in guards still do unmodified).
	 *
	 * The guard below is a hard invariant, not a convenience: without it, a crafted request to a
	 * real `/phishing/*` URL that also carries a forged {@see SHORTCODE_ROUTE_FIELD} field could
	 * fire both dispatchers. This must hold regardless of `add_action()` registration order.
	 *
	 * Adds no new bypass of anything a raw route already required: every nonce
	 * ({@see verify_nonce()}), rate limit and ownership check inside the `handle_*()` methods this
	 * calls runs exactly as it does for the raw route, since it's the same method either way. The
	 * hidden route field carries no authority of its own - it only selects which already-guarded
	 * handler runs.
	 */
	public function dispatch_shortcode_post(): void {
		if ( '' !== (string) get_query_var( self::QUERY_VAR ) ) {
			return;
		}

		if ( ! $this->is_post() ) {
			return;
		}

		$route = $this->post_field( self::SHORTCODE_ROUTE_FIELD );

		if ( '' === $route || ! in_array( $route, self::SHORTCODE_ROUTES, true ) ) {
			return;
		}

		$result = match ( $route ) {
			'register' => $this->handle_register(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->handle_login(),
			'forgot-password' => $this->handle_forgot_password(),
			'reset-password' => $this->handle_reset_password(),
			'account' => $this->handle_account(),
			'company' => $this->handle_company(),
		};

		// A handler that redirected (the common case for a successful login, or either gated
		// route's own not-logged-in guard) already terminated the request inside the call above via
		// a `never`-returning `exit` and control never reaches this line at all. Only a
		// non-terminating outcome (a validation error, or a workspace action's own inline notice -
		// none of wp-phishing's account/company write actions redirect on success, they always
		// redisplay the same page) gets here, and needs stashing for the shortcode's own render
		// callback ({@see render_customer_shortcode()}) to pick up instead of doing a fresh
		// GET-render.
		self::$pending_shortcode_render[ $route ] = $result;
	}

	/**
	 * Sends the same "never cache this" signal {@see dispatch()} has always sent for raw
	 * `/phishing/*` routes, to WordPress core and any page-cache plugin. Neither `dispatch()` nor
	 * {@see dispatch_shortcode_post()} covers the actual page a `[wpp_customer_*]` shortcode is
	 * embedded on being requested with a plain GET: that request is an ordinary WordPress page view
	 * as far as core is concerned, and every one of these screens renders content specific to
	 * whichever customer is (or isn't) currently signed in - caching that response would serve one
	 * visitor's account/company page, or a stale login/reset-password form and nonce, to the next
	 * visitor who requests the same URL. This closes that gap by checking, once per request at the
	 * same `template_redirect` point {@see dispatch()} already runs at (before any theme output),
	 * whether the currently queried page's content embeds any customer-portal shortcode, and if so
	 * sending the no-cache signal - scoped to only those pages, so ordinary page caching elsewhere
	 * on the site is untouched.
	 */
	public function maybe_send_no_cache_headers_for_shortcode_page(): void {
		$post = get_post();

		if ( ! $post instanceof \WP_Post ) {
			return;
		}

		foreach ( self::SHORTCODE_ROUTES as $route ) {
			if ( has_shortcode( $post->post_content, 'wpp_customer_' . str_replace( '-', '_', $route ) ) ) {
				nocache_headers();

				return;
			}
		}
	}

	/**
	 * Renders one of the shortcode-eligible customer-portal screens as a themed-page-compatible
	 * fragment, for a `[wpp_customer_*]` shortcode (registered separately, in
	 * {@see \Alltime\WPPhishing\Shortcodes\CustomerPortalShortcodes}) to embed inside ordinary page
	 * content. Returns only the body - no `<!doctype html>` wrapper and no `<h1>` title, unlike
	 * {@see dispatch()}'s raw-route rendering, since the theme's own page (and the site builder's
	 * own surrounding heading, if any) already provide that context.
	 *
	 * Deliberately never branches on {@see is_post()} or reads `$_POST` fields directly: by the
	 * time a shortcode's content renders (during `the_content`, well after `template_redirect`),
	 * any POST this request carried has already been fully handled by
	 * {@see dispatch_shortcode_post()} - which knows exactly which one shortcode's form (if any)
	 * was actually submitted, via {@see SHORTCODE_ROUTE_FIELD}. `is_post()` alone cannot answer
	 * that: a themed page can host more than one of these shortcodes at once, and the HTTP
	 * request's method is a property of the whole request, not of any one shortcode on the page -
	 * naively re-running a `handle_*()` method's own POST branch here would process (or mis-nonce)
	 * a different shortcode's submission. So this only ever calls the pure, GET-only rendering
	 * methods, after first checking {@see $pending_shortcode_render} for a result
	 * dispatch_shortcode_post() already produced for this exact route.
	 *
	 * @param array<string,mixed> $atts
	 */
	public function render_customer_shortcode( string $route, array $atts = array() ): string {
		if ( ! in_array( $route, self::SHORTCODE_ROUTES, true ) ) {
			return '';
		}

		$stashed = self::$pending_shortcode_render[ $route ] ?? null;

		if ( null !== $stashed ) {
			unset( self::$pending_shortcode_render[ $route ] );

			return $stashed->body;
		}

		if ( in_array( $route, self::GATED_SHORTCODE_ROUTES, true ) && ! is_user_logged_in() ) {
			return $this->sign_in_prompt_fragment();
		}

		$result = match ( $route ) {
			'register' => $this->render_register_form(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->render_login_form( null, isset( $atts['redirect'] ) ? (string) $atts['redirect'] : '' ),
			'forgot-password' => $this->render_forgot_password_form(),
			'reset-password' => $this->render_reset_password_screen(),
			'account' => $this->render_account_page( null ),
			'company' => $this->render_company_shortcode(),
		};

		return $result->body;
	}

	private function sign_in_prompt_fragment(): string {
		return '<p>' . esc_html__( 'Please sign in to view this.', 'wp-phishing' ) . ' <a href="' . esc_url( CustomerPortalUrls::url( 'login' ) ) . '">' . esc_html__( 'Sign in', 'wp-phishing' ) . '</a></p>';
	}

	// -----------------------------------------------------------------------------------
	// Registration
	// -----------------------------------------------------------------------------------

	private function handle_register(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_register_form();
		}

		if ( ! $this->verify_nonce( 'wpp_register' ) || ! Honeypot::passes() ) {
			return $this->render_register_form( __( 'Please try again.', 'wp-phishing' ) );
		}

		if ( ! $this->rate_limiter->allow( 'register', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS, $this->post_field( 'email' ) ) ) {
			return $this->render_register_form( __( 'Please try again in a little while.', 'wp-phishing' ) );
		}

		if ( ! Turnstile::verify( $this->post_field( 'cf-turnstile-response' ), $this->rate_limiter->client_ip() ) ) {
			return $this->render_register_form( __( 'Please try again.', 'wp-phishing' ) );
		}

		try {
			$result = ( new RegistrationService() )->register(
				$this->post_field( 'given_name' ),
				$this->post_field( 'family_name' ),
				$this->post_field( 'email' ),
				$this->post_field( 'password' ),
				$this->post_field( 'password_confirmation' ),
				$this->post_checked( 'terms_accepted' ),
				$this->post_checked( 'privacy_acknowledged' ),
				$this->post_checked( 'marketing_consent' )
			);
		} catch ( RegistrationException $exception ) {
			return $this->render_register_form( $exception->getMessage() );
		}

		// Section 12: identical response whether or not the address was already registered.
		if ( $result->is_new && null !== $result->user_id && null !== $result->verification_token ) {
			$this->send_verification_email( $result->user_id, $result->verification_token );
		}

		return $this->render_result(
			__( 'Check your email', 'wp-phishing' ),
			'<p>' . esc_html__( 'If your details were accepted, we have sent a verification link to the email address you provided. Follow it to activate your account.', 'wp-phishing' ) . '</p>'
		);
	}

	private function render_register_form( ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpp_register', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Given name', 'wp-phishing' ) . '<br><input type="text" name="given_name" required></label></p>
				<p><label>' . esc_html__( 'Family name', 'wp-phishing' ) . '<br><input type="text" name="family_name" required></label></p>
				<p><label>' . esc_html__( 'Email address', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Password', 'wp-phishing' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm password', 'wp-phishing' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><label><input type="checkbox" name="terms_accepted" value="1" required> ' . esc_html__( 'I accept the service terms.', 'wp-phishing' ) . '</label></p>
				<p><label><input type="checkbox" name="privacy_acknowledged" value="1" required> ' . esc_html__( 'I acknowledge the privacy notice.', 'wp-phishing' ) . '</label></p>
				<p><label><input type="checkbox" name="marketing_consent" value="1"> ' . esc_html__( 'I would like to receive occasional marketing updates (optional).', 'wp-phishing' ) . '</label></p>
				' . Honeypot::render() . '
				' . $this->turnstile_widget_html() . '
				<p><button type="submit">' . esc_html__( 'Create account', 'wp-phishing' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( CustomerPortalUrls::url( 'login' ) ) . '">' . esc_html__( 'Already have an account? Sign in.', 'wp-phishing' ) . '</a></p>';

		return $this->render_result( __( 'Create your account', 'wp-phishing' ), $body );
	}

	private function send_verification_email( int $user_id, string $token ): void {
		$user = get_userdata( $user_id );

		if ( false === $user ) {
			return;
		}

		$link = CustomerPortalUrls::url( 'verify-email', array( 'token' => $token ) );

		// A single, low-volume transactional email - deliberately plain wp_mail(), not the
		// multi-provider queue (Section 25) that governs bulk phishing-simulation delivery.
		wp_mail( // phpcs:ignore WordPress.WP.AlternativeFunctions.wp_mail_wp_mail -- transactional account email, not campaign simulation delivery; see docblock.
			$user->user_email,
			__( 'Verify your email address', 'wp-phishing' ),
			sprintf(
				/* translators: %s: verification link */
				__( "Please verify your email address by visiting the following link:\n\n%s", 'wp-phishing' ),
				esc_url_raw( $link )
			)
		);
	}

	// -----------------------------------------------------------------------------------
	// Email verification
	// -----------------------------------------------------------------------------------

	private function handle_verify_email(): CustomerPageResult {
		$token = $this->get_field( 'token' );

		if ( '' === $token ) {
			return $this->render_result( __( 'Verify your email', 'wp-phishing' ), '<p>' . esc_html__( 'No verification token was supplied.', 'wp-phishing' ) . '</p>' );
		}

		$user_id = ( new TokenService() )->consume( $token, TokenType::EmailVerification );

		if ( null === $user_id ) {
			return $this->render_result( __( 'Verify your email', 'wp-phishing' ), '<p>' . esc_html__( 'This verification link is invalid or has expired.', 'wp-phishing' ) . '</p>' );
		}

		update_user_meta( $user_id, RegistrationService::EMAIL_VERIFIED_META_KEY, true );

		$this->audit_logger->log( 'registration.email_verified', 'user', (string) $user_id, $user_id, source: 'customer_portal' );

		return $this->render_result(
			__( 'Verify your email', 'wp-phishing' ),
			'<p>' . esc_html__( 'Your email address has been verified. You can now sign in.', 'wp-phishing' ) . '</p><p><a href="' . esc_url( CustomerPortalUrls::url( 'login' ) ) . '">' . esc_html__( 'Sign in', 'wp-phishing' ) . '</a></p>'
		);
	}

	// -----------------------------------------------------------------------------------
	// Login / logout
	// -----------------------------------------------------------------------------------

	private function handle_login(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_login_form();
		}

		if ( ! $this->verify_nonce( 'wpp_login' ) || ! $this->rate_limiter->allow( 'login', $this->rate_limiter->client_ip(), 10, 15 * MINUTE_IN_SECONDS, $this->post_field( 'email' ) ) ) {
			return $this->render_login_form( __( 'Too many attempts. Please try again shortly.', 'wp-phishing' ) );
		}

		$generic_error = __( 'Incorrect email address or password.', 'wp-phishing' );

		$user = wp_signon(
			array(
				'user_login'    => $this->post_field( 'email' ),
				'user_password' => $this->post_field( 'password' ),
				'remember'      => true,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			return $this->render_login_form( $generic_error );
		}

		if ( ! in_array( Roles::CUSTOMER_ROLE, (array) $user->roles, true ) ) {
			wp_logout();
			return $this->render_login_form( $generic_error );
		}

		if ( ! (bool) get_user_meta( $user->ID, RegistrationService::EMAIL_VERIFIED_META_KEY, true ) ) {
			wp_logout();
			return $this->render_login_form( __( 'Please verify your email address before signing in.', 'wp-phishing' ) );
		}

		// Deliberately NOT a referer bounce: the referer for a shortcode-embedded login form is the
		// login page itself (this form has no action= attribute, so it self-submits) - sending a
		// just-authenticated visitor back there would show them the login form again instead of
		// somewhere useful. Defaults to the account route regardless of whether this was reached via
		// the raw route or a shortcode; a site embedding [wpp_customer_login redirect="..."] can
		// override that via the hidden field render_login_form() embeds, re-validated here rather
		// than trusted as-is since a hidden field's value is still attacker-editable on the client.
		$default_target = CustomerPortalUrls::url( 'account' );
		$override       = $this->post_field( self::LOGIN_REDIRECT_FIELD );
		$target         = '' !== $override ? wp_validate_redirect( $override, $default_target ) : $default_target;

		wp_safe_redirect( $target );
		exit;
	}

	private function render_login_form( ?string $error = null, string $redirect_path = '' ): CustomerPageResult {
		$redirect_field = '' !== $redirect_path
			? '<input type="hidden" name="' . esc_attr( self::LOGIN_REDIRECT_FIELD ) . '" value="' . esc_attr( home_url( $redirect_path ) ) . '">'
			: '';

		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpp_login', '_wpnonce', true, false ) . '
				' . $redirect_field . '
				<p><label>' . esc_html__( 'Email address', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Password', 'wp-phishing' ) . '<br><input type="password" name="password" required></label></p>
				<p><button type="submit">' . esc_html__( 'Sign in', 'wp-phishing' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( CustomerPortalUrls::url( 'forgot-password' ) ) . '">' . esc_html__( 'Forgotten your password?', 'wp-phishing' ) . '</a></p>
			<p><a href="' . esc_url( CustomerPortalUrls::url( 'register' ) ) . '">' . esc_html__( 'Create an account', 'wp-phishing' ) . '</a></p>';

		return $this->render_result( __( 'Sign in', 'wp-phishing' ), $body );
	}

	private function handle_logout(): CustomerPageResult {
		wp_logout();
		wp_safe_redirect( CustomerPortalUrls::url( 'login' ) );
		exit;
	}

	// -----------------------------------------------------------------------------------
	// Forgot / reset password
	// -----------------------------------------------------------------------------------

	private function handle_forgot_password(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_forgot_password_form();
		}

		$generic_notice = __( 'If an account exists for that address, we have sent password reset instructions.', 'wp-phishing' );

		if ( ! $this->verify_nonce( 'wpp_forgot_password' ) || ! Honeypot::passes() || ! $this->rate_limiter->allow( 'forgot_password', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS, $this->post_field( 'email' ) ) ) {
			return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
		}

		if ( ! Turnstile::verify( $this->post_field( 'cf-turnstile-response' ), $this->rate_limiter->client_ip() ) ) {
			return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
		}

		$user = get_user_by( 'email', $this->post_field( 'email' ) );

		if ( false !== $user && in_array( Roles::CUSTOMER_ROLE, (array) $user->roles, true ) ) {
			$token = ( new TokenService() )->issue( $user->ID, TokenType::PasswordReset, HOUR_IN_SECONDS );
			$link  = CustomerPortalUrls::url( 'reset-password', array( 'token' => $token ) );

			wp_mail( // phpcs:ignore WordPress.WP.AlternativeFunctions.wp_mail_wp_mail -- transactional account email, not campaign simulation delivery.
				$user->user_email,
				__( 'Reset your password', 'wp-phishing' ),
				sprintf(
					/* translators: %s: reset link */
					__( "Reset your password by visiting the following link (valid for one hour):\n\n%s", 'wp-phishing' ),
					esc_url_raw( $link )
				)
			);

			$this->audit_logger->log( 'password_reset.requested', 'user', (string) $user->ID, $user->ID, source: 'customer_portal' );
		}

		// Identical response whether or not the address matched an account (Section 12).
		return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
	}

	private function render_forgot_password_form(): CustomerPageResult {
		$body = '<form method="post">
			' . wp_nonce_field( 'wpp_forgot_password', '_wpnonce', true, false ) . '
			<p><label>' . esc_html__( 'Email address', 'wp-phishing' ) . '<br><input type="email" name="email" required></label></p>
			' . Honeypot::render() . '
			' . $this->turnstile_widget_html() . '
			<p><button type="submit">' . esc_html__( 'Send reset instructions', 'wp-phishing' ) . '</button></p>
		</form>';

		return $this->render_result( __( 'Forgotten password', 'wp-phishing' ), $body );
	}

	private function handle_reset_password(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_reset_password_screen();
		}

		$token = $this->post_field( 'token' );

		if ( '' === $token ) {
			return $this->render_result( __( 'Reset password', 'wp-phishing' ), '<p>' . esc_html__( 'No reset token was supplied.', 'wp-phishing' ) . '</p>' );
		}

		if ( ! $this->verify_nonce( 'wpp_reset_password' ) ) {
			return $this->render_reset_password_form( $token, __( 'Please try again.', 'wp-phishing' ) );
		}

		$password              = $this->post_field( 'password' );
		$password_confirmation = $this->post_field( 'password_confirmation' );

		if ( strlen( $password ) < 12 ) {
			return $this->render_reset_password_form( $token, __( 'Password must be at least 12 characters long.', 'wp-phishing' ) );
		}

		if ( $password !== $password_confirmation ) {
			return $this->render_reset_password_form( $token, __( 'Password and confirmation do not match.', 'wp-phishing' ) );
		}

		$user_id = ( new TokenService() )->consume( $token, TokenType::PasswordReset );

		if ( null === $user_id ) {
			return $this->render_result( __( 'Reset password', 'wp-phishing' ), '<p>' . esc_html__( 'This reset link is invalid or has expired.', 'wp-phishing' ) . '</p>' );
		}

		reset_password( get_userdata( $user_id ), $password );

		$this->audit_logger->log( 'password_reset.completed', 'user', (string) $user_id, $user_id, source: 'customer_portal' );

		return $this->render_result(
			__( 'Reset password', 'wp-phishing' ),
			'<p>' . esc_html__( 'Your password has been reset. You can now sign in.', 'wp-phishing' ) . '</p><p><a href="' . esc_url( CustomerPortalUrls::url( 'login' ) ) . '">' . esc_html__( 'Sign in', 'wp-phishing' ) . '</a></p>'
		);
	}

	/**
	 * The GET-only view: the token-check + form, with no `is_post()` branching - reused by
	 * {@see handle_reset_password()}'s own GET branch and by the shortcode-rendering path
	 * ({@see render_customer_shortcode()}), which must never re-run POST detection based on the
	 * request's overall method (a different shortcode's form on the same themed page may be what
	 * was actually submitted - see render_customer_shortcode()'s docblock).
	 */
	private function render_reset_password_screen(): CustomerPageResult {
		$token = $this->get_field( 'token' );

		if ( '' === $token ) {
			return $this->render_result( __( 'Reset password', 'wp-phishing' ), '<p>' . esc_html__( 'No reset token was supplied.', 'wp-phishing' ) . '</p>' );
		}

		return $this->render_reset_password_form( $token );
	}

	private function render_reset_password_form( string $token, ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpp_reset_password', '_wpnonce', true, false ) . '
				<input type="hidden" name="token" value="' . esc_attr( $token ) . '">
				<p><label>' . esc_html__( 'New password', 'wp-phishing' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm new password', 'wp-phishing' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><button type="submit">' . esc_html__( 'Reset password', 'wp-phishing' ) . '</button></p>
			</form>';

		return $this->render_result( __( 'Reset password', 'wp-phishing' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Account dashboard
	// -----------------------------------------------------------------------------------

	private function handle_account(): CustomerPageResult {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( CustomerPortalUrls::url( 'login' ) );
			exit;
		}

		$notice = null;

		if ( $this->is_post() && $this->verify_nonce( 'wpp_account_action' ) ) {
			$notice = $this->handle_account_action();
		}

		return $this->render_account_page( $notice );
	}

	/**
	 * @return string|null An error message to show, or null on success (a success banner is
	 *                       shown instead, distinguished by {@see render_account_page()}'s
	 *                       `$notice` handling being purely informational either way here).
	 */
	private function handle_account_action(): ?string {
		$user_id = get_current_user_id();
		$action  = $this->post_field( 'wpp_account_action' );

		return match ( $action ) {
			'create_organisation' => $this->handle_create_organisation( $user_id ),
			'add_domain' => $this->handle_add_domain(),
			'start_verification' => $this->handle_start_verification( $user_id ),
			'check_verification' => $this->handle_check_verification(),
			'accept_invitation' => $this->handle_accept_invitation( $user_id ),
			'create_group' => $this->handle_create_group( $user_id ),
			'delete_group' => $this->handle_delete_group( $user_id ),
			'create_suppression', 'workspace_suppress_recipient' => $this->handle_suppress_recipient( $user_id ),
			'workspace_suppress_domain' => $this->handle_suppress_domain( $user_id ),
			'workspace_start_import' => $this->handle_workspace_start_import( $user_id ),
			'workspace_set_import_mapping' => $this->handle_workspace_set_import_mapping(),
			'workspace_validate_import' => $this->handle_workspace_validate_import(),
			'workspace_commit_import' => $this->handle_workspace_commit_import( $user_id ),
			'workspace_cancel_import' => $this->handle_workspace_cancel_import( $user_id ),
			'initiate_mail_integration' => $this->handle_initiate_mail_integration( $user_id ),
			'verify_mail_integration' => $this->handle_verify_mail_integration(),
			'revoke_mail_integration' => $this->handle_revoke_mail_integration( $user_id ),
			default => __( 'Unrecognised action.', 'wp-phishing' ),
		};
	}

	private function handle_create_organisation( int $user_id ): ?string {
		$name = $this->post_field( 'name' );

		if ( '' === trim( $name ) ) {
			return __( 'An organisation name is required.', 'wp-phishing' );
		}

		$service = $this->organisation_service();
		$result  = $service->create_or_update_organisation( new OrganisationInput( name: $name ) );

		$membership = $service->add_member( $result->organisation->organisation_uuid, $user_id, MembershipRole::Owner );
		$service->update_member_status( $membership->id, MembershipStatus::Active );

		return null;
	}

	private function handle_add_domain(): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$domain            = strtolower( trim( $this->post_field( 'domain' ) ) );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage domains for this organisation.', 'wp-phishing' );
		}

		if ( '' === $domain || ! preg_match( '/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/', $domain ) ) {
			return __( 'A valid domain name is required.', 'wp-phishing' );
		}

		$service = $this->organisation_service();

		if ( null !== $service->find_domain_by_ascii( $domain ) ) {
			return __( 'This domain is already registered to an organisation.', 'wp-phishing' );
		}

		$service->add_domain( $organisation_uuid, $domain, DomainVerificationMethod::DnsTxt );

		return null;
	}

	private function handle_start_verification( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$domain_uuid       = $this->post_field( 'domain_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage domains for this organisation.', 'wp-phishing' );
		}

		try {
			$this->domain_verification->generate_challenge( $domain_uuid, $user_id, 'customer_portal' );
		} catch ( SchemaNotReadyException | \InvalidArgumentException $exception ) {
			return $exception->getMessage(); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- rendered via esc_html() in error_html() below.
		}

		return null;
	}

	private function handle_check_verification(): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$domain_uuid       = $this->post_field( 'domain_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage domains for this organisation.', 'wp-phishing' );
		}

		$domain = $this->organisation_service()->get_domain( $domain_uuid );

		if ( null === $domain || $domain->organisation_uuid !== $organisation_uuid ) {
			return __( 'Domain not found.', 'wp-phishing' );
		}

		$verified = $this->domain_verification->check( $domain, 'customer_portal' );

		return $verified ? null : __( 'The verification record was not found yet. DNS changes can take time to propagate - try again shortly.', 'wp-phishing' );
	}

	private function handle_accept_invitation( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );
		$service           = $this->organisation_service();
		$membership        = $service->get_membership( $organisation_uuid, $user_id );

		if ( null === $membership || MembershipStatus::Invited !== $membership->status ) {
			return __( 'This invitation is no longer available.', 'wp-phishing' );
		}

		$service->update_member_status( $membership->id, MembershipStatus::Active );

		$this->audit_logger->log( 'organisation.invitation_accepted', 'organisation', $organisation_uuid, $user_id, source: 'customer_portal', organisation_uuid: $organisation_uuid );

		return null;
	}

	// -----------------------------------------------------------------------------------
	// Company workspace write actions - the customer-side equivalents of Admin\AdminBootstrap's
	// own group/suppression/import/mail-integration handlers, calling the same underlying services
	// but gated on TenantGuard::has_role() (Owner/Administrator) rather than a WP capability, and
	// returning an error message (or null on success) rather than redirecting - this route always
	// redisplays the same tab it was submitted from.
	// -----------------------------------------------------------------------------------

	private function handle_create_group( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage groups for this organisation.', 'wp-phishing' );
		}

		$name = $this->post_field( 'name' );

		if ( '' === $name ) {
			return __( 'A group name is required.', 'wp-phishing' );
		}

		$group = $this->groups->create( $organisation_uuid, $name, null );
		$this->audit_logger->log( 'recipient_group.created', 'recipient_group', $group->group_uuid, $user_id, summary: $name, source: 'customer_portal', organisation_uuid: $organisation_uuid );

		return null;
	}

	private function handle_delete_group( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage groups for this organisation.', 'wp-phishing' );
		}

		$group = $this->groups->find_by_uuid( $organisation_uuid, $this->post_field( 'group_uuid' ) );

		if ( null === $group ) {
			return __( 'Group not found.', 'wp-phishing' );
		}

		$this->groups->delete( $group->id );
		$this->audit_logger->log( 'recipient_group.deleted', 'recipient_group', $group->group_uuid, $user_id, summary: $group->name, source: 'customer_portal', organisation_uuid: $organisation_uuid );

		return null;
	}

	private function handle_suppress_recipient( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage suppressions for this organisation.', 'wp-phishing' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see handle_account_action()/verify_nonce().
		$email  = isset( $_POST['email'] ) && is_string( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$reason = SuppressionReason::tryFrom( $this->post_field( 'reason' ) );

		if ( ! is_email( $email ) || null === $reason ) {
			return __( 'Could not suppress that recipient.', 'wp-phishing' );
		}

		$this->suppression_service->suppress( $organisation_uuid, $email, $reason, 'customer_portal', null, $user_id );

		return null;
	}

	private function handle_suppress_domain( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage suppressions for this organisation.', 'wp-phishing' );
		}

		$domain = $this->post_field( 'domain' );
		$reason = SuppressionReason::tryFrom( $this->post_field( 'reason' ) );

		if ( '' === $domain || null === $reason ) {
			return __( 'Could not suppress that domain.', 'wp-phishing' );
		}

		$this->suppression_service->suppress_domain( $organisation_uuid, $domain, $reason, 'customer_portal', null, $user_id );

		return null;
	}

	private function handle_workspace_start_import( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage recipient imports for this organisation.', 'wp-phishing' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see handle_account_action(); $_FILES carries no nonce of its own.
		$file = $_FILES['file'] ?? null;

		if ( ! is_array( $file ) || UPLOAD_ERR_OK !== ( (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) ) {
			return __( 'No file was uploaded.', 'wp-phishing' );
		}

		if ( (int) $file['size'] > self::MAX_IMPORT_UPLOAD_BYTES ) {
			return __( 'The uploaded file exceeds the maximum allowed size.', 'wp-phishing' );
		}

		if ( ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
			return __( 'The uploaded file could not be verified.', 'wp-phishing' );
		}

		$source_format = ImportSourceFormat::tryFrom( $this->post_field( 'source_format' ) );

		if ( null === $source_format ) {
			return __( 'Choose a valid file format.', 'wp-phishing' );
		}

		try {
			$this->import_service->start_import( $organisation_uuid, $source_format, (string) $file['tmp_name'], sanitize_file_name( (string) $file['name'] ), $user_id );
		} catch ( \Throwable $exception ) {
			return $exception->getMessage(); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- rendered via esc_html() in error_html().
		}

		return null;
	}

	private function handle_workspace_set_import_mapping(): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage recipient imports for this organisation.', 'wp-phishing' );
		}

		$import = $this->imports->find_by_uuid( $organisation_uuid, $this->post_field( 'import_uuid' ) );

		if ( null === $import ) {
			return __( 'Import not found.', 'wp-phishing' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see handle_account_action().
		$raw_mapping = isset( $_POST['mapping'] ) && is_array( $_POST['mapping'] ) ? wp_unslash( $_POST['mapping'] ) : array();
		$mapping     = array();

		foreach ( $raw_mapping as $header => $target ) {
			$target = sanitize_text_field( (string) $target );

			if ( '' !== $target ) {
				$mapping[ sanitize_text_field( (string) $header ) ] = $target;
			}
		}

		try {
			$import = $this->import_service->set_column_mapping( $import, $mapping );
		} catch ( \InvalidArgumentException $exception ) {
			return $exception->getMessage(); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- see handle_workspace_start_import().
		}

		for ( $i = 0; $i < self::MAX_INLINE_IMPORT_BATCHES && ImportStatus::Validating === $import->status; $i++ ) {
			$import = $this->import_service->validate_batch( $import );
		}

		return null;
	}

	private function handle_workspace_validate_import(): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage recipient imports for this organisation.', 'wp-phishing' );
		}

		$import = $this->imports->find_by_uuid( $organisation_uuid, $this->post_field( 'import_uuid' ) );

		if ( null === $import ) {
			return __( 'Import not found.', 'wp-phishing' );
		}

		for ( $i = 0; $i < self::MAX_INLINE_IMPORT_BATCHES; $i++ ) {
			$import = $this->import_service->validate_batch( $import );

			if ( ImportStatus::Validating !== $import->status ) {
				break;
			}
		}

		return null;
	}

	private function handle_workspace_commit_import( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage recipient imports for this organisation.', 'wp-phishing' );
		}

		$import = $this->imports->find_by_uuid( $organisation_uuid, $this->post_field( 'import_uuid' ) );

		if ( null === $import ) {
			return __( 'Import not found.', 'wp-phishing' );
		}

		for ( $i = 0; $i < self::MAX_INLINE_IMPORT_BATCHES; $i++ ) {
			$import = $this->import_service->commit_batch( $import, $user_id );

			if ( ImportStatus::Committing !== $import->status ) {
				break;
			}
		}

		return null;
	}

	private function handle_workspace_cancel_import( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage recipient imports for this organisation.', 'wp-phishing' );
		}

		$import = $this->imports->find_by_uuid( $organisation_uuid, $this->post_field( 'import_uuid' ) );

		if ( null === $import ) {
			return __( 'Import not found.', 'wp-phishing' );
		}

		try {
			$this->import_service->cancel( $import, $user_id );
		} catch ( \RuntimeException $exception ) {
			return $exception->getMessage(); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- see handle_workspace_start_import().
		}

		return null;
	}

	private function handle_initiate_mail_integration( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage mail integrations for this organisation.', 'wp-phishing' );
		}

		$provider_enum   = MailIntegrationProvider::tryFrom( $this->post_field( 'provider' ) );
		$capability_enum = MailIntegrationCapability::tryFrom( $this->post_field( 'capability' ) );

		if ( null === $provider_enum || null === $capability_enum ) {
			return __( 'Choose a valid provider and capability.', 'wp-phishing' );
		}

		$this->mail_integrations->initiate( $organisation_uuid, $provider_enum, $capability_enum, $user_id );

		return null;
	}

	private function handle_verify_mail_integration(): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage mail integrations for this organisation.', 'wp-phishing' );
		}

		$integration = $this->mail_integrations->get( $organisation_uuid, $this->post_field( 'integration_uuid' ) );

		if ( null === $integration ) {
			return __( 'Integration not found.', 'wp-phishing' );
		}

		if ( MailIntegrationProvider::Microsoft365 === $integration->provider ) {
			$this->mail_integrations->verify_microsoft( $integration, $this->post_field( 'tenant_id' ) );
		} else {
			$this->mail_integrations->verify_google( $integration, $this->post_field( 'primary_domain' ), $this->post_field( 'test_mailbox' ) );
		}

		return null;
	}

	private function handle_revoke_mail_integration( int $user_id ): ?string {
		$organisation_uuid = $this->post_field( 'organisation_uuid' );

		if ( ! $this->tenant_guard->has_role( $organisation_uuid, MembershipRole::Owner, MembershipRole::Administrator ) ) {
			return __( 'You do not have permission to manage mail integrations for this organisation.', 'wp-phishing' );
		}

		$integration = $this->mail_integrations->get( $organisation_uuid, $this->post_field( 'integration_uuid' ) );

		if ( null === $integration ) {
			return __( 'Integration not found.', 'wp-phishing' );
		}

		$this->mail_integrations->revoke( $integration, $user_id );

		return null;
	}

	// -----------------------------------------------------------------------------------
	// Company workspace (read) - reuses every CompanyWorkspaceRenderer tab method the admin
	// Companies workspace does (Admin\AdminBootstrap::render_company_workspace()), with a
	// customer-side WorkspaceContext; the tab bar itself is bare markup rather than WP-admin's
	// nav-tab-wrapper, since this route renders outside wp-admin entirely.
	// -----------------------------------------------------------------------------------

	private function handle_company(): CustomerPageResult {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( CustomerPortalUrls::url( 'login' ) );
			exit;
		}

		$organisation = $this->requested_company();

		if ( null === $organisation ) {
			return $this->render_result( __( 'Company', 'wp-phishing' ), '<p>' . esc_html__( 'Company not found.', 'wp-phishing' ) . '</p>' );
		}

		$notice = null;

		if ( $this->is_post() && $this->verify_nonce( 'wpp_account_action' ) ) {
			$notice = $this->handle_account_action();
		}

		return $this->render_company_page( $organisation, $notice );
	}

	/**
	 * Resolves and authorises the `organisation_uuid` query arg shared by {@see handle_company()}
	 * and {@see render_company_shortcode()} - the request-reading half of "which company", kept
	 * separate from the not-logged-in guard (which differs between those two callers: a redirect
	 * for the raw route, {@see sign_in_prompt_fragment()} for the shortcode render).
	 */
	private function requested_company(): ?Organisation {
		$organisation_uuid = $this->get_field( 'organisation_uuid' );

		if ( '' === $organisation_uuid ) {
			return null;
		}

		$organisation = $this->organisation_service()->get_by_uuid( $organisation_uuid );

		return ( null !== $organisation && $this->tenant_guard->can_access_organisation( $organisation_uuid ) ) ? $organisation : null;
	}

	/**
	 * The GET-only counterpart to {@see handle_company()}, for {@see render_customer_shortcode()} -
	 * the not-logged-in case is already handled by that caller (via {@see GATED_SHORTCODE_ROUTES}),
	 * so this only needs to resolve the company and, if found, delegate to the same
	 * {@see render_company_page()} the raw route uses.
	 */
	private function render_company_shortcode(): CustomerPageResult {
		$organisation = $this->requested_company();

		if ( null === $organisation ) {
			return $this->render_result( __( 'Company', 'wp-phishing' ), '<p>' . esc_html__( 'Company not found.', 'wp-phishing' ) . '</p>' );
		}

		return $this->render_company_page( $organisation, null );
	}

	private function render_company_page( Organisation $organisation, ?string $notice ): CustomerPageResult {
		$tabs        = CompanyWorkspaceRenderer::TABS;
		$current_tab = $this->current_workspace_tab( $tabs );

		$context = new WorkspaceContext(
			is_admin: false,
			nonce_action: 'wpp_account_action',
			action_field_name: 'wpp_account_action',
			url_for: static fn ( string $tab, array $extra = array() ): string => CustomerPortalUrls::url(
				'company',
				array_merge(
					array(
						'organisation_uuid' => $organisation->organisation_uuid,
						'tab'               => $tab,
					),
					$extra
				)
			)
		);

		$body  = $this->error_html( $notice );
		$body .= '<p><a href="' . esc_url( CustomerPortalUrls::url( 'account' ) ) . '">&larr; ' . esc_html__( 'Back to My account', 'wp-phishing' ) . '</a></p>';
		$body .= '<h2>' . esc_html( $organisation->name ) . '</h2>';

		$body .= '<ul>';

		foreach ( $tabs as $slug => $label ) {
			$body .= '<li' . ( $slug === $current_tab ? ' style="font-weight:bold"' : '' ) . '><a href="' . esc_url( $context->url( $slug ) ) . '">' . esc_html( $label ) . '</a></li>';
		}

		$body .= '</ul>';

		$panel = match ( $current_tab ) {
			'domains' => $this->workspace->render_domains_tab( $organisation, $context ),
			'groups' => $this->workspace->render_groups_tab( $organisation, $context ),
			'recipients' => $this->workspace->render_recipients_tab( $organisation, $context ),
			'import' => $this->workspace->render_import_tab( $organisation, $context ),
			'suppressions' => $this->workspace->render_suppressions_tab( $organisation, $context ),
			'mail-integrations' => $this->workspace->render_mail_integrations_tab( $organisation, $context ),
			// Unreachable in practice - current_workspace_tab() only ever returns a key already
			// present in $tabs - kept only because $current_tab's static type is a plain string,
			// not an enum, so PHPStan cannot see that guarantee itself.
			default => $this->workspace->render_domains_tab( $organisation, $context ),
		};

		$body .= $panel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $panel is HTML already assembled from esc_*()-escaped fragments by CompanyWorkspaceRenderer's own render_*_tab() methods.

		return new CustomerPageResult( $organisation->name, $body );
	}

	/**
	 * @param array<string,string> $tabs slug => label
	 */
	private function current_workspace_tab( array $tabs ): string {
		$requested = $this->get_field( 'tab' );

		return array_key_exists( $requested, $tabs ) ? $requested : (string) array_key_first( $tabs );
	}

	private function render_account_page( ?string $notice ): CustomerPageResult {
		$user_id     = get_current_user_id();
		$user        = wp_get_current_user();
		$service     = $this->organisation_service();
		$memberships = $service->get_memberships_for_user( $user_id );

		$active_memberships  = array_values( array_filter( $memberships, static fn ( OrganisationMembership $m ): bool => MembershipStatus::Active === $m->status ) );
		$pending_invitations = array_values( array_filter( $memberships, static fn ( OrganisationMembership $m ): bool => MembershipStatus::Invited === $m->status ) );

		$body = $this->error_html( $notice );

		// Deliberately CustomerPortalUrls::url( 'logout' ) is NEVER used here - 'logout' is
		// excluded from SHORTCODE_ROUTES precisely so it can never be mapped to a themed page:
		// reloading a mapped Account/Company page after signing out would show it still signed in
		// (a themed page has no way to reflect the just-ended session), so this must always hit
		// its own raw route regardless of any Settings > Portal Pages mapping.
		$body .= '<p>' . sprintf(
			/* translators: %s: display name */
			esc_html__( 'Signed in as %s.', 'wp-phishing' ),
			esc_html( $user->display_name )
		) . ' <a href="' . esc_url( home_url( '/phishing/logout/' ) ) . '">' . esc_html__( 'Sign out', 'wp-phishing' ) . '</a></p>';

		if ( array() !== $pending_invitations ) {
			$body .= '<h2>' . esc_html__( 'Pending invitations', 'wp-phishing' ) . '</h2>';

			foreach ( $pending_invitations as $membership ) {
				$organisation = $service->get_by_uuid( $membership->organisation_uuid );

				if ( null === $organisation ) {
					continue;
				}

				$body .= '<form method="post" style="display:inline">'
					. wp_nonce_field( 'wpp_account_action', '_wpnonce', true, false )
					. '<input type="hidden" name="wpp_account_action" value="accept_invitation">'
					. '<input type="hidden" name="organisation_uuid" value="' . esc_attr( $organisation->organisation_uuid ) . '">'
					. '<p>' . esc_html( $organisation->name ) . ' (' . esc_html( $membership->role->value ) . ') '
					. '<button type="submit">' . esc_html__( 'Accept invitation', 'wp-phishing' ) . '</button></p>'
					. '</form>';
			}
		}

		$body .= '<h2>' . esc_html__( 'Your organisations', 'wp-phishing' ) . '</h2>';

		if ( array() === $active_memberships ) {
			$body .= '<p>' . esc_html__( 'You do not belong to any organisation yet.', 'wp-phishing' ) . '</p>';
		}

		foreach ( $active_memberships as $membership ) {
			$organisation = $service->get_by_uuid( $membership->organisation_uuid );

			if ( null === $organisation ) {
				continue;
			}

			$body .= $this->render_organisation_section( $organisation->organisation_uuid, $organisation->name, $membership->role );
		}

		$body .= '<h3>' . esc_html__( 'Establish a new organisation', 'wp-phishing' ) . '</h3>'
			. '<form method="post">'
			. wp_nonce_field( 'wpp_account_action', '_wpnonce', true, false )
			. '<input type="hidden" name="wpp_account_action" value="create_organisation">'
			. '<p><label>' . esc_html__( 'Organisation name', 'wp-phishing' ) . '<br><input type="text" name="name" required></label></p>'
			. '<p><button type="submit">' . esc_html__( 'Create organisation', 'wp-phishing' ) . '</button></p>'
			. '</form>';

		return new CustomerPageResult( __( 'My account', 'wp-phishing' ), $body );
	}

	/**
	 * A summary linking into the full company workspace ({@see handle_company()}) rather than
	 * inlining every organisation's domains/groups/recipients/etc. on this one page - unusable once
	 * a customer belongs to more than a couple of organisations, and duplicative now that the
	 * workspace covers everything this section used to render inline.
	 */
	private function render_organisation_section( string $organisation_uuid, string $name, MembershipRole $role ): string {
		$section = '<h3>' . esc_html( $name ) . ' <small>(' . esc_html( $role->value ) . ')</small></h3>';

		$workspace_url = CustomerPortalUrls::url( 'company', array( 'organisation_uuid' => $organisation_uuid ) );

		return $section . '<p><a href="' . esc_url( $workspace_url ) . '">' . esc_html__( 'Manage this organisation', 'wp-phishing' ) . '</a></p>';
	}

	// -----------------------------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------------------------

	private function organisation_service(): OrganisationServiceInterface {
		$service = OrganisationPlatformDiscovery::resolve();

		if ( null === $service ) {
			throw new \RuntimeException( esc_html( 'No organisation service is registered.' ) );
		}

		return $service;
	}

	private function is_post(): bool {
		return isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
	}

	private function post_field( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- every caller verifies the relevant action nonce itself (see verify_nonce()) before reading any field.
		return isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : '';
	}

	private function post_checked( string $name ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see post_field().
		return ! empty( $_POST[ $name ] );
	}

	private function get_field( string $name ): string {
		return isset( $_GET[ $name ] ) && is_string( $_GET[ $name ] ) ? sanitize_text_field( wp_unslash( $_GET[ $name ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only token lookup (email verification / password reset links), not a state-changing action.
	}

	private function verify_nonce( string $action ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- this method *is* the nonce verification.
		$nonce  = isset( $_POST['_wpnonce'] ) && is_string( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
		$result = wp_verify_nonce( $nonce, $action );

		// wp_verify_nonce() returns 1 for a nonce in its first 12-hour "tick" and 2 for one in its
		// second - both are legitimately still valid; only `false` (or 0) means invalid/expired.
		return 1 === $result || 2 === $result;
	}

	private function error_html( ?string $message ): string {
		return null !== $message ? '<p style="color:red">' . esc_html( $message ) . '</p>' : '';
	}

	/**
	 * Empty when Turnstile is unconfigured - {@see Turnstile::verify()} fails open in that case
	 * too, so omitting the widget here is purely cosmetic (no point showing a challenge that
	 * verification would never actually check).
	 */
	private function turnstile_widget_html(): string {
		if ( ! Turnstile::configured() ) {
			return '';
		}

		wp_enqueue_script( 'wpp-turnstile', Turnstile::WIDGET_SCRIPT_URL, array(), null, array( 'strategy' => 'async' ) ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Cloudflare serves this URL unversioned by design (their own embed snippet never appends one); Cloudflare's own CDN handles cache-busting.

		ob_start();
		wp_print_scripts( array( 'wpp-turnstile' ) );
		$script_tag = ob_get_clean();

		return ( false !== $script_tag ? $script_tag : '' ) . '<div class="cf-turnstile" data-sitekey="' . esc_attr( Turnstile::site_key() ) . '"></div>';
	}

	private function render_result( string $title, string $body ): CustomerPageResult {
		return new CustomerPageResult( $title, $body );
	}
}
