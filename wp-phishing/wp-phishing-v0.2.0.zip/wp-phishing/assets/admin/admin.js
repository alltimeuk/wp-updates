/**
 * Admin screen behaviour: tab navigation shared by every tabbed screen (Settings, and the
 * Companies workspace) - matches the nav-tab/data-tab pattern already established in
 * alltimeuk/wp-reconnaissance and alltimeuk/wp-questionnaires' own Settings screens.
 */
( function ( $ ) {
	'use strict';

	$( function () {
		$( document ).on( 'click', '.wpp-nav-tabs .nav-tab', function ( e ) {
			e.preventDefault();

			var tab = $( this ).data( 'tab' );

			$( this ).closest( '.wpp-nav-tabs' ).find( '.nav-tab' ).removeClass( 'nav-tab-active' );
			$( this ).addClass( 'nav-tab-active' );

			var $panels = $( this ).closest( '.wpp-tab-container' ).find( '.wpp-tab-panel' );
			$panels.addClass( 'wpp-hidden' );
			$panels.filter( '#tab-' + tab ).removeClass( 'wpp-hidden' );

			if ( window.history && window.history.replaceState ) {
				var url = new URL( window.location.href );
				url.searchParams.set( 'tab', tab );
				window.history.replaceState( null, '', url.toString() );
			}
		} );

		// Deep-linking: ?tab=slug opens directly on that tab, for every wpp-nav-tabs bar on the page.
		var initial = new URLSearchParams( window.location.search ).get( 'tab' );

		if ( initial && $( '#tab-' + initial ).length ) {
			$( '.wpp-nav-tabs .nav-tab[data-tab="' + initial + '"]' ).trigger( 'click' );
		}
	} );
}( jQuery ) );
