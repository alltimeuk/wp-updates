<?php
/**
 * Issues and consumes short-lived, single-use, hashed tokens for email verification and
 * password reset, per Section 18.1.
 *
 * Only the SHA-256 hash of a token is ever persisted; the raw value exists only in memory long
 * enough to be embedded in the verification/reset link, matching the "do not store plaintext
 * verification or reset tokens" requirement.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Data\Schema;

final class TokenService {

	private const RAW_TOKEN_BYTES = 32;

	/**
	 * @return string The raw token. Callers must embed this in a URL/email immediately - it
	 *                 cannot be recovered once this call returns.
	 */
	public function issue( int $user_id, TokenType $type, int $ttl_seconds ): string {
		global $wpdb;

		$raw  = bin2hex( random_bytes( self::RAW_TOKEN_BYTES ) );
		$hash = hash( 'sha256', $raw );

		// Invalidate any outstanding tokens of this type for this user - only the most recently
		// issued token should ever be usable.
		$this->invalidate_outstanding( $user_id, $type );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'auth_tokens' ),
			array(
				'user_id'    => $user_id,
				'token_hash' => $hash,
				'type'       => $type->value,
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + $ttl_seconds ),
				'created_at' => current_time( 'mysql', true ),
			)
		);

		return $raw;
	}

	/**
	 * Validates and consumes a raw token. Returns the associated user ID once, and only once -
	 * a second call with the same token always returns null, even if it races the first call:
	 * the check (unused, right type, not expired) and the transition to used happen in one
	 * atomic conditional UPDATE, not a SELECT followed by a separate UPDATE - two concurrent
	 * calls with the same token can otherwise both pass the SELECT before either UPDATE commits,
	 * and both return the same user ID. WordPress's $wpdb->update() helper only builds equality
	 * WHERE clauses, which can't express `used_at IS NULL`, hence the raw prepared query - the
	 * same discipline {@see \Alltime\WPReconnaissance\Data\Repositories\ScopeRepository::verify_and_authorise()}
	 * already uses for DNS verification, extended here to a condition that helper can't express.
	 */
	public function consume( string $raw_token, TokenType $type ): ?int {
		global $wpdb;

		$table = Schema::table( 'auth_tokens' );
		$hash  = hash( 'sha256', $raw_token );
		$now   = gmdate( 'Y-m-d H:i:s' );

		$claimed = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"UPDATE `{$table}` SET used_at = %s WHERE token_hash = %s AND type = %s AND used_at IS NULL AND expires_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$hash,
				$type->value,
				$now
			)
		);

		if ( ! $claimed ) {
			return null;
		}

		// Safe to read now without a race: this token is already marked used above, so no
		// concurrent caller can still be mid-flight expecting to win the same claim.
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT user_id FROM `{$table}` WHERE token_hash = %s AND type = %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$hash,
				$type->value
			),
			ARRAY_A
		);

		return null !== $row ? (int) $row['user_id'] : null;
	}

	/**
	 * Deletes every outstanding token belonging to any of the given users - only intended caller
	 * is {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}, run before the
	 * customer accounts themselves are deleted (`auth_tokens.user_id` has no real `FOREIGN KEY`
	 * constraint enforcing that ordering). `0` (nothing left) is a benign, idempotent outcome;
	 * only `false` is a genuine failure.
	 *
	 * @param int[] $user_ids
	 */
	public function delete_by_user_ids( array $user_ids ): int {
		if ( array() === $user_ids ) {
			return 0;
		}

		global $wpdb;

		$table        = Schema::table( 'auth_tokens' );
		$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );

		// $table/$placeholders are fixed, internally derived identifiers; the %d count in
		// $placeholders and the spread ...$user_ids args are both derived from the same
		// count($user_ids), so they always match even though phpcs cannot verify that statically.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE user_id IN ({$placeholders})", ...$user_ids ) );

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( 'Failed to delete auth tokens.' ) );
		}

		return (int) $deleted;
	}

	private function invalidate_outstanding( int $user_id, TokenType $type ): void {
		global $wpdb;

		$table = Schema::table( 'auth_tokens' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array( 'used_at' => current_time( 'mysql', true ) ),
			array(
				'user_id' => $user_id,
				'type'    => $type->value,
			)
		);
	}
}
