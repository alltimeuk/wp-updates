<?php
/**
 * Persistence for pending daily-digest notification entries against
 * `wpr_notification_digest_entries`, per Section 33.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Notifications\DigestEntry;

final class DigestEntryRepository {

	/**
	 * Same idempotency-key discipline as the immediate-delivery mail queue (Section 22.5): a
	 * hook firing twice, or a cron tick re-scanning the same still-relevant state tomorrow, must
	 * never add the same line to a customer's digest twice. A no-op if the key already exists.
	 */
	public function add_if_new( int $organisation_id, int $user_id, string $idempotency_key, string $subject, string $summary ): void {
		global $wpdb;

		if ( $this->exists( $idempotency_key ) ) {
			return;
		}

		$table = Schema::table( 'notification_digest_entries' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'organisation_id' => $organisation_id,
				'user_id'         => $user_id,
				'idempotency_key' => $idempotency_key,
				'subject'         => $subject,
				'summary'         => $summary,
				'created_at'      => $now,
			)
		);
	}

	private function exists( string $idempotency_key ): bool {
		global $wpdb;

		$table = Schema::table( 'notification_digest_entries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return null !== $wpdb->get_var( $wpdb->prepare( "SELECT id FROM `{$table}` WHERE idempotency_key = %s", $idempotency_key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Every account with at least one unsent digest entry - the daily digest sweep's candidate
	 * list.
	 *
	 * @return int[] User IDs.
	 */
	public function find_user_ids_with_pending_entries(): array {
		global $wpdb;

		$table = Schema::table( 'notification_digest_entries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_col( "SELECT DISTINCT user_id FROM `{$table}` WHERE sent_at IS NULL" );

		return array_map( 'intval', null !== $rows ? $rows : array() );
	}

	/**
	 * @return DigestEntry[]
	 */
	public function find_pending_by_user( int $user_id ): array {
		global $wpdb;

		$table = Schema::table( 'notification_digest_entries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE user_id = %d AND sent_at IS NULL ORDER BY created_at ASC", $user_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return array_map( array( DigestEntry::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @param int[] $ids
	 */
	public function mark_sent( array $ids ): void {
		global $wpdb;

		if ( array() === $ids ) {
			return;
		}

		$table        = Schema::table( 'notification_digest_entries' );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"UPDATE `{$table}` SET sent_at = %s WHERE id IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_merge( array( current_time( 'mysql', true ) ), $ids )
			)
		);
	}

	/**
	 * Deletes every digest entry belonging to an organisation - only intended caller is
	 * {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}. `0` (nothing left)
	 * is a benign, idempotent outcome; only `false` is a genuine failure.
	 */
	public function delete_by_organisation( int $organisation_id ): int {
		global $wpdb;

		$table = Schema::table( 'notification_digest_entries' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE organisation_id = %d", $organisation_id ) );

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( "Failed to delete digest entries for organisation {$organisation_id}." ) );
		}

		return (int) $deleted;
	}
}
