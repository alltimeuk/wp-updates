<?php
/**
 * Service discovery for the shared contact platform, per Section 6.1.2/6.1.3.
 *
 * "Cross-plugin calls shall use PHP services, actions or filters, not direct writes to another
 * plugin's tables" and "Service discovery shall be deterministic and version checked. Plugins
 * shall fail safely if a required contract version is unavailable." A WordPress filter is the
 * discovery mechanism precisely because it works the same way whether the provider and consumer
 * are the same plugin (today) or two independent ones (once this is extracted): whichever plugin
 * registers the filter first wins, and every consumer resolves through this class rather than
 * ever constructing {@see ContactService} directly.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class ContactPlatformDiscovery {

	private const FILTER = 'alltime_customer_platform_contact_service';

	/**
	 * The contract version this class of provider satisfies. Bump the major segment only for a
	 * breaking change to {@see ContactServiceInterface} - {@see resolve()} checks the major
	 * segment only, so minor/patch bumps stay compatible with existing consumers.
	 */
	public const CONTRACT_VERSION = '1.1.0';

	/**
	 * Registers a service instance as the platform's contact-service provider. Idempotent by
	 * WordPress filter semantics: the first registration wins, later ones are ignored - only one
	 * plugin should ever own this data.
	 */
	public static function provide( ContactServiceInterface $service, string $version = self::CONTRACT_VERSION ): void {
		add_filter(
			self::FILTER,
			static fn ( mixed $current ): mixed => $current ?? array(
				'service' => $service,
				'version' => $version,
			)
		);
	}

	/**
	 * Resolves the registered contact service, or null if none is registered or the registered
	 * provider's major version does not satisfy $required_major_version. Callers must treat a
	 * null return as "the platform is unavailable" and degrade gracefully - never assume the
	 * service exists.
	 */
	public static function resolve( string $required_major_version = '1' ): ?ContactServiceInterface {
		$registration = apply_filters( self::FILTER, null );

		if ( ! is_array( $registration ) || ! ( $registration['service'] ?? null ) instanceof ContactServiceInterface ) {
			return null;
		}

		$provided_version = (string) ( $registration['version'] ?? '' );

		if ( ! str_starts_with( $provided_version, $required_major_version . '.' ) ) {
			return null;
		}

		return $registration['service'];
	}
}
