<?php
/**
 * The concrete {@see ContactServiceInterface} implementation currently shipped inside
 * WP Reconnaissance. Never instantiated directly by consuming code - always go through
 * {@see ContactPlatformDiscovery::resolve()}, exactly as an external plugin would once this
 * becomes its own component.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\IdentityType;
use Alltime\CustomerPlatform\Repositories\ConsentRepository;
use Alltime\CustomerPlatform\Repositories\ContactIdentityRepository;
use Alltime\CustomerPlatform\Repositories\ContactOrganisationRepository;
use Alltime\CustomerPlatform\Repositories\ContactRepository;
use Alltime\CustomerPlatform\Repositories\InteractionRepository;
use Alltime\CustomerPlatform\Repositories\PreferenceRepository;
use Alltime\CustomerPlatform\Repositories\VisitorContextRepository;

final class ContactService implements ContactServiceInterface {

	public function __construct(
		private readonly ContactRepository $contacts = new ContactRepository(),
		private readonly ContactIdentityRepository $identities = new ContactIdentityRepository(),
		private readonly ContactOrganisationRepository $organisations = new ContactOrganisationRepository(),
		private readonly InteractionRepository $interactions = new InteractionRepository(),
		private readonly ConsentRepository $consents = new ConsentRepository(),
		private readonly PreferenceRepository $preferences = new PreferenceRepository(),
		private readonly VisitorContextRepository $visitor_contexts = new VisitorContextRepository()
	) {}

	public function resolve_visitor_context(): VisitorContext {
		if ( ! is_user_logged_in() ) {
			return new VisitorContext( null, false );
		}

		$contact = $this->get_contact_for_user( get_current_user_id() );

		return new VisitorContext( $contact?->id, null !== $contact );
	}

	public function create_or_update_contact( ContactInput $input, PurposeContext $purpose ): ContactResult {
		$normalised_email  = strtolower( trim( $input->email ) );
		$existing_identity = $this->identities->find_by_value( IdentityType::Email, $normalised_email );

		if ( null !== $existing_identity ) {
			$contact = $this->contacts->update_names( $existing_identity->contact_id, $input->given_name, $input->family_name );

			if ( null !== $input->organisation_name ) {
				$this->organisations->upsert_primary( $contact->id, $input->organisation_name );
			}

			do_action( 'alltime_contact_updated', $contact->id, array( 'given_name', 'family_name' ), $purpose );

			return new ContactResult( $contact, false );
		}

		$contact = $this->contacts->create( $input->given_name, $input->family_name );
		$this->identities->create( $contact->id, IdentityType::Email, $normalised_email, true, $purpose->product_id );

		if ( null !== $input->telephone ) {
			$this->identities->create( $contact->id, IdentityType::Telephone, $input->telephone, false, $purpose->product_id );
		}

		if ( null !== $input->organisation_name ) {
			$this->organisations->upsert_primary( $contact->id, $input->organisation_name );
		}

		do_action( 'alltime_contact_created', $contact->id, $purpose );

		return new ContactResult( $contact, true );
	}

	public function link_wordpress_user( int $contact_id, int $user_id ): void {
		$this->contacts->link_wp_user( $contact_id, $user_id );
	}

	public function record_interaction( int $contact_id, InteractionInput $interaction ): int {
		$id = $this->interactions->record( $contact_id, $interaction );

		do_action( 'alltime_interaction_recorded', $id, $contact_id, $interaction->product_id );

		return $id;
	}

	public function record_consent( int $contact_id, ConsentInput $consent ): int {
		$id = $this->consents->record( $contact_id, $consent );

		do_action( 'alltime_consent_changed', $contact_id, $consent->purpose, $consent->state->value );

		return $id;
	}

	public function get_contact_for_user( int $user_id ): ?Contact {
		return $this->contacts->find_by_wp_user( $user_id );
	}

	public function get_contact_for_email( string $email ): ?Contact {
		$normalised_email = strtolower( trim( $email ) );
		$identity         = $this->identities->find_by_value( IdentityType::Email, $normalised_email );

		return null !== $identity ? $this->contacts->find( $identity->contact_id ) : null;
	}

	/**
	 * Permanently deletes a contact and everything linked to it - only intended caller is
	 * {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}, which only reaches
	 * this once an operator has explicitly chosen to purge the organisation it belongs to
	 * (Section 6.1.3's cross-plugin-boundary rule: another plugin never writes `atcp_*` tables
	 * directly, it calls this). Deliberately excludes `atcp_privacy_requests` (keyed purely by
	 * email, no contact_id column to sever) and `atcp_contact_merge_log` (a historical audit trail
	 * that survives exactly like `wpr_audit_log` does; its surviving/merged contact id columns
	 * going dangling here is the same already-accepted, pre-existing pattern as a merge itself
	 * leaving them dangling once either contact is later deleted by any other means).
	 *
	 * Every delete in the cascade is unconditional (never a find-or-fail guard first), and 0 rows
	 * affected is treated as a benign no-op throughout - a safe retry after a partial failure must
	 * be able to re-run against tables already emptied by the first attempt.
	 */
	public function delete_contact( int $contact_id ): void {
		global $wpdb;

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		try {
			$this->interactions->delete_by_contact( $contact_id );
			$this->consents->delete_by_contact( $contact_id );
			$this->preferences->delete_by_contact( $contact_id );
			$this->identities->delete_by_contact( $contact_id );
			$this->organisations->delete_by_contact( $contact_id );
			$this->visitor_contexts->delete_by_contact( $contact_id );
			$this->contacts->delete( $contact_id );

			$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		} catch ( \Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			throw $exception;
		}

		do_action( 'alltime_contact_deleted', $contact_id );
	}
}
