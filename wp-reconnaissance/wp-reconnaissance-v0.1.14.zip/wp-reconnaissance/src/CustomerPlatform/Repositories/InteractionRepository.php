<?php
/**
 * Persistence for interactions against `atcp_interactions`, per Section 8.0.2.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\InteractionInput;
use Alltime\CustomerPlatform\Schema;

final class InteractionRepository {

	public function record( int $contact_id, InteractionInput $interaction ): int {
		global $wpdb;

		$table = Schema::table( 'interactions' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'         => $contact_id,
				'organisation_id'    => $interaction->organisation_id,
				'product_id'         => $interaction->product_id,
				'interaction_type'   => $interaction->interaction_type,
				'source_object_type' => $interaction->source_object_type,
				'source_object_id'   => $interaction->source_object_id,
				'occurred_at'        => ( $interaction->occurred_at ?? new \DateTimeImmutable() )->format( 'Y-m-d H:i:s' ),
				'campaign_reference' => $interaction->campaign_reference,
				'purpose'            => $interaction->purpose,
				'created_at'         => $now,
			)
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Deletes every interaction belonging to a contact - only intended caller is
	 * {@see \Alltime\CustomerPlatform\ContactService::delete_contact()}. 0 rows affected is a
	 * benign, idempotent outcome; only `false` is a genuine failure.
	 */
	public function delete_by_contact( int $contact_id ): int {
		global $wpdb;

		$table   = Schema::table( 'interactions' );
		$deleted = $wpdb->delete( $table, array( 'contact_id' => $contact_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( "Failed to delete interactions for contact {$contact_id}." ) );
		}

		return (int) $deleted;
	}
}
