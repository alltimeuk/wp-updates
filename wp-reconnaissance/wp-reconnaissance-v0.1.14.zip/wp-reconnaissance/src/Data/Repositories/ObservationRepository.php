<?php
/**
 * Persistence for observations and their per-collector evidence, per Section 8.5 and Section 9.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Observation;

final class ObservationRepository {

	public function find( int $id ): ?Observation {
		global $wpdb;

		$table = Schema::table( 'observations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Observation::from_row( $row ) : null;
	}

	/**
	 * The most recent observation for a scope, used as the basis for a new report.
	 */
	public function find_latest_by_scope( int $scope_id ): ?Observation {
		global $wpdb;

		$table = Schema::table( 'observations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE scope_id = %d ORDER BY id DESC LIMIT 1", $scope_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return null !== $row ? Observation::from_row( $row ) : null;
	}

	/**
	 * The most recent observation for a scope before the given one, used by the change engine
	 * to compare against the preceding successful assessment.
	 */
	public function find_previous( int $scope_id, int $before_observation_id ): ?Observation {
		global $wpdb;

		$table = Schema::table( 'observations' );

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE scope_id = %d AND id < %d ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scope_id,
				$before_observation_id
			),
			ARRAY_A
		);

		return null !== $row ? Observation::from_row( $row ) : null;
	}

	/**
	 * Idempotent on job_id: re-ingesting the same job's evidence updates the existing
	 * observation rather than creating a duplicate (Section 28, Section 34 acceptance
	 * criterion 10).
	 *
	 * @param array<string,string>           $collector_versions
	 * @param string[]                       $limitations
	 * @param string[]                       $failed_collectors
	 * @param array<int,array<string,mixed>> $evidence_rows Decoded evidence.schema.json `collectors` entries.
	 */
	public function ingest(
		int $scope_id,
		int $job_id,
		\DateTimeImmutable $observed_at,
		array $collector_versions,
		string $schema_version,
		string $collection_status,
		?string $raw_evidence_ref,
		array $limitations,
		array $failed_collectors,
		string $integrity_hash,
		array $evidence_rows
	): Observation {
		global $wpdb;

		$table = Schema::table( 'observations' );

		$existing_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT id FROM `{$table}` WHERE job_id = %d", $job_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		$data = array(
			'scope_id'           => $scope_id,
			'job_id'             => $job_id,
			'observed_at'        => $observed_at->format( 'Y-m-d H:i:s' ),
			'collector_versions' => wp_json_encode( $collector_versions ),
			'schema_version'     => $schema_version,
			'collection_status'  => $collection_status,
			'raw_evidence_ref'   => $raw_evidence_ref,
			'limitations'        => wp_json_encode( $limitations ),
			'failed_collectors'  => wp_json_encode( $failed_collectors ),
			'integrity_hash'     => $integrity_hash,
		);

		if ( null !== $existing_id ) {
			$observation_id = (int) $existing_id;
			$wpdb->update( $table, $data, array( 'id' => $observation_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$this->delete_evidence_rows( $observation_id );
		} else {
			$data['created_at'] = current_time( 'mysql', true );
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$observation_id = (int) $wpdb->insert_id;
		}

		$this->insert_evidence_rows( $observation_id, $evidence_rows );

		$observation = $this->find( $observation_id );

		if ( null === $observation ) {
			throw new \RuntimeException( esc_html( "Observation {$observation_id} was expected to exist but could not be loaded." ) );
		}

		return $observation;
	}

	/**
	 * Observations older than the cutoff that still have a raw evidence file reference - the
	 * retention sweep's candidate list for {@see \Alltime\WPReconnaissance\Retention\RetentionService},
	 * which deletes the referenced file via EvidenceStorage before calling
	 * {@see clear_evidence_ref()}/{@see anonymise_evidence_rows()} here.
	 *
	 * @return array<int,array{id:int,raw_evidence_ref:string}>
	 */
	public function find_stale_with_evidence_ref( \DateTimeImmutable $cutoff ): array {
		global $wpdb;

		$table = Schema::table( 'observations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT id, raw_evidence_ref FROM `{$table}` WHERE observed_at < %s AND raw_evidence_ref IS NOT NULL", $cutoff->format( 'Y-m-d H:i:s' ) ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return array_map(
			static fn ( array $row ): array => array(
				'id'               => (int) $row['id'],
				'raw_evidence_ref' => (string) $row['raw_evidence_ref'],
			),
			null !== $rows ? $rows : array()
		);
	}

	/**
	 * Every observation belonging to any of the given scopes, id plus its raw evidence file
	 * reference (if any) - for {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}
	 * to capture before it deletes these rows outright, so the referenced evidence files can still
	 * be found and removed afterwards even though the row that named them is gone.
	 *
	 * @param int[] $scope_ids
	 * @return array<int,array{id:int,raw_evidence_ref:?string}>
	 */
	public function find_by_scope_ids( array $scope_ids ): array {
		if ( array() === $scope_ids ) {
			return array();
		}

		global $wpdb;

		$table        = Schema::table( 'observations' );
		$placeholders = implode( ',', array_fill( 0, count( $scope_ids ), '%d' ) );

		// $table/$placeholders are fixed, internally derived identifiers; the %d count in
		// $placeholders and the spread ...$scope_ids args are both derived from the same
		// count($scope_ids), so they always match even though phpcs cannot verify that statically.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, raw_evidence_ref FROM `{$table}` WHERE scope_id IN ({$placeholders})", ...$scope_ids ), ARRAY_A );

		return array_map(
			static fn ( array $row ): array => array(
				'id'               => (int) $row['id'],
				'raw_evidence_ref' => null !== $row['raw_evidence_ref'] ? (string) $row['raw_evidence_ref'] : null,
			),
			null !== $rows ? $rows : array()
		);
	}

	/**
	 * A genuine hard delete of `wpr_evidence` rows, unlike {@see anonymise_evidence_rows()} (which
	 * only NULLs the payload and keeps the row for change-history purposes) - only intended caller
	 * is {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}, run before
	 * {@see delete_by_scope_ids()} so the parent observation rows still exist to filter by.
	 *
	 * @param int[] $observation_ids
	 */
	public function delete_evidence_by_observation_ids( array $observation_ids ): int {
		if ( array() === $observation_ids ) {
			return 0;
		}

		global $wpdb;

		$table        = Schema::table( 'evidence' );
		$placeholders = implode( ',', array_fill( 0, count( $observation_ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE observation_id IN ({$placeholders})", ...$observation_ids ) );

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( 'Failed to delete evidence rows.' ) );
		}

		return (int) $deleted;
	}

	/**
	 * Deletes every observation belonging to any of the given scopes - only intended caller is
	 * {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}, run only after
	 * {@see delete_evidence_by_observation_ids()} has already cleared their evidence rows.
	 *
	 * @param int[] $scope_ids
	 */
	public function delete_by_scope_ids( array $scope_ids ): int {
		if ( array() === $scope_ids ) {
			return 0;
		}

		global $wpdb;

		$table        = Schema::table( 'observations' );
		$placeholders = implode( ',', array_fill( 0, count( $scope_ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE scope_id IN ({$placeholders})", ...$scope_ids ) );

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( 'Failed to delete observations.' ) );
		}

		return (int) $deleted;
	}

	public function clear_evidence_ref( int $observation_id ): void {
		global $wpdb;

		$wpdb->update( Schema::table( 'observations' ), array( 'raw_evidence_ref' => null ), array( 'id' => $observation_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Clears the `data` payload for every `wpr_evidence` row belonging to the given observations
	 * - Section 26.7: "Record deletion outcomes without retaining the deleted content." Collector
	 * name, status, source and timestamps are kept, so change history stays intact; only the
	 * payload itself is gone.
	 *
	 * @param int[] $observation_ids
	 */
	public function anonymise_evidence_rows( array $observation_ids ): int {
		global $wpdb;

		if ( array() === $observation_ids ) {
			return 0;
		}

		$table        = Schema::table( 'evidence' );
		$placeholders = implode( ',', array_fill( 0, count( $observation_ids ), '%d' ) );

		// $table/$placeholders are fixed, internally derived identifiers; the %d count in
		// $placeholders and the spread ...$observation_ids args are both derived from the same
		// count($observation_ids), so they always match even though phpcs cannot verify that
		// statically.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->query( $wpdb->prepare( "UPDATE `{$table}` SET data = NULL WHERE observation_id IN ({$placeholders})", ...$observation_ids ) );
	}

	/**
	 * @return array<string,array<string,mixed>> Collector key => decoded `data` payload.
	 */
	public function evidence_data_by_collector( int $observation_id ): array {
		global $wpdb;

		$table = Schema::table( 'evidence' );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT collector, status, data FROM `{$table}` WHERE observation_id = %d", $observation_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		$by_collector = array();
		foreach ( null !== $rows ? $rows : array() as $row ) {
			$decoded                           = json_decode( (string) $row['data'], true );
			$by_collector[ $row['collector'] ] = array(
				'status' => $row['status'],
				'data'   => is_array( $decoded ) ? $decoded : array(),
			);
		}

		return $by_collector;
	}

	/**
	 * @param array<int,array<string,mixed>> $evidence_rows
	 */
	private function insert_evidence_rows( int $observation_id, array $evidence_rows ): void {
		global $wpdb;

		$table = Schema::table( 'evidence' );
		$now   = current_time( 'mysql', true );

		foreach ( $evidence_rows as $row ) {
			$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$table,
				array(
					'observation_id'    => $observation_id,
					'collector'         => $row['collector'],
					'collector_version' => $row['collector_version'],
					'status'            => $row['status'],
					'observed_at'       => gmdate( 'Y-m-d H:i:s', false !== strtotime( $row['observed_at'] ) ? strtotime( $row['observed_at'] ) : time() ),
					'source'            => $row['source'] ?? '',
					'duration_ms'       => $row['duration_ms'] ?? 0,
					'data'              => wp_json_encode( $row['data'] ?? array() ),
					'limitations'       => wp_json_encode( $row['limitations'] ?? array() ),
					'errors'            => wp_json_encode( $row['errors'] ?? array() ),
					'created_at'        => $now,
				)
			);
		}
	}

	private function delete_evidence_rows( int $observation_id ): void {
		global $wpdb;

		$table = Schema::table( 'evidence' );

		$wpdb->delete( $table, array( 'observation_id' => $observation_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}
