<?php
/**
 * Persistence for remediation task event history against `wpr_task_events`, per Section 21.3:
 * "Tasks shall remain linked to the evidence and rule version from which they were generated...
 * it must not silently destroy the task history."
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;

final class TaskEventRepository {

	public function record( int $task_id, string $event_type, ?int $actor_id = null, ?string $summary = null ): void {
		global $wpdb;

		$table = Schema::table( 'task_events' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'task_id'     => $task_id,
				'event_type'  => $event_type,
				'actor_id'    => $actor_id,
				'summary'     => $summary,
				'occurred_at' => current_time( 'mysql', true ),
			)
		);
	}

	/**
	 * @return array<int,array{event_type:string,actor_id:?int,summary:?string,occurred_at:string}>
	 */
	public function find_by_task( int $task_id ): array {
		global $wpdb;

		$table = Schema::table( 'task_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT event_type, actor_id, summary, occurred_at FROM `{$table}` WHERE task_id = %d ORDER BY id ASC", $task_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return null !== $rows ? $rows : array();
	}

	/**
	 * Deletes every event belonging to any of the given remediation tasks - only intended caller
	 * is {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}, run before the
	 * tasks themselves are deleted (`task_events.task_id` has no real `FOREIGN KEY` constraint
	 * enforcing that ordering). `0` (nothing left) is a benign, idempotent outcome; only `false` is
	 * a genuine failure.
	 *
	 * @param int[] $task_ids
	 */
	public function delete_by_task_ids( array $task_ids ): int {
		if ( array() === $task_ids ) {
			return 0;
		}

		global $wpdb;

		$table        = Schema::table( 'task_events' );
		$placeholders = implode( ',', array_fill( 0, count( $task_ids ), '%d' ) );

		// $table/$placeholders are fixed, internally derived identifiers; the %d count in
		// $placeholders and the spread ...$task_ids args are both derived from the same
		// count($task_ids), so they always match even though phpcs cannot verify that statically.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE task_id IN ({$placeholders})", ...$task_ids ) );

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( 'Failed to delete task events.' ) );
		}

		return (int) $deleted;
	}
}
