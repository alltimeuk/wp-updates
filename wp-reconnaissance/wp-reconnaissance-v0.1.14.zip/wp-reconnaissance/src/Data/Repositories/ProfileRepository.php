<?php
/**
 * Persistence for monitoring profiles against `wpr_profiles`, per Section 8.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\MonitoringProfile;

final class ProfileRepository {

	public function find( int $id ): ?MonitoringProfile {
		global $wpdb;

		$table = Schema::table( 'profiles' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? MonitoringProfile::from_row( $row ) : null;
	}

	/**
	 * Creates the built-in default profile the first time it is needed. Idempotent by name so
	 * repeated calls (e.g. from WP-CLI) don't accumulate duplicate default profiles.
	 */
	public function find_or_create_default(): MonitoringProfile {
		global $wpdb;

		$table = Schema::table( 'profiles' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE name = %s AND organisation_id IS NULL", 'Default' ), ARRAY_A );

		if ( null !== $row ) {
			return MonitoringProfile::from_row( $row );
		}

		$now = current_time( 'mysql', true );

		$data = array(
			'organisation_id'          => null,
			'name'                     => 'Default',
			'enabled_collectors'       => wp_json_encode( array( 'rdap', 'dns', 'dnssec', 'mail', 'http', 'tls', 'ct', 'subdomains', 'lookalikes' ) ),
			'collector_timeouts'       => wp_json_encode(
				array(
					'default' => 15,
					'ct'      => 30,
				)
			),
			'schedule'                 => 'daily',
			'change_thresholds'        => wp_json_encode( array() ),
			'notification_rules'       => wp_json_encode( array() ),
			'rule_packs'               => wp_json_encode( array( 'core' ) ),
			'evidence_retention_days'  => 365,
			'max_lookalike_candidates' => 500,
			'created_at'               => $now,
			'updated_at'               => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return MonitoringProfile::from_row( array_merge( $data, array( 'id' => $wpdb->insert_id ) ) );
	}

	/**
	 * Updates the per-collector timeout overrides (Settings > Collectors) - the one field of a
	 * monitoring profile currently editable from wp-admin. Every other field keeps whatever value
	 * {@see find_or_create_default()} seeded it with; there is no general-purpose update() here
	 * because nothing else is exposed to edit yet.
	 *
	 * @param array<string,int> $timeouts
	 */
	public function update_collector_timeouts( int $id, array $timeouts ): void {
		global $wpdb;

		$table = Schema::table( 'profiles' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'collector_timeouts' => wp_json_encode( $timeouts ),
				'updated_at'         => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new \RuntimeException( esc_html( "Failed to update collector timeouts for profile {$id}." ) );
		}
	}

	/**
	 * Deletes every profile belonging to an organisation - only intended caller is
	 * {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}. The global "Default"
	 * profile has `organisation_id IS NULL`, which a plain `= %d` filter never matches, so it is
	 * never at risk here. `0` (nothing left) is a benign, idempotent outcome; only `false` is a
	 * genuine failure.
	 */
	public function delete_by_organisation( int $organisation_id ): int {
		global $wpdb;

		$table = Schema::table( 'profiles' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE organisation_id = %d", $organisation_id ) );

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( "Failed to delete profiles for organisation {$organisation_id}." ) );
		}

		return (int) $deleted;
	}
}
