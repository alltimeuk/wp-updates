<?php
/**
 * Persistence for organisations against `wpr_organisations`, per Section 8.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Organisation;

final class OrganisationRepository {

	public function find( int $id ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	/**
	 * Identical to {@see find()} except it locks the row (`SELECT ... FOR UPDATE`) for the
	 * duration of the caller's transaction - used to serialise a check-then-act sequence against
	 * this organisation (see {@see \Alltime\WPReconnaissance\Entitlements\PlanEnforcementService::authorise_within_plan_limit()})
	 * so two concurrent callers can't both pass a plan-limit check before either's write commits.
	 * Callers must already be inside a transaction; calling this outside one takes no lock at all.
	 */
	public function find_for_update( int $id ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d FOR UPDATE", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	public function find_by_slug( string $slug ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE slug = %s", $slug ), ARRAY_A );

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	/**
	 * @return Organisation[]
	 */
	public function list( int $per_page = 20, int $page = 1 ): array {
		global $wpdb;

		$table  = Schema::table( 'organisations' );
		$offset = max( 0, ( max( 1, $page ) - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A );

		return array_map( array( Organisation::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function count(): int {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
	}

	public function update( int $id, string $name, string $timezone, string $status ): Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'name'       => $name,
				'timezone'   => $timezone,
				'status'     => $status,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new OrganisationRepositoryException( esc_html( "Failed to update organisation {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	/**
	 * Assigns (or clears, with null) a managed entitlement plan (Section 33) - the operator
	 * action behind the admin Organisations screen's plan selector.
	 */
	public function assign_plan( int $id, ?int $plan_id ): Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'plan_id'    => $plan_id,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new OrganisationRepositoryException( esc_html( "Failed to assign a plan to organisation {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	/**
	 * Deletes the organisation row itself - {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}
	 * is the only intended caller, and only as the very last step of a full cascade: every table
	 * that references this organisation (directly or transitively) must already be empty before
	 * this runs, since no real `FOREIGN KEY` constraint exists anywhere in this schema to enforce
	 * that. `0 === $deleted` (already gone) is a benign, idempotent outcome; only `false` is a
	 * genuine failure.
	 */
	public function delete( int $id ): void {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		$deleted = $wpdb->delete( $table, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( false === $deleted ) {
			throw new OrganisationRepositoryException( esc_html( "Failed to delete organisation {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}
	}

	private function find_or_fail( int $id ): Organisation {
		$organisation = $this->find( $id );

		if ( null === $organisation ) {
			throw new \RuntimeException( esc_html( "Organisation {$id} was expected to exist but could not be loaded." ) );
		}

		return $organisation;
	}

	public function create( string $name, string $slug, ?int $primary_contact_id = null, string $timezone = 'UTC' ): Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'name'               => $name,
			'slug'               => $slug,
			'status'             => 'active',
			'primary_contact_id' => $primary_contact_id,
			'timezone'           => $timezone,
			'created_at'         => $now,
			'updated_at'         => $now,
		);

		$inserted = $wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( false === $inserted ) {
			throw new OrganisationRepositoryException( esc_html( "Failed to create organisation \"{$name}\"." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return Organisation::from_row( array_merge( $data, array( 'id' => $wpdb->insert_id ) ) );
	}

	/**
	 * Derives a unique slug from an organisation name, appending a numeric suffix on collision.
	 */
	public function unique_slug( string $name ): string {
		$base   = sanitize_title( $name );
		$base   = '' !== $base ? $base : 'organisation';
		$slug   = $base;
		$suffix = 2;

		while ( null !== $this->find_by_slug( $slug ) ) {
			$slug = "{$base}-{$suffix}";
			++$suffix;
		}

		return $slug;
	}
}
