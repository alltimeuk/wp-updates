<?php
/**
 * Outcome of an organisation purge - a per-category row count for the audit-log summary and any
 * future CLI/UI breakdown, per the "purge organisation" design.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Organisations;

final class OrganisationPurgeSummary {

	public function __construct(
		public readonly int $scopes,
		public readonly int $jobs,
		public readonly int $observations,
		public readonly int $evidence_rows,
		public readonly int $evidence_files,
		public readonly int $findings,
		public readonly int $finding_events,
		public readonly int $remediation_tasks,
		public readonly int $task_events,
		public readonly int $reports,
		public readonly int $report_files,
		public readonly int $digest_entries,
		public readonly int $profiles,
		public readonly int $entitlements,
		public readonly int $auth_tokens,
		public readonly int $customer_accounts,
		public readonly int $contacts
	) {}

	/**
	 * A short, human-readable line for the `organisation.purged` audit-log entry - not exhaustive
	 * of every field above, just the counts an operator reviewing the log would care most about.
	 */
	public function to_summary_line(): string {
		return sprintf(
			'%d scope(s), %d job(s), %d finding(s), %d remediation task(s), %d report(s), %d customer account(s), %d contact(s).',
			$this->scopes,
			$this->jobs,
			$this->findings,
			$this->remediation_tasks,
			$this->reports,
			$this->customer_accounts,
			$this->contacts
		);
	}
}
