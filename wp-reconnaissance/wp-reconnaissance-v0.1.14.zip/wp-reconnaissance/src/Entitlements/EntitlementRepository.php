<?php
/**
 * Persistence for entitlements against `wpr_entitlements`, per Section 5.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Entitlements\Enums\EntitlementState;

final class EntitlementRepository {

	public function find( int $id ): ?Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Entitlement::from_row( $row ) : null;
	}

	/**
	 * @return Entitlement[] Most recent first.
	 */
	public function find_history( int $contact_id, string $tool_id, string $registrable_domain ): array {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE contact_id = %d AND tool_id = %s AND registrable_domain = %s ORDER BY id DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$contact_id,
				$tool_id,
				$registrable_domain
			),
			ARRAY_A
		);

		return array_map( array( Entitlement::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * The single open (Reserved) entitlement for a contact/tool/domain, if any -
	 * {@see \Alltime\WPReconnaissance\Entitlements\EntitlementPolicy} guarantees at most one can
	 * exist at a time, since a second {@see reserve()} attempt is blocked while one is open. Used
	 * by {@see \Alltime\WPReconnaissance\Entitlements\EntitlementFulfillment} to find the
	 * reservation a completed job should consume or release.
	 */
	public function find_open_reservation( int $contact_id, string $tool_id, string $registrable_domain ): ?Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE contact_id = %d AND tool_id = %s AND registrable_domain = %s AND state = %s ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$contact_id,
				$tool_id,
				$registrable_domain,
				EntitlementState::Reserved->value
			),
			ARRAY_A
		);

		return null !== $row ? Entitlement::from_row( $row ) : null;
	}

	public function reserve( int $contact_id, string $tool_id, string $registrable_domain ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );
		$now   = current_time( 'mysql', true );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'         => $contact_id,
				'tool_id'            => $tool_id,
				'registrable_domain' => $registrable_domain,
				'state'              => EntitlementState::Reserved->value,
				'reserved_at'        => $now,
				'created_at'         => $now,
				'updated_at'         => $now,
			)
		);

		if ( false === $inserted ) {
			throw new EntitlementRepositoryException( esc_html( "Failed to reserve an entitlement for contact {$contact_id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function consume( int $id ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'state'       => EntitlementState::Consumed->value,
				'consumed_at' => current_time( 'mysql', true ),
				'updated_at'  => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new EntitlementRepositoryException( esc_html( "Failed to consume entitlement {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	/**
	 * Deletes a reservation outright rather than transitioning it to some "released" state -
	 * Section 5.5: "Do not consume the entitlement for a validation failure or a job that
	 * produces no usable assessment"; a released reservation must leave no trace that would
	 * block the next genuine attempt.
	 */
	public function release( int $id ): void {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$deleted = $wpdb->delete(
			$table,
			array(
				'id'    => $id,
				'state' => EntitlementState::Reserved->value,
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( false === $deleted ) {
			throw new EntitlementRepositoryException( esc_html( "Failed to release entitlement {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}
	}

	public function grant( int $contact_id, string $tool_id, string $registrable_domain, int $granted_by, ?string $reason, ?\DateTimeImmutable $expires_at ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );
		$now   = current_time( 'mysql', true );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'         => $contact_id,
				'tool_id'            => $tool_id,
				'registrable_domain' => $registrable_domain,
				'state'              => EntitlementState::AdministrativelyGranted->value,
				'granted_by'         => $granted_by,
				'reason'             => $reason,
				'expires_at'         => $expires_at?->format( 'Y-m-d H:i:s' ),
				'created_at'         => $now,
				'updated_at'         => $now,
			)
		);

		if ( false === $inserted ) {
			throw new EntitlementRepositoryException( esc_html( "Failed to grant an entitlement for contact {$contact_id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function revoke( int $id ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'state'      => EntitlementState::Revoked->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new EntitlementRepositoryException( esc_html( "Failed to revoke entitlement {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	/**
	 * Deletes every entitlement belonging to any of the given contacts - only intended caller is
	 * {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}. `wpr_entitlements`
	 * has no `organisation_id` column, so the caller must first resolve the organisation's customer
	 * accounts to contact ids (e.g. via
	 * {@see \Alltime\WPReconnaissance\CustomerPlatform\ContactPlatformDiscovery::resolve()}). `0`
	 * (nothing left) is a benign, idempotent outcome; only `false` is a genuine failure.
	 *
	 * @param int[] $contact_ids
	 */
	public function delete_by_contact_ids( array $contact_ids ): int {
		if ( array() === $contact_ids ) {
			return 0;
		}

		global $wpdb;

		$table        = Schema::table( 'entitlements' );
		$placeholders = implode( ',', array_fill( 0, count( $contact_ids ), '%d' ) );

		// $table/$placeholders are fixed, internally derived identifiers; the %d count in
		// $placeholders and the spread ...$contact_ids args are both derived from the same
		// count($contact_ids), so they always match even though phpcs cannot verify that statically.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE contact_id IN ({$placeholders})", ...$contact_ids ) );

		if ( false === $deleted ) {
			throw new EntitlementRepositoryException( esc_html( 'Failed to delete entitlements.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return (int) $deleted;
	}

	private function find_or_fail( int $id ): Entitlement {
		$entitlement = $this->find( $id );

		if ( null === $entitlement ) {
			throw new \RuntimeException( esc_html( "Entitlement {$id} was expected to exist but could not be loaded." ) );
		}

		return $entitlement;
	}
}
