<?php
/**
 * Persistence for finding change events against `wpr_finding_events`, per Section 8.7.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\ChangeSignificance;

final class FindingEventRepository {

	public function record(
		int $finding_id,
		?int $observation_id,
		ChangeSignificance $event_type,
		?int $actor_id = null,
		?string $summary = null
	): int {
		global $wpdb;

		$table = Schema::table( 'finding_events' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'finding_id'     => $finding_id,
				'observation_id' => $observation_id,
				'event_type'     => $event_type->value,
				'actor_id'       => $actor_id,
				'summary'        => $summary,
				'occurred_at'    => current_time( 'mysql', true ),
			)
		);

		return (int) $wpdb->insert_id;
	}

	public function find_event_type( int $event_id ): ?ChangeSignificance {
		global $wpdb;

		$table = Schema::table( 'finding_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$value = $wpdb->get_var( $wpdb->prepare( "SELECT event_type FROM `{$table}` WHERE id = %d", $event_id ) );

		return null !== $value ? ChangeSignificance::from( (string) $value ) : null;
	}

	/**
	 * Deletes every event belonging to any of the given findings - only intended caller is
	 * {@see \Alltime\WPReconnaissance\Organisations\OrganisationPurgeService}, run before the
	 * findings themselves are deleted (`finding_events.finding_id` has no real `FOREIGN KEY`
	 * constraint enforcing that ordering). `0` (nothing left) is a benign, idempotent outcome;
	 * only `false` is a genuine failure.
	 *
	 * @param int[] $finding_ids
	 */
	public function delete_by_finding_ids( array $finding_ids ): int {
		if ( array() === $finding_ids ) {
			return 0;
		}

		global $wpdb;

		$table        = Schema::table( 'finding_events' );
		$placeholders = implode( ',', array_fill( 0, count( $finding_ids ), '%d' ) );

		// $table/$placeholders are fixed, internally derived identifiers; the %d count in
		// $placeholders and the spread ...$finding_ids args are both derived from the same
		// count($finding_ids), so they always match even though phpcs cannot verify that statically.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE finding_id IN ({$placeholders})", ...$finding_ids ) );

		if ( false === $deleted ) {
			throw new \RuntimeException( esc_html( 'Failed to delete finding events.' ) );
		}

		return (int) $deleted;
	}
}
