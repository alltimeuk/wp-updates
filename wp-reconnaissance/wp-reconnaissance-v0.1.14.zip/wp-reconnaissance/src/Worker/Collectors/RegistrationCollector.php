<?php
/**
 * Collects domain registration data via RDAP, with WHOIS as a controlled fallback
 * (Section 5.1, 12.1). Registrant personal data is minimised: only fields needed to evaluate
 * registration-related rules (expiry, registrar, status) are retained.
 *
 * Uses https://rdap.org as an IANA-bootstrap-aware RDAP redirector rather than implementing
 * bootstrap resolution and per-registry caching directly. A single transient 502/timeout is
 * retried once ({@see HttpClient::request_with_retry()}).
 * # TODO(12.1): replace with a direct IANA bootstrap client with a local cache, and add a WHOIS
 * fallback for registries without RDAP service.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\HttpClient;

final class RegistrationCollector extends AbstractCollector {
    public function key(): string {
        return 'rdap';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $timeout = $context->timeout_for($this->key());

        try {
            $response = HttpClient::request_with_retry(
                'GET',
                "https://rdap.org/domain/{$context->registrable_domain}",
                [ 'Accept' => 'application/rdap+json' ],
                $timeout
            );
        } catch (\Throwable $exception) {
            return $this->result(
                HttpClient::is_timeout_error($exception) ? CollectorStatus::TimedOut : CollectorStatus::Failed,
                $started,
                'rdap',
                errors: [ $exception->getMessage() ]
            );
        }

        if (404 === $response->status) {
            return $this->result(CollectorStatus::NotObservable, $started, 'rdap', errors: [ 'Domain was not found in RDAP.' ]);
        }

        if (429 === $response->status) {
            return $this->result(CollectorStatus::RateLimited, $started, 'rdap', errors: [ 'RDAP service rate-limited this request.' ]);
        }

        if ($response->status < 200 || $response->status >= 300) {
            return $this->result(CollectorStatus::Failed, $started, 'rdap', errors: [ "RDAP service returned HTTP {$response->status}." ]);
        }

        $decoded = json_decode($response->body, true);

        if (! is_array($decoded)) {
            return $this->result(CollectorStatus::Failed, $started, 'rdap', errors: [ 'RDAP response could not be parsed as JSON.' ]);
        }

        $events    = array_map(
            static fn ( array $event ): array => [ 'action' => $event['eventAction'] ?? null, 'date' => $event['eventDate'] ?? null ],
            $decoded['events'] ?? []
        );
        $expiry    = array_values(array_filter($events, static fn ( array $event ): bool => 'expiration' === $event['action']))[0]['date'] ?? null;
        $registrar = array_values(
            array_filter(
                $decoded['entities'] ?? [],
                static fn ( array $entity ): bool => in_array('registrar', $entity['roles'] ?? [], true)
            )
        )[0]['handle'] ?? null;

        $data = [
            'ldh_name'    => $decoded['ldhName'] ?? $context->registrable_domain,
            'status'      => $decoded['status'] ?? [],
            'expiry'      => $expiry,
            'registrar'   => $registrar,
            'nameservers' => array_map(
                static fn ( array $ns ): ?string => $ns['ldhName'] ?? null,
                $decoded['nameservers'] ?? []
            ),
            'events'      => $events,
        ];

        return $this->result(CollectorStatus::Succeeded, $started, 'rdap', $data);
    }
}
