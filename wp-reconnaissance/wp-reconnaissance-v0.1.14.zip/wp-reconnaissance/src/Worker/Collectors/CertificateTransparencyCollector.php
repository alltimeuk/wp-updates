<?php
/**
 * Queries crt.sh for certificates covering the apex and its subdomains, deterministically
 * deduplicating certificates and SAN entries (Section 12.1).
 *
 * Crt.sh has no formal SLA and rate-limits aggressively; this collector treats a non-200
 * response or malformed JSON as rate_limited/failed rather than "no certificates found". A
 * single transient 502/timeout is retried once ({@see HttpClient::request_with_retry()}); a
 * persistent problem still surfaces as failed/timed_out rather than being retried indefinitely.
 * # TODO(12.1): add a local result cache and consider a second CT search provider for
 * redundancy.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\HttpClient;

final class CertificateTransparencyCollector extends AbstractCollector {
    public function key(): string {
        return 'ct';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $timeout = $context->timeout_for($this->key(), 30);

        try {
            $response = HttpClient::request_with_retry(
                'GET',
                'https://crt.sh/?q=%25.' . $context->registrable_domain . '&output=json',
                [],
                $timeout
            );
        } catch (\Throwable $exception) {
            return $this->result(
                HttpClient::is_timeout_error($exception) ? CollectorStatus::TimedOut : CollectorStatus::Failed,
                $started,
                'crt.sh',
                errors: [ $exception->getMessage() ]
            );
        }

        if (429 === $response->status) {
            return $this->result(CollectorStatus::RateLimited, $started, 'crt.sh', errors: [ 'crt.sh rate-limited this request.' ]);
        }

        $entries = json_decode($response->body, true);

        if (! is_array($entries)) {
            return $this->result(CollectorStatus::Failed, $started, 'crt.sh', errors: [ 'crt.sh response could not be parsed as JSON.' ]);
        }

        $deduped_certificates = [];
        $discovered_names     = [];

        foreach ($entries as $entry) {
            $dedup_key = ( $entry['issuer_ca_id'] ?? '' ) . '|' . ( $entry['serial_number'] ?? '' );

            if (! isset($deduped_certificates[ $dedup_key ])) {
                $deduped_certificates[ $dedup_key ] = [
                    'id'          => $entry['id'] ?? null,
                    'issuer_name' => $entry['issuer_name'] ?? null,
                    'common_name' => $entry['common_name'] ?? null,
                    'not_before'  => $entry['not_before'] ?? null,
                    'not_after'   => $entry['not_after'] ?? null,
                ];
            }

            foreach (explode("\n", (string) ( $entry['name_value'] ?? '' )) as $name) {
                $discovered_names[ strtolower(trim($name)) ] = true;
            }
        }

        usort($deduped_certificates, static fn ( array $a, array $b ): int => strcmp((string) ( $b['not_before'] ?? '' ), (string) ( $a['not_before'] ?? '' )));

        $data = [
            'certificates'     => array_values($deduped_certificates),
            'discovered_names' => array_values(array_filter(array_keys($discovered_names))),
        ];

        return $this->result(CollectorStatus::Succeeded, $started, 'crt.sh', $data);
    }
}
