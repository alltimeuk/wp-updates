<?php
/**
 * Minimal cURL wrapper shared by the collectors that need to make outbound HTTP(S) requests
 * (RDAP, HTTP, Certificate Transparency). Centralises timeout, redirect and response-size
 * handling so each collector doesn't reimplement it (Section 27: "apply response-size and
 * redirect limits").
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Support;

final class HttpClient {
    private const MAX_RESPONSE_BYTES = 5 * 1024 * 1024; // 5 MiB.

    /**
     * Performs a single request without following redirects - callers that need redirect
     * chains (the HTTP collector) walk hops themselves so every hop is individually recorded,
     * which is exactly why the SSRF guard below runs on every call to this method, not once per
     * chain: each redirect hop is a fresh request() call with an attacker-influenced $url.
     *
     * @param array<string,string> $headers
     */
    public static function request( string $method, string $url, array $headers = [], int $timeout_seconds = 15 ): HttpResponse {
        $resolve_entry = self::assert_safe_and_resolve($url);

        $handle = curl_init($url);

        if (false === $handle) {
            throw new \RuntimeException("Unable to initialise HTTP request to {$url}.");
        }

        $response_headers = [];

        curl_setopt_array(
            $handle,
            [
                CURLOPT_CUSTOMREQUEST  => $method,
                CURLOPT_NOBODY         => 'HEAD' === $method,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_TIMEOUT        => $timeout_seconds,
                CURLOPT_CONNECTTIMEOUT => $timeout_seconds,
                CURLOPT_MAXFILESIZE    => self::MAX_RESPONSE_BYTES,
                CURLOPT_HTTPHEADER     => self::format_request_headers($headers),
                // Pins the connection to the exact IP already validated below, while $url above
                // keeps the original hostname for the Host header, TLS SNI and certificate
                // hostname checks (CURLOPT_SSL_VERIFYHOST) - closing the DNS-rebinding gap
                // between validation time and connection time that re-resolving here would open.
                CURLOPT_RESOLVE        => [$resolve_entry],
                CURLOPT_HEADERFUNCTION => static function ( $curl_handle, string $line ) use ( &$response_headers ): int {
                    $parts = explode(':', $line, 2);
                    if (2 === count($parts)) {
                        $response_headers[ strtolower(trim($parts[0])) ] = trim($parts[1]);
                    }
                    return strlen($line);
                },
                CURLOPT_USERAGENT      => 'WPR/1.0 (+https://alltimetech.co.uk)',
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ]
        );

        $body       = curl_exec($handle);
        $error      = curl_error($handle);
        $status     = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);

        curl_close($handle);

        if (false === $body) {
            throw new \RuntimeException("HTTP request to {$url} failed: {$error}");
        }

        return new HttpResponse($status, $response_headers, (string) $body);
    }

    /**
     * Retries once, after a brief fixed delay, when the first attempt either times out or the
     * remote returns a 502 (Bad Gateway) - both observed in practice (crt.sh in particular has no
     * formal SLA and its nginx frontend occasionally 502s under load) as a transient,
     * single-request condition rather than a persistent one. Never retries anything else: a
     * definitive answer (a 4xx, a parse failure the caller will report, any other status) is
     * returned as-is from the first attempt, and a 429 (rate-limited) is deliberately left alone
     * too - retrying immediately after being told to back off would only make that worse. Runs
     * inside the standalone collection worker process, never a web request, so the blocking
     * sleep() below is safe - it's a small, fixed cost against that process's own generous
     * execution-time budget (`wpr_worker_max_execution_seconds`), not a request thread.
     *
     * @param array<string,string> $headers
     */
    public static function request_with_retry(
        string $method,
        string $url,
        array $headers = [],
        int $timeout_seconds = 15,
        int $retry_delay_seconds = 2
    ): HttpResponse {
        try {
            $response = self::request($method, $url, $headers, $timeout_seconds);

            if (502 !== $response->status) {
                return $response;
            }
        } catch (\RuntimeException $exception) {
            if (!self::is_timeout_error($exception)) {
                throw $exception;
            }
        }

        sleep($retry_delay_seconds);

        return self::request($method, $url, $headers, $timeout_seconds);
    }

    /**
     * Whether $exception represents a request timeout (connection or transfer) rather than some
     * other failure (DNS resolution, refused connection, TLS, an unsafe/malformed URL) - the one
     * exception message pattern collectors already classify as retryable/CollectorStatus::TimedOut
     * distinctly from CollectorStatus::Failed. A single shared check, not duplicated per caller.
     */
    public static function is_timeout_error( \Throwable $exception ): bool {
        return str_contains($exception->getMessage(), 'timed out') || str_contains($exception->getMessage(), 'Timeout');
    }

    /**
     * @param array<string,string> $headers
     * @return string[]
     */
    private static function format_request_headers( array $headers ): array {
        $formatted = [];

        foreach ($headers as $name => $value) {
            $formatted[] = "{$name}: {$value}";
        }

        return $formatted;
    }

    /**
     * SSRF guard: rejects anything but a well-formed http(s) URL, then resolves its host and
     * requires at least one address outside the private/loopback/link-local/reserved ranges
     * (which includes the 169.254.169.254 cloud metadata address) - never letting curl perform
     * its own DNS resolution, since a purely-numeric host (e.g. a redirect Location of
     * "http://2130706433/") is silently treated as a raw IP by curl itself, which would bypass a
     * check that only ever validated the string form. Returns the CURLOPT_RESOLVE entry pinning
     * the connection to the one validated address.
     *
     * @throws \RuntimeException When the URL is malformed, uses an unsupported scheme, or
     *                             resolves to no address outside those ranges.
     */
    private static function assert_safe_and_resolve( string $url ): string {
        $parts = parse_url($url);

        if (false === $parts || !isset($parts['host']) || !isset($parts['scheme']) || !in_array($parts['scheme'], ['http', 'https'], true)) {
            throw new \RuntimeException("Refusing to request an unsupported or malformed URL: {$url}.");
        }

        $host = $parts['host'];
        $port = $parts['port'] ?? ('https' === $parts['scheme'] ? 443 : 80);
        $ip   = self::first_safe_ip($host);

        if (null === $ip) {
            throw new \RuntimeException("Refusing to request {$host}: it does not resolve to a permitted address.");
        }

        return "{$host}:{$port}:{$ip}";
    }

    /**
     * The first address $host resolves to (or, if $host is itself an IP literal, $host itself)
     * that passes {@see is_safe_ip()} - not necessarily the first address returned, since a
     * mixed result (a private address alongside a public one) must still resolve safely rather
     * than being rejected outright for the presence of one unsafe entry.
     */
    private static function first_safe_ip( string $host ): ?string {
        if (false !== filter_var($host, FILTER_VALIDATE_IP)) {
            return self::is_safe_ip($host) ? $host : null;
        }

        foreach ([...Dns::query($host, DNS_A), ...Dns::query($host, DNS_AAAA)] as $record) {
            $address = $record['ip'] ?? ($record['ipv6'] ?? null);

            if (is_string($address) && self::is_safe_ip($address)) {
                return $address;
            }
        }

        return null;
    }

    private static function is_safe_ip( string $ip ): bool {
        return false !== filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }
}
