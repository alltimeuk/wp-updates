<?php
/**
 * Schedules the recurring DNS domain-verification sweep, per the DNS TXT domain-ownership
 * verification feature. A dedicated bootstrap, separate from {@see \Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap},
 * since it owns its own cron interval and hook rather than reusing the existing daily
 * maintenance sweep.
 *
 * Also listens for {@see DomainVerificationService::VERIFIED_HOOK}, fired whenever a scope is
 * newly authorised via DNS verification (customer "Check now", or this class's own sweep), and
 * dispatches the organisation's held free assessment - the cross-module wiring point between the
 * generic verification mechanism and that specific product flow, matching how
 * {@see \Alltime\WPReconnaissance\Integrations\IntegrationsBootstrap} wires other modules'
 * `do_action()` events to their own listeners.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Verification;

use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Auth\FreeAssessmentService;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class VerificationBootstrap {

	public const RUN_SWEEP_HOOK = 'wpr_run_domain_verification_sweep';

	private const INTERVAL_SLUG = 'wpr_thirty_minutes';

	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly FreeAssessmentService $free_assessment = new FreeAssessmentService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	public function boot(): void {
		add_filter( 'cron_schedules', array( $this, 'register_thirty_minute_interval' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 30 minutes is intentional, not the "at least hourly" this sniff nudges toward; see the class docblock.
		add_action( self::RUN_SWEEP_HOOK, array( $this, 'run_sweep' ) );
		add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
		add_action( DomainVerificationService::VERIFIED_HOOK, array( $this, 'dispatch_free_assessment' ) );
	}

	/**
	 * Exactly one dispatch attempt per verified scope - not one per account in its
	 * organisation. {@see FreeAssessmentService::dispatch_free_assessment_for_account()}'s own
	 * idempotency guard only catches an already-*run* job (a `Job` row is created when the
	 * scheduled action actually fires, not when it's merely enqueued) - so for an organisation
	 * with more than one account (a supported configuration, {@see \Alltime\WPReconnaissance\Auth\CustomerAccountRepository::find_by_organisation()}),
	 * calling it once per account here would let each account's call independently see "not yet
	 * dispatched" and both reserve an entitlement and schedule the assessment for the same
	 * scope. `verify_and_authorise()`'s own atomic conditional UPDATE already guarantees this
	 * hook fires at most once per scope per verification event, so one dispatch attempt here -
	 * using any one account from the organisation - is the correct amount, not a shortcut.
	 */
	public function dispatch_free_assessment( int $scope_id ): void {
		$scope = $this->scopes->find( $scope_id );

		if ( null === $scope ) {
			return;
		}

		$accounts = $this->accounts->find_by_organisation( $scope->organisation_id );

		if ( array() === $accounts ) {
			return;
		}

		// A broken listener must never take down VERIFIED_HOOK's firer - whether that's the sweep
		// (already caught further up), or a synchronous customer/admin "check now" request, which
		// would otherwise turn a successful domain verification into a raw fatal for the customer.
		try {
			$this->free_assessment->dispatch_free_assessment_for_account( $accounts[0] );
		} catch ( \Throwable $exception ) {
			$this->audit_logger->log( 'entitlement.free_assessment_dispatch_failed', 'scope', $scope_id, null, outcome: 'failure', summary: $exception->getMessage(), source: 'cron' );
		}
	}

	/**
	 * @param array<string,array{interval:int,display:string}> $schedules
	 *
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function register_thirty_minute_interval( array $schedules ): array {
		$schedules[ self::INTERVAL_SLUG ] = array(
			'interval' => 30 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 30 minutes (WP-Reconnaissance domain verification)', 'wp-reconnaissance' ),
		);

		return $schedules;
	}

	/**
	 * Schedules the recurring sweep on first boot after activation. Idempotent: wp_next_scheduled()
	 * prevents piling up duplicate recurring schedules on every request.
	 */
	public function ensure_sweep_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_SWEEP_HOOK ) ) {
			wp_schedule_event( time(), self::INTERVAL_SLUG, self::RUN_SWEEP_HOOK );
		}
	}

	public function run_sweep(): void {
		( new DomainVerificationService() )->run_sweep();
	}
}
