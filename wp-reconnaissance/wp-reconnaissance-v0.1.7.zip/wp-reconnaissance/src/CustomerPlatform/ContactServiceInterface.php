<?php
/**
 * Cross-plugin contact service contract, per Section 6.1.3.
 *
 * Semantically equivalent to the pseudocode in the design specification; method names use this
 * codebase's snake_case convention (as does every other interface here - ExecutionAdapterInterface,
 * ReportGeneratorInterface) rather than the spec's literal camelCase, since the spec introduces it
 * as "a versioned PHP contract equivalent to", not a byte-for-byte mandate.
 *
 * This lives under the `Alltime\CustomerPlatform` namespace - deliberately separate from
 * `Alltime\WPReconnaissance` - because Section 6.1.2 requires the canonical contact/consent
 * service to be owned by neither WP-Reconnaissance nor WP Questionnaires: "the API and database
 * ownership boundary must allow it to become an independent plugin without changing contact
 * IDs." For now it is delivered inside this plugin (permitted explicitly by that same section),
 * discovered only through {@see ContactPlatformDiscovery}, and consumed by WP-Reconnaissance's
 * own registration flow exactly as an external plugin eventually would - never through a direct
 * `new ContactService()` from outside this namespace.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

interface ContactServiceInterface {

	/**
	 * Resolves whatever is currently known about the acting visitor without requiring them to be
	 * logged in. Section 18.1.1's full cross-tool visitor-context cookie is not implemented yet
	 * (see ContactPlatformDiscovery's docblock) - this currently only recognises an
	 * already-authenticated WordPress user linked to a contact.
	 */
	public function resolve_visitor_context(): VisitorContext;

	/**
	 * Creates a new contact, or updates and returns the existing one matched by primary email
	 * identity - never creates a duplicate contact for an email already on file.
	 */
	public function create_or_update_contact( ContactInput $input, PurposeContext $purpose ): ContactResult;

	/**
	 * Links a contact to a WordPress user once one exists (e.g. after registration completes).
	 * A contact may exist before any WordPress user does - the reverse is not modelled here.
	 */
	public function link_wordpress_user( int $contact_id, int $user_id ): void;

	/**
	 * Records a product event against a contact without moving product-specific data into the
	 * contact record itself (Section 8.0.2).
	 */
	public function record_interaction( int $contact_id, InteractionInput $interaction ): int;

	/**
	 * Records a consent decision for one purpose. Does not interpret or aggregate consent state -
	 * callers needing "is this contact currently opted in to X" query the ledger, this method
	 * only appends to it.
	 */
	public function record_consent( int $contact_id, ConsentInput $consent ): int;

	public function get_contact_for_user( int $user_id ): ?Contact;

	public function get_contact_for_email( string $email ): ?Contact;
}
