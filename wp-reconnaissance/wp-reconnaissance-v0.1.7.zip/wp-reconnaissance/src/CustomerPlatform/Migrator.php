<?php
/**
 * Incremental, idempotent schema migrations for the shared Customer Platform tables, driven by
 * `dbDelta()` - a deliberately separate migration surface from
 * {@see \Alltime\WPReconnaissance\Data\Migrator}, tracked under its own option key, so this can
 * be lifted into its own plugin later without entangling its version history with
 * WP-Reconnaissance's.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class Migrator {

	private const SCHEMA_VERSION_OPTION = 'atcp_db_schema_version';
	private const CURRENT_VERSION       = 2;

	public static function install(): void {
		self::maybe_upgrade();
	}

	public static function maybe_upgrade(): void {
		$current = (int) get_option( self::SCHEMA_VERSION_OPTION, 0 );

		if ( $current >= self::CURRENT_VERSION ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		for ( $version = $current + 1; $version <= self::CURRENT_VERSION; $version++ ) {
			$method = "apply_version_{$version}";

			if ( method_exists( self::class, $method ) ) {
				self::$method();
			}

			update_option( self::SCHEMA_VERSION_OPTION, $version, true );
		}
	}

	/**
	 * Removes the Customer Platform's own tables and options. Only invoked from uninstall.php
	 * after the same explicit administrator opt-in that governs WP-Reconnaissance's own tables.
	 */
	public static function uninstall(): void {
		global $wpdb;

		$drop_order = array( 'contact_merge_log', 'privacy_requests', 'preferences', 'visitor_contexts', 'consents', 'interactions', 'contact_organisations', 'contact_identities', 'contacts' );

		foreach ( $drop_order as $key ) {
			$table = Schema::table( $key );
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier (Schema::table()), never user input.
		}

		delete_option( self::SCHEMA_VERSION_OPTION );
	}

	private static function apply_version_1(): void {
		foreach ( Schema::version_1_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	private static function apply_version_2(): void {
		global $wpdb;

		// The unique (source_object_type, source_object_id) key on atcp_interactions is the
		// migration idempotency marker. If historic rows already duplicate a pair, the index add
		// would fail - dedupe first so dbDelta can add it cleanly.
		$interactions = Schema::table( 'interactions' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $interactions is a fixed internally derived identifier.
		$query = "DELETE t1 FROM `{$interactions}` t1 INNER JOIN `{$interactions}` t2
			 WHERE t1.id > t2.id
			   AND t1.source_object_type = t2.source_object_type
			   AND t1.source_object_id = t2.source_object_id
			   AND t1.source_object_id IS NOT NULL"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$wpdb->query( $query ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- one-off migration dedupe; $query is a fixed internally derived identifier.

		foreach ( Schema::version_2_statements() as $statement ) {
			dbDelta( $statement );
		}
	}
}
