<?php
/**
 * Refuses a write to {@see ProtectedUploadDirectory}'s `'uploads'`-mode fallback location unless
 * a recent, positively-confirmed-safe verdict exists for it - the fail-closed counterpart to
 * `SiteHealthChecks::check_evidence_storage()`/`check_report_storage()`'s read-only diagnostic.
 * Genuinely tri-state: `protected` allows a write, `exposed` refuses it, and so does `unknown` -
 * missing, expired, or any unrecognised cached value. Treating "never checked" the same as
 * "confirmed safe" is exactly the gap that made an earlier version of this class fail-*after*-
 * detection rather than fail-closed; the safe state requires positive confirmation, not merely
 * the absence of positive danger.
 *
 * Deliberately consults only a cached verdict {@see \Alltime\WPReconnaissance\Diagnostics\SiteHealthChecks}
 * already recorded via {@see record_probe_result()} - {@see assert_not_exposed()} never makes an
 * HTTP request of its own. A synchronous probe on the write path itself would add a real
 * outbound-HTTP dependency (and its failure modes: timeouts, blocked self-requests) to every
 * evidence/report write, and WordPress's per-test database rollback resets transient caches
 * between tests, so it would also add an uncached network attempt to most of this plugin's
 * integration tests.
 *
 * The verdict is bound to the exact URL prefix it was tested against plus the reporting web
 * server ({@see verdict_key()}) - a domain migration, a custom uploads path/CDN filter, or an
 * Apache<->nginx swap all produce a different cache key, which is a miss (unknown, blocks) rather
 * than a stale answer trusted past its relevance. The cache also simply expires after 15 minutes
 * regardless, the backstop for configuration changes this specific binding can't detect (an nginx
 * config edit, a proxy topology change).
 *
 * Because "unknown" now blocks, a subdirectory that has never been checked - a fresh install, or
 * one whose verdict was just invalidated - would otherwise stay blocked until Site Health happens
 * to run, passively up to a week away (WordPress's own weekly background Site Health check).
 * {@see schedule_reprobe()} bounds that window by scheduling a one-off background check the
 * moment a write is refused, instead of waiting on that.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

final class StorageExposureGuard {

	public const PROBE_HOOK = 'wpr_probe_storage_exposure';

	private const VERDICT_TRANSIENT_PREFIX = 'wpr_storage_verdict_';

	private const BLOCKED_OPTION = 'wpr_storage_write_blocked';

	private const REVALIDATE_INTERVAL = 15 * MINUTE_IN_SECONDS;

	/**
	 * @throws StorageExposedException When the last recorded live probe of $subdirectory
	 *                                  confirmed it's directly reachable over the web.
	 * @throws StorageUnverifiedException When no recent, positively-confirmed-safe verdict exists
	 *                                     for $subdirectory - never checked, expired, or the
	 *                                     configuration it was last checked under has since
	 *                                     changed.
	 */
	public static function assert_not_exposed( string $subdirectory ): void {
		$verdict = get_transient( self::verdict_key( $subdirectory ) );

		if ( 'protected' === $verdict ) {
			self::clear_blocked( $subdirectory );
			return;
		}

		self::schedule_reprobe();

		if ( 'exposed' === $verdict ) {
			self::record_blocked( $subdirectory, 'exposed' );

			throw new StorageExposedException(
				esc_html(
					"Refusing to write to \"{$subdirectory}\" - Site Health's last check confirmed this location is directly reachable over the web. Add an explicit deny rule for it (see docs/installation.md) or resolve whatever is preventing storage from escaping the document root, then re-check Site Health before retrying."
				)
			);
		}

		self::record_blocked( $subdirectory, 'unverified' );

		throw new StorageUnverifiedException(
			esc_html(
				"Refusing to write to \"{$subdirectory}\" - this location's safety has not been positively confirmed (never checked, the check has expired, or the site's configuration has changed since the last check). A check has been scheduled automatically; try again shortly, or visit Tools > Site Health to run one now."
			)
		);
	}

	/**
	 * Called by SiteHealthChecks after it live-probes $subdirectory, so assert_not_exposed() can
	 * consult a cached verdict instead of making its own HTTP request.
	 */
	public static function record_probe_result( string $subdirectory, bool $exposed ): void {
		set_transient( self::verdict_key( $subdirectory ), $exposed ? 'exposed' : 'protected', self::REVALIDATE_INTERVAL );

		if ( ! $exposed ) {
			self::clear_blocked( $subdirectory );
		}
	}

	/**
	 * Registered unconditionally on `admin_notices` ({@see \Alltime\WPReconnaissance\Diagnostics\SiteHealthChecks::boot()})
	 * - silent unless a write is currently blocked. Never names a filesystem path, only the fixed
	 * subdirectory name and the reason - matching this codebase's one other admin notice of this
	 * kind, {@see \Alltime\WPReconnaissance\Data\Migrator::render_admin_notice()}.
	 */
	public static function render_admin_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$blocked = get_option( self::BLOCKED_OPTION );

		if ( ! is_array( $blocked ) || array() === $blocked ) {
			return;
		}

		foreach ( $blocked as $subdirectory => $detail ) {
			$reason = 'exposed' === ( $detail['reason'] ?? null )
				? __( 'a live check confirmed it is directly reachable over the web', 'wp-reconnaissance' )
				: __( 'its safety has not been positively confirmed yet', 'wp-reconnaissance' );

			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: subdirectory name, e.g. "wpr-evidence". 2: why the write is blocked. */
						__( 'WP-Reconnaissance is refusing to write new evidence/report files to "%1$s" - %2$s. See Tools &raquo; Site Health for details, or relocate storage outside the document root.', 'wp-reconnaissance' ),
						(string) $subdirectory,
						$reason
					)
				)
			);
		}
	}

	/**
	 * Idempotent: does nothing if a probe is already pending, so concurrently blocked writes don't
	 * pile up duplicate scheduled checks.
	 */
	private static function schedule_reprobe(): void {
		if ( function_exists( 'as_next_scheduled_action' ) && function_exists( 'as_enqueue_async_action' ) ) {
			if ( false === as_next_scheduled_action( self::PROBE_HOOK, array(), 'wp-reconnaissance' ) ) {
				as_enqueue_async_action( self::PROBE_HOOK, array(), 'wp-reconnaissance' );
			}

			return;
		}

		if ( false === wp_next_scheduled( self::PROBE_HOOK ) ) {
			wp_schedule_single_event( time(), self::PROBE_HOOK );
		}
	}

	private static function record_blocked( string $subdirectory, string $reason ): void {
		$blocked = get_option( self::BLOCKED_OPTION );
		$blocked = is_array( $blocked ) ? $blocked : array();

		$blocked[ $subdirectory ] = array(
			'reason'     => $reason,
			'blocked_at' => time(),
		);

		update_option( self::BLOCKED_OPTION, $blocked, false );
	}

	private static function clear_blocked( string $subdirectory ): void {
		$blocked = get_option( self::BLOCKED_OPTION );

		if ( ! is_array( $blocked ) || ! array_key_exists( $subdirectory, $blocked ) ) {
			return;
		}

		unset( $blocked[ $subdirectory ] );

		if ( array() === $blocked ) {
			delete_option( self::BLOCKED_OPTION );
			return;
		}

		update_option( self::BLOCKED_OPTION, $blocked, false );
	}

	/**
	 * Binds the cached verdict to the exact URL prefix it was tested against plus the reporting
	 * web server - a domain migration, a custom uploads path/CDN filter, or an Apache<->nginx swap
	 * all produce a different key here, so a verdict tested under the old configuration is simply
	 * never found rather than wrongly trusted under the new one.
	 */
	private static function verdict_key( string $subdirectory ): string {
		$upload_dir      = wp_upload_dir();
		$server_software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? (string) $_SERVER['SERVER_SOFTWARE'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only, used only as a cache-key discriminator, never output or persisted verbatim.

		$binding = substr( md5( $upload_dir['baseurl'] . '|' . $server_software ), 0, 12 );

		return self::VERDICT_TRANSIENT_PREFIX . $subdirectory . '_' . $binding;
	}
}
