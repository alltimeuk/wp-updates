<?php
/**
 * REST API bootstrap, per Section 23.
 *
 * Registers the versioned `wp-reconnaissance/v1` namespace. Every route must define a
 * `permission_callback`; resource controllers (organisations, scopes, jobs, observations,
 * findings, reports) are added incrementally as their owning modules are implemented - this
 * bootstrap currently wires only an authenticated status endpoint to establish the pattern.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Support\Capabilities;

use const Alltime\WPReconnaissance\WPR_SCHEMA_VERSION;
use const Alltime\WPReconnaissance\WPR_VERSION;

final class RestBootstrap {

	public const NAMESPACE_V1 = 'wp-reconnaissance/v1';

	public function boot(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			self::NAMESPACE_V1,
			'/status',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_status' ),
				'permission_callback' => static fn (): bool => current_user_can( Capabilities::VIEW_ALL_RESULTS ),
				'args'                => array(),
			)
		);

		( new OrganisationsController() )->register_routes();
		( new ScopesController() )->register_routes();
		( new JobsController() )->register_routes();
		( new FindingsController() )->register_routes();
		( new ReportsController() )->register_routes();
		( new RemediationTasksController() )->register_routes();
		( new ContactsController() )->register_routes();
	}

	public function get_status( \WP_REST_Request $request ): \WP_REST_Response {
		return new \WP_REST_Response(
			array(
				'plugin_version' => WPR_VERSION,
				'schema_version' => WPR_SCHEMA_VERSION,
			)
		);
	}
}
