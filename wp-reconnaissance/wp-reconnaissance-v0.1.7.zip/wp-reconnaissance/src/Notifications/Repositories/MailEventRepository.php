<?php
/**
 * Append-only persistence for mail delivery events against `wpr_mail_events`, per Section 22.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications\Repositories;

use Alltime\WPReconnaissance\Data\Schema;

final class MailEventRepository {

	public function record( int $message_id, string $event_type, ?string $detail = null ): void {
		global $wpdb;

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_events' ),
			array(
				'message_id'  => $message_id,
				'event_type'  => $event_type,
				'detail'      => $detail,
				'occurred_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function delete_for_message( int $message_id ): void {
		global $wpdb;

		$wpdb->delete( Schema::table( 'mail_events' ), array( 'message_id' => $message_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}
