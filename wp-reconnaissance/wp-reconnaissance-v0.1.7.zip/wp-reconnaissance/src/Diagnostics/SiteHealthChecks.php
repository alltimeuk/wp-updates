<?php
/**
 * Site Health diagnostics, per Section 29.
 *
 * Adds synchronous ("direct") tests to WordPress core's Site Health "Status" tab, and a
 * "wp-reconnaissance" section to its "Info" tab. Diagnostics exports must redact tokens,
 * credentials, evidence and personal information (Section 29); every filesystem path exposed
 * below is marked `'private' => true`, which is the mechanism WordPress core's own "Copy site
 * info to clipboard" export already uses to exclude a field, so no separate export/redaction
 * routine is needed. No evidence content, credentials or personal information is surfaced here at
 * all - only configuration state and counts.
 *
 * Loopback request health is not duplicated here: WordPress core's own Site Health already tests
 * it via its "REST API availability"/"communication with WordPress.org" checks (Section 29 lists
 * "loopback processing where used", which this plugin does not add its own loopback requests
 * beyond what core already exercises).
 *
 * Every check is registered under 'direct' (synchronous) except the two protected-storage checks
 * below, which are the deliberate sole exception: they each make a real outbound HTTP request to
 * this site's own public URL (the only way to verify direct-access protection *behaviourally*,
 * rather than inferring it from `.htaccess`/`index.php` file presence - a check that would report
 * "good" on nginx even though nginx never reads `.htaccess` at all). A synchronous network
 * round-trip on every Site Health page load is exactly what 'async' exists to avoid.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Diagnostics;

use Alltime\WPReconnaissance\Api\RestBootstrap;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Execution\LocalProcessAdapter;
use Alltime\WPReconnaissance\Execution\RemoteWorkerAdapter;
use Alltime\WPReconnaissance\Notifications\Repositories\MailQueueRepository;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;
use Alltime\WPReconnaissance\Support\ProtectedUploadDirectory;
use Alltime\WPReconnaissance\Support\StorageExposureGuard;
use Alltime\WPReconnaissance\Worker\Cli\Runner;

use const Alltime\WPReconnaissance\WPR_SCHEMA_VERSION;

final class SiteHealthChecks {

	private const MIN_PHP_VERSION = '8.2';

	/** A retention sweep is scheduled daily; anything twice that old signals a stalled sweep. */
	private const RETENTION_STALE_AFTER_HOURS = 48;

	/** Matches NotificationDispatcher::REPEATED_FAILURE_THRESHOLD - same signal, operator view. */
	private const REPEATED_FAILURE_THRESHOLD = 3;

	public function __construct(
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly MailQueueRepository $mail_queue = new MailQueueRepository(),
		private readonly LocalProcessAdapter $local_adapter = new LocalProcessAdapter(),
		private readonly RemoteWorkerAdapter $remote_adapter = new RemoteWorkerAdapter(),
		/**
		 * @var callable(string):(array<string,mixed>|\WP_Error) Defaults to {@see default_http_get()};
		 *      overridable so tests can assert against deterministic responses instead of making a
		 *      real HTTP request, matching {@see \Alltime\WPReconnaissance\Verification\DomainVerificationService}'s
		 *      injectable `$dns_query`.
		 */
		private $http_get = array( self::class, 'default_http_get' )
	) {}

	public function boot(): void {
		add_filter( 'site_status_tests', array( $this, 'register_tests' ) );
		add_filter( 'debug_information', array( $this, 'register_debug_information' ) );
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'admin_notices', array( StorageExposureGuard::class, 'render_admin_notice' ) );
	}

	/**
	 * @param array<string,array<string,mixed>> $tests
	 * @return array<string,array<string,mixed>>
	 */
	public function register_tests( array $tests ): array {
		$direct_checks = array(
			'wpr_php_version'           => array( $this, 'check_php_version' ),
			'wpr_database_schema'       => array( $this, 'check_database_schema' ),
			'wpr_mail_queue'            => array( $this, 'check_mail_queue' ),
			'wpr_cron_health'           => array( $this, 'check_cron_health' ),
			'wpr_worker_availability'   => array( $this, 'check_worker_availability' ),
			'wpr_worker_version'        => array( $this, 'check_worker_version' ),
			'wpr_worker_directory'      => array( $this, 'check_worker_directory' ),
			'wpr_remote_worker'         => array( $this, 'check_remote_worker' ),
			'wpr_retention_task'        => array( $this, 'check_retention_task' ),
			'wpr_repeated_failures'     => array( $this, 'check_repeated_failures' ),
			'wpr_application_passwords' => array( $this, 'check_application_passwords' ),
		);

		foreach ( $direct_checks as $key => $callback ) {
			$tests['direct'][ $key ] = array(
				'label' => $key,
				'test'  => $callback,
			);
		}

		$async_checks = array(
			'wpr_evidence_storage' => array( 'check_evidence_storage', '/site-health/evidence-storage' ),
			'wpr_report_storage'   => array( 'check_report_storage', '/site-health/report-storage' ),
		);

		foreach ( $async_checks as $key => [ $method, $route ] ) {
			$tests['async'][ $key ] = array(
				'label'             => $key,
				'test'              => rest_url( RestBootstrap::NAMESPACE_V1 . $route ),
				'has_rest'          => true,
				'async_direct_test' => array( $this, $method ),
			);
		}

		return $tests;
	}

	/**
	 * The REST surface Site Health's JS calls for the two async checks above - `has_rest` tests
	 * are dispatched as a plain `wp.apiRequest()` against the URL registered as their `test` value
	 * (`rest_url()`-derived, see {@see register_tests()}), not through `admin-ajax.php`.
	 */
	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/site-health/evidence-storage',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => fn (): \WP_REST_Response => new \WP_REST_Response( $this->check_evidence_storage() ),
				'permission_callback' => static fn (): bool => current_user_can( 'view_site_health_checks' ),
				'args'                => array(),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/site-health/report-storage',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => fn (): \WP_REST_Response => new \WP_REST_Response( $this->check_report_storage() ),
				'permission_callback' => static fn (): bool => current_user_can( 'view_site_health_checks' ),
				'args'                => array(),
			)
		);
	}

	// -----------------------------------------------------------------------------------
	// Checks
	// -----------------------------------------------------------------------------------

	/**
	 * @return array<string,mixed>
	 */
	public function check_php_version(): array {
		if ( version_compare( PHP_VERSION, self::MIN_PHP_VERSION, '>=' ) ) {
			return $this->result(
				'good',
				__( 'PHP version is supported', 'wp-reconnaissance' ),
				sprintf(
					/* translators: 1: minimum required PHP version, 2: running PHP version */
					__( 'WP-Reconnaissance requires PHP %1$s or newer; this site is running PHP %2$s.', 'wp-reconnaissance' ),
					self::MIN_PHP_VERSION,
					PHP_VERSION
				)
			);
		}

		return $this->result(
			'critical',
			__( 'PHP version is not supported', 'wp-reconnaissance' ),
			sprintf(
				/* translators: 1: minimum required PHP version, 2: running PHP version */
				__( 'WP-Reconnaissance requires PHP %1$s or newer; this site is running PHP %2$s. Some functionality may not work correctly.', 'wp-reconnaissance' ),
				self::MIN_PHP_VERSION,
				PHP_VERSION
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_database_schema(): array {
		$current = (int) get_option( 'wpr_db_schema_version', 0 );

		if ( $current >= WPR_SCHEMA_VERSION ) {
			return $this->result(
				'good',
				__( 'Database schema is up to date', 'wp-reconnaissance' ),
				__( 'The WP-Reconnaissance database schema matches the version this plugin expects.', 'wp-reconnaissance' )
			);
		}

		$failure = get_option( 'wpr_migration_failure', null );

		if ( is_array( $failure ) ) {
			return $this->result(
				'critical',
				__( 'Database schema upgrade is failing', 'wp-reconnaissance' ),
				sprintf(
					/* translators: 1: schema version the upgrade is trying to reach, 2: safe failure classification, 3: number of times this has been retried, 4: UTC datetime of the most recent retry */
					__( 'The schema upgrade to version %1$d has failed (%2$s) and has been retried automatically %3$d time(s), most recently at %4$s (UTC). It will keep retrying automatically; contact support if this persists.', 'wp-reconnaissance' ),
					(int) ( $failure['target_version'] ?? 0 ),
					(string) ( $failure['classification'] ?? 'unknown' ),
					(int) ( $failure['occurrences'] ?? 0 ),
					(string) ( $failure['last_seen_at'] ?? '' )
				)
			);
		}

		return $this->result(
			'critical',
			__( 'Database schema is out of date', 'wp-reconnaissance' ),
			__( 'The stored schema version is behind what this plugin expects. Reload any admin screen to trigger the pending migration, or deactivate and reactivate the plugin.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_mail_queue(): array {
		$failed = $this->mail_queue->count_failed();

		if ( 0 === $failed ) {
			return $this->result(
				'good',
				__( 'Mail queue is healthy', 'wp-reconnaissance' ),
				__( 'No queued messages are stuck in a failed state.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'recommended',
			__( 'Some queued messages have failed to send', 'wp-reconnaissance' ),
			sprintf(
				/* translators: %d: number of failed messages */
				_n(
					'%d queued message has permanently failed to send and needs attention.',
					'%d queued messages have permanently failed to send and need attention.',
					$failed,
					'wp-reconnaissance'
				),
				$failed
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_cron_health(): array {
		if ( false === wp_next_scheduled( SchedulingBootstrap::DAILY_MAINTENANCE_HOOK ) ) {
			return $this->result(
				'critical',
				__( 'Daily maintenance is not scheduled', 'wp-reconnaissance' ),
				__( 'The daily retention/notification maintenance task has no next run scheduled. Reload any admin screen to reschedule it.', 'wp-reconnaissance' )
			);
		}

		if ( ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) && ! function_exists( 'as_schedule_recurring_action' ) ) {
			return $this->result(
				'recommended',
				__( 'Scheduled tasks depend on a system cron', 'wp-reconnaissance' ),
				__( 'WP-Cron is disabled and Action Scheduler is not available, so scheduled maintenance and mail delivery depend entirely on a real system cron calling wp-cron.php. Confirm one is configured.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'good',
			__( 'Scheduled tasks are healthy', 'wp-reconnaissance' ),
			__( 'Daily maintenance is scheduled and a task runner (Action Scheduler or WP-Cron) is available.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_worker_availability(): array {
		$enabled = (bool) get_option( 'wpr_local_adapter_enabled', false );

		if ( ! $enabled ) {
			return $this->result(
				'recommended',
				__( 'No collection execution adapter is enabled', 'wp-reconnaissance' ),
				__( 'The local process execution adapter is not enabled, so assessments cannot run. Configure it under WP-Reconnaissance &raquo; Settings.', 'wp-reconnaissance' )
			);
		}

		if ( $this->local_adapter->is_ready() ) {
			return $this->result(
				'good',
				__( 'The local execution adapter is ready', 'wp-reconnaissance' ),
				__( 'The configured PHP CLI binary and worker script both exist and are usable.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'critical',
			__( 'The local execution adapter is misconfigured', 'wp-reconnaissance' ),
			__( 'The local process execution adapter is enabled, but the configured PHP CLI binary or worker script path is missing or not executable. Assessments will fail until this is corrected under WP-Reconnaissance &raquo; Settings.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_worker_version(): array {
		$recent = $this->jobs->list_recent( 1 );

		if ( array() === $recent || null === $recent[0]->worker_version ) {
			return $this->result(
				'good',
				__( 'Worker version compatibility', 'wp-reconnaissance' ),
				__( 'No completed job has reported a worker version yet.', 'wp-reconnaissance' )
			);
		}

		$reported = $recent[0]->worker_version;

		if ( Runner::WORKER_VERSION === $reported ) {
			return $this->result(
				'good',
				__( 'Worker version matches', 'wp-reconnaissance' ),
				sprintf(
					/* translators: %s: worker version string */
					__( 'The most recent job ran collection worker version %s, matching this plugin.', 'wp-reconnaissance' ),
					$reported
				)
			);
		}

		return $this->result(
			'recommended',
			__( 'Worker version mismatch', 'wp-reconnaissance' ),
			sprintf(
				/* translators: 1: worker version reported by the most recent job, 2: version bundled with this plugin */
				__( 'The most recent job ran collection worker version %1$s, but this plugin bundles %2$s. Confirm the configured worker script path points at the current copy.', 'wp-reconnaissance' ),
				$reported,
				Runner::WORKER_VERSION
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_worker_directory(): array {
		if ( ! (bool) get_option( 'wpr_local_adapter_enabled', false ) ) {
			return $this->result(
				'good',
				__( 'Worker directory permissions', 'wp-reconnaissance' ),
				__( 'Not applicable - the local execution adapter is not enabled.', 'wp-reconnaissance' )
			);
		}

		$dir = (string) get_option( 'wpr_worker_work_dir', sys_get_temp_dir() );

		if ( '' !== $dir && is_dir( $dir ) && is_writable( $dir ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
			return $this->result(
				'good',
				__( 'Worker directory is writable', 'wp-reconnaissance' ),
				__( 'The configured worker working directory exists and is writable.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'critical',
			__( 'Worker directory is not usable', 'wp-reconnaissance' ),
			__( 'The configured worker working directory does not exist or is not writable by the web server. Assessments using the local execution adapter will fail.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_evidence_storage(): array {
		return $this->storage_protection_result(
			$this->probe_canary_protection( 'wpr-evidence' ),
			__( 'Evidence storage protection', 'wp-reconnaissance' ),
			__( 'raw collection evidence', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_report_storage(): array {
		return $this->storage_protection_result(
			$this->probe_canary_protection( 'wpr-reports' ),
			__( 'Report storage protection', 'wp-reconnaissance' ),
			__( 'issued report PDFs', 'wp-reconnaissance' )
		);
	}

	/**
	 * Makes a real, unauthenticated HTTP request to a directory's canary file - the only way to
	 * confirm direct-access protection is actually effective regardless of web server software,
	 * rather than inferring it from `.htaccess`/`index.php` presence (true on every server, proves
	 * nothing on nginx, which never reads `.htaccess`).
	 *
	 * Checks the escaped (outside-the-document-root) location first, without triggering a fresh
	 * mode resolution - only a canary already written by a real `store()` call is checked, so a
	 * fresh install that has never stored anything still correctly reports `not_applicable`,
	 * exactly as before. When storage lives outside the document root, no HTTP probe is possible
	 * at all (there is no public URL for a location outside the served tree to request) - the live
	 * probe below only ever applies to the uploads-directory fallback.
	 *
	 * @return 'not_applicable'|'escaped'|'protected'|'exposed'|'inconclusive'
	 */
	private function probe_canary_protection( string $subdirectory ): string {
		$canary = ProtectedUploadDirectory::canary_filename();

		$escaped_dir = ProtectedUploadDirectory::directory_for_mode( $subdirectory, ProtectedUploadDirectory::MODE_ESCAPED );
		if ( is_file( $escaped_dir . DIRECTORY_SEPARATOR . $canary ) ) {
			return 'escaped';
		}

		$upload_dir = wp_upload_dir();
		$dir        = ProtectedUploadDirectory::directory_for_mode( $subdirectory, ProtectedUploadDirectory::MODE_UPLOADS );

		if ( ! is_file( $dir . DIRECTORY_SEPARATOR . $canary ) ) {
			return 'not_applicable';
		}

		// Cache-busting query arg as a second line of defence alongside the no-cache header below -
		// not every intermediary (CDN/proxy) honours the request header, but a URL that changes on
		// every check is never cacheable regardless.
		$url = add_query_arg(
			'_wpr_nocache',
			wp_generate_password( 12, false, false ),
			trailingslashit( $upload_dir['baseurl'] ) . $subdirectory . '/' . $canary
		);

		$response = ( $this->http_get )( $url );

		if ( is_wp_error( $response ) ) {
			return 'inconclusive';
		}

		$exposed = 200 === (int) wp_remote_retrieve_response_code( $response )
			&& ProtectedUploadDirectory::canary_content() === wp_remote_retrieve_body( $response );

		// Persists this verdict so StorageExposureGuard::assert_not_exposed() can refuse a future
		// write without making its own HTTP request - see that class's docblock.
		StorageExposureGuard::record_probe_result( $subdirectory, $exposed );

		return $exposed ? 'exposed' : 'protected';
	}

	/**
	 * @param 'not_applicable'|'escaped'|'protected'|'exposed'|'inconclusive' $outcome
	 * @return array<string,mixed>
	 */
	private function storage_protection_result( string $outcome, string $label, string $content_description ): array {
		return match ( $outcome ) {
			'not_applicable' => $this->result(
				'good',
				$label,
				sprintf(
					/* translators: %s: kind of file this directory stores, e.g. "raw collection evidence" */
					__( 'Not applicable - no %s has been stored yet.', 'wp-reconnaissance' ),
					$content_description
				)
			),
			'escaped'         => $this->result(
				'good',
				$label,
				sprintf(
					/* translators: %s: kind of file this directory stores, e.g. "raw collection evidence" */
					__( '%s is stored outside the web server\'s document root, verified writable there - no URL exists for this location on any web server, so this was not (and cannot be) empirically tested over HTTP the way the fallback location below is. Known limitation: backup, staging and site-cloning tools commonly snapshot only the WordPress installation itself, so a restored or cloned copy of this site may be missing files stored here.', 'wp-reconnaissance' ),
					ucfirst( $content_description )
				)
			),
			'protected'       => $this->result(
				'good',
				$label,
				sprintf(
					/* translators: %s: kind of file this directory stores, e.g. "raw collection evidence" */
					__( 'A direct, unauthenticated request for a known file in this directory was rejected - %s is not reachable over the web without going through this plugin\'s own authenticated download handler.', 'wp-reconnaissance' ),
					$content_description
				)
			),
			'exposed'         => $this->result(
				'critical',
				$label,
				sprintf(
					/* translators: %s: kind of file this directory stores, e.g. "raw collection evidence" */
					__( 'A direct, unauthenticated request for a known file in this directory succeeded - %s may be reachable directly over the web, bypassing this plugin\'s authenticated download handler entirely. This server could not store files outside the document root (see the plugin\'s documentation), so it is relying on this directory alone, which is not enough on its own. If this server runs nginx, its own configuration must explicitly deny access to this directory; a WordPress plugin cannot add that automatically for nginx the way it can for Apache.', 'wp-reconnaissance' ),
					$content_description
				)
			),
			default           => $this->result(
				'recommended',
				$label,
				__( 'This server could not verify its own storage protection over HTTP just now (the verification request itself failed or was blocked) - protection has not been confirmed either way. If this persists, check whether outbound HTTP requests from this server to itself are permitted.', 'wp-reconnaissance' )
			),
		};
	}

	/**
	 * Public, not private: referenced only indirectly via the string-callable array in this
	 * class's own constructor default (matching {@see \Alltime\WPReconnaissance\Verification\DomainVerificationService}'s
	 * `Dns::query()`, itself public for the same reason) - static analysis can't trace that
	 * reference through a private method.
	 *
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function default_http_get( string $url ) {
		return wp_remote_get(
			$url,
			array(
				'timeout'   => 5,
				// Matches WP core's own loopback-check filter (WP_Site_Health::can_perform_loopback()) -
				// a self-signed/staging cert on a request the server makes to itself is common.
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- a WordPress core filter, not one this plugin defines; intentionally unprefixed to match core's own name.
				'headers'   => array( 'Cache-Control' => 'no-cache' ),
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_remote_worker(): array {
		if ( $this->remote_adapter->is_ready() ) {
			return $this->result(
				'good',
				__( 'Remote worker connectivity', 'wp-reconnaissance' ),
				__( 'The remote worker adapter is configured and reachable.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'good',
			__( 'Remote worker connectivity', 'wp-reconnaissance' ),
			__( 'Not applicable - the remote worker adapter is not available in this release; use the local execution adapter.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_retention_task(): array {
		$last_run_raw = get_option( 'wpr_retention_last_run_at', '' );

		if ( '' === $last_run_raw || ! is_string( $last_run_raw ) ) {
			return $this->result(
				'recommended',
				__( 'Retention sweep has not run yet', 'wp-reconnaissance' ),
				__( 'The retention and deletion sweep has never completed. It runs automatically as part of daily maintenance, or on demand via "wp reconnaissance retention run".', 'wp-reconnaissance' )
			);
		}

		$last_run = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $last_run_raw, new \DateTimeZone( 'UTC' ) );
		$stale    = false === $last_run || ( new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) )->getTimestamp() - $last_run->getTimestamp() > self::RETENTION_STALE_AFTER_HOURS * HOUR_IN_SECONDS;

		if ( $stale ) {
			return $this->result(
				'critical',
				__( 'Retention sweep is overdue', 'wp-reconnaissance' ),
				__( 'The retention and deletion sweep has not completed recently, even though it is scheduled daily. Check that scheduled tasks are running.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'good',
			__( 'Retention sweep is running', 'wp-reconnaissance' ),
			sprintf(
				/* translators: %s: date/time the retention sweep last completed */
				__( 'The retention and deletion sweep last completed at %s (UTC).', 'wp-reconnaissance' ),
				$last_run_raw
			)
		);
	}

	/**
	 * Section 33's operator-facing failure monitoring: how many scopes' most recent
	 * {@see self::REPEATED_FAILURE_THRESHOLD} jobs are all failures. The same signal the
	 * customer-facing "repeated collection failure" notification already reacts to per scope,
	 * surfaced fleet-wide here for an operator glancing at Site Health rather than waiting on a
	 * job to complete and trigger it.
	 *
	 * @return array<string,mixed>
	 */
	public function check_repeated_failures(): array {
		$count = count( $this->jobs->find_scopes_with_repeated_failures( self::REPEATED_FAILURE_THRESHOLD ) );

		if ( 0 === $count ) {
			return $this->result(
				'good',
				__( 'No scopes have repeated assessment failures', 'wp-reconnaissance' ),
				__( 'Every scope with a recent assessment has at least one recent success.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'recommended',
			__( 'Some scopes have repeated assessment failures', 'wp-reconnaissance' ),
			sprintf(
				/* translators: %d: number of affected scopes */
				_n(
					'%d scope\'s last several assessment attempts have all failed. Review it under WP-Reconnaissance &raquo; Jobs.',
					'%d scopes\' last several assessment attempts have all failed. Review them under WP-Reconnaissance &raquo; Jobs.',
					$count,
					'wp-reconnaissance'
				),
				$count
			)
		);
	}

	/**
	 * Section 33's CRM/service-account integration relies entirely on WordPress core's own
	 * Application Passwords feature for authentication - this confirms the site actually supports
	 * it (some hosts/plugins disable it, and it requires HTTPS by default) rather than a customer
	 * only discovering that when an external system's requests start failing.
	 *
	 * @return array<string,mixed>
	 */
	public function check_application_passwords(): array {
		if ( wp_is_application_passwords_available() ) {
			return $this->result(
				'good',
				__( 'Application Passwords are available', 'wp-reconnaissance' ),
				__( 'An external system (e.g. a CRM or PSA) can authenticate against the REST API using a WordPress Application Password.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'recommended',
			__( 'Application Passwords are not available', 'wp-reconnaissance' ),
			__( 'No external system can authenticate against the REST API until Application Passwords are available - typically this means serving the site over HTTPS, or a plugin/filter has disabled the feature.', 'wp-reconnaissance' )
		);
	}

	// -----------------------------------------------------------------------------------
	// Info tab (Section 29: diagnostics exports must redact tokens, credentials, evidence and
	// personal information - every filesystem path below is marked private for exactly that
	// reason; nothing here is a token, credential or personal-data value).
	// -----------------------------------------------------------------------------------

	/**
	 * @param array<string,array<string,mixed>> $info
	 * @return array<string,array<string,mixed>>
	 */
	public function register_debug_information( array $info ): array {
		$info['wp-reconnaissance'] = array(
			'label'  => __( 'WP-Reconnaissance', 'wp-reconnaissance' ),
			'fields' => array(
				'db_schema_version'     => array(
					'label' => __( 'Database schema version', 'wp-reconnaissance' ),
					'value' => (string) get_option( 'wpr_db_schema_version', 0 ) . ' / ' . WPR_SCHEMA_VERSION,
				),
				'local_adapter_enabled' => array(
					'label' => __( 'Local execution adapter enabled', 'wp-reconnaissance' ),
					'value' => (bool) get_option( 'wpr_local_adapter_enabled', false ) ? __( 'Yes', 'wp-reconnaissance' ) : __( 'No', 'wp-reconnaissance' ),
				),
				'php_binary_path'       => array(
					'label'   => __( 'PHP CLI binary path', 'wp-reconnaissance' ),
					'value'   => (string) get_option( 'wpr_php_binary_path', '' ),
					'private' => true,
				),
				'worker_script_path'    => array(
					'label'   => __( 'Worker script path', 'wp-reconnaissance' ),
					'value'   => (string) get_option( 'wpr_worker_script_path', '' ),
					'private' => true,
				),
				'worker_work_dir'       => array(
					'label'   => __( 'Worker working directory', 'wp-reconnaissance' ),
					'value'   => (string) get_option( 'wpr_worker_work_dir', '' ),
					'private' => true,
				),
				'mail_queue_failed'     => array(
					'label' => __( 'Failed queued messages', 'wp-reconnaissance' ),
					'value' => (string) $this->mail_queue->count_failed(),
				),
				'retention_last_run'    => array(
					'label' => __( 'Retention sweep last ran (UTC)', 'wp-reconnaissance' ),
					'value' => (string) get_option( 'wpr_retention_last_run_at', __( 'Never', 'wp-reconnaissance' ) ),
				),
			),
		);

		return $info;
	}

	/**
	 * @return array<string,mixed>
	 */
	private function result( string $status, string $label, string $description ): array {
		return array(
			'label'       => $label,
			'status'      => $status,
			'badge'       => array(
				'label' => __( 'WP-Reconnaissance', 'wp-reconnaissance' ),
				'color' => 'blue',
			),
			'description' => '<p>' . esc_html( $description ) . '</p>',
			'actions'     => '',
			'test'        => 'wpr_site_health',
		);
	}
}
