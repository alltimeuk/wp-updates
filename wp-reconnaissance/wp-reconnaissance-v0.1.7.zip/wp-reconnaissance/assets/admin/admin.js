/**
 * Admin screen behaviour. Currently only the Settings screen's tab navigation, matching the
 * nav-tab/data-tab pattern WP Questionnaires already uses for its own Settings tabs.
 */
( function ( $ ) {
	'use strict';

	$( function () {
		$( document ).on( 'click', '.wpr-nav-tabs .nav-tab', function ( e ) {
			e.preventDefault();

			var tab = $( this ).data( 'tab' );

			$( '.wpr-nav-tabs .nav-tab' ).removeClass( 'nav-tab-active' );
			$( this ).addClass( 'nav-tab-active' );

			$( '.wpr-tab-panel' ).addClass( 'wpr-hidden' );
			$( '#tab-' + tab ).removeClass( 'wpr-hidden' );

			if ( window.history && window.history.replaceState ) {
				var url = new URL( window.location.href );
				url.searchParams.set( 'tab', tab );
				window.history.replaceState( null, '', url.toString() );
			}
		} );

		// Deep-linking: admin.php?page=wp-reconnaissance-settings&tab=shortcodes opens directly
		// on that tab.
		var initial = new URLSearchParams( window.location.search ).get( 'tab' );

		if ( initial && $( '#tab-' + initial ).length ) {
			$( '.wpr-nav-tabs .nav-tab[data-tab="' + initial + '"]' ).trigger( 'click' );
		}
	} );
}( jQuery ) );
