<?php
/**
 * Registers the dedicated customer role and extends the administrator role with plugin
 * capabilities. Per Section 18.1, customer accounts must never gain ordinary WordPress
 * administration capabilities.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

use Alltime\WPReconnaissance\Auth\CustomerPortalUrls;

/**
 * Role registration and capability wiring.
 */
final class Roles {

	public const CUSTOMER_ROLE    = 'wpr_customer';
	public const OPERATOR_ROLE    = 'wpr_operator';
	public const INTEGRATION_ROLE = 'wpr_integration';

	/**
	 * Registers the roles. Idempotent: safe to call on every activation.
	 */
	public static function register(): void {
		add_role(
			self::CUSTOMER_ROLE,
			__( 'Reconnaissance Customer', 'wp-reconnaissance' ),
			array_fill_keys( array_merge( array( 'read' ), Capabilities::customer_capabilities() ), true )
		);

		add_role(
			self::OPERATOR_ROLE,
			__( 'Reconnaissance Operator', 'wp-reconnaissance' ),
			array_fill_keys( array_merge( array( 'read' ), Capabilities::operator_capabilities() ), true )
		);

		/**
		 * Section 33's CRM/service-account integration (e.g. HaloPSA polling the REST API): a
		 * WordPress Application Password authenticated against a user in this role satisfies
		 * every read-only permission_callback in the REST API (they all check
		 * VIEW_ALL_RESULTS/VIEW_ASSIGNED_ORG), without granting any of the write capabilities
		 * (MANAGE_SCOPES, ISSUE_REPORTS, etc.) the full operator role carries.
		 */
		add_role(
			self::INTEGRATION_ROLE,
			__( 'Reconnaissance Integration', 'wp-reconnaissance' ),
			array_fill_keys( array( 'read', Capabilities::VIEW_ALL_RESULTS ), true )
		);

		$administrator = get_role( 'administrator' );

		if ( null === $administrator ) {
			return;
		}

		foreach ( Capabilities::operator_capabilities() as $capability ) {
			$administrator->add_cap( $capability );
		}
	}

	/**
	 * Hides the administration toolbar and blocks /wp-admin/ access for customer accounts,
	 * redirecting them to the customer portal instead.
	 */
	public static function boot(): void {
		add_filter( 'show_admin_bar', array( self::class, 'hide_admin_bar_for_customers' ) );
		add_action( 'admin_init', array( self::class, 'block_wp_admin_for_customers' ) );
	}

	/**
	 * @param bool $show Whether the admin bar would otherwise be shown.
	 */
	public static function hide_admin_bar_for_customers( bool $show ): bool {
		if ( self::current_user_is_customer_only() ) {
			return false;
		}

		return $show;
	}

	/**
	 * Redirects customer-only accounts away from /wp-admin/ (excluding AJAX requests) to the
	 * front-end customer portal per acceptance criterion #2.
	 */
	public static function block_wp_admin_for_customers(): void {
		if ( wp_doing_ajax() || ! self::current_user_is_customer_only() ) {
			return;
		}

		wp_safe_redirect( CustomerPortalUrls::url( 'account' ) );
		exit;
	}

	/**
	 * True when the current user holds only the customer role and no operator/administrator
	 * capabilities.
	 */
	private static function current_user_is_customer_only(): bool {
		if ( ! is_user_logged_in() ) {
			return false;
		}

		$user = wp_get_current_user();

		return in_array( self::CUSTOMER_ROLE, (array) $user->roles, true )
			&& ! $user->has_cap( Capabilities::MANAGE_SETTINGS );
	}
}
