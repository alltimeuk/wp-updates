<?php
/**
 * Handles the forgot-password / reset-password flow, per Section 18.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class PasswordResetService {

	// Public: CustomerAccountAdminService::send_password_reset_link() needs the same TTL for an
	// admin-triggered reset link, matching the visibility RegistrationService::
	// EMAIL_VERIFICATION_TTL_SECONDS already has for the equivalent reason.
	public const RESET_TTL_SECONDS        = HOUR_IN_SECONDS;
	private const MINIMUM_PASSWORD_LENGTH = 12;

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly AuthEventRepository $auth_events = new AuthEventRepository()
	) {}

	/**
	 * Always returns the same shape regardless of whether the address is registered - the
	 * caller shows an identical "if an account exists, an email has been sent" message either
	 * way (Section 18.1 anti-enumeration). Diagnostic logging (Settings > Diagnostics) still
	 * records the true outcome either way - it's a request-scoped trace for an admin to read, not
	 * something returned to the visitor, so it doesn't weaken anti-enumeration.
	 */
	public function request( string $email ): ?string {
		$account = $this->accounts->find_by_email( $email );

		if ( null === $account ) {
			$this->auth_events->record( 'password_reset_requested_unknown_email', null, $email );
			return null;
		}

		$this->audit_logger->log( 'account.password_reset_requested', 'customer_account', $account->user_id, $account->user_id );

		$token = $this->tokens->issue( $account->user_id, TokenType::PasswordReset, self::RESET_TTL_SECONDS );

		$this->auth_events->record( 'password_reset_token_issued', $account->user_id, $email );

		return $token;
	}

	/**
	 * @throws \InvalidArgumentException When the new password fails minimum requirements. Not
	 *                                     thrown for an invalid/expired token - callers check
	 *                                     the boolean return instead, again to avoid leaking
	 *                                     token state.
	 */
	public function reset( string $raw_token, string $new_password ): bool {
		// A hash, never the raw token itself - enough to correlate this row with the email link
		// that carried it (matching how MailQueueService already keys its own idempotency),
		// without being able to replay it from the log.
		$token_hash = hash( 'sha256', $raw_token );

		if ( strlen( $new_password ) < self::MINIMUM_PASSWORD_LENGTH ) {
			$this->auth_events->record( 'password_reset_failed_password_too_short', null, null, $token_hash );
			throw new \InvalidArgumentException( esc_html( 'Password must be at least ' . self::MINIMUM_PASSWORD_LENGTH . ' characters long.' ) );
		}

		$user_id = $this->tokens->consume( $raw_token, TokenType::PasswordReset );

		if ( null === $user_id ) {
			$this->auth_events->record( 'password_reset_failed_invalid_token', null, null, $token_hash );
			return false;
		}

		wp_set_password( $new_password, $user_id );

		// Section 18.1: rotate sessions after a password change - every existing session,
		// including the one that may have been hijacked, is invalidated.
		$this->accounts->destroy_all_sessions( $user_id );

		$this->audit_logger->log( 'account.password_reset_completed', 'customer_account', $user_id, $user_id );
		$this->auth_events->record( 'password_reset_succeeded', $user_id, null, $token_hash );

		return true;
	}
}
