<?php
/**
 * Operator-triggered actions against a customer account, per Section 18.4's `wpr_manage_customers`
 * capability - the admin-side counterpart to the self-service flows {@see PasswordResetService}
 * and email verification already provide, for the cases a customer can't complete those
 * themselves (a lost/expired verification link, a support request instead of self-service).
 *
 * Deliberately does not call {@see PasswordResetService::request()} for the reset-link action:
 * that method's own audit log entry hardcodes `actor_id` as the account holder themselves (correct
 * for its self-service caller, wrong here - an admin-triggered reset must be attributed to the
 * admin, not misattributed to the customer). This service issues the token directly instead,
 * mirroring what PasswordResetService/RegistrationService already do internally, and logs its own
 * actions with the operating admin as actor.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\AccountStatus;
use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\MailQueueService;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class CustomerAccountAdminService {

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly MailQueueService $mail_queue = new MailQueueService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @throws \InvalidArgumentException When no account exists, or it isn't currently
	 *                                     PendingEmailVerification - there's nothing to (re-)verify
	 *                                     otherwise.
	 */
	public function resend_verification_email( int $user_id, int $actor_id ): void {
		$account = $this->find_or_fail( $user_id );

		if ( AccountStatus::PendingEmailVerification !== $account->status ) {
			throw new \InvalidArgumentException( esc_html__( 'This account is already verified.', 'wp-reconnaissance' ) );
		}

		// issue() already invalidates any outstanding verification token for this user first, so
		// resending is always safe to call, even if a still-valid link was already sent.
		$token = $this->tokens->issue( $user_id, TokenType::EmailVerification, RegistrationService::EMAIL_VERIFICATION_TTL_SECONDS );

		$this->send_verification_email( $account, $token );

		$this->audit_logger->log( 'account.verification_email_resent', 'customer_account', $user_id, $actor_id );
	}

	/**
	 * @throws \InvalidArgumentException When no account exists, or it has been deleted.
	 */
	public function send_password_reset_link( int $user_id, int $actor_id ): void {
		$account = $this->find_or_fail( $user_id );

		if ( AccountStatus::Deleted === $account->status ) {
			throw new \InvalidArgumentException( esc_html__( 'This account has been deleted.', 'wp-reconnaissance' ) );
		}

		$token = $this->tokens->issue( $user_id, TokenType::PasswordReset, PasswordResetService::RESET_TTL_SECONDS );

		$this->send_password_reset_email( $account, $token );

		$this->audit_logger->log( 'account.password_reset_link_sent', 'customer_account', $user_id, $actor_id );
	}

	/**
	 * Reverses a previous {@see disable_account()} - deliberately not a general status setter, so
	 * it can never resurrect a Deleted account or override a status the Privacy Requests workflow
	 * owns (PrivacyRequestPending/ScheduledForDeletion).
	 *
	 * @throws \InvalidArgumentException When no account exists, or it isn't currently Suspended.
	 */
	public function enable_account( int $user_id, int $actor_id ): void {
		$account = $this->find_or_fail( $user_id );

		if ( AccountStatus::Suspended !== $account->status ) {
			throw new \InvalidArgumentException( esc_html__( 'Only a suspended account can be enabled.', 'wp-reconnaissance' ) );
		}

		$this->accounts->set_status( $user_id, AccountStatus::Active );
		$this->audit_logger->log( 'account.enabled', 'customer_account', $user_id, $actor_id );
	}

	/**
	 * @throws \InvalidArgumentException When no account exists, or it already cannot log in.
	 */
	public function disable_account( int $user_id, int $actor_id ): void {
		$account = $this->find_or_fail( $user_id );

		if ( ! $account->status->permits_login() ) {
			throw new \InvalidArgumentException( esc_html__( 'This account cannot currently log in.', 'wp-reconnaissance' ) );
		}

		$this->accounts->set_status( $user_id, AccountStatus::Suspended );

		// Section 18.4: "Customer sessions shall be invalidated when an account is suspended or
		// deleted" - set_status() alone doesn't do this, so it's done explicitly here.
		$this->accounts->destroy_all_sessions( $user_id );

		$this->audit_logger->log( 'account.disabled', 'customer_account', $user_id, $actor_id );
	}

	private function find_or_fail( int $user_id ): CustomerAccount {
		$account = $this->accounts->find( $user_id );

		if ( null === $account ) {
			throw new \InvalidArgumentException( esc_html__( 'Customer account not found.', 'wp-reconnaissance' ) );
		}

		return $account;
	}

	/**
	 * Mirrors {@see \Alltime\WPReconnaissance\Auth\AuthBootstrap::send_verification_email()}'s
	 * QueuedMessage shape exactly - that method is private to AuthBootstrap's self-service
	 * registration flow, so this is a small, deliberate duplicate rather than a cross-class call.
	 */
	private function send_verification_email( CustomerAccount $account, string $token ): void {
		$link = CustomerPortalUrls::url( 'verify-email', array( 'token' => $token ) );

		$this->mail_queue->enqueue(
			new QueuedMessage(
				idempotency_key: 'verify_email:' . hash( 'sha256', $token ),
				recipient: $account->email,
				template: 'verify_email',
				purpose: MailPurpose::AccountSecurity,
				subject: __( 'Verify your email address', 'wp-reconnaissance' ),
				html_body: sprintf( '<p>Follow this link to verify your email address: <a href="%1$s">%1$s</a></p>', esc_url( $link ) )
			)
		);
	}

	/**
	 * Mirrors {@see \Alltime\WPReconnaissance\Auth\AuthBootstrap::send_password_reset_email()}'s
	 * QueuedMessage shape exactly - see {@see send_verification_email()}'s docblock for why this
	 * is a deliberate duplicate rather than a cross-class call.
	 */
	private function send_password_reset_email( CustomerAccount $account, string $token ): void {
		$link = CustomerPortalUrls::url( 'reset-password', array( 'token' => $token ) );

		$this->mail_queue->enqueue(
			new QueuedMessage(
				idempotency_key: 'password_reset:' . hash( 'sha256', $token ),
				recipient: $account->email,
				template: 'password_reset',
				purpose: MailPurpose::AccountSecurity,
				subject: __( 'Reset your password', 'wp-reconnaissance' ),
				html_body: sprintf( '<p>Follow this link to reset your password: <a href="%1$s">%1$s</a></p>', esc_url( $link ) )
			)
		);
	}
}
