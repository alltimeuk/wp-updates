<?php
/**
 * Opt-in, request-scoped diagnostic trace for the customer login and password-reset flows -
 * Settings > Diagnostics's "Verbose login/password-reset logging" toggle. Distinct from
 * {@see \Alltime\WPReconnaissance\Support\AuditLogger}: that class is a compliance-oriented audit
 * trail (one row per meaningful account state change, and its own docblock explicitly forbids
 * passwords, tokens or raw evidence in its summary); this is the opposite shape - a narrow,
 * short-lived trace of which check failed (nonce, rate limit, wp_signon(), account status, token
 * validity) for the specific case those audit rows can't help with: diagnosing a still-unresolved
 * "it didn't work" report when the underlying code has already been proven correct in isolation.
 *
 * The verbose-logging setting is record()'s own on/off switch - it's a no-op unless enabled, so none of its
 * ~15 call sites across AuthBootstrap.php/PasswordResetService.php need their own guard. Never
 * pass a password or a raw token into $detail - a token's sha256 hash (matching how
 * {@see \Alltime\WPReconnaissance\Notifications\MailQueueService} already keys its own
 * idempotency) is fine for correlating log rows to a specific attempt without being able to
 * replay it.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Data\Schema;

final class AuthEventRepository {

	public function record( string $event_type, ?int $user_id, ?string $email, ?string $detail = null ): void {
		if ( ! (bool) get_option( 'wpr_verbose_auth_logging', false ) ) {
			return;
		}

		global $wpdb;

		$wpdb->insert(
			Schema::table( 'auth_events' ),
			array(
				'user_id'     => $user_id,
				'email'       => $email,
				'event_type'  => $event_type,
				'detail'      => $detail,
				'occurred_at' => current_time( 'mysql', true ),
			)
		);
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function find_recent( int $limit = 200 ): array {
		global $wpdb;

		$table = Schema::table( 'auth_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );

		return null !== $rows ? $rows : array();
	}

	public function clear(): void {
		global $wpdb;

		$table = Schema::table( 'auth_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier, not user input; a full clear is the whole point of this method.
		$wpdb->query( "DELETE FROM `{$table}`" );
	}
}
