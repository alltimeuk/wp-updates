<?php
/**
 * Resolves the URL for one of the customer portal's routes (see {@see AuthBootstrap::ROUTES}),
 * preferring a themed WordPress Page an admin has mapped to that route (via the Settings > Portal
 * pages tab) over the plugin's own raw, unstyled `/customer/<route>/` URL.
 *
 * Every link this plugin generates to one of its own customer-portal screens - the verification
 * and password-reset emails, the "please sign in" prompt on a gated shortcode page, the post-login
 * redirect, cross-links between screens - previously hardcoded the raw route regardless of whether
 * the admin had built a themed `[wpr_customer_*]` shortcode page instead, so even a fully themed
 * portal still bounced a visitor through unstyled pages at those specific moments. This is the
 * single place that decision now gets made, so every call site agrees.
 *
 * Deliberately static-only, never instantiating {@see AuthBootstrap}: its constructor pulls in
 * seven other services, which callers like {@see \Alltime\WPReconnaissance\Support\Roles} or
 * {@see \Alltime\WPReconnaissance\Shortcodes\GetStartedShortcode} - which need nothing else from
 * it - shouldn't have to drag in just to resolve one URL.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

final class CustomerPortalUrls {

	/**
	 * Per-request memoization: several render loops (the account dashboard's report links, the
	 * reports list, a report's version history) resolve the same route once per row - no need to
	 * re-run get_option()/get_permalink()/get_post_status() every time when only the query args
	 * differ.
	 *
	 * @var array<string,string>
	 */
	private static array $cache = array();

	/**
	 * @param array<string,mixed> $query_args
	 */
	public static function url( string $route, array $query_args = array() ): string {
		$base = self::$cache[ $route ] ??= self::resolve_base( $route );
		$url  = array() !== $query_args ? add_query_arg( $query_args, $base ) : $base;

		/**
		 * Filters the resolved URL for a customer-portal route - a developer-level override that
		 * doesn't require going through wp-admin, matching this codebase's existing hook-based
		 * extensibility precedent (litespeed_control_set_nocache in AuthBootstrap::send_no_cache_headers()).
		 *
		 * @param string               $url        The resolved URL.
		 * @param string               $route      The route slug (see AuthBootstrap::ROUTES).
		 * @param array<string,mixed>  $query_args Query args that were appended, if any.
		 */
		return (string) apply_filters( 'wpr_customer_portal_url', $url, $route, $query_args );
	}

	/**
	 * Test-only: clears the per-request memoization cache. Not reached by WordPress's own
	 * per-test database rollback, since it isn't database state - without this, a route mapping
	 * one test resolves (and therefore caches) would silently leak into a later, unrelated test
	 * sharing the same PHPUnit process, even after that test's own `update_option()` call to
	 * change or remove the mapping.
	 */
	public static function reset_cache_for_tests(): void {
		self::$cache = array();
	}

	private static function resolve_base( string $route ): string {
		$page_id = (int) get_option( 'wpr_customer_page_' . str_replace( '-', '_', $route ), 0 );

		if ( $page_id > 0
			&& 'publish' === get_post_status( $page_id )
			&& 'page' === get_post_type( $page_id )
		) {
			$permalink = get_permalink( $page_id );

			if ( false !== $permalink ) {
				return $permalink;
			}
		}

		return home_url( '/customer/' . $route . '/' );
	}
}
