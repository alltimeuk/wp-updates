<?php
/**
 * Table naming and dbDelta definitions for the Phase 1 core tables.
 *
 * Only the organisation/scope/job/observation/finding data model (Section 8) is defined here.
 * CRM, entitlement, remediation-task and mail tables are introduced by later migrations as
 * those modules are built, without altering the tables defined here.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data;

/**
 * Resolves prefixed table names and the dbDelta CREATE TABLE statements for schema version 1.
 */
final class Schema {

	/**
	 * @return array<string,string> Unprefixed table key => bare table name.
	 */
	public static function table_names(): array {
		return array(
			'organisations'               => 'wpr_organisations',
			'scopes'                      => 'wpr_scopes',
			'profiles'                    => 'wpr_profiles',
			'jobs'                        => 'wpr_jobs',
			'observations'                => 'wpr_observations',
			'evidence'                    => 'wpr_evidence',
			'findings'                    => 'wpr_findings',
			'finding_events'              => 'wpr_finding_events',
			'audit_log'                   => 'wpr_audit_log',
			'auth_tokens'                 => 'wpr_auth_tokens',
			'remediation_tasks'           => 'wpr_remediation_tasks',
			'task_events'                 => 'wpr_task_events',
			'reports'                     => 'wpr_reports',
			'entitlements'                => 'wpr_entitlements',
			'mail_queue'                  => 'wpr_mail_queue',
			'mail_events'                 => 'wpr_mail_events',
			'privacy_requests'            => 'wpr_privacy_requests',
			'abuse_signals'               => 'wpr_abuse_signals',
			'blocklist'                   => 'wpr_blocklist',
			'notification_digest_entries' => 'wpr_notification_digest_entries',
			'plans'                       => 'wpr_plans',
			'auth_events'                 => 'wpr_auth_events',
		);
	}

	/**
	 * Returns the fully prefixed table name.
	 */
	public static function table( string $key ): string {
		global $wpdb;

		$names = self::table_names();

		if ( ! isset( $names[ $key ] ) ) {
			throw new \InvalidArgumentException( esc_html( "Unknown WP Reconnaissance table key: {$key}" ) );
		}

		return $wpdb->prefix . $names[ $key ];
	}

	/**
	 * Builds the dbDelta-compatible CREATE TABLE statements for schema version 1.
	 *
	 * @return string[]
	 */
	public static function version_1_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$statements      = array();

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_organisations (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			slug VARCHAR(191) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'active',
			primary_contact_id BIGINT UNSIGNED NULL,
			timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
			default_profile_id BIGINT UNSIGNED NULL,
			retention_policy VARCHAR(64) NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_profiles (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			organisation_id BIGINT UNSIGNED NULL,
			name VARCHAR(191) NOT NULL,
			enabled_collectors TEXT NOT NULL,
			collector_timeouts TEXT NULL,
			schedule VARCHAR(64) NULL,
			change_thresholds TEXT NULL,
			notification_rules TEXT NULL,
			rule_packs TEXT NULL,
			evidence_retention_days INT UNSIGNED NULL,
			max_lookalike_candidates INT UNSIGNED NOT NULL DEFAULT 500,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY organisation_id (organisation_id)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_scopes (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			organisation_id BIGINT UNSIGNED NOT NULL,
			name VARCHAR(191) NOT NULL,
			domain_ascii VARCHAR(253) NOT NULL,
			domain_display VARCHAR(253) NOT NULL,
			registrable_domain VARCHAR(253) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'pending',
			authorisation_status VARCHAR(32) NOT NULL DEFAULT 'pending',
			authorised_by BIGINT UNSIGNED NULL,
			authorisation_reference VARCHAR(191) NULL,
			authorised_from DATETIME NULL,
			authorised_until DATETIME NULL,
			permitted_collectors TEXT NULL,
			permitted_schedule VARCHAR(64) NULL,
			known_subdomains LONGTEXT NULL,
			known_dkim_selectors LONGTEXT NULL,
			expected_state LONGTEXT NULL,
			monitoring_profile_id BIGINT UNSIGNED NULL,
			notes TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY organisation_domain (organisation_id, domain_ascii),
			KEY registrable_domain (registrable_domain),
			KEY status (status)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_jobs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			job_uuid VARCHAR(64) NOT NULL,
			organisation_id BIGINT UNSIGNED NOT NULL,
			scope_id BIGINT UNSIGNED NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'pending',
			adapter VARCHAR(32) NULL,
			actor_id BIGINT UNSIGNED NULL,
			manifest_hash CHAR(64) NULL,
			worker_version VARCHAR(32) NULL,
			exit_code SMALLINT NULL,
			error_category VARCHAR(64) NULL,
			requested_at DATETIME NOT NULL,
			queued_at DATETIME NULL,
			started_at DATETIME NULL,
			completed_at DATETIME NULL,
			expires_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY job_uuid (job_uuid),
			KEY scope_id (scope_id),
			KEY organisation_id (organisation_id),
			KEY status (status)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_observations (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scope_id BIGINT UNSIGNED NOT NULL,
			job_id BIGINT UNSIGNED NOT NULL,
			observed_at DATETIME NOT NULL,
			collector_versions TEXT NULL,
			schema_version VARCHAR(16) NOT NULL,
			collection_status VARCHAR(32) NOT NULL,
			raw_evidence_ref VARCHAR(191) NULL,
			limitations TEXT NULL,
			failed_collectors TEXT NULL,
			integrity_hash CHAR(64) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY job_id (job_id),
			KEY scope_id (scope_id),
			KEY observed_at (observed_at)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_evidence (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			observation_id BIGINT UNSIGNED NOT NULL,
			collector VARCHAR(32) NOT NULL,
			collector_version VARCHAR(32) NOT NULL,
			status VARCHAR(32) NOT NULL,
			observed_at DATETIME NOT NULL,
			source VARCHAR(191) NULL,
			duration_ms INT UNSIGNED NULL,
			data LONGTEXT NULL,
			storage_ref VARCHAR(191) NULL,
			limitations TEXT NULL,
			errors TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY observation_id (observation_id),
			KEY collector (collector)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_findings (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			finding_uuid VARCHAR(64) NOT NULL,
			organisation_id BIGINT UNSIGNED NOT NULL,
			scope_id BIGINT UNSIGNED NOT NULL,
			rule_id VARCHAR(64) NOT NULL,
			rule_version VARCHAR(16) NOT NULL,
			title VARCHAR(191) NOT NULL,
			category VARCHAR(32) NOT NULL,
			severity VARCHAR(16) NOT NULL,
			confidence VARCHAR(16) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'new',
			first_observed_at DATETIME NOT NULL,
			last_observed_at DATETIME NOT NULL,
			resolved_at DATETIME NULL,
			evidence_refs TEXT NULL,
			expected_state LONGTEXT NULL,
			observed_state LONGTEXT NULL,
			risk_statement TEXT NULL,
			recommendation TEXT NULL,
			standards_references TEXT NULL,
			assigned_owner BIGINT UNSIGNED NULL,
			due_date DATE NULL,
			operator_notes TEXT NULL,
			suppression_reason TEXT NULL,
			suppression_expires_at DATETIME NULL,
			risk_accepted_by BIGINT UNSIGNED NULL,
			risk_accept_review_date DATE NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY finding_uuid (finding_uuid),
			KEY organisation_id (organisation_id),
			KEY scope_id (scope_id),
			KEY rule_id (rule_id),
			KEY status (status),
			KEY severity (severity)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_finding_events (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			finding_id BIGINT UNSIGNED NOT NULL,
			observation_id BIGINT UNSIGNED NULL,
			event_type VARCHAR(32) NOT NULL,
			actor_id BIGINT UNSIGNED NULL,
			summary TEXT NULL,
			occurred_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY finding_id (finding_id),
			KEY event_type (event_type),
			KEY occurred_at (occurred_at)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_audit_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			actor_id BIGINT UNSIGNED NULL,
			action VARCHAR(128) NOT NULL,
			object_type VARCHAR(64) NOT NULL,
			object_id BIGINT UNSIGNED NULL,
			source VARCHAR(32) NOT NULL DEFAULT 'admin',
			outcome VARCHAR(32) NOT NULL DEFAULT 'success',
			summary TEXT NULL,
			occurred_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY object_type_id (object_type, object_id),
			KEY action (action),
			KEY occurred_at (occurred_at)
		) {$charset_collate};";

		return $statements;
	}

	/**
	 * Schema version 2: the customer authentication token store (Section 18.1). Email
	 * verification and password-reset tokens share one table, distinguished by `type`; only
	 * the SHA-256 hash of each token is ever stored, never the raw value.
	 *
	 * @return string[]
	 */
	public static function version_2_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_auth_tokens (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				token_hash CHAR(64) NOT NULL,
				type VARCHAR(32) NOT NULL,
				expires_at DATETIME NOT NULL,
				used_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY user_id_type (user_id, type)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 3: remediation tasks and their event history (Section 21.3), and issued
	 * reports (Section 21). A report row stores the full report.schema.json-conformant document
	 * as JSON rather than normalising it into columns - reports are immutable and versioned, so
	 * the stored document *is* the record; HTML/Markdown/JSON output are all just renderings of
	 * it, never separately stored copies that could drift from one another.
	 *
	 * @return string[]
	 */
	public static function version_3_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_remediation_tasks (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				task_uuid VARCHAR(64) NOT NULL,
				organisation_id BIGINT UNSIGNED NOT NULL,
				scope_id BIGINT UNSIGNED NOT NULL,
				finding_id BIGINT UNSIGNED NOT NULL,
				rule_id VARCHAR(64) NOT NULL,
				title VARCHAR(191) NOT NULL,
				technical_subject VARCHAR(64) NOT NULL,
				priority_band VARCHAR(8) NOT NULL,
				priority_score SMALLINT UNSIGNED NOT NULL DEFAULT 0,
				priority_explanation LONGTEXT NULL,
				recommended_order INT UNSIGNED NOT NULL DEFAULT 0,
				rationale TEXT NULL,
				implementation_steps LONGTEXT NULL,
				validation_steps LONGTEXT NULL,
				dependencies LONGTEXT NULL,
				suggested_owner_type VARCHAR(32) NULL,
				estimated_effort_band VARCHAR(16) NULL,
				target_date DATE NULL,
				reminder_requested TINYINT(1) NOT NULL DEFAULT 0,
				status VARCHAR(32) NOT NULL DEFAULT 'not_started',
				customer_notes TEXT NULL,
				operator_notes TEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				completed_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY task_uuid (task_uuid),
				KEY finding_id (finding_id),
				KEY scope_id (scope_id),
				KEY organisation_id (organisation_id),
				KEY status (status),
				KEY priority_band (priority_band)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpr_task_events (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				task_id BIGINT UNSIGNED NOT NULL,
				event_type VARCHAR(32) NOT NULL,
				actor_id BIGINT UNSIGNED NULL,
				summary TEXT NULL,
				occurred_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY task_id (task_id),
				KEY event_type (event_type),
				KEY occurred_at (occurred_at)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpr_reports (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				report_uuid VARCHAR(64) NOT NULL,
				organisation_id BIGINT UNSIGNED NOT NULL,
				scope_id BIGINT UNSIGNED NOT NULL,
				observation_id BIGINT UNSIGNED NOT NULL,
				version INT UNSIGNED NOT NULL,
				document LONGTEXT NOT NULL,
				generated_at DATETIME NOT NULL,
				generated_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY report_uuid (report_uuid),
				UNIQUE KEY scope_version (scope_id, version),
				KEY organisation_id (organisation_id)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 4: entitlements (Section 5.5). `contact_id` references
	 * `Alltime\CustomerPlatform`'s `atcp_contacts` table - a plain integer reference rather than
	 * a foreign key, per Section 6.1.3: "Cross-plugin calls shall use PHP services, actions or
	 * filters, not direct writes to another plugin's tables."
	 *
	 * @return string[]
	 */
	public static function version_4_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_entitlements (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL,
				tool_id VARCHAR(64) NOT NULL,
				registrable_domain VARCHAR(253) NOT NULL,
				state VARCHAR(32) NOT NULL,
				reserved_at DATETIME NULL,
				consumed_at DATETIME NULL,
				expires_at DATETIME NULL,
				granted_by BIGINT UNSIGNED NULL,
				reason TEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY contact_tool_domain (contact_id, tool_id, registrable_domain),
				KEY state (state)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 5: the persistent transactional mail queue and its delivery-state history,
	 * per Section 22.5: "Record recipient, template, purpose, provider, provider ID, state and
	 * timestamps... Prevent duplicate sends through idempotency keys."
	 *
	 * @return string[]
	 */
	public static function version_5_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_mail_queue (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				idempotency_key VARCHAR(191) NOT NULL,
				recipient VARCHAR(191) NOT NULL,
				template VARCHAR(64) NOT NULL,
				purpose VARCHAR(32) NOT NULL,
				subject VARCHAR(191) NOT NULL,
				html_body LONGTEXT NOT NULL,
				merge_fields LONGTEXT NULL,
				state VARCHAR(16) NOT NULL DEFAULT 'pending',
				provider_id VARCHAR(32) NULL,
				provider_message_id VARCHAR(191) NULL,
				attempt_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
				next_attempt_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				sent_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY idempotency_key (idempotency_key),
				KEY recipient (recipient),
				KEY state (state),
				KEY purpose (purpose)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpr_mail_events (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				message_id BIGINT UNSIGNED NOT NULL,
				event_type VARCHAR(32) NOT NULL,
				detail TEXT NULL,
				occurred_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY message_id (message_id),
				KEY event_type (event_type)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 6: data-subject rights requests (Section 26.3/26.4). One row per request,
	 * covering every right in Section 26.5 (`right_type`) through a single admin workflow rather
	 * than a separate table per right - `wpr_audit_log` (object_type = 'privacy_request') already
	 * provides the "audit trail" Section 26.4 requires for status changes, so no separate events
	 * table is added here.
	 *
	 * @return string[]
	 */
	public static function version_6_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_privacy_requests (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				request_uuid VARCHAR(64) NOT NULL,
				user_id BIGINT UNSIGNED NULL,
				email VARCHAR(191) NOT NULL,
				right_type VARCHAR(32) NOT NULL,
				status VARCHAR(32) NOT NULL DEFAULT 'submitted',
				channel VARCHAR(32) NOT NULL DEFAULT 'portal',
				details TEXT NULL,
				restricted TINYINT UNSIGNED NOT NULL DEFAULT 0,
				identity_verified_at DATETIME NULL,
				assigned_to BIGINT UNSIGNED NULL,
				outcome_summary TEXT NULL,
				refusal_reason TEXT NULL,
				due_at DATETIME NOT NULL,
				completed_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY request_uuid (request_uuid),
				KEY email (email),
				KEY user_id (user_id),
				KEY status (status),
				KEY due_at (due_at)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 7: the anti-abuse review queue and block/allow lists (Section 5.6).
	 *
	 * `wpr_abuse_signals` is the administrative review-and-release queue: one row per automated
	 * or manual eligibility signal (disposable email, duplicate domain, blocked subject, max
	 * queued jobs, failed bot challenge). A signal is a review signal, not an infallible
	 * rejection - an operator reviews it and either releases, blocks or dismisses it. `context`
	 * holds the JSON payload (names, organisation, domain, IP, user id) needed to act on the
	 * signal without re-deriving it.
	 *
	 * `wpr_blocklist` is the operator-maintained block/allow list. A `block` entry rejects the
	 * matching subject outright; an `allow` entry overrides a block for the same subject. Entries
	 * are scoped by `match_type` (email, domain or IP) and may carry an optional expiry.
	 *
	 * @return string[]
	 */
	public static function version_7_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_abuse_signals (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				signal_type VARCHAR(32) NOT NULL,
				subject_type VARCHAR(16) NOT NULL,
				subject_value VARCHAR(191) NOT NULL,
				severity VARCHAR(16) NOT NULL DEFAULT 'review',
				state VARCHAR(16) NOT NULL DEFAULT 'open',
				context LONGTEXT NULL,
				reviewed_by BIGINT UNSIGNED NULL,
				reviewed_at DATETIME NULL,
				review_note TEXT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY signal_type (signal_type),
				KEY state (state),
				KEY subject (subject_type, subject_value),
				KEY created_at (created_at)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpr_blocklist (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				list_type VARCHAR(8) NOT NULL,
				match_type VARCHAR(16) NOT NULL,
				value VARCHAR(191) NOT NULL,
				reason TEXT NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				expires_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY list_match_value (list_type, match_type, value),
				KEY match_type_value (match_type, value)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 8: the customer-requested remediation task reminder flag (Section 22.5
	 * "Remediation reminder where requested"). A single additive column on the existing
	 * `wpr_remediation_tasks` table; dbDelta adds it to already-installed tables and the fresh
	 * CREATE TABLE below is a no-op for new installs (the column is also present in
	 * {@see version_3_statements()}).
	 *
	 * @return string[]
	 */
	public static function version_8_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_remediation_tasks (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				task_uuid VARCHAR(64) NOT NULL,
				organisation_id BIGINT UNSIGNED NOT NULL,
				scope_id BIGINT UNSIGNED NOT NULL,
				finding_id BIGINT UNSIGNED NOT NULL,
				rule_id VARCHAR(64) NOT NULL,
				title VARCHAR(191) NOT NULL,
				technical_subject VARCHAR(64) NOT NULL,
				priority_band VARCHAR(8) NOT NULL,
				priority_score SMALLINT UNSIGNED NOT NULL DEFAULT 0,
				priority_explanation LONGTEXT NULL,
				recommended_order INT UNSIGNED NOT NULL DEFAULT 0,
				rationale TEXT NULL,
				implementation_steps LONGTEXT NULL,
				validation_steps LONGTEXT NULL,
				dependencies LONGTEXT NULL,
				suggested_owner_type VARCHAR(32) NULL,
				estimated_effort_band VARCHAR(16) NULL,
				target_date DATE NULL,
				reminder_requested TINYINT(1) NOT NULL DEFAULT 0,
				status VARCHAR(32) NOT NULL DEFAULT 'not_started',
				customer_notes TEXT NULL,
				operator_notes TEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				completed_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY task_uuid (task_uuid),
				KEY finding_id (finding_id),
				KEY scope_id (scope_id),
				KEY organisation_id (organisation_id),
				KEY status (status),
				KEY priority_band (priority_band)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 9: durable recurring assessment schedules (Section 33). Three additive
	 * columns on the existing `wpr_scopes` table; dbDelta adds them to already-installed tables
	 * and the fresh CREATE TABLE below is a no-op for new installs.
	 *
	 * @return string[]
	 */
	public static function version_9_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_scopes (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				organisation_id BIGINT UNSIGNED NOT NULL,
				name VARCHAR(191) NOT NULL,
				domain_ascii VARCHAR(253) NOT NULL,
				domain_display VARCHAR(253) NOT NULL,
				registrable_domain VARCHAR(253) NOT NULL,
				status VARCHAR(32) NOT NULL DEFAULT 'pending',
				authorisation_status VARCHAR(32) NOT NULL DEFAULT 'pending',
				authorised_by BIGINT UNSIGNED NULL,
				authorisation_reference VARCHAR(191) NULL,
				authorised_from DATETIME NULL,
				authorised_until DATETIME NULL,
				permitted_collectors TEXT NULL,
				permitted_schedule VARCHAR(64) NULL,
				known_subdomains LONGTEXT NULL,
				known_dkim_selectors LONGTEXT NULL,
				expected_state LONGTEXT NULL,
				monitoring_profile_id BIGINT UNSIGNED NULL,
				notes TEXT NULL,
				monitoring_schedule VARCHAR(64) NULL,
				next_assessment_due_at DATETIME NULL,
				last_scheduled_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY organisation_domain (organisation_id, domain_ascii),
				KEY registrable_domain (registrable_domain),
				KEY status (status),
				KEY next_assessment_due_at (next_assessment_due_at)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 10: customer-configurable notifications (Section 33). A single additive
	 * column on `wpr_remediation_tasks` (per-task reminder lookahead, overriding the previous
	 * system-wide constant) plus a new table backing the daily-digest delivery option - pending
	 * notification summaries for accounts that chose digest over immediate delivery, cleared out
	 * once folded into a sent digest email.
	 *
	 * @return string[]
	 */
	public static function version_10_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_remediation_tasks (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				task_uuid VARCHAR(64) NOT NULL,
				organisation_id BIGINT UNSIGNED NOT NULL,
				scope_id BIGINT UNSIGNED NOT NULL,
				finding_id BIGINT UNSIGNED NOT NULL,
				rule_id VARCHAR(64) NOT NULL,
				title VARCHAR(191) NOT NULL,
				technical_subject VARCHAR(64) NOT NULL,
				priority_band VARCHAR(8) NOT NULL,
				priority_score SMALLINT UNSIGNED NOT NULL DEFAULT 0,
				priority_explanation LONGTEXT NULL,
				recommended_order INT UNSIGNED NOT NULL DEFAULT 0,
				rationale TEXT NULL,
				implementation_steps LONGTEXT NULL,
				validation_steps LONGTEXT NULL,
				dependencies LONGTEXT NULL,
				suggested_owner_type VARCHAR(32) NULL,
				estimated_effort_band VARCHAR(16) NULL,
				target_date DATE NULL,
				reminder_requested TINYINT(1) NOT NULL DEFAULT 0,
				reminder_days_before SMALLINT UNSIGNED NULL,
				status VARCHAR(32) NOT NULL DEFAULT 'not_started',
				customer_notes TEXT NULL,
				operator_notes TEXT NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				completed_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY task_uuid (task_uuid),
				KEY finding_id (finding_id),
				KEY scope_id (scope_id),
				KEY organisation_id (organisation_id),
				KEY status (status),
				KEY priority_band (priority_band)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpr_notification_digest_entries (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				organisation_id BIGINT UNSIGNED NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				idempotency_key VARCHAR(191) NOT NULL,
				subject VARCHAR(191) NOT NULL,
				summary TEXT NOT NULL,
				created_at DATETIME NOT NULL,
				sent_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY idempotency_key (idempotency_key),
				KEY user_id_sent_at (user_id, sent_at)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 11: managed entitlement plans (Section 33 "repeat, paid and managed-service
	 * entitlements"). A new `wpr_plans` table, plus a single additive `plan_id` column on the
	 * existing `wpr_organisations` table; dbDelta adds it to already-installed tables and the
	 * fresh CREATE TABLE below is a no-op for new installs.
	 *
	 * @return string[]
	 */
	public static function version_11_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_plans (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				name VARCHAR(191) NOT NULL,
				slug VARCHAR(191) NOT NULL,
				max_active_scopes INT UNSIGNED NULL,
				rerun_interval_days INT UNSIGNED NULL,
				min_schedule_frequency VARCHAR(64) NULL,
				external_billing_reference VARCHAR(191) NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY slug (slug)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}wpr_organisations (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				name VARCHAR(191) NOT NULL,
				slug VARCHAR(191) NOT NULL,
				status VARCHAR(32) NOT NULL DEFAULT 'active',
				primary_contact_id BIGINT UNSIGNED NULL,
				timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
				default_profile_id BIGINT UNSIGNED NULL,
				retention_policy VARCHAR(64) NULL,
				plan_id BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY slug (slug),
				KEY status (status)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 12: DNS TXT domain-ownership verification. Five additive columns on the
	 * existing `wpr_scopes` table; dbDelta adds them to already-installed tables and the fresh
	 * CREATE TABLE below is a no-op for new installs.
	 *
	 * @return string[]
	 */
	public static function version_12_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_scopes (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				organisation_id BIGINT UNSIGNED NOT NULL,
				name VARCHAR(191) NOT NULL,
				domain_ascii VARCHAR(253) NOT NULL,
				domain_display VARCHAR(253) NOT NULL,
				registrable_domain VARCHAR(253) NOT NULL,
				status VARCHAR(32) NOT NULL DEFAULT 'pending',
				authorisation_status VARCHAR(32) NOT NULL DEFAULT 'pending',
				authorised_by BIGINT UNSIGNED NULL,
				authorisation_reference VARCHAR(191) NULL,
				authorised_from DATETIME NULL,
				authorised_until DATETIME NULL,
				permitted_collectors TEXT NULL,
				permitted_schedule VARCHAR(64) NULL,
				known_subdomains LONGTEXT NULL,
				known_dkim_selectors LONGTEXT NULL,
				expected_state LONGTEXT NULL,
				monitoring_profile_id BIGINT UNSIGNED NULL,
				notes TEXT NULL,
				monitoring_schedule VARCHAR(64) NULL,
				next_assessment_due_at DATETIME NULL,
				last_scheduled_at DATETIME NULL,
				domain_verification_status VARCHAR(32) NOT NULL DEFAULT 'not_started',
				domain_verification_secret_hash VARCHAR(64) NULL,
				domain_verification_requested_at DATETIME NULL,
				domain_verification_requested_by BIGINT UNSIGNED NULL,
				domain_verified_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY organisation_domain (organisation_id, domain_ascii),
				KEY registrable_domain (registrable_domain),
				KEY status (status),
				KEY next_assessment_due_at (next_assessment_due_at),
				KEY domain_verification_status (domain_verification_status)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 13: opt-in verbose diagnostic logging for the customer login and
	 * password-reset flows (Settings > Diagnostics) - a request-scoped trace of which check
	 * failed (nonce, rate limit, wp_signon(), account status, token validity), not an audit-log
	 * entry and never a password or raw token. See {@see \Alltime\WPReconnaissance\Auth\AuthEventRepository}.
	 *
	 * @return string[]
	 */
	public static function version_13_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_auth_events (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NULL,
				email VARCHAR(255) NULL,
				event_type VARCHAR(64) NOT NULL,
				detail TEXT NULL,
				occurred_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY event_type (event_type),
				KEY occurred_at (occurred_at)
			) {$charset_collate};",
		);
	}
}
