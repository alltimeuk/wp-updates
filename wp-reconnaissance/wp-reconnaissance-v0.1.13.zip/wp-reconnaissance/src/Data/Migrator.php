<?php
/**
 * Incremental, idempotent schema migrations driven by `dbDelta()`.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data;

use Alltime\WPReconnaissance\Data\Enums\MigrationFailureClassification;
use Alltime\WPReconnaissance\Support\AuditLogger;

use const Alltime\WPReconnaissance\WPR_SCHEMA_VERSION;

/**
 * Installs and upgrades the plugin's database schema.
 *
 * Each schema version is a self-contained, additive step. Steps never drop columns or tables;
 * destructive changes belong to an explicit, separately reviewed later migration.
 */
final class Migrator {

	private const SCHEMA_VERSION_OPTION = 'wpr_db_schema_version';

	/**
	 * Absence means healthy. Present only while a version step has failed; cleared the moment a
	 * later boot's retry reaches WPR_SCHEMA_VERSION. Never contains $wpdb->last_error's raw text -
	 * only a safe MigrationFailureClassification value - see record_failure().
	 */
	private const FAILURE_OPTION = 'wpr_migration_failure';

	/**
	 * Runs on activation. Applies every migration step up to the current schema version.
	 */
	public static function install(): void {
		self::maybe_upgrade();
	}

	/**
	 * Runs on every boot; a no-op unless the stored schema version is behind the current one,
	 * which covers plugin upgrades without a re-activation step.
	 */
	public static function maybe_upgrade(): void {
		global $wpdb;

		$current = (int) get_option( self::SCHEMA_VERSION_OPTION, 0 );

		if ( $current >= WPR_SCHEMA_VERSION ) {
			self::maybe_clear_failure_state();
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		for ( $version = $current + 1; $version <= WPR_SCHEMA_VERSION; $version++ ) {
			$method = "apply_version_{$version}";

			if ( method_exists( self::class, $method ) && ! self::$method() ) {
				// Captured before anything else touches $wpdb (including get_option() below, which
				// resets last_error on its own success) - stop here rather than advancing past a
				// step that didn't actually complete. This version (and anything after it) is
				// retried on the next boot once the underlying issue is fixed - the loop never runs
				// update_option() for it.
				self::record_failure( $version, $current, (string) $wpdb->last_error );
				add_action( 'admin_notices', array( self::class, 'render_admin_notice' ) );
				return;
			}

			update_option( self::SCHEMA_VERSION_OPTION, $version, true );
		}

		self::maybe_clear_failure_state();
	}

	/**
	 * Always records the attempt (refreshing last_seen_at/occurrences, cheap and idempotent), but
	 * only writes a new wpr_audit_log row when the failing target version is new - a still-broken
	 * site retries on every boot, and logging identically on every one of those would grow the
	 * audit log without bound for a single ongoing problem.
	 */
	private static function record_failure( int $target_version, int $current_version, string $raw_error ): void {
		$classification = MigrationFailureClassification::classify_from_error( $raw_error );
		$now            = current_time( 'mysql', true );
		$existing       = get_option( self::FAILURE_OPTION, null );
		$is_new_failure = ! is_array( $existing ) || ( $existing['target_version'] ?? null ) !== $target_version;

		update_option(
			self::FAILURE_OPTION,
			array(
				'target_version'  => $target_version,
				'current_version' => $current_version,
				'classification'  => $classification->value,
				'first_seen_at'   => $is_new_failure ? $now : ( $existing['first_seen_at'] ?? $now ),
				'last_seen_at'    => $now,
				'occurrences'     => $is_new_failure ? 1 : ( (int) ( $existing['occurrences'] ?? 0 ) + 1 ),
			),
			true
		);

		if ( $is_new_failure ) {
			( new AuditLogger() )->log(
				'migration.upgrade_failed',
				'schema',
				null,
				null,
				outcome: 'failure',
				summary: sprintf( 'Schema upgrade to version %d failed (%s).', $target_version, $classification->value ),
				source: 'system'
			);
		}
	}

	/**
	 * Called from both of maybe_upgrade()'s "the schema is current" exits - the early return for an
	 * already-current install, and falling through the loop after every step succeeds. A normal
	 * install where get_option() returns null here is the common case and does nothing.
	 */
	private static function maybe_clear_failure_state(): void {
		if ( ! is_array( get_option( self::FAILURE_OPTION, null ) ) ) {
			return;
		}

		delete_option( self::FAILURE_OPTION );

		( new AuditLogger() )->log(
			'migration.recovered',
			'schema',
			null,
			null,
			summary: sprintf( 'Schema upgrade recovered; stored version is now %d.', WPR_SCHEMA_VERSION ),
			source: 'system'
		);
	}

	/**
	 * Registered on admin_notices only while a failure is on record (see maybe_upgrade()) - never
	 * shows the underlying error, only that something needs attention; Site Health carries the
	 * classification/occurrence detail for anyone who follows the notice there.
	 */
	public static function render_admin_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			esc_html__( 'WP Reconnaissance\'s database schema failed to upgrade; some functionality may not work correctly until this is resolved. It will keep retrying automatically. See Tools &raquo; Site Health for details.', 'wp-reconnaissance' )
		);
	}

	/**
	 * Runs each statement through dbDelta(), stopping at (and reporting) the first one whose own
	 * SQL failed. dbDelta() never throws on a failing statement, so `$wpdb->last_error` - reset
	 * immediately before each individual statement, not once for the whole batch - is the only
	 * signal available. A version step with several CREATE TABLE statements (most of them do)
	 * must not have an early failure masked by a later statement's success, which checking
	 * `$wpdb->last_error` only once per step, after the last statement, would do.
	 *
	 * @param string[] $statements
	 */
	private static function run_statements( array $statements ): bool {
		global $wpdb;

		foreach ( $statements as $statement ) {
			$wpdb->last_error = '';

			dbDelta( $statement );

			if ( '' !== $wpdb->last_error ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Removes plugin tables and options. Only invoked from uninstall.php after an explicit
	 * administrator opt-in via the "wpr_remove_data_on_uninstall" option.
	 */
	public static function uninstall(): void {
		global $wpdb;

		// Drop in dependency order (children before parents).
		$drop_order = array( 'auth_events', 'notification_digest_entries', 'plans', 'abuse_signals', 'blocklist', 'privacy_requests', 'mail_events', 'mail_queue', 'entitlements', 'reports', 'task_events', 'remediation_tasks', 'auth_tokens', 'finding_events', 'findings', 'evidence', 'observations', 'jobs', 'scopes', 'profiles', 'audit_log', 'organisations' );

		foreach ( $drop_order as $key ) {
			$table = Schema::table( $key );
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier (Schema::table()), never user input.
		}

		delete_option( self::SCHEMA_VERSION_OPTION );
		delete_option( self::FAILURE_OPTION );
		delete_option( 'wpr_local_adapter_enabled' );
		delete_option( 'wpr_remove_data_on_uninstall' );

		// Mail-provider credentials (Section 22) - secrets must not survive uninstall.
		delete_option( 'wpr_mail_provider' );
		delete_option( 'wpr_gmail_oauth_client_id' );
		delete_option( 'wpr_gmail_oauth_client_secret' );
		delete_option( 'wpr_gmail_sender_address' );
		delete_option( 'wpr_gmail_refresh_token' );
		delete_option( 'wpr_ses_region' );
		delete_option( 'wpr_ses_access_key_id' );
		delete_option( 'wpr_ses_secret_access_key' );
		delete_option( 'wpr_ses_sender_address' );
	}

	/**
	 * Schema version 1: the Phase 1 core tables (organisations, scopes, profiles, jobs,
	 * observations, evidence, findings, finding_events, audit_log).
	 */
	private static function apply_version_1(): bool {
		return self::run_statements( Schema::version_1_statements() );
	}

	/**
	 * Schema version 2: the customer authentication token store (Section 18.1).
	 */
	private static function apply_version_2(): bool {
		return self::run_statements( Schema::version_2_statements() );
	}

	/**
	 * Schema version 3: remediation tasks, their event history, and issued reports (Section 21).
	 */
	private static function apply_version_3(): bool {
		return self::run_statements( Schema::version_3_statements() );
	}

	/**
	 * Schema version 4: entitlements (Section 5.5).
	 */
	private static function apply_version_4(): bool {
		return self::run_statements( Schema::version_4_statements() );
	}

	/**
	 * Schema version 5: the persistent mail queue and its delivery-state history (Section 22.5).
	 */
	private static function apply_version_5(): bool {
		return self::run_statements( Schema::version_5_statements() );
	}

	/**
	 * Schema version 6: data-subject rights requests (Section 26.3/26.4).
	 */
	private static function apply_version_6(): bool {
		return self::run_statements( Schema::version_6_statements() );
	}

	/**
	 * Schema version 7: the anti-abuse review queue and block/allow lists (Section 5.6).
	 */
	private static function apply_version_7(): bool {
		return self::run_statements( Schema::version_7_statements() );
	}

	private static function apply_version_8(): bool {
		return self::run_statements( Schema::version_8_statements() );
	}

	/**
	 * Schema version 9: durable recurring assessment schedules (Section 33).
	 */
	private static function apply_version_9(): bool {
		return self::run_statements( Schema::version_9_statements() );
	}

	/**
	 * Schema version 10: customer-configurable notifications (Section 33).
	 */
	private static function apply_version_10(): bool {
		return self::run_statements( Schema::version_10_statements() );
	}

	/**
	 * Schema version 11: managed entitlement plans (Section 33).
	 */
	private static function apply_version_11(): bool {
		return self::run_statements( Schema::version_11_statements() );
	}

	/**
	 * Schema version 12: DNS TXT domain-ownership verification.
	 */
	private static function apply_version_12(): bool {
		return self::run_statements( Schema::version_12_statements() );
	}

	/**
	 * Schema version 13: opt-in verbose diagnostic logging for login/password-reset.
	 */
	private static function apply_version_13(): bool {
		return self::run_statements( Schema::version_13_statements() );
	}
}
