<?php
/**
 * `[wpr_get_started]`: a call-to-action a site admin can drop into any ordinary WordPress
 * page/post to surface the reconnaissance service and link into the existing self-service
 * registration flow. Deliberately a link, not an embedded copy of the registration form itself -
 * see the approved plan for why (redirect-on-error assumes a fixed route; the honeypot/rate-limit/
 * nonce handling already built into {@see \Alltime\WPReconnaissance\Auth\AuthBootstrap::handle_register()}
 * isn't factored out for reuse; shortcode rendering happens well after the `template_redirect`
 * point that route's own form-handling depends on).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Shortcodes;

use Alltime\WPReconnaissance\Auth\CustomerPortalUrls;

final class GetStartedShortcode {

	public const TAG = 'wpr_get_started';

	public function boot(): void {
		add_shortcode( self::TAG, array( $this, 'render' ) );
	}

	/**
	 * @param array<string,mixed>|string $atts
	 */
	public function render( $atts ): string {
		$atts = shortcode_atts(
			array(
				'heading'     => __( 'Find out what attackers can already see', 'wp-reconnaissance' ),
				'description' => __( 'Get a free external assessment of your domain, DNS, mail authentication and web security configuration.', 'wp-reconnaissance' ),
				'button_text' => __( 'Get started', 'wp-reconnaissance' ),
			),
			(array) $atts,
			self::TAG
		);

		return sprintf(
			'<div class="wpr-get-started"><h2>%1$s</h2><p>%2$s</p><p><a class="button" href="%3$s">%4$s</a></p></div>',
			esc_html( (string) $atts['heading'] ),
			esc_html( (string) $atts['description'] ),
			esc_url( CustomerPortalUrls::url( 'register' ) ),
			esc_html( (string) $atts['button_text'] )
		);
	}
}
