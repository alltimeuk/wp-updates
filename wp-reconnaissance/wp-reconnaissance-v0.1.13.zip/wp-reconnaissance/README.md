### WP Reconnaissance ###
Contributors: @sjackson0109
Tags: security, domain, dns, reconnaissance, customer-portal
Requires at least: 6.6
Tested up to: 6.6
Requires PHP: 8.1
Stable tag: 0.1.13
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A self-service customer portal through which a prospective or existing customer can create an account, submit an
authorised domain, obtain a free Domain Reconnaissance assessment and receive a formal report with a prioritised
remediation plan.

## Description ##

WP Reconnaissance gives an organisation a defensible view of the externally observable controls associated with its
domains, email services, DNS, websites and public certificates. It is not a vulnerability scanner and does not claim
to prove compliance with any certification or regulatory standard.

The plugin separates scope and authorisation, evidence collection, evidence normalisation, rule evaluation, finding
and change management, customer-facing reporting, notifications, customer identity and account management, CRM lead
capture and consent management, and reusable tool registration and entitlement management.

Domain Reconnaissance is the first tool built on this platform. The underlying services (identity, profiles, consent,
communications, entitlements, tool execution, reporting, task management) are designed for reuse by later Alltime
self-service tools.

# Requirements #

* WordPress 6.6 or later
* PHP 8.1 or later (8.1, 8.2 and 8.3 are all tested in CI)
* Advanced Custom Fields 6.6.2 or later (required for branded content editing)
* PHP CLI with the curl, openssl, intl and json extensions on the collection worker host

# Explicit exclusions #

This plugin does not perform port scanning beyond explicitly implemented protocol connections, broad service
enumeration, web crawling, vulnerability exploitation, credential testing, password spraying, authenticated testing,
active takeover attempts, phishing simulation, domain/DNS modification or automatic remediation.

## Installation ##

1. Upload the plugin to `/wp-content/plugins/wp-reconnaissance/` or install through the WordPress plugin screen.
2. Activate the plugin.
3. Install and activate Advanced Custom Fields 6.6.2 or later.
4. Configure the collection worker under WP Reconnaissance → Settings before enabling the local process adapter.
5. Configure a mail provider (Gmail API, Amazon SES or Microsoft 365) before customer-facing
   features go live.

See `docs/installation.md` for the full guide.

## Changelog ##

# 0.1.13 #
* New Settings > Portal pages tab: map each customer-portal route (register, login, account,
  security and the rest) to a themed WordPress Page you've built with its matching shortcode -
  every link this plugin generates to that route now uses your themed page instead of the raw,
  unstyled route (signing out and the two file-download links always stay on their raw route).
* New Settings > Diagnostics tab: an opt-in "Verbose login/password-reset logging" toggle that
  records which check failed for each attempt - never a password or a reset token - to help
  diagnose a report that keeps recurring despite the underlying code checking out.

# 0.1.12 #
* Customer portal pages embedded via shortcode (registration, login, account, security and the
  rest) now tell WordPress and LiteSpeed Cache not to cache their response, the same way the raw
  /customer/* routes always have - previously only the raw routes sent a no-cache signal, so a
  shortcode-embedded page could be cached and served to the wrong visitor even though its content
  is specific to whoever is (or isn't) currently signed in.

# 0.1.11 #
* The reset-password success screen now tells a customer to wait a minute and try again if
  signing in with their new password doesn't work straight away, before requesting another reset.

# 0.1.10 #
* The Customers admin screen's "Linked data" section now shows the actual reason a failed email
  send failed, not just that it did.
* Clarified that the Microsoft 365 mail provider's "From address" must be a genuine mailbox
  (shared, user or room) - a distribution list will not work, even with "Send As" permission
  granted, since Microsoft Graph does not support sending as a mail-enabled group.

# 0.1.9 #
* New "Customers" admin screen: browse/search customer accounts, view everything linked to one for
  GDPR purposes, resend a verification email, send a password reset link, and enable/disable an
  account - none of this was previously possible from wp-admin.
* Fixed customer portal routes (registration, login, forgot/reset password, account and the rest
  of `/customer/*`) occasionally 404ing after a plugin update - the underlying rewrite rules now
  refresh themselves automatically instead of requiring a manual Settings > Permalinks re-save.

# 0.1.8 #
* Gmail API, Amazon SES and Microsoft 365 (Graph API) are now real, working mail providers -
  previously all three either didn't exist or always failed to send. Configure credentials and
  choose the active provider from Settings > Mail provider; the Microsoft 365 provider supports
  sending as a shared mailbox separately from the account it authenticates with.
* The Plugins list screen now has a "Settings" link on this plugin's own row.
* Plugin display name changed from "WP-Reconnaissance" to "WP Reconnaissance" throughout the admin
  UI, and its internal machine identifier changed from `wp-reconnaissance` to `wpr` in the REST
  API (now `/wp-json/wpr/v1/...`) and the admin menu's page slug (now `admin.php?page=wpr-*` -
  update any bookmarked admin URLs). The installed plugin folder and update mechanism are
  unaffected.

# 0.1.7 #
* The customer portal (registration, sign-in, account, security, privacy, tools, reports,
  remediation tasks) can now be embedded as themed shortcodes on ordinary WordPress pages, in
  addition to its existing unthemed /customer/* routes - both work permanently side by side.
* Added the account security screen: change password and sign out of every other session,
  previously not implemented.

# 0.1.6 #
* Added a Settings > Shortcodes reference tab, listing every shortcode this plugin registers
  with its attributes and worked usage examples. The Settings screen is now tab-based.

# 0.1.5 #
* Email verification alone no longer authorises a domain for scanning - it starts DNS
  ownership verification instead, closing a gap where an unverified domain could be scanned.
* The collection worker now validates every request destination (including redirects),
  refusing private/internal network addresses to close a server-side request forgery gap.
* Email-verification and password-reset links, and the transactional mail queue, can no
  longer be used or sent twice by two requests racing each other.

# 0.1.4 #
* A failed database schema upgrade is now visible: an admin notice, a WordPress Site Health entry,
  and a WP-CLI status command all report it, and it clears itself automatically once resolved.
* Fixed a rare case where a DNS domain-verification database write that failed partway through
  could be silently treated as if nothing needed to happen, instead of being reported as a failure.

# 0.1.3 #
* Fixed a fatal error on the admin Plans screen (and three other screens built the same way: the
  Finding review form, the privacy-request-type dropdown, and the customer portal's notification
  preferences) caused by passing a PHP enum directly to WordPress's selected()/checked() helpers.
* Fixed a "_load_textdomain_just_in_time" notice appearing on every request by deferring
  translation loading and role registration to the init action.

# 0.1.2 #
* Phase 2, continuous monitoring (Section 33): durable recurring schedules, baselines/expected
  state, a generalized change engine, a suppression/risk-acceptance review workflow,
  customer-configurable notifications, operator-facing failure monitoring, issued report version
  history/comparison, managed entitlement plans, and a read-only CRM/PSA integration API.
* Retired the WP Questionnaires contact migration in favour of WP Questionnaires' own canonical
  Customer Platform bridge (WPQ v1.15.0+).

# 0.1.1 #
* No functional change; confirms the self-hosted update pipeline end to end (release build,
  package smoke test, and publish to the shared alltimeuk/wp-updates update server).

# 0.1.0 #
* Initial Phase 1 scaffold: plugin bootstrap, database migrations for the core reconnaissance tables, domain
  entities, execution adapter contracts, job manifest and evidence schemas, and the PHP collection worker.
