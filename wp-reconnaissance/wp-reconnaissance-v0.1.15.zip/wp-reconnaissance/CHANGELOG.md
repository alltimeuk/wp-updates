# Changelog

All notable changes to WP Reconnaissance are documented in this file.

## 0.1.15 - 2026-09-08

### Fixed

- **Critical:** 0.1.14 introduced a fatal error on any site running both WP Reconnaissance and
  WP Questionnaires together, caused by adding a new required method to the shared cross-plugin
  contact-service contract - a hard breaking change for WP Questionnaires' own implementation of
  that contract. WordPress's fatal-error protection automatically rolled affected sites back to
  0.1.13 rather than leaving them broken, but the update was blocked until this release. The new
  method now lives on its own separate, optional interface instead, so the shared contract is
  back to its original shape and both plugins are compatible again. If your site was rolled back
  to 0.1.13, this update should now apply cleanly.

## 0.1.14 - 2026-09-08

### Added

- **Purge organisation**: a permanent delete action on Organisations > Edit ("Danger zone"),
  behind a confirmation prompt that shows the actual scope and customer-account counts about to
  be removed. Deletes the organisation and everything linked to it in one operation - scopes,
  jobs, findings, remediation tasks, reports, customer accounts, and their linked contact
  records in the shared Customer Platform - for when an organisation needs to be fully and
  permanently removed rather than archived. The linked contact record is hard-deleted too, not
  just unlinked; if the same contact is also used by another Alltime tool (e.g. WP Questionnaires),
  that tool loses its own reference to it as a result.
- A new Settings > Collectors tab: per-collector timeout overrides (default, RDAP, Certificate
  Transparency) for the monitoring profile - previously only settable at the database level.

### Changed

- RDAP and Certificate Transparency lookups now retry once, after a short delay, on a timeout or
  a literal HTTP 502 before giving up - crt.sh in particular has no formal SLA and occasionally
  returns one transiently, which previously surfaced as a full collection failure.
- The Customers screen's single-customer Audit log now renders as one table (Occurred at /
  Action / Object type / Outcome), instead of a separate small table repeated for every entry.
- **Breaking:** the DNS TXT domain-ownership verification record prefix changed from
  `v=wpreconnaissance` to `v=alltime-reconnaissance`. A domain with an already-published but
  still-pending verification record needs to regenerate and republish its TXT record (Account
  page > "Generate verification code"); already-authorised domains are unaffected.

## 0.1.13 - 2026-09-07

### Added

- A new Settings > Portal pages tab: map each customer-portal route (register, login, account,
  security and the rest) to a themed WordPress Page you've built with its matching
  `[wpr_customer_*]` shortcode. Every link this plugin generates to that route - the sign-in
  prompt on a gated page, the verification and password-reset emails, cross-links between screens
  - now uses your themed page instead of always pointing at the plugin's own raw, unstyled
  `/customer/<route>/` route. Signing out and the two file-download links (personal-data export,
  report PDF) always stay on their raw route regardless, since a themed page can't stream a file
  or safely react to a GET-triggered action.
- A new Settings > Diagnostics tab: an opt-in "Verbose login/password-reset logging" toggle that
  records which check failed for each attempt (an expired session, too many attempts, an incorrect
  password, an account that isn't allowed to sign in yet, an invalid or expired reset link) - never
  a password or a reset token - to help diagnose a report that keeps recurring despite the
  underlying code checking out. Off by default; switch it back off once you have what you need.

## 0.1.12 - 2026-09-05

### Fixed

- Customer portal pages embedded via `[wpr_customer_*]` shortcode (registration, login, account,
  security and the rest) now tell WordPress and LiteSpeed Cache not to cache their response, the
  same way the plugin's raw `/customer/*` routes always have. Previously, only the raw routes sent
  a no-cache signal - a shortcode-embedded page was, as far as any page-cache plugin is concerned,
  an ordinary WordPress Page, even though every one of these screens renders content specific to
  whichever customer is (or isn't) currently signed in. Found while investigating a real report of
  a fresh password reset appearing to still fail on a host running LiteSpeed Cache and Cloudflare.

## 0.1.11 - 2026-09-04

### Changed

- The reset-password success screen now tells a customer to wait a minute and try again if
  signing in with their new password doesn't work straight away, before requesting another reset -
  found while diagnosing a real report of exactly this on a staging environment with a persistent
  object cache in front of it: `wp_set_password()` genuinely updates the database, but a cached
  user lookup that hasn't yet been invalidated can still serve the old password hash to the very
  next login attempt for a short window.

## 0.1.10 - 2026-09-02

### Added

- The "Customers" admin screen's "Linked data" section now shows *why* a failed email send
  failed, not just that it did - the provider's own error message was already being recorded
  (`wpr_mail_events.detail`, written by `MailQueueService::handle_failure()`) but nothing
  previously read it back anywhere, so a "failed" state was a dead end for diagnosing the actual
  cause without direct database access.

### Changed

- Clarified the Microsoft 365 mail provider's "From address" field help text and code comments:
  it must be a genuine mailbox (shared, user or room), not a distribution list - confirmed against
  a real tenant that Microsoft Graph's `sendMail` rejects a distribution list as a Send-As target
  even with the delegate permission correctly granted on it, since a distribution list isn't a
  mailbox at all. Previously only said "a shared mailbox" as an example, which didn't rule out a
  distribution list looking like a reasonable choice.

## 0.1.9 - 2026-09-02

### Added

- A new "Customers" admin screen, under a `wpr_manage_customers` capability that already existed
  but was never actually wired to anything until now: browse/search customer accounts, view
  everything linked to one (via the same lookup the Privacy Requests screen already uses), resend
  a verification email, send a password reset link, and enable/disable an account - none of these
  were previously possible from wp-admin at all; a customer with a lost verification/reset email
  or a login issue had no self-service or operator-assisted recovery path. Disabling an account now
  also invalidates every one of its existing sessions, closing a gap where account suspension and
  session invalidation weren't actually linked. Deliberately does not add a raw "erase this
  customer's data" shortcut - erasure stays owned by the existing, properly reviewed Privacy
  Requests workflow; the new screen links directly into it instead, with the customer's email
  pre-filled.

### Fixed

- Every `/customer/*` route (registration, login, forgot/reset password, account, security,
  privacy, tools, reports, tasks) could 404 after a plugin update, even though the route handlers
  themselves were working correctly - `flush_rewrite_rules()` only ran on plugin *activation*,
  which WordPress does not re-run when an already-active plugin is updated, so the routes'
  underlying rewrite rules could silently go stale until an administrator happened to manually
  re-save Settings > Permalinks. Now self-healing: the plugin notices when `WPR_VERSION` has
  changed since the rules were last flushed and re-flushes automatically on the next request,
  once, rather than requiring manual intervention after every release.

## 0.1.8 - 2026-09-02

### Changed

- Plugin display name changed from "WP-Reconnaissance" to "WP Reconnaissance" (hyphen dropped)
  everywhere it appears in the WordPress admin, downloaded files and this project's own
  documentation: the Plugins list, admin menu, Site Health checks and debug info, the Privacy
  exporter/eraser tools, notification and error messages, and the self-hosted update server's
  "View details" popup and status page. The plugin's *internal* machine identifier is now `wpr`
  in the places that were previously the hyphenated slug and had no coupling to WordPress's own
  plugin-folder identity: the REST API namespace (`/wp-json/wpr/v1/...`, was
  `/wp-json/wp-reconnaissance/v1/...`), the admin menu's page slug (`admin.php?page=wpr-settings`,
  was `page=wp-reconnaissance-settings` - any bookmarked admin URL using the old slug will need
  updating), the Privacy/debug-info registration keys, downloaded file names
  (`wpr-report-*.pdf`/`wpr-personal-data.json`), and outbound HTTP User-Agent strings. Left
  deliberately unchanged: the installed plugin folder name, the self-hosted update package's
  publish path (`alltimeuk.github.io/wp-updates/wp-reconnaissance/`), the i18n text domain, and
  the `product_id`/purpose-context identifiers this plugin writes into the shared cross-product
  contact/consent platform - all four are tied to an existing installed/persisted identity that
  changing here would silently break or orphan, not a purely internal implementation detail.

### Removed

- The repo-root `PLAN.md` planning document, no longer maintained and unreferenced elsewhere in
  the repo.

### Fixed

- The Plugins list screen now has a "Settings" link on this plugin's own row, next to
  Activate/Deactivate - there was previously no way to reach Settings from there at all.

### Changed

- Internal groundwork for real mail-provider implementations, part 1 of a multi-part change: a
  new `HttpTransport` seam every provider will send through (mirroring `AuthBootstrap`'s
  `$terminator`/`DomainVerificationService`'s `$dns_query` injectable-callable pattern, so OAuth
  and signing logic can be unit-tested without a live network), and two real gaps closed in
  `GmailProvider`/`SesProvider`'s configuration validation - a missing OAuth client secret
  (Gmail) or missing access/secret key (SES) previously passed validation and would only have
  surfaced as a failure on the first real send.

### Added

- Part 2: the Gmail API mail provider actually sends mail now, replacing its "not yet
  implemented" stub. OAuth 2.0 refresh-token exchange (cached between sends), an RFC 5322
  message built from the queued mail and posted via the Gmail API's `messages.send` endpoint,
  and error mapping (missing/invalid configuration, 4xx vs. 429/5xx) that plugs into the mail
  queue's existing retry/backoff logic via `MailDeliveryException`'s `is_transient` flag.

- Part 3: the Amazon SES mail provider actually sends mail now, replacing its "not yet
  implemented" stub. Requests are signed by hand with AWS Signature Version 4 (no AWS SDK
  dependency) and posted to SES v2's `outbound-emails` REST endpoint; the signing implementation
  is cross-verified against an independent, from-scratch reference computation of the same
  algorithm for a fixed example, not just tested for "a signature was produced."

- Part 4: a new Microsoft 365 mail provider (Graph API), the third alongside Gmail and Amazon SES.
  Authenticates as an Entra ID app registration via the OAuth2 client-credentials grant (no
  interactive sign-in, no per-user refresh token) and sends through `POST /v1.0/users/{sender}/
  sendMail`. Separates the mailbox that *authenticates* the send (`sender`) from the address mail
  can appear to come *from* (`from`) - when `from` differs from `sender`, it's sent as an explicit
  `message.from` address while the URL path segment stays `sender` (the identity the app-only
  token is actually authorised against), which requires `sender` to hold Exchange Online "Send As"
  permission on the `from` mailbox.

- Part 5: the Settings screen's mail provider section now has fields for Microsoft 365
  (tenant ID, application ID, client secret, sending mailbox, and an optional From-address
  Send-As override), and only shows the active provider's own fields - Gmail's, Amazon SES's, and
  Microsoft 365's field groups now toggle with the "Active provider" dropdown instead of all three
  always being shown at once, which was already getting crowded with two providers and would only
  have gotten worse with a third.

## 0.1.7 - 2026-09-01

### Changed

- Internal refactor of the customer portal's route handlers (`AuthBootstrap`), part 1 of a
  multi-part change: every screen now builds its title/body as a returned `CustomerPageResult`
  instead of echoing a full HTML document itself, and the "must be a signed-in customer" gate is
  now reusable in a form that returns null instead of redirecting. No behaviour change for any
  existing `/customer/*` route - this only lays the groundwork for the same screens to also be
  embeddable as shortcodes on ordinary themed pages, landing in a follow-up change.

- Part 2 of the same change: a second, page-agnostic request handler that recognises a
  shortcode-rendered form's POST from anywhere on the site (not just the raw `/customer/*` route
  it mirrors), and a redirect-target helper so a successful action sends the visitor back to
  whichever page hosted the shortcode instead of always to the raw route's own URL. No new
  shortcode exists yet to exercise this path - still no behaviour change for any existing
  `/customer/*` route.

### Added

- Part 3, and the first user-facing piece: 10 new `[wpr_customer_*]` shortcodes
  (`wpr_customer_register`, `_verify_email`, `_login`, `_forgot_password`, `_reset_password`,
  `_account`, `_privacy`, `_tools`, `_reports`, `_tasks`), themed-page equivalents of the customer
  portal's raw `/customer/*` routes - both keep working permanently side by side. Documented on
  the Settings > Shortcodes tab alongside `[wpr_get_started]`. `[wpr_customer_login]` takes an
  optional `redirect` attribute for where a successful sign-in should land, since the referring
  page (the login page itself) is never the right default there. A signed-out visitor sees a
  "please sign in" prompt in place of a gated screen (account/privacy/tools/reports/tasks) rather
  than being redirected, since a shortcode can't safely redirect from inside a theme's own page
  render. File downloads (personal-data export, report PDF) still only work via their raw routes -
  a file download can't be embedded page content.

- Part 4: the customer portal's `security` screen, previously an unimplemented stub - both at
  `/customer/security/` and as `[wpr_customer_security]`. Lets a signed-in customer change their
  password (re-verifying the current one first) and sign out of every other session while keeping
  the current one. Changing the password re-issues the current session's auth cookie, since
  WordPress's own `wp_set_password()` would otherwise invalidate it and unexpectedly sign the
  customer out of their own successful action; "sign out elsewhere" uses `WP_Session_Tokens`'s
  `destroy_others()`, not the existing session-rotation helper used after a token-based password
  reset, which deliberately destroys the current session too (there's no current session to
  preserve in that logged-out flow).

## 0.1.6 - 2026-08-27

### Added

- A "Shortcodes" tab on Settings, listing every shortcode this plugin registers with its
  attributes and worked usage examples - the same reference-table pattern WP Questionnaires
  already uses on its own Settings > Shortcodes tab. This is also the plugin's first tab-based
  Settings screen: the existing Local adapter / Anti-abuse / Mail / Integrations sections moved
  into tabs alongside it, and the first admin-side JS/CSS this plugin ships (a small nav-tab
  toggle script, `assets/admin/`), enqueued only on wp-reconnaissance's own admin screens.

## 0.1.5 - 2026-08-24

### Fixed

- Email verification alone no longer authorises a scope for scanning. Verifying an email now
  only starts DNS TXT domain-ownership verification for the domain that was registered - the
  same mechanism every other authorisation path already goes through - and the free assessment
  is dispatched once that verification actually succeeds, or an operator manually authorises the
  scope from the admin Scopes screen (unchanged, for bulk/managed cases where DNS records aren't
  practical to add per-domain). A verification challenge older than 24 hours is no longer retried
  by the background sweep; the customer and admin screens say so, and a fresh code or an on-demand
  check both still work past that window.

- The collection worker's outbound HTTP(S) requests - including every hop of a redirect chain,
  where the destination is attacker-influenced - now validate the resolved address before
  connecting, refusing private, loopback, link-local and reserved ranges, including the
  169.254.169.254 cloud instance metadata address. Previously a redirect could point the
  collector at an address on the collection worker's own private network.

- Email-verification and password-reset links can no longer be used twice by two requests racing
  each other with the same link.

- The transactional mail queue can no longer send the same message twice when two processing
  runs overlap (for example a scheduled retry racing a manually-triggered send).

- Raw collection evidence and issued report PDFs are now stored outside the web server's document
  root whenever that can be positively verified, so no URL - on nginx or Apache - maps to them at
  all; nginx never reads `.htaccess`, so a plugin-managed `wp-content/uploads` subdirectory alone
  could never protect them there. The escape is refused whenever it can't be positively confirmed
  (including the "give WordPress its own directory" and Bedrock-style layouts, where it would be
  unsafe), falling back to the previous `wp-content/uploads` protection with an unchanged, honest
  Site Health check; `docs/installation.md` documents the explicit nginx deny rule to add if that
  check ever reports it as reachable. A report-download link valid for one report could also be
  substituted onto a different report's URL and would be served, because only its expiry was
  checked, not which report it was actually issued for - download links now carry and enforce that
  binding, and every rejected download request returns a real 403/404 instead of HTTP 200.

- Evidence collection and report generation now refuse to write to the `wp-content/uploads`
  fallback storage location unless a recent Site Health check has positively confirmed it's safe -
  genuinely fail-closed, not just fail-after-detection: a location that's never been checked, or
  whose last check has expired or was run under a configuration that has since changed (a domain
  migration, an Apache/nginx swap), is treated the same as a confirmed-exposed one and blocks the
  write, rather than being allowed by default until proven dangerous. A background check is
  scheduled automatically the moment a write is refused for lack of a recent verdict, so this
  doesn't leave a fresh install waiting on an admin to open Site Health manually, and an admin
  notice explains what's blocked and why while it persists. An assessment now also fails cleanly
  (recorded on the job, not left stuck at "running" forever) if evidence genuinely cannot be
  written to storage for any reason; a report PDF that fails to store for any reason is now
  recorded in the audit log instead of failing silently with no trace.

## 0.1.4 - 2026-08-20

### Added

- Operational visibility when a database schema upgrade fails (`Migrator::maybe_upgrade()`
  already stopped without advancing the stored version on a failing step; it now says so too): a
  `wpr_migration_failure` option records the failed target/current version, a safe classification
  derived from the database error (never the raw error text itself), and how many times it's been
  retried; WordPress Site Health's existing "Database schema" check now shows that detail instead
  of a generic message; a capability-gated admin notice appears while it persists; and
  `wp reconnaissance status` reports it from the command line. Clears itself - with a single
  recorded recovery event, not a lingering flag - the moment a later boot's automatic retry
  succeeds. Domain verification (`generate_challenge()`/`check()`) now refuses to attempt a write
  against columns a stuck-at-an-earlier-version install doesn't have yet, with a clear message
  instead of a raw database error - scoped to the specific schema version those columns actually
  need, so an unrelated future migration failure never blocks it for no reason connected to it.

- `docs/installation.md`: README.md's `## Installation ##` section referenced this file for "the
  full guide" but it never existed. Covers the two things that need more than one line - setting
  up the local collection worker (the `proc_open()`-based adapter under Reconnaissance → Settings)
  and configuring a transactional mail provider (Gmail API or Amazon SES), both required before
  the plugin can actually run assessments or notify customers.

- `[wpr_get_started]` shortcode: drop it into any ordinary WordPress page or post to surface a
  "Get started" call-to-action linking into the existing self-service registration flow
  (`/customer/register/`) - previously only reachable via that dedicated route, with no way to
  embed it into arbitrary site content. Deliberately a link, not an inline copy of the
  registration form itself: embedding the form would need redirect-on-error to return to an
  arbitrary originating page (the whole rewrite-route system assumes fixed routes) and a second,
  parallel POST-handling path (shortcode rendering happens well after the `template_redirect`
  point the real form's honeypot/rate-limit/nonce handling depends on) - a plain link satisfies
  the actual need with none of that. Accepts optional `heading`/`description`/`button_text`
  attributes; ships with sensible defaults. Adds `esc_url()`/`home_url()`/`shortcode_atts()` to
  the unit-test WordPress polyfills (`tests/bootstrap.php`) - none were needed by anything under
  test before this.

- A genuine WordPress PHPUnit integration test harness (`tests/Integration`), previously just a
  README describing an environment that was never wired up. `bin/install-wp-tests.sh` downloads a
  version-pinned, checksum-verified WordPress core plus a pinned, integrity-checked copy of the
  official SQLite Database Integration drop-in, so neither a MySQL server nor svn/wp-cli are
  required, locally or in CI; `composer test:integration` runs it. CI exercises PHP 8.1/8.2/8.3
  against current WordPress plus PHP 8.2 against the plugin's declared floor
  (`README.md`'s "Requires at least: 6.6") - see `tests/Integration/README.md` for why PHP 8.1
  doesn't run the integration suite in CI (a Windows-build SQLite version limitation, not a defect
  in this plugin, WordPress core or the SQLite plugin; PHP 8.1 remains fully covered by the unit
  suite). New coverage, by kind:
    - **Real WordPress REST dispatch** (`rest_get_server()->dispatch()`, not calling controller
      methods directly) on the scopes resource: unauthenticated/cross-organisation
      read/list/write rejection - including an actually-attempted, actually-rejected create for a
      prohibited case, not just a capability check - an operator's write succeeding, an
      unsupported HTTP method rejected at the server level, and REST argument validation.
    - **Real WordPress plugin lifecycle** via `activate_plugin()`/`deactivate_plugin()`/
      `get_plugins()`, not only `Support\Plugin::activate()`/`deactivate()` called directly:
      WordPress recognising the entry file, the registered activation callback creating schema
      and options, deactivation never dropping data, and idempotent reactivation.
    - **Real customer-facing handler dispatch**, not just the service it calls: an injectable
      `$terminator` on `AuthBootstrap` (mirroring `DomainVerificationService`'s DNS seam) lets
      tests drive `dispatch()` itself through nonce enforcement, cross-organisation ownership
      checks, malformed input, per-account rate limiting and plan-limit opacity, without tearing
      down the test process on the real `exit` every redirect ends with in production.
    - A genuine pre-v12 `wpr_scopes` table shape (not a v12 table with only the version *option*
      rolled back) upgrading to v12 preserving existing data; and a migration step whose own SQL
      fails not advancing the stored schema version, leaving it to retry cleanly.
    - The DNS TXT domain-verification service end-to-end: correct/incorrect/partial-match TXT
      records, reconstructing a value legitimately fragmented across multiple `entries` within one
      record (never concatenating separate records), the scheduled sweep, and an atomic
      single-write verify-and-authorise transition (`ScopeRepository::verify_and_authorise()`) -
      idempotent against a stale in-memory `Scope` object, and safe under two competing checks -
      replacing the previous two-separate-writes sequence that could leave a scope verified but
      never authorised if the second write failed.
    - Role/capability wiring and cron scheduling idempotency.

- Customer portal UI for DNS TXT domain-ownership verification (part 5, and the last UI piece, of
  the feature): each not-yet-authorised domain on a customer's `/customer/account/` dashboard now
  gets its own "Generate verification code"/"Check now" section, mirroring the admin Scopes
  screen. The one genuinely new security-relevant check in this feature:
  `customers_own_scope()` confirms a scope both exists and belongs to the logged-in customer's own
  organisation before either action can touch it, silently rejecting anything else with no
  distinguishing error - the same "no information leak" posture `handle_register()` already uses.
  The "Check now" path is additionally rate-limited (10/hour per account) against DNS-lookup
  abuse, matching the bucket/window shape already used for `privacy_request`/`register`/`login`;
  the admin side has no equivalent limit, since it's already capability-gated. A plan-limit
  rejection is caught silently (challenge stays pending for a later retry) rather than surfacing
  plan/billing detail to a customer.

- Admin UI for DNS TXT domain-ownership verification (part 4 of the feature): a "Verify domain"
  action alongside the existing "Authorise" one on the admin Scopes screen, gated the same way -
  visible only while a scope isn't yet authorised. Shows the exact TXT record to publish (once a
  verification code has been generated) and a "Check now" button for an immediate DNS check,
  independent of the 30-minute sweep. Reuses `PlanLimitException` handling identically to the
  existing manual "Authorise" action, so a DNS-verified authorisation is blocked the same way a
  manual one already is when it would exceed an organisation's plan. Customer-portal UI follows
  in the next PR.

- `Verification\VerificationBootstrap` (part 3 of the DNS TXT domain-ownership verification
  feature): a new recurring 30-minute sweep (`wpr_run_domain_verification_sweep`), separate from
  the existing daily maintenance sweep since it needs its own cron interval - WordPress core only
  ships hourly/twicedaily/daily by default, so this registers a `wpr_thirty_minutes` interval via
  the `cron_schedules` filter. Deliberately pure WP-Cron with no Action Scheduler dual-path,
  matching the one other existing recurring sweep's (`SchedulingBootstrap::ensure_daily_maintenance_scheduled()`)
  precedent - Action Scheduler's dual-path elsewhere in this codebase is only for one-off
  dispatches, not recurring events. Calls `DomainVerificationService::run_sweep()` on every tick.
  No admin/customer UI yet - that follows in subsequent PRs.

- `Verification\DomainVerificationService` (part 2 of the DNS TXT domain-ownership verification
  feature): `generate_challenge()` produces a random per-challenge secret and stores only its
  SHA-256 hash - the hash itself is the value published in DNS, not a credential, so there is no
  raw secret to protect after generation. `check()` looks up the domain's TXT records (via the
  existing `Worker\Support\Dns` helper, never a subdomain) for a `v#wpreconnaissance h#... t#...`
  record matching the stored hash and, on a match, authorises the scope through the existing
  `ScopeRepository::authorise()` path - the same plan-limit check
  (`PlanEnforcementService::assert_can_authorise_scope()`) the manual admin authorise flow already
  applies runs here too, so DNS verification can't silently authorise a scope past an
  organisation's plan. `run_sweep()` is the entry point for a later scheduled check across every
  outstanding challenge. No admin/customer UI or scheduling wiring yet - those follow in
  subsequent PRs. No email is sent anywhere in this service (deliberate).

- Schema v12 and repository groundwork for DNS TXT domain-ownership verification (part 1 of a
  multi-PR feature): `wpr_scopes` gains `domain_verification_status`,
  `domain_verification_secret_hash`, `domain_verification_requested_at`,
  `domain_verification_requested_by` and `domain_verified_at`, mirrored on the `Scope` domain
  object. `ScopeRepository::authorise()`'s `$authorised_by` is now `?int` (was `int`) so a
  system/cron-triggered authorisation - e.g. automatic authorisation on a successful DNS
  verification, landing in a later PR - can be recorded with no acting WP user, matching the
  `?int $actor_id # null` convention every other cron-facing method in this codebase already
  uses. New `ScopeRepository::find_pending_domain_verification()`,
  `start_domain_verification()` and `mark_domain_verified()`. No UI or verification logic yet -
  those follow in subsequent PRs.

### Fixed

- `ScopeRepository::verify_and_authorise()` (the single atomic write that transitions a scope from
  a pending DNS challenge to verified and authorised) treated an expected no-op - the row was no
  longer pending by the time the write ran, because someone else already completed it - identically
  to a genuine database failure: both just returned `false`. A real failure now throws instead, so
  it's never mistaken for "already handled" - `DomainVerificationService::check()` no longer risks
  reporting success (or silently doing nothing) when the underlying write actually broke, and the
  scheduled sweep now records a distinct failure event for it rather than treating it as routine.

- `bin/install-wp-tests.sh`'s cached WordPress core directory was keyed on the literal requested
  version string, so `.wp-core-latest` never changed even as WordPress shipped new releases - a
  persistent self-hosted CI workspace could silently keep testing against whichever release
  happened to be "latest" the first time the script ever ran there. Now keyed on the resolved
  WordPress version and the pinned SQLite Database Integration plugin version together, so either
  one changing gets its own cache entry automatically.

### Changed

- Company website references (`composer.json`, the generated plugin-update manifest, the
  collection worker's outbound User-Agent string, and the customer-facing privacy notice's contact
  email) now consistently use `alltimetech.co.uk`, matching the plugin header's `Author URI`
  corrected below.

- Plugin header `Author`/`Author URI` (shown on the wp-admin Installed Plugins screen) now read
  "Simon Jackson @ Alltime Technologies Ltd" and `https://alltimetech.co.uk`, correcting the
  organisation's actual domain.

- Widened the supported PHP range from `>#8.2` to `>#8.1` (plugin header, `composer.json`,
  `README.md`), and CI's PHPUnit/PHPCS/PHPStan matrix now covers PHP 8.1, 8.2 and 8.3, not just
  8.2/8.3 - for portability if this plugin is ever moved to a different hosting environment.
  `phpcs.xml.dist`'s `PHPCompatibilityWP` check was only ever configured with `testVersion 8.2-`
  (validating the declared floor, never anything below it); it's now `8.1-8.3`, actually
  enforcing the full supported range on every PR rather than trusting the declared minimum was
  accurate.

## 0.1.3 - 2026-08-17

### Fixed

- Every admin/customer-portal `<select>`/radio built from a backed enum's `::cases()` crashed with
  `Uncaught Error: Object of class ... could not be converted to string` the instant it rendered:
  the admin Plans screen (`AdminBootstrap::plan_form_fields()`), the Finding review status dropdown
  (`AdminBootstrap::render_finding_review()` - a core, frequently-visited admin workflow), the
  privacy-request-type dropdown (`AdminBootstrap::privacy_right_type_options()`), and the customer
  portal's notification-delivery radios (`AuthBootstrap`'s privacy centre) all passed a raw enum
  instance into WordPress's `selected()`/`checked()` instead of its scalar `->value` - those
  functions string-cast their arguments internally, and PHP backed enums are not implicitly
  stringable. Found via a live production report (WordPress's own "critical error" recovery page,
  with the real error in `debug.log`) after the Plans screen fatal on first real-world use; audited
  every other `selected()`/`checked()` call site in the codebase for the same pattern - these four
  were the only ones passing a raw enum, everything else already compared strings/ints/booleans.
- `_load_textdomain_just_in_time` notice on every request (wp-admin, WP-CLI, cron): `Plugin::boot()`
  ran at `plugins_loaded` and called `Roles::register()` directly, whose three `add_role()` calls
  translate the role display names - WordPress 6.7+ warns on any translation call before `init`.
  Textdomain loading and role (re-)registration now both run on `init` at priority 0 instead; roles
  persist in the database after their first registration, so nothing running between
  `plugins_loaded` and `init` loses sight of them, and the every-boot re-registration that picks up
  new capabilities on plugin updates still happens on every request. `Roles::boot()` (pure hook
  wiring, no translations) stays at `plugins_loaded`.

## 0.1.2 - 2026-08-16

### Changed

- Retired the WP Questionnaires contact migration in favour of WPQ's own canonical store. WP
  Questionnaires v1.15.0 shipped `WPQ_Customer_Platform_Bridge`, which registers its `wpq_contacts`
  store on this plugin's `alltime_customer_platform_contact_service` discovery filter at a higher
  priority than this plugin's own registration - making WPQ canonical on any dual-install site.
  Continuing to write WPQ submissions/enquiries into this plugin's own `atcp_contacts` tables would
  have produced a second, conflicting contact record, so `WpqMigrationService`,
  `wp reconnaissance wpq-migrate` and `MigrationReport` have been deleted, and
  `WpqCompatibilityAdapter`/`WpqCapabilityProbe` trimmed down to the one read still needed:
  `PersonalDataLocator`'s GDPR export still pulls WPQ's raw submission/enquiry/preference data via
  `export_contact_data()`, since the shared contact contract has no read method rich enough to
  replace it. This plugin's own visitor-context/cookie code has no WPQ equivalent and is
  unaffected. Also fixed the `alltime_contact_merged` hook's third argument (`ContactMergeService`)
  to match WPQ's documented `array{actor: int}` shape instead of a plain admin-user-id int, since
  WPQ's bridge is the first real external listener this hook has ever had to interoperate with.

### Added

- CRM/PSA integration API (Section 33, Phase 2 item 9, e.g. HaloPSA polling for contacts, domains
  and reports): no outbound integration mechanism or service-account REST auth existed before
  this. Every REST permission callback was already a plain `current_user_can()` check, so a
  WordPress Application Password against a suitably-privileged account would have worked
  transparently - it just had nothing to authenticate as. A new read-only
  `Roles::INTEGRATION_ROLE` (`wpr_integration`, holding only `VIEW_ALL_RESULTS` - none of the
  write capabilities the full operator role carries) is the account an external system
  authenticates as. `Roles::register()` now runs on every boot, not only activation, so this new
  role (and any capability a past release added) actually reaches an already-active install.
  Domains/config and reports were already exposable via the existing `/organisations/{id}/scopes`
  and `/scopes/{id}/reports` routes; the one genuinely missing piece was contacts, added via a new
  `GET /organisations/{id}/contacts` route (`Api\ContactsController`, backed by the existing
  `CustomerAccountRepository::find_by_organisation()`). A new admin Settings section documents the
  whole flow (create a WordPress user with the integration role, generate an Application Password
  from their profile, point the external system at the REST base URL), and a new Site Health check
  confirms Application Passwords are actually available on the site.

- Managed entitlement plans (Section 33, Phase 2 item 8): entitlements were strictly one-shot,
  gated only by a flat system-wide rerun-interval option with no plan/tier concept. Schema v11
  adds `wpr_plans` (name, `max_active_scopes`, `rerun_interval_days`, `min_schedule_frequency`,
  and a reserved-but-unused `external_billing_reference` for a future payment integration to
  write into) and a `plan_id` column on `wpr_organisations`. An operator creates plans and assigns
  them to organisations from a new admin "Plans" screen; an organisation with no plan stays fully
  unrestricted, exactly as before this shipped. Enforcement: `EntitlementService::check()` uses
  the organisation's plan's `rerun_interval_days` when set, falling back to the existing global
  option; `PlanEnforcementService::assert_can_authorise_scope()` blocks authorising a scope past
  `max_active_scopes` (checked at authorisation, not creation, since nothing runs against an
  unauthorised scope); a new `Scheduling\ScheduleFrequencyClamp` (pure, unit-tested) slows a
  scope's durable-schedule cadence down to the plan's `min_schedule_frequency` floor when it would
  otherwise run faster. No payment gateway integration - that remains a deliberately separate,
  later decision.
- Issued report version history and comparison (Section 33, Phase 2 item 7): reports were always
  versioned at the schema level (`wpr_reports`'s unique `scope_id`+`version` key,
  `ReportRepository::find_by_scope()`), but nothing ever exposed more than the single latest
  version per scope - not the admin Reports screen, not the customer portal, not the REST API. A
  new `GET /scopes/{scope_id}/reports` route exposes the full history; both the admin report view
  and the customer portal's report view now show a version-history table and, where an
  immediately-earlier version exists, a "what changed since version N" summary. The comparison
  itself is a new `Reports\ReportComparator`, reusing `Findings\AssetDiffer` - the same pure
  set-comparison the generalized change engine (item 3) introduced - applied to each report
  document's `findings[].finding_id` instead of an asset identifier.
- Operator-facing failure monitoring (Section 33, Phase 2 item 6): the "repeated collection
  failure" trigger already existed, but only reactively, as a customer-facing email sent at the
  moment one job completed. `JobRepository::find_scopes_with_repeated_failures()` computes the
  same signal (a scope's most recent 3 jobs all failed) proactively across the whole fleet, and
  `count_by_status_since()` adds a "Jobs failed today" count. Surfaced in three places an operator
  actually looks: a new tile on the admin Overview screen, a warning box at the top of the admin
  Jobs screen listing every affected scope, and a new Site Health check
  (`wpr_repeated_failures`) so it shows up alongside the plugin's existing infrastructure-health
  checks (mail queue, cron, worker readiness) rather than only in a dedicated view.
- Customer-configurable notifications (Section 33, Phase 2 item 5): schema v10 adds
  `reminder_days_before` to `wpr_remediation_tasks` and a new `wpr_notification_digest_entries`
  table. A customer's requested task reminder previously always fired at the same system-wide
  7-day lookahead (`RemediationTaskRepository::REMINDER_LOOKAHEAD_DAYS`); the customer portal task
  form now lets them pick 1/3/7/14/30 days instead, falling back to the same 7-day default when
  unset. A new per-account delivery preference (`Auth\Enums\NotificationFrequency`, set from the
  customer portal's privacy centre) lets a customer choose a single combined daily digest email
  over one email per triggering event; `NotificationDispatcher::notify_organisation()` routes to
  a pending-digest entry instead of the immediate mail queue when chosen, and a new
  `NotificationDigestService` (run from the existing daily maintenance sweep) folds each account's
  pending entries into one email and marks them sent. Both paths share the same idempotency key,
  so a hook firing twice can never duplicate a notification regardless of delivery mode.
- Suppression/risk-acceptance review workflow (Section 33, Phase 2 item 4): `risk_accepted_by`
  and `risk_accept_review_date` existed only as unused `wpr_findings` columns - now wired into
  `Domain\Finding`, `FindingRepository` (hydrate/save/`update_review()`), and the assessment
  pipeline's re-evaluation path (carried forward across re-observations, cleared if a finding
  re-appears as genuinely new). Both admin ("Review" form) and REST (`PATCH /findings/{id}`)
  review paths now capture the reviewer (the acting user, not a client-supplied value) and an
  optional review date whenever a finding is marked "Accepted risk"; any other status clears
  both, so a stale reviewer/date never survives past the decision it was recorded for. A new
  `FindingRepository::find_due_risk_acceptance_reviews()` (30-day lookahead) surfaces accepted
  risks coming up for reconfirmation as a warning box on the admin Findings screen.
- Generalized change engine (Section 33, Phase 2 item 3): the one-off certificate/subdomain
  diffing in `NotificationDispatcher::check_new_assets()` is replaced by a reusable
  `Findings\AssetDiffer` (pure set comparison) and `Findings\AssetChangeDetector` (a small
  registry mapping asset kind to collector and extractor, versus duplicating diff logic per
  kind). Broadened from 2 to 4 asset kinds in the process - IP addresses (`dns` collector's A/AAAA
  records) and DKIM selectors (`mail` collector, skipping any selector the collector could not
  observe) now also trigger the "new assets detected" notification alongside certificates and
  subdomains. Adding a further kind is now a registry entry plus one extractor method, not a
  parallel `array_diff()` call site. Deferred: surfacing this as a browsable change timeline in
  the customer portal, rather than only a notification side-effect.
- Baselines and expected state (Section 33, Phase 2 item 2): `Scope::$expected_state` was
  schema-only and never read by the rule engine. `RuleEngine::evaluate()` and
  `RuleHandlerInterface::evaluate()` now take the scope alongside the evidence document, so a
  handler can compare observed evidence against a customer/operator-declared baseline instead of
  (or in addition to) a rule-intrinsic literal. A new `Rules\Handlers\BaselineRuleHandlers` adds
  three rules - `BASELINE.RDAP.NAMESERVERS_CHANGED`, `BASELINE.MAIL.MX_CHANGED`,
  `BASELINE.TLS.ISSUER_CHANGED` - each silent until a baseline for that collector key actually
  exists, then firing on drift (a classic domain-hijack/mail-rerouting/rogue-certificate
  indicator). `Rules\BaselineCaptureService` is the practical way to establish one: "adopt the
  current observed state as the baseline", available from the admin Scopes screen and
  `wp reconnaissance scope capture-baseline --scope-id#<id>`; a collector that failed on the
  latest run leaves its existing baseline untouched rather than clearing it.
- Durable recurring assessment schedules (Section 33, Phase 2 item 1): schema v9 adds
  `monitoring_schedule`, `next_assessment_due_at` and `last_scheduled_at` to `wpr_scopes`. A new
  `Domain\Enums\ScheduleFrequency` (daily/weekly/monthly/manual) and pure `NextOccurrenceCalculator`
  compute the next due date, correctly clamping month-end overflow (e.g. Jan 31 -> Feb 28/29)
  instead of letting `+1 month` roll into March. `SchedulingBootstrap::run_due_assessments()` -
  previously an empty stub - now seeds any never-scheduled scope's due date (without dispatching,
  so turning this on never causes a mass run) and then dispatches every scope whose due date has
  arrived, each isolated in its own try/catch and audit-logged on failure so one bad scope never
  blocks the batch. Runs as part of the existing daily maintenance sweep, capped by
  `wpr_max_scheduled_assessments_per_sweep` (default 50). A scope's own `monitoring_schedule`
  overrides its monitoring profile's inherited cadence. New `wp reconnaissance schedule run
  [--dry-run]` CLI command for on-demand/preview invocation.

- Self-service free-assessment journey (Section 5.3/5.5): registration now collects the domain to
  assess and the customer's confirmation of authority over it, creating (but not yet authorising)
  the scope immediately. Once the account's email is verified, `Auth\FreeAssessmentService`
  authorises the scope and - if the free-use entitlement allows it - reserves it and queues the
  assessment automatically, so a customer sees progress in their account without waiting on an
  operator. Dispatch is deliberately gated on email verification, not registration itself, so
  nobody can queue a scan of an arbitrary domain by typing someone else's address into the form.
  `Entitlements\EntitlementFulfillment` listens for `wpr_job_completed` and consumes the
  reservation on a usable result or releases it on failure, exactly as Section 5.5 requires.
- Anti-abuse controls (Section 5.6): schema v7 adds `wpr_abuse_signals` (review queue) and
  `wpr_blocklist`. A new `AntiAbuse\` module layers a configurable bot-challenge adapter (a
  bundled zero-dependency honeypot + minimum form-fill-time check, swappable for a real CAPTCHA
  provider later), disposable-email detection, duplicate-domain and maximum-queued-jobs review
  signals, and block/allow lists over the existing per-IP `Auth\RateLimiter`. `RegistrationService`
  evaluates all of this before the duplicate-email check - hard blocks (blocklist match or failed
  challenge) throw a generic `RegistrationException`; review signals are queued rather than
  rejected. `FreeAssessmentService` holds a free assessment while an open review signal exists and
  dispatches it when an operator releases it. Audit events record both automated and manual
  eligibility decisions. Admin: an "Abuse review" screen (release/dismiss/block signals, add/remove
  blocklist entries) and anti-abuse settings (captcha enabled, minimum form seconds, maximum queued
  jobs), gated by the new `wpr_manage_abuse_review` capability.
- Downloadable PDF reports (Section 21.2): added `dompdf/dompdf ^3.1.6` and a new `Reports\`
  module. `PdfReportRenderer` reuses `HtmlReportRenderer` for the source markup and converts it to
  PDF via dompdf (remote/php/javascript disabled). `ReportFileStorage` keeps the files in a
  protected `wpr-reports/` uploads subdirectory (`.htaccess` + `index.php`, mirroring
  `EvidenceStorage`), with a deterministic filename derived from the report UUID so no schema
  change is needed. Generation is asynchronous - `SchedulingBootstrap` queues
  `wpr_generate_report_pdf` on `wpr_report_issued` (Action Scheduler when available, WP-Cron
  fallback) - so a slow render never blocks the request that issued the report. Downloads are
  served through protected, capability/ownership-checked endpoints in both the admin Reports
  screen and the customer portal, gated by a short-lived HMAC-signed token
  (`ReportDownloadToken`, 15-minute expiry); a not-yet-generated PDF surfaces a "not ready yet"
  state rather than a broken link.
- Admin organisation editing: an "Edit" action on the Organisations screen updates name, timezone
  and status - previously only possible via the REST API.
- Customer-editable remediation task notes (Section 21.3 names "Customer notes" as a field
  distinct from operator-only "Alltime notes"): the `/customer/tasks/` route now lets a customer
  add or update their own note on each of their organisation's tasks, without touching status,
  target date or operator notes.
- Persistent transactional mail queue (Section 22.5): `wpr_mail_queue`/`wpr_mail_events` record
  every message's recipient, template, purpose, provider, provider ID, state and timestamps, with
  idempotency-key deduplication and bounded exponential backoff for transient provider failures.
  Registration/password-reset email (previously logged to `error_log()` as a development aid)
  now goes through the same queue as every other notification.
- Notification triggers (Section 22.5): new high/critical finding, an existing finding worsening,
  a report becoming ready (with a distinct "free report ready" template for a scope's first
  issued report), repeated collection failure, and authorisation approaching expiry. Wired from
  the plain `wpr_job_completed`/`wpr_finding_created`/`wpr_finding_changed`/`wpr_report_issued`
  action hooks Section 22.5 itself specifies, so any other integration can subscribe
  independently - `NotificationDispatcher` is their first subscriber, not a special case. Every
  enqueue carries a stable, event-derived idempotency key rather than a random one.
- `ChangeDetector` now distinguishes a finding actively worsening from a lateral `Modified`
  change (Section 8.7), using confidence-rank movement as a generic proxy since severity is fixed
  per rule and can never itself signal worsening for a single finding instance.
- Retention and deletion sweep (Section 26.7): unverified registrations, raw evidence (file plus
  its `wpr_evidence` row), the audit log, the mail queue, and (via
  `Alltime\CustomerPlatform\RetentionSweeper`) cross-tool interaction history, each on its own
  configurable `wpr_retention_*_days` window. Runs daily via WP-Cron/Action Scheduler and on
  demand through `wp reconnaissance retention run`, which replaces the "not yet implemented"
  stub. `wp reconnaissance report generate <scope-id>` likewise now issues a real report instead
  of erroring.
- REST API resources for organisations, scopes, jobs and findings (`wp-reconnaissance/v1`):
  list/get/create/update, scope authorisation, and asynchronous job dispatch. Every route is
  scoped by `Support\ActorScope` so an operator sees everything while a customer sees only the
  single organisation their account is linked to.
- Real admin screens (Overview, Organisations, Scopes, Jobs, Findings, Settings) replacing the
  Phase 1 placeholders: create/authorise scopes, dispatch assessments, review and annotate
  findings, and configure the local execution adapter, all backed by real data.
- Asynchronous job dispatch (`Scheduling\SchedulingBootstrap::schedule_assessment()`), using
  Action Scheduler when available and falling back to a one-off WP-Cron event - the admin "Run
  now" action and the REST job-dispatch endpoint both queue a run rather than executing
  `AssessmentService` inline from an HTTP request (Section 15).
- Repository additions needed by the above: paginated `list()`/`count()` across organisations,
  scopes, jobs and findings, plus `FindingRepository::update_review()` for operator review
  actions (status, notes, ownership, suppression) without touching the change-detection fields
  the assessment pipeline owns.
- Remediation task generation (Section 21.3): every actionable finding maps to one task, kept
  updated (not duplicated) across re-scans, with a transparent, fully unit-tested priority
  algorithm (`Reports\PriorityCalculator`) that scores severity, confidence, time-bound urgency,
  enabling-control status and persistence rather than sorting on severity alone. A finding that
  resolves, is accepted as risk, suppressed or marked a false positive transitions its linked
  task to the matching terminal status automatically.
- Report generation and issuing (Section 19.6/21): `Reports\DomainReconnaissanceReportBuilder`
  builds a `schemas/report.schema.json`-conformant document from a scope's latest observation,
  findings and remediation plan; the admin Reports screen supports the full draft → review → add
  executive summary → issue immutable version workflow. Issued reports render as HTML (admin and
  customer portal) and Markdown, and are exposed as JSON via REST.
- Customer portal now shows real data instead of placeholders: the dashboard lists the
  organisation's domains with a link to each one's latest report and an open-task-by-priority
  summary, plus dedicated `/customer/reports/` and `/customer/tasks/` routes (read-only for now -
  updating a task's status still goes through an operator).
- REST resources for reports (list/create/get) and remediation tasks (list/get/update), scoped by
  `Support\ActorScope` like every other resource.
- Shared Alltime Customer Platform (Section 6.1.2/6.1.3), delivered as its own
  `Alltime\CustomerPlatform` namespace and PSR-4 root so it can be extracted into an independent
  plugin later without changing contact IDs. `ContactServiceInterface` (canonical contact,
  identity, interaction and consent records against new `atcp_*` tables) is discovered only
  through `ContactPlatformDiscovery`'s versioned WordPress-filter contract, never constructed
  directly - `RegistrationService` is its first real consumer, creating/linking a contact and
  recording a `registration_completed` interaction and a marketing-consent decision on every
  registration, exactly as an external plugin eventually would.
- Tool registry (Section 5.4): `Tools\ToolRegistry`, populated entirely through the
  `wpr_register_tools` action - `domain-reconnaissance` is registered through that same public
  API, not hard-coded into the registry itself. The customer portal's `/customer/tools/` route
  now renders the catalogue instead of a placeholder.
- Entitlement service (Section 5.5): one free completed report per contact and registrable
  domain by default, a configurable re-run interval, administrator grants/revocations, and
  operator/admin accounts exempted from public limits. Decision logic
  (`Entitlements\EntitlementPolicy`) is pure and fully unit-tested, separate from the
  database-backed repository.
- Data-subject rights requests (Section 26.3/26.4): `wpr_privacy_requests` records every right
  (access, rectification, erasure, restriction, portability, objection, marketing withdrawal)
  through one workflow - `PrivacyRequestService` submits, verifies identity, classifies, places a
  processing restriction, locates linked data, and completes/partially completes/refuses a
  request with an outcome notice, all captured in `wpr_audit_log`. Withdrawing marketing consent
  is auto-fulfilled immediately rather than queued for review, per Section 26.6. A new
  `/customer/privacy/` portal route lets a customer view a summary of their linked data, download
  it as JSON, manage their marketing preference, submit and track requests, and cancel one they
  submitted; a new admin "Privacy requests" screen lets an operator with
  `wpr_manage_privacy_requests` record requests received by another channel, action every
  workflow step, and see approaching/overdue statutory deadlines. `PersonalDataLocator` backs both
  the portal and the admin screen and is now what WordPress core's own personal-data export tool
  calls too - `Privacy\PersonalDataExporter`/`PersonalDataEraser` are real implementations,
  replacing the Phase 1 stubs.
- Site Health diagnostics (Section 29): ten checks covering supported PHP version, database schema
  status, mail queue health, scheduled-task health, the local execution adapter's readiness and
  worker version compatibility, the worker working directory and evidence storage protection, the
  (not-yet-available) remote worker adapter, and retention-sweep freshness, plus a
  "wp-reconnaissance" Info-tab section with every filesystem path marked private so WordPress
  core's own diagnostics export redacts them automatically.
- Customer task status updates (Section 34 item 21): the customer task form now renders a status
  `<select>` over all eight `RemediationTaskStatus` cases and `handle_update_task_notes()`
  validates the submitted value via `RemediationTaskStatus::tryFrom()` before calling
  `update_status()`. Target date and operator notes remain operator-only.
- Mail provider admin screen (Section 22.1-22.3): the Settings screen now has a "Mail provider"
  section to pick Gmail API / Amazon SES / None, enter credentials, save (validating the active
  provider's configuration) and send a test message to the current admin's address. Secret fields
  (Gmail refresh token, SES secret access key) are never echoed back after save. The new
  `wpr_mail_provider`/`wpr_gmail_*`/`wpr_ses_*` options are removed on uninstall.
- New certificate / new subdomain notification trigger (Section 22.5):
  `NotificationDispatcher::check_new_assets()` diffs the just-completed observation's `ct` and
  `subdomains` collector evidence against its predecessor and notifies the organisation of
  anything newly seen, firing on `wpr_job_completed` for succeeded/partially-succeeded runs.
- Customer-requested task reminder (Section 22.5): schema v8 adds `reminder_requested` to
  `wpr_remediation_tasks`; a checkbox on the customer task form sets it, and the daily sweep
  (`NotificationDispatcher::check_task_reminders()`) sends one reminder per task per account when
  the target date is due or within 7 days.
- WP Questionnaires compatibility and cross-tool contact linkage (Sections 6.1.4, 9.0,
  18.1.1-18.1.4, 26.3): the shared Customer Platform gained schema v2 (`atcp_visitor_contexts`,
  `atcp_preferences`, `atcp_privacy_requests`, `atcp_contact_merge_log`) plus a unique
  `(source_object_type, source_object_id)` key on `atcp_interactions` as the migration idempotency
  marker. A new `VisitorContextService` implements the cross-tool `at_contact_context` cookie
  (256-bit opaque token, keyed hash only in DB, Secure/HttpOnly/SameSite#Lax/Path#/), a
  `CookiePurposeClassifier` enforces Section 18.1.2's consent boundary, and a
  `MergePrecedenceResolver` implements Section 18.1.3's precedence ladder; the context is
  associated with the canonical contact on login, registration and email verification, with
  security events on contact mismatch. `ContactMergeService` plus an admin "Contact merge" screen
  implement Section 18.1.4's dedup/merge/review workflow with before/after snapshots.
  `WpqCompatibilityAdapter` links WPQ submissions/enquiries to canonical contacts (reading WPQ
  only through its public static methods, guarded by `WpqCapabilityProbe`), `WpqMigrationService`
  migrates existing WPQ rows idempotently (ambiguous rows queued for review, opt-outs preserved),
  a `wp reconnaissance wpq-migrate` WP-CLI command drives it, and `PersonalDataLocator` now
  includes WPQ data in the same privacy export/rights-request workflow when WPQ is active.

### Fixed

- TLS chain-trust probe reporting hostname mismatches as chain distrust: `probe_chain_trust()`
  set `verify_peer_name#true` alongside `verify_peer#true`, so a domain with a perfectly valid
  certificate chain but a merely mismatched hostname would fail that connection too and get
  reported as `chain_trusted#false` - misattributing a hostname problem as a chain-trust one.
  `hostname_matches()` already independently determines the hostname outcome from the captured
  certificate's SAN/CN, so the trust probe now only verifies the chain
  (`TlsCollector::probe_chain_trust()`); SNI is unaffected since it's controlled by
  `SNI_enabled`/`peer_name`, not `verify_peer_name`.
- `ci.yml`/`release.yml` targeted the specific self-hosted runner machine by its bare
  `self-hosted` label; when that machine couldn't service a job (offline, swapped for a different
  host), there was no way to redirect work without editing every job's `runs-on`. Both workflows
  now target the org's `Default` runner group directly (`runs-on: { group: Default, labels:
  [self-hosted] }`), so whichever self-hosted runner is online in that group - local or remote -
  picks up the job with no workflow change needed.

### Known limitations

- Notification triggers implemented are a defensible subset of Section 22.5's full list: the new
  mail-enabled lookalike domain trigger is not covered, since it needs the lookalike collector to
  emit evidence, which the worker does not produce yet. New certificate, new subdomain and
  customer-requested task reminders are now implemented (see Added).
- Mail suppression for Marketing-purpose messages checks this plugin's own
  `wpr_marketing_consent` flag, not the shared Customer Platform's `atcp_consents` ledger that is
  also recorded at registration - wiring suppression through the cross-plugin contact contract
  is a reasonable follow-up once a second product needs to observe the same consent decision.
- The retention sweep does not purge issued reports (Section 26.7 says to retain them "according
  to the organisation policy" - silently deleting a customer's historical deliverables deserves
  its own careful implementation, not a rushed addition alongside evidence/log cleanup), CRM
  leads (no lead entity exists yet), or anything under legal hold (no hold concept exists yet).
- The prioritisation algorithm deliberately does not model customer-specific applicability or an
  explicit task dependency graph (Section 21.5) - both need data this plugin does not capture
  yet.
- Customers can update a remediation task's status and their own notes, but not its target date
  or operator notes - those remain operator-only (Admin/REST).
- The Customer Platform's visitor-context cookie, preferences, privacy-request tracking and
  contact merge/review log are built (see Added), but the coordinated WP Questionnaires-side
  migration that adds `contact_id` columns to `wpq_submissions`/`wpq_enquiries` and updates the
  WPQ Contacts screen (Section 9.0) is not - it requires write access to the `wp-questionnaires`
  plugin, which was read-only for this work.
- The self-service free-assessment journey only covers the single domain a customer supplies at
  registration; a customer cannot yet add a second domain to their organisation and trigger its
  own free assessment themselves - that still requires an operator (Admin/REST).
- No CRM lead capture or full-purpose consent/preference centre beyond the single marketing
  decision yet (Section 22.6/22.7) - the shared `atcp_preferences` store and the visitor-context
  cookie-choice preference are built, but a full consent/preference centre UI is not.
- `PersonalDataLocator` deliberately covers WordPress user/account data, the shared Customer
  Platform contact record, audit log entries, mail history and (when WPQ is active) WP
  Questionnaires data - not the Customer Platform's interaction/consent ledger (no read method
  exists yet on `ContactServiceInterface`), and not organisational security data
  (findings/evidence/reports, which describe a domain rather than the requester).
- Erasure is never fully automatic: `PersonalDataEraser` only ever removes queued/sent mail
  history unconditionally. An active customer account, the shared contact record and audit log
  entries are always retained and flagged for manual review through the admin privacy-request
  workflow, since deleting an active account has cross-organisation consequences (other members,
  in-flight assessments, issued reports) this plugin does not yet have a deliberate, reviewed way
  to action automatically.
- "Restriction of processing" on a privacy request is tracked and operator-visible only; it is not
  wired into any actual processing decision elsewhere in the plugin yet (assessment dispatch,
  reporting, etc. do not check it).
- Site Health's remote-worker-connectivity check always reports "not applicable", since the remote
  worker adapter itself is Phase 3 scope and is not selectable yet.

## 0.1.1 - 2026-08-12

No functional change. Confirms the self-hosted update pipeline end to end: release build,
package smoke test, GitHub Release, and publish to the shared `alltimeuk/wp-updates` update
server - `v0.1.0`'s deploy step failed because the deploy token wasn't yet reachable by this
(private) repository; see the fix below.

### Fixed

- `WP_UPDATES_TOKEN` was created as an organisation-level secret, but GitHub only delivers
  organisation secrets to private repositories on paid org plans; `alltimeuk` is on the Free
  plan, so the secret silently resolved empty in the release workflow. Switched to a
  repository-level secret on `wp-reconnaissance`, matching the existing `wp-questionnaires`
  setup.

## 0.1.0 - 2026-08-12

Initial Phase 1 scaffold and first working slice of the collection-to-findings pipeline and the
customer identity journey.

### Added

- Plugin bootstrap, Composer PSR-4 autoloading, and the PHPUnit/PHPCS/PHPStan quality-gate
  tooling.
- Database migrations for the core reconnaissance tables (organisations, scopes, profiles, jobs,
  observations, evidence, findings, finding events, audit log) and the customer auth-token store.
- Domain entities and `DomainValidator` (canonical ASCII/IDNA handling, correct Public Suffix
  List behaviour, rejection of IP literals/URLs/shell syntax).
- Job manifest and evidence JSON Schemas, and the execution adapter layer (`LocalProcessAdapter`
  with the Section 16 security controls, `RemoteWorkerAdapter` stub for Phase 3).
- A PHP-based collection worker (`worker/collect.php`) implementing all nine collectors (RDAP,
  DNS, DNSSEC, mail/SPF/DMARC/DKIM, HTTP, TLS, Certificate Transparency, subdomains, lookalike
  domains), verified end-to-end against a live domain.
- `Assessment\AssessmentService`: the orchestrator that turns an authorised scope into a job,
  dispatches it, ingests and schema-validates the returned evidence, evaluates the rule engine,
  and creates/updates/reopens/resolves findings by diffing against the scope's prior state.
- 22 core rules with real evaluation handlers across registration, mail, DNS, web and TLS
  categories.
- Working `wp reconnaissance` WP-CLI commands (`run`, `scope add`, `scope list`, `job status`,
  `findings list`, `worker test`).
- The customer identity journey: registration, email verification, login, logout,
  forgot/reset-password, and a minimal account page - dedicated `/customer/*` routes, never
  `wp-login.php`, with anti-enumeration responses, nonces, rate limiting, and session rotation
  after password changes.
- Self-hosted plugin updater (`Support\Updater`), onboarded onto the shared
  `alltimeuk/wp-updates` update server alongside `wp-questionnaires`.

### Known limitations

- Mail delivery is not yet implemented (Gmail API/SES providers are stubs); registration and
  password-reset links are logged rather than emailed.
- The consent ledger is a single marketing-consent flag, not the full Section 6.1.2 shared
  contact-platform subsystem.
- No customer portal, remediation-task generation, report rendering (HTML/PDF/Markdown/JSON),
  entitlements, anti-abuse controls, or WP Questionnaires integration yet.
- Not yet exercised against a live WordPress `$wpdb` - verified via static analysis and unit
  tests, plus a live end-to-end run of the collection worker itself.
