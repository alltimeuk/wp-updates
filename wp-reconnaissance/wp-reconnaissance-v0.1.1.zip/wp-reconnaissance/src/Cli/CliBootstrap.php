<?php
/**
 * WP-CLI command registration, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

final class CliBootstrap {

	public function boot(): void {
		if ( ! defined( 'WP_CLI' ) || ! \WP_CLI ) {
			return;
		}

		\WP_CLI::add_command( 'reconnaissance', ReconnaissanceCommand::class );
		\WP_CLI::add_command( 'reconnaissance organisation', OrganisationCommand::class );
		\WP_CLI::add_command( 'reconnaissance scope', ScopeCommand::class );
		\WP_CLI::add_command( 'reconnaissance job', JobCommand::class );
		\WP_CLI::add_command( 'reconnaissance findings', FindingsCommand::class );
		\WP_CLI::add_command( 'reconnaissance report', ReportCommand::class );
		\WP_CLI::add_command( 'reconnaissance worker', WorkerCommand::class );
		\WP_CLI::add_command( 'reconnaissance retention', RetentionCommand::class );
	}
}
