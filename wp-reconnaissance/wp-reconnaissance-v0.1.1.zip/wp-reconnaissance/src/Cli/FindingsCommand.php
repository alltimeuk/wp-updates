<?php
/**
 * `wp reconnaissance findings ...`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Findings\FindingRepository;

final class FindingsCommand {

	/**
	 * Lists findings for a scope.
	 *
	 * ## OPTIONS
	 *
	 * --scope-id=<id>
	 * : Numeric scope ID.
	 *
	 * @param array<string,string> $assoc_args
	 */
	public function list( array $args = array(), array $assoc_args = array() ): void {
		if ( empty( $assoc_args['scope-id'] ) ) {
			\WP_CLI::error( 'Usage: wp reconnaissance findings list --scope-id=<id>' );
			return;
		}

		$findings = ( new FindingRepository() )->find_by_scope( (int) $assoc_args['scope-id'] );

		if ( array() === $findings ) {
			\WP_CLI::log( 'No findings found.' );
			return;
		}

		\WP_CLI\Utils\format_items(
			'table',
			array_map(
				static fn ( $finding ): array => array(
					'rule_id'    => $finding->rule_id,
					'severity'   => $finding->severity->value,
					'confidence' => $finding->confidence->value,
					'status'     => $finding->status->value,
					'title'      => $finding->title,
				),
				$findings
			),
			array( 'rule_id', 'severity', 'confidence', 'status', 'title' )
		);
	}
}
