<?php
/**
 * Shared helper for WP-CLI subcommands that are part of the Phase 1 command surface but whose
 * underlying service is not yet implemented.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

trait NotYetImplementedTrait {

	private function not_yet_implemented( string $command ): void {
		\WP_CLI::error( sprintf( '"%s" is registered but not yet implemented.', $command ) );
	}
}
