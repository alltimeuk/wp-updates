<?php
/**
 * `wp reconnaissance retention run`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

final class RetentionCommand {

	use NotYetImplementedTrait;

	/**
	 * Executes retention and deletion rules (Section 26.7).
	 */
	public function run(): void {
		$this->not_yet_implemented( 'wp reconnaissance retention run' );
	}
}
