<?php
/**
 * `wp reconnaissance job ...`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Data\Repositories\JobRepository;

final class JobCommand {

	/**
	 * Shows job status.
	 *
	 * ## OPTIONS
	 *
	 * <job-id>
	 * : The job UUID.
	 *
	 * @param string[] $args
	 */
	public function status( array $args ): void {
		if ( empty( $args[0] ) ) {
			\WP_CLI::error( 'Usage: wp reconnaissance job status <job-id>' );
			return;
		}

		$job = ( new JobRepository() )->find_by_uuid( (string) $args[0] );

		if ( null === $job ) {
			\WP_CLI::error( "No job found with UUID {$args[0]}." );
			return;
		}

		$fields = array(
			'job_uuid'       => $job->job_uuid,
			'status'         => $job->status->value,
			'scope_id'       => (string) $job->scope_id,
			'adapter'        => $job->adapter ?? '',
			'worker_version' => $job->worker_version ?? '',
			'exit_code'      => (string) ( $job->exit_code ?? '' ),
			'error_category' => $job->error_category ?? '',
			'requested_at'   => $job->requested_at->format( DATE_ATOM ),
			'completed_at'   => $job->completed_at?->format( DATE_ATOM ) ?? '',
		);

		foreach ( $fields as $label => $value ) {
			\WP_CLI::log( "{$label}: {$value}" );
		}
	}
}
