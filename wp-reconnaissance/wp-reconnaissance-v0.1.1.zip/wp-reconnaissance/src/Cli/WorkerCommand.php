<?php
/**
 * `wp reconnaissance worker test`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Execution\LocalProcessAdapter;
use Alltime\WPReconnaissance\Execution\RemoteWorkerAdapter;

final class WorkerCommand {

	/**
	 * Reports whether the configured execution adapters are ready, mirroring the Site Health
	 * check described in Section 16.
	 */
	public function test(): void {
		$local = ( new LocalProcessAdapter() )->is_ready();
		\WP_CLI::log( sprintf( 'Local process adapter: %s', $local ? 'ready' : 'not ready / disabled' ) );

		$remote = ( new RemoteWorkerAdapter() )->is_ready();
		\WP_CLI::log( sprintf( 'Remote worker adapter: %s', $remote ? 'ready' : 'not ready (Phase 3)' ) );

		if ( ! $local && ! $remote ) {
			\WP_CLI::warning( 'No execution adapter is currently ready to run collection jobs.' );
			return;
		}

		\WP_CLI::success( 'At least one execution adapter is ready.' );
	}
}
