<?php
/**
 * `wp reconnaissance organisation ...`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Data\Schema;

final class OrganisationCommand {

	/**
	 * Lists organisations.
	 */
	public function list(): void {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( "SELECT id, name, slug, status FROM `{$table}` ORDER BY id DESC", ARRAY_A );

		if ( empty( $rows ) ) {
			\WP_CLI::log( 'No organisations found.' );
			return;
		}

		\WP_CLI\Utils\format_items( 'table', $rows, array( 'id', 'name', 'slug', 'status' ) );
	}
}
