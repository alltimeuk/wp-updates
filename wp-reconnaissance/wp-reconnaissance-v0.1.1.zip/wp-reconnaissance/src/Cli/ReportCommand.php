<?php
/**
 * `wp reconnaissance report ...`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

final class ReportCommand {

	use NotYetImplementedTrait;

	/**
	 * Generates a report for a scope.
	 *
	 * ## OPTIONS
	 *
	 * <scope-id>
	 * : The numeric ID of the scope to report on.
	 *
	 * @param string[] $args
	 */
	public function generate( array $args ): void {
		$this->not_yet_implemented( 'wp reconnaissance report generate <scope-id>' );
	}
}
