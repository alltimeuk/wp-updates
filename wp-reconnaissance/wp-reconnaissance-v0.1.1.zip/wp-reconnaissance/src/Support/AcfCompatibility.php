<?php
/**
 * Advanced Custom Fields compatibility guard, per Section 9.2.
 *
 * ACF is required for the branded content-editing experience, but its absence or an
 * unsupported version must produce a clear administrator notice rather than a fatal error.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

/**
 * Detects ACF availability/version and gates ACF-dependent registration accordingly.
 */
final class AcfCompatibility {

	public const MINIMUM_VERSION = '6.6.2';

	public static function boot(): void {
		if ( self::is_available() ) {
			add_action( 'acf/init', array( self::class, 'register_field_groups' ) );
			return;
		}

		add_action( 'admin_notices', array( self::class, 'render_missing_notice' ) );
	}

	public static function is_available(): bool {
		return function_exists( 'acf_get_setting' )
			&& version_compare( (string) acf_get_setting( 'version' ), self::MINIMUM_VERSION, '>=' );
	}

	/**
	 * Registers plugin-owned ACF field groups. Local JSON definitions are loaded from
	 * `acf-json/` via the `acf/settings/load_json` filter registered here.
	 */
	public static function register_field_groups(): void {
		add_filter(
			'acf/settings/load_json',
			static function ( array $paths ): array {
				$paths[] = trailingslashit( \Alltime\WPReconnaissance\WPR_PLUGIN_DIR ) . 'acf-json';

				return $paths;
			}
		);
	}

	public static function render_missing_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: %s: minimum required ACF version. */
					__( 'WP-Reconnaissance branding and content editing requires Advanced Custom Fields %s or later. Core reconnaissance functionality remains available.', 'wp-reconnaissance' ),
					self::MINIMUM_VERSION
				)
			)
		);
	}
}
