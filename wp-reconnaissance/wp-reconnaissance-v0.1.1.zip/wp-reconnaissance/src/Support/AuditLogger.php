<?php
/**
 * Append-only audit logging against `wpr_audit_log`, per Section 25.
 *
 * Never pass passwords, tokens, complete manifests containing secrets, or raw evidence into
 * `$summary` - the audit log records that an action happened, not the sensitive payload it
 * happened to.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

use Alltime\WPReconnaissance\Data\Schema;

final class AuditLogger {

	public function log(
		string $action,
		string $object_type,
		?int $object_id = null,
		?int $actor_id = null,
		string $outcome = 'success',
		?string $summary = null,
		string $source = 'admin'
	): void {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'actor_id'    => $actor_id,
				'action'      => $action,
				'object_type' => $object_type,
				'object_id'   => $object_id,
				'source'      => $source,
				'outcome'     => $outcome,
				'summary'     => $summary,
				'occurred_at' => current_time( 'mysql', true ),
			)
		);
	}
}
