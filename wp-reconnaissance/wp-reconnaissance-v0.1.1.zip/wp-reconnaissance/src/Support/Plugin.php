<?php
/**
 * Plugin bootstrap container.
 *
 * The bootstrap file only wires activation/deactivation hooks and defers everything else to
 * this class. No business logic lives here or in the plugin bootstrap file itself.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

use Alltime\WPReconnaissance\Admin\AdminBootstrap;
use Alltime\WPReconnaissance\Api\RestBootstrap;
use Alltime\WPReconnaissance\Auth\AuthBootstrap;
use Alltime\WPReconnaissance\Cli\CliBootstrap;
use Alltime\WPReconnaissance\Data\Migrator;
use Alltime\WPReconnaissance\Integrations\IntegrationsBootstrap;
use Alltime\WPReconnaissance\Privacy\PrivacyBootstrap;
use Alltime\WPReconnaissance\Rules\RulesBootstrap;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;

use const Alltime\WPReconnaissance\WPR_PLUGIN_DIR;

/**
 * Coordinates activation, deactivation and runtime boot of the plugin's modules.
 */
final class Plugin {

	private static ?self $instance = null;

	private bool $booted = false;

	private function __construct() {}

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Runs on plugin activation: installs/upgrades the database schema, registers roles and
	 * flushes rewrite rules for the front-end customer routes. Never destroys existing data.
	 */
	public static function activate(): void {
		Migrator::install();
		Roles::register();

		add_option( 'wpr_local_adapter_enabled', false );
		add_option( 'wpr_remove_data_on_uninstall', false );

		flush_rewrite_rules();
	}

	/**
	 * Runs on plugin deactivation. Deliberately does not remove data, tables or roles - only
	 * uninstall.php (with explicit administrator opt-in) may do that.
	 */
	public static function deactivate(): void {
		flush_rewrite_rules();
	}

	/**
	 * Boots the plugin at `plugins_loaded`. Idempotent.
	 */
	public function boot(): void {
		if ( $this->booted ) {
			return;
		}

		$this->booted = true;

		load_plugin_textdomain( 'wp-reconnaissance', false, dirname( plugin_basename( WPR_PLUGIN_DIR . 'wp-reconnaissance.php' ) ) . '/languages' );

		Migrator::maybe_upgrade();

		Roles::boot();

		( new AdminBootstrap() )->boot();
		( new RestBootstrap() )->boot();
		( new AuthBootstrap() )->boot();
		( new CliBootstrap() )->boot();
		( new IntegrationsBootstrap() )->boot();
		( new PrivacyBootstrap() )->boot();
		( new RulesBootstrap() )->boot();
		( new SchedulingBootstrap() )->boot();

		AcfCompatibility::boot();
	}
}
