<?php
/**
 * Evaluates loaded rule definitions against a normalised evidence document, per Section 13.
 *
 * The engine only dispatches to registered handlers; it holds no scoring logic itself, so the
 * same evidence and rule version always produce the same result (Section 3, "deterministic
 * rules"). Concrete handlers for the Section 13 rule catalogue are added incrementally and
 * register themselves via the `wpr_rule_handlers` filter.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

final class RuleEngine {

	public function __construct(
		private readonly RuleLoader $loader = new RuleLoader()
	) {}

	/**
	 * @param array<string,mixed> $evidence Decoded evidence.schema.json document.
	 * @return array<string,RuleResult> Rule ID => result, only for rules that fired.
	 */
	public function evaluate( array $evidence ): array {
		$handlers = $this->handlers();
		$results  = array();

		foreach ( $this->loader->load_core_rules() as $rule_id => $rule ) {
			if ( ! $rule->enabled_by_default && ! $this->is_explicitly_enabled( $rule_id ) ) {
				continue;
			}

			$handler = $handlers[ $rule->evaluation_handler ] ?? null;

			if ( null === $handler ) {
				continue;
			}

			$result = $handler->evaluate( $rule, $evidence );

			if ( null !== $result ) {
				$results[ $rule_id ] = $result;
			}
		}

		return $results;
	}

	/**
	 * @return array<string,RuleHandlerInterface>
	 */
	private function handlers(): array {
		/**
		 * Filters the registry of rule evaluation handlers, keyed by handler identifier.
		 *
		 * @param array<string,RuleHandlerInterface> $handlers
		 */
		return apply_filters( 'wpr_rule_handlers', array() );
	}

	private function is_explicitly_enabled( string $rule_id ): bool {
		$overrides = get_option( 'wpr_rule_overrides', array() );

		return is_array( $overrides ) && ! empty( $overrides[ $rule_id ] );
	}
}
