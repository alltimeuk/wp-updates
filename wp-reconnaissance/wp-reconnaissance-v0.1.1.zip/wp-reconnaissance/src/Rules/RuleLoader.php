<?php
/**
 * Loads and validates rule definitions from `rules/core/*.json` against
 * `schemas/rule.schema.json`.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

use Opis\JsonSchema\Errors\ErrorFormatter;
use Opis\JsonSchema\Validator;

use const Alltime\WPReconnaissance\WPR_PLUGIN_DIR;

final class RuleLoader {

	/**
	 * @return RuleDefinition[] Keyed by rule_id.
	 */
	public function load_core_rules(): array {
		$rules  = array();
		$schema = json_decode( (string) file_get_contents( WPR_PLUGIN_DIR . 'schemas/rule.schema.json' ) );

		if ( ! $schema instanceof \stdClass ) {
			throw new \RuntimeException( esc_html( 'Unable to load or parse schemas/rule.schema.json.' ) );
		}

		$validator = new Validator();

		$rule_files = glob( WPR_PLUGIN_DIR . 'rules/core/*.json' );

		foreach ( false !== $rule_files ? $rule_files : array() as $file ) {
			$decoded = json_decode( (string) file_get_contents( $file ) );

			if ( null === $decoded ) {
				throw new \RuntimeException( esc_html( "Rule file is not valid JSON: {$file}" ) );
			}

			// A decoded schema object is passed directly rather than a file:// URI string, so
			// validation doesn't depend on platform-specific URI parsing of local file paths.
			$result = $validator->validate( $decoded, $schema );

			if ( ! $result->isValid() ) {
				$formatter = new ErrorFormatter();
				throw new \RuntimeException(
					esc_html( "Rule file failed schema validation: {$file} - " . wp_json_encode( $formatter->format( $result->error() ) ) )
				);
			}

			$rule = RuleDefinition::from_array( (array) json_decode( (string) file_get_contents( $file ), true ) );

			$rules[ $rule->rule_id ] = $rule;
		}

		return $rules;
	}
}
