<?php
/**
 * Outcome of evaluating one rule against one observation's evidence.
 *
 * A null return from a handler means the rule did not fire (no finding). A non-null result
 * always carries the confidence the handler actually established - never a value stronger
 * than the evidence supports (Section 13.2).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;

final class RuleResult {

	/**
	 * @param array<string,mixed> $expected_state
	 * @param array<string,mixed> $observed_state
	 * @param string[]            $evidence_refs
	 */
	public function __construct(
		public readonly Confidence $confidence,
		public readonly array $expected_state,
		public readonly array $observed_state,
		public readonly array $evidence_refs
	) {}
}
