<?php
/**
 * Small helper shared by rule handlers to locate a specific collector's result within a decoded
 * evidence.schema.json document, so every handler doesn't re-implement the same array scan.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

final class EvidenceAccessor {

	/**
	 * @param array<string,mixed> $evidence Decoded evidence.schema.json document.
	 * @return array<string,mixed>|null The collector's result entry (status, data, limitations,
	 *                                    errors), or null if this evidence document has no
	 *                                    result for that collector at all.
	 */
	public static function collector( array $evidence, string $key ): ?array {
		foreach ( $evidence['collectors'] ?? array() as $collector ) {
			if ( ( $collector['collector'] ?? null ) === $key ) {
				return $collector;
			}
		}

		return null;
	}

	/**
	 * @param array<string,mixed> $evidence Decoded evidence.schema.json document.
	 * @return array<string,mixed> The collector's `data` payload, or an empty array if the
	 *                              collector is absent or did not succeed - callers should pair
	 *                              this with {@see usable()} before drawing a conclusion from it.
	 */
	public static function data( array $evidence, string $key ): array {
		$collector = self::collector( $evidence, $key );

		return is_array( $collector['data'] ?? null ) ? $collector['data'] : array();
	}

	/**
	 * True when the collector ran and produced evidence a rule can safely reason about
	 * (succeeded or partially_succeeded). A rule must never fire from a collector that
	 * failed, timed out, was rate-limited or was skipped - that is an absence of evidence, not
	 * evidence of absence (Section 3).
	 */
	public static function usable( array $evidence, string $key ): bool {
		$collector = self::collector( $evidence, $key );

		return null !== $collector && in_array( $collector['status'] ?? '', array( 'succeeded', 'partially_succeeded' ), true );
	}
}
