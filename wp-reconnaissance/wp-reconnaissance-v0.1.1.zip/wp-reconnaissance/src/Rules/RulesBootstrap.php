<?php
/**
 * Registers the core rule evaluation handlers via the `wpr_rule_handlers` filter, per Section 13.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

use Alltime\WPReconnaissance\Rules\Handlers\DnsRuleHandlers;
use Alltime\WPReconnaissance\Rules\Handlers\MailRuleHandlers;
use Alltime\WPReconnaissance\Rules\Handlers\RegistrationRuleHandlers;
use Alltime\WPReconnaissance\Rules\Handlers\TlsRuleHandlers;
use Alltime\WPReconnaissance\Rules\Handlers\WebRuleHandlers;

final class RulesBootstrap {

	public function boot(): void {
		add_filter( 'wpr_rule_handlers', array( $this, 'register_core_handlers' ) );
	}

	/**
	 * @param array<string,RuleHandlerInterface> $handlers
	 * @return array<string,RuleHandlerInterface>
	 */
	public function register_core_handlers( array $handlers ): array {
		return array_merge(
			$handlers,
			array(
				'registration_rules' => new RegistrationRuleHandlers(),
				'mail_rules'         => new MailRuleHandlers(),
				'dns_rules'          => new DnsRuleHandlers(),
				'web_rules'          => new WebRuleHandlers(),
				'tls_rules'          => new TlsRuleHandlers(),
			)
		);
	}
}
