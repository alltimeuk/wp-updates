<?php
/**
 * Contract for a rule's evaluation handler, per Section 13.
 *
 * Handlers are looked up by the `evaluation.handler` identifier in the rule definition. Kept
 * as small, named, testable units rather than embedding scoring logic in collectors.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

interface RuleHandlerInterface {

	/**
	 * Evaluates a rule against a normalised evidence document.
	 *
	 * @param array<string,mixed> $evidence Decoded evidence.schema.json document for one observation.
	 */
	public function evaluate( RuleDefinition $rule, array $evidence ): ?RuleResult;
}
