<?php
/**
 * In-memory representation of a data-driven rule, per Section 13 and `schemas/rule.schema.json`.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

use Alltime\WPReconnaissance\Domain\Enums\ChangeSignificance;
use Alltime\WPReconnaissance\Domain\Enums\Severity;

final class RuleDefinition {

	/**
	 * @param string[]                                               $evidence_requirements
	 * @param array<int,array{reference:string,relationship:string}> $standards_references
	 * @param string[]                                               $technical_subjects
	 */
	public function __construct(
		public readonly string $rule_id,
		public readonly string $version,
		public readonly string $title,
		public readonly string $category,
		public readonly string $applicability,
		public readonly array $evidence_requirements,
		public readonly string $evaluation_handler,
		public readonly Severity $severity,
		public readonly string $confidence_strategy,
		public readonly string $risk_statement,
		public readonly string $recommendation,
		public readonly array $standards_references,
		public readonly ChangeSignificance $change_significance,
		public readonly bool $enabled_by_default,
		public readonly array $technical_subjects = array()
	) {}

	/**
	 * @param array<string,mixed> $data Decoded rule.schema.json document.
	 */
	public static function from_array( array $data ): self {
		return new self(
			rule_id: (string) $data['rule_id'],
			version: (string) $data['version'],
			title: (string) $data['title'],
			category: (string) $data['category'],
			applicability: (string) $data['applicability'],
			evidence_requirements: $data['evidence_requirements'],
			evaluation_handler: (string) $data['evaluation']['handler'],
			severity: Severity::from( (string) $data['severity'] ),
			confidence_strategy: (string) $data['confidence']['strategy'],
			risk_statement: (string) $data['risk_statement'],
			recommendation: (string) $data['recommendation'],
			standards_references: $data['standards_references'] ?? array(),
			change_significance: ChangeSignificance::from( (string) $data['change_significance'] ),
			enabled_by_default: (bool) $data['enabled_by_default'],
			technical_subjects: $data['technical_subjects'] ?? array()
		);
	}
}
