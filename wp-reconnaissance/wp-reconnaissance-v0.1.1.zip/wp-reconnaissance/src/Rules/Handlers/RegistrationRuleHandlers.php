<?php
/**
 * Evaluation handlers for registration-related rules (Section 13, category "registration").
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules\Handlers;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Rules\EvidenceAccessor;
use Alltime\WPReconnaissance\Rules\RuleDefinition;
use Alltime\WPReconnaissance\Rules\RuleHandlerInterface;
use Alltime\WPReconnaissance\Rules\RuleResult;

final class RegistrationRuleHandlers implements RuleHandlerInterface {

	private const EXPIRY_WARNING_DAYS = 30;

	public function evaluate( RuleDefinition $rule, array $evidence ): ?RuleResult {
		return match ( $rule->rule_id ) {
			'REG.DOMAIN.EXPIRING' => $this->domain_expiring( $evidence ),
			default => null,
		};
	}

	private function domain_expiring( array $evidence ): ?RuleResult {
		if ( ! EvidenceAccessor::usable( $evidence, 'rdap' ) ) {
			return null;
		}

		$data = EvidenceAccessor::data( $evidence, 'rdap' );

		if ( empty( $data['expiry'] ) ) {
			return null;
		}

		$expiry = new \DateTimeImmutable( (string) $data['expiry'] );
		$days   = (int) floor( ( $expiry->getTimestamp() - time() ) / 86400 );

		if ( $days > self::EXPIRY_WARNING_DAYS ) {
			return null;
		}

		return new RuleResult(
			confidence: Confidence::Confirmed,
			expected_state: array( 'registration' => 'renewed_in_time' ),
			observed_state: array(
				'expiry'         => $data['expiry'],
				'days_remaining' => $days,
			),
			evidence_refs: array( 'rdap' )
		);
	}
}
