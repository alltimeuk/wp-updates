<?php
/**
 * Evaluation handlers for TLS/certificate rules (Section 13, category "tls").
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules\Handlers;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Rules\EvidenceAccessor;
use Alltime\WPReconnaissance\Rules\RuleDefinition;
use Alltime\WPReconnaissance\Rules\RuleHandlerInterface;
use Alltime\WPReconnaissance\Rules\RuleResult;

final class TlsRuleHandlers implements RuleHandlerInterface {

	private const EXPIRY_WARNING_DAYS = 30;

	public function evaluate( RuleDefinition $rule, array $evidence ): ?RuleResult {
		if ( ! EvidenceAccessor::usable( $evidence, 'tls' ) ) {
			return null;
		}

		$data = EvidenceAccessor::data( $evidence, 'tls' );

		if ( empty( $data['certificate']['connected'] ) ) {
			return null;
		}

		return match ( $rule->rule_id ) {
			'TLS.CERT.EXPIRED' => $this->cert_expired( $data ),
			'TLS.CERT.EXPIRING' => $this->cert_expiring( $data ),
			'TLS.CERT.HOSTNAME_MISMATCH' => $this->hostname_mismatch( $data ),
			'TLS.CERT.CHAIN_INVALID' => $this->chain_invalid( $data ),
			default => null,
		};
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function cert_expired( array $data ): ?RuleResult {
		$days = (int) ( $data['expires_in_days'] ?? 0 );

		if ( $days >= 0 ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'expires_in_days' => '>= 0' ), array( 'expires_in_days' => $days ), array( 'tls' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function cert_expiring( array $data ): ?RuleResult {
		$days = (int) ( $data['expires_in_days'] ?? 0 );

		if ( $days < 0 || $days > self::EXPIRY_WARNING_DAYS ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'expires_in_days' => '> ' . self::EXPIRY_WARNING_DAYS ), array( 'expires_in_days' => $days ), array( 'tls' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function hostname_mismatch( array $data ): ?RuleResult {
		if ( false !== ( $data['certificate']['hostname_matches'] ?? true ) ) {
			return null;
		}

		return new RuleResult(
			Confidence::Confirmed,
			array( 'hostname_matches' => true ),
			array(
				'hostname_matches' => false,
				'san'              => $data['certificate']['san'] ?? array(),
			),
			array( 'tls' )
		);
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function chain_invalid( array $data ): ?RuleResult {
		if ( true === ( $data['certificate']['chain_trusted'] ?? true ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'chain_trusted' => true ), array( 'chain_trusted' => false ), array( 'tls' ) );
	}
}
