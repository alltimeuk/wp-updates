<?php
/**
 * Amazon SES mail provider, per Section 22.3.
 *
 * Full SDK wiring, bounce/complaint event ingestion and IAM-role credential support are not
 * yet implemented in this scaffold.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;

final class SesProvider implements MailProviderInterface {

	public function id(): string {
		return 'amazon_ses';
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( '' === (string) get_option( 'wpr_ses_region', '' ) ) {
			$errors[] = 'Amazon SES region is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_ses_sender_address', '' ) ) {
			$errors[] = 'Amazon SES verified sender identity is not configured.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		throw new MailDeliveryException( 'The Amazon SES provider is not yet implemented.' );
	}
}
