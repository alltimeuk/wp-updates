<?php
/**
 * Mail-provider abstraction, per Section 22.1. Administrators select exactly one active
 * provider at a time; messages already submitted retain their provider identity and status
 * even if the active provider setting later changes.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

interface MailProviderInterface {

	/** Stable provider identifier, e.g. "gmail_api" or "amazon_ses". */
	public function id(): string;

	/**
	 * Validates the provider's current configuration without sending anything.
	 *
	 * @return string[] Validation errors; empty when configuration is valid.
	 */
	public function validate_configuration(): array;

	/**
	 * Sends a single transactional message.
	 *
	 * @throws \Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException
	 */
	public function send( QueuedMessage $message ): MailSendResult;
}
