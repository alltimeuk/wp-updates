<?php
/**
 * Gmail API mail provider, per Section 22.2.
 *
 * Uses OAuth 2.0; never requests or stores the mailbox owner's Google password. Full OAuth
 * client-credential handling, token refresh and the Gmail API send call are not yet
 * implemented in this scaffold.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;

final class GmailProvider implements MailProviderInterface {

	public function id(): string {
		return 'gmail_api';
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( '' === (string) get_option( 'wpr_gmail_oauth_client_id', '' ) ) {
			$errors[] = 'Gmail OAuth client ID is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_gmail_sender_address', '' ) ) {
			$errors[] = 'Gmail authorised sender mailbox is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_gmail_refresh_token', '' ) ) {
			$errors[] = 'Gmail account is not connected (no refresh token stored).';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		throw new MailDeliveryException( 'The Gmail API provider is not yet implemented.' );
	}
}
