<?php
/**
 * Result of a provider send attempt, per Section 22.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

final class MailSendResult {

	public function __construct(
		public readonly string $provider_id,
		public readonly string $provider_message_id,
		public readonly string $state
	) {}
}
