<?php
/**
 * A single transactional/marketing message handed to a mail provider, per Section 22.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;

final class QueuedMessage {

	public function __construct(
		public readonly string $idempotency_key,
		public readonly string $recipient,
		public readonly string $template,
		public readonly MailPurpose $purpose,
		public readonly string $subject,
		public readonly string $html_body,
		/** @var array<string,mixed> */
		public readonly array $merge_fields = array()
	) {}
}
