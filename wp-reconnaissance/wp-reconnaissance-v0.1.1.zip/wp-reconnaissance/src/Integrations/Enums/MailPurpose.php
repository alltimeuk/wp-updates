<?php
/**
 * Processing-purpose classification for queued mail, per Sections 22.5 and 26.1.
 *
 * Transactional purposes must never be suppressed by a marketing opt-out; only Marketing is
 * subject to consent withdrawal and suppression screening.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations\Enums;

enum MailPurpose: string {
	case AccountSecurity = 'account_security';
	case ServiceDelivery = 'service_delivery';
	case PrivacyRequest  = 'privacy_request';
	case Marketing       = 'marketing';

	public function is_suppressible(): bool {
		return self::Marketing === $this;
	}
}
