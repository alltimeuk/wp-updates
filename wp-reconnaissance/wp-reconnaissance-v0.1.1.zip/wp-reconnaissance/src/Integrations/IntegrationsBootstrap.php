<?php
/**
 * Integrations module bootstrap, per Section 22.
 *
 * Wires the mail-provider abstraction and the notification action/filter hooks that later
 * modules (Findings, Reports, Scheduling) fire into. The WP Questionnaires compatibility
 * adapter described in Section 6.1.4 is separate, later Phase 1 work.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

final class IntegrationsBootstrap {

	public function boot(): void {
		// Notification hook surface (Section 22.5). Registered here so the action/filter names
		// are documented centrally even before their firing modules are implemented.
		//
		// do_action( 'wpr_job_completed', $job_id );
		// do_action( 'wpr_finding_created', $finding_id );
		// do_action( 'wpr_finding_changed', $finding_id, $event_id );
		// do_action( 'wpr_report_issued', $report_id );
		// apply_filters( 'wpr_notification_payload', $payload, $event ); // phpcs:ignore Squiz.Commenting.InlineComment.InvalidEndChar -- commented-out example code, not prose.
	}
}
