<?php
/**
 * Thrown when a mail provider cannot accept a message for delivery.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations\Exceptions;

class MailDeliveryException extends \RuntimeException {

	public function __construct(
		string $message,
		public readonly bool $is_transient = false
	) {
		parent::__construct( $message );
	}
}
