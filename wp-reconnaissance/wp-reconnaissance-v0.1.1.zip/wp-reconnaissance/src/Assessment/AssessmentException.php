<?php
/**
 * Thrown when an assessment cannot even be attempted (unknown scope). A failure once the job
 * exists is instead recorded on the job itself via {@see AssessmentService}, not thrown, so the
 * caller always gets a Job record back to inspect.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Assessment;

final class AssessmentException extends \RuntimeException {}
