<?php
/**
 * Persistence for authorised scopes against `wpr_scopes`, per Section 8.2.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Scope;

final class ScopeRepository {

	public function find( int $id ): ?Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Scope::from_row( $row ) : null;
	}

	/**
	 * @return Scope[]
	 */
	public function find_by_organisation( int $organisation_id ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_id = %d ORDER BY id DESC", $organisation_id ), ARRAY_A );

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Creates a new scope. Domain canonicalisation (ASCII/display/registrable) must already
	 * have happened via {@see \Alltime\WPReconnaissance\Domain\DomainValidator} before calling
	 * this - the repository persists what it is given, it does not validate.
	 *
	 * @param string[]            $permitted_collectors
	 * @param string[]            $known_subdomains
	 * @param string[]            $known_dkim_selectors
	 * @param array<string,mixed> $expected_state
	 */
	public function create(
		int $organisation_id,
		string $name,
		string $domain_ascii,
		string $domain_display,
		string $registrable_domain,
		array $permitted_collectors,
		?int $monitoring_profile_id = null,
		array $known_subdomains = array(),
		array $known_dkim_selectors = array(),
		array $expected_state = array()
	): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'organisation_id'       => $organisation_id,
			'name'                  => $name,
			'domain_ascii'          => $domain_ascii,
			'domain_display'        => $domain_display,
			'registrable_domain'    => $registrable_domain,
			'status'                => 'pending',
			'authorisation_status'  => 'pending',
			'permitted_collectors'  => wp_json_encode( $permitted_collectors ),
			'known_subdomains'      => wp_json_encode( $known_subdomains ),
			'known_dkim_selectors'  => wp_json_encode( $known_dkim_selectors ),
			'expected_state'        => wp_json_encode( $expected_state ),
			'monitoring_profile_id' => $monitoring_profile_id,
			'created_at'            => $now,
			'updated_at'            => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Authorises a pending scope. Section 27: the plugin must display a clear authorised-use
	 * notice during scope creation - enforced by the caller (the admin/CLI action invoking
	 * this), not by the repository.
	 */
	public function authorise(
		int $scope_id,
		int $authorised_by,
		string $authorisation_reference,
		?\DateTimeImmutable $authorised_from = null,
		?\DateTimeImmutable $authorised_until = null
	): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'                  => 'active',
				'authorisation_status'    => 'authorised',
				'authorised_by'           => $authorised_by,
				'authorisation_reference' => $authorisation_reference,
				'authorised_from'         => ( $authorised_from ?? new \DateTimeImmutable() )->format( 'Y-m-d H:i:s' ),
				'authorised_until'        => $authorised_until?->format( 'Y-m-d H:i:s' ),
				'updated_at'              => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		return $this->find_or_fail( $scope_id );
	}

	private function find_or_fail( int $id ): Scope {
		$scope = $this->find( $id );

		if ( null === $scope ) {
			throw new \RuntimeException( esc_html( "Scope {$id} was expected to exist but could not be loaded." ) );
		}

		return $scope;
	}
}
