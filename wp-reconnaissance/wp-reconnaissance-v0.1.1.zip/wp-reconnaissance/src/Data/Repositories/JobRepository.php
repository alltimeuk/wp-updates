<?php
/**
 * Persistence for jobs against `wpr_jobs`, per Section 8.4.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\JobStatus;
use Alltime\WPReconnaissance\Domain\Job;

final class JobRepository {

	public function find( int $id ): ?Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Job::from_row( $row ) : null;
	}

	public function find_by_uuid( string $job_uuid ): ?Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE job_uuid = %s", $job_uuid ), ARRAY_A );

		return null !== $row ? Job::from_row( $row ) : null;
	}

	public function create( string $job_uuid, int $organisation_id, int $scope_id, ?int $actor_id, string $adapter ): Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'job_uuid'        => $job_uuid,
			'organisation_id' => $organisation_id,
			'scope_id'        => $scope_id,
			'status'          => JobStatus::Pending->value,
			'adapter'         => $adapter,
			'actor_id'        => $actor_id,
			'requested_at'    => $now,
			'created_at'      => $now,
			'updated_at'      => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * @param array<string,mixed> $extra Additional columns to set alongside the status
	 *                                    transition (manifest_hash, worker_version, exit_code,
	 *                                    error_category, timestamps).
	 */
	public function transition( int $job_id, JobStatus $status, array $extra = array() ): Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		$data             = array_merge(
			$extra,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			)
		);
		$timestamp_column = match ( $status ) {
			JobStatus::Queued => 'queued_at',
			JobStatus::Running => 'started_at',
			JobStatus::Succeeded, JobStatus::PartiallySucceeded, JobStatus::Failed, JobStatus::Cancelled, JobStatus::Expired => 'completed_at',
			default => null,
		};

		if ( null !== $timestamp_column && ! isset( $data[ $timestamp_column ] ) ) {
			$data[ $timestamp_column ] = current_time( 'mysql', true );
		}

		$wpdb->update( $table, $data, array( 'id' => $job_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $job_id );
	}

	private function find_or_fail( int $id ): Job {
		$job = $this->find( $id );

		if ( null === $job ) {
			throw new \RuntimeException( esc_html( "Job {$id} was expected to exist but could not be loaded." ) );
		}

		return $job;
	}
}
