<?php
/**
 * Persistence for organisations against `wpr_organisations`, per Section 8.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Organisation;

final class OrganisationRepository {

	public function find( int $id ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	public function find_by_slug( string $slug ): ?Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE slug = %s", $slug ), ARRAY_A );

		return null !== $row ? Organisation::from_row( $row ) : null;
	}

	public function create( string $name, string $slug, ?int $primary_contact_id = null, string $timezone = 'UTC' ): Organisation {
		global $wpdb;

		$table = Schema::table( 'organisations' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'name'               => $name,
			'slug'               => $slug,
			'status'             => 'active',
			'primary_contact_id' => $primary_contact_id,
			'timezone'           => $timezone,
			'created_at'         => $now,
			'updated_at'         => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return Organisation::from_row( array_merge( $data, array( 'id' => $wpdb->insert_id ) ) );
	}

	/**
	 * Derives a unique slug from an organisation name, appending a numeric suffix on collision.
	 */
	public function unique_slug( string $name ): string {
		$base   = sanitize_title( $name );
		$base   = '' !== $base ? $base : 'organisation';
		$slug   = $base;
		$suffix = 2;

		while ( null !== $this->find_by_slug( $slug ) ) {
			$slug = "{$base}-{$suffix}";
			++$suffix;
		}

		return $slug;
	}
}
