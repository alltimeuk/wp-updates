<?php
/**
 * Persistence for observations and their per-collector evidence, per Section 8.5 and Section 9.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Observation;

final class ObservationRepository {

	public function find( int $id ): ?Observation {
		global $wpdb;

		$table = Schema::table( 'observations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Observation::from_row( $row ) : null;
	}

	/**
	 * The most recent observation for a scope before the given one, used by the change engine
	 * to compare against the preceding successful assessment.
	 */
	public function find_previous( int $scope_id, int $before_observation_id ): ?Observation {
		global $wpdb;

		$table = Schema::table( 'observations' );

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE scope_id = %d AND id < %d ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scope_id,
				$before_observation_id
			),
			ARRAY_A
		);

		return null !== $row ? Observation::from_row( $row ) : null;
	}

	/**
	 * Idempotent on job_id: re-ingesting the same job's evidence updates the existing
	 * observation rather than creating a duplicate (Section 28, Section 34 acceptance
	 * criterion 10).
	 *
	 * @param array<string,string>           $collector_versions
	 * @param string[]                       $limitations
	 * @param string[]                       $failed_collectors
	 * @param array<int,array<string,mixed>> $evidence_rows Decoded evidence.schema.json `collectors` entries.
	 */
	public function ingest(
		int $scope_id,
		int $job_id,
		\DateTimeImmutable $observed_at,
		array $collector_versions,
		string $schema_version,
		string $collection_status,
		?string $raw_evidence_ref,
		array $limitations,
		array $failed_collectors,
		string $integrity_hash,
		array $evidence_rows
	): Observation {
		global $wpdb;

		$table = Schema::table( 'observations' );

		$existing_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT id FROM `{$table}` WHERE job_id = %d", $job_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		$data = array(
			'scope_id'           => $scope_id,
			'job_id'             => $job_id,
			'observed_at'        => $observed_at->format( 'Y-m-d H:i:s' ),
			'collector_versions' => wp_json_encode( $collector_versions ),
			'schema_version'     => $schema_version,
			'collection_status'  => $collection_status,
			'raw_evidence_ref'   => $raw_evidence_ref,
			'limitations'        => wp_json_encode( $limitations ),
			'failed_collectors'  => wp_json_encode( $failed_collectors ),
			'integrity_hash'     => $integrity_hash,
		);

		if ( null !== $existing_id ) {
			$observation_id = (int) $existing_id;
			$wpdb->update( $table, $data, array( 'id' => $observation_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$this->delete_evidence_rows( $observation_id );
		} else {
			$data['created_at'] = current_time( 'mysql', true );
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$observation_id = (int) $wpdb->insert_id;
		}

		$this->insert_evidence_rows( $observation_id, $evidence_rows );

		$observation = $this->find( $observation_id );

		if ( null === $observation ) {
			throw new \RuntimeException( esc_html( "Observation {$observation_id} was expected to exist but could not be loaded." ) );
		}

		return $observation;
	}

	/**
	 * @return array<string,array<string,mixed>> Collector key => decoded `data` payload.
	 */
	public function evidence_data_by_collector( int $observation_id ): array {
		global $wpdb;

		$table = Schema::table( 'evidence' );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT collector, status, data FROM `{$table}` WHERE observation_id = %d", $observation_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		$by_collector = array();
		foreach ( null !== $rows ? $rows : array() as $row ) {
			$decoded                           = json_decode( (string) $row['data'], true );
			$by_collector[ $row['collector'] ] = array(
				'status' => $row['status'],
				'data'   => is_array( $decoded ) ? $decoded : array(),
			);
		}

		return $by_collector;
	}

	/**
	 * @param array<int,array<string,mixed>> $evidence_rows
	 */
	private function insert_evidence_rows( int $observation_id, array $evidence_rows ): void {
		global $wpdb;

		$table = Schema::table( 'evidence' );
		$now   = current_time( 'mysql', true );

		foreach ( $evidence_rows as $row ) {
			$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$table,
				array(
					'observation_id'    => $observation_id,
					'collector'         => $row['collector'],
					'collector_version' => $row['collector_version'],
					'status'            => $row['status'],
					'observed_at'       => gmdate( 'Y-m-d H:i:s', false !== strtotime( $row['observed_at'] ) ? strtotime( $row['observed_at'] ) : time() ),
					'source'            => $row['source'] ?? '',
					'duration_ms'       => $row['duration_ms'] ?? 0,
					'data'              => wp_json_encode( $row['data'] ?? array() ),
					'limitations'       => wp_json_encode( $row['limitations'] ?? array() ),
					'errors'            => wp_json_encode( $row['errors'] ?? array() ),
					'created_at'        => $now,
				)
			);
		}
	}

	private function delete_evidence_rows( int $observation_id ): void {
		global $wpdb;

		$table = Schema::table( 'evidence' );

		$wpdb->delete( $table, array( 'observation_id' => $observation_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}
