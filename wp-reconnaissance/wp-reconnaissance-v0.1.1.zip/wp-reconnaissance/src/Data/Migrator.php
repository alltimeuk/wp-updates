<?php
/**
 * Incremental, idempotent schema migrations driven by `dbDelta()`.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data;

use const Alltime\WPReconnaissance\WPR_SCHEMA_VERSION;

/**
 * Installs and upgrades the plugin's database schema.
 *
 * Each schema version is a self-contained, additive step. Steps never drop columns or tables;
 * destructive changes belong to an explicit, separately reviewed later migration.
 */
final class Migrator {

	private const SCHEMA_VERSION_OPTION = 'wpr_db_schema_version';

	/**
	 * Runs on activation. Applies every migration step up to the current schema version.
	 */
	public static function install(): void {
		self::maybe_upgrade();
	}

	/**
	 * Runs on every boot; a no-op unless the stored schema version is behind the current one,
	 * which covers plugin upgrades without a re-activation step.
	 */
	public static function maybe_upgrade(): void {
		$current = (int) get_option( self::SCHEMA_VERSION_OPTION, 0 );

		if ( $current >= WPR_SCHEMA_VERSION ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		for ( $version = $current + 1; $version <= WPR_SCHEMA_VERSION; $version++ ) {
			$method = "apply_version_{$version}";

			if ( method_exists( self::class, $method ) ) {
				self::$method();
			}

			update_option( self::SCHEMA_VERSION_OPTION, $version, true );
		}
	}

	/**
	 * Removes plugin tables and options. Only invoked from uninstall.php after an explicit
	 * administrator opt-in via the "wpr_remove_data_on_uninstall" option.
	 */
	public static function uninstall(): void {
		global $wpdb;

		// Drop in dependency order (children before parents).
		$drop_order = array( 'auth_tokens', 'finding_events', 'findings', 'evidence', 'observations', 'jobs', 'scopes', 'profiles', 'audit_log', 'organisations' );

		foreach ( $drop_order as $key ) {
			$table = Schema::table( $key );
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier (Schema::table()), never user input.
		}

		delete_option( self::SCHEMA_VERSION_OPTION );
		delete_option( 'wpr_local_adapter_enabled' );
		delete_option( 'wpr_remove_data_on_uninstall' );
	}

	/**
	 * Schema version 1: the Phase 1 core tables (organisations, scopes, profiles, jobs,
	 * observations, evidence, findings, finding_events, audit_log).
	 */
	private static function apply_version_1(): void {
		foreach ( Schema::version_1_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 2: the customer authentication token store (Section 18.1).
	 */
	private static function apply_version_2(): void {
		foreach ( Schema::version_2_statements() as $statement ) {
			dbDelta( $statement );
		}
	}
}
