<?php
/**
 * Table naming and dbDelta definitions for the Phase 1 core tables.
 *
 * Only the organisation/scope/job/observation/finding data model (Section 8) is defined here.
 * CRM, entitlement, remediation-task and mail tables are introduced by later migrations as
 * those modules are built, without altering the tables defined here.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data;

/**
 * Resolves prefixed table names and the dbDelta CREATE TABLE statements for schema version 1.
 */
final class Schema {

	/**
	 * @return array<string,string> Unprefixed table key => bare table name.
	 */
	public static function table_names(): array {
		return array(
			'organisations'  => 'wpr_organisations',
			'scopes'         => 'wpr_scopes',
			'profiles'       => 'wpr_profiles',
			'jobs'           => 'wpr_jobs',
			'observations'   => 'wpr_observations',
			'evidence'       => 'wpr_evidence',
			'findings'       => 'wpr_findings',
			'finding_events' => 'wpr_finding_events',
			'audit_log'      => 'wpr_audit_log',
			'auth_tokens'    => 'wpr_auth_tokens',
		);
	}

	/**
	 * Returns the fully prefixed table name.
	 */
	public static function table( string $key ): string {
		global $wpdb;

		$names = self::table_names();

		if ( ! isset( $names[ $key ] ) ) {
			throw new \InvalidArgumentException( esc_html( "Unknown WP-Reconnaissance table key: {$key}" ) );
		}

		return $wpdb->prefix . $names[ $key ];
	}

	/**
	 * Builds the dbDelta-compatible CREATE TABLE statements for schema version 1.
	 *
	 * @return string[]
	 */
	public static function version_1_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$statements      = array();

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_organisations (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			slug VARCHAR(191) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'active',
			primary_contact_id BIGINT UNSIGNED NULL,
			timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
			default_profile_id BIGINT UNSIGNED NULL,
			retention_policy VARCHAR(64) NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_profiles (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			organisation_id BIGINT UNSIGNED NULL,
			name VARCHAR(191) NOT NULL,
			enabled_collectors TEXT NOT NULL,
			collector_timeouts TEXT NULL,
			schedule VARCHAR(64) NULL,
			change_thresholds TEXT NULL,
			notification_rules TEXT NULL,
			rule_packs TEXT NULL,
			evidence_retention_days INT UNSIGNED NULL,
			max_lookalike_candidates INT UNSIGNED NOT NULL DEFAULT 500,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY organisation_id (organisation_id)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_scopes (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			organisation_id BIGINT UNSIGNED NOT NULL,
			name VARCHAR(191) NOT NULL,
			domain_ascii VARCHAR(253) NOT NULL,
			domain_display VARCHAR(253) NOT NULL,
			registrable_domain VARCHAR(253) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'pending',
			authorisation_status VARCHAR(32) NOT NULL DEFAULT 'pending',
			authorised_by BIGINT UNSIGNED NULL,
			authorisation_reference VARCHAR(191) NULL,
			authorised_from DATETIME NULL,
			authorised_until DATETIME NULL,
			permitted_collectors TEXT NULL,
			permitted_schedule VARCHAR(64) NULL,
			known_subdomains LONGTEXT NULL,
			known_dkim_selectors LONGTEXT NULL,
			expected_state LONGTEXT NULL,
			monitoring_profile_id BIGINT UNSIGNED NULL,
			notes TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY organisation_domain (organisation_id, domain_ascii),
			KEY registrable_domain (registrable_domain),
			KEY status (status)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_jobs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			job_uuid VARCHAR(64) NOT NULL,
			organisation_id BIGINT UNSIGNED NOT NULL,
			scope_id BIGINT UNSIGNED NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'pending',
			adapter VARCHAR(32) NULL,
			actor_id BIGINT UNSIGNED NULL,
			manifest_hash CHAR(64) NULL,
			worker_version VARCHAR(32) NULL,
			exit_code SMALLINT NULL,
			error_category VARCHAR(64) NULL,
			requested_at DATETIME NOT NULL,
			queued_at DATETIME NULL,
			started_at DATETIME NULL,
			completed_at DATETIME NULL,
			expires_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY job_uuid (job_uuid),
			KEY scope_id (scope_id),
			KEY organisation_id (organisation_id),
			KEY status (status)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_observations (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scope_id BIGINT UNSIGNED NOT NULL,
			job_id BIGINT UNSIGNED NOT NULL,
			observed_at DATETIME NOT NULL,
			collector_versions TEXT NULL,
			schema_version VARCHAR(16) NOT NULL,
			collection_status VARCHAR(32) NOT NULL,
			raw_evidence_ref VARCHAR(191) NULL,
			limitations TEXT NULL,
			failed_collectors TEXT NULL,
			integrity_hash CHAR(64) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY job_id (job_id),
			KEY scope_id (scope_id),
			KEY observed_at (observed_at)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_evidence (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			observation_id BIGINT UNSIGNED NOT NULL,
			collector VARCHAR(32) NOT NULL,
			collector_version VARCHAR(32) NOT NULL,
			status VARCHAR(32) NOT NULL,
			observed_at DATETIME NOT NULL,
			source VARCHAR(191) NULL,
			duration_ms INT UNSIGNED NULL,
			data LONGTEXT NULL,
			storage_ref VARCHAR(191) NULL,
			limitations TEXT NULL,
			errors TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY observation_id (observation_id),
			KEY collector (collector)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_findings (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			finding_uuid VARCHAR(64) NOT NULL,
			organisation_id BIGINT UNSIGNED NOT NULL,
			scope_id BIGINT UNSIGNED NOT NULL,
			rule_id VARCHAR(64) NOT NULL,
			rule_version VARCHAR(16) NOT NULL,
			title VARCHAR(191) NOT NULL,
			category VARCHAR(32) NOT NULL,
			severity VARCHAR(16) NOT NULL,
			confidence VARCHAR(16) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'new',
			first_observed_at DATETIME NOT NULL,
			last_observed_at DATETIME NOT NULL,
			resolved_at DATETIME NULL,
			evidence_refs TEXT NULL,
			expected_state LONGTEXT NULL,
			observed_state LONGTEXT NULL,
			risk_statement TEXT NULL,
			recommendation TEXT NULL,
			standards_references TEXT NULL,
			assigned_owner BIGINT UNSIGNED NULL,
			due_date DATE NULL,
			operator_notes TEXT NULL,
			suppression_reason TEXT NULL,
			suppression_expires_at DATETIME NULL,
			risk_accepted_by BIGINT UNSIGNED NULL,
			risk_accept_review_date DATE NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY finding_uuid (finding_uuid),
			KEY organisation_id (organisation_id),
			KEY scope_id (scope_id),
			KEY rule_id (rule_id),
			KEY status (status),
			KEY severity (severity)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_finding_events (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			finding_id BIGINT UNSIGNED NOT NULL,
			observation_id BIGINT UNSIGNED NULL,
			event_type VARCHAR(32) NOT NULL,
			actor_id BIGINT UNSIGNED NULL,
			summary TEXT NULL,
			occurred_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY finding_id (finding_id),
			KEY event_type (event_type),
			KEY occurred_at (occurred_at)
		) {$charset_collate};";

		$statements[] = "CREATE TABLE {$wpdb->prefix}wpr_audit_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			actor_id BIGINT UNSIGNED NULL,
			action VARCHAR(128) NOT NULL,
			object_type VARCHAR(64) NOT NULL,
			object_id BIGINT UNSIGNED NULL,
			source VARCHAR(32) NOT NULL DEFAULT 'admin',
			outcome VARCHAR(32) NOT NULL DEFAULT 'success',
			summary TEXT NULL,
			occurred_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY object_type_id (object_type, object_id),
			KEY action (action),
			KEY occurred_at (occurred_at)
		) {$charset_collate};";

		return $statements;
	}

	/**
	 * Schema version 2: the customer authentication token store (Section 18.1). Email
	 * verification and password-reset tokens share one table, distinguished by `type`; only
	 * the SHA-256 hash of each token is ever stored, never the raw value.
	 *
	 * @return string[]
	 */
	public static function version_2_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}wpr_auth_tokens (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				token_hash CHAR(64) NOT NULL,
				type VARCHAR(32) NOT NULL,
				expires_at DATETIME NOT NULL,
				used_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY user_id_type (user_id, type)
			) {$charset_collate};",
		);
	}
}
