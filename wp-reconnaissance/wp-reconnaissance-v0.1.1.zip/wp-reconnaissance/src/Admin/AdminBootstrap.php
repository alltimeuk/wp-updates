<?php
/**
 * Administrative interface bootstrap, per Section 19.
 *
 * Registers the principal admin screens (Overview, Organisations, Scopes, Jobs, Findings,
 * Reports, Settings). Screen rendering is intentionally minimal at this stage; the data-bearing
 * implementation for each screen lands with its owning module (Domain, Execution, Findings,
 * Reports).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Admin;

use Alltime\WPReconnaissance\Support\Capabilities;

final class AdminBootstrap {

	private const MENU_SLUG = 'wp-reconnaissance';

	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
	}

	public function register_menu(): void {
		add_menu_page(
			__( 'WP-Reconnaissance', 'wp-reconnaissance' ),
			__( 'Reconnaissance', 'wp-reconnaissance' ),
			Capabilities::VIEW_ALL_RESULTS,
			self::MENU_SLUG,
			array( $this, 'render_overview' ),
			'dashicons-shield',
			58
		);

		$screens = array(
			array( 'overview', __( 'Overview', 'wp-reconnaissance' ), Capabilities::VIEW_ALL_RESULTS, 'render_overview' ),
			array( 'organisations', __( 'Organisations', 'wp-reconnaissance' ), Capabilities::MANAGE_ORGANISATIONS, 'render_organisations' ),
			array( 'scopes', __( 'Scopes', 'wp-reconnaissance' ), Capabilities::MANAGE_SCOPES, 'render_scopes' ),
			array( 'jobs', __( 'Jobs', 'wp-reconnaissance' ), Capabilities::VIEW_ALL_RESULTS, 'render_jobs' ),
			array( 'findings', __( 'Findings', 'wp-reconnaissance' ), Capabilities::REVIEW_FINDINGS, 'render_findings' ),
			array( 'reports', __( 'Reports', 'wp-reconnaissance' ), Capabilities::ISSUE_REPORTS, 'render_reports' ),
			array( 'settings', __( 'Settings', 'wp-reconnaissance' ), Capabilities::MANAGE_SETTINGS, 'render_settings' ),
		);

		foreach ( $screens as [ $slug, $label, $capability, $callback ] ) {
			add_submenu_page(
				self::MENU_SLUG,
				$label,
				$label,
				$capability,
				self::MENU_SLUG . '-' . $slug,
				array( $this, $callback )
			);
		}

		remove_submenu_page( self::MENU_SLUG, self::MENU_SLUG );
	}

	public function render_overview(): void {
		$this->render_placeholder( __( 'Overview', 'wp-reconnaissance' ), Capabilities::VIEW_ALL_RESULTS );
	}

	public function render_organisations(): void {
		$this->render_placeholder( __( 'Organisations', 'wp-reconnaissance' ), Capabilities::MANAGE_ORGANISATIONS );
	}

	public function render_scopes(): void {
		$this->render_placeholder( __( 'Scopes', 'wp-reconnaissance' ), Capabilities::MANAGE_SCOPES );
	}

	public function render_jobs(): void {
		$this->render_placeholder( __( 'Jobs', 'wp-reconnaissance' ), Capabilities::VIEW_ALL_RESULTS );
	}

	public function render_findings(): void {
		$this->render_placeholder( __( 'Findings', 'wp-reconnaissance' ), Capabilities::REVIEW_FINDINGS );
	}

	public function render_reports(): void {
		$this->render_placeholder( __( 'Reports', 'wp-reconnaissance' ), Capabilities::ISSUE_REPORTS );
	}

	public function render_settings(): void {
		$this->render_placeholder( __( 'Settings', 'wp-reconnaissance' ), Capabilities::MANAGE_SETTINGS );
	}

	private function render_placeholder( string $title, string $capability ): void {
		if ( ! current_user_can( $capability ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		printf(
			'<div class="wrap"><h1>%s</h1><p>%s</p></div>',
			esc_html( $title ),
			esc_html__( 'This screen is part of the Phase 1 build and is not yet implemented.', 'wp-reconnaissance' )
		);
	}
}
