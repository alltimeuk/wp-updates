<?php
/**
 * Persistence for finding change events against `wpr_finding_events`, per Section 8.7.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\ChangeSignificance;

final class FindingEventRepository {

	public function record(
		int $finding_id,
		?int $observation_id,
		ChangeSignificance $event_type,
		?int $actor_id = null,
		?string $summary = null
	): void {
		global $wpdb;

		$table = Schema::table( 'finding_events' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'finding_id'     => $finding_id,
				'observation_id' => $observation_id,
				'event_type'     => $event_type->value,
				'actor_id'       => $actor_id,
				'summary'        => $summary,
				'occurred_at'    => current_time( 'mysql', true ),
			)
		);
	}
}
