<?php
/**
 * Persistence for findings against `wpr_findings`, per Section 8.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Enums\Severity;
use Alltime\WPReconnaissance\Domain\Finding;

final class FindingRepository {

	/**
	 * @return Finding[] Findings for a scope, most recently observed first.
	 */
	public function find_by_scope( int $scope_id, ?FindingStatus $status = null ): array {
		global $wpdb;

		$table = Schema::table( 'findings' );

		if ( null !== $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM `{$table}` WHERE scope_id = %d AND status = %s ORDER BY last_observed_at DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$scope_id,
					$status->value
				),
				ARRAY_A
			);
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM `{$table}` WHERE scope_id = %d ORDER BY last_observed_at DESC", $scope_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				ARRAY_A
			);
		}

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Finds the current (non-resolved) finding for a rule within a scope, used by the change
	 * engine to decide whether an evaluation result is new, unchanged or a re-observation of an
	 * existing finding.
	 */
	public function find_open_by_rule( int $scope_id, string $rule_id ): ?Finding {
		global $wpdb;

		$table = Schema::table( 'findings' );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE scope_id = %d AND rule_id = %s AND status NOT IN ('resolved','false_positive') ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scope_id,
				$rule_id
			),
			ARRAY_A
		);

		return null !== $row ? $this->hydrate( $row ) : null;
	}

	/**
	 * Finds the most recent finding for a rule within a scope regardless of status, used by
	 * the change engine to distinguish a genuinely new finding from a previously resolved one
	 * recurring (Reopened) versus a currently-open one changing (Modified).
	 */
	public function find_latest_by_rule( int $scope_id, string $rule_id ): ?Finding {
		global $wpdb;

		$table = Schema::table( 'findings' );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE scope_id = %d AND rule_id = %s ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scope_id,
				$rule_id
			),
			ARRAY_A
		);

		return null !== $row ? $this->hydrate( $row ) : null;
	}

	public function save( Finding $finding ): Finding {
		global $wpdb;

		$table = Schema::table( 'findings' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'finding_uuid'           => $finding->finding_uuid,
			'organisation_id'        => $finding->organisation_id,
			'scope_id'               => $finding->scope_id,
			'rule_id'                => $finding->rule_id,
			'rule_version'           => $finding->rule_version,
			'title'                  => $finding->title,
			'category'               => $finding->category,
			'severity'               => $finding->severity->value,
			'confidence'             => $finding->confidence->value,
			'status'                 => $finding->status->value,
			'first_observed_at'      => $finding->first_observed_at->format( 'Y-m-d H:i:s' ),
			'last_observed_at'       => $finding->last_observed_at->format( 'Y-m-d H:i:s' ),
			'resolved_at'            => $finding->resolved_at?->format( 'Y-m-d H:i:s' ),
			'evidence_refs'          => wp_json_encode( $finding->evidence_refs ),
			'expected_state'         => wp_json_encode( $finding->expected_state ),
			'observed_state'         => wp_json_encode( $finding->observed_state ),
			'risk_statement'         => $finding->risk_statement,
			'recommendation'         => $finding->recommendation,
			'standards_references'   => wp_json_encode( $finding->standards_references ),
			'assigned_owner'         => $finding->assigned_owner,
			'due_date'               => $finding->due_date?->format( 'Y-m-d' ),
			'operator_notes'         => $finding->operator_notes,
			'suppression_reason'     => $finding->suppression_reason,
			'suppression_expires_at' => $finding->suppression_expires_at?->format( 'Y-m-d H:i:s' ),
			'updated_at'             => $now,
		);

		if ( null === $finding->id ) {
			$data['created_at'] = $now;
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			return $this->hydrate( array_merge( $data, array( 'id' => $wpdb->insert_id ) ) );
		}

		$wpdb->update( $table, $data, array( 'id' => $finding->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->hydrate( array_merge( $data, array( 'id' => $finding->id ) ) );
	}

	/**
	 * @param array<string,mixed> $row
	 */
	private function hydrate( array $row ): Finding {
		return new Finding(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			finding_uuid: (string) $row['finding_uuid'],
			organisation_id: (int) $row['organisation_id'],
			scope_id: (int) $row['scope_id'],
			rule_id: (string) $row['rule_id'],
			rule_version: (string) $row['rule_version'],
			title: (string) $row['title'],
			category: (string) $row['category'],
			severity: Severity::from( (string) $row['severity'] ),
			confidence: Confidence::from( (string) $row['confidence'] ),
			status: FindingStatus::from( (string) $row['status'] ),
			first_observed_at: new \DateTimeImmutable( (string) $row['first_observed_at'] ),
			last_observed_at: new \DateTimeImmutable( (string) $row['last_observed_at'] ),
			resolved_at: ! empty( $row['resolved_at'] ) ? new \DateTimeImmutable( (string) $row['resolved_at'] ) : null,
			evidence_refs: self::decode( $row['evidence_refs'] ?? null ),
			expected_state: self::decode( $row['expected_state'] ?? null ),
			observed_state: self::decode( $row['observed_state'] ?? null ),
			risk_statement: $row['risk_statement'] ?? null,
			recommendation: $row['recommendation'] ?? null,
			standards_references: self::decode( $row['standards_references'] ?? null ),
			assigned_owner: isset( $row['assigned_owner'] ) ? (int) $row['assigned_owner'] : null,
			due_date: ! empty( $row['due_date'] ) ? new \DateTimeImmutable( (string) $row['due_date'] ) : null,
			operator_notes: $row['operator_notes'] ?? null,
			suppression_reason: $row['suppression_reason'] ?? null,
			suppression_expires_at: ! empty( $row['suppression_expires_at'] ) ? new \DateTimeImmutable( (string) $row['suppression_expires_at'] ) : null
		);
	}

	/**
	 * @return array<int|string,mixed>
	 */
	private static function decode( mixed $json ): array {
		if ( ! is_string( $json ) || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}
}
