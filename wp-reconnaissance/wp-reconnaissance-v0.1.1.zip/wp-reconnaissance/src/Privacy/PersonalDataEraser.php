<?php
/**
 * Core personal-data erasure callback, per Section 26.
 *
 * The right to erasure is not absolute: retention, suppression and legal-hold records may
 * still be required (Section 26.4), so this must apply the same retention rules as the
 * administrative rights-request workflow rather than deleting unconditionally. Not yet
 * implemented - depends on the customer/organisation/lead tables added by later Phase 1 work.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

final class PersonalDataEraser {

	/**
	 * @return array{items_removed: bool, items_retained: bool, messages: string[], done: bool}
	 */
	public static function erase( string $email_address, int $page = 1 ): array {
		return array(
			'items_removed'  => false,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}
}
