<?php
/**
 * Core personal-data export callback, per Section 26.
 *
 * Must locate linked data across custom tables (leads, findings' assigned owners, audit log
 * actor references) and protected files (raw evidence), not only WordPress core user data.
 * Not yet implemented - the customer/organisation/lead tables this will query are added by
 * later Phase 1 work.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

final class PersonalDataExporter {

	/**
	 * @return array{data: array<int,array<string,mixed>>, done: bool}
	 */
	public static function export( string $email_address, int $page = 1 ): array {
		return array(
			'data' => array(),
			'done' => true,
		);
	}
}
