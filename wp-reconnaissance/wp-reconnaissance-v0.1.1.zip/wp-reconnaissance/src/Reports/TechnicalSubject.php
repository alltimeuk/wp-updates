<?php
/**
 * Technical-subject taxonomy for grouping remediation tasks, per Section 21.4.
 *
 * Findings group by technical subject, not by DNS domain name.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

enum TechnicalSubject: string {
	case DomainRegistration    = 'domain_registration_and_ownership';
	case DnsArchitecture       = 'dns_architecture_and_resilience';
	case EmailAuthentication   = 'email_authentication_and_deliverability';
	case WebTransportTls       = 'web_transport_and_tls_pki';
	case WebSecurityHeaders    = 'web_security_headers_and_browser_controls';
	case AssetGovernance       = 'public_asset_and_subdomain_governance';
	case BrandProtection       = 'brand_protection_and_lookalike_domains';
	case OperationalGovernance = 'monitoring_ownership_and_operational_governance';
}
