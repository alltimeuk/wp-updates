<?php
/**
 * Remediation-plan priority bands, per Section 21.5.
 *
 * Bands are the output of the prioritisation algorithm (severity, confidence, applicability,
 * exposure, dependency order, urgency, enablement, trend) - never a direct re-labelling of
 * severity alone.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

enum PriorityBand: string {
	case Immediate   = 'P1';
	case High        = 'P2';
	case Planned     = 'P3';
	case Improvement = 'P4';
}
