<?php
/**
 * Contract for generating an immutable, versioned report from a reviewed observation and its
 * findings, per Section 21.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

interface ReportGeneratorInterface {

	/**
	 * Generates a new report document (see `schemas/report.schema.json`) for a scope's latest
	 * reviewed observation. A correction to an issued report must call this again to create a
	 * new version rather than mutating the existing one.
	 *
	 * @return array<string,mixed> A document conforming to schemas/report.schema.json.
	 */
	public function generate( int $scope_id ): array;
}
