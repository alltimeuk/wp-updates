<?php
/**
 * Result of dispatching a job manifest to an execution adapter.
 *
 * The evidence payload is treated as untrusted until it has been schema-validated by the
 * ingestion pipeline; this object only carries it, it does not interpret it.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Execution;

final class ExecutionResult {

	public function __construct(
		public readonly bool $accepted,
		public readonly ?int $exit_code,
		public readonly ?string $evidence_json,
		public readonly ?string $stderr,
		public readonly ?string $error_category = null
	) {}

	public static function accepted_pending(): self {
		return new self( accepted: true, exit_code: null, evidence_json: null, stderr: null );
	}
}
