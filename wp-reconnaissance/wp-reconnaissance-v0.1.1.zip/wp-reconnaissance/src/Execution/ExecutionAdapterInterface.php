<?php
/**
 * Contract for supplying a job manifest to a collection worker, per Section 6.3.
 *
 * Two adapters are required: a same-server local process adapter (disabled by default) and a
 * remote HTTPS worker adapter whose interface is defined in Phase 1 even though the worker
 * deployment follows in Phase 2/3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Execution;

use Alltime\WPReconnaissance\Execution\Exceptions\ExecutionException;

interface ExecutionAdapterInterface {

	/**
	 * Dispatches a manifest to the worker. Must never construct a shell string from any
	 * manifest field; the manifest is passed as a file or request body only.
	 *
	 * @throws ExecutionException When the adapter cannot dispatch the job at all (configuration,
	 *                            connectivity, or a safety precondition failure). A worker-side
	 *                            collection failure is not an ExecutionException - it is a
	 *                            normal ExecutionResult with a failed/timed_out status.
	 */
	public function dispatch( JobManifest $manifest ): ExecutionResult;

	/**
	 * Requests cancellation of an in-flight job. Best-effort: the adapter may not be able to
	 * guarantee immediate termination.
	 */
	public function cancel( string $job_id ): void;

	/**
	 * Whether this adapter is currently configured and safe to use (e.g. the local adapter
	 * reports false until an administrator has validated the worker path).
	 */
	public function is_ready(): bool;
}
