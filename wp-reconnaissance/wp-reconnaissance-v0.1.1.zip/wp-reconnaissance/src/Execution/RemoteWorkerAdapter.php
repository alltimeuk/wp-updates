<?php
/**
 * Remote worker execution adapter, per Section 6.3 (adapter 2) and the Section 17 interface.
 *
 * The interface is defined in Phase 1; full remote-worker deployment (containerised worker,
 * signed job API, tenant/concurrency limits) is Phase 3 scope. This class currently reports
 * itself not ready and fails safely rather than silently no-op'ing.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Execution;

use Alltime\WPReconnaissance\Execution\Exceptions\ExecutionException;

final class RemoteWorkerAdapter implements ExecutionAdapterInterface {

	public function is_ready(): bool {
		// Deliberately always false until the Phase 3 remote worker is implemented: signed
		// request construction, replay protection and result-signature verification are not
		// yet built, so this adapter must not be selectable in production.
		return false;
	}

	public function dispatch( JobManifest $manifest ): ExecutionResult {
		throw new ExecutionException( 'The remote worker adapter is not yet implemented (Phase 3). Use the local process adapter or wait for the remote worker release.' );
	}

	public function cancel( string $job_id ): void {
		throw new ExecutionException( 'The remote worker adapter is not yet implemented (Phase 3).' );
	}
}
