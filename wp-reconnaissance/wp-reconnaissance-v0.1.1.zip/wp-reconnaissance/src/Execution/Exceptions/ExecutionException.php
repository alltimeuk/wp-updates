<?php
/**
 * Thrown by an execution adapter when a job cannot be dispatched, or by the manifest builder
 * when a manifest cannot be safely constructed.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Execution\Exceptions;

class ExecutionException extends \RuntimeException {}
