<?php
/**
 * Local process execution adapter, per Section 6.3 (adapter 1) and the mandatory controls in
 * Section 16.
 *
 * High risk by design: it invokes a PHP CLI binary on the same trusted server to run the
 * collection worker (worker/collect.php) as a separate process. Disabled by default via the
 * "wpr_local_adapter_enabled" option until an administrator has validated the executable and
 * worker paths through Site Health.
 *
 * The worker is deliberately run as its own OS process rather than called in-process as a PHP
 * class, even though both now run the same language: this preserves process isolation (a
 * worker crash, timeout or runaway memory use cannot take the web request down with it) and
 * lets it run under its own CLI php.ini limits, independent of the web SAPI's.
 *
 * This adapter must only ever be invoked from a background execution context (Action Scheduler
 * task), never directly from an HTTP admin request - Section 15 requires PHP web requests to
 * stay short.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Execution;

use Alltime\WPReconnaissance\Execution\Exceptions\ExecutionException;

final class LocalProcessAdapter implements ExecutionAdapterInterface {

	private const DEFAULT_MAX_EXECUTION_SECONDS = 120;
	private const DEFAULT_MAX_OUTPUT_BYTES      = 10 * 1024 * 1024; // 10 MiB.

	public function is_ready(): bool {
		if ( ! (bool) get_option( 'wpr_local_adapter_enabled', false ) ) {
			return false;
		}

		$php_binary_path = (string) get_option( 'wpr_php_binary_path', '' );
		$worker_path     = (string) get_option( 'wpr_worker_script_path', '' );

		return '' !== $php_binary_path
			&& '' !== $worker_path
			&& $this->is_safe_executable( $php_binary_path )
			&& $this->is_safe_worker_script( $worker_path );
	}

	public function dispatch( JobManifest $manifest ): ExecutionResult {
		if ( ! $this->is_ready() ) {
			throw new ExecutionException( 'Local process adapter is not enabled or not correctly configured.' );
		}

		if ( $manifest->expires_at < new \DateTimeImmutable() ) {
			throw new ExecutionException( 'Manifest has already expired; refusing to dispatch.' );
		}

		$work_dir = $this->create_job_working_directory( $manifest->job_id );

		try {
			return $this->run( $manifest, $work_dir );
		} finally {
			$this->cleanup_working_directory( $work_dir );
		}
	}

	public function cancel( string $job_id ): void {
		// Best-effort: requires a persisted PID registry keyed by job_id, owned by the job
		// runner rather than this stateless adapter. Intentionally not implemented in Phase 1;
		// abandoned-job detection (Section 15) reclaims stalled jobs on a timeout instead.
		do_action( 'wpr_local_adapter_cancel_requested', $job_id );
	}

	private function run( JobManifest $manifest, string $work_dir ): ExecutionResult {
		$php_binary_path = (string) get_option( 'wpr_php_binary_path', '' );
		$worker_path     = (string) get_option( 'wpr_worker_script_path', '' );
		$manifest_file   = $work_dir . DIRECTORY_SEPARATOR . 'manifest.json';

		if ( false === file_put_contents( $manifest_file, $manifest->to_json(), LOCK_EX ) ) {
			throw new ExecutionException( 'Unable to write job manifest to the worker working directory.' );
		}

		chmod( $manifest_file, 0600 );

		// Argument array: proc_open never builds a shell string, so no manifest field - or any
		// other value here - can alter command construction regardless of its content.
		$command = array(
			$php_binary_path,
			$worker_path,
			'--manifest',
			$manifest_file,
		);

		$descriptors = array(
			0 => array( 'pipe', 'r' ),
			1 => array( 'pipe', 'w' ),
			2 => array( 'pipe', 'w' ),
		);

		$process = proc_open( $command, $descriptors, $pipes, $work_dir, null, array( 'bypass_shell' => true ) );

		if ( ! is_resource( $process ) ) {
			throw new ExecutionException( 'Unable to start the collection worker process.' );
		}

		fclose( $pipes[0] );
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );

		$max_seconds      = (int) get_option( 'wpr_worker_max_execution_seconds', self::DEFAULT_MAX_EXECUTION_SECONDS );
		$max_output_bytes = (int) get_option( 'wpr_worker_max_output_bytes', self::DEFAULT_MAX_OUTPUT_BYTES );

		[ $stdout, $stderr, $exit_code, $error_category ] = $this->wait_for_completion( $process, $pipes, $max_seconds, $max_output_bytes );

		if ( 0 !== $exit_code || null !== $error_category ) {
			return new ExecutionResult(
				accepted: true,
				exit_code: $exit_code,
				evidence_json: null,
				stderr: $stderr,
				error_category: $error_category ?? 'worker_nonzero_exit'
			);
		}

		return new ExecutionResult(
			accepted: true,
			exit_code: $exit_code,
			evidence_json: $stdout,
			stderr: $stderr
		);
	}

	/**
	 * @param resource            $process
	 * @param array<int,resource> $pipes
	 * @return array{0:string,1:string,2:?int,3:?string}
	 */
	private function wait_for_completion( $process, array $pipes, int $max_seconds, int $max_output_bytes ): array {
		$stdout         = '';
		$stderr         = '';
		$started        = microtime( true );
		$error_category = null;

		while ( true ) {
			$status = proc_get_status( $process );

			$stdout .= (string) stream_get_contents( $pipes[1] );
			$stderr .= (string) stream_get_contents( $pipes[2] );

			if ( strlen( $stdout ) > $max_output_bytes ) {
				proc_terminate( $process, 9 );
				$error_category = 'output_size_exceeded';
				break;
			}

			if ( ! $status['running'] ) {
				break;
			}

			if ( ( microtime( true ) - $started ) > $max_seconds ) {
				proc_terminate( $process, 9 );
				$error_category = 'execution_timeout';
				break;
			}

			usleep( 100000 );
		}

		// proc_get_status() always returns an 'exitcode' key (-1 while still running or once
		// already reaped), so this is never null - kept as a plain int, not a `??` fallback.
		$exit_code = $status['exitcode'];

		fclose( $pipes[1] );
		fclose( $pipes[2] );
		proc_close( $process );

		return array( $stdout, $stderr, $exit_code, $error_category );
	}

	private function create_job_working_directory( string $job_id ): string {
		$base = trailingslashit( (string) get_option( 'wpr_worker_work_dir', sys_get_temp_dir() ) ) . 'wpr-jobs';

		if ( ! is_dir( $base ) ) {
			wp_mkdir_p( $base );
		}

		$dir = $base . DIRECTORY_SEPARATOR . preg_replace( '/[^A-Za-z0-9._-]/', '', $job_id ) . '-' . wp_generate_password( 12, false );

		if ( ! wp_mkdir_p( $dir ) ) {
			throw new ExecutionException( 'Unable to create a working directory for the collection job.' );
		}

		chmod( $dir, 0700 );

		return $dir;
	}

	private function cleanup_working_directory( string $dir ): void {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$files = glob( $dir . DIRECTORY_SEPARATOR . '*' );

		foreach ( false !== $files ? $files : array() as $file ) {
			if ( is_file( $file ) ) {
				unlink( $file );
			}
		}

		rmdir( $dir );
	}

	private function is_safe_executable( string $path ): bool {
		return '' !== $path && is_file( $path ) && is_executable( $path ) && ! str_contains( $path, '..' );
	}

	private function is_safe_worker_script( string $path ): bool {
		return '' !== $path && is_file( $path ) && ! str_contains( $path, '..' ) && str_ends_with( strtolower( $path ), '.php' );
	}
}
