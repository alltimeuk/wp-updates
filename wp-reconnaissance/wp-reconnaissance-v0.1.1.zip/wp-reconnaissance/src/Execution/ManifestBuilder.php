<?php
/**
 * Builds an immutable {@see JobManifest} from an authorised scope and its monitoring profile.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Execution;

use Alltime\WPReconnaissance\Domain\MonitoringProfile;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Execution\Exceptions\ExecutionException;

final class ManifestBuilder {

	private const DEFAULT_TTL_SECONDS = 900;

	/**
	 * @throws ExecutionException When the scope is not currently authorised for collection.
	 *                            Section 16 requires this check to happen again at dispatch
	 *                            time, not only at scope-creation time.
	 */
	public function build( Scope $scope, MonitoringProfile $profile, string $job_id, ?\DateTimeImmutable $now = null ): JobManifest {
		$now = $now ?? new \DateTimeImmutable();

		if ( ! $scope->is_currently_authorised( $now ) ) {
			throw new ExecutionException( 'Scope authorisation is missing or has expired; refusing to build a job manifest.' );
		}

		$collectors = array_values( array_intersect( $scope->permitted_collectors, $profile->enabled_collectors ) );

		if ( empty( $collectors ) ) {
			throw new ExecutionException( 'No collectors are both permitted for this scope and enabled on its monitoring profile.' );
		}

		return new JobManifest(
			job_id: $job_id,
			issued_at: $now,
			expires_at: $now->modify( '+' . self::DEFAULT_TTL_SECONDS . ' seconds' ),
			domain: $scope->domain_ascii,
			registrable_domain: $scope->registrable_domain,
			scope_id: (int) $scope->id,
			authorisation_reference: (string) $scope->authorisation_reference,
			collectors: $collectors,
			known_dkim_selectors: $scope->known_dkim_selectors,
			common_subdomains: $scope->known_subdomains,
			timeouts_seconds: $profile->collector_timeouts,
			max_lookalike_candidates: $profile->max_lookalike_candidates
		);
	}
}
