<?php
/**
 * Immutable job manifest, per Section 10.
 *
 * The manifest is the only channel through which scope and collector configuration reaches the
 * worker. It is serialised to a file/stdin payload - never interpolated into a shell command.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Execution;

final class JobManifest {

	public const SCHEMA_VERSION = '1.0.0';

	/**
	 * @param string[]          $collectors
	 * @param string[]          $known_dkim_selectors
	 * @param string[]          $common_subdomains
	 * @param array<string,int> $timeouts_seconds
	 */
	public function __construct(
		public readonly string $job_id,
		public readonly \DateTimeImmutable $issued_at,
		public readonly \DateTimeImmutable $expires_at,
		public readonly string $domain,
		public readonly string $registrable_domain,
		public readonly int $scope_id,
		public readonly string $authorisation_reference,
		public readonly array $collectors,
		public readonly array $known_dkim_selectors = array(),
		public readonly array $common_subdomains = array(),
		public readonly array $timeouts_seconds = array(),
		public readonly int $max_lookalike_candidates = 500,
		public readonly string $callback_mode = 'file'
	) {}

	/**
	 * @return array<string,mixed>
	 */
	public function to_array(): array {
		return array(
			'schema_version' => self::SCHEMA_VERSION,
			'job_id'         => $this->job_id,
			'issued_at'      => $this->issued_at->format( \DateTimeInterface::ATOM ),
			'expires_at'     => $this->expires_at->format( \DateTimeInterface::ATOM ),
			'scope'          => array(
				'domain'             => $this->domain,
				'registrable_domain' => $this->registrable_domain,
			),
			'authorisation'  => array(
				'scope_id'  => $this->scope_id,
				'reference' => $this->authorisation_reference,
			),
			'profile'        => array(
				'collectors'               => array_values( $this->collectors ),
				'known_dkim_selectors'     => array_values( $this->known_dkim_selectors ),
				'common_subdomains'        => array_values( $this->common_subdomains ),
				'timeouts_seconds'         => $this->timeouts_seconds,
				'max_lookalike_candidates' => $this->max_lookalike_candidates,
			),
			'callback'       => array(
				'mode' => $this->callback_mode,
			),
		);
	}

	public function to_json(): string {
		return (string) wp_json_encode( $this->to_array(), JSON_UNESCAPED_SLASHES );
	}
}
