<?php
/**
 * Contract for registrable-domain resolution against a maintained Public Suffix List.
 *
 * Section 12.1 requires a maintained PSL rather than ad hoc suffix guessing. The default
 * implementation ships a small, explicitly-labelled fallback list; production deployments
 * should provide an implementation backed by a periodically refreshed PSL data file (e.g.
 * https://publicsuffix.org/list/public_suffix_list.dat) via this interface.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

interface PublicSuffixListInterface {

	/**
	 * Returns the registrable domain (public suffix plus one label) for a canonical ASCII
	 * (IDNA) domain, or null if no rule matches.
	 */
	public function registrable_domain( string $ascii_domain ): ?string;
}
