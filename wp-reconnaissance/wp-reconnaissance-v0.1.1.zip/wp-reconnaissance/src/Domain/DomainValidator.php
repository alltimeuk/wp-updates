<?php
/**
 * Canonicalises and validates a customer- or operator-supplied scope domain, per Section 8.2
 * and the corrections required by Section 12.1.
 *
 * Rejects IP literals, URLs, paths, wildcard-only values, shell syntax and malformed
 * internationalised domains before any value reaches the collection worker or a database query.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

use Alltime\WPReconnaissance\Domain\Exceptions\InvalidDomainException;

final class DomainValidator {

	/** Characters that must never appear in a scope domain; a strong signal of shell/URL injection attempts. */
	private const FORBIDDEN_CHARACTERS = array( '/', '\\', ' ', "\t", "\n", "\r", ';', '|', '&', '$', '`', '(', ')', '<', '>', '"', "'", '%', '#', '?', '@', ':' );

	private const MAX_LENGTH = 253;

	public function __construct(
		private readonly PublicSuffixListInterface $public_suffix_list = new FallbackPublicSuffixList()
	) {}

	/**
	 * @throws InvalidDomainException When the input cannot be canonicalised into a safe,
	 *                                 authorisable scope domain.
	 */
	public function validate( string $raw ): ValidatedDomain {
		$candidate = trim( $raw );

		if ( '' === $candidate ) {
			throw new InvalidDomainException( 'Domain must not be empty.' );
		}

		if ( str_contains( $candidate, '://' ) ) {
			throw new InvalidDomainException( 'Domain must not include a URL scheme.' );
		}

		foreach ( self::FORBIDDEN_CHARACTERS as $character ) {
			if ( str_contains( $candidate, $character ) ) {
				throw new InvalidDomainException( 'Domain contains a disallowed character.' );
			}
		}

		if ( strlen( $candidate ) > self::MAX_LENGTH ) {
			throw new InvalidDomainException( 'Domain exceeds the maximum permitted length.' );
		}

		$candidate = rtrim( $candidate, '.' );

		if ( false !== filter_var( trim( $candidate, '[]' ), FILTER_VALIDATE_IP ) ) {
			throw new InvalidDomainException( 'IP literals are not permitted as an authorised scope; supply a domain name.' );
		}

		$labels = explode( '.', $candidate );

		if ( count( $labels ) < 2 ) {
			throw new InvalidDomainException( 'Domain must include at least a label and a top-level domain.' );
		}

		foreach ( $labels as $label ) {
			if ( '' === $label || '*' === $label ) {
				throw new InvalidDomainException( 'Wildcard-only or empty labels are not permitted in an authorised scope domain.' );
			}
		}

		$ascii = $this->to_ascii( $candidate );

		if ( ! preg_match( '/^(?:[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i', $ascii ) ) {
			throw new InvalidDomainException( 'Domain failed canonical ASCII (IDNA) validation.' );
		}

		$registrable = $this->public_suffix_list->registrable_domain( $ascii );

		if ( null === $registrable ) {
			throw new InvalidDomainException( 'Unable to determine a registrable domain for this scope; a public suffix alone is not an authorisable scope.' );
		}

		return new ValidatedDomain(
			ascii: $ascii,
			display: $this->to_display( $ascii ),
			registrable: $registrable
		);
	}

	private function to_ascii( string $candidate ): string {
		if ( function_exists( 'idn_to_ascii' ) ) {
			$ascii = idn_to_ascii( $candidate, IDNA_NONTRANSITIONAL_TO_ASCII | IDNA_USE_STD3_RULES, INTL_IDNA_VARIANT_UTS46 );

			if ( false === $ascii ) {
				throw new InvalidDomainException( 'Domain contains malformed internationalised characters.' );
			}

			return strtolower( $ascii );
		}

		if ( ! mb_check_encoding( $candidate, 'ASCII' ) ) {
			throw new InvalidDomainException( 'The intl extension is required to validate internationalised domain names.' );
		}

		return strtolower( $candidate );
	}

	private function to_display( string $ascii ): string {
		if ( ! function_exists( 'idn_to_utf8' ) ) {
			return $ascii;
		}

		$display = idn_to_utf8( $ascii, IDNA_NONTRANSITIONAL_TO_ASCII | IDNA_USE_STD3_RULES, INTL_IDNA_VARIANT_UTS46 );

		return false !== $display ? $display : $ascii;
	}
}
