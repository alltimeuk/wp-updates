<?php
/**
 * Thrown when scope input fails canonicalisation or authorised-scope validation.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Exceptions;

final class InvalidDomainException extends \InvalidArgumentException {}
