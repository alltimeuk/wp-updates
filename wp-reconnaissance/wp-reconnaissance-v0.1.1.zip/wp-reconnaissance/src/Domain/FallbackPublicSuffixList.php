<?php
/**
 * Minimal placeholder Public Suffix List covering common multi-label suffixes.
 *
 * This is NOT a substitute for a maintained PSL. It exists so the plugin has correct behaviour
 * for common cases (including UK second-level domains such as .co.uk, which the current engine
 * gets wrong per Section 12.1) out of the box, while defaulting to "last two labels" for
 * everything else. Replace this implementation via `PublicSuffixListInterface` before relying
 * on it for less common suffixes.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

final class FallbackPublicSuffixList implements PublicSuffixListInterface {

	/**
	 * Multi-label public suffixes that are not simply "one label + TLD".
	 *
	 * @var string[]
	 */
	private const KNOWN_MULTI_LABEL_SUFFIXES = array(
		'co.uk',
		'org.uk',
		'me.uk',
		'net.uk',
		'ltd.uk',
		'plc.uk',
		'sch.uk',
		'ac.uk',
		'gov.uk',
		'nhs.uk',
		'police.uk',
		'com.au',
		'net.au',
		'org.au',
		'edu.au',
		'gov.au',
		'co.nz',
		'net.nz',
		'org.nz',
		'govt.nz',
		'co.za',
		'org.za',
		'gov.za',
		'com.br',
		'com.cn',
		'com.mx',
		'com.sg',
		'com.hk',
		'com.tw',
		'co.jp',
		'co.in',
		'co.il',
		'co.kr',
	);

	public function registrable_domain( string $ascii_domain ): ?string {
		$labels = explode( '.', strtolower( trim( $ascii_domain, '.' ) ) );

		if ( count( $labels ) < 2 ) {
			return null;
		}

		$last_two   = implode( '.', array_slice( $labels, -2 ) );
		$last_three = count( $labels ) >= 3 ? implode( '.', array_slice( $labels, -3 ) ) : null;

		if ( in_array( $last_two, self::KNOWN_MULTI_LABEL_SUFFIXES, true ) ) {
			// The input is exactly a known multi-label public suffix (e.g. "co.uk") with no
			// registrable label in front of it - it is a suffix, not an authorisable domain.
			return $last_three;
		}

		return $last_two;
	}
}
