<?php
/**
 * Finding entity, per Section 8.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Enums\Severity;

final class Finding {

	/**
	 * @param string[]                                               $evidence_refs
	 * @param array<string,mixed>                                    $expected_state
	 * @param array<string,mixed>                                    $observed_state
	 * @param array<int,array{reference:string,relationship:string}> $standards_references
	 */
	public function __construct(
		public readonly ?int $id,
		public readonly string $finding_uuid,
		public readonly int $organisation_id,
		public readonly int $scope_id,
		public readonly string $rule_id,
		public readonly string $rule_version,
		public readonly string $title,
		public readonly string $category,
		public readonly Severity $severity,
		public readonly Confidence $confidence,
		public readonly FindingStatus $status,
		public readonly \DateTimeImmutable $first_observed_at,
		public readonly \DateTimeImmutable $last_observed_at,
		public readonly ?\DateTimeImmutable $resolved_at,
		public readonly array $evidence_refs,
		public readonly array $expected_state,
		public readonly array $observed_state,
		public readonly ?string $risk_statement,
		public readonly ?string $recommendation,
		public readonly array $standards_references,
		public readonly ?int $assigned_owner,
		public readonly ?\DateTimeImmutable $due_date,
		public readonly ?string $operator_notes,
		public readonly ?string $suppression_reason,
		public readonly ?\DateTimeImmutable $suppression_expires_at
	) {}

	/**
	 * A finding may only be exposed as "confirmed" when the underlying evidence directly
	 * supports the conclusion; enforced here as a structural guard rather than left to callers.
	 */
	public function is_confirmable(): bool {
		return Confidence::Confirmed !== $this->confidence || ! empty( $this->evidence_refs );
	}
}
