<?php
/**
 * Change event entity, per Section 8.7.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

use Alltime\WPReconnaissance\Domain\Enums\ChangeSignificance;

final class ChangeEvent {

	public function __construct(
		public readonly ?int $id,
		public readonly int $finding_id,
		public readonly ?int $observation_id,
		public readonly ChangeSignificance $event_type,
		public readonly ?int $actor_id,
		public readonly ?string $summary,
		public readonly \DateTimeImmutable $occurred_at
	) {}
}
