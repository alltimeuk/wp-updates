<?php
/**
 * Finding confidence, per Section 13.2. `Confirmed` requires evidence that directly supports
 * the conclusion - a guessed DKIM selector, a failed network request or a resolving lookalike
 * domain can never justify it.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum Confidence: string {
	case Low       = 'low';
	case Medium    = 'medium';
	case High      = 'high';
	case Confirmed = 'confirmed';
}
