<?php
/**
 * Finding severity, per Section 13.1. Reflects plausible impact and context, not a count of
 * missing controls.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum Severity: string {
	case Informational = 'informational';
	case Low           = 'low';
	case Medium        = 'medium';
	case High          = 'high';
	case Critical      = 'critical';

	public function rank(): int {
		return match ( $this ) {
			self::Informational => 0,
			self::Low => 1,
			self::Medium => 2,
			self::High => 3,
			self::Critical => 4,
		};
	}
}
