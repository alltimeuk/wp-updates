<?php
/**
 * Job lifecycle states, per Section 8.4.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum JobStatus: string {
	case Pending            = 'pending';
	case Authorised         = 'authorised';
	case Queued             = 'queued';
	case Running            = 'running';
	case Succeeded          = 'succeeded';
	case PartiallySucceeded = 'partially_succeeded';
	case Failed             = 'failed';
	case Cancelled          = 'cancelled';
	case Expired            = 'expired';

	public function is_terminal(): bool {
		return match ( $this ) {
			self::Succeeded, self::PartiallySucceeded, self::Failed, self::Cancelled, self::Expired => true,
			default => false,
		};
	}
}
