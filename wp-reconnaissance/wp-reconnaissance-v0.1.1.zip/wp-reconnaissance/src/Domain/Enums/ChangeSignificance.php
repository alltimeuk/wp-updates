<?php
/**
 * Change-event classifications, per Section 8.7.
 *
 * Record order, TTL alone or JSON property order must never be treated as material unless a
 * rule explicitly requires it - callers should only ever construct this enum from a rule's
 * deliberate comparison outcome.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum ChangeSignificance: string {
	case Added                 = 'added';
	case Removed               = 'removed';
	case Modified              = 'modified';
	case Improved              = 'improved';
	case Worsened              = 'worsened';
	case Resolved              = 'resolved';
	case Reopened              = 'reopened';
	case CollectionUnavailable = 'collection_unavailable';
	case Unchanged             = 'unchanged';
}
