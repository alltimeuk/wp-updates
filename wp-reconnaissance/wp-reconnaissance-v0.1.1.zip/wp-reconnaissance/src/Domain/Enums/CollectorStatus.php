<?php
/**
 * Per-collector evidence status, per Section 11. Absence, failure and non-applicability must
 * never share the same representation.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum CollectorStatus: string {
	case Succeeded          = 'succeeded';
	case PartiallySucceeded = 'partially_succeeded';
	case NotApplicable      = 'not_applicable';
	case NotObservable      = 'not_observable';
	case RateLimited        = 'rate_limited';
	case TimedOut           = 'timed_out';
	case Failed             = 'failed';
	case Skipped            = 'skipped';
}
