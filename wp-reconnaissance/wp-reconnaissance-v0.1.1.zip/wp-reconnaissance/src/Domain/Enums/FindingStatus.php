<?php
/**
 * Finding lifecycle states, per Section 8.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum FindingStatus: string {
	case New           = 'new';
	case Open          = 'open';
	case Acknowledged  = 'acknowledged';
	case InProgress    = 'in_progress';
	case Resolved      = 'resolved';
	case AcceptedRisk  = 'accepted_risk';
	case Suppressed    = 'suppressed';
	case FalsePositive = 'false_positive';
}
