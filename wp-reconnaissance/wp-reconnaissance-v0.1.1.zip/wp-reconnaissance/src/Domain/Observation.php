<?php
/**
 * Observation entity, per Section 8.5. Per-collector evidence is stored separately (see
 * `wpr_evidence` / Section 9) and referenced from here rather than duplicated inline.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

final class Observation {

	/**
	 * @param array<string,string> $collector_versions Collector key => collector_version.
	 * @param string[]             $limitations
	 * @param string[]             $failed_collectors
	 */
	public function __construct(
		public readonly ?int $id,
		public readonly int $scope_id,
		public readonly int $job_id,
		public readonly \DateTimeImmutable $observed_at,
		public readonly array $collector_versions,
		public readonly string $schema_version,
		public readonly string $collection_status,
		public readonly ?string $raw_evidence_ref,
		public readonly array $limitations,
		public readonly array $failed_collectors,
		public readonly ?string $integrity_hash
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values, JSON columns as strings).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			scope_id: (int) $row['scope_id'],
			job_id: (int) $row['job_id'],
			observed_at: new \DateTimeImmutable( (string) $row['observed_at'] ),
			collector_versions: self::decode( $row['collector_versions'] ?? null ),
			schema_version: (string) $row['schema_version'],
			collection_status: (string) $row['collection_status'],
			raw_evidence_ref: $row['raw_evidence_ref'] ?? null,
			limitations: self::decode( $row['limitations'] ?? null ),
			failed_collectors: self::decode( $row['failed_collectors'] ?? null ),
			integrity_hash: $row['integrity_hash'] ?? null
		);
	}

	/**
	 * @return array<int|string,mixed>
	 */
	private static function decode( mixed $json ): array {
		if ( ! is_string( $json ) || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}
}
