<?php
/**
 * Authorised collection boundary entity, per Section 8.2.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

final class Scope {

	/**
	 * @param string[]            $permitted_collectors
	 * @param string[]            $known_subdomains
	 * @param string[]            $known_dkim_selectors
	 * @param array<string,mixed> $expected_state
	 */
	public function __construct(
		public readonly ?int $id,
		public readonly int $organisation_id,
		public readonly string $name,
		public readonly string $domain_ascii,
		public readonly string $domain_display,
		public readonly string $registrable_domain,
		public readonly string $status,
		public readonly string $authorisation_status,
		public readonly ?int $authorised_by,
		public readonly ?string $authorisation_reference,
		public readonly ?\DateTimeImmutable $authorised_from,
		public readonly ?\DateTimeImmutable $authorised_until,
		public readonly array $permitted_collectors,
		public readonly ?string $permitted_schedule,
		public readonly array $known_subdomains,
		public readonly array $known_dkim_selectors,
		public readonly array $expected_state,
		public readonly ?int $monitoring_profile_id,
		public readonly ?string $notes
	) {}

	/**
	 * Whether the scope is currently authorised for collection, checked at job-dispatch time
	 * as well as at scope-creation time so an expired authorisation always blocks execution.
	 */
	public function is_currently_authorised( ?\DateTimeImmutable $now = null ): bool {
		$now = $now ?? new \DateTimeImmutable();

		if ( 'authorised' !== $this->authorisation_status ) {
			return false;
		}

		if ( null !== $this->authorised_from && $now < $this->authorised_from ) {
			return false;
		}

		if ( null !== $this->authorised_until && $now > $this->authorised_until ) {
			return false;
		}

		return true;
	}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values, JSON columns as strings).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			organisation_id: (int) $row['organisation_id'],
			name: (string) $row['name'],
			domain_ascii: (string) $row['domain_ascii'],
			domain_display: (string) $row['domain_display'],
			registrable_domain: (string) $row['registrable_domain'],
			status: (string) $row['status'],
			authorisation_status: (string) $row['authorisation_status'],
			authorised_by: isset( $row['authorised_by'] ) ? (int) $row['authorised_by'] : null,
			authorisation_reference: $row['authorisation_reference'] ?? null,
			authorised_from: ! empty( $row['authorised_from'] ) ? new \DateTimeImmutable( (string) $row['authorised_from'] ) : null,
			authorised_until: ! empty( $row['authorised_until'] ) ? new \DateTimeImmutable( (string) $row['authorised_until'] ) : null,
			permitted_collectors: self::decode( $row['permitted_collectors'] ?? null ),
			permitted_schedule: $row['permitted_schedule'] ?? null,
			known_subdomains: self::decode( $row['known_subdomains'] ?? null ),
			known_dkim_selectors: self::decode( $row['known_dkim_selectors'] ?? null ),
			expected_state: self::decode( $row['expected_state'] ?? null ),
			monitoring_profile_id: isset( $row['monitoring_profile_id'] ) ? (int) $row['monitoring_profile_id'] : null,
			notes: $row['notes'] ?? null
		);
	}

	/**
	 * @return array<int|string,mixed>
	 */
	private static function decode( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}
}
