<?php
/**
 * Job entity, per Section 8.4.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

use Alltime\WPReconnaissance\Domain\Enums\JobStatus;

final class Job {

	public function __construct(
		public readonly ?int $id,
		public readonly string $job_uuid,
		public readonly int $organisation_id,
		public readonly int $scope_id,
		public readonly JobStatus $status,
		public readonly ?string $adapter,
		public readonly ?int $actor_id,
		public readonly ?string $manifest_hash,
		public readonly ?string $worker_version,
		public readonly ?int $exit_code,
		public readonly ?string $error_category,
		public readonly \DateTimeImmutable $requested_at,
		public readonly ?\DateTimeImmutable $queued_at,
		public readonly ?\DateTimeImmutable $started_at,
		public readonly ?\DateTimeImmutable $completed_at,
		public readonly ?\DateTimeImmutable $expires_at
	) {}

	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			job_uuid: (string) $row['job_uuid'],
			organisation_id: (int) $row['organisation_id'],
			scope_id: (int) $row['scope_id'],
			status: JobStatus::from( (string) $row['status'] ),
			adapter: $row['adapter'] ?? null,
			actor_id: isset( $row['actor_id'] ) ? (int) $row['actor_id'] : null,
			manifest_hash: $row['manifest_hash'] ?? null,
			worker_version: $row['worker_version'] ?? null,
			exit_code: isset( $row['exit_code'] ) ? (int) $row['exit_code'] : null,
			error_category: $row['error_category'] ?? null,
			requested_at: new \DateTimeImmutable( (string) $row['requested_at'] ),
			queued_at: ! empty( $row['queued_at'] ) ? new \DateTimeImmutable( (string) $row['queued_at'] ) : null,
			started_at: ! empty( $row['started_at'] ) ? new \DateTimeImmutable( (string) $row['started_at'] ) : null,
			completed_at: ! empty( $row['completed_at'] ) ? new \DateTimeImmutable( (string) $row['completed_at'] ) : null,
			expires_at: ! empty( $row['expires_at'] ) ? new \DateTimeImmutable( (string) $row['expires_at'] ) : null
		);
	}
}
