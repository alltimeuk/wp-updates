<?php
/**
 * Canonicalised scope domain: ASCII (IDNA) form for querying, a safe Unicode form for display,
 * and its registrable domain per Section 8.2.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

final class ValidatedDomain {

	public function __construct(
		public readonly string $ascii,
		public readonly string $display,
		public readonly string $registrable
	) {}
}
