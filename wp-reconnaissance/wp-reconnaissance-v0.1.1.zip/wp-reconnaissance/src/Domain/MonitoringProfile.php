<?php
/**
 * Monitoring profile entity, per Section 8.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

final class MonitoringProfile {

	/**
	 * @param string[]            $enabled_collectors
	 * @param array<string,int>   $collector_timeouts
	 * @param array<string,mixed> $change_thresholds
	 * @param array<string,mixed> $notification_rules
	 * @param string[]            $rule_packs
	 */
	public function __construct(
		public readonly ?int $id,
		public readonly ?int $organisation_id,
		public readonly string $name,
		public readonly array $enabled_collectors,
		public readonly array $collector_timeouts,
		public readonly ?string $schedule,
		public readonly array $change_thresholds,
		public readonly array $notification_rules,
		public readonly array $rule_packs,
		public readonly ?int $evidence_retention_days,
		public readonly int $max_lookalike_candidates = 500
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values, JSON columns as strings).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			organisation_id: isset( $row['organisation_id'] ) ? (int) $row['organisation_id'] : null,
			name: (string) $row['name'],
			enabled_collectors: self::decode( $row['enabled_collectors'] ?? null ),
			collector_timeouts: self::decode( $row['collector_timeouts'] ?? null ),
			schedule: $row['schedule'] ?? null,
			change_thresholds: self::decode( $row['change_thresholds'] ?? null ),
			notification_rules: self::decode( $row['notification_rules'] ?? null ),
			rule_packs: self::decode( $row['rule_packs'] ?? null ),
			evidence_retention_days: isset( $row['evidence_retention_days'] ) ? (int) $row['evidence_retention_days'] : null,
			max_lookalike_candidates: isset( $row['max_lookalike_candidates'] ) ? (int) $row['max_lookalike_candidates'] : 500
		);
	}

	/**
	 * @return array<int|string,mixed>
	 */
	private static function decode( mixed $json ): array {
		if ( ! is_string( $json ) || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}
}
