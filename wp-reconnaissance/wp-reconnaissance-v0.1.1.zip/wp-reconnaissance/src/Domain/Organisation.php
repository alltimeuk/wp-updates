<?php
/**
 * Organisation entity, per Section 8.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

final class Organisation {

	public function __construct(
		public readonly ?int $id,
		public readonly string $name,
		public readonly string $slug,
		public readonly string $status,
		public readonly ?int $primary_contact_id,
		public readonly string $timezone,
		public readonly ?int $default_profile_id,
		public readonly ?string $retention_policy,
		public readonly ?\DateTimeImmutable $created_at = null,
		public readonly ?\DateTimeImmutable $updated_at = null
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			name: (string) $row['name'],
			slug: (string) $row['slug'],
			status: (string) $row['status'],
			primary_contact_id: isset( $row['primary_contact_id'] ) ? (int) $row['primary_contact_id'] : null,
			timezone: (string) $row['timezone'],
			default_profile_id: isset( $row['default_profile_id'] ) ? (int) $row['default_profile_id'] : null,
			retention_policy: $row['retention_policy'] ?? null,
			created_at: isset( $row['created_at'] ) ? new \DateTimeImmutable( (string) $row['created_at'] ) : null,
			updated_at: isset( $row['updated_at'] ) ? new \DateTimeImmutable( (string) $row['updated_at'] ) : null
		);
	}
}
