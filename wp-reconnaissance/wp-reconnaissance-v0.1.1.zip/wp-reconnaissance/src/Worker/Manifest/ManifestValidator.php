<?php
/**
 * Validates a decoded job manifest against `schemas/job-manifest.schema.json` plus the
 * business rules the schema cannot express: expiry and domain-safety checks (Section 10).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Manifest;

use Alltime\WPReconnaissance\Domain\DomainValidator;
use Alltime\WPReconnaissance\Domain\Exceptions\InvalidDomainException;
use Alltime\WPReconnaissance\Worker\Exceptions\ManifestException;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Opis\JsonSchema\Validator;

final class ManifestValidator {
    public function __construct(
        private readonly string $schema_path,
        private readonly DomainValidator $domain_validator = new DomainValidator()
    ) {
    }

    /**
     * @throws ManifestException When the manifest fails schema or business-rule validation.
     */
    public function validate( \stdClass $manifest ): ScopeContext {
        $this->validate_against_schema($manifest);
        $this->validate_business_rules($manifest);

        $profile = $manifest->profile;

        return new ScopeContext(
            domain: $manifest->scope->domain,
            registrable_domain: $manifest->scope->registrable_domain,
            known_dkim_selectors: (array) ( $profile->known_dkim_selectors ?? [] ),
            common_subdomains: (array) ( $profile->common_subdomains ?? [] ),
            timeouts_seconds: (array) ( $profile->timeouts_seconds ?? [] ),
            max_lookalike_candidates: (int) ( $profile->max_lookalike_candidates ?? 500 )
        );
    }

    private function validate_against_schema( \stdClass $manifest ): void {
        $schema = json_decode((string) file_get_contents($this->schema_path));

        if (! $schema instanceof \stdClass) {
            throw new ManifestException("Unable to load or parse the manifest schema at {$this->schema_path}.");
        }

        $validator = new Validator();
        // A decoded schema object is passed directly rather than a file:// URI string, so
        // validation doesn't depend on platform-specific URI parsing of local file paths.
        $result = $validator->validate($manifest, $schema);

        if (! $result->isValid()) {
            $error  = $result->error();
            $detail = null !== $error
                ? $error->keyword() . ' at ' . implode('.', $error->data()->fullPath())
                : 'unknown error';

            throw new ManifestException("Manifest failed schema validation: {$detail}");
        }
    }

    private function validate_business_rules( \stdClass $manifest ): void {
        $expires_at = \DateTimeImmutable::createFromFormat(\DateTimeInterface::ATOM, $manifest->expires_at)
            ?: new \DateTimeImmutable($manifest->expires_at);

        if ($expires_at < new \DateTimeImmutable()) {
            throw new ManifestException('Manifest has expired.');
        }

        foreach ([ $manifest->scope->domain, $manifest->scope->registrable_domain ] as $domain) {
            try {
                $this->domain_validator->validate($domain);
            } catch (InvalidDomainException $exception) {
                throw new ManifestException("Manifest scope domain failed safety validation: {$exception->getMessage()}");
            }
        }
    }
}
