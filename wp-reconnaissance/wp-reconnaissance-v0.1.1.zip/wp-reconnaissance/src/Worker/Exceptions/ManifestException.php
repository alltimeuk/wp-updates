<?php
/**
 * Thrown when a job manifest fails validation before any collection starts. The orchestrator
 * maps this to exit code 64 (Section 10, Section 34 acceptance criterion 8).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Exceptions;

final class ManifestException extends \RuntimeException {
}
