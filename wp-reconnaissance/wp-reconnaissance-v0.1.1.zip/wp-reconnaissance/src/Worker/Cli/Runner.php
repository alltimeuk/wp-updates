<?php
/**
 * Collection worker orchestrator (Section 6.2, 12).
 *
 * Validates the manifest, runs only the requested collectors, and assembles the evidence
 * document (`schemas/evidence.schema.json`). Never touches the WordPress database, never holds
 * WordPress credentials, never makes scoring or customer-access decisions - those belong to
 * WordPress once it ingests this evidence.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Cli;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Collectors\CollectorInterface;
use Alltime\WPReconnaissance\Worker\Collectors\CollectorRegistry;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\Exceptions\ManifestException;
use Alltime\WPReconnaissance\Worker\Manifest\ManifestValidator;

final class Runner {
    public const EXIT_SUCCESS            = 0;
    public const EXIT_MANIFEST_INVALID   = 64;
    public const EXIT_INTERNAL_ERROR     = 70;

    private const WORKER_VERSION = '0.1.0';

    /** @var array<string,CollectorInterface> */
    private readonly array $collectors;

    /**
     * @param array<string,CollectorInterface>|null $collectors Defaults to
     *        {@see CollectorRegistry::default_collectors()} when omitted.
     */
    public function __construct(
        private readonly ManifestValidator $manifest_validator,
        ?array $collectors = null
    ) {
        $this->collectors = $collectors ?? CollectorRegistry::default_collectors();
    }

    /**
     * @return array{0:int,1:?array<string,mixed>} Exit code and, on success, the evidence document.
     */
    public function run( string $manifest_json, ?callable $log = null ): array {
        $log ??= static function ( string $message ): void {
            fwrite(STDERR, "[wpr-worker] {$message}\n");
        };

        try {
            $decoded = json_decode($manifest_json, false, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $exception) {
            $log("Manifest is not valid JSON: {$exception->getMessage()}");
            return [ self::EXIT_MANIFEST_INVALID, null ];
        }

        if (! $decoded instanceof \stdClass) {
            $log('Manifest must be a JSON object.');
            return [ self::EXIT_MANIFEST_INVALID, null ];
        }

        try {
            $context = $this->manifest_validator->validate($decoded);
        } catch (ManifestException $exception) {
            $log("Manifest validation failed: {$exception->getMessage()}");
            return [ self::EXIT_MANIFEST_INVALID, null ];
        }

        $log("Manifest accepted for job {$decoded->job_id} (scope: {$context->domain})");

        try {
            $collector_results = [];

            foreach ($decoded->profile->collectors as $collector_key) {
                $collector = $this->collectors[ $collector_key ] ?? null;

                if (null === $collector) {
                    $log("Skipping unknown collector: {$collector_key}");
                    continue;
                }

                $log("Running collector: {$collector_key}");
                $result               = $collector->collect($context);
                $collector_results[]  = $result;
                $log("Collector {$collector_key} finished with status: {$result->status->value}");
            }

            $evidence = [
                'schema_version' => '1.0.0',
                'job_id'         => $decoded->job_id,
                'scope'          => [
                    'domain'             => $context->domain,
                    'registrable_domain' => $context->registrable_domain,
                ],
                'worker_version' => self::WORKER_VERSION,
                'generated_at'   => ( new \DateTimeImmutable() )->format(\DateTimeInterface::ATOM),
                'limitations'    => array_values(
                    array_map(
                        static fn ( CollectorResult $result ): string => "{$result->collector}: {$result->status->value}",
                        array_filter($collector_results, static fn ( CollectorResult $result ): bool => CollectorStatus::Succeeded !== $result->status)
                    )
                ),
                'collectors'     => array_map(
                    static fn ( CollectorResult $result ): array => $result->to_array(),
                    $collector_results
                ),
            ];

            return [ self::EXIT_SUCCESS, $evidence ];
        } catch (\Throwable $exception) {
            $log("Unexpected worker error: {$exception->getMessage()}");
            return [ self::EXIT_INTERNAL_ERROR, null ];
        }
    }
}
