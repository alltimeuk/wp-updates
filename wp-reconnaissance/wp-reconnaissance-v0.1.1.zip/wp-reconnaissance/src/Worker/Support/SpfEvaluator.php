<?php
/**
 * RFC 7208-aligned recursive SPF evaluation: walks include: and redirect= chains, counting the
 * mechanisms that cost a DNS lookup (include, a, mx, exists, redirect; ptr is deprecated and
 * excluded) against the 10-lookup ceiling, and detects loops via a visited-domain set. This
 * corrects the previous engine's non-recursive root-record regex (Section 12.1).
 *
 * # TODO(12.1): void-lookup counting (RFC 7208 4.6.4, max 2) is approximated - a and mx
 * sub-lookups are counted toward the 10-lookup budget but their own void/NXDOMAIN outcomes are
 * not yet separately tallied.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Support;

final class SpfEvaluator {
    private const MAX_DEPTH = 10;

    /**
     * @param array<string,bool> $visited
     * @return array<string,mixed>
     */
    public static function evaluate( string $domain, array &$visited = [], int $depth = 0 ): array {
        $result = [
            'domain'        => $domain,
            'record'        => null,
            'lookup_count'  => 0,
            'loop_detected' => false,
            'includes'      => [],
            'redirect'      => null,
            'all_mechanism' => null,
            'errors'        => [],
        ];

        $key = strtolower($domain);

        if ($depth > self::MAX_DEPTH || isset($visited[ $key ])) {
            $result['loop_detected'] = true;
            return $result;
        }
        $visited[ $key ] = true;

        $txt_records = array_map(
            static fn ( array $record ): string => $record['txt'] ?? '',
            Dns::query($domain, DNS_TXT)
        );
        $spf_records = array_values(array_filter($txt_records, static fn ( string $txt ): bool => str_starts_with($txt, 'v=spf1')));

        if (0 === count($spf_records)) {
            $result['errors'][] = 'No SPF record found.';
            return $result;
        }
        if (count($spf_records) > 1) {
            $result['errors'][] = 'Multiple SPF records found (permanent error under RFC 7208).';
        }

        $record            = $spf_records[0];
        $result['record']  = $record;
        $raw_terms         = preg_split('/\s+/', $record) ?: [];
        $terms             = array_values(
            array_filter($raw_terms, static fn ( string $term ): bool => '' !== $term && 'v=spf1' !== $term)
        );

        foreach ($terms as $term) {
            if (preg_match('/^[+\-~?]?all$/', $term)) {
                $result['all_mechanism'] = $term;
                continue;
            }

            if (preg_match('/^include:(.+)$/', $term, $matches)) {
                ++$result['lookup_count'];
                $nested                    = self::evaluate($matches[1], $visited, $depth + 1);
                $result['lookup_count']   += $nested['lookup_count'];
                $result['loop_detected']   = $result['loop_detected'] || $nested['loop_detected'];
                $result['includes'][]      = $nested;
                continue;
            }

            if (preg_match('/^redirect=(.+)$/', $term, $matches)) {
                ++$result['lookup_count'];
                $nested                  = self::evaluate($matches[1], $visited, $depth + 1);
                $result['lookup_count'] += $nested['lookup_count'];
                $result['loop_detected'] = $result['loop_detected'] || $nested['loop_detected'];
                $result['redirect']      = $nested;
                continue;
            }

            if (preg_match('/^(a|mx|exists)(:.+)?$/', $term)) {
                ++$result['lookup_count'];
            }
        }

        return $result;
    }
}
