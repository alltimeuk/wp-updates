<?php
/**
 * Thin wrapper around PHP's built-in `dns_get_record()` so collectors share one error-handling
 * convention: a genuine resolution error throws, while "no records of this type" returns an
 * empty array (never a merged "failed = absent" representation - Section 11).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Support;

final class Dns {
    /**
     * @return array<int,array<string,mixed>>
     */
    public static function query( string $name, int $type ): array {
        set_error_handler(
            static function ( int $errno, string $errstr ): bool {
                throw new \RuntimeException($errstr);
            }
        );

        try {
            $records = dns_get_record(rtrim($name, '.') . '.', $type);

            return false !== $records ? $records : [];
        } catch (\RuntimeException $exception) {
            if (str_contains($exception->getMessage(), 'DNS Query failed')) {
                return [];
            }

            throw $exception;
        } finally {
            restore_error_handler();
        }
    }
}
