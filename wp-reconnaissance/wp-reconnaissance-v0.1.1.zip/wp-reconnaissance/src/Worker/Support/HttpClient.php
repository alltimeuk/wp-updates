<?php
/**
 * Minimal cURL wrapper shared by the collectors that need to make outbound HTTP(S) requests
 * (RDAP, HTTP, Certificate Transparency). Centralises timeout, redirect and response-size
 * handling so each collector doesn't reimplement it (Section 27: "apply response-size and
 * redirect limits").
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Support;

final class HttpClient {
    private const MAX_RESPONSE_BYTES = 5 * 1024 * 1024; // 5 MiB.

    /**
     * Performs a single request without following redirects - callers that need redirect
     * chains (the HTTP collector) walk hops themselves so every hop is individually recorded.
     *
     * @param array<string,string> $headers
     */
    public static function request( string $method, string $url, array $headers = [], int $timeout_seconds = 15 ): HttpResponse {
        $handle = curl_init($url);

        if (false === $handle) {
            throw new \RuntimeException("Unable to initialise HTTP request to {$url}.");
        }

        $response_headers = [];

        curl_setopt_array(
            $handle,
            [
                CURLOPT_CUSTOMREQUEST  => $method,
                CURLOPT_NOBODY         => 'HEAD' === $method,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_TIMEOUT        => $timeout_seconds,
                CURLOPT_CONNECTTIMEOUT => $timeout_seconds,
                CURLOPT_MAXFILESIZE    => self::MAX_RESPONSE_BYTES,
                CURLOPT_HTTPHEADER     => self::format_request_headers($headers),
                CURLOPT_HEADERFUNCTION => static function ( $curl_handle, string $line ) use ( &$response_headers ): int {
                    $parts = explode(':', $line, 2);
                    if (2 === count($parts)) {
                        $response_headers[ strtolower(trim($parts[0])) ] = trim($parts[1]);
                    }
                    return strlen($line);
                },
                CURLOPT_USERAGENT      => 'WP-Reconnaissance/1.0 (+https://alltimeuk.com)',
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ]
        );

        $body       = curl_exec($handle);
        $error      = curl_error($handle);
        $status     = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);

        curl_close($handle);

        if (false === $body) {
            throw new \RuntimeException("HTTP request to {$url} failed: {$error}");
        }

        return new HttpResponse($status, $response_headers, (string) $body);
    }

    /**
     * @param array<string,string> $headers
     * @return string[]
     */
    private static function format_request_headers( array $headers ): array {
        $formatted = [];

        foreach ($headers as $name => $value) {
            $formatted[] = "{$name}: {$value}";
        }

        return $formatted;
    }
}
