<?php
/**
 * Result of a single HTTP request made by {@see HttpClient}.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Support;

final class HttpResponse {
    /**
     * @param array<string,string> $headers Lower-cased header name => value.
     */
    public function __construct(
        public readonly int $status,
        public readonly array $headers,
        public readonly string $body
    ) {
    }

    public function header( string $name ): ?string {
        return $this->headers[ strtolower($name) ] ?? null;
    }

    public function is_redirect(): bool {
        return in_array($this->status, [ 301, 302, 303, 307, 308 ], true);
    }
}
