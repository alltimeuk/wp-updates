<?php
/**
 * Generates bounded typosquat/lookalike candidates for a registrable domain's label: omission,
 * insertion, transposition, substitution, hyphenation, prefix, suffix, TLD and a small set of
 * confusable variants (Section 12.1).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Support;

final class LookalikeGenerator {
    private const ALPHABET = 'abcdefghijklmnopqrstuvwxyz0123456789';

    /**
     * A handful of visually-confusable single/multi-character substitutions used by common
     * typosquatting. Not a substitute for full Unicode confusable-skeleton matching.
     * # TODO(12.1): replace with a proper Unicode confusable-skeleton table (UTS #39) for
     * mixed-script and homoglyph candidates.
     *
     * @var array<string,string>
     */
    private const CONFUSABLE_SUBSTITUTIONS = [ 'o' => '0', 'l' => '1', 'i' => '1', 'rn' => 'm', 'vv' => 'w' ];

    /** @var string[] */
    private const COMMON_ALTERNATE_TLDS = [ 'com', 'net', 'org', 'io', 'co' ];

    /** @var string[] */
    private const COMMON_AFFIXES = [ 'secure', 'login', 'account', 'my', 'portal', 'support' ];

    /**
     * Always computes the registrable domain correctly (caller passes the label/suffix split
     * of an already-resolved registrable domain), fixing the previous engine's bug of querying
     * a random name directly beneath a public suffix such as co.uk.
     *
     * @return array<int,array{candidate:string,variant_type:string}>
     */
    public static function generate( string $label, string $suffix, int $max_candidates = 500 ): array {
        $candidates = [];

        $add = static function (
            string $candidate_label,
            string $candidate_suffix,
            string $variant_type
        ) use ( &$candidates, $label, $suffix, $max_candidates ): void {
            if (count($candidates) >= $max_candidates) {
                return;
            }
            if ($candidate_label === $label && $candidate_suffix === $suffix) {
                return;
            }
            $candidates[] = [ 'candidate' => "{$candidate_label}.{$candidate_suffix}", 'variant_type' => $variant_type ];
        };

        $length = strlen($label);

        for ($i = 0; $i < $length && count($candidates) < $max_candidates; $i++) {
            $add(substr_replace($label, '', $i, 1), $suffix, 'omission');
        }

        for ($i = 0; $i < $length - 1 && count($candidates) < $max_candidates; $i++) {
            $chars       = str_split($label);
            [ $chars[ $i ], $chars[ $i + 1 ] ] = [ $chars[ $i + 1 ], $chars[ $i ] ];
            $add(implode('', $chars), $suffix, 'transposition');
        }

        for ($i = 1; $i < $length && count($candidates) < $max_candidates; $i++) {
            $add(substr($label, 0, $i) . '-' . substr($label, $i), $suffix, 'hyphenation');
        }

        for ($i = 0; $i <= $length && count($candidates) < $max_candidates; $i++) {
            foreach (str_split(self::ALPHABET) as $char) {
                if (count($candidates) >= $max_candidates) {
                    break;
                }
                $add(substr_replace($label, $char, $i, 0), $suffix, 'insertion');

                if ($i < $length) {
                    $add(substr_replace($label, $char, $i, 1), $suffix, 'substitution');
                }
            }
        }

        foreach (self::CONFUSABLE_SUBSTITUTIONS as $from => $to) {
            if (count($candidates) >= $max_candidates) {
                break;
            }
            if (str_contains($label, $from)) {
                $add(str_replace($from, $to, $label), $suffix, 'confusable');
            }
        }

        foreach (self::COMMON_AFFIXES as $affix) {
            if (count($candidates) >= $max_candidates) {
                break;
            }
            $add("{$affix}-{$label}", $suffix, 'prefix');
            $add("{$label}-{$affix}", $suffix, 'suffix');
        }

        foreach (self::COMMON_ALTERNATE_TLDS as $alt_tld) {
            if (count($candidates) >= $max_candidates) {
                break;
            }
            if ($alt_tld !== $suffix) {
                $add($label, $alt_tld, 'tld');
            }
        }

        return $candidates;
    }
}
