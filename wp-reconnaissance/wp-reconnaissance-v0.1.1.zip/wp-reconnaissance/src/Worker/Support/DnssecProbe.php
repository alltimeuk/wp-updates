<?php
/**
 * Minimal raw DNS client for a single DNSKEY query with the EDNS(0) "DO" (DNSSEC OK) bit set,
 * so the response's AD (Authenticated Data) flag can be inspected directly.
 *
 * PHP's built-in `dns_get_record()` has no DNSSEC support at all - it exposes neither the DO
 * bit on the query nor the AD bit on the response - so there is no way to get this evidence
 * through the standard API without either shelling out to `dig`/`drill` (an extra runtime
 * dependency and another process-execution surface to secure) or speaking the wire protocol
 * directly. This does the latter: one UDP query, ~40 bytes out, a parsed 12-byte header back.
 *
 * Queries a known DNSSEC-validating public resolver rather than the host's configured system
 * resolver, because many ISP/hosting resolvers do not perform DNSSEC validation at all - which
 * would make every domain look "insecure" regardless of its actual DNSSEC status. This is a
 * deliberate, documented choice, not an oversight.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Support;

final class DnssecProbe {
    private const DNSKEY_TYPE = 48;
    private const DNS_CLASS_IN = 1;

    /**
     * @return array{ad: bool, ancount: int, rcode: int}
     *
     * @throws \RuntimeException When the resolver cannot be reached or the response is malformed.
     */
    public static function query( string $domain, string $resolver = '1.1.1.1', int $timeout_seconds = 5 ): array {
        $packet = self::build_query($domain);

        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- fsockopen warnings are redundant with the $errno/$errstr check below.
        $socket = @fsockopen('udp://' . $resolver, 53, $errno, $errstr, $timeout_seconds);

        if (false === $socket) {
            throw new \RuntimeException("Unable to reach DNS resolver {$resolver}: {$errstr}");
        }

        try {
            stream_set_timeout($socket, $timeout_seconds);
            fwrite($socket, $packet);

            $response = fread($socket, 4096);

            if (false === $response || strlen($response) < 12) {
                throw new \RuntimeException('No or malformed response from DNS resolver.');
            }

            return self::parse_header($response);
        } finally {
            fclose($socket);
        }
    }

    private static function build_query( string $domain ): string {
        $id     = random_int(0, 0xFFFF);
        $header = pack('n6', $id, 0x0100, 1, 0, 0, 1); // RD=1; QDCOUNT=1; ARCOUNT=1 (OPT record).

        $question = self::encode_name($domain) . pack('n2', self::DNSKEY_TYPE, self::DNS_CLASS_IN);

        // OPT pseudo-record: root name, TYPE=OPT(41), CLASS=4096 (UDP payload size),
        // TTL carries ext-rcode/version/flags where the top bit of the flags word is DO.
        $opt = "\x00" . pack('n', 41) . pack('n', 4096) . pack('N', 0x00008000) . pack('n', 0);

        return $header . $question . $opt;
    }

    private static function encode_name( string $domain ): string {
        $encoded = '';

        foreach (explode('.', rtrim($domain, '.')) as $label) {
            $encoded .= chr(strlen($label)) . $label;
        }

        return $encoded . "\x00";
    }

    /**
     * @return array{ad: bool, ancount: int, rcode: int}
     */
    private static function parse_header( string $response ): array {
        $flags   = ( ord($response[2]) << 8 ) | ord($response[3]);
        $ancount = ( ord($response[6]) << 8 ) | ord($response[7]);

        return [
            'ad'      => (bool) ( $flags & 0x0020 ),
            'ancount' => $ancount,
            'rcode'   => $flags & 0x000F,
        ];
    }
}
