<?php
/**
 * The subset of a validated job manifest that collectors actually need. Deliberately narrower
 * than the raw manifest array so a collector cannot reach into unrelated manifest fields.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker;

final class ScopeContext {
    /**
     * @param string[]          $known_dkim_selectors
     * @param string[]          $common_subdomains
     * @param array<string,int> $timeouts_seconds
     */
    public function __construct(
        public readonly string $domain,
        public readonly string $registrable_domain,
        public readonly array $known_dkim_selectors = [],
        public readonly array $common_subdomains = [],
        public readonly array $timeouts_seconds = [],
        public readonly int $max_lookalike_candidates = 500
    ) {
    }

    public function timeout_for( string $collector, int $default = 15 ): int {
        return $this->timeouts_seconds[ $collector ] ?? $this->timeouts_seconds['default'] ?? $default;
    }
}
