<?php
/**
 * One collector-result envelope, matching `schemas/evidence.schema.json`'s
 * `$defs.collectorResult` exactly. Every collector returns this shape so the orchestrator never
 * has to special-case a collector, and absence/failure/non-applicability are always distinct
 * statuses (Section 11).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Evidence;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;

final class CollectorResult {
    /**
     * @param array<string,mixed> $data
     * @param string[]            $limitations
     * @param string[]            $errors
     */
    public function __construct(
        public readonly string $collector,
        public readonly string $collector_version,
        public readonly CollectorStatus $status,
        public readonly float $duration_ms,
        public readonly string $source = '',
        public readonly array $data = [],
        public readonly array $limitations = [],
        public readonly array $errors = [],
        public readonly ?\DateTimeImmutable $observed_at = null
    ) {
    }

    /**
     * @return array<string,mixed>
     */
    public function to_array(): array {
        return [
            'collector'         => $this->collector,
            'collector_version' => $this->collector_version,
            'status'            => $this->status->value,
            'observed_at'       => ( $this->observed_at ?? new \DateTimeImmutable() )->format(\DateTimeInterface::ATOM),
            'source'            => $this->source,
            'duration_ms'       => (int) round($this->duration_ms),
            'data'              => (object) $this->data,
            'limitations'       => array_values($this->limitations),
            'errors'            => array_values($this->errors),
        ];
    }
}
