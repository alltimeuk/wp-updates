<?php
/**
 * Contract every collector implements, per Section 12 ("Each collector shall implement a
 * common interface and return objects rather than writing presentation strings").
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;

interface CollectorInterface {
    /** The manifest collector key this handles, e.g. "dns", "mail", "tls". */
    public function key(): string;

    public function collect( ScopeContext $context ): CollectorResult;
}
