<?php
/**
 * Generates and resolves lookalike-domain candidates (Section 5.1, 12.1). A resolving candidate
 * is recorded as an observation, never classified as malicious - that judgement belongs to the
 * rule engine.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\Dns;
use Alltime\WPReconnaissance\Worker\Support\LookalikeGenerator;

final class LookalikeCollector extends AbstractCollector {
    public function key(): string {
        return 'lookalikes';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $separator = strpos($context->registrable_domain, '.');

        if (false === $separator) {
            return $this->result(CollectorStatus::NotApplicable, $started, errors: [ 'Registrable domain has no separable label/suffix.' ]);
        }

        $label      = substr($context->registrable_domain, 0, $separator);
        $suffix     = substr($context->registrable_domain, $separator + 1);
        $candidates = LookalikeGenerator::generate($label, $suffix, $context->max_lookalike_candidates);

        $resolving = [];

        foreach ($candidates as $candidate) {
            $addresses = Dns::query($candidate['candidate'], DNS_A);

            if (0 === count($addresses)) {
                continue;
            }

            $resolving[] = [
                'candidate'    => $candidate['candidate'],
                'variant_type' => $candidate['variant_type'],
                'resolves'     => true,
                'mx_enabled'   => count(Dns::query($candidate['candidate'], DNS_MX)) > 0,
                'addresses'    => array_map(static fn ( array $record ): ?string => $record['ip'] ?? null, $addresses),
            ];
        }

        $data = [
            'candidates_generated' => count($candidates),
            'resolving_candidates' => $resolving,
        ];

        return $this->result(
            CollectorStatus::Succeeded,
            $started,
            'system_resolver',
            $data,
            [ 'Resolving candidates are not yet enriched with RDAP, MX-provider, TLS or HTTP-redirect evidence.' ]
        );
    }
}
