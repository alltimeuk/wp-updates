<?php
/**
 * Resolves the scope's known and configured common subdomains (Section 5.1). This collector
 * only reports what actually resolves; classifying a name as "shadow infrastructure" belongs to
 * the rule engine comparing this evidence against known/expected state, not to the collector
 * (Section 12.1: "do not label a name shadow infrastructure solely because a small wordlist did
 * not find it").
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\Dns;

final class SubdomainCollector extends AbstractCollector {
    /** @var string[] */
    private const DEFAULT_COMMON_SUBDOMAINS = [
        'www', 'mail', 'autodiscover', 'webmail', 'portal', 'vpn', 'remote', 'ftp', 'api', 'staging', 'dev', 'test',
    ];

    public function key(): string {
        return 'subdomains';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $candidates = array_values(
            array_unique(
                array_filter(
                    array_merge($context->common_subdomains, self::DEFAULT_COMMON_SUBDOMAINS),
                    static fn ( string $label ): bool => '' !== $label && '*' !== $label
                )
            )
        );

        $results = [];

        foreach ($candidates as $label) {
            $fqdn    = "{$label}.{$context->domain}";
            $answers = array_merge(Dns::query($fqdn, DNS_A), Dns::query($fqdn, DNS_AAAA));

            $results[] = [
                'label'    => $label,
                'fqdn'     => $fqdn,
                'resolves' => count($answers) > 0,
                'records'  => array_map(
                    static fn ( array $record ): array => [ 'type' => $record['type'] ?? '', 'value' => $record['ip'] ?? ( $record['ipv6'] ?? null ) ],
                    $answers
                ),
            ];
        }

        $data = [
            'candidates_checked' => count($candidates),
            'results'            => $results,
        ];

        return $this->result(CollectorStatus::Succeeded, $started, 'system_resolver', $data);
    }
}
