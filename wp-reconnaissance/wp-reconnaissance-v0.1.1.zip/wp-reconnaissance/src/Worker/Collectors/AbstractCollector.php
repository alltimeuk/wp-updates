<?php
/**
 * Shared timing/exception-safety wrapper for collectors: a collector failure must never abort
 * the whole job (Section 3, "graceful degradation") - an uncaught exception becomes a `failed`
 * result rather than crashing the worker process.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;

abstract class AbstractCollector implements CollectorInterface {
    protected const COLLECTOR_VERSION = '1.0.0';

    final public function collect( ScopeContext $context ): CollectorResult {
        $started = microtime(true);

        try {
            return $this->run($context, $started);
        } catch (\Throwable $exception) {
            return $this->result(CollectorStatus::Failed, $started, errors: [ $exception->getMessage() ]);
        }
    }

    abstract protected function run( ScopeContext $context, float $started ): CollectorResult;

    /**
     * @param array<string,mixed> $data
     * @param string[]            $limitations
     * @param string[]            $errors
     */
    protected function result(
        CollectorStatus $status,
        float $started,
        string $source = '',
        array $data = [],
        array $limitations = [],
        array $errors = []
    ): CollectorResult {
        return new CollectorResult(
            collector: $this->key(),
            collector_version: static::COLLECTOR_VERSION,
            status: $status,
            duration_ms: ( microtime(true) - $started ) * 1000,
            source: $source,
            data: $data,
            limitations: $limitations,
            errors: $errors
        );
    }
}
