<?php
/**
 * Captures HTTP and HTTPS redirect chains and evaluates security headers (Section 5.1, 12.1).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\HttpClient;
use Alltime\WPReconnaissance\Worker\Support\HttpResponse;

final class HttpCollector extends AbstractCollector {
    private const MAX_HOPS = 10;

    public function key(): string {
        return 'http';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $timeout     = $context->timeout_for($this->key());
        $limitations = [];

        $https_chain = $this->follow_redirect_chain("https://{$context->domain}/", $timeout);
        $http_chain  = $this->follow_redirect_chain("http://{$context->domain}/", $timeout);

        $https_available = count($https_chain) > 0 && null !== $https_chain[0]['status_code'];
        if (! $https_available) {
            $limitations[] = 'HTTPS was not reachable on the assessed host.';
        }

        $final_hop = end($https_chain) ?: [ 'headers' => [] ];
        $headers   = $final_hop['headers'];

        $http_redirects_to_https = count($http_chain) > 0
            && in_array($http_chain[0]['status_code'] ?? 0, [ 301, 302, 307, 308 ], true)
            && count(array_filter($http_chain, static fn ( array $hop ): bool => str_starts_with($hop['uri'], 'https://'))) > 0;

        $csp             = $headers['content-security-policy'] ?? null;
        $csp_report_only = $headers['content-security-policy-report-only'] ?? null;

        $data = [
            'https_available'           => $https_available,
            'http_redirects_to_https'   => $http_redirects_to_https,
            'https_redirect_chain'      => $https_chain,
            'http_redirect_chain'       => $http_chain,
            'hsts'                      => $this->evaluate_hsts($headers['strict-transport-security'] ?? null),
            'csp'                       => [
                'present'     => null !== $csp,
                'report_only' => null === $csp && null !== $csp_report_only,
                'policy'      => $csp ?? $csp_report_only,
            ],
            'frame_ancestors_controlled' => ( null !== $csp && str_contains($csp, 'frame-ancestors') ) || isset($headers['x-frame-options']),
            'x_xss_protection_legacy'    => $headers['x-xss-protection'] ?? null,
            'server_disclosure_headers'  => [
                'server'       => $headers['server'] ?? null,
                'x_powered_by' => $headers['x-powered-by'] ?? null,
            ],
        ];

        $status = $https_available ? CollectorStatus::Succeeded : CollectorStatus::PartiallySucceeded;

        return $this->result($status, $started, 'direct_http_request', $data, $limitations);
    }

    /**
     * @return array<int,array{uri:string,status_code:?int,headers:array<string,string>,error?:string}>
     */
    private function follow_redirect_chain( string $uri, int $timeout ): array {
        $hops    = [];
        $current = $uri;

        for ($i = 0; $i < self::MAX_HOPS; $i++) {
            try {
                $response = HttpClient::request('HEAD', $current, [], $timeout);
            } catch (\Throwable $head_exception) {
                // Some servers reject HEAD; fall back to a bounded GET (Section 12.1).
                try {
                    $response = HttpClient::request('GET', $current, [], $timeout);
                } catch (\Throwable $get_exception) {
                    $hops[] = [ 'uri' => $current, 'status_code' => null, 'headers' => [], 'error' => $get_exception->getMessage() ];
                    break;
                }
            }

            $hops[] = [ 'uri' => $current, 'status_code' => $response->status, 'headers' => $response->headers ];

            if (! $response->is_redirect() || null === $response->header('location')) {
                break;
            }

            $current = $this->resolve_location($current, (string) $response->header('location'));
        }

        return $hops;
    }

    private function resolve_location( string $current, string $location ): string {
        if (str_starts_with($location, 'http://') || str_starts_with($location, 'https://')) {
            return $location;
        }

        $parts = parse_url($current);

        return sprintf('%s://%s%s', $parts['scheme'] ?? 'https', $parts['host'] ?? '', $location);
    }

    /**
     * @return array{present:bool,max_age:int,include_sub_domains:bool,preload:bool,weak:bool}
     */
    private function evaluate_hsts( ?string $header_value ): array {
        if (null === $header_value) {
            return [ 'present' => false, 'max_age' => 0, 'include_sub_domains' => false, 'preload' => false, 'weak' => true ];
        }

        $max_age = 0;
        if (1 === preg_match('/max-age=(\d+)/', $header_value, $matches)) {
            $max_age = (int) $matches[1];
        }

        return [
            'present'             => true,
            'max_age'             => $max_age,
            'include_sub_domains' => str_contains($header_value, 'includeSubDomains'),
            'preload'             => str_contains($header_value, 'preload'),
            // Below six months is treated as a weak deployment (Section 12.1: evaluate directives, not presence only).
            'weak'                => $max_age < 15552000,
        ];
    }
}
