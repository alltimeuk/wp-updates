<?php
/**
 * Collects A, AAAA, MX, NS, TXT, SOA and CAA records for the scope domain (Section 5.1, 12).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\Dns;

final class DnsCollector extends AbstractCollector {
    public function key(): string {
        return 'dns';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $record_types = $this->record_types();
        $data         = [];
        $limitations  = [];
        $failed       = 0;

        foreach ($record_types as $key => $type) {
            try {
                $data[ $key ] = Dns::query($context->domain, $type);
            } catch (\Throwable $exception) {
                ++$failed;
                $limitations[] = "Failed to resolve {$key} records: {$exception->getMessage()}";
                $data[ $key ]  = [];
            }
        }

        // CAA support depends on the underlying resolver library the PHP build was compiled
        // against - it is not guaranteed to exist (notably on some Windows builds). Reported
        // as null (never observed), never merged with "queried, found nothing" (empty array).
        if (! defined('DNS_CAA')) {
            $data['caa']   = null;
            $limitations[] = 'CAA record type is not supported by this PHP build (DNS_CAA is undefined).';
        }

        $status = match (true) {
            0 === $failed => CollectorStatus::Succeeded,
            $failed < count($record_types) => CollectorStatus::PartiallySucceeded,
            default => CollectorStatus::Failed,
        };

        return $this->result($status, $started, 'system_resolver', $data, $limitations);
    }

    /**
     * @return array<string,int>
     */
    private function record_types(): array {
        $types = [
            'a'    => DNS_A,
            'aaaa' => DNS_AAAA,
            'mx'   => DNS_MX,
            'ns'   => DNS_NS,
            'txt'  => DNS_TXT,
            'soa'  => DNS_SOA,
        ];

        if (defined('DNS_CAA')) {
            $types['caa'] = constant('DNS_CAA');
        }

        return $types;
    }
}
