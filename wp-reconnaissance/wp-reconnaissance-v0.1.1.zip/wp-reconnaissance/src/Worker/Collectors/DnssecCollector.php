<?php
/**
 * Reports the DNSSEC validation state for the domain, distinguishing validated, insecure,
 * bogus and indeterminate outcomes rather than inferring validation from DNSKEY presence alone
 * (Section 12.1).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\DnssecProbe;

final class DnssecCollector extends AbstractCollector {
    private const RESOLVER = '1.1.1.1';
    private const RCODE_SERVFAIL = 2;

    public function key(): string {
        return 'dnssec';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $probe = DnssecProbe::query($context->domain, self::RESOLVER, $context->timeout_for('dnssec'));

        $state = match (true) {
            self::RCODE_SERVFAIL === $probe['rcode'] => 'bogus',
            $probe['ancount'] > 0 && $probe['ad'] => 'validated',
            $probe['ancount'] > 0 && ! $probe['ad'] => 'indeterminate',
            0 === $probe['rcode'] => 'insecure',
            default => 'indeterminate',
        };

        $data = [
            'state'      => $state,
            'has_dnskey' => $probe['ancount'] > 0,
            'ad_bit_set' => $probe['ad'],
            'resolver'   => self::RESOLVER,
        ];

        return $this->result(
            CollectorStatus::Succeeded,
            $started,
            'dns_query:' . self::RESOLVER,
            $data,
            [ 'Validation state reflects a single query to resolver ' . self::RESOLVER . ", not an independently validated parent-DS-to-child-DNSKEY chain." ]
        );
    }
}
