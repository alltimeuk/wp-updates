<?php
/**
 * Maps manifest collector keys to their implementation.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

final class CollectorRegistry {
    /**
     * @return array<string,CollectorInterface>
     */
    public static function default_collectors(): array {
        $collectors = [
            new RegistrationCollector(),
            new DnsCollector(),
            new DnssecCollector(),
            new MailCollector(),
            new HttpCollector(),
            new TlsCollector(),
            new CertificateTransparencyCollector(),
            new SubdomainCollector(),
            new LookalikeCollector(),
        ];

        $indexed = [];
        foreach ($collectors as $collector) {
            $indexed[ $collector->key() ] = $collector;
        }

        return $indexed;
    }
}
