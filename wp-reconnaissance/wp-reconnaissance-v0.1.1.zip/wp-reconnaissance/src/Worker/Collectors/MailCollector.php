<?php
/**
 * Collects MX/provider inference, recursive SPF evaluation, DMARC policy and DKIM selector
 * evidence (Section 5.1, 12.1).
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\Dns;
use Alltime\WPReconnaissance\Worker\Support\SpfEvaluator;

final class MailCollector extends AbstractCollector {
    /** @var array<string,string[]> */
    private const PROVIDER_SIGNATURES = [
        'Microsoft 365'    => [ 'outlook.com', 'protection.outlook.com' ],
        'Google Workspace' => [ 'google.com', 'googlemail.com', 'aspmx.l.google.com' ],
        'Zoho Mail'        => [ 'zoho.com', 'zohomail.com' ],
        'Amazon SES'       => [ 'amazonses.com' ],
    ];

    public function key(): string {
        return 'mail';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $limitations = [];

        $mx_hosts = array_map(
            static fn ( array $record ): string => (string) ( $record['target'] ?? '' ),
            $this->sort_by_priority(Dns::query($context->domain, DNS_MX))
        );

        $inferred_provider = $this->infer_provider($mx_hosts);

        $visited = [];
        $spf     = SpfEvaluator::evaluate($context->domain, $visited);
        if ($spf['lookup_count'] > 10) {
            $limitations[] = 'SPF evaluation exceeds the RFC 7208 10-lookup limit (permanent error).';
        }

        $dmarc = $this->collect_dmarc($context->domain);
        $dkim  = $this->collect_dkim($context->domain, $context->known_dkim_selectors);

        if (0 === count($context->known_dkim_selectors)) {
            $limitations[] = 'No DKIM selectors were configured; DKIM status is not_observable rather than absent.';
        }

        $data = [
            'mx_hosts'          => $mx_hosts,
            'inferred_provider' => $inferred_provider,
            'spf'               => $spf,
            'dmarc'             => $dmarc,
            'dkim'              => $dkim,
        ];

        $status = 0 === count($limitations) ? CollectorStatus::Succeeded : CollectorStatus::PartiallySucceeded;

        return $this->result($status, $started, 'system_resolver', $data, $limitations);
    }

    /**
     * @param array<int,array<string,mixed>> $records
     * @return array<int,array<string,mixed>>
     */
    private function sort_by_priority( array $records ): array {
        usort($records, static fn ( array $a, array $b ): int => ( $a['pri'] ?? 0 ) <=> ( $b['pri'] ?? 0 ));

        return $records;
    }

    /**
     * @param string[] $mx_hosts
     */
    private function infer_provider( array $mx_hosts ): ?string {
        foreach (self::PROVIDER_SIGNATURES as $provider => $signatures) {
            foreach ($mx_hosts as $host) {
                foreach ($signatures as $signature) {
                    if (str_ends_with($host, $signature)) {
                        return $provider;
                    }
                }
            }
        }

        return null;
    }

    /**
     * @return array<string,mixed>|null
     */
    private function collect_dmarc( string $domain ): ?array {
        $records = array_map(
            static fn ( array $record ): string => $record['txt'] ?? '',
            Dns::query("_dmarc.{$domain}", DNS_TXT)
        );
        $dmarc_records = array_values(array_filter($records, static fn ( string $txt ): bool => str_starts_with($txt, 'v=DMARC1')));

        if (0 === count($dmarc_records)) {
            return null;
        }

        $record = $dmarc_records[0];

        return [
            'record'           => $record,
            'policy'           => $this->extract_tag($record, 'p'),
            'subdomain_policy' => $this->extract_tag($record, 'sp'),
            'pct'              => null !== $this->extract_tag($record, 'pct') ? (int) $this->extract_tag($record, 'pct') : 100,
        ];
    }

    /**
     * @param string[] $selectors
     * @return array<int,array<string,mixed>>
     */
    private function collect_dkim( string $domain, array $selectors ): array {
        $results = [];

        foreach ($selectors as $selector) {
            $records = array_map(
                static fn ( array $record ): string => $record['txt'] ?? '',
                Dns::query("{$selector}._domainkey.{$domain}", DNS_TXT)
            );
            $dkim_records = array_values(array_filter($records, static fn ( string $txt ): bool => str_contains($txt, 'v=DKIM1') || str_contains($txt, 'p=')));

            if (0 === count($dkim_records)) {
                $results[] = [ 'selector' => $selector, 'status' => 'not_observable', 'revoked' => null ];
                continue;
            }

            $p_value = $this->extract_tag($dkim_records[0], 'p');

            $results[] = [
                'selector' => $selector,
                'status'   => 'observed',
                'record'   => $dkim_records[0],
                'revoked'  => null !== $p_value && '' === trim($p_value),
            ];
        }

        return $results;
    }

    private function extract_tag( string $record, string $tag ): ?string {
        if (1 === preg_match('/(?:^|;)\s*' . preg_quote($tag, '/') . '=([^;]*)/', $record, $matches)) {
            return trim($matches[1]);
        }

        return null;
    }
}
