<?php
/**
 * Wraps the WordPress user record for a customer account, per Section 18.2-18.3.
 *
 * The underlying identity remains an ordinary WordPress user (core password hashing, session
 * management retained, per Section 18.1); this only layers the plugin-owned attributes on top
 * via user meta, which is the WordPress-native place for lightweight per-user state.
 *
 * The organisation-level consent ledger described in Section 6.1.2/22.7 is a separate, larger
 * shared-platform subsystem that has not been built yet; the single `wpr_marketing_consent`
 * flag here is a minimal stand-in that only covers this one direct-marketing choice, not the
 * full purpose-by-purpose consent record the design specification calls for.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\AccountStatus;
use Alltime\WPReconnaissance\Support\Roles;

final class CustomerAccountRepository {

	private const META_ORGANISATION_ID   = 'wpr_organisation_id';
	private const META_ACCOUNT_STATUS    = 'wpr_account_status';
	private const META_MARKETING_CONSENT = 'wpr_marketing_consent';
	private const META_MARKETING_AT      = 'wpr_marketing_consent_at';

	public function find_by_email( string $email ): ?CustomerAccount {
		$user = get_user_by( 'email', $email );

		return false !== $user ? $this->to_account( $user ) : null;
	}

	public function find( int $user_id ): ?CustomerAccount {
		$user = get_user_by( 'id', $user_id );

		return false !== $user ? $this->to_account( $user ) : null;
	}

	/**
	 * Creates the underlying WordPress user with the customer role and the plugin's
	 * organisation/status/consent meta. Password hashing is entirely WordPress core's - this
	 * never touches password material directly.
	 */
	public function create(
		string $email,
		string $password,
		string $given_name,
		string $family_name,
		int $organisation_id,
		bool $marketing_consent
	): CustomerAccount {
		$user_id = wp_insert_user(
			array(
				'user_login'   => $this->unique_login( $email ),
				'user_email'   => $email,
				'user_pass'    => $password,
				'first_name'   => $given_name,
				'last_name'    => $family_name,
				'display_name' => trim( "{$given_name} {$family_name}" ),
				'role'         => Roles::CUSTOMER_ROLE,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			throw new \RuntimeException( esc_html( $user_id->get_error_message() ) );
		}

		update_user_meta( $user_id, self::META_ORGANISATION_ID, $organisation_id );
		update_user_meta( $user_id, self::META_ACCOUNT_STATUS, AccountStatus::PendingEmailVerification->value );
		update_user_meta( $user_id, self::META_MARKETING_CONSENT, $marketing_consent ? '1' : '0' );
		update_user_meta( $user_id, self::META_MARKETING_AT, current_time( 'mysql', true ) );

		return $this->find_or_fail( $user_id );
	}

	public function set_status( int $user_id, AccountStatus $status ): void {
		update_user_meta( $user_id, self::META_ACCOUNT_STATUS, $status->value );
	}

	/**
	 * Ensures the account cannot be reused with old sessions after a sensitive change
	 * (password reset, status change) - Section 18.1: "rotate sessions after password and
	 * material security changes."
	 */
	public function destroy_all_sessions( int $user_id ): void {
		\WP_Session_Tokens::get_instance( $user_id )->destroy_all();
	}

	private function find_or_fail( int $user_id ): CustomerAccount {
		$account = $this->find( $user_id );

		if ( null === $account ) {
			throw new \RuntimeException( esc_html( "Customer account {$user_id} was expected to exist but could not be loaded." ) );
		}

		return $account;
	}

	private function to_account( \WP_User $user ): CustomerAccount {
		$status = AccountStatus::tryFrom( (string) get_user_meta( $user->ID, self::META_ACCOUNT_STATUS, true ) )
			?? AccountStatus::PendingEmailVerification;

		return new CustomerAccount(
			user_id: $user->ID,
			email: $user->user_email,
			given_name: $user->first_name,
			family_name: $user->last_name,
			organisation_id: (int) get_user_meta( $user->ID, self::META_ORGANISATION_ID, true ),
			status: $status
		);
	}

	private function unique_login( string $email ): string {
		$local_part = strstr( $email, '@', true );
		$base       = sanitize_user( false !== $local_part ? $local_part : $email, true );
		$base       = '' !== $base ? $base : 'customer';
		$login      = $base;

		$suffix = 2;
		while ( username_exists( $login ) ) {
			$login = "{$base}{$suffix}";
			++$suffix;
		}

		return $login;
	}
}
