<?php
/**
 * Handles new customer registration, per Section 18.2 and the journey in Section 5.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Auth\Exceptions\RegistrationException;
use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class RegistrationService {

	private const MINIMUM_PASSWORD_LENGTH       = 12;
	public const EMAIL_VERIFICATION_TTL_SECONDS = 24 * HOUR_IN_SECONDS;

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @throws RegistrationException When the submitted input itself is invalid. Never thrown
	 *                                 for an email address that is already registered.
	 */
	public function register(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged,
		bool $marketing_consent
	): RegistrationResult {
		$this->validate(
			$given_name,
			$family_name,
			$email,
			$organisation_name,
			$password,
			$password_confirmation,
			$terms_accepted,
			$privacy_acknowledged
		);

		$existing = $this->accounts->find_by_email( $email );

		if ( null !== $existing ) {
			// Section 18.1: do not reveal that this address is already registered. The caller
			// shows the identical "check your email" response either way.
			$this->audit_logger->log( 'registration.duplicate_attempt', 'customer_account', $existing->user_id, outcome: 'rejected' );

			return new RegistrationResult( is_new: false, account: null, verification_token: null );
		}

		$organisation = $this->organisations->create(
			$organisation_name,
			$this->organisations->unique_slug( $organisation_name )
		);

		$account = $this->accounts->create(
			$email,
			$password,
			$given_name,
			$family_name,
			(int) $organisation->id,
			$marketing_consent
		);

		$this->audit_logger->log( 'registration.created', 'customer_account', $account->user_id, $account->user_id );

		$verification_token = $this->tokens->issue( $account->user_id, TokenType::EmailVerification, self::EMAIL_VERIFICATION_TTL_SECONDS );

		return new RegistrationResult( is_new: true, account: $account, verification_token: $verification_token );
	}

	private function validate(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged
	): void {
		if ( '' === trim( $given_name ) || '' === trim( $family_name ) ) {
			throw new RegistrationException( 'Given name and family name are required.' );
		}

		if ( ! is_email( $email ) ) {
			throw new RegistrationException( 'A valid business email address is required.' );
		}

		if ( '' === trim( $organisation_name ) ) {
			throw new RegistrationException( 'Organisation name is required.' );
		}

		if ( strlen( $password ) < self::MINIMUM_PASSWORD_LENGTH ) {
			throw new RegistrationException( 'Password must be at least ' . self::MINIMUM_PASSWORD_LENGTH . ' characters long.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- an exception message is not browser output; AuthBootstrap escapes it via esc_html() when rendering it.
		}

		if ( $password !== $password_confirmation ) {
			throw new RegistrationException( 'Password and confirmation do not match.' );
		}

		if ( ! $terms_accepted ) {
			throw new RegistrationException( 'You must accept the service terms to register.' );
		}

		if ( ! $privacy_acknowledged ) {
			throw new RegistrationException( 'You must acknowledge the privacy notice to register.' );
		}
	}
}
