<?php
/**
 * A customer account: the WordPress user identity plus the plugin-owned attributes layered on
 * top of it (organisation link, lifecycle status, marketing preference).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\AccountStatus;

final class CustomerAccount {

	public function __construct(
		public readonly int $user_id,
		public readonly string $email,
		public readonly string $given_name,
		public readonly string $family_name,
		public readonly int $organisation_id,
		public readonly AccountStatus $status
	) {}
}
