<?php
/**
 * Minimal per-IP throttle for the public auth endpoints (registration, login, password reset),
 * per Section 18.1 "apply throttling and bot controls".
 *
 * This is a lightweight transient-based counter, not the full layered anti-abuse system
 * (CAPTCHA adapter, disposable-email detection, block/allow lists, admin review queue)
 * described in Section 5.6 - that remains a separate, larger piece of work.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

final class RateLimiter {

	/**
	 * Increments the counter for this action/identifier and returns whether the request should
	 * be allowed to proceed.
	 */
	public function allow( string $action, string $identifier, int $max_attempts, int $window_seconds ): bool {
		$key   = 'wpr_rl_' . md5( "{$action}:{$identifier}" );
		$count = (int) get_transient( $key );

		if ( $count >= $max_attempts ) {
			return false;
		}

		if ( 0 === $count ) {
			set_transient( $key, 1, $window_seconds );
		} else {
			set_transient( $key, $count + 1, $window_seconds );
		}

		return true;
	}

	public function client_ip(): string {
		$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only rate-limiter key, not echoed or persisted as trusted data.

		return is_string( $ip ) ? $ip : '0.0.0.0';
	}
}
