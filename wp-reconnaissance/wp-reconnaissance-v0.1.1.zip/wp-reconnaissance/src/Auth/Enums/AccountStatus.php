<?php
/**
 * Customer account lifecycle states, per Section 18.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth\Enums;

enum AccountStatus: string {
	case PendingEmailVerification = 'pending_email_verification';
	case Active                   = 'active';
	case Restricted               = 'restricted';
	case Suspended                = 'suspended';
	case PrivacyRequestPending    = 'privacy_request_pending';
	case ScheduledForDeletion     = 'scheduled_for_deletion';
	case Deleted                  = 'deleted';

	public function permits_login(): bool {
		return self::Active === $this || self::Restricted === $this;
	}
}
