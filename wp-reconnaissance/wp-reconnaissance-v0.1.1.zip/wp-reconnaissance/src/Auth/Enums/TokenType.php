<?php
/**
 * Types of single-use authentication token stored in `wpr_auth_tokens`, per Section 18.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth\Enums;

enum TokenType: string {
	case EmailVerification = 'email_verification';
	case PasswordReset     = 'password_reset';
}
