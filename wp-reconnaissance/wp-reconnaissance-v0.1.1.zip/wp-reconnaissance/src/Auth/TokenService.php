<?php
/**
 * Issues and consumes short-lived, single-use, hashed tokens for email verification and
 * password reset, per Section 18.1.
 *
 * Only the SHA-256 hash of a token is ever persisted; the raw value exists only in memory long
 * enough to be embedded in the verification/reset link, matching the "do not store plaintext
 * verification or reset tokens" requirement.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Data\Schema;

final class TokenService {

	private const RAW_TOKEN_BYTES = 32;

	/**
	 * @return string The raw token. Callers must embed this in a URL/email immediately - it
	 *                 cannot be recovered once this call returns.
	 */
	public function issue( int $user_id, TokenType $type, int $ttl_seconds ): string {
		global $wpdb;

		$raw  = bin2hex( random_bytes( self::RAW_TOKEN_BYTES ) );
		$hash = hash( 'sha256', $raw );

		// Invalidate any outstanding tokens of this type for this user - only the most recently
		// issued token should ever be usable.
		$this->invalidate_outstanding( $user_id, $type );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'auth_tokens' ),
			array(
				'user_id'    => $user_id,
				'token_hash' => $hash,
				'type'       => $type->value,
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + $ttl_seconds ),
				'created_at' => current_time( 'mysql', true ),
			)
		);

		return $raw;
	}

	/**
	 * Validates and consumes a raw token. Returns the associated user ID once, and only once -
	 * a second call with the same token always returns null.
	 */
	public function consume( string $raw_token, TokenType $type ): ?int {
		global $wpdb;

		$table = Schema::table( 'auth_tokens' );
		$hash  = hash( 'sha256', $raw_token );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE token_hash = %s AND type = %s AND used_at IS NULL LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$hash,
				$type->value
			),
			ARRAY_A
		);

		if ( null === $row ) {
			return null;
		}

		if ( strtotime( (string) $row['expires_at'] ) < time() ) {
			return null;
		}

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array( 'used_at' => current_time( 'mysql', true ) ),
			array( 'id' => (int) $row['id'] )
		);

		return (int) $row['user_id'];
	}

	private function invalidate_outstanding( int $user_id, TokenType $type ): void {
		global $wpdb;

		$table = Schema::table( 'auth_tokens' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array( 'used_at' => current_time( 'mysql', true ) ),
			array(
				'user_id' => $user_id,
				'type'    => $type->value,
			)
		);
	}
}
