<?php
/**
 * Handles the forgot-password / reset-password flow, per Section 18.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class PasswordResetService {

	private const RESET_TTL_SECONDS       = HOUR_IN_SECONDS;
	private const MINIMUM_PASSWORD_LENGTH = 12;

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * Always returns the same shape regardless of whether the address is registered - the
	 * caller shows an identical "if an account exists, an email has been sent" message either
	 * way (Section 18.1 anti-enumeration).
	 */
	public function request( string $email ): ?string {
		$account = $this->accounts->find_by_email( $email );

		if ( null === $account ) {
			return null;
		}

		$this->audit_logger->log( 'account.password_reset_requested', 'customer_account', $account->user_id, $account->user_id );

		return $this->tokens->issue( $account->user_id, TokenType::PasswordReset, self::RESET_TTL_SECONDS );
	}

	/**
	 * @throws \InvalidArgumentException When the new password fails minimum requirements. Not
	 *                                     thrown for an invalid/expired token - callers check
	 *                                     the boolean return instead, again to avoid leaking
	 *                                     token state.
	 */
	public function reset( string $raw_token, string $new_password ): bool {
		if ( strlen( $new_password ) < self::MINIMUM_PASSWORD_LENGTH ) {
			throw new \InvalidArgumentException( esc_html( 'Password must be at least ' . self::MINIMUM_PASSWORD_LENGTH . ' characters long.' ) );
		}

		$user_id = $this->tokens->consume( $raw_token, TokenType::PasswordReset );

		if ( null === $user_id ) {
			return false;
		}

		wp_set_password( $new_password, $user_id );

		// Section 18.1: rotate sessions after a password change - every existing session,
		// including the one that may have been hijacked, is invalidated.
		$this->accounts->destroy_all_sessions( $user_id );

		$this->audit_logger->log( 'account.password_reset_completed', 'customer_account', $user_id, $user_id );

		return true;
	}
}
