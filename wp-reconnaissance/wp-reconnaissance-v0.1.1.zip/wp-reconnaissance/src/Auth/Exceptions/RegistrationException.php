<?php
/**
 * Thrown for genuine input-validation failures during registration (missing fields, password
 * mismatch, terms not accepted). Never thrown for "this email is already registered" - that
 * case is handled as a soft success to avoid account enumeration (Section 18.1).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth\Exceptions;

final class RegistrationException extends \RuntimeException {}
