<?php
/**
 * Dedicated customer authentication route bootstrap, per Section 18.1.
 *
 * Customers never register, sign in, reset passwords or manage their account through the
 * native wp-login.php presentation. The underlying identity records remain ordinary WordPress
 * users (core password hashing and session handling are retained via wp_insert_user(),
 * wp_signon(), wp_set_password()); this class owns the public routes, form handling, validation
 * messages and redirections.
 *
 * Rendering here is deliberately minimal inline HTML - not the branded, ACF-driven templates
 * Section 9.3 describes. It exists so the routes are genuinely functional end-to-end; a real
 * template/theme layer is later Phase 1 work.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\AccountStatus;
use Alltime\WPReconnaissance\Auth\Exceptions\RegistrationException;
use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;
use Alltime\WPReconnaissance\Integrations\MailManager;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Support\Capabilities;
use Alltime\WPReconnaissance\Support\Roles;

final class AuthBootstrap {

	private const QUERY_VAR = 'wpr_customer_route';

	/** @var string[] */
	private const ROUTES = array(
		'register',
		'verify-email',
		'login',
		'forgot-password',
		'reset-password',
		'account',
		'security',
		'privacy',
		'tools',
	);

	private RateLimiter $rate_limiter;

	public function __construct() {
		$this->rate_limiter = new RateLimiter();
	}

	public function boot(): void {
		add_action( 'init', array( $this, 'register_rewrite_rules' ) );
		add_filter( 'query_vars', array( $this, 'register_query_var' ) );
		add_action( 'template_redirect', array( $this, 'dispatch' ) );
	}

	public function register_rewrite_rules(): void {
		foreach ( self::ROUTES as $slug ) {
			add_rewrite_rule(
				'^customer/' . preg_quote( $slug, '/' ) . '/?$',
				'index.php?' . self::QUERY_VAR . '=' . $slug,
				'top'
			);
		}
	}

	/**
	 * @param string[] $vars
	 * @return string[]
	 */
	public function register_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	public function dispatch(): void {
		$route = get_query_var( self::QUERY_VAR );

		if ( ! is_string( $route ) || '' === $route || ! in_array( $route, self::ROUTES, true ) ) {
			return;
		}

		status_header( 200 );
		nocache_headers();

		match ( $route ) {
			'register' => $this->handle_register(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->handle_login(),
			'forgot-password' => $this->handle_forgot_password(),
			'reset-password' => $this->handle_reset_password(),
			'account' => $this->handle_account(),
			default => $this->render_placeholder( $route ),
		};

		exit;
	}

	// -----------------------------------------------------------------------------------
	// Registration
	// -----------------------------------------------------------------------------------

	private function handle_register(): void {
		if ( ! $this->is_post() ) {
			$this->render_register_form();
			return;
		}

		if ( ! $this->verify_nonce( 'wpr_register' ) || ! $this->rate_limiter->allow( 'register', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS ) ) {
			$this->render_register_form( __( 'Please try again in a little while.', 'wp-reconnaissance' ) );
			return;
		}

		try {
			$result = ( new RegistrationService() )->register(
				$this->post_field( 'given_name' ),
				$this->post_field( 'family_name' ),
				$this->post_field( 'email' ),
				$this->post_field( 'organisation_name' ),
				$this->post_field( 'password' ),
				$this->post_field( 'password_confirmation' ),
				$this->post_checked( 'terms_accepted' ),
				$this->post_checked( 'privacy_acknowledged' ),
				$this->post_checked( 'marketing_consent' )
			);
		} catch ( RegistrationException $exception ) {
			$this->render_register_form( $exception->getMessage() );
			return;
		}

		// Section 18.1: identical response whether or not the address was already registered.
		if ( $result->is_new && null !== $result->account && null !== $result->verification_token ) {
			$this->send_verification_email( $result->account, $result->verification_token );
		}

		$this->render_page(
			__( 'Check your email', 'wp-reconnaissance' ),
			'<p>' . esc_html__( 'If your details were accepted, we have sent a verification link to the email address you provided. Follow it to activate your account.', 'wp-reconnaissance' ) . '</p>'
		);
	}

	private function render_register_form( ?string $error = null ): void {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpr_register', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Given name', 'wp-reconnaissance' ) . '<br><input type="text" name="given_name" required></label></p>
				<p><label>' . esc_html__( 'Family name', 'wp-reconnaissance' ) . '<br><input type="text" name="family_name" required></label></p>
				<p><label>' . esc_html__( 'Business email address', 'wp-reconnaissance' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Organisation name', 'wp-reconnaissance' ) . '<br><input type="text" name="organisation_name" required></label></p>
				<p><label>' . esc_html__( 'Password', 'wp-reconnaissance' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm password', 'wp-reconnaissance' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><label><input type="checkbox" name="terms_accepted" value="1" required> ' . esc_html__( 'I accept the service terms.', 'wp-reconnaissance' ) . '</label></p>
				<p><label><input type="checkbox" name="privacy_acknowledged" value="1" required> ' . esc_html__( 'I acknowledge the privacy notice.', 'wp-reconnaissance' ) . '</label></p>
				<p><label><input type="checkbox" name="marketing_consent" value="1"> ' . esc_html__( 'I would like to receive occasional marketing updates (optional).', 'wp-reconnaissance' ) . '</label></p>
				<p><button type="submit">' . esc_html__( 'Create account', 'wp-reconnaissance' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Already have an account? Sign in.', 'wp-reconnaissance' ) . '</a></p>';

		$this->render_page( __( 'Create your account', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Email verification
	// -----------------------------------------------------------------------------------

	private function handle_verify_email(): void {
		$token = $this->get_field( 'token' );

		if ( '' === $token ) {
			$this->render_page( __( 'Verify your email', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No verification token was supplied.', 'wp-reconnaissance' ) . '</p>' );
			return;
		}

		$verified = ( new EmailVerificationService() )->verify( $token );

		$body = $verified
			? '<p>' . esc_html__( 'Your email address has been verified. You can now sign in.', 'wp-reconnaissance' ) . '</p><p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Sign in', 'wp-reconnaissance' ) . '</a></p>'
			: '<p>' . esc_html__( 'This verification link is invalid or has expired.', 'wp-reconnaissance' ) . '</p>';

		$this->render_page( __( 'Verify your email', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Login
	// -----------------------------------------------------------------------------------

	private function handle_login(): void {
		if ( ! $this->is_post() ) {
			$this->render_login_form();
			return;
		}

		if ( ! $this->verify_nonce( 'wpr_login' ) || ! $this->rate_limiter->allow( 'login', $this->rate_limiter->client_ip(), 10, 15 * MINUTE_IN_SECONDS ) ) {
			$this->render_login_form( __( 'Too many attempts. Please try again shortly.', 'wp-reconnaissance' ) );
			return;
		}

		$generic_error = __( 'Incorrect email address or password.', 'wp-reconnaissance' );

		$user = wp_signon(
			array(
				'user_login'    => $this->post_field( 'email' ),
				'user_password' => $this->post_field( 'password' ),
				'remember'      => true,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			$this->render_login_form( $generic_error );
			return;
		}

		if ( ! in_array( Roles::CUSTOMER_ROLE, (array) $user->roles, true ) ) {
			wp_logout();
			$this->render_login_form( $generic_error );
			return;
		}

		$account = ( new CustomerAccountRepository() )->find( $user->ID );

		if ( null === $account || ! $account->status->permits_login() ) {
			wp_logout();

			$message = null !== $account && AccountStatus::PendingEmailVerification === $account->status
				? __( 'Please verify your email address before signing in.', 'wp-reconnaissance' )
				: __( 'This account is not currently available. Contact support for help.', 'wp-reconnaissance' );

			$this->render_login_form( $message );
			return;
		}

		wp_safe_redirect( home_url( '/customer/account/' ) );
		exit;
	}

	private function render_login_form( ?string $error = null ): void {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpr_login', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Email address', 'wp-reconnaissance' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Password', 'wp-reconnaissance' ) . '<br><input type="password" name="password" required></label></p>
				<p><button type="submit">' . esc_html__( 'Sign in', 'wp-reconnaissance' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( home_url( '/customer/forgot-password/' ) ) . '">' . esc_html__( 'Forgotten your password?', 'wp-reconnaissance' ) . '</a></p>
			<p><a href="' . esc_url( home_url( '/customer/register/' ) ) . '">' . esc_html__( 'Create an account', 'wp-reconnaissance' ) . '</a></p>';

		$this->render_page( __( 'Sign in', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Forgot / reset password
	// -----------------------------------------------------------------------------------

	private function handle_forgot_password(): void {
		if ( ! $this->is_post() ) {
			$this->render_forgot_password_form();
			return;
		}

		$generic_notice = __( 'If an account exists for that address, we have sent password reset instructions.', 'wp-reconnaissance' );

		if ( ! $this->verify_nonce( 'wpr_forgot_password' ) || ! $this->rate_limiter->allow( 'forgot_password', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS ) ) {
			$this->render_page( __( 'Forgotten password', 'wp-reconnaissance' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
			return;
		}

		$email = $this->post_field( 'email' );
		$token = ( new PasswordResetService() )->request( $email );

		if ( null !== $token ) {
			$account = ( new CustomerAccountRepository() )->find_by_email( $email );

			if ( null !== $account ) {
				$this->send_password_reset_email( $account, $token );
			}
		}

		$this->render_page( __( 'Forgotten password', 'wp-reconnaissance' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
	}

	private function render_forgot_password_form(): void {
		$body = '
			<form method="post">
				' . wp_nonce_field( 'wpr_forgot_password', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Email address', 'wp-reconnaissance' ) . '<br><input type="email" name="email" required></label></p>
				<p><button type="submit">' . esc_html__( 'Send reset instructions', 'wp-reconnaissance' ) . '</button></p>
			</form>';

		$this->render_page( __( 'Forgotten password', 'wp-reconnaissance' ), $body );
	}

	private function handle_reset_password(): void {
		if ( ! $this->is_post() ) {
			$token = $this->get_field( 'token' );

			if ( '' === $token ) {
				$this->render_page( __( 'Reset password', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No reset token was supplied.', 'wp-reconnaissance' ) . '</p>' );
				return;
			}

			$this->render_reset_password_form( $token );
			return;
		}

		if ( ! $this->verify_nonce( 'wpr_reset_password' ) ) {
			$this->render_page( __( 'Reset password', 'wp-reconnaissance' ), '<p>' . esc_html__( 'This link is invalid or has expired.', 'wp-reconnaissance' ) . '</p>' );
			return;
		}

		$token        = $this->post_field( 'token' );
		$password     = $this->post_field( 'password' );
		$confirmation = $this->post_field( 'password_confirmation' );

		if ( $password !== $confirmation ) {
			$this->render_reset_password_form( $token, __( 'Password and confirmation do not match.', 'wp-reconnaissance' ) );
			return;
		}

		try {
			$succeeded = ( new PasswordResetService() )->reset( $token, $password );
		} catch ( \InvalidArgumentException $exception ) {
			$this->render_reset_password_form( $token, $exception->getMessage() );
			return;
		}

		$body = $succeeded
			? '<p>' . esc_html__( 'Your password has been updated. You can now sign in.', 'wp-reconnaissance' ) . '</p><p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Sign in', 'wp-reconnaissance' ) . '</a></p>'
			: '<p>' . esc_html__( 'This link is invalid or has expired.', 'wp-reconnaissance' ) . '</p>';

		$this->render_page( __( 'Reset password', 'wp-reconnaissance' ), $body );
	}

	private function render_reset_password_form( string $token, ?string $error = null ): void {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpr_reset_password', '_wpnonce', true, false ) . '
				<input type="hidden" name="token" value="' . esc_attr( $token ) . '">
				<p><label>' . esc_html__( 'New password', 'wp-reconnaissance' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm new password', 'wp-reconnaissance' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><button type="submit">' . esc_html__( 'Update password', 'wp-reconnaissance' ) . '</button></p>
			</form>';

		$this->render_page( __( 'Reset password', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Account
	// -----------------------------------------------------------------------------------

	private function handle_account(): void {
		if ( ! is_user_logged_in() || ! current_user_can( Capabilities::VIEW_ASSIGNED_ORG ) ) {
			wp_safe_redirect( home_url( '/customer/login/' ) );
			exit;
		}

		if ( 'logout' === $this->get_field( 'wpr_action' ) && $this->verify_nonce( 'wpr_logout', '_wpnonce', 'GET' ) ) {
			wp_logout();
			wp_safe_redirect( home_url( '/customer/login/' ) );
			exit;
		}

		$account = ( new CustomerAccountRepository() )->find( get_current_user_id() );

		if ( null === $account ) {
			wp_safe_redirect( home_url( '/customer/login/' ) );
			exit;
		}

		$logout_url = wp_nonce_url( home_url( '/customer/account/?wpr_action=logout' ), 'wpr_logout' );

		$body = '
			<p>' . esc_html__( 'Name', 'wp-reconnaissance' ) . ': ' . esc_html( trim( "{$account->given_name} {$account->family_name}" ) ) . '</p>
			<p>' . esc_html__( 'Email', 'wp-reconnaissance' ) . ': ' . esc_html( $account->email ) . '</p>
			<p>' . esc_html__( 'Account status', 'wp-reconnaissance' ) . ': ' . esc_html( $account->status->value ) . '</p>
			<p><a href="' . esc_url( $logout_url ) . '">' . esc_html__( 'Sign out', 'wp-reconnaissance' ) . '</a></p>';

		$this->render_page( __( 'Your account', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Mail delivery (best-effort; see Section 22 - no mail provider is implemented yet)
	// -----------------------------------------------------------------------------------

	private function send_verification_email( CustomerAccount $account, string $token ): void {
		$link = home_url( '/customer/verify-email/?token=' . rawurlencode( $token ) );

		$this->deliver_or_log(
			$account->email,
			'verify_email',
			MailPurpose::AccountSecurity,
			__( 'Verify your email address', 'wp-reconnaissance' ),
			sprintf( '<p>Follow this link to verify your email address: <a href="%1$s">%1$s</a></p>', esc_url( $link ) )
		);
	}

	private function send_password_reset_email( CustomerAccount $account, string $token ): void {
		$link = home_url( '/customer/reset-password/?token=' . rawurlencode( $token ) );

		$this->deliver_or_log(
			$account->email,
			'password_reset',
			MailPurpose::AccountSecurity,
			__( 'Reset your password', 'wp-reconnaissance' ),
			sprintf( '<p>Follow this link to reset your password: <a href="%1$s">%1$s</a></p>', esc_url( $link ) )
		);
	}

	/**
	 * Sends via the configured mail provider if one is active; otherwise (and on any delivery
	 * failure) logs the message so the flow remains testable end-to-end while Section 22's mail
	 * providers are not yet implemented. This is a development aid, not a production delivery
	 * path - it must be removed once Gmail API/SES sending is built.
	 */
	private function deliver_or_log( string $to, string $template, MailPurpose $purpose, string $subject, string $html_body ): void {
		$provider = ( new MailManager() )->active_provider();

		if ( null !== $provider ) {
			try {
				$provider->send( new QueuedMessage( wp_generate_uuid4(), $to, $template, $purpose, $subject, $html_body ) );
				return;
			} catch ( MailDeliveryException $exception ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- temporary development aid; see method docblock.
				error_log( "wpr-mail-undelivered to={$to} template={$template}: {$exception->getMessage()}" );
			}
		}

		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- temporary development aid; see method docblock.
		error_log( "wpr-mail-not-configured to={$to} template={$template} body={$html_body}" );
	}

	// -----------------------------------------------------------------------------------
	// Shared helpers
	// -----------------------------------------------------------------------------------

	private function render_placeholder( string $route ): void {
		$this->render_page(
			__( 'WP-Reconnaissance', 'wp-reconnaissance' ),
			'<p>' . esc_html__( 'This customer portal route is part of the Phase 1 build and is not yet implemented.', 'wp-reconnaissance' ) . '</p>'
		);
	}

	private function render_page( string $title, string $body ): void {
		echo '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html( $title ) . '</title></head><body>';
		echo '<h1>' . esc_html( $title ) . '</h1>';
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $body is assembled from esc_html()/esc_attr()/esc_url()-escaped fragments and wp_nonce_field() by every caller.
		echo '</body></html>';
	}

	private function error_html( ?string $error ): string {
		return null !== $error ? '<p role="alert">' . esc_html( $error ) . '</p>' : '';
	}

	private function is_post(): bool {
		return 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' );
	}

	private function post_field( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified by the caller before any $_POST field is read.
		return isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : '';
	}

	private function post_checked( string $name ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified by the caller before any $_POST field is read.
		return isset( $_POST[ $name ] ) && '' !== $_POST[ $name ];
	}

	private function get_field( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only lookup routes (verify-email/reset-password token, logout confirmation); state-changing actions verify their own nonce separately.
		return isset( $_GET[ $name ] ) && is_string( $_GET[ $name ] ) ? sanitize_text_field( wp_unslash( $_GET[ $name ] ) ) : '';
	}

	private function verify_nonce( string $action, string $field = '_wpnonce', string $method = 'POST' ): bool {
		$source = 'GET' === $method ? $_GET : $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing -- this *is* the nonce verification helper.
		$nonce  = isset( $source[ $field ] ) && is_string( $source[ $field ] ) ? wp_unslash( $source[ $field ] ) : '';

		return '' !== $nonce && false !== wp_verify_nonce( $nonce, $action );
	}
}
