<?php
/**
 * Outcome of a registration attempt. `is_new` is deliberately not exposed to the visitor - the
 * front-end controller must show the same generic message regardless, per Section 18.1's
 * anti-enumeration requirement. It exists only for server-side logging.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

final class RegistrationResult {

	public function __construct(
		public readonly bool $is_new,
		public readonly ?CustomerAccount $account,
		public readonly ?string $verification_token
	) {}
}
