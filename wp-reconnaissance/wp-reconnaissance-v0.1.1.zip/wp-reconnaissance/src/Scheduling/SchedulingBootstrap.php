<?php
/**
 * Scheduling module bootstrap, per Section 15.
 *
 * Durable execution must not rely solely on a single WP-Cron callback. This registers the
 * Action Scheduler hook this plugin will use once job dispatch is implemented; if Action
 * Scheduler is not available (it ships bundled with WooCommerce/Action Scheduler-aware
 * plugins, or must be required as a Composer dependency), the plugin falls back to WP-Cron and
 * an administrator-visible warning rather than failing silently.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Scheduling;

final class SchedulingBootstrap {

	public const RUN_DUE_ASSESSMENTS_HOOK = 'wpr_run_due_assessments';

	public function boot(): void {
		add_action( self::RUN_DUE_ASSESSMENTS_HOOK, array( $this, 'run_due_assessments' ) );

		add_action( 'admin_init', array( $this, 'maybe_warn_missing_durable_queue' ) );
	}

	/**
	 * Dispatches manifests for scopes whose monitoring schedule is due. Not yet implemented -
	 * depends on the scope/profile query and job-creation service.
	 */
	public function run_due_assessments(): void {}

	public function maybe_warn_missing_durable_queue(): void {
		if ( function_exists( 'as_schedule_recurring_action' ) ) {
			return;
		}

		add_action(
			'admin_notices',
			static function (): void {
				if ( ! current_user_can( 'activate_plugins' ) ) {
					return;
				}

				printf(
					'<div class="notice notice-warning"><p>%s</p></div>',
					esc_html__( 'WP-Reconnaissance works best with Action Scheduler for durable, long-running job execution. It is currently unavailable, so scheduled assessments will fall back to WP-Cron.', 'wp-reconnaissance' )
				);
			}
		);
	}
}
