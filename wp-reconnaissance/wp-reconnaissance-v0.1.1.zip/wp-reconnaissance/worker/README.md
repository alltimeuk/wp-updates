# WP-Reconnaissance collection worker

PHP 8.2+ collection engine for the Domain Reconnaissance tool. This directory (together with
`src/Worker/`) is a standalone artefact: it accepts a versioned job manifest, performs only the
collectors it is told to run, and emits a single normalised evidence document. It never talks to
the WordPress database, never holds WordPress credentials, and never makes scoring or
customer-access decisions - see `schemas/job-manifest.schema.json` and
`schemas/evidence.schema.json` in the plugin root for the contracts this worker must honour.

Although the worker is written in the same language as the rest of the plugin, it is
deliberately run as a **separate OS process** (via the local execution adapter's `proc_open()`
call, or over HTTPS by the future remote worker adapter) rather than called in-process as a PHP
class. That keeps a worker crash, timeout or runaway resource use from ever taking a web request
down with it, and lets it run under its own CLI `php.ini` limits independent of the web SAPI's.

## Running it

```bash
php collect.php --manifest=./manifest.json
```

The evidence document is written to stdout as JSON. Progress/diagnostic lines are written to
stderr so stdout stays parseable. Exit codes:

| Code | Meaning                                            |
|------|-----------------------------------------------------|
| 0    | Evidence document produced (individual collectors may still have failed - check each collector's `status`). |
| 64   | Manifest failed validation before any collection started. |
| 70   | Unexpected internal worker error. |

## Layout

- `collect.php` - thin CLI entry point. Reads the manifest (file or stdin), hands it to
  `Alltime\WPReconnaissance\Worker\Cli\Runner`, prints the evidence document, exits with the
  appropriate code. No business logic lives here.
- `src/Worker/Manifest/ManifestValidator.php` - validates the manifest against
  `schemas/job-manifest.schema.json` (via `opis/json-schema`) plus the business rules the schema
  can't express (expiry, domain-safety re-validation).
- `src/Worker/Evidence/CollectorResult.php` - the shared collector-result envelope every
  collector returns, matching `schemas/evidence.schema.json`'s `collectorResult` definition.
- `src/Worker/Collectors/*Collector.php` - one class per collector (`rdap`, `dns`, `dnssec`,
  `mail`, `http`, `tls`, `ct`, `subdomains`, `lookalikes`), matching Section 12 of the design
  specification. All extend `AbstractCollector`, which turns any uncaught exception into a
  `failed` result rather than aborting the whole job.
- `src/Worker/Support/*` - shared helpers (`Dns` wraps `dns_get_record()`, `HttpClient` wraps
  cURL, `SpfEvaluator` does the recursive SPF walk, `DnssecProbe` speaks raw DNS wire format for
  the one thing PHP's DNS API can't do - report the AD bit, `LookalikeGenerator` produces bounded
  typosquat candidates).

Nothing under `src/Worker/` calls a WordPress function; it only depends on `src/Domain/`, which
is equally WordPress-free (used for `DomainValidator` and the Public Suffix List fallback). This
is what keeps the worker portable enough to run standalone or, in Phase 3, inside its own
container - copy `src/Worker/`, `src/Domain/`, `worker/collect.php`, `schemas/`, `composer.json`
and `vendor/` and it runs with nothing else from the plugin.

## Status of the Section 12.1 corrections

This worker implements working collection for every collector, but several of the specific
corrections mandated by Section 12.1 are partial and flagged inline with `# TODO(12.1)` comments
where a production hardening pass is still required - notably: full RFC 7208 void-lookup
counting beyond the bounded recursive SPF walk, DNSSEC validation beyond a single query to a
known-validating public resolver (see `DnssecProbe`'s docblock for why the system resolver isn't
used instead), CT log deduplication edge cases, RDAP IANA-bootstrap caching, and IDNA
confusable-glyph handling for lookalike-domain generation. None of these gaps are hidden: where
a collector's evaluation is incomplete it returns `partially_succeeded` with an explicit entry
in `limitations`, never a stronger conclusion than the evidence supports.

## Requirements

- PHP 8.2 or later with the `curl`, `openssl`, `intl` and `json` extensions.
- Outbound network access to the destinations each enabled collector needs: the target domain's
  authoritative/recursive DNS, its web/TLS ports, `rdap.org`, `crt.sh`, and (for the DNSSEC
  collector) `1.1.1.1:53/udp`.
