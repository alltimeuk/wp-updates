<?php
/**
 * Domain Reconnaissance collection worker CLI entry point (Section 6.2, 12).
 *
 * Accepts a versioned job manifest (schemas/job-manifest.schema.json), validates it, runs only
 * the requested collectors with per-collector timeouts, and emits a single normalised evidence
 * document (schemas/evidence.schema.json) to stdout. Progress is written to stderr so stdout
 * stays parseable JSON.
 *
 * This is a deliberately thin script: all logic lives in Alltime\WPReconnaissance\Worker\*,
 * which has no WordPress dependency and is independently unit-tested. Keeping the worker a
 * separate PHP process (rather than a class WordPress calls in-process) preserves the
 * process-isolation properties Section 16 requires of the local execution adapter - a worker
 * crash, timeout or resource-limit breach cannot take the web request down with it, and it runs
 * under its own CLI php.ini (memory/time limits) independent of the web SAPI's.
 *
 * Usage:
 *   php collect.php --manifest=/path/to/manifest.json
 *   php collect.php < manifest.json   (reads from stdin when --manifest is omitted)
 *
 * Exit codes: 0 success (individual collectors may still report failure/timeout/etc. - check
 * each collector's `status`), 64 manifest failed validation, 70 unexpected internal error.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use Alltime\WPReconnaissance\Worker\Cli\Runner;
use Alltime\WPReconnaissance\Worker\Manifest\ManifestValidator;

/** @var string[] $arguments */
$arguments = $_SERVER['argv'] ?? [];

$manifest_path = null;

foreach ($arguments as $arg) {
    if (str_starts_with($arg, '--manifest=')) {
        $manifest_path = substr($arg, strlen('--manifest='));
    }
}

$manifest_index = array_search('--manifest', $arguments, true);
if (null === $manifest_path && false !== $manifest_index && isset($arguments[ $manifest_index + 1 ])) {
    $manifest_path = $arguments[ $manifest_index + 1 ];
}

if (null !== $manifest_path) {
    if (! is_file($manifest_path)) {
        fwrite(STDERR, "[wpr-worker] Manifest file not found: {$manifest_path}\n");
        exit(Runner::EXIT_MANIFEST_INVALID);
    }
    $manifest_json = file_get_contents($manifest_path);
} else {
    $manifest_json = stream_get_contents(STDIN);
}

if (false === $manifest_json) {
    fwrite(STDERR, "[wpr-worker] Unable to read the job manifest.\n");
    exit(Runner::EXIT_MANIFEST_INVALID);
}

$schema_path = realpath(__DIR__ . '/../schemas/job-manifest.schema.json');

if (false === $schema_path) {
    fwrite(STDERR, "[wpr-worker] Unable to locate schemas/job-manifest.schema.json.\n");
    exit(Runner::EXIT_INTERNAL_ERROR);
}

$runner            = new Runner(new ManifestValidator($schema_path));
[ $exit_code, $evidence ] = $runner->run($manifest_json);

if (null !== $evidence) {
    echo json_encode($evidence, JSON_UNESCAPED_SLASHES) . "\n";
}

exit($exit_code);
