=== WP-Reconnaissance ===
Contributors: alltimetechnologies
Tags: security, domain, dns, reconnaissance, customer-portal
Requires at least: 6.6
Tested up to: 6.6
Requires PHP: 8.2
Stable tag: 0.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A self-service customer portal through which a prospective or existing customer can create an account, submit an
authorised domain, obtain a free Domain Reconnaissance assessment and receive a formal report with a prioritised
remediation plan.

== Description ==

WP-Reconnaissance gives an organisation a defensible view of the externally observable controls associated with its
domains, email services, DNS, websites and public certificates. It is not a vulnerability scanner and does not claim
to prove compliance with any certification or regulatory standard.

The plugin separates scope and authorisation, evidence collection, evidence normalisation, rule evaluation, finding
and change management, customer-facing reporting, notifications, customer identity and account management, CRM lead
capture and consent management, and reusable tool registration and entitlement management.

Domain Reconnaissance is the first tool built on this platform. The underlying services (identity, profiles, consent,
communications, entitlements, tool execution, reporting, task management) are designed for reuse by later Alltime
self-service tools.

= Requirements =

* WordPress 6.6 or later
* PHP 8.2 or later
* Advanced Custom Fields 6.6.2 or later (required for branded content editing)
* PHP CLI with the curl, openssl, intl and json extensions on the collection worker host

= Explicit exclusions =

This plugin does not perform port scanning beyond explicitly implemented protocol connections, broad service
enumeration, web crawling, vulnerability exploitation, credential testing, password spraying, authenticated testing,
active takeover attempts, phishing simulation, domain/DNS modification or automatic remediation.

== Installation ==

1. Upload the plugin to `/wp-content/plugins/wp-reconnaissance/` or install through the WordPress plugin screen.
2. Activate the plugin.
3. Install and activate Advanced Custom Fields 6.6.2 or later.
4. Configure the collection worker under WP-Reconnaissance → Settings before enabling the local process adapter.
5. Configure a mail provider (Gmail API or Amazon SES) before customer-facing features go live.

See `docs/installation.md` for the full guide.

== Changelog ==

= 0.1.1 =
* No functional change; confirms the self-hosted update pipeline end to end (release build,
  package smoke test, and publish to the shared alltimeuk/wp-updates update server).

= 0.1.0 =
* Initial Phase 1 scaffold: plugin bootstrap, database migrations for the core reconnaissance tables, domain
  entities, execution adapter contracts, job manifest and evidence schemas, and the PHP collection worker.
