# Changelog

All notable changes to WP-Reconnaissance are documented in this file.

## 0.1.1 - 2026-08-12

No functional change. Confirms the self-hosted update pipeline end to end: release build,
package smoke test, GitHub Release, and publish to the shared `alltimeuk/wp-updates` update
server - `v0.1.0`'s deploy step failed because the deploy token wasn't yet reachable by this
(private) repository; see the fix below.

### Fixed

- `WP_UPDATES_TOKEN` was created as an organisation-level secret, but GitHub only delivers
  organisation secrets to private repositories on paid org plans; `alltimeuk` is on the Free
  plan, so the secret silently resolved empty in the release workflow. Switched to a
  repository-level secret on `wp-reconnaissance`, matching the existing `wp-questionnaires`
  setup.

## 0.1.0 - 2026-08-12

Initial Phase 1 scaffold and first working slice of the collection-to-findings pipeline and the
customer identity journey.

### Added

- Plugin bootstrap, Composer PSR-4 autoloading, and the PHPUnit/PHPCS/PHPStan quality-gate
  tooling.
- Database migrations for the core reconnaissance tables (organisations, scopes, profiles, jobs,
  observations, evidence, findings, finding events, audit log) and the customer auth-token store.
- Domain entities and `DomainValidator` (canonical ASCII/IDNA handling, correct Public Suffix
  List behaviour, rejection of IP literals/URLs/shell syntax).
- Job manifest and evidence JSON Schemas, and the execution adapter layer (`LocalProcessAdapter`
  with the Section 16 security controls, `RemoteWorkerAdapter` stub for Phase 3).
- A PHP-based collection worker (`worker/collect.php`) implementing all nine collectors (RDAP,
  DNS, DNSSEC, mail/SPF/DMARC/DKIM, HTTP, TLS, Certificate Transparency, subdomains, lookalike
  domains), verified end-to-end against a live domain.
- `Assessment\AssessmentService`: the orchestrator that turns an authorised scope into a job,
  dispatches it, ingests and schema-validates the returned evidence, evaluates the rule engine,
  and creates/updates/reopens/resolves findings by diffing against the scope's prior state.
- 22 core rules with real evaluation handlers across registration, mail, DNS, web and TLS
  categories.
- Working `wp reconnaissance` WP-CLI commands (`run`, `scope add`, `scope list`, `job status`,
  `findings list`, `worker test`).
- The customer identity journey: registration, email verification, login, logout,
  forgot/reset-password, and a minimal account page - dedicated `/customer/*` routes, never
  `wp-login.php`, with anti-enumeration responses, nonces, rate limiting, and session rotation
  after password changes.
- Self-hosted plugin updater (`Support\Updater`), onboarded onto the shared
  `alltimeuk/wp-updates` update server alongside `wp-questionnaires`.

### Known limitations

- Mail delivery is not yet implemented (Gmail API/SES providers are stubs); registration and
  password-reset links are logged rather than emailed.
- The consent ledger is a single marketing-consent flag, not the full Section 6.1.2 shared
  contact-platform subsystem.
- No customer portal, remediation-task generation, report rendering (HTML/PDF/Markdown/JSON),
  entitlements, anti-abuse controls, or WP Questionnaires integration yet.
- Not yet exercised against a live WordPress `$wpdb` - verified via static analysis and unit
  tests, plus a live end-to-end run of the collection worker itself.
