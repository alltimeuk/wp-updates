<?php
/**
 * Fires when the plugin is deleted through the WordPress plugin screen.
 *
 * Data is preserved by default. Destructive removal only happens if an administrator has
 * explicitly opted in via the "wpr_remove_data_on_uninstall" option before deletion.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance;

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$wpr_autoloader = __DIR__ . '/vendor/autoload.php';

if ( ! file_exists( $wpr_autoloader ) ) {
	return;
}

require_once $wpr_autoloader;

if ( ! get_option( 'wpr_remove_data_on_uninstall', false ) ) {
	return;
}

Data\Migrator::uninstall();
