# Changelog

All notable changes to WP-Reconnaissance are documented in this file.

## 0.1.2 - 2026-08-16

### Changed

- Retired the WP Questionnaires contact migration in favour of WPQ's own canonical store. WP
  Questionnaires v1.15.0 shipped `WPQ_Customer_Platform_Bridge`, which registers its `wpq_contacts`
  store on this plugin's `alltime_customer_platform_contact_service` discovery filter at a higher
  priority than this plugin's own registration - making WPQ canonical on any dual-install site.
  Continuing to write WPQ submissions/enquiries into this plugin's own `atcp_contacts` tables would
  have produced a second, conflicting contact record, so `WpqMigrationService`,
  `wp reconnaissance wpq-migrate` and `MigrationReport` have been deleted, and
  `WpqCompatibilityAdapter`/`WpqCapabilityProbe` trimmed down to the one read still needed:
  `PersonalDataLocator`'s GDPR export still pulls WPQ's raw submission/enquiry/preference data via
  `export_contact_data()`, since the shared contact contract has no read method rich enough to
  replace it. This plugin's own visitor-context/cookie code has no WPQ equivalent and is
  unaffected. Also fixed the `alltime_contact_merged` hook's third argument (`ContactMergeService`)
  to match WPQ's documented `array{actor: int}` shape instead of a plain admin-user-id int, since
  WPQ's bridge is the first real external listener this hook has ever had to interoperate with.

### Added

- CRM/PSA integration API (Section 33, Phase 2 item 9, e.g. HaloPSA polling for contacts, domains
  and reports): no outbound integration mechanism or service-account REST auth existed before
  this. Every REST permission callback was already a plain `current_user_can()` check, so a
  WordPress Application Password against a suitably-privileged account would have worked
  transparently - it just had nothing to authenticate as. A new read-only
  `Roles::INTEGRATION_ROLE` (`wpr_integration`, holding only `VIEW_ALL_RESULTS` - none of the
  write capabilities the full operator role carries) is the account an external system
  authenticates as. `Roles::register()` now runs on every boot, not only activation, so this new
  role (and any capability a past release added) actually reaches an already-active install.
  Domains/config and reports were already exposable via the existing `/organisations/{id}/scopes`
  and `/scopes/{id}/reports` routes; the one genuinely missing piece was contacts, added via a new
  `GET /organisations/{id}/contacts` route (`Api\ContactsController`, backed by the existing
  `CustomerAccountRepository::find_by_organisation()`). A new admin Settings section documents the
  whole flow (create a WordPress user with the integration role, generate an Application Password
  from their profile, point the external system at the REST base URL), and a new Site Health check
  confirms Application Passwords are actually available on the site.

- Managed entitlement plans (Section 33, Phase 2 item 8): entitlements were strictly one-shot,
  gated only by a flat system-wide rerun-interval option with no plan/tier concept. Schema v11
  adds `wpr_plans` (name, `max_active_scopes`, `rerun_interval_days`, `min_schedule_frequency`,
  and a reserved-but-unused `external_billing_reference` for a future payment integration to
  write into) and a `plan_id` column on `wpr_organisations`. An operator creates plans and assigns
  them to organisations from a new admin "Plans" screen; an organisation with no plan stays fully
  unrestricted, exactly as before this shipped. Enforcement: `EntitlementService::check()` uses
  the organisation's plan's `rerun_interval_days` when set, falling back to the existing global
  option; `PlanEnforcementService::assert_can_authorise_scope()` blocks authorising a scope past
  `max_active_scopes` (checked at authorisation, not creation, since nothing runs against an
  unauthorised scope); a new `Scheduling\ScheduleFrequencyClamp` (pure, unit-tested) slows a
  scope's durable-schedule cadence down to the plan's `min_schedule_frequency` floor when it would
  otherwise run faster. No payment gateway integration - that remains a deliberately separate,
  later decision.
- Issued report version history and comparison (Section 33, Phase 2 item 7): reports were always
  versioned at the schema level (`wpr_reports`'s unique `scope_id`+`version` key,
  `ReportRepository::find_by_scope()`), but nothing ever exposed more than the single latest
  version per scope - not the admin Reports screen, not the customer portal, not the REST API. A
  new `GET /scopes/{scope_id}/reports` route exposes the full history; both the admin report view
  and the customer portal's report view now show a version-history table and, where an
  immediately-earlier version exists, a "what changed since version N" summary. The comparison
  itself is a new `Reports\ReportComparator`, reusing `Findings\AssetDiffer` - the same pure
  set-comparison the generalized change engine (item 3) introduced - applied to each report
  document's `findings[].finding_id` instead of an asset identifier.
- Operator-facing failure monitoring (Section 33, Phase 2 item 6): the "repeated collection
  failure" trigger already existed, but only reactively, as a customer-facing email sent at the
  moment one job completed. `JobRepository::find_scopes_with_repeated_failures()` computes the
  same signal (a scope's most recent 3 jobs all failed) proactively across the whole fleet, and
  `count_by_status_since()` adds a "Jobs failed today" count. Surfaced in three places an operator
  actually looks: a new tile on the admin Overview screen, a warning box at the top of the admin
  Jobs screen listing every affected scope, and a new Site Health check
  (`wpr_repeated_failures`) so it shows up alongside the plugin's existing infrastructure-health
  checks (mail queue, cron, worker readiness) rather than only in a dedicated view.
- Customer-configurable notifications (Section 33, Phase 2 item 5): schema v10 adds
  `reminder_days_before` to `wpr_remediation_tasks` and a new `wpr_notification_digest_entries`
  table. A customer's requested task reminder previously always fired at the same system-wide
  7-day lookahead (`RemediationTaskRepository::REMINDER_LOOKAHEAD_DAYS`); the customer portal task
  form now lets them pick 1/3/7/14/30 days instead, falling back to the same 7-day default when
  unset. A new per-account delivery preference (`Auth\Enums\NotificationFrequency`, set from the
  customer portal's privacy centre) lets a customer choose a single combined daily digest email
  over one email per triggering event; `NotificationDispatcher::notify_organisation()` routes to
  a pending-digest entry instead of the immediate mail queue when chosen, and a new
  `NotificationDigestService` (run from the existing daily maintenance sweep) folds each account's
  pending entries into one email and marks them sent. Both paths share the same idempotency key,
  so a hook firing twice can never duplicate a notification regardless of delivery mode.
- Suppression/risk-acceptance review workflow (Section 33, Phase 2 item 4): `risk_accepted_by`
  and `risk_accept_review_date` existed only as unused `wpr_findings` columns - now wired into
  `Domain\Finding`, `FindingRepository` (hydrate/save/`update_review()`), and the assessment
  pipeline's re-evaluation path (carried forward across re-observations, cleared if a finding
  re-appears as genuinely new). Both admin ("Review" form) and REST (`PATCH /findings/{id}`)
  review paths now capture the reviewer (the acting user, not a client-supplied value) and an
  optional review date whenever a finding is marked "Accepted risk"; any other status clears
  both, so a stale reviewer/date never survives past the decision it was recorded for. A new
  `FindingRepository::find_due_risk_acceptance_reviews()` (30-day lookahead) surfaces accepted
  risks coming up for reconfirmation as a warning box on the admin Findings screen.
- Generalized change engine (Section 33, Phase 2 item 3): the one-off certificate/subdomain
  diffing in `NotificationDispatcher::check_new_assets()` is replaced by a reusable
  `Findings\AssetDiffer` (pure set comparison) and `Findings\AssetChangeDetector` (a small
  registry mapping asset kind to collector and extractor, versus duplicating diff logic per
  kind). Broadened from 2 to 4 asset kinds in the process - IP addresses (`dns` collector's A/AAAA
  records) and DKIM selectors (`mail` collector, skipping any selector the collector could not
  observe) now also trigger the "new assets detected" notification alongside certificates and
  subdomains. Adding a further kind is now a registry entry plus one extractor method, not a
  parallel `array_diff()` call site. Deferred: surfacing this as a browsable change timeline in
  the customer portal, rather than only a notification side-effect.
- Baselines and expected state (Section 33, Phase 2 item 2): `Scope::$expected_state` was
  schema-only and never read by the rule engine. `RuleEngine::evaluate()` and
  `RuleHandlerInterface::evaluate()` now take the scope alongside the evidence document, so a
  handler can compare observed evidence against a customer/operator-declared baseline instead of
  (or in addition to) a rule-intrinsic literal. A new `Rules\Handlers\BaselineRuleHandlers` adds
  three rules - `BASELINE.RDAP.NAMESERVERS_CHANGED`, `BASELINE.MAIL.MX_CHANGED`,
  `BASELINE.TLS.ISSUER_CHANGED` - each silent until a baseline for that collector key actually
  exists, then firing on drift (a classic domain-hijack/mail-rerouting/rogue-certificate
  indicator). `Rules\BaselineCaptureService` is the practical way to establish one: "adopt the
  current observed state as the baseline", available from the admin Scopes screen and
  `wp reconnaissance scope capture-baseline --scope-id=<id>`; a collector that failed on the
  latest run leaves its existing baseline untouched rather than clearing it.
- Durable recurring assessment schedules (Section 33, Phase 2 item 1): schema v9 adds
  `monitoring_schedule`, `next_assessment_due_at` and `last_scheduled_at` to `wpr_scopes`. A new
  `Domain\Enums\ScheduleFrequency` (daily/weekly/monthly/manual) and pure `NextOccurrenceCalculator`
  compute the next due date, correctly clamping month-end overflow (e.g. Jan 31 -> Feb 28/29)
  instead of letting `+1 month` roll into March. `SchedulingBootstrap::run_due_assessments()` -
  previously an empty stub - now seeds any never-scheduled scope's due date (without dispatching,
  so turning this on never causes a mass run) and then dispatches every scope whose due date has
  arrived, each isolated in its own try/catch and audit-logged on failure so one bad scope never
  blocks the batch. Runs as part of the existing daily maintenance sweep, capped by
  `wpr_max_scheduled_assessments_per_sweep` (default 50). A scope's own `monitoring_schedule`
  overrides its monitoring profile's inherited cadence. New `wp reconnaissance schedule run
  [--dry-run]` CLI command for on-demand/preview invocation.

- Self-service free-assessment journey (Section 5.3/5.5): registration now collects the domain to
  assess and the customer's confirmation of authority over it, creating (but not yet authorising)
  the scope immediately. Once the account's email is verified, `Auth\FreeAssessmentService`
  authorises the scope and - if the free-use entitlement allows it - reserves it and queues the
  assessment automatically, so a customer sees progress in their account without waiting on an
  operator. Dispatch is deliberately gated on email verification, not registration itself, so
  nobody can queue a scan of an arbitrary domain by typing someone else's address into the form.
  `Entitlements\EntitlementFulfillment` listens for `wpr_job_completed` and consumes the
  reservation on a usable result or releases it on failure, exactly as Section 5.5 requires.
- Anti-abuse controls (Section 5.6): schema v7 adds `wpr_abuse_signals` (review queue) and
  `wpr_blocklist`. A new `AntiAbuse\` module layers a configurable bot-challenge adapter (a
  bundled zero-dependency honeypot + minimum form-fill-time check, swappable for a real CAPTCHA
  provider later), disposable-email detection, duplicate-domain and maximum-queued-jobs review
  signals, and block/allow lists over the existing per-IP `Auth\RateLimiter`. `RegistrationService`
  evaluates all of this before the duplicate-email check - hard blocks (blocklist match or failed
  challenge) throw a generic `RegistrationException`; review signals are queued rather than
  rejected. `FreeAssessmentService` holds a free assessment while an open review signal exists and
  dispatches it when an operator releases it. Audit events record both automated and manual
  eligibility decisions. Admin: an "Abuse review" screen (release/dismiss/block signals, add/remove
  blocklist entries) and anti-abuse settings (captcha enabled, minimum form seconds, maximum queued
  jobs), gated by the new `wpr_manage_abuse_review` capability.
- Downloadable PDF reports (Section 21.2): added `dompdf/dompdf ^3.1.6` and a new `Reports\`
  module. `PdfReportRenderer` reuses `HtmlReportRenderer` for the source markup and converts it to
  PDF via dompdf (remote/php/javascript disabled). `ReportFileStorage` keeps the files in a
  protected `wpr-reports/` uploads subdirectory (`.htaccess` + `index.php`, mirroring
  `EvidenceStorage`), with a deterministic filename derived from the report UUID so no schema
  change is needed. Generation is asynchronous - `SchedulingBootstrap` queues
  `wpr_generate_report_pdf` on `wpr_report_issued` (Action Scheduler when available, WP-Cron
  fallback) - so a slow render never blocks the request that issued the report. Downloads are
  served through protected, capability/ownership-checked endpoints in both the admin Reports
  screen and the customer portal, gated by a short-lived HMAC-signed token
  (`ReportDownloadToken`, 15-minute expiry); a not-yet-generated PDF surfaces a "not ready yet"
  state rather than a broken link.
- Admin organisation editing: an "Edit" action on the Organisations screen updates name, timezone
  and status - previously only possible via the REST API.
- Customer-editable remediation task notes (Section 21.3 names "Customer notes" as a field
  distinct from operator-only "Alltime notes"): the `/customer/tasks/` route now lets a customer
  add or update their own note on each of their organisation's tasks, without touching status,
  target date or operator notes.
- Persistent transactional mail queue (Section 22.5): `wpr_mail_queue`/`wpr_mail_events` record
  every message's recipient, template, purpose, provider, provider ID, state and timestamps, with
  idempotency-key deduplication and bounded exponential backoff for transient provider failures.
  Registration/password-reset email (previously logged to `error_log()` as a development aid)
  now goes through the same queue as every other notification.
- Notification triggers (Section 22.5): new high/critical finding, an existing finding worsening,
  a report becoming ready (with a distinct "free report ready" template for a scope's first
  issued report), repeated collection failure, and authorisation approaching expiry. Wired from
  the plain `wpr_job_completed`/`wpr_finding_created`/`wpr_finding_changed`/`wpr_report_issued`
  action hooks Section 22.5 itself specifies, so any other integration can subscribe
  independently - `NotificationDispatcher` is their first subscriber, not a special case. Every
  enqueue carries a stable, event-derived idempotency key rather than a random one.
- `ChangeDetector` now distinguishes a finding actively worsening from a lateral `Modified`
  change (Section 8.7), using confidence-rank movement as a generic proxy since severity is fixed
  per rule and can never itself signal worsening for a single finding instance.
- Retention and deletion sweep (Section 26.7): unverified registrations, raw evidence (file plus
  its `wpr_evidence` row), the audit log, the mail queue, and (via
  `Alltime\CustomerPlatform\RetentionSweeper`) cross-tool interaction history, each on its own
  configurable `wpr_retention_*_days` window. Runs daily via WP-Cron/Action Scheduler and on
  demand through `wp reconnaissance retention run`, which replaces the "not yet implemented"
  stub. `wp reconnaissance report generate <scope-id>` likewise now issues a real report instead
  of erroring.
- REST API resources for organisations, scopes, jobs and findings (`wp-reconnaissance/v1`):
  list/get/create/update, scope authorisation, and asynchronous job dispatch. Every route is
  scoped by `Support\ActorScope` so an operator sees everything while a customer sees only the
  single organisation their account is linked to.
- Real admin screens (Overview, Organisations, Scopes, Jobs, Findings, Settings) replacing the
  Phase 1 placeholders: create/authorise scopes, dispatch assessments, review and annotate
  findings, and configure the local execution adapter, all backed by real data.
- Asynchronous job dispatch (`Scheduling\SchedulingBootstrap::schedule_assessment()`), using
  Action Scheduler when available and falling back to a one-off WP-Cron event - the admin "Run
  now" action and the REST job-dispatch endpoint both queue a run rather than executing
  `AssessmentService` inline from an HTTP request (Section 15).
- Repository additions needed by the above: paginated `list()`/`count()` across organisations,
  scopes, jobs and findings, plus `FindingRepository::update_review()` for operator review
  actions (status, notes, ownership, suppression) without touching the change-detection fields
  the assessment pipeline owns.
- Remediation task generation (Section 21.3): every actionable finding maps to one task, kept
  updated (not duplicated) across re-scans, with a transparent, fully unit-tested priority
  algorithm (`Reports\PriorityCalculator`) that scores severity, confidence, time-bound urgency,
  enabling-control status and persistence rather than sorting on severity alone. A finding that
  resolves, is accepted as risk, suppressed or marked a false positive transitions its linked
  task to the matching terminal status automatically.
- Report generation and issuing (Section 19.6/21): `Reports\DomainReconnaissanceReportBuilder`
  builds a `schemas/report.schema.json`-conformant document from a scope's latest observation,
  findings and remediation plan; the admin Reports screen supports the full draft → review → add
  executive summary → issue immutable version workflow. Issued reports render as HTML (admin and
  customer portal) and Markdown, and are exposed as JSON via REST.
- Customer portal now shows real data instead of placeholders: the dashboard lists the
  organisation's domains with a link to each one's latest report and an open-task-by-priority
  summary, plus dedicated `/customer/reports/` and `/customer/tasks/` routes (read-only for now -
  updating a task's status still goes through an operator).
- REST resources for reports (list/create/get) and remediation tasks (list/get/update), scoped by
  `Support\ActorScope` like every other resource.
- Shared Alltime Customer Platform (Section 6.1.2/6.1.3), delivered as its own
  `Alltime\CustomerPlatform` namespace and PSR-4 root so it can be extracted into an independent
  plugin later without changing contact IDs. `ContactServiceInterface` (canonical contact,
  identity, interaction and consent records against new `atcp_*` tables) is discovered only
  through `ContactPlatformDiscovery`'s versioned WordPress-filter contract, never constructed
  directly - `RegistrationService` is its first real consumer, creating/linking a contact and
  recording a `registration_completed` interaction and a marketing-consent decision on every
  registration, exactly as an external plugin eventually would.
- Tool registry (Section 5.4): `Tools\ToolRegistry`, populated entirely through the
  `wpr_register_tools` action - `domain-reconnaissance` is registered through that same public
  API, not hard-coded into the registry itself. The customer portal's `/customer/tools/` route
  now renders the catalogue instead of a placeholder.
- Entitlement service (Section 5.5): one free completed report per contact and registrable
  domain by default, a configurable re-run interval, administrator grants/revocations, and
  operator/admin accounts exempted from public limits. Decision logic
  (`Entitlements\EntitlementPolicy`) is pure and fully unit-tested, separate from the
  database-backed repository.
- Data-subject rights requests (Section 26.3/26.4): `wpr_privacy_requests` records every right
  (access, rectification, erasure, restriction, portability, objection, marketing withdrawal)
  through one workflow - `PrivacyRequestService` submits, verifies identity, classifies, places a
  processing restriction, locates linked data, and completes/partially completes/refuses a
  request with an outcome notice, all captured in `wpr_audit_log`. Withdrawing marketing consent
  is auto-fulfilled immediately rather than queued for review, per Section 26.6. A new
  `/customer/privacy/` portal route lets a customer view a summary of their linked data, download
  it as JSON, manage their marketing preference, submit and track requests, and cancel one they
  submitted; a new admin "Privacy requests" screen lets an operator with
  `wpr_manage_privacy_requests` record requests received by another channel, action every
  workflow step, and see approaching/overdue statutory deadlines. `PersonalDataLocator` backs both
  the portal and the admin screen and is now what WordPress core's own personal-data export tool
  calls too - `Privacy\PersonalDataExporter`/`PersonalDataEraser` are real implementations,
  replacing the Phase 1 stubs.
- Site Health diagnostics (Section 29): ten checks covering supported PHP version, database schema
  status, mail queue health, scheduled-task health, the local execution adapter's readiness and
  worker version compatibility, the worker working directory and evidence storage protection, the
  (not-yet-available) remote worker adapter, and retention-sweep freshness, plus a
  "wp-reconnaissance" Info-tab section with every filesystem path marked private so WordPress
  core's own diagnostics export redacts them automatically.
- Customer task status updates (Section 34 item 21): the customer task form now renders a status
  `<select>` over all eight `RemediationTaskStatus` cases and `handle_update_task_notes()`
  validates the submitted value via `RemediationTaskStatus::tryFrom()` before calling
  `update_status()`. Target date and operator notes remain operator-only.
- Mail provider admin screen (Section 22.1-22.3): the Settings screen now has a "Mail provider"
  section to pick Gmail API / Amazon SES / None, enter credentials, save (validating the active
  provider's configuration) and send a test message to the current admin's address. Secret fields
  (Gmail refresh token, SES secret access key) are never echoed back after save. The new
  `wpr_mail_provider`/`wpr_gmail_*`/`wpr_ses_*` options are removed on uninstall.
- New certificate / new subdomain notification trigger (Section 22.5):
  `NotificationDispatcher::check_new_assets()` diffs the just-completed observation's `ct` and
  `subdomains` collector evidence against its predecessor and notifies the organisation of
  anything newly seen, firing on `wpr_job_completed` for succeeded/partially-succeeded runs.
- Customer-requested task reminder (Section 22.5): schema v8 adds `reminder_requested` to
  `wpr_remediation_tasks`; a checkbox on the customer task form sets it, and the daily sweep
  (`NotificationDispatcher::check_task_reminders()`) sends one reminder per task per account when
  the target date is due or within 7 days.
- WP Questionnaires compatibility and cross-tool contact linkage (Sections 6.1.4, 9.0,
  18.1.1-18.1.4, 26.3): the shared Customer Platform gained schema v2 (`atcp_visitor_contexts`,
  `atcp_preferences`, `atcp_privacy_requests`, `atcp_contact_merge_log`) plus a unique
  `(source_object_type, source_object_id)` key on `atcp_interactions` as the migration idempotency
  marker. A new `VisitorContextService` implements the cross-tool `at_contact_context` cookie
  (256-bit opaque token, keyed hash only in DB, Secure/HttpOnly/SameSite=Lax/Path=/), a
  `CookiePurposeClassifier` enforces Section 18.1.2's consent boundary, and a
  `MergePrecedenceResolver` implements Section 18.1.3's precedence ladder; the context is
  associated with the canonical contact on login, registration and email verification, with
  security events on contact mismatch. `ContactMergeService` plus an admin "Contact merge" screen
  implement Section 18.1.4's dedup/merge/review workflow with before/after snapshots.
  `WpqCompatibilityAdapter` links WPQ submissions/enquiries to canonical contacts (reading WPQ
  only through its public static methods, guarded by `WpqCapabilityProbe`), `WpqMigrationService`
  migrates existing WPQ rows idempotently (ambiguous rows queued for review, opt-outs preserved),
  a `wp reconnaissance wpq-migrate` WP-CLI command drives it, and `PersonalDataLocator` now
  includes WPQ data in the same privacy export/rights-request workflow when WPQ is active.

### Fixed

- TLS chain-trust probe reporting hostname mismatches as chain distrust: `probe_chain_trust()`
  set `verify_peer_name=true` alongside `verify_peer=true`, so a domain with a perfectly valid
  certificate chain but a merely mismatched hostname would fail that connection too and get
  reported as `chain_trusted=false` - misattributing a hostname problem as a chain-trust one.
  `hostname_matches()` already independently determines the hostname outcome from the captured
  certificate's SAN/CN, so the trust probe now only verifies the chain
  (`TlsCollector::probe_chain_trust()`); SNI is unaffected since it's controlled by
  `SNI_enabled`/`peer_name`, not `verify_peer_name`.
- `ci.yml`/`release.yml` targeted the specific self-hosted runner machine by its bare
  `self-hosted` label; when that machine couldn't service a job (offline, swapped for a different
  host), there was no way to redirect work without editing every job's `runs-on`. Both workflows
  now target the org's `Default` runner group directly (`runs-on: { group: Default, labels:
  [self-hosted] }`), so whichever self-hosted runner is online in that group - local or remote -
  picks up the job with no workflow change needed.

### Known limitations

- Notification triggers implemented are a defensible subset of Section 22.5's full list: the new
  mail-enabled lookalike domain trigger is not covered, since it needs the lookalike collector to
  emit evidence, which the worker does not produce yet. New certificate, new subdomain and
  customer-requested task reminders are now implemented (see Added).
- Mail suppression for Marketing-purpose messages checks this plugin's own
  `wpr_marketing_consent` flag, not the shared Customer Platform's `atcp_consents` ledger that is
  also recorded at registration - wiring suppression through the cross-plugin contact contract
  is a reasonable follow-up once a second product needs to observe the same consent decision.
- The retention sweep does not purge issued reports (Section 26.7 says to retain them "according
  to the organisation policy" - silently deleting a customer's historical deliverables deserves
  its own careful implementation, not a rushed addition alongside evidence/log cleanup), CRM
  leads (no lead entity exists yet), or anything under legal hold (no hold concept exists yet).
- The prioritisation algorithm deliberately does not model customer-specific applicability or an
  explicit task dependency graph (Section 21.5) - both need data this plugin does not capture
  yet.
- Customers can update a remediation task's status and their own notes, but not its target date
  or operator notes - those remain operator-only (Admin/REST).
- The Customer Platform's visitor-context cookie, preferences, privacy-request tracking and
  contact merge/review log are built (see Added), but the coordinated WP Questionnaires-side
  migration that adds `contact_id` columns to `wpq_submissions`/`wpq_enquiries` and updates the
  WPQ Contacts screen (Section 9.0) is not - it requires write access to the `wp-questionnaires`
  plugin, which was read-only for this work.
- The self-service free-assessment journey only covers the single domain a customer supplies at
  registration; a customer cannot yet add a second domain to their organisation and trigger its
  own free assessment themselves - that still requires an operator (Admin/REST).
- No CRM lead capture or full-purpose consent/preference centre beyond the single marketing
  decision yet (Section 22.6/22.7) - the shared `atcp_preferences` store and the visitor-context
  cookie-choice preference are built, but a full consent/preference centre UI is not.
- `PersonalDataLocator` deliberately covers WordPress user/account data, the shared Customer
  Platform contact record, audit log entries, mail history and (when WPQ is active) WP
  Questionnaires data - not the Customer Platform's interaction/consent ledger (no read method
  exists yet on `ContactServiceInterface`), and not organisational security data
  (findings/evidence/reports, which describe a domain rather than the requester).
- Erasure is never fully automatic: `PersonalDataEraser` only ever removes queued/sent mail
  history unconditionally. An active customer account, the shared contact record and audit log
  entries are always retained and flagged for manual review through the admin privacy-request
  workflow, since deleting an active account has cross-organisation consequences (other members,
  in-flight assessments, issued reports) this plugin does not yet have a deliberate, reviewed way
  to action automatically.
- "Restriction of processing" on a privacy request is tracked and operator-visible only; it is not
  wired into any actual processing decision elsewhere in the plugin yet (assessment dispatch,
  reporting, etc. do not check it).
- Site Health's remote-worker-connectivity check always reports "not applicable", since the remote
  worker adapter itself is Phase 3 scope and is not selectable yet.

## 0.1.1 - 2026-08-12

No functional change. Confirms the self-hosted update pipeline end to end: release build,
package smoke test, GitHub Release, and publish to the shared `alltimeuk/wp-updates` update
server - `v0.1.0`'s deploy step failed because the deploy token wasn't yet reachable by this
(private) repository; see the fix below.

### Fixed

- `WP_UPDATES_TOKEN` was created as an organisation-level secret, but GitHub only delivers
  organisation secrets to private repositories on paid org plans; `alltimeuk` is on the Free
  plan, so the secret silently resolved empty in the release workflow. Switched to a
  repository-level secret on `wp-reconnaissance`, matching the existing `wp-questionnaires`
  setup.

## 0.1.0 - 2026-08-12

Initial Phase 1 scaffold and first working slice of the collection-to-findings pipeline and the
customer identity journey.

### Added

- Plugin bootstrap, Composer PSR-4 autoloading, and the PHPUnit/PHPCS/PHPStan quality-gate
  tooling.
- Database migrations for the core reconnaissance tables (organisations, scopes, profiles, jobs,
  observations, evidence, findings, finding events, audit log) and the customer auth-token store.
- Domain entities and `DomainValidator` (canonical ASCII/IDNA handling, correct Public Suffix
  List behaviour, rejection of IP literals/URLs/shell syntax).
- Job manifest and evidence JSON Schemas, and the execution adapter layer (`LocalProcessAdapter`
  with the Section 16 security controls, `RemoteWorkerAdapter` stub for Phase 3).
- A PHP-based collection worker (`worker/collect.php`) implementing all nine collectors (RDAP,
  DNS, DNSSEC, mail/SPF/DMARC/DKIM, HTTP, TLS, Certificate Transparency, subdomains, lookalike
  domains), verified end-to-end against a live domain.
- `Assessment\AssessmentService`: the orchestrator that turns an authorised scope into a job,
  dispatches it, ingests and schema-validates the returned evidence, evaluates the rule engine,
  and creates/updates/reopens/resolves findings by diffing against the scope's prior state.
- 22 core rules with real evaluation handlers across registration, mail, DNS, web and TLS
  categories.
- Working `wp reconnaissance` WP-CLI commands (`run`, `scope add`, `scope list`, `job status`,
  `findings list`, `worker test`).
- The customer identity journey: registration, email verification, login, logout,
  forgot/reset-password, and a minimal account page - dedicated `/customer/*` routes, never
  `wp-login.php`, with anti-enumeration responses, nonces, rate limiting, and session rotation
  after password changes.
- Self-hosted plugin updater (`Support\Updater`), onboarded onto the shared
  `alltimeuk/wp-updates` update server alongside `wp-questionnaires`.

### Known limitations

- Mail delivery is not yet implemented (Gmail API/SES providers are stubs); registration and
  password-reset links are logged rather than emailed.
- The consent ledger is a single marketing-consent flag, not the full Section 6.1.2 shared
  contact-platform subsystem.
- No customer portal, remediation-task generation, report rendering (HTML/PDF/Markdown/JSON),
  entitlements, anti-abuse controls, or WP Questionnaires integration yet.
- Not yet exercised against a live WordPress `$wpdb` - verified via static analysis and unit
  tests, plus a live end-to-end run of the collection worker itself.
