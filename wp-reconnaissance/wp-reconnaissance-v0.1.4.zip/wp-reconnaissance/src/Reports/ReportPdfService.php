<?php
/**
 * Orchestrates PDF generation, storage and retrieval for issued reports, per Section 21.2.
 *
 * Generation is asynchronous: {@see generate_for_report()} is the worker entry point invoked off
 * the HTTP request (via {@see \Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap}), so a
 * slow PDF render never blocks the request that issued the report. Retrieval returns null until
 * the async job has produced the file, which download handlers surface as a "not ready yet" state.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Domain\Report;

final class ReportPdfService {

	public function __construct(
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly ReportStorageInterface $storage = new ReportFileStorage(),
		private readonly PdfRendererInterface $renderer = new PdfReportRenderer()
	) {}

	/**
	 * Generates and stores the PDF for a report id. Safe to call repeatedly - a report that is
	 * missing, or whose PDF cannot be rendered, is simply skipped.
	 */
	public function generate_for_report( int $report_id ): void {
		$report = $this->reports->find( $report_id );

		if ( null === $report ) {
			return;
		}

		$pdf = $this->renderer->render( $report );

		if ( null === $pdf ) {
			return;
		}

		$this->storage->store( $report->report_uuid, $pdf );
	}

	/**
	 * Returns the stored PDF bytes for a report, or null if the async job has not produced it yet.
	 */
	public function retrieve_pdf( Report $report ): ?string {
		return $this->storage->retrieve( $this->reference_for( $report ) );
	}

	/** The deterministic storage reference for a report. */
	public function reference_for( Report $report ): string {
		return $this->storage->reference_for( $report->report_uuid );
	}
}
