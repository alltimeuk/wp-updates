<?php
/**
 * Stores issued-report PDF files in a protected uploads subdirectory, per Section 21.2:
 * "Issued files shall be protected from direct public access and delivered using short-lived,
 * authorised download responses."
 *
 * Only the reference returned by {@see store()} is used by download handlers; nothing in this
 * class is a public URL. The filename is derived deterministically from the report UUID (already
 * unique and immutable), so no schema change is needed to track where a report's PDF lives.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

final class ReportFileStorage implements ReportStorageInterface {

	/**
	 * Writes the PDF bytes and returns a reference like "wpr-reports/{safe_name}.pdf".
	 */
	public function store( string $report_uuid, string $pdf_bytes ): string {
		$dir = $this->directory();

		$this->ensure_protected( $dir );

		$safe_name = $this->safe_name( $report_uuid );
		$path      = $dir . DIRECTORY_SEPARATOR . "{$safe_name}.pdf";

		if ( false === file_put_contents( $path, $pdf_bytes, LOCK_EX ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			throw new \RuntimeException( esc_html( 'Unable to write report PDF to protected storage.' ) );
		}

		chmod( $path, 0600 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod

		return "wpr-reports/{$safe_name}.pdf";
	}

	/**
	 * Removes the stored PDF for a reference, if it still exists - the retention sweep's
	 * counterpart to {@see store()}.
	 */
	public function delete( string $reference ): void {
		$path = $this->directory() . DIRECTORY_SEPARATOR . basename( $reference );

		if ( is_file( $path ) ) {
			wp_delete_file( $path );
		}
	}

	public function retrieve( string $reference ): ?string {
		$path = $this->directory() . DIRECTORY_SEPARATOR . basename( $reference );

		if ( ! is_file( $path ) ) {
			return null;
		}

		$contents = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		return false !== $contents ? $contents : null;
	}

	public function reference_for( string $report_uuid ): string {
		return 'wpr-reports/' . $this->safe_name( $report_uuid ) . '.pdf';
	}

	private function safe_name( string $report_uuid ): string {
		return (string) preg_replace( '/[^A-Za-z0-9._-]/', '', $report_uuid );
	}

	private function directory(): string {
		$upload_dir = wp_upload_dir();

		return trailingslashit( $upload_dir['basedir'] ) . 'wpr-reports';
	}

	private function ensure_protected( string $dir ): void {
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		$htaccess = $dir . DIRECTORY_SEPARATOR . '.htaccess';
		if ( ! is_file( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$index = $dir . DIRECTORY_SEPARATOR . 'index.php';
		if ( ! is_file( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}
}
