<?php
/**
 * Persistence for findings against `wpr_findings`, per Section 8.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Enums\Severity;
use Alltime\WPReconnaissance\Domain\Finding;

final class FindingRepository {

	/** How far ahead a risk-acceptance review date must fall to count as "due soon". */
	private const RISK_REVIEW_LOOKAHEAD_DAYS = 30;

	/**
	 * @return Finding[] Findings for a scope, most recently observed first.
	 */
	public function find_by_scope( int $scope_id, ?FindingStatus $status = null ): array {
		global $wpdb;

		$table = Schema::table( 'findings' );

		if ( null !== $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM `{$table}` WHERE scope_id = %d AND status = %s ORDER BY last_observed_at DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$scope_id,
					$status->value
				),
				ARRAY_A
			);
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM `{$table}` WHERE scope_id = %d ORDER BY last_observed_at DESC", $scope_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				ARRAY_A
			);
		}

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return Finding[] Findings across every scope belonging to an organisation, most recently
	 *                    observed first.
	 */
	public function find_by_organisation( int $organisation_id, ?FindingStatus $status = null ): array {
		global $wpdb;

		$table = Schema::table( 'findings' );

		if ( null !== $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM `{$table}` WHERE organisation_id = %d AND status = %s ORDER BY last_observed_at DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$organisation_id,
					$status->value
				),
				ARRAY_A
			);
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_id = %d ORDER BY last_observed_at DESC", $organisation_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				ARRAY_A
			);
		}

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Every finding across every organisation, for the operator-facing admin screen when no
	 * organisation filter is applied. Never exposed to customers.
	 *
	 * @return Finding[]
	 */
	public function list_all( int $per_page = 20, int $page = 1, ?FindingStatus $status = null ): array {
		global $wpdb;

		$table  = Schema::table( 'findings' );
		$offset = max( 0, ( max( 1, $page ) - 1 ) * $per_page );

		if ( null !== $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM `{$table}` WHERE status = %s ORDER BY last_observed_at DESC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$status->value,
					$per_page,
					$offset
				),
				ARRAY_A
			);
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY last_observed_at DESC LIMIT %d OFFSET %d", $per_page, $offset ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				ARRAY_A
			);
		}

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	public function find( int $id ): ?Finding {
		global $wpdb;

		$table = Schema::table( 'findings' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? $this->hydrate( $row ) : null;
	}

	/**
	 * Counts of currently-open findings (status new/open/acknowledged/in_progress) grouped by
	 * severity, for the admin overview dashboard. Restricted to one organisation when given,
	 * otherwise across every organisation.
	 *
	 * @return array<string,int> Severity value => count.
	 */
	public function count_open_by_severity( ?int $organisation_id = null ): array {
		global $wpdb;

		$table        = Schema::table( 'findings' );
		$open_status  = array( FindingStatus::New->value, FindingStatus::Open->value, FindingStatus::Acknowledged->value, FindingStatus::InProgress->value );
		$placeholders = implode( ',', array_fill( 0, count( $open_status ), '%s' ) );

		$sql    = "SELECT severity, COUNT(*) as total FROM `{$table}` WHERE status IN ({$placeholders})"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table/$placeholders are fixed, internally derived identifiers, not user input.
		$params = $open_status;

		if ( null !== $organisation_id ) {
			$sql     .= ' AND organisation_id = %d';
			$params[] = $organisation_id;
		}

		$sql .= ' GROUP BY severity';

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql is built above from fixed fragments only; every value is bound via $wpdb->prepare().
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$counts = array_fill_keys( array_map( static fn ( Severity $severity ): string => $severity->value, Severity::cases() ), 0 );

		foreach ( null !== $rows ? $rows : array() as $row ) {
			$counts[ (string) $row['severity'] ] = (int) $row['total'];
		}

		return $counts;
	}

	/**
	 * Applies an operator review action to an existing finding (Section 8.6/19.5): status
	 * transition plus the review-only fields. Does not touch the change-detection fields
	 * (evidence_refs, expected_state, observed_state, first/last_observed_at) - those are only
	 * ever written by {@see AssessmentService} via {@see save()}.
	 *
	 * `$risk_accepted_by`/`$risk_accept_review_date` are meaningful only while `$status` is
	 * {@see FindingStatus::AcceptedRisk} - the caller is responsible for passing null for both
	 * on any other status, so a finding that moves off accepted-risk never keeps a stale
	 * reviewer/review-date attached to whatever status it moved to.
	 */
	public function update_review(
		int $id,
		FindingStatus $status,
		?string $operator_notes,
		?int $assigned_owner,
		?\DateTimeImmutable $due_date,
		?string $suppression_reason,
		?\DateTimeImmutable $suppression_expires_at,
		?int $risk_accepted_by = null,
		?\DateTimeImmutable $risk_accept_review_date = null
	): Finding {
		global $wpdb;

		$existing = $this->find_or_fail( $id );
		$table    = Schema::table( 'findings' );
		$now      = current_time( 'mysql', true );

		// resolved_at marks the moment a finding first became Resolved; re-saving other review
		// fields while it stays Resolved must not keep pushing that date forward, and leaving
		// Resolved for any other status clears it.
		$resolved_at = match ( true ) {
			FindingStatus::Resolved !== $status => null,
			FindingStatus::Resolved === $existing->status && null !== $existing->resolved_at => $existing->resolved_at->format( 'Y-m-d H:i:s' ),
			default => $now,
		};

		$data = array(
			'status'                  => $status->value,
			'operator_notes'          => $operator_notes,
			'assigned_owner'          => $assigned_owner,
			'due_date'                => $due_date?->format( 'Y-m-d' ),
			'suppression_reason'      => $suppression_reason,
			'suppression_expires_at'  => $suppression_expires_at?->format( 'Y-m-d H:i:s' ),
			'risk_accepted_by'        => $risk_accepted_by,
			'risk_accept_review_date' => $risk_accept_review_date?->format( 'Y-m-d' ),
			'resolved_at'             => $resolved_at,
			'updated_at'              => $now,
		);

		$wpdb->update( $table, $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $id );
	}

	/**
	 * Findings currently accepted-as-risk whose review date has arrived or is within
	 * {@see RISK_REVIEW_LOOKAHEAD_DAYS} - Section 33's suppression/risk-acceptance review
	 * workflow ("this risk acceptance expires soon - reconfirm or resolve").
	 *
	 * @return Finding[]
	 */
	public function find_due_risk_acceptance_reviews(): array {
		global $wpdb;

		$table = Schema::table( 'findings' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE status = %s AND risk_accept_review_date IS NOT NULL AND risk_accept_review_date <= DATE_ADD(CURDATE(), INTERVAL %d DAY) ORDER BY risk_accept_review_date ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				FindingStatus::AcceptedRisk->value,
				self::RISK_REVIEW_LOOKAHEAD_DAYS
			),
			ARRAY_A
		);

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	private function find_or_fail( int $id ): Finding {
		$finding = $this->find( $id );

		if ( null === $finding ) {
			throw new \RuntimeException( esc_html( "Finding {$id} was expected to exist but could not be loaded." ) );
		}

		return $finding;
	}

	/**
	 * Finds the current (non-resolved) finding for a rule within a scope, used by the change
	 * engine to decide whether an evaluation result is new, unchanged or a re-observation of an
	 * existing finding.
	 */
	public function find_open_by_rule( int $scope_id, string $rule_id ): ?Finding {
		global $wpdb;

		$table = Schema::table( 'findings' );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE scope_id = %d AND rule_id = %s AND status NOT IN ('resolved','false_positive') ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scope_id,
				$rule_id
			),
			ARRAY_A
		);

		return null !== $row ? $this->hydrate( $row ) : null;
	}

	/**
	 * Finds the most recent finding for a rule within a scope regardless of status, used by
	 * the change engine to distinguish a genuinely new finding from a previously resolved one
	 * recurring (Reopened) versus a currently-open one changing (Modified).
	 */
	public function find_latest_by_rule( int $scope_id, string $rule_id ): ?Finding {
		global $wpdb;

		$table = Schema::table( 'findings' );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE scope_id = %d AND rule_id = %s ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scope_id,
				$rule_id
			),
			ARRAY_A
		);

		return null !== $row ? $this->hydrate( $row ) : null;
	}

	public function save( Finding $finding ): Finding {
		global $wpdb;

		$table = Schema::table( 'findings' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'finding_uuid'            => $finding->finding_uuid,
			'organisation_id'         => $finding->organisation_id,
			'scope_id'                => $finding->scope_id,
			'rule_id'                 => $finding->rule_id,
			'rule_version'            => $finding->rule_version,
			'title'                   => $finding->title,
			'category'                => $finding->category,
			'severity'                => $finding->severity->value,
			'confidence'              => $finding->confidence->value,
			'status'                  => $finding->status->value,
			'first_observed_at'       => $finding->first_observed_at->format( 'Y-m-d H:i:s' ),
			'last_observed_at'        => $finding->last_observed_at->format( 'Y-m-d H:i:s' ),
			'resolved_at'             => $finding->resolved_at?->format( 'Y-m-d H:i:s' ),
			'evidence_refs'           => wp_json_encode( $finding->evidence_refs ),
			'expected_state'          => wp_json_encode( $finding->expected_state ),
			'observed_state'          => wp_json_encode( $finding->observed_state ),
			'risk_statement'          => $finding->risk_statement,
			'recommendation'          => $finding->recommendation,
			'standards_references'    => wp_json_encode( $finding->standards_references ),
			'assigned_owner'          => $finding->assigned_owner,
			'due_date'                => $finding->due_date?->format( 'Y-m-d' ),
			'operator_notes'          => $finding->operator_notes,
			'suppression_reason'      => $finding->suppression_reason,
			'suppression_expires_at'  => $finding->suppression_expires_at?->format( 'Y-m-d H:i:s' ),
			'risk_accepted_by'        => $finding->risk_accepted_by,
			'risk_accept_review_date' => $finding->risk_accept_review_date?->format( 'Y-m-d' ),
			'updated_at'              => $now,
		);

		if ( null === $finding->id ) {
			$data['created_at'] = $now;
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			return $this->hydrate( array_merge( $data, array( 'id' => $wpdb->insert_id ) ) );
		}

		$wpdb->update( $table, $data, array( 'id' => $finding->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->hydrate( array_merge( $data, array( 'id' => $finding->id ) ) );
	}

	/**
	 * @param array<string,mixed> $row
	 */
	private function hydrate( array $row ): Finding {
		return new Finding(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			finding_uuid: (string) $row['finding_uuid'],
			organisation_id: (int) $row['organisation_id'],
			scope_id: (int) $row['scope_id'],
			rule_id: (string) $row['rule_id'],
			rule_version: (string) $row['rule_version'],
			title: (string) $row['title'],
			category: (string) $row['category'],
			severity: Severity::from( (string) $row['severity'] ),
			confidence: Confidence::from( (string) $row['confidence'] ),
			status: FindingStatus::from( (string) $row['status'] ),
			first_observed_at: new \DateTimeImmutable( (string) $row['first_observed_at'] ),
			last_observed_at: new \DateTimeImmutable( (string) $row['last_observed_at'] ),
			resolved_at: ! empty( $row['resolved_at'] ) ? new \DateTimeImmutable( (string) $row['resolved_at'] ) : null,
			evidence_refs: self::decode( $row['evidence_refs'] ?? null ),
			expected_state: self::decode( $row['expected_state'] ?? null ),
			observed_state: self::decode( $row['observed_state'] ?? null ),
			risk_statement: $row['risk_statement'] ?? null,
			recommendation: $row['recommendation'] ?? null,
			standards_references: self::decode( $row['standards_references'] ?? null ),
			assigned_owner: isset( $row['assigned_owner'] ) ? (int) $row['assigned_owner'] : null,
			due_date: ! empty( $row['due_date'] ) ? new \DateTimeImmutable( (string) $row['due_date'] ) : null,
			operator_notes: $row['operator_notes'] ?? null,
			suppression_reason: $row['suppression_reason'] ?? null,
			suppression_expires_at: ! empty( $row['suppression_expires_at'] ) ? new \DateTimeImmutable( (string) $row['suppression_expires_at'] ) : null,
			risk_accepted_by: isset( $row['risk_accepted_by'] ) ? (int) $row['risk_accepted_by'] : null,
			risk_accept_review_date: ! empty( $row['risk_accept_review_date'] ) ? new \DateTimeImmutable( (string) $row['risk_accept_review_date'] ) : null
		);
	}

	/**
	 * @return array<int|string,mixed>
	 */
	private static function decode( mixed $json ): array {
		if ( ! is_string( $json ) || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}
}
