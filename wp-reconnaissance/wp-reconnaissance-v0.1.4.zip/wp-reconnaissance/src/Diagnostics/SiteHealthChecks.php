<?php
/**
 * Site Health diagnostics, per Section 29.
 *
 * Adds synchronous ("direct") tests to WordPress core's Site Health "Status" tab, and a
 * "wp-reconnaissance" section to its "Info" tab. Diagnostics exports must redact tokens,
 * credentials, evidence and personal information (Section 29); every filesystem path exposed
 * below is marked `'private' => true`, which is the mechanism WordPress core's own "Copy site
 * info to clipboard" export already uses to exclude a field, so no separate export/redaction
 * routine is needed. No evidence content, credentials or personal information is surfaced here at
 * all - only configuration state and counts.
 *
 * Loopback request health is not duplicated here: WordPress core's own Site Health already tests
 * it via its "REST API availability"/"communication with WordPress.org" checks (Section 29 lists
 * "loopback processing where used", which this plugin does not add its own loopback requests
 * beyond what core already exercises).
 *
 * Every check is registered under 'direct' (synchronous), not 'async': all of them are cheap
 * local reads (options, a handful of small queries, filesystem stat calls) with nothing that
 * warrants Site Health's JavaScript-driven async test flow.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Diagnostics;

use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Execution\LocalProcessAdapter;
use Alltime\WPReconnaissance\Execution\RemoteWorkerAdapter;
use Alltime\WPReconnaissance\Notifications\Repositories\MailQueueRepository;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;
use Alltime\WPReconnaissance\Worker\Cli\Runner;

use const Alltime\WPReconnaissance\WPR_SCHEMA_VERSION;

final class SiteHealthChecks {

	private const MIN_PHP_VERSION = '8.2';

	/** A retention sweep is scheduled daily; anything twice that old signals a stalled sweep. */
	private const RETENTION_STALE_AFTER_HOURS = 48;

	/** Matches NotificationDispatcher::REPEATED_FAILURE_THRESHOLD - same signal, operator view. */
	private const REPEATED_FAILURE_THRESHOLD = 3;

	public function __construct(
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly MailQueueRepository $mail_queue = new MailQueueRepository(),
		private readonly LocalProcessAdapter $local_adapter = new LocalProcessAdapter(),
		private readonly RemoteWorkerAdapter $remote_adapter = new RemoteWorkerAdapter()
	) {}

	public function boot(): void {
		add_filter( 'site_status_tests', array( $this, 'register_tests' ) );
		add_filter( 'debug_information', array( $this, 'register_debug_information' ) );
	}

	/**
	 * @param array<string,array<string,mixed>> $tests
	 * @return array<string,array<string,mixed>>
	 */
	public function register_tests( array $tests ): array {
		$checks = array(
			'wpr_php_version'           => array( $this, 'check_php_version' ),
			'wpr_database_schema'       => array( $this, 'check_database_schema' ),
			'wpr_mail_queue'            => array( $this, 'check_mail_queue' ),
			'wpr_cron_health'           => array( $this, 'check_cron_health' ),
			'wpr_worker_availability'   => array( $this, 'check_worker_availability' ),
			'wpr_worker_version'        => array( $this, 'check_worker_version' ),
			'wpr_worker_directory'      => array( $this, 'check_worker_directory' ),
			'wpr_evidence_storage'      => array( $this, 'check_evidence_storage' ),
			'wpr_remote_worker'         => array( $this, 'check_remote_worker' ),
			'wpr_retention_task'        => array( $this, 'check_retention_task' ),
			'wpr_repeated_failures'     => array( $this, 'check_repeated_failures' ),
			'wpr_application_passwords' => array( $this, 'check_application_passwords' ),
		);

		foreach ( $checks as $key => $callback ) {
			$tests['direct'][ $key ] = array(
				'label' => $key,
				'test'  => $callback,
			);
		}

		return $tests;
	}

	// -----------------------------------------------------------------------------------
	// Checks
	// -----------------------------------------------------------------------------------

	/**
	 * @return array<string,mixed>
	 */
	public function check_php_version(): array {
		if ( version_compare( PHP_VERSION, self::MIN_PHP_VERSION, '>=' ) ) {
			return $this->result(
				'good',
				__( 'PHP version is supported', 'wp-reconnaissance' ),
				sprintf(
					/* translators: 1: minimum required PHP version, 2: running PHP version */
					__( 'WP-Reconnaissance requires PHP %1$s or newer; this site is running PHP %2$s.', 'wp-reconnaissance' ),
					self::MIN_PHP_VERSION,
					PHP_VERSION
				)
			);
		}

		return $this->result(
			'critical',
			__( 'PHP version is not supported', 'wp-reconnaissance' ),
			sprintf(
				/* translators: 1: minimum required PHP version, 2: running PHP version */
				__( 'WP-Reconnaissance requires PHP %1$s or newer; this site is running PHP %2$s. Some functionality may not work correctly.', 'wp-reconnaissance' ),
				self::MIN_PHP_VERSION,
				PHP_VERSION
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_database_schema(): array {
		$current = (int) get_option( 'wpr_db_schema_version', 0 );

		if ( $current >= WPR_SCHEMA_VERSION ) {
			return $this->result(
				'good',
				__( 'Database schema is up to date', 'wp-reconnaissance' ),
				__( 'The WP-Reconnaissance database schema matches the version this plugin expects.', 'wp-reconnaissance' )
			);
		}

		$failure = get_option( 'wpr_migration_failure', null );

		if ( is_array( $failure ) ) {
			return $this->result(
				'critical',
				__( 'Database schema upgrade is failing', 'wp-reconnaissance' ),
				sprintf(
					/* translators: 1: schema version the upgrade is trying to reach, 2: safe failure classification, 3: number of times this has been retried, 4: UTC datetime of the most recent retry */
					__( 'The schema upgrade to version %1$d has failed (%2$s) and has been retried automatically %3$d time(s), most recently at %4$s (UTC). It will keep retrying automatically; contact support if this persists.', 'wp-reconnaissance' ),
					(int) ( $failure['target_version'] ?? 0 ),
					(string) ( $failure['classification'] ?? 'unknown' ),
					(int) ( $failure['occurrences'] ?? 0 ),
					(string) ( $failure['last_seen_at'] ?? '' )
				)
			);
		}

		return $this->result(
			'critical',
			__( 'Database schema is out of date', 'wp-reconnaissance' ),
			__( 'The stored schema version is behind what this plugin expects. Reload any admin screen to trigger the pending migration, or deactivate and reactivate the plugin.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_mail_queue(): array {
		$failed = $this->mail_queue->count_failed();

		if ( 0 === $failed ) {
			return $this->result(
				'good',
				__( 'Mail queue is healthy', 'wp-reconnaissance' ),
				__( 'No queued messages are stuck in a failed state.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'recommended',
			__( 'Some queued messages have failed to send', 'wp-reconnaissance' ),
			sprintf(
				/* translators: %d: number of failed messages */
				_n(
					'%d queued message has permanently failed to send and needs attention.',
					'%d queued messages have permanently failed to send and need attention.',
					$failed,
					'wp-reconnaissance'
				),
				$failed
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_cron_health(): array {
		if ( false === wp_next_scheduled( SchedulingBootstrap::DAILY_MAINTENANCE_HOOK ) ) {
			return $this->result(
				'critical',
				__( 'Daily maintenance is not scheduled', 'wp-reconnaissance' ),
				__( 'The daily retention/notification maintenance task has no next run scheduled. Reload any admin screen to reschedule it.', 'wp-reconnaissance' )
			);
		}

		if ( ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) && ! function_exists( 'as_schedule_recurring_action' ) ) {
			return $this->result(
				'recommended',
				__( 'Scheduled tasks depend on a system cron', 'wp-reconnaissance' ),
				__( 'WP-Cron is disabled and Action Scheduler is not available, so scheduled maintenance and mail delivery depend entirely on a real system cron calling wp-cron.php. Confirm one is configured.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'good',
			__( 'Scheduled tasks are healthy', 'wp-reconnaissance' ),
			__( 'Daily maintenance is scheduled and a task runner (Action Scheduler or WP-Cron) is available.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_worker_availability(): array {
		$enabled = (bool) get_option( 'wpr_local_adapter_enabled', false );

		if ( ! $enabled ) {
			return $this->result(
				'recommended',
				__( 'No collection execution adapter is enabled', 'wp-reconnaissance' ),
				__( 'The local process execution adapter is not enabled, so assessments cannot run. Configure it under WP-Reconnaissance &raquo; Settings.', 'wp-reconnaissance' )
			);
		}

		if ( $this->local_adapter->is_ready() ) {
			return $this->result(
				'good',
				__( 'The local execution adapter is ready', 'wp-reconnaissance' ),
				__( 'The configured PHP CLI binary and worker script both exist and are usable.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'critical',
			__( 'The local execution adapter is misconfigured', 'wp-reconnaissance' ),
			__( 'The local process execution adapter is enabled, but the configured PHP CLI binary or worker script path is missing or not executable. Assessments will fail until this is corrected under WP-Reconnaissance &raquo; Settings.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_worker_version(): array {
		$recent = $this->jobs->list_recent( 1 );

		if ( array() === $recent || null === $recent[0]->worker_version ) {
			return $this->result(
				'good',
				__( 'Worker version compatibility', 'wp-reconnaissance' ),
				__( 'No completed job has reported a worker version yet.', 'wp-reconnaissance' )
			);
		}

		$reported = $recent[0]->worker_version;

		if ( Runner::WORKER_VERSION === $reported ) {
			return $this->result(
				'good',
				__( 'Worker version matches', 'wp-reconnaissance' ),
				sprintf(
					/* translators: %s: worker version string */
					__( 'The most recent job ran collection worker version %s, matching this plugin.', 'wp-reconnaissance' ),
					$reported
				)
			);
		}

		return $this->result(
			'recommended',
			__( 'Worker version mismatch', 'wp-reconnaissance' ),
			sprintf(
				/* translators: 1: worker version reported by the most recent job, 2: version bundled with this plugin */
				__( 'The most recent job ran collection worker version %1$s, but this plugin bundles %2$s. Confirm the configured worker script path points at the current copy.', 'wp-reconnaissance' ),
				$reported,
				Runner::WORKER_VERSION
			)
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_worker_directory(): array {
		if ( ! (bool) get_option( 'wpr_local_adapter_enabled', false ) ) {
			return $this->result(
				'good',
				__( 'Worker directory permissions', 'wp-reconnaissance' ),
				__( 'Not applicable - the local execution adapter is not enabled.', 'wp-reconnaissance' )
			);
		}

		$dir = (string) get_option( 'wpr_worker_work_dir', sys_get_temp_dir() );

		if ( '' !== $dir && is_dir( $dir ) && is_writable( $dir ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
			return $this->result(
				'good',
				__( 'Worker directory is writable', 'wp-reconnaissance' ),
				__( 'The configured worker working directory exists and is writable.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'critical',
			__( 'Worker directory is not usable', 'wp-reconnaissance' ),
			__( 'The configured worker working directory does not exist or is not writable by the web server. Assessments using the local execution adapter will fail.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_evidence_storage(): array {
		$dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'wpr-evidence';

		if ( ! is_dir( $dir ) ) {
			return $this->result(
				'good',
				__( 'Evidence storage protection', 'wp-reconnaissance' ),
				__( 'Not applicable - no raw evidence has been stored yet.', 'wp-reconnaissance' )
			);
		}

		$protected = is_file( $dir . DIRECTORY_SEPARATOR . '.htaccess' ) && is_file( $dir . DIRECTORY_SEPARATOR . 'index.php' );

		if ( $protected ) {
			return $this->result(
				'good',
				__( 'Evidence storage is protected', 'wp-reconnaissance' ),
				__( 'The raw evidence directory has direct web access denied.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'critical',
			__( 'Evidence storage is not protected', 'wp-reconnaissance' ),
			__( 'The raw evidence directory is missing its access-denial files. Raw collection evidence may be reachable directly over the web.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_remote_worker(): array {
		if ( $this->remote_adapter->is_ready() ) {
			return $this->result(
				'good',
				__( 'Remote worker connectivity', 'wp-reconnaissance' ),
				__( 'The remote worker adapter is configured and reachable.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'good',
			__( 'Remote worker connectivity', 'wp-reconnaissance' ),
			__( 'Not applicable - the remote worker adapter is not available in this release; use the local execution adapter.', 'wp-reconnaissance' )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function check_retention_task(): array {
		$last_run_raw = get_option( 'wpr_retention_last_run_at', '' );

		if ( '' === $last_run_raw || ! is_string( $last_run_raw ) ) {
			return $this->result(
				'recommended',
				__( 'Retention sweep has not run yet', 'wp-reconnaissance' ),
				__( 'The retention and deletion sweep has never completed. It runs automatically as part of daily maintenance, or on demand via "wp reconnaissance retention run".', 'wp-reconnaissance' )
			);
		}

		$last_run = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $last_run_raw, new \DateTimeZone( 'UTC' ) );
		$stale    = false === $last_run || ( new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) )->getTimestamp() - $last_run->getTimestamp() > self::RETENTION_STALE_AFTER_HOURS * HOUR_IN_SECONDS;

		if ( $stale ) {
			return $this->result(
				'critical',
				__( 'Retention sweep is overdue', 'wp-reconnaissance' ),
				__( 'The retention and deletion sweep has not completed recently, even though it is scheduled daily. Check that scheduled tasks are running.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'good',
			__( 'Retention sweep is running', 'wp-reconnaissance' ),
			sprintf(
				/* translators: %s: date/time the retention sweep last completed */
				__( 'The retention and deletion sweep last completed at %s (UTC).', 'wp-reconnaissance' ),
				$last_run_raw
			)
		);
	}

	/**
	 * Section 33's operator-facing failure monitoring: how many scopes' most recent
	 * {@see self::REPEATED_FAILURE_THRESHOLD} jobs are all failures. The same signal the
	 * customer-facing "repeated collection failure" notification already reacts to per scope,
	 * surfaced fleet-wide here for an operator glancing at Site Health rather than waiting on a
	 * job to complete and trigger it.
	 *
	 * @return array<string,mixed>
	 */
	public function check_repeated_failures(): array {
		$count = count( $this->jobs->find_scopes_with_repeated_failures( self::REPEATED_FAILURE_THRESHOLD ) );

		if ( 0 === $count ) {
			return $this->result(
				'good',
				__( 'No scopes have repeated assessment failures', 'wp-reconnaissance' ),
				__( 'Every scope with a recent assessment has at least one recent success.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'recommended',
			__( 'Some scopes have repeated assessment failures', 'wp-reconnaissance' ),
			sprintf(
				/* translators: %d: number of affected scopes */
				_n(
					'%d scope\'s last several assessment attempts have all failed. Review it under WP-Reconnaissance &raquo; Jobs.',
					'%d scopes\' last several assessment attempts have all failed. Review them under WP-Reconnaissance &raquo; Jobs.',
					$count,
					'wp-reconnaissance'
				),
				$count
			)
		);
	}

	/**
	 * Section 33's CRM/service-account integration relies entirely on WordPress core's own
	 * Application Passwords feature for authentication - this confirms the site actually supports
	 * it (some hosts/plugins disable it, and it requires HTTPS by default) rather than a customer
	 * only discovering that when an external system's requests start failing.
	 *
	 * @return array<string,mixed>
	 */
	public function check_application_passwords(): array {
		if ( wp_is_application_passwords_available() ) {
			return $this->result(
				'good',
				__( 'Application Passwords are available', 'wp-reconnaissance' ),
				__( 'An external system (e.g. a CRM or PSA) can authenticate against the REST API using a WordPress Application Password.', 'wp-reconnaissance' )
			);
		}

		return $this->result(
			'recommended',
			__( 'Application Passwords are not available', 'wp-reconnaissance' ),
			__( 'No external system can authenticate against the REST API until Application Passwords are available - typically this means serving the site over HTTPS, or a plugin/filter has disabled the feature.', 'wp-reconnaissance' )
		);
	}

	// -----------------------------------------------------------------------------------
	// Info tab (Section 29: diagnostics exports must redact tokens, credentials, evidence and
	// personal information - every filesystem path below is marked private for exactly that
	// reason; nothing here is a token, credential or personal-data value).
	// -----------------------------------------------------------------------------------

	/**
	 * @param array<string,array<string,mixed>> $info
	 * @return array<string,array<string,mixed>>
	 */
	public function register_debug_information( array $info ): array {
		$info['wp-reconnaissance'] = array(
			'label'  => __( 'WP-Reconnaissance', 'wp-reconnaissance' ),
			'fields' => array(
				'db_schema_version'     => array(
					'label' => __( 'Database schema version', 'wp-reconnaissance' ),
					'value' => (string) get_option( 'wpr_db_schema_version', 0 ) . ' / ' . WPR_SCHEMA_VERSION,
				),
				'local_adapter_enabled' => array(
					'label' => __( 'Local execution adapter enabled', 'wp-reconnaissance' ),
					'value' => (bool) get_option( 'wpr_local_adapter_enabled', false ) ? __( 'Yes', 'wp-reconnaissance' ) : __( 'No', 'wp-reconnaissance' ),
				),
				'php_binary_path'       => array(
					'label'   => __( 'PHP CLI binary path', 'wp-reconnaissance' ),
					'value'   => (string) get_option( 'wpr_php_binary_path', '' ),
					'private' => true,
				),
				'worker_script_path'    => array(
					'label'   => __( 'Worker script path', 'wp-reconnaissance' ),
					'value'   => (string) get_option( 'wpr_worker_script_path', '' ),
					'private' => true,
				),
				'worker_work_dir'       => array(
					'label'   => __( 'Worker working directory', 'wp-reconnaissance' ),
					'value'   => (string) get_option( 'wpr_worker_work_dir', '' ),
					'private' => true,
				),
				'mail_queue_failed'     => array(
					'label' => __( 'Failed queued messages', 'wp-reconnaissance' ),
					'value' => (string) $this->mail_queue->count_failed(),
				),
				'retention_last_run'    => array(
					'label' => __( 'Retention sweep last ran (UTC)', 'wp-reconnaissance' ),
					'value' => (string) get_option( 'wpr_retention_last_run_at', __( 'Never', 'wp-reconnaissance' ) ),
				),
			),
		);

		return $info;
	}

	/**
	 * @return array<string,mixed>
	 */
	private function result( string $status, string $label, string $description ): array {
		return array(
			'label'       => $label,
			'status'      => $status,
			'badge'       => array(
				'label' => __( 'WP-Reconnaissance', 'wp-reconnaissance' ),
				'color' => 'blue',
			),
			'description' => '<p>' . esc_html( $description ) . '</p>',
			'actions'     => '',
			'test'        => 'wpr_site_health',
		);
	}
}
