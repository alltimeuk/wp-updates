<?php
/**
 * DNS TXT domain-ownership verification: an administrator or customer generates a random
 * per-challenge secret, publishes its SHA-256 hash as a `v=wpreconnaissance h={hash} t={date}`
 * TXT record on the domain itself, and this service checks whether that record now resolves. A
 * match authorises the scope through the same {@see \Alltime\WPReconnaissance\Data\Repositories\ScopeRepository::authorise()}
 * path every other authorisation route already uses - this is a new, verifiable way to trigger
 * that existing mechanism, not a new one.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Verification;

use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Entitlements\PlanEnforcementService;
use Alltime\WPReconnaissance\Entitlements\PlanLimitException;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Worker\Support\Dns;

final class DomainVerificationService {

	/**
	 * The schema version that introduced the domain-verification columns this entire service
	 * depends on (see Schema::version_12_statements()) - deliberately a local constant, not the
	 * plugin-wide WPR_SCHEMA_VERSION. Migrator::maybe_upgrade() stops at the *first* failing
	 * version, so a later, unrelated migration failing would leave the stored version behind
	 * WPR_SCHEMA_VERSION while these columns are still perfectly fine; comparing against the
	 * global constant would then block domain verification for no reason connected to it.
	 */
	private const REQUIRED_SCHEMA_VERSION = 12;

	/**
	 * @param callable(string,int):array<int,array<string,mixed>> $dns_query Defaults to
	 *        {@see Dns::query()}; overridable so tests can assert against deterministic TXT
	 *        responses instead of depending on public DNS (Section 8).
	 */
	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly PlanEnforcementService $plan_enforcement = new PlanEnforcementService(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private $dns_query = array( Dns::class, 'query' )
	) {}

	/**
	 * Starts (or restarts) a DNS verification challenge for a scope. The returned hash is the
	 * value to publish - it is derived from a random secret discarded immediately after hashing;
	 * there is no raw secret to protect, since the hash itself is meant to be made public.
	 */
	public function generate_challenge( int $scope_id, int $requested_by, string $source ): string {
		self::assert_schema_ready();

		$hash = hash( 'sha256', bin2hex( random_bytes( 32 ) ) );

		$this->scopes->start_domain_verification( $scope_id, $hash, $requested_by );

		$this->audit_logger->log(
			'scope.domain_verification_started',
			'scope',
			$scope_id,
			$requested_by,
			source: $source
		);

		return $hash;
	}

	/**
	 * The exact TXT record value to publish on the domain itself (never a subdomain).
	 */
	public function txt_record_value( string $hash, ?\DateTimeImmutable $requested_at = null ): string {
		return sprintf(
			'v=wpreconnaissance h=%s t=%s',
			$hash,
			gmdate( 'Y-m-d', $requested_at?->getTimestamp() ?? time() )
		);
	}

	/**
	 * Runs one DNS TXT lookup against the scope's domain and compares any `v=wpreconnaissance
	 * h=...` record found to the scope's outstanding challenge hash. On a match, authorises the
	 * scope (Section 27's authorised-use notice requirement is satisfied by the on-screen
	 * verification instructions themselves, not by this method). On no match, the scope is left
	 * `pending` for a later check - not logged, since a 30-minute sweep re-checking every
	 * outstanding challenge would otherwise fill the audit log with non-events.
	 *
	 * @throws PlanLimitException Propagated from {@see PlanEnforcementService::assert_can_authorise_scope()}
	 *                             so a caller sweeping many scopes can catch it per-scope rather
	 *                             than have one over-limit organisation abort the whole batch.
	 * @throws SchemaNotReadyException See {@see assert_schema_ready()}.
	 * @throws \Alltime\WPReconnaissance\Data\Repositories\ScopeRepositoryException Propagated from
	 *          {@see \Alltime\WPReconnaissance\Data\Repositories\ScopeRepository::verify_and_authorise()}
	 *          on a genuine database failure - distinct from that same method's ordinary `false`
	 *          return for an already-transitioned/no-longer-pending scope, which this method still
	 *          treats as a benign no-op below.
	 */
	public function check( Scope $scope, string $source ): bool {
		self::assert_schema_ready();

		if ( 'pending' !== $scope->domain_verification_status || null === $scope->domain_verification_secret_hash ) {
			return false;
		}

		if ( ! $this->has_matching_txt_record( $scope->domain_ascii, $scope->domain_verification_secret_hash ) ) {
			return false;
		}

		$this->plan_enforcement->assert_can_authorise_scope( $scope->organisation_id );

		// Conditioned on the row's *currently persisted* status, not $scope's possibly-stale
		// in-memory one - if a concurrent caller (an overlapping sweep tick, say) already
		// completed this transition, this is a no-op and neither audit event below fires twice.
		if ( ! $this->scopes->verify_and_authorise( $scope->id ) ) {
			return false;
		}

		$this->audit_logger->log( 'scope.domain_verified', 'scope', $scope->id, null, source: $source );
		$this->audit_logger->log( 'scope.authorised', 'scope', $scope->id, null, summary: 'DNS TXT verification', source: $source );

		return true;
	}

	/**
	 * The 30-minute sweep entry point: checks every scope with an outstanding challenge, capped
	 * per run so a large backlog can't turn one sweep into an unbounded batch of DNS lookups.
	 */
	public function run_sweep(): void {
		$max = (int) get_option( 'wpr_max_domain_verifications_per_sweep', 50 );

		foreach ( $this->scopes->find_pending_domain_verification( $max ) as $scope ) {
			try {
				$this->check( $scope, 'cron' );
			} catch ( \Throwable $e ) {
				$this->audit_logger->log(
					'scope.domain_verification_check_failed',
					'scope',
					$scope->id,
					null,
					outcome: 'failure',
					summary: $e->getMessage(),
					source: 'cron'
				);
			}
		}
	}

	private function has_matching_txt_record( string $domain, string $expected_hash ): bool {
		foreach ( ( $this->dns_query )( $domain, DNS_TXT ) as $record ) {
			// A record that isn't itself an array is not a shape this format recognises - real
			// dns_get_record() never produces one, but $dns_query is an injectable callable
			// (tests substitute it, and it's still reachable from a misbehaving resolver in
			// principle), and reconstruct_txt_value()'s `array $record` parameter would otherwise
			// throw an uncaught TypeError here instead of just not matching.
			if ( ! is_array( $record ) ) {
				continue;
			}

			$hash = $this->extract_hash( $this->reconstruct_txt_value( $record ) );

			if ( null !== $hash && hash_equals( $expected_hash, $hash ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * A single DNS TXT resource record can carry its value split across multiple <255-byte
	 * character-string fragments, joined back into one record on the wire - never across
	 * separate records, which {@see has_matching_txt_record()}'s per-record loop already keeps
	 * distinct. PHP's own `dns_get_record()` already concatenates these into `txt` with no
	 * separator (verified directly against php-src's `ext/standard/dns.c`: `entries` holds the
	 * same fragments individually, `txt` is their direct `memcpy` concatenation) - `entries` is
	 * therefore normally redundant, but is used as a defensive fallback if `txt` is ever absent
	 * or empty while fragments are still present, rather than trusting a single field exclusively.
	 *
	 * @param array<string,mixed> $record
	 */
	private function reconstruct_txt_value( array $record ): string {
		$txt = $record['txt'] ?? '';

		// Real dns_get_record() only ever puts a string here; a non-string value is not a shape
		// this format recognises, so it's treated the same as absent rather than coerced (which
		// would risk matching on a misleadingly stringified value instead of correctly rejecting
		// the record).
		if ( is_string( $txt ) && '' !== $txt ) {
			return $txt;
		}

		if ( isset( $record['entries'] ) && is_array( $record['entries'] ) ) {
			foreach ( $record['entries'] as $entry ) {
				// A fragment that isn't itself a plain string can't be part of a legitimate
				// on-the-wire TXT value - reject the whole record rather than silently coercing
				// it (array_map( 'strval', ... ) would otherwise emit an "Array to string
				// conversion" warning for a nested-array fragment and still fail to match).
				if ( ! is_string( $entry ) ) {
					return '';
				}
			}

			return implode( '', $record['entries'] );
		}

		return '';
	}

	private function extract_hash( string $txt_value ): ?string {
		if ( 1 === preg_match( '/^v=wpreconnaissance\s+h=([0-9a-f]{64})(?:\s+t=\S+)?$/', trim( $txt_value ), $matches ) ) {
			return $matches[1];
		}

		return null;
	}

	/**
	 * A stuck-at-an-earlier-version install (Section 7) is missing the columns
	 * start_domain_verification()/verify_and_authorise() write to - without this guard, either
	 * would fail with a raw, uncaught database error instead of this clear, safe message.
	 *
	 * @throws SchemaNotReadyException
	 */
	private static function assert_schema_ready(): void {
		if ( (int) get_option( 'wpr_db_schema_version', 0 ) < self::REQUIRED_SCHEMA_VERSION ) {
			throw new SchemaNotReadyException(
				esc_html__( 'Domain verification is temporarily unavailable while a required database upgrade completes.', 'wp-reconnaissance' )
			);
		}
	}
}
