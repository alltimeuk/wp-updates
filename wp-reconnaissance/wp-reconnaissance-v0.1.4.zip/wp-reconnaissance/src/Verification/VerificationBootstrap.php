<?php
/**
 * Schedules the recurring DNS domain-verification sweep, per the DNS TXT domain-ownership
 * verification feature. A dedicated bootstrap, separate from {@see \Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap},
 * since it owns its own cron interval and hook rather than reusing the existing daily
 * maintenance sweep.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Verification;

final class VerificationBootstrap {

	public const RUN_SWEEP_HOOK = 'wpr_run_domain_verification_sweep';

	private const INTERVAL_SLUG = 'wpr_thirty_minutes';

	public function boot(): void {
		add_filter( 'cron_schedules', array( $this, 'register_thirty_minute_interval' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 30 minutes is intentional, not the "at least hourly" this sniff nudges toward; see the class docblock.
		add_action( self::RUN_SWEEP_HOOK, array( $this, 'run_sweep' ) );
		add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
	}

	/**
	 * @param array<string,array{interval:int,display:string}> $schedules
	 *
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function register_thirty_minute_interval( array $schedules ): array {
		$schedules[ self::INTERVAL_SLUG ] = array(
			'interval' => 30 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 30 minutes (WP-Reconnaissance domain verification)', 'wp-reconnaissance' ),
		);

		return $schedules;
	}

	/**
	 * Schedules the recurring sweep on first boot after activation. Idempotent: wp_next_scheduled()
	 * prevents piling up duplicate recurring schedules on every request.
	 */
	public function ensure_sweep_scheduled(): void {
		if ( false === wp_next_scheduled( self::RUN_SWEEP_HOOK ) ) {
			wp_schedule_event( time(), self::INTERVAL_SLUG, self::RUN_SWEEP_HOOK );
		}
	}

	public function run_sweep(): void {
		( new DomainVerificationService() )->run_sweep();
	}
}
