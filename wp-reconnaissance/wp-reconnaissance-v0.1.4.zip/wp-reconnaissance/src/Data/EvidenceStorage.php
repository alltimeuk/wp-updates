<?php
/**
 * Stores the full raw evidence document in a protected uploads subdirectory, per Section 9:
 * "Raw evidence may be stored in a protected uploads subdirectory... Direct web access must be
 * denied. Downloads must pass WordPress authentication and authorisation."
 *
 * Only the reference returned by {@see store()} is persisted in `wpr_observations`; access to
 * the file itself must always go through an authenticated, capability-checked download handler
 * - nothing in this class is a public URL.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data;

final class EvidenceStorage {

	/**
	 * Writes the evidence document and returns a reference to store in `raw_evidence_ref`.
	 */
	public function store( string $job_uuid, string $evidence_json ): string {
		$dir = $this->directory();

		$this->ensure_protected( $dir );

		$safe_name = preg_replace( '/[^A-Za-z0-9._-]/', '', $job_uuid );
		$path      = $dir . DIRECTORY_SEPARATOR . "{$safe_name}.json";

		if ( false === file_put_contents( $path, $evidence_json, LOCK_EX ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			throw new \RuntimeException( esc_html( 'Unable to write evidence document to protected storage.' ) );
		}

		chmod( $path, 0600 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod

		return "wpr-evidence/{$safe_name}.json";
	}

	/**
	 * Removes the stored evidence file for a reference, if it still exists - the retention
	 * sweep's counterpart to {@see store()} (Section 26.7).
	 */
	public function delete( string $reference ): void {
		$path = $this->directory() . DIRECTORY_SEPARATOR . basename( $reference );

		if ( is_file( $path ) ) {
			wp_delete_file( $path );
		}
	}

	public function retrieve( string $reference ): ?string {
		$path = $this->directory() . DIRECTORY_SEPARATOR . basename( $reference );

		if ( ! is_file( $path ) ) {
			return null;
		}

		$contents = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		return false !== $contents ? $contents : null;
	}

	private function directory(): string {
		$upload_dir = wp_upload_dir();

		return trailingslashit( $upload_dir['basedir'] ) . 'wpr-evidence';
	}

	private function ensure_protected( string $dir ): void {
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		$htaccess = $dir . DIRECTORY_SEPARATOR . '.htaccess';
		if ( ! is_file( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$index = $dir . DIRECTORY_SEPARATOR . 'index.php';
		if ( ! is_file( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}
}
