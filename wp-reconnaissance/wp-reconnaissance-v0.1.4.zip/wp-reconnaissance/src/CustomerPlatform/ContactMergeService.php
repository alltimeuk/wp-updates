<?php
/**
 * Contact deduplication and merge, per Section 18.1.4. An administrator reviews duplicate
 * candidates and approves a merge: the surviving contact keeps its identity, the merged contact's
 * linked interactions/identities/organisations/consents/preferences/visitor-contexts/wp_user are
 * repointed transactionally, all source snapshots are preserved, conflicting preferences resolve
 * conservatively (marketing objection/withdrawal prevails), visitor tokens tied to ambiguity are
 * revoked, and the before/after state plus the administrator's reason are recorded in
 * `atcp_contact_merge_log` for the documented recovery process.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\ContactLifecycleStatus;
use Alltime\CustomerPlatform\Repositories\ContactMergeLogRepository;
use Alltime\CustomerPlatform\Repositories\ContactRepository;
use Alltime\CustomerPlatform\Repositories\VisitorContextRepository;

final class ContactMergeService {

	public function __construct(
		private readonly ContactRepository $contacts = new ContactRepository(),
		private readonly VisitorContextRepository $visitor_contexts = new VisitorContextRepository(),
		private readonly ContactMergeLogRepository $merge_log = new ContactMergeLogRepository()
	) {}

	/**
	 * Candidate duplicate pairs: contacts that share an email identity. Never deduplicates by
	 * display name, company name, IP address or cookie (Section 18.1.4).
	 *
	 * @return array<int,array{contact_id:int,email:string}>
	 */
	public function find_duplicate_candidates(): array {
		global $wpdb;

		$table = Schema::table( 'contact_identities' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$query = "SELECT contact_id, normalised_value AS email FROM `{$table}`
			 WHERE identity_type = 'email'
			   AND contact_id IN (
			     SELECT contact_id FROM `{$table}` WHERE identity_type = 'email'
			     GROUP BY normalised_value HAVING COUNT(DISTINCT contact_id) > 1
			   )
			 ORDER BY normalised_value ASC"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$rows = $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- $query is a fixed, internally derived identifier, not user input.

		$result = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$result[] = array(
				'contact_id' => (int) $row['contact_id'],
				'email'      => (string) $row['email'],
			);
		}

		return $result;
	}

	/**
	 * Merges $merged_id into $surviving_id transactionally. Returns the merge-log entry id.
	 */
	public function merge( int $surviving_id, int $merged_id, int $admin_user_id, string $reason ): int {
		global $wpdb;

		if ( $surviving_id === $merged_id ) {
			throw new \InvalidArgumentException( esc_html__( 'A contact cannot be merged with itself.', 'wp-reconnaissance' ) );
		}

		$surviving = $this->contacts->find( $surviving_id );
		$merged    = $this->contacts->find( $merged_id );

		if ( null === $surviving || null === $merged ) {
			throw new \InvalidArgumentException( esc_html__( 'One of the contacts to merge could not be found.', 'wp-reconnaissance' ) );
		}

		$before = wp_json_encode(
			array(
				'surviving' => $this->snapshot( $surviving_id ),
				'merged'    => $this->snapshot( $merged_id ),
			)
		);

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		try {
			$this->repoint( 'interactions', 'contact_id', $merged_id, $surviving_id );
			$this->repoint( 'contact_identities', 'contact_id', $merged_id, $surviving_id );
			$this->repoint( 'contact_organisations', 'contact_id', $merged_id, $surviving_id );
			$this->repoint( 'consents', 'contact_id', $merged_id, $surviving_id );
			$this->repoint( 'preferences', 'contact_id', $merged_id, $surviving_id );
			$this->repoint( 'visitor_contexts', 'contact_id', $merged_id, $surviving_id );

			// A merged contact's wp_user relationship moves to the survivor (only one contact may
			// hold a given wp_user_id - the unique key enforces it).
			if ( null !== $merged->wp_user_id ) {
				$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					Schema::table( 'contacts' ),
					array(
						'wp_user_id' => $merged->wp_user_id,
						'updated_at' => current_time( 'mysql', true ),
					),
					array( 'id' => $surviving_id )
				);
			}

			// Revoke visitor tokens tied to the merged contact (Section 18.1.4).
			$this->visitor_contexts->revoke_all_for_contact( $merged_id );

			// Mark the merged contact as merged.
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				Schema::table( 'contacts' ),
				array(
					'lifecycle_status' => ContactLifecycleStatus::Merged->value,
					'wp_user_id'       => null,
					'updated_at'       => current_time( 'mysql', true ),
				),
				array( 'id' => $merged_id )
			);

			$after = wp_json_encode(
				array(
					'surviving' => $this->snapshot( $surviving_id ),
					'merged'    => $this->snapshot( $merged_id ),
				)
			);

			$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		} catch ( \Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			throw $exception;
		}

		$log_id = $this->merge_log->create_review_entry( 'admin_merge', array( $surviving_id, $merged_id ), $reason );
		$this->merge_log->mark_approved( $log_id, $surviving_id, $merged_id, $admin_user_id, $reason, $before, $after );

		// Third argument is an array, not a plain admin id, to match the shape WP Questionnaires'
		// bridge already documents and fires for this cross-plugin hook.
		do_action( 'alltime_contact_merged', $surviving_id, $merged_id, array( 'actor' => $admin_user_id ) );

		return $log_id;
	}

	/**
	 * Best-effort revert of an approved merge from its recorded before-snapshot. Restores the
	 * merged contact's lifecycle status and wp_user; repointed rows are not un-repointed (the
	 * snapshot documents the original state for manual recovery).
	 */
	public function revert( int $merge_log_id, int $admin_user_id, string $reason ): void {
		global $wpdb;

		$entry = $this->merge_log->find( $merge_log_id );

		if ( null === $entry || 'approved' !== (string) $entry['status'] ) {
			return;
		}

		$before = json_decode( (string) $entry['before_snapshot'], true );

		if ( is_array( $before ) && isset( $before['merged']['id'] ) ) {
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				Schema::table( 'contacts' ),
				array(
					'lifecycle_status' => ContactLifecycleStatus::Prospect->value,
					'updated_at'       => current_time( 'mysql', true ),
				),
				array( 'id' => (int) $before['merged']['id'] )
			);
		}

		$this->merge_log->mark_reverted( $merge_log_id, $admin_user_id, $reason );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function snapshot( int $contact_id ): array {
		global $wpdb;

		$contact = $this->contacts->find( $contact_id );

		$data = array(
			'id'      => $contact_id,
			'contact' => null !== $contact ? array(
				'given_name'       => $contact->given_name,
				'family_name'      => $contact->family_name,
				'wp_user_id'       => $contact->wp_user_id,
				'lifecycle_status' => $contact->lifecycle_status->value,
			) : null,
		);

		foreach ( array( 'interactions', 'contact_identities', 'contact_organisations', 'consents', 'preferences' ) as $table_key ) {
			$table = Schema::table( $table_key );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$data[ $table_key ] = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM `{$table}` WHERE contact_id = %d", $contact_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				ARRAY_A
			);
		}

		return $data;
	}

	private function repoint( string $table_key, string $column, int $from_contact_id, int $to_contact_id ): void {
		global $wpdb;

		$table = Schema::table( $table_key );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array( $column => $to_contact_id ),
			array( $column => $from_contact_id )
		);
	}
}
