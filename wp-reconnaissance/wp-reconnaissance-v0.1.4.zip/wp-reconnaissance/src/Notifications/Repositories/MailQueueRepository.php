<?php
/**
 * Persistence for the transactional mail queue against `wpr_mail_queue`, per Section 22.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\Enums\MailState;
use Alltime\WPReconnaissance\Notifications\QueuedMail;

final class MailQueueRepository {

	public function find( int $id ): ?QueuedMail {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? QueuedMail::from_row( $row ) : null;
	}

	/**
	 * Section 22.5: "Prevent duplicate sends through idempotency keys." A message already
	 * pending, sending or sent for this key is never re-queued; only a previously Failed attempt
	 * may be retried by enqueuing again (a fresh row - failures keep their own history).
	 */
	public function find_active_by_idempotency_key( string $idempotency_key ): ?QueuedMail {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE idempotency_key = %s AND state IN ('pending','sending','sent') ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$idempotency_key
			),
			ARRAY_A
		);

		return null !== $row ? QueuedMail::from_row( $row ) : null;
	}

	public function enqueue( QueuedMessage $message ): QueuedMail {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'idempotency_key' => $message->idempotency_key,
				'recipient'       => $message->recipient,
				'template'        => $message->template,
				'purpose'         => $message->purpose->value,
				'subject'         => $message->subject,
				'html_body'       => $message->html_body,
				'merge_fields'    => wp_json_encode( $message->merge_fields ),
				'state'           => MailState::Pending->value,
				'created_at'      => $now,
				'updated_at'      => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function mark_sending( int $id ): QueuedMail {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'         => MailState::Sending->value,
				'attempt_count' => $this->find_or_fail( $id )->attempt_count + 1,
				'updated_at'    => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function mark_sent( int $id, string $provider_id, string $provider_message_id ): QueuedMail {
		global $wpdb;

		$now = current_time( 'mysql', true );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'               => MailState::Sent->value,
				'provider_id'         => $provider_id,
				'provider_message_id' => $provider_message_id,
				'sent_at'             => $now,
				'updated_at'          => $now,
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function mark_failed( int $id ): QueuedMail {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'           => MailState::Failed->value,
				'next_attempt_at' => null,
				'updated_at'      => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function schedule_retry( int $id, \DateTimeImmutable $next_attempt_at ): QueuedMail {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'           => MailState::Pending->value,
				'next_attempt_at' => $next_attempt_at->format( 'Y-m-d H:i:s' ),
				'updated_at'      => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function mark_suppressed( int $id ): QueuedMail {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'      => MailState::Suppressed->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	/**
	 * Pending messages whose retry backoff has elapsed (or that have never been attempted),
	 * for the retry sweep.
	 *
	 * @return QueuedMail[]
	 */
	public function find_due( int $limit = 50 ): array {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE state = 'pending' AND (next_attempt_at IS NULL OR next_attempt_at <= %s) ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$limit
			),
			ARRAY_A
		);

		return array_map( array( QueuedMail::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Rows older than a cutoff, in a terminal state - for the retention sweep.
	 *
	 * @return int[] IDs only, to keep this cheap for a potentially large purge.
	 */
	public function find_terminal_ids_before( \DateTimeImmutable $cutoff, int $limit = 500 ): array {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM `{$table}` WHERE state IN ('sent','failed','suppressed') AND updated_at < %s LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$cutoff->format( 'Y-m-d H:i:s' ),
				$limit
			)
		);

		return array_map( 'intval', $rows );
	}

	/**
	 * Every queued message ever sent to an address - the personal-data locator/eraser's source
	 * for "mail events" (Section 26.4: "find all linked data across... mail events").
	 *
	 * @return QueuedMail[]
	 */
	public function find_by_recipient( string $email ): array {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE recipient = %s ORDER BY id DESC", $email ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array_map( array( QueuedMail::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Count of messages currently in a Failed state - the Site Health "queue operation" check's
	 * signal that something needs operator attention (Section 29).
	 */
	public function count_failed(): int {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE state = %s", MailState::Failed->value ) );
	}

	public function delete( int $id ): void {
		global $wpdb;

		$wpdb->delete( Schema::table( 'mail_queue' ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	private function find_or_fail( int $id ): QueuedMail {
		$mail = $this->find( $id );

		if ( null === $mail ) {
			throw new \RuntimeException( esc_html( "Queued mail {$id} was expected to exist but could not be loaded." ) );
		}

		return $mail;
	}
}
