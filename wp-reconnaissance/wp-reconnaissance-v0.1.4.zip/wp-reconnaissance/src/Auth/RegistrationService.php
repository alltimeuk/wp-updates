<?php
/**
 * Handles new customer registration, per Section 18.2 and the journey in Section 5.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\CustomerPlatform\ConsentInput;
use Alltime\CustomerPlatform\ContactInput;
use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\VisitorContextPlatformDiscovery;
use Alltime\CustomerPlatform\Enums\ConsentState;
use Alltime\CustomerPlatform\InteractionInput;
use Alltime\CustomerPlatform\PurposeContext;
use Alltime\WPReconnaissance\AntiAbuse\AntiAbuseService;
use Alltime\WPReconnaissance\AntiAbuse\RegistrationContext;
use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Auth\Exceptions\RegistrationException;
use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\DomainValidator;
use Alltime\WPReconnaissance\Domain\Exceptions\InvalidDomainException;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class RegistrationService {

	private const MINIMUM_PASSWORD_LENGTH       = 12;
	public const EMAIL_VERIFICATION_TTL_SECONDS = 24 * HOUR_IN_SECONDS;

	/** Mirrors the default collector set {@see \Alltime\WPReconnaissance\Admin\AdminBootstrap} offers for an operator-created scope. */
	private const DEFAULT_COLLECTORS = array( 'rdap', 'dns', 'dnssec', 'mail', 'http', 'tls', 'ct', 'subdomains', 'lookalikes' );

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly DomainValidator $domain_validator = new DomainValidator(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly AntiAbuseService $anti_abuse = new AntiAbuseService()
	) {}

	/**
	 * Section 5.3 steps 5-10: the registration form itself collects the domain and the customer's
	 * confirmation of authority to assess it, and creates the scope immediately - but leaves it
	 * unauthorised until the account's email is verified ({@see
	 * \Alltime\WPReconnaissance\Auth\FreeAssessmentService}), so the free assessment can never be
	 * dispatched against an unverified email address.
	 *
	 * @throws RegistrationException When the submitted input itself is invalid. Never thrown
	 *                                 for an email address that is already registered.
	 */
	public function register(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		string $domain,
		bool $domain_authorisation_confirmed,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged,
		bool $marketing_consent,
		string $client_ip = '0.0.0.0',
		array $captcha_input = array()
	): RegistrationResult {
		$this->validate(
			$given_name,
			$family_name,
			$email,
			$organisation_name,
			$password,
			$password_confirmation,
			$terms_accepted,
			$privacy_acknowledged
		);

		if ( ! $domain_authorisation_confirmed ) {
			throw new RegistrationException( 'You must confirm that you own or have authority to assess this domain.' );
		}

		try {
			$validated_domain = $this->domain_validator->validate( $domain );
		} catch ( InvalidDomainException $exception ) {
			throw new RegistrationException( $exception->getMessage() ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- an exception message is not browser output; AuthBootstrap escapes it via esc_html() when rendering it.
		}

		// Section 5.6 layered anti-abuse: a hard block (blocklist match or failed bot challenge)
		// rejects the registration with a generic message that discloses no detection logic.
		$decision = $this->anti_abuse->evaluate_registration(
			new RegistrationContext(
				email: $email,
				registrable_domain: $validated_domain->registrable,
				ip: $client_ip,
				captcha_input: $captcha_input
			),
			(int) get_option( 'wpr_abuse_max_queued_jobs', 0 )
		);

		if ( $decision->blocks() ) {
			throw new RegistrationException( 'We could not complete your registration. Please contact support if you believe this is in error.' );
		}

		$existing = $this->accounts->find_by_email( $email );

		if ( null !== $existing ) {
			// Section 18.1: do not reveal that this address is already registered. The caller
			// shows the identical "check your email" response either way.
			$this->audit_logger->log( 'registration.duplicate_attempt', 'customer_account', $existing->user_id, outcome: 'rejected' );

			return new RegistrationResult( is_new: false, account: null, verification_token: null );
		}

		$organisation = $this->organisations->create(
			$organisation_name,
			$this->organisations->unique_slug( $organisation_name )
		);

		$account = $this->accounts->create(
			$email,
			$password,
			$given_name,
			$family_name,
			(int) $organisation->id,
			$marketing_consent
		);

		$this->audit_logger->log( 'registration.created', 'customer_account', $account->user_id, $account->user_id );

		$this->record_contact_platform_registration( $given_name, $family_name, $email, $organisation_name, $account->user_id, (int) $organisation->id, $marketing_consent );

		$scope = $this->scopes->create(
			(int) $organisation->id,
			$organisation_name,
			$validated_domain->ascii,
			$validated_domain->display,
			$validated_domain->registrable,
			self::DEFAULT_COLLECTORS
		);

		$this->audit_logger->log( 'scope.created', 'scope', $scope->id, $account->user_id, summary: $scope->domain_display );

		$verification_token = $this->tokens->issue( $account->user_id, TokenType::EmailVerification, self::EMAIL_VERIFICATION_TTL_SECONDS );

		return new RegistrationResult( is_new: true, account: $account, verification_token: $verification_token );
	}

	/**
	 * Creates or links the canonical contact for this registration via the shared Customer
	 * Platform (Section 6.1.2), proving {@see \Alltime\CustomerPlatform\ContactServiceInterface}
	 * end to end from its first real consumer. Section 6.1.3: "Plugins shall fail safely if a
	 * required contract version is unavailable" - if no provider is registered, registration
	 * still succeeds; the WordPress account remains the source of truth either way.
	 */
	private function record_contact_platform_registration(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		int $user_id,
		int $organisation_id,
		bool $marketing_consent
	): void {
		$contact_service = ContactPlatformDiscovery::resolve();

		if ( null === $contact_service ) {
			return;
		}

		$purpose = new PurposeContext( 'wp-reconnaissance', 'customer_registration' );

		$result = $contact_service->create_or_update_contact(
			new ContactInput( $given_name, $family_name, $email, null, $organisation_name ),
			$purpose
		);

		$contact_service->link_wordpress_user( $result->contact->id, $user_id );

		// Associate the cross-tool visitor context with the newly registered contact (Section 18.1.3).
		VisitorContextPlatformDiscovery::resolve()?->handle_authenticated_identity( $result->contact->id );

		$contact_service->record_interaction(
			$result->contact->id,
			new InteractionInput(
				product_id: 'wp-reconnaissance',
				interaction_type: 'registration_completed',
				source_object_type: 'customer_account',
				source_object_id: $user_id,
				organisation_id: $organisation_id
			)
		);

		$contact_service->record_consent(
			$result->contact->id,
			new ConsentInput(
				purpose: 'marketing',
				state: $marketing_consent ? ConsentState::Granted : ConsentState::Withdrawn,
				source: 'registration_form'
			)
		);
	}

	private function validate(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged
	): void {
		if ( '' === trim( $given_name ) || '' === trim( $family_name ) ) {
			throw new RegistrationException( 'Given name and family name are required.' );
		}

		if ( ! is_email( $email ) ) {
			throw new RegistrationException( 'A valid business email address is required.' );
		}

		if ( '' === trim( $organisation_name ) ) {
			throw new RegistrationException( 'Organisation name is required.' );
		}

		if ( strlen( $password ) < self::MINIMUM_PASSWORD_LENGTH ) {
			throw new RegistrationException( 'Password must be at least ' . self::MINIMUM_PASSWORD_LENGTH . ' characters long.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- an exception message is not browser output; AuthBootstrap escapes it via esc_html() when rendering it.
		}

		if ( $password !== $password_confirmation ) {
			throw new RegistrationException( 'Password and confirmation do not match.' );
		}

		if ( ! $terms_accepted ) {
			throw new RegistrationException( 'You must accept the service terms to register.' );
		}

		if ( ! $privacy_acknowledged ) {
			throw new RegistrationException( 'You must acknowledge the privacy notice to register.' );
		}
	}
}
