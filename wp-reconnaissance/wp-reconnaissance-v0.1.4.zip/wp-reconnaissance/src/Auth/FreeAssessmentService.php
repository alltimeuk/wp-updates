<?php
/**
 * Completes Section 5.3's self-service journey once a customer's email is verified: authorises
 * the scope created at registration and, if the free-use entitlement (Section 5.5) allows it,
 * queues the assessment - so a customer never waits on an operator to see their first result.
 *
 * Deliberately triggered by email verification, not registration itself (Section 5.6: "Apply
 * layered controls... Email verification"): dispatching a collection job against a domain before
 * the requester has proven control of the email address they registered with would let anyone
 * queue a scan of an arbitrary domain by typing someone else's address into the registration form.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\WPReconnaissance\AntiAbuse\AntiAbuseService;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Entitlements\EntitlementService;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Tools\ToolsBootstrap;

final class FreeAssessmentService {

	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly EntitlementService $entitlements = new EntitlementService(),
		private readonly SchedulingBootstrap $scheduling = new SchedulingBootstrap(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly AntiAbuseService $anti_abuse = new AntiAbuseService(),
		private readonly JobRepository $jobs = new JobRepository()
	) {}

	/**
	 * Authorises every still-pending scope belonging to the newly verified account's organisation
	 * (in practice, the single scope {@see RegistrationService::register()} created) and attempts
	 * to dispatch the free assessment for each. Never throws: a customer who cannot yet be
	 * entitled (no Customer Platform provider registered, or - unexpectedly for a brand-new
	 * registration - no entitlement available) still gets a verified, authorised scope; an
	 * operator can dispatch it manually from the admin Scopes screen either way.
	 */
	public function provision_for_verified_account( CustomerAccount $account ): void {
		foreach ( $this->scopes->find_by_organisation( $account->organisation_id ) as $scope ) {
			if ( 'pending' !== $scope->authorisation_status ) {
				continue;
			}

			$scope = $this->scopes->authorise( $scope->id, $account->user_id, 'Self-certified by the account holder at registration, confirmed via email verification.' );

			$this->audit_logger->log( 'scope.authorised', 'scope', $scope->id, $account->user_id, summary: 'self_service' );

			// Section 5.6: an open review signal (disposable email, duplicate domain, or the
			// max-queued-jobs throttle) holds the free assessment until an operator releases it.
			if ( $this->anti_abuse->has_open_review( $account->email, $scope->registrable_domain ) ) {
				$this->audit_logger->log( 'abuse.assessment_held_for_review', 'scope', $scope->id, $account->user_id, outcome: 'review', summary: 'free_assessment_held' );

				continue;
			}

			$this->dispatch_free_assessment( $scope, $account );
		}
	}

	/**
	 * Dispatches the free assessment for an account's already-authorised scopes that have not yet
	 * been dispatched. Used by the admin Abuse-review screen when an operator releases a held
	 * signal, so a legitimate customer still gets their result without waiting on an operator.
	 */
	public function dispatch_free_assessment_for_account( CustomerAccount $account ): void {
		foreach ( $this->scopes->find_by_organisation( $account->organisation_id ) as $scope ) {
			if ( 'authorised' !== $scope->authorisation_status ) {
				continue;
			}

			if ( count( $this->jobs->find_by_scope( $scope->id ) ) > 0 ) {
				continue; // Already dispatched - keep the release action idempotent.
			}

			$this->dispatch_free_assessment( $scope, $account );
		}
	}

	private function dispatch_free_assessment( Scope $scope, CustomerAccount $account ): void {
		$contact = ContactPlatformDiscovery::resolve()?->get_contact_for_user( $account->user_id );

		if ( null === $contact ) {
			return;
		}

		$decision = $this->entitlements->check( $contact->id, ToolsBootstrap::DOMAIN_RECONNAISSANCE_TOOL_ID, $scope->registrable_domain, organisation_id: $scope->organisation_id );

		if ( ! $decision->allowed ) {
			return;
		}

		$this->entitlements->reserve( $contact->id, ToolsBootstrap::DOMAIN_RECONNAISSANCE_TOOL_ID, $scope->registrable_domain );
		$this->scheduling->schedule_assessment( $scope->id, $account->user_id );
	}
}
