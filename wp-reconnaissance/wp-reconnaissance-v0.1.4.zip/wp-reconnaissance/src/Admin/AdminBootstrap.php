<?php
/**
 * Administrative interface bootstrap, per Section 19.
 *
 * Registers the principal admin screens (Overview, Organisations, Scopes, Jobs, Findings,
 * Reports, Settings) with real data and actions throughout, including issuing reports (Section
 * 19.6/21): generate a draft, review it, add an executive summary, then issue an immutable
 * version - generating a report also refreshes the scope's remediation tasks first, so the plan
 * it contains is always current.
 *
 * Rendering here is deliberately plain, unescaped-by-hand HTML in the style already established
 * by {@see \Alltime\WPReconnaissance\Auth\AuthBootstrap} for the customer portal - functional
 * end-to-end rather than the polished, JS-driven list tables a later pass could build.
 *
 * Form submissions are handled on `admin_init` (before any admin chrome has been output), never
 * inside a render_* callback, because a callback registered via {@see add_submenu_page()} only
 * runs after WordPress has already started writing the page - a redirect from inside it would
 * fail with "headers already sent".
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Admin;

use Alltime\WPReconnaissance\AntiAbuse\AntiAbuseService;
use Alltime\WPReconnaissance\Api\RestBootstrap;
use Alltime\WPReconnaissance\AntiAbuse\Enums\ListType;
use Alltime\WPReconnaissance\AntiAbuse\Enums\MatchType;
use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalState;
use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalType;
use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Auth\FreeAssessmentService;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepositoryException;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Enums\JobStatus;
use Alltime\WPReconnaissance\Domain\Enums\ScheduleFrequency;
use Alltime\WPReconnaissance\Domain\Enums\Severity;
use Alltime\WPReconnaissance\Domain\Exceptions\InvalidDomainException;
use Alltime\WPReconnaissance\Domain\DomainValidator;
use Alltime\WPReconnaissance\Domain\Finding;
use Alltime\WPReconnaissance\Domain\Job;
use Alltime\WPReconnaissance\Domain\Organisation;
use Alltime\WPReconnaissance\Domain\Report;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Entitlements\Plan;
use Alltime\WPReconnaissance\Entitlements\PlanEnforcementService;
use Alltime\WPReconnaissance\Entitlements\PlanLimitException;
use Alltime\WPReconnaissance\Entitlements\PlanRepository;
use Alltime\WPReconnaissance\Findings\FindingRepository;
use Alltime\CustomerPlatform\ContactMergeService;
use Alltime\CustomerPlatform\Repositories\ContactMergeLogRepository;
use Alltime\CustomerPlatform\Repositories\ContactRepository;
use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;
use Alltime\WPReconnaissance\Integrations\MailManager;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRequestStatus;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRightType;
use Alltime\WPReconnaissance\Privacy\PrivacyRequest;
use Alltime\WPReconnaissance\Privacy\PrivacyRequestRepository;
use Alltime\WPReconnaissance\Privacy\PrivacyRequestService;
use Alltime\WPReconnaissance\Reports\DomainReconnaissanceReportBuilder;
use Alltime\WPReconnaissance\Reports\HtmlReportRenderer;
use Alltime\WPReconnaissance\Reports\RemediationTaskGenerator;
use Alltime\WPReconnaissance\Reports\ReportComparator;
use Alltime\WPReconnaissance\Reports\ReportDownloadToken;
use Alltime\WPReconnaissance\Reports\ReportException;
use Alltime\WPReconnaissance\Reports\ReportPdfService;
use Alltime\WPReconnaissance\Rules\BaselineCaptureException;
use Alltime\WPReconnaissance\Rules\BaselineCaptureService;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Support\Capabilities;
use Alltime\WPReconnaissance\Support\Roles;
use Alltime\WPReconnaissance\Verification\DomainVerificationService;
use Alltime\WPReconnaissance\Verification\SchemaNotReadyException;

final class AdminBootstrap {

	private const MENU_SLUG = 'wp-reconnaissance';
	private const PER_PAGE  = 20;

	/** Matches NotificationDispatcher::REPEATED_FAILURE_THRESHOLD - same signal, operator view. */
	private const REPEATED_FAILURE_THRESHOLD = 3;

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly FindingRepository $findings = new FindingRepository(),
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly DomainValidator $domain_validator = new DomainValidator(),
		private readonly SchedulingBootstrap $scheduling = new SchedulingBootstrap(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly DomainReconnaissanceReportBuilder $report_builder = new DomainReconnaissanceReportBuilder(),
		private readonly HtmlReportRenderer $report_renderer = new HtmlReportRenderer(),
		private readonly RemediationTaskGenerator $task_generator = new RemediationTaskGenerator(),
		private readonly PrivacyRequestRepository $privacy_requests = new PrivacyRequestRepository(),
		private readonly PrivacyRequestService $privacy_request_service = new PrivacyRequestService(),
		private readonly AntiAbuseService $anti_abuse = new AntiAbuseService(),
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly FreeAssessmentService $free_assessment = new FreeAssessmentService(),
		private readonly MailManager $mail_manager = new MailManager(),
		private readonly BaselineCaptureService $baseline_capture = new BaselineCaptureService(),
		private readonly ReportComparator $report_comparator = new ReportComparator(),
		private readonly PlanEnforcementService $plan_enforcement = new PlanEnforcementService(),
		private readonly PlanRepository $plans = new PlanRepository(),
		private readonly DomainVerificationService $domain_verification = new DomainVerificationService()
	) {}

	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'handle_form_submissions' ) );
	}

	public function register_menu(): void {
		add_menu_page(
			__( 'WP-Reconnaissance', 'wp-reconnaissance' ),
			__( 'Reconnaissance', 'wp-reconnaissance' ),
			Capabilities::VIEW_ALL_RESULTS,
			self::MENU_SLUG,
			array( $this, 'render_overview' ),
			'dashicons-shield',
			58
		);

		$screens = array(
			array( 'overview', __( 'Overview', 'wp-reconnaissance' ), Capabilities::VIEW_ALL_RESULTS, 'render_overview' ),
			array( 'organisations', __( 'Organisations', 'wp-reconnaissance' ), Capabilities::MANAGE_ORGANISATIONS, 'render_organisations' ),
			array( 'plans', __( 'Plans', 'wp-reconnaissance' ), Capabilities::MANAGE_ORGANISATIONS, 'render_plans' ),
			array( 'scopes', __( 'Scopes', 'wp-reconnaissance' ), Capabilities::MANAGE_SCOPES, 'render_scopes' ),
			array( 'jobs', __( 'Jobs', 'wp-reconnaissance' ), Capabilities::VIEW_ALL_RESULTS, 'render_jobs' ),
			array( 'findings', __( 'Findings', 'wp-reconnaissance' ), Capabilities::REVIEW_FINDINGS, 'render_findings' ),
			array( 'privacy-requests', __( 'Privacy requests', 'wp-reconnaissance' ), Capabilities::MANAGE_PRIVACY_REQUESTS, 'render_privacy_requests' ),
			array( 'reports', __( 'Reports', 'wp-reconnaissance' ), Capabilities::ISSUE_REPORTS, 'render_reports' ),
			array( 'abuse-review', __( 'Abuse review', 'wp-reconnaissance' ), Capabilities::MANAGE_ABUSE_REVIEW, 'render_abuse_review' ),
			array( 'contact-merge', __( 'Contact merge', 'wp-reconnaissance' ), Capabilities::MANAGE_CONTACT_MERGE, 'render_contact_merge' ),
			array( 'settings', __( 'Settings', 'wp-reconnaissance' ), Capabilities::MANAGE_SETTINGS, 'render_settings' ),
		);

		foreach ( $screens as [ $slug, $label, $capability, $callback ] ) {
			add_submenu_page(
				self::MENU_SLUG,
				$label,
				$label,
				$capability,
				self::MENU_SLUG . '-' . $slug,
				array( $this, $callback )
			);
		}

		remove_submenu_page( self::MENU_SLUG, self::MENU_SLUG );
	}

	// -----------------------------------------------------------------------------------
	// Form submission dispatch (admin_init - runs before any output)
	// -----------------------------------------------------------------------------------

	public function handle_form_submissions(): void {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! isset( $_POST['wpr_admin_action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- every branch below verifies its own nonce before acting.
		$action = sanitize_key( wp_unslash( $_POST['wpr_admin_action'] ) );

		match ( $action ) {
			'create_organisation' => $this->handle_create_organisation(),
			'create_scope' => $this->handle_create_scope(),
			'authorise_scope' => $this->handle_authorise_scope(),
			'start_domain_verification' => $this->handle_start_domain_verification(),
			'check_domain_verification' => $this->handle_check_domain_verification(),
			'dispatch_assessment' => $this->handle_dispatch_assessment(),
			'capture_baseline' => $this->handle_capture_baseline(),
			'review_finding' => $this->handle_review_finding(),
			'record_privacy_request' => $this->handle_record_privacy_request(),
			'verify_privacy_request_identity' => $this->handle_verify_privacy_request_identity(),
			'classify_privacy_request' => $this->handle_classify_privacy_request(),
			'assign_privacy_request' => $this->handle_assign_privacy_request(),
			'toggle_privacy_request_restriction' => $this->handle_toggle_privacy_request_restriction(),
			'complete_privacy_request' => $this->handle_complete_privacy_request(),
			'refuse_privacy_request' => $this->handle_refuse_privacy_request(),
			'update_organisation' => $this->handle_update_organisation(),
			'assign_plan' => $this->handle_assign_plan(),
			'create_plan' => $this->handle_create_plan(),
			'update_plan' => $this->handle_update_plan(),
			'issue_report' => $this->handle_issue_report(),
			'save_settings' => $this->handle_save_settings(),
			'save_mail_provider' => $this->handle_save_mail_provider(),
			'test_mail_provider' => $this->handle_test_mail_provider(),
			'release_abuse_signal' => $this->handle_release_abuse_signal(),
			'dismiss_abuse_signal' => $this->handle_dismiss_abuse_signal(),
			'block_abuse_signal' => $this->handle_block_abuse_signal(),
			'add_blocklist_entry' => $this->handle_add_blocklist_entry(),
			'remove_blocklist_entry' => $this->handle_remove_blocklist_entry(),
			'approve_contact_merge' => $this->handle_approve_contact_merge(),
			'reject_contact_merge' => $this->handle_reject_contact_merge(),
			'revert_contact_merge' => $this->handle_revert_contact_merge(),
			default => null,
		};
	}

	// -----------------------------------------------------------------------------------
	// Overview
	// -----------------------------------------------------------------------------------

	public function render_overview(): void {
		if ( ! current_user_can( Capabilities::VIEW_ALL_RESULTS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		$today             = new \DateTimeImmutable( 'today' );
		$organisations     = $this->organisations->count();
		$active_scopes     = $this->scopes->count_by_status( 'active' );
		$jobs_today        = $this->jobs->count_since( $today );
		$jobs_failed_today = $this->jobs->count_by_status_since( JobStatus::Failed, $today );
		$open_by_severity  = $this->findings->count_open_by_severity();

		echo '<div class="wrap"><h1>' . esc_html__( 'Overview', 'wp-reconnaissance' ) . '</h1>';
		echo '<div style="display:flex;gap:16px;flex-wrap:wrap;margin-top:16px">';
		$this->render_tile( __( 'Organisations', 'wp-reconnaissance' ), (string) $organisations );
		$this->render_tile( __( 'Active scopes', 'wp-reconnaissance' ), (string) $active_scopes );
		$this->render_tile( __( 'Jobs today', 'wp-reconnaissance' ), (string) $jobs_today );
		$this->render_tile( __( 'Jobs failed today', 'wp-reconnaissance' ), (string) $jobs_failed_today );
		echo '</div>';

		echo '<h2>' . esc_html__( 'Open findings by severity', 'wp-reconnaissance' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:480px"><thead><tr><th>' . esc_html__( 'Severity', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Open findings', 'wp-reconnaissance' ) . '</th></tr></thead><tbody>';
		foreach ( array_reverse( Severity::cases() ) as $severity ) {
			echo '<tr><td>' . esc_html( ucfirst( $severity->value ) ) . '</td><td>' . esc_html( (string) ( $open_by_severity[ $severity->value ] ?? 0 ) ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	private function render_tile( string $label, string $value ): void {
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:4px;padding:16px 24px;min-width:160px">'
			. '<div style="font-size:28px;font-weight:600">' . esc_html( $value ) . '</div>'
			. '<div style="color:#646970">' . esc_html( $label ) . '</div></div>';
	}

	// -----------------------------------------------------------------------------------
	// Organisations
	// -----------------------------------------------------------------------------------

	public function render_organisations(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ORGANISATIONS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
		if ( 'edit' === ( $_GET['action'] ?? '' ) && isset( $_GET['id'] ) ) {
			$this->render_organisation_edit( (int) $_GET['id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			return;
		}

		$page = max( 1, (int) ( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.

		echo '<div class="wrap"><h1>' . esc_html__( 'Organisations', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		echo '<h2>' . esc_html__( 'Add organisation', 'wp-reconnaissance' ) . '</h2>';
		echo '<form method="post">';
		wp_nonce_field( 'wpr_create_organisation' );
		echo '<input type="hidden" name="wpr_admin_action" value="create_organisation">';
		echo '<table class="form-table"><tbody>';
		echo '<tr><th><label for="wpr_name">' . esc_html__( 'Name', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_name" name="name" class="regular-text" required></td></tr>';
		echo '<tr><th><label for="wpr_timezone">' . esc_html__( 'Timezone', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_timezone" name="timezone" value="UTC" class="regular-text"></td></tr>';
		echo '</tbody></table>';
		submit_button( __( 'Add organisation', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Organisations', 'wp-reconnaissance' ) . '</h2>';
		$organisations = $this->organisations->list( self::PER_PAGE, $page );

		if ( array() === $organisations ) {
			echo '<p>' . esc_html__( 'No organisations yet.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'ID', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Name', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Slug', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Created', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Scopes', 'wp-reconnaissance' ) . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>';

		foreach ( $organisations as $organisation ) {
			$scopes_url = add_query_arg(
				array(
					'page'            => self::MENU_SLUG . '-scopes',
					'organisation_id' => $organisation->id,
				),
				admin_url( 'admin.php' )
			);

			$edit_url = add_query_arg(
				array(
					'page'   => self::MENU_SLUG . '-organisations',
					'action' => 'edit',
					'id'     => $organisation->id,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr>'
				. '<td>' . esc_html( (string) $organisation->id ) . '</td>'
				. '<td>' . esc_html( $organisation->name ) . '</td>'
				. '<td>' . esc_html( $organisation->slug ) . '</td>'
				. '<td>' . esc_html( $organisation->status ) . '</td>'
				. '<td>' . esc_html( $organisation->created_at?->format( 'Y-m-d H:i' ) ?? '' ) . '</td>'
				. '<td><a href="' . esc_url( $scopes_url ) . '">' . esc_html__( 'View scopes', 'wp-reconnaissance' ) . '</a></td>'
				. '<td><a href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit', 'wp-reconnaissance' ) . '</a></td>'
				. '</tr>';
		}

		echo '</tbody></table></div>';
	}

	private function render_organisation_edit( int $id ): void {
		$organisation = $this->organisations->find( $id );
		$back_url     = add_query_arg( array( 'page' => self::MENU_SLUG . '-organisations' ), admin_url( 'admin.php' ) );

		echo '<div class="wrap"><h1>' . esc_html__( 'Edit organisation', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();
		echo '<p><a href="' . esc_url( $back_url ) . '">&larr; ' . esc_html__( 'Back to organisations', 'wp-reconnaissance' ) . '</a></p>';

		if ( null === $organisation ) {
			echo '<p>' . esc_html__( 'Organisation not found.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<form method="post">';
		wp_nonce_field( 'wpr_update_organisation' );
		echo '<input type="hidden" name="wpr_admin_action" value="update_organisation">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $organisation->id ) . '">';
		echo '<table class="form-table"><tbody>';
		echo '<tr><th><label for="wpr_edit_name">' . esc_html__( 'Name', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_edit_name" name="name" value="' . esc_attr( $organisation->name ) . '" class="regular-text" required></td></tr>';
		echo '<tr><th><label for="wpr_edit_timezone">' . esc_html__( 'Timezone', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_edit_timezone" name="timezone" value="' . esc_attr( $organisation->timezone ) . '" class="regular-text"></td></tr>';
		echo '<tr><th><label for="wpr_edit_status">' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_edit_status" name="status">';
		foreach ( array( 'active', 'suspended', 'archived' ) as $status ) {
			echo '<option value="' . esc_attr( $status ) . '"' . selected( $organisation->status, $status, false ) . '>' . esc_html( ucfirst( $status ) ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '</tbody></table>';
		submit_button( __( 'Save organisation', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Managed plan', 'wp-reconnaissance' ) . '</h2>';
		echo '<form method="post">';
		wp_nonce_field( 'wpr_assign_plan' );
		echo '<input type="hidden" name="wpr_admin_action" value="assign_plan">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $organisation->id ) . '">';
		echo '<table class="form-table"><tbody><tr><th><label for="wpr_plan_id">' . esc_html__( 'Plan', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_plan_id" name="plan_id">'
			. '<option value="">' . esc_html__( '- Unrestricted (no plan) -', 'wp-reconnaissance' ) . '</option>'
			. $this->plan_options( $organisation->plan_id ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plan_options() only emits esc_attr()/esc_html()-escaped <option> markup.
			. '</select></td></tr></tbody></table>';
		submit_button( __( 'Assign plan', 'wp-reconnaissance' ) );
		echo '</form></div>';
	}

	private function plan_options( ?int $selected ): string {
		$options = '';

		foreach ( $this->plans->list_all() as $plan ) {
			$options .= '<option value="' . esc_attr( (string) $plan->id ) . '"' . selected( $selected, $plan->id, false ) . '>' . esc_html( $plan->name ) . '</option>';
		}

		return $options;
	}

	private function handle_assign_plan(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ORGANISATIONS ) || ! $this->verify_nonce( 'wpr_assign_plan' ) ) {
			$this->redirect_with_notice( 'organisations', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $id || null === $this->organisations->find( $id ) ) {
			$this->redirect_with_notice( 'organisations', 'error', __( 'Organisation not found.', 'wp-reconnaissance' ) );
		}

		$plan_id_raw = isset( $_POST['plan_id'] ) ? sanitize_text_field( wp_unslash( $_POST['plan_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$plan_id     = '' !== $plan_id_raw ? (int) $plan_id_raw : null;

		$this->organisations->assign_plan( $id, $plan_id );

		$this->audit_logger->log( 'organisation.plan_assigned', 'organisation', $id, get_current_user_id(), summary: (string) ( $plan_id ?? 'none' ) );
		$this->redirect_with_notice( 'organisations', 'success', __( 'Plan assignment saved.', 'wp-reconnaissance' ) );
	}

	private function handle_update_organisation(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ORGANISATIONS ) || ! $this->verify_nonce( 'wpr_update_organisation' ) ) {
			$this->redirect_with_notice( 'organisations', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $id || null === $this->organisations->find( $id ) ) {
			$this->redirect_with_notice( 'organisations', 'error', __( 'Organisation not found.', 'wp-reconnaissance' ) );
		}

		$name     = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$timezone = isset( $_POST['timezone'] ) ? sanitize_text_field( wp_unslash( $_POST['timezone'] ) ) : 'UTC'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$status   = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'active'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( '' === $name || ! in_array( $status, array( 'active', 'suspended', 'archived' ), true ) ) {
			$this->redirect_with_notice( 'organisations', 'error', __( 'Name is required and status must be valid.', 'wp-reconnaissance' ) );
		}

		$this->organisations->update( $id, $name, '' !== $timezone ? $timezone : 'UTC', $status );

		$this->audit_logger->log( 'organisation.updated', 'organisation', $id, get_current_user_id(), summary: $name );
		$this->redirect_with_notice( 'organisations', 'success', __( 'Organisation updated.', 'wp-reconnaissance' ) );
	}

	private function handle_create_organisation(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ORGANISATIONS ) || ! $this->verify_nonce( 'wpr_create_organisation' ) ) {
			$this->redirect_with_notice( 'organisations', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( '' === $name ) {
			$this->redirect_with_notice( 'organisations', 'error', __( 'Organisation name is required.', 'wp-reconnaissance' ) );
		}

		$timezone     = isset( $_POST['timezone'] ) ? sanitize_text_field( wp_unslash( $_POST['timezone'] ) ) : 'UTC'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$slug         = $this->organisations->unique_slug( $name );
		$organisation = $this->organisations->create( $name, $slug, null, '' !== $timezone ? $timezone : 'UTC' );

		$this->audit_logger->log( 'organisation.created', 'organisation', $organisation->id, get_current_user_id(), summary: $organisation->name );
		$this->redirect_with_notice( 'organisations', 'success', __( 'Organisation created.', 'wp-reconnaissance' ) );
	}

	// -----------------------------------------------------------------------------------
	// Plans (Section 33 "repeat, paid and managed-service entitlements")
	// -----------------------------------------------------------------------------------

	public function render_plans(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ORGANISATIONS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
		if ( 'edit' === ( $_GET['action'] ?? '' ) && isset( $_GET['id'] ) ) {
			$this->render_plan_edit( (int) $_GET['id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Plans', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();
		echo '<p>' . esc_html__( 'Managed plans let you cap what an organisation can do - how many scopes it may actively monitor, how often it may re-run a free assessment, and the fastest monitoring cadence it is permitted. An organisation with no assigned plan is unrestricted, exactly as before this feature existed.', 'wp-reconnaissance' ) . '</p>';

		echo '<h2>' . esc_html__( 'Add plan', 'wp-reconnaissance' ) . '</h2>';
		echo '<form method="post">';
		wp_nonce_field( 'wpr_create_plan' );
		echo '<input type="hidden" name="wpr_admin_action" value="create_plan">';
		echo $this->plan_form_fields(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plan_form_fields() only emits esc_*()-escaped fragments.
		submit_button( __( 'Add plan', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Plans', 'wp-reconnaissance' ) . '</h2>';
		$plans = $this->plans->list_all();

		if ( array() === $plans ) {
			echo '<p>' . esc_html__( 'No plans yet.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'Name', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Max active scopes', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Rerun interval (days)', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Fastest cadence', 'wp-reconnaissance' ) . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>';

		foreach ( $plans as $plan ) {
			$edit_url = add_query_arg(
				array(
					'page'   => self::MENU_SLUG . '-plans',
					'action' => 'edit',
					'id'     => $plan->id,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr>'
				. '<td>' . esc_html( $plan->name ) . '</td>'
				. '<td>' . esc_html( null !== $plan->max_active_scopes ? (string) $plan->max_active_scopes : __( 'Unlimited', 'wp-reconnaissance' ) ) . '</td>'
				. '<td>' . esc_html( null !== $plan->rerun_interval_days ? (string) $plan->rerun_interval_days : __( 'System default', 'wp-reconnaissance' ) ) . '</td>'
				. '<td>' . esc_html( $plan->min_schedule_frequency?->value ?? __( 'Unrestricted', 'wp-reconnaissance' ) ) . '</td>'
				. '<td><a href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit', 'wp-reconnaissance' ) . '</a></td>'
				. '</tr>';
		}

		echo '</tbody></table></div>';
	}

	private function render_plan_edit( int $id ): void {
		$plan     = $this->plans->find( $id );
		$back_url = add_query_arg( array( 'page' => self::MENU_SLUG . '-plans' ), admin_url( 'admin.php' ) );

		echo '<div class="wrap"><h1>' . esc_html__( 'Edit plan', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();
		echo '<p><a href="' . esc_url( $back_url ) . '">&larr; ' . esc_html__( 'Back to plans', 'wp-reconnaissance' ) . '</a></p>';

		if ( null === $plan ) {
			echo '<p>' . esc_html__( 'Plan not found.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<form method="post">';
		wp_nonce_field( 'wpr_update_plan' );
		echo '<input type="hidden" name="wpr_admin_action" value="update_plan">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $plan->id ) . '">';
		echo $this->plan_form_fields( $plan ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plan_form_fields() only emits esc_*()-escaped fragments.
		submit_button( __( 'Save plan', 'wp-reconnaissance' ) );
		echo '</form></div>';
	}

	private function plan_form_fields( ?Plan $plan = null ): string {
		$frequency_options = '<option value="">' . esc_html__( '- Unrestricted -', 'wp-reconnaissance' ) . '</option>';
		foreach ( ScheduleFrequency::cases() as $frequency ) {
			$frequency_options .= '<option value="' . esc_attr( $frequency->value ) . '"' . selected( $plan?->min_schedule_frequency?->value, $frequency->value, false ) . '>' . esc_html( $frequency->value ) . '</option>';
		}

		return '<table class="form-table"><tbody>'
			. '<tr><th><label for="wpr_plan_name">' . esc_html__( 'Name', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_plan_name" name="name" value="' . esc_attr( $plan->name ?? '' ) . '" class="regular-text" required></td></tr>'
			. '<tr><th><label for="wpr_plan_max_active_scopes">' . esc_html__( 'Max active scopes', 'wp-reconnaissance' ) . '</label></th><td><input type="number" min="1" id="wpr_plan_max_active_scopes" name="max_active_scopes" value="' . esc_attr( null !== $plan?->max_active_scopes ? (string) $plan->max_active_scopes : '' ) . '"><p class="description">' . esc_html__( 'Leave blank for unlimited.', 'wp-reconnaissance' ) . '</p></td></tr>'
			. '<tr><th><label for="wpr_plan_rerun_interval_days">' . esc_html__( 'Rerun interval (days)', 'wp-reconnaissance' ) . '</label></th><td><input type="number" min="0" id="wpr_plan_rerun_interval_days" name="rerun_interval_days" value="' . esc_attr( null !== $plan?->rerun_interval_days ? (string) $plan->rerun_interval_days : '' ) . '"><p class="description">' . esc_html__( 'Leave blank to use the system default.', 'wp-reconnaissance' ) . '</p></td></tr>'
			. '<tr><th><label for="wpr_plan_min_schedule_frequency">' . esc_html__( 'Fastest monitoring cadence', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_plan_min_schedule_frequency" name="min_schedule_frequency">' . $frequency_options . '</select></td></tr>'
			. '<tr><th><label for="wpr_plan_external_billing_reference">' . esc_html__( 'External billing reference', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_plan_external_billing_reference" name="external_billing_reference" value="' . esc_attr( $plan->external_billing_reference ?? '' ) . '" class="regular-text"><p class="description">' . esc_html__( 'Not used by this plugin - reserved for a future billing/payment integration to record its own identifier here.', 'wp-reconnaissance' ) . '</p></td></tr>'
			. '</tbody></table>';
	}

	private function handle_create_plan(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ORGANISATIONS ) || ! $this->verify_nonce( 'wpr_create_plan' ) ) {
			$this->redirect_with_notice( 'plans', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( '' === $name ) {
			$this->redirect_with_notice( 'plans', 'error', __( 'Plan name is required.', 'wp-reconnaissance' ) );
		}

		[ $max_active_scopes, $rerun_interval_days, $frequency, $billing_reference ] = $this->parsed_plan_fields();

		$plan = $this->plans->create( $name, $this->plans->unique_slug( $name ), $max_active_scopes, $rerun_interval_days, $frequency, $billing_reference );

		$this->audit_logger->log( 'plan.created', 'plan', $plan->id, get_current_user_id(), summary: $plan->name );
		$this->redirect_with_notice( 'plans', 'success', __( 'Plan created.', 'wp-reconnaissance' ) );
	}

	private function handle_update_plan(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ORGANISATIONS ) || ! $this->verify_nonce( 'wpr_update_plan' ) ) {
			$this->redirect_with_notice( 'plans', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $id || null === $this->plans->find( $id ) ) {
			$this->redirect_with_notice( 'plans', 'error', __( 'Plan not found.', 'wp-reconnaissance' ) );
		}

		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( '' === $name ) {
			$this->redirect_with_notice( 'plans', 'error', __( 'Plan name is required.', 'wp-reconnaissance' ) );
		}

		[ $max_active_scopes, $rerun_interval_days, $frequency, $billing_reference ] = $this->parsed_plan_fields();

		$this->plans->update( $id, $name, $max_active_scopes, $rerun_interval_days, $frequency, $billing_reference );

		$this->audit_logger->log( 'plan.updated', 'plan', $id, get_current_user_id(), summary: $name );
		$this->redirect_with_notice( 'plans', 'success', __( 'Plan updated.', 'wp-reconnaissance' ) );
	}

	/**
	 * @return array{0:?int,1:?int,2:?ScheduleFrequency,3:?string}
	 */
	private function parsed_plan_fields(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified by the caller before this is read.
		$max_active_scopes_raw = isset( $_POST['max_active_scopes'] ) ? sanitize_text_field( wp_unslash( $_POST['max_active_scopes'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified by the caller before this is read.
		$rerun_interval_days_raw = isset( $_POST['rerun_interval_days'] ) ? sanitize_text_field( wp_unslash( $_POST['rerun_interval_days'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified by the caller before this is read.
		$frequency_raw = isset( $_POST['min_schedule_frequency'] ) ? sanitize_key( wp_unslash( $_POST['min_schedule_frequency'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified by the caller before this is read.
		$billing_reference_raw = isset( $_POST['external_billing_reference'] ) ? sanitize_text_field( wp_unslash( $_POST['external_billing_reference'] ) ) : '';

		return array(
			'' !== $max_active_scopes_raw ? (int) $max_active_scopes_raw : null,
			'' !== $rerun_interval_days_raw ? (int) $rerun_interval_days_raw : null,
			ScheduleFrequency::from_nullable( $frequency_raw ),
			'' !== $billing_reference_raw ? $billing_reference_raw : null,
		);
	}

	// -----------------------------------------------------------------------------------
	// Scopes
	// -----------------------------------------------------------------------------------

	public function render_scopes(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SCOPES ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		$organisation_id_filter = isset( $_GET['organisation_id'] ) ? (int) $_GET['organisation_id'] : null;

		echo '<div class="wrap"><h1>' . esc_html__( 'Scopes', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		echo '<h2>' . esc_html__( 'Add scope', 'wp-reconnaissance' ) . '</h2>';
		echo '<form method="post">';
		wp_nonce_field( 'wpr_create_scope' );
		echo '<input type="hidden" name="wpr_admin_action" value="create_scope">';
		echo '<table class="form-table"><tbody>';
		echo '<tr><th><label for="wpr_organisation_id">' . esc_html__( 'Organisation', 'wp-reconnaissance' ) . '</label></th><td>' . $this->organisation_select( $organisation_id_filter ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr()/esc_html()-escaped fragments in organisation_select().
		echo '<tr><th><label for="wpr_scope_name">' . esc_html__( 'Name', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_scope_name" name="name" class="regular-text" required></td></tr>';
		echo '<tr><th><label for="wpr_domain">' . esc_html__( 'Domain', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_domain" name="domain" class="regular-text" placeholder="example.com" required></td></tr>';
		echo '</tbody></table>';
		submit_button( __( 'Add scope (pending authorisation)', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Scopes', 'wp-reconnaissance' ) . '</h2>';
		$page   = max( 1, (int) ( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.
		$scopes = null !== $organisation_id_filter ? $this->scopes->find_by_organisation( $organisation_id_filter ) : $this->scopes->list_all( self::PER_PAGE, $page );

		if ( array() === $scopes ) {
			echo '<p>' . esc_html__( 'No scopes yet.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'ID', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Organisation', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Domain', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Authorisation', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Actions', 'wp-reconnaissance' ) . '</th>'
			. '</tr></thead><tbody>';

		foreach ( $scopes as $scope ) {
			echo '<tr>'
				. '<td>' . esc_html( (string) $scope->id ) . '</td>'
				. '<td>' . esc_html( (string) $scope->organisation_id ) . '</td>'
				. '<td>' . esc_html( $scope->domain_display ) . '</td>'
				. '<td>' . esc_html( $scope->status ) . '</td>'
				. '<td>' . esc_html( $scope->authorisation_status ) . '</td>'
				. '<td>' . $this->scope_row_actions( $scope ) . '</td>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- scope_row_actions() only emits esc_*()-escaped fragments and wp_nonce_field()/submit_button() output.
				. '</tr>';
		}

		echo '</tbody></table></div>';
	}

	private function scope_row_actions( Scope $scope ): string {
		$jobs_url = esc_url(
			add_query_arg(
				array(
					'page'     => self::MENU_SLUG . '-jobs',
					'scope_id' => $scope->id,
				),
				admin_url( 'admin.php' )
			)
		);

		$html = '<a href="' . $jobs_url . '">' . esc_html__( 'View jobs', 'wp-reconnaissance' ) . '</a>';

		if ( 'authorised' !== $scope->authorisation_status ) {
			$html .= ' &middot; <details style="display:inline-block"><summary style="display:inline">' . esc_html__( 'Authorise', 'wp-reconnaissance' ) . '</summary>'
				. '<form method="post" style="margin-top:8px">'
				. wp_nonce_field( 'wpr_authorise_scope', '_wpnonce', true, false )
				. '<input type="hidden" name="wpr_admin_action" value="authorise_scope">'
				. '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope->id ) . '">'
				. '<p><input type="text" name="authorisation_reference" placeholder="' . esc_attr__( 'Authorisation reference', 'wp-reconnaissance' ) . '" required></p>'
				. '<p><button type="submit" class="button button-primary">' . esc_html__( 'Confirm authorisation', 'wp-reconnaissance' ) . '</button></p>'
				. '</form></details>';
		}

		if ( 'authorised' !== $scope->authorisation_status && current_user_can( Capabilities::MANAGE_SCOPES ) ) {
			$html .= ' &middot; <details style="display:inline-block"><summary style="display:inline">' . esc_html__( 'Verify domain', 'wp-reconnaissance' ) . '</summary>'
				. $this->domain_verification_summary( $scope )
				. '<form method="post" style="margin-top:8px">'
				. wp_nonce_field( 'wpr_start_domain_verification', '_wpnonce', true, false )
				. '<input type="hidden" name="wpr_admin_action" value="start_domain_verification">'
				. '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope->id ) . '">'
				. '<p><button type="submit" class="button">' . esc_html__( 'Generate verification code', 'wp-reconnaissance' ) . '</button></p>'
				. '</form>'
				. ( 'pending' === $scope->domain_verification_status
					? '<form method="post">'
						. wp_nonce_field( 'wpr_check_domain_verification', '_wpnonce', true, false )
						. '<input type="hidden" name="wpr_admin_action" value="check_domain_verification">'
						. '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope->id ) . '">'
						. '<p><button type="submit" class="button">' . esc_html__( 'Check now', 'wp-reconnaissance' ) . '</button></p>'
						. '</form>'
					: '' )
				. '</details>';
		}

		if ( current_user_can( Capabilities::RUN_ASSESSMENTS ) && $scope->is_currently_authorised() ) {
			$html .= ' &middot; <form method="post" style="display:inline">'
				. wp_nonce_field( 'wpr_dispatch_assessment', '_wpnonce', true, false )
				. '<input type="hidden" name="wpr_admin_action" value="dispatch_assessment">'
				. '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope->id ) . '">'
				. '<button type="submit" class="button">' . esc_html__( 'Run now', 'wp-reconnaissance' ) . '</button>'
				. '</form>';
		}

		if ( current_user_can( Capabilities::MANAGE_SCOPES ) && $scope->is_currently_authorised() ) {
			$html .= ' &middot; <details style="display:inline-block"><summary style="display:inline">' . esc_html__( 'Baseline', 'wp-reconnaissance' ) . '</summary>'
				. $this->baseline_summary( $scope )
				. '<form method="post" style="margin-top:8px">'
				. wp_nonce_field( 'wpr_capture_baseline', '_wpnonce', true, false )
				. '<input type="hidden" name="wpr_admin_action" value="capture_baseline">'
				. '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope->id ) . '">'
				. '<p><button type="submit" class="button">' . esc_html__( 'Adopt current state as baseline', 'wp-reconnaissance' ) . '</button></p>'
				. '</form></details>';
		}

		return $html;
	}

	/**
	 * A compact, read-only view of the collector keys Section 33's baseline drift rules
	 * ({@see \Alltime\WPReconnaissance\Rules\Handlers\BaselineRuleHandlers}) currently compare
	 * against, for operator visibility into what "Adopt current state as baseline" last captured.
	 */
	private function baseline_summary( Scope $scope ): string {
		if ( array() === $scope->expected_state ) {
			return '<p>' . esc_html__( 'No baseline captured yet.', 'wp-reconnaissance' ) . '</p>';
		}

		$lines = array();

		if ( isset( $scope->expected_state['rdap']['nameservers'] ) ) {
			$lines[] = esc_html__( 'Nameservers', 'wp-reconnaissance' ) . ': ' . esc_html( implode( ', ', (array) $scope->expected_state['rdap']['nameservers'] ) );
		}

		if ( isset( $scope->expected_state['mail']['mx_hosts'] ) ) {
			$lines[] = esc_html__( 'Mail exchangers', 'wp-reconnaissance' ) . ': ' . esc_html( implode( ', ', (array) $scope->expected_state['mail']['mx_hosts'] ) );
		}

		if ( isset( $scope->expected_state['tls']['issuer'] ) ) {
			$lines[] = esc_html__( 'TLS issuer', 'wp-reconnaissance' ) . ': ' . esc_html( (string) $scope->expected_state['tls']['issuer'] );
		}

		if ( array() === $lines ) {
			return '<p>' . esc_html__( 'No baseline captured yet.', 'wp-reconnaissance' ) . '</p>';
		}

		return '<p>' . implode( '<br>', $lines ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every element of $lines is already esc_html()-escaped above.
	}

	/**
	 * The DNS TXT record an operator (or customer) must publish to prove domain ownership - see
	 * {@see \Alltime\WPReconnaissance\Verification\DomainVerificationService}.
	 */
	private function domain_verification_summary( Scope $scope ): string {
		if ( null === $scope->domain_verification_secret_hash ) {
			return '<p>' . esc_html__( 'No verification code generated yet.', 'wp-reconnaissance' ) . '</p>';
		}

		$txt_value = $this->domain_verification->txt_record_value( $scope->domain_verification_secret_hash, $scope->domain_verification_requested_at );

		return '<p>' . esc_html__( 'Publish this TXT record on the domain itself (not a subdomain), then check back once it has propagated:', 'wp-reconnaissance' ) . '</p>'
			. '<p><code style="user-select:all">' . esc_html( $scope->domain_ascii ) . ' TXT "' . esc_html( $txt_value ) . '"</code></p>';
	}

	private function organisation_select( ?int $selected ): string {
		$options = '';

		foreach ( $this->organisations->list( 200, 1 ) as $organisation ) {
			$options .= '<option value="' . esc_attr( (string) $organisation->id ) . '"' . selected( $selected, $organisation->id, false ) . '>' . esc_html( $organisation->name ) . '</option>';
		}

		return '<select id="wpr_organisation_id" name="organisation_id" required><option value="">' . esc_html__( '- Select -', 'wp-reconnaissance' ) . '</option>' . $options . '</select>';
	}

	private function handle_create_scope(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SCOPES ) || ! $this->verify_nonce( 'wpr_create_scope' ) ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$organisation_id = isset( $_POST['organisation_id'] ) ? (int) $_POST['organisation_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$name            = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$domain_raw      = isset( $_POST['domain'] ) ? sanitize_text_field( wp_unslash( $_POST['domain'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $organisation_id || '' === $name || '' === $domain_raw ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Organisation, name and domain are all required.', 'wp-reconnaissance' ) );
		}

		try {
			$domain = $this->domain_validator->validate( $domain_raw );
		} catch ( InvalidDomainException $exception ) {
			$this->redirect_with_notice( 'scopes', 'error', $exception->getMessage() );
		}

		$scope = $this->scopes->create(
			$organisation_id,
			$name,
			$domain->ascii,
			$domain->display,
			$domain->registrable,
			array( 'rdap', 'dns', 'dnssec', 'mail', 'http', 'tls', 'ct', 'subdomains', 'lookalikes' )
		);

		$this->audit_logger->log( 'scope.created', 'scope', $scope->id, get_current_user_id(), summary: $scope->domain_display );
		$this->redirect_with_notice( 'scopes', 'success', __( 'Scope created, pending authorisation.', 'wp-reconnaissance' ) );
	}

	private function handle_authorise_scope(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SCOPES ) || ! $this->verify_nonce( 'wpr_authorise_scope' ) ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$scope_id  = isset( $_POST['scope_id'] ) ? (int) $_POST['scope_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$reference = isset( $_POST['authorisation_reference'] ) ? sanitize_text_field( wp_unslash( $_POST['authorisation_reference'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $scope_id || '' === $reference ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'An authorisation reference is required.', 'wp-reconnaissance' ) );
		}

		$existing = $this->scopes->find( $scope_id );

		if ( null === $existing ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Scope not found.', 'wp-reconnaissance' ) );
		}

		try {
			$this->plan_enforcement->assert_can_authorise_scope( $existing->organisation_id );
		} catch ( PlanLimitException $exception ) {
			$this->redirect_with_notice( 'scopes', 'error', $exception->getMessage() );
		}

		$scope = $this->scopes->authorise( $scope_id, get_current_user_id(), $reference );

		$this->audit_logger->log( 'scope.authorised', 'scope', $scope->id, get_current_user_id(), summary: $reference );
		$this->redirect_with_notice( 'scopes', 'success', __( 'Scope authorised.', 'wp-reconnaissance' ) );
	}

	private function handle_start_domain_verification(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SCOPES ) || ! $this->verify_nonce( 'wpr_start_domain_verification' ) ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$scope_id = isset( $_POST['scope_id'] ) ? (int) $_POST['scope_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $scope_id || null === $this->scopes->find( $scope_id ) ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Scope not found.', 'wp-reconnaissance' ) );
		}

		try {
			$this->domain_verification->generate_challenge( $scope_id, get_current_user_id(), 'admin' );
		} catch ( SchemaNotReadyException | ScopeRepositoryException $exception ) {
			$this->redirect_with_notice( 'scopes', 'error', $exception->getMessage() );
		}

		$this->redirect_with_notice( 'scopes', 'success', __( 'Verification code generated. Publish the TXT record shown, then check back.', 'wp-reconnaissance' ) );
	}

	private function handle_check_domain_verification(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SCOPES ) || ! $this->verify_nonce( 'wpr_check_domain_verification' ) ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$scope_id = isset( $_POST['scope_id'] ) ? (int) $_POST['scope_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$scope    = $this->scopes->find( $scope_id );

		if ( null === $scope ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Scope not found.', 'wp-reconnaissance' ) );
		}

		try {
			$verified = $this->domain_verification->check( $scope, 'admin' );
		} catch ( PlanLimitException | SchemaNotReadyException | ScopeRepositoryException $exception ) {
			$this->redirect_with_notice( 'scopes', 'error', $exception->getMessage() );
		}

		$this->redirect_with_notice(
			'scopes',
			$verified ? 'success' : 'error',
			$verified
				? __( 'Domain verified and scope authorised.', 'wp-reconnaissance' )
				: __( 'No matching TXT record was found yet. DNS changes can take a while to propagate - try again shortly.', 'wp-reconnaissance' )
		);
	}

	private function handle_dispatch_assessment(): void {
		if ( ! current_user_can( Capabilities::RUN_ASSESSMENTS ) || ! $this->verify_nonce( 'wpr_dispatch_assessment' ) ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$scope_id = isset( $_POST['scope_id'] ) ? (int) $_POST['scope_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $scope_id ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'No scope was specified.', 'wp-reconnaissance' ) );
		}

		$this->scheduling->schedule_assessment( $scope_id, get_current_user_id() );
		$this->audit_logger->log( 'job.dispatch_requested', 'scope', $scope_id, get_current_user_id() );

		$url = add_query_arg(
			array(
				'page'        => self::MENU_SLUG . '-jobs',
				'scope_id'    => $scope_id,
				'wpr_notice'  => 'success',
				'wpr_message' => rawurlencode( __( 'Assessment queued. It will appear below once it starts running.', 'wp-reconnaissance' ) ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Adopts a scope's most recently observed nameservers/MX/TLS issuer as its baseline
	 * (Section 33) - the operator-facing entry point for {@see BaselineCaptureService}.
	 */
	private function handle_capture_baseline(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SCOPES ) || ! $this->verify_nonce( 'wpr_capture_baseline' ) ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$scope_id = isset( $_POST['scope_id'] ) ? (int) $_POST['scope_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $scope_id ) {
			$this->redirect_with_notice( 'scopes', 'error', __( 'No scope was specified.', 'wp-reconnaissance' ) );
		}

		try {
			$this->baseline_capture->capture_from_latest_observation( $scope_id );
		} catch ( BaselineCaptureException $exception ) {
			$this->redirect_with_notice( 'scopes', 'error', $exception->getMessage() );
		}

		$this->audit_logger->log( 'scope.baseline_captured', 'scope', $scope_id, get_current_user_id() );
		$this->redirect_with_notice( 'scopes', 'success', __( 'Current state adopted as the baseline. Future assessments will flag drift from it.', 'wp-reconnaissance' ) );
	}

	// -----------------------------------------------------------------------------------
	// Jobs
	// -----------------------------------------------------------------------------------

	public function render_jobs(): void {
		if ( ! current_user_can( Capabilities::VIEW_ALL_RESULTS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		$scope_id = isset( $_GET['scope_id'] ) ? (int) $_GET['scope_id'] : null;

		echo '<div class="wrap"><h1>' . esc_html__( 'Jobs', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		if ( null === $scope_id ) {
			$this->render_repeated_failures();
		}

		$jobs = null !== $scope_id ? $this->jobs->find_by_scope( $scope_id, 50 ) : $this->jobs->list_recent( 50 );

		if ( array() === $jobs ) {
			echo '<p>' . esc_html__( 'No jobs yet.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'ID', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Scope', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Adapter', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Requested', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Completed', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Error', 'wp-reconnaissance' ) . '</th>'
			. '</tr></thead><tbody>';

		foreach ( $jobs as $job ) {
			echo '<tr>'
				. '<td>' . esc_html( (string) $job->id ) . '</td>'
				. '<td>' . esc_html( (string) $job->scope_id ) . '</td>'
				. '<td>' . esc_html( $this->job_status_label( $job ) ) . '</td>'
				. '<td>' . esc_html( $job->adapter ?? '' ) . '</td>'
				. '<td>' . esc_html( $job->requested_at->format( 'Y-m-d H:i' ) ) . '</td>'
				. '<td>' . esc_html( $job->completed_at?->format( 'Y-m-d H:i' ) ?? '' ) . '</td>'
				. '<td>' . esc_html( $job->error_category ?? '' ) . '</td>'
				. '</tr>';
		}

		echo '</tbody></table></div>';
	}

	/**
	 * Section 33's operator-facing failure monitoring: scopes whose most recent
	 * {@see self::REPEATED_FAILURE_THRESHOLD} jobs are all failures, surfaced proactively here
	 * rather than only reactively via the customer-facing notification
	 * {@see \Alltime\WPReconnaissance\Notifications\NotificationDispatcher} sends per scope.
	 */
	private function render_repeated_failures(): void {
		$scope_ids = $this->jobs->find_scopes_with_repeated_failures( self::REPEATED_FAILURE_THRESHOLD );

		if ( array() === $scope_ids ) {
			return;
		}

		echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Scopes with repeated assessment failures', 'wp-reconnaissance' ) . '</strong></p><ul style="margin-left:1.5em;list-style:disc">';

		foreach ( $scope_ids as $scope_id ) {
			$scope    = $this->scopes->find( $scope_id );
			$label    = null !== $scope ? $scope->domain_display : (string) $scope_id;
			$jobs_url = add_query_arg(
				array(
					'page'     => self::MENU_SLUG . '-jobs',
					'scope_id' => $scope_id,
				),
				admin_url( 'admin.php' )
			);

			echo '<li><a href="' . esc_url( $jobs_url ) . '">' . esc_html( $label ) . '</a></li>';
		}

		echo '</ul></div>';
	}

	private function job_status_label( Job $job ): string {
		return match ( $job->status ) {
			JobStatus::Succeeded => __( 'Succeeded', 'wp-reconnaissance' ),
			JobStatus::PartiallySucceeded => __( 'Partially succeeded', 'wp-reconnaissance' ),
			JobStatus::Failed => __( 'Failed', 'wp-reconnaissance' ),
			JobStatus::Running => __( 'Running', 'wp-reconnaissance' ),
			JobStatus::Queued => __( 'Queued', 'wp-reconnaissance' ),
			JobStatus::Cancelled => __( 'Cancelled', 'wp-reconnaissance' ),
			JobStatus::Expired => __( 'Expired', 'wp-reconnaissance' ),
			default => ucfirst( $job->status->value ),
		};
	}

	// -----------------------------------------------------------------------------------
	// Findings
	// -----------------------------------------------------------------------------------

	public function render_findings(): void {
		if ( ! current_user_can( Capabilities::REVIEW_FINDINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
		if ( 'review' === ( $_GET['action'] ?? '' ) && isset( $_GET['id'] ) ) {
			$this->render_finding_review( (int) $_GET['id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filters.
		$organisation_id = isset( $_GET['organisation_id'] ) ? (int) $_GET['organisation_id'] : null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filters.
		$status_raw = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$status     = FindingStatus::tryFrom( $status_raw );
		$page       = max( 1, (int) ( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.

		echo '<div class="wrap"><h1>' . esc_html__( 'Findings', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();
		$this->render_risk_reviews_due();

		$findings = null !== $organisation_id
			? $this->findings->find_by_organisation( $organisation_id, $status )
			: $this->findings->list_all( self::PER_PAGE, $page, $status );

		if ( array() === $findings ) {
			echo '<p>' . esc_html__( 'No findings yet.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'ID', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Scope', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Rule', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Title', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Severity', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Last observed', 'wp-reconnaissance' ) . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>';

		foreach ( $findings as $finding ) {
			$review_url = add_query_arg(
				array(
					'page'   => self::MENU_SLUG . '-findings',
					'action' => 'review',
					'id'     => $finding->id,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr>'
				. '<td>' . esc_html( (string) $finding->id ) . '</td>'
				. '<td>' . esc_html( (string) $finding->scope_id ) . '</td>'
				. '<td>' . esc_html( $finding->rule_id ) . '</td>'
				. '<td>' . esc_html( $finding->title ) . '</td>'
				. '<td>' . esc_html( ucfirst( $finding->severity->value ) ) . '</td>'
				. '<td>' . esc_html( ucfirst( str_replace( '_', ' ', $finding->status->value ) ) ) . '</td>'
				. '<td>' . esc_html( $finding->last_observed_at->format( 'Y-m-d H:i' ) ) . '</td>'
				. '<td><a href="' . esc_url( $review_url ) . '">' . esc_html__( 'Review', 'wp-reconnaissance' ) . '</a></td>'
				. '</tr>';
		}

		echo '</tbody></table></div>';
	}

	/**
	 * Section 33's suppression/risk-acceptance review workflow: a compact, dismiss-free box
	 * surfacing accepted-risk findings whose review date has arrived or is coming up soon, so a
	 * risk acceptance never silently persists past when it was meant to be reconfirmed.
	 */
	private function render_risk_reviews_due(): void {
		$due = $this->findings->find_due_risk_acceptance_reviews();

		if ( array() === $due ) {
			return;
		}

		echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Risk acceptances due for review', 'wp-reconnaissance' ) . '</strong></p><ul style="margin-left:1.5em;list-style:disc">';

		foreach ( $due as $finding ) {
			$review_url = add_query_arg(
				array(
					'page'   => self::MENU_SLUG . '-findings',
					'action' => 'review',
					'id'     => $finding->id,
				),
				admin_url( 'admin.php' )
			);

			echo '<li><a href="' . esc_url( $review_url ) . '">' . esc_html( $finding->title ) . '</a> - ' . sprintf(
				/* translators: %s: review date */
				esc_html__( 'review due %s', 'wp-reconnaissance' ),
				esc_html( $finding->risk_accept_review_date?->format( 'Y-m-d' ) ?? '' )
			) . '</li>';
		}

		echo '</ul></div>';
	}

	private function render_finding_review( int $id ): void {
		$finding = $this->findings->find( $id );

		if ( null === $finding ) {
			echo '<div class="wrap"><h1>' . esc_html__( 'Findings', 'wp-reconnaissance' ) . '</h1><p>' . esc_html__( 'Finding not found.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		$back_url = add_query_arg( array( 'page' => self::MENU_SLUG . '-findings' ), admin_url( 'admin.php' ) );
		$can_edit = current_user_can( Capabilities::MANAGE_FINDINGS );

		echo '<div class="wrap"><h1>' . esc_html( $finding->title ) . '</h1>';
		$this->render_notices();
		echo '<p><a href="' . esc_url( $back_url ) . '">&larr; ' . esc_html__( 'Back to findings', 'wp-reconnaissance' ) . '</a></p>';

		echo '<table class="form-table"><tbody>';
		echo '<tr><th>' . esc_html__( 'Rule', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $finding->rule_id ) . ' (v' . esc_html( $finding->rule_version ) . ')</td></tr>';
		echo '<tr><th>' . esc_html__( 'Severity', 'wp-reconnaissance' ) . '</th><td>' . esc_html( ucfirst( $finding->severity->value ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Confidence', 'wp-reconnaissance' ) . '</th><td>' . esc_html( ucfirst( $finding->confidence->value ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Risk statement', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $finding->risk_statement ?? '' ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Recommendation', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $finding->recommendation ?? '' ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'First observed', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $finding->first_observed_at->format( 'Y-m-d H:i' ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Last observed', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $finding->last_observed_at->format( 'Y-m-d H:i' ) ) . '</td></tr>';
		echo '</tbody></table>';

		if ( ! $can_edit ) {
			echo '</div>';
			return;
		}

		echo '<h2>' . esc_html__( 'Review', 'wp-reconnaissance' ) . '</h2>';
		echo '<form method="post">';
		wp_nonce_field( 'wpr_review_finding' );
		echo '<input type="hidden" name="wpr_admin_action" value="review_finding">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $finding->id ) . '">';
		echo '<table class="form-table"><tbody>';

		echo '<tr><th><label for="wpr_status">' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_status" name="status">';
		foreach ( FindingStatus::cases() as $status ) {
			echo '<option value="' . esc_attr( $status->value ) . '"' . selected( $finding->status->value, $status->value, false ) . '>' . esc_html( ucfirst( str_replace( '_', ' ', $status->value ) ) ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th><label for="wpr_operator_notes">' . esc_html__( 'Operator notes', 'wp-reconnaissance' ) . '</label></th><td><textarea id="wpr_operator_notes" name="operator_notes" rows="4" class="large-text">' . esc_textarea( $finding->operator_notes ?? '' ) . '</textarea></td></tr>';
		echo '<tr><th><label for="wpr_due_date">' . esc_html__( 'Due date', 'wp-reconnaissance' ) . '</label></th><td><input type="date" id="wpr_due_date" name="due_date" value="' . esc_attr( $finding->due_date?->format( 'Y-m-d' ) ?? '' ) . '"></td></tr>';
		echo '<tr><th><label for="wpr_suppression_reason">' . esc_html__( 'Suppression reason', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_suppression_reason" name="suppression_reason" value="' . esc_attr( $finding->suppression_reason ?? '' ) . '" class="regular-text"></td></tr>';
		echo '<tr><th><label for="wpr_suppression_expires_at">' . esc_html__( 'Suppression expires', 'wp-reconnaissance' ) . '</label></th><td><input type="date" id="wpr_suppression_expires_at" name="suppression_expires_at" value="' . esc_attr( $finding->suppression_expires_at?->format( 'Y-m-d' ) ?? '' ) . '"></td></tr>';
		echo '<tr><th><label for="wpr_risk_accept_review_date">' . esc_html__( 'Risk acceptance review date', 'wp-reconnaissance' ) . '</label></th><td><input type="date" id="wpr_risk_accept_review_date" name="risk_accept_review_date" value="' . esc_attr( $finding->risk_accept_review_date?->format( 'Y-m-d' ) ?? '' ) . '"><p class="description">' . esc_html__( 'Only recorded while status is "Accepted risk" - saving with any other status clears it. You will be recorded as the reviewer.', 'wp-reconnaissance' ) . '</p></td></tr>';
		echo '</tbody></table>';

		if ( FindingStatus::AcceptedRisk === $finding->status && null !== $finding->risk_accepted_by ) {
			$reviewer = get_userdata( $finding->risk_accepted_by );
			echo '<p>' . sprintf(
				/* translators: 1: reviewer display name, 2: review date */
				esc_html__( 'Risk currently accepted by %1$s, for review by %2$s.', 'wp-reconnaissance' ),
				esc_html( false !== $reviewer ? $reviewer->display_name : __( 'a former user', 'wp-reconnaissance' ) ),
				esc_html( $finding->risk_accept_review_date?->format( 'Y-m-d' ) ?? __( 'no date set', 'wp-reconnaissance' ) )
			) . '</p>';
		}
		submit_button( __( 'Save review', 'wp-reconnaissance' ) );
		echo '</form></div>';
	}

	private function handle_review_finding(): void {
		if ( ! current_user_can( Capabilities::MANAGE_FINDINGS ) || ! $this->verify_nonce( 'wpr_review_finding' ) ) {
			$this->redirect_with_notice( 'findings', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $id || null === $this->findings->find( $id ) ) {
			$this->redirect_with_notice( 'findings', 'error', __( 'Finding not found.', 'wp-reconnaissance' ) );
		}

		$status_raw      = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$status          = FindingStatus::tryFrom( $status_raw );
		$notes           = isset( $_POST['operator_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['operator_notes'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$due_date_raw    = isset( $_POST['due_date'] ) ? sanitize_text_field( wp_unslash( $_POST['due_date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$supp_reason     = isset( $_POST['suppression_reason'] ) ? sanitize_text_field( wp_unslash( $_POST['suppression_reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$supp_until      = isset( $_POST['suppression_expires_at'] ) ? sanitize_text_field( wp_unslash( $_POST['suppression_expires_at'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$risk_review_raw = isset( $_POST['risk_accept_review_date'] ) ? sanitize_text_field( wp_unslash( $_POST['risk_accept_review_date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( null === $status ) {
			$this->redirect_with_notice( 'findings', 'error', __( 'Invalid status.', 'wp-reconnaissance' ) );
		}

		// Meaningful only while the finding is being marked (or stays marked) accepted-risk - any
		// other status clears both, so a stale reviewer/review-date never survives past the
		// status it was recorded for.
		$is_accepting_risk = FindingStatus::AcceptedRisk === $status;

		$this->findings->update_review(
			$id,
			$status,
			'' !== $notes ? $notes : null,
			null,
			'' !== $due_date_raw ? new \DateTimeImmutable( $due_date_raw ) : null,
			'' !== $supp_reason ? $supp_reason : null,
			'' !== $supp_until ? new \DateTimeImmutable( $supp_until ) : null,
			$is_accepting_risk ? get_current_user_id() : null,
			$is_accepting_risk && '' !== $risk_review_raw ? new \DateTimeImmutable( $risk_review_raw ) : null
		);

		$this->audit_logger->log( 'finding.reviewed', 'finding', $id, get_current_user_id(), summary: $status->value );

		$url = add_query_arg(
			array(
				'page'        => self::MENU_SLUG . '-findings',
				'action'      => 'review',
				'id'          => $id,
				'wpr_notice'  => 'success',
				'wpr_message' => rawurlencode( __( 'Review saved.', 'wp-reconnaissance' ) ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	// -----------------------------------------------------------------------------------
	// Privacy requests (Section 26.4)
	// -----------------------------------------------------------------------------------

	public function render_privacy_requests(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
		if ( 'review' === ( $_GET['action'] ?? '' ) && isset( $_GET['id'] ) ) {
			$this->render_privacy_request_review( (int) $_GET['id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Privacy requests', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		echo '<h2>' . esc_html__( 'Record a request received by another channel', 'wp-reconnaissance' ) . '</h2>';
		echo '<p>' . esc_html__( 'For a verbal or written request that did not come through the customer portal (Section 26.4).', 'wp-reconnaissance' ) . '</p>';
		echo '<form method="post">';
		wp_nonce_field( 'wpr_record_privacy_request' );
		echo '<input type="hidden" name="wpr_admin_action" value="record_privacy_request">';
		echo '<table class="form-table"><tbody>';
		echo '<tr><th><label for="wpr_privacy_email">' . esc_html__( 'Email address', 'wp-reconnaissance' ) . '</label></th><td><input type="email" id="wpr_privacy_email" name="email" class="regular-text" required></td></tr>';
		echo '<tr><th><label for="wpr_privacy_right_type">' . esc_html__( 'Right', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_privacy_right_type" name="right_type">' . $this->privacy_right_type_options() . '</select></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- privacy_right_type_options() only emits esc_attr()/esc_html()-escaped <option> markup.
		echo '<tr><th><label for="wpr_privacy_channel">' . esc_html__( 'Channel', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_privacy_channel" name="channel" value="manual" class="regular-text"></td></tr>';
		echo '<tr><th><label for="wpr_privacy_details">' . esc_html__( 'Details', 'wp-reconnaissance' ) . '</label></th><td><textarea id="wpr_privacy_details" name="details" rows="3" class="large-text"></textarea></td></tr>';
		echo '</tbody></table>';
		submit_button( __( 'Record request', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Requests', 'wp-reconnaissance' ) . '</h2>';
		$this->render_privacy_requests_list();
		echo '</div>';
	}

	private function render_privacy_requests_list(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		$status_raw = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$status     = PrivacyRequestStatus::tryFrom( $status_raw );
		$page       = max( 1, (int) ( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.

		$result = $this->privacy_requests->list_all( self::PER_PAGE, $page, $status );

		if ( array() === $result['items'] ) {
			echo '<p>' . esc_html__( 'No privacy requests yet.', 'wp-reconnaissance' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'Email', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Right', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Channel', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Due', 'wp-reconnaissance' ) . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>';

		foreach ( $result['items'] as $request ) {
			$review_url = add_query_arg(
				array(
					'page'   => self::MENU_SLUG . '-privacy-requests',
					'action' => 'review',
					'id'     => $request->id,
				),
				admin_url( 'admin.php' )
			);

			$due_label = $request->is_overdue() ? '<strong style="color:#b32d2e">' . esc_html( $request->due_at->format( 'Y-m-d' ) ) . '</strong>' : esc_html( $request->due_at->format( 'Y-m-d' ) );

			echo '<tr>'
				. '<td>' . esc_html( $request->email ) . '</td>'
				. '<td>' . esc_html( $request->right_type->label() ) . '</td>'
				. '<td>' . esc_html( ucwords( str_replace( '_', ' ', $request->status->value ) ) ) . '</td>'
				. '<td>' . esc_html( $request->channel ) . '</td>'
				. '<td>' . $due_label . '</td>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $due_label is built from esc_html()-escaped fragments above.
				. '<td><a href="' . esc_url( $review_url ) . '">' . esc_html__( 'Review', 'wp-reconnaissance' ) . '</a></td>'
				. '</tr>';
		}

		echo '</tbody></table>';
	}

	private function render_privacy_request_review( int $id ): void {
		$request  = $this->privacy_requests->find( $id );
		$back_url = add_query_arg( array( 'page' => self::MENU_SLUG . '-privacy-requests' ), admin_url( 'admin.php' ) );

		echo '<div class="wrap"><h1>' . esc_html__( 'Privacy request', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();
		echo '<p><a href="' . esc_url( $back_url ) . '">&larr; ' . esc_html__( 'Back to privacy requests', 'wp-reconnaissance' ) . '</a></p>';

		if ( null === $request ) {
			echo '<p>' . esc_html__( 'Request not found.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo '<table class="form-table"><tbody>';
		echo '<tr><th>' . esc_html__( 'Email', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->email ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Right', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->right_type->label() ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th><td>' . esc_html( ucwords( str_replace( '_', ' ', $request->status->value ) ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Channel', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->channel ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Details', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->details ?? '' ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Identity verified', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->identity_verified_at?->format( 'Y-m-d H:i' ) ?? __( 'Not yet', 'wp-reconnaissance' ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Restricted', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->restricted ? __( 'Yes', 'wp-reconnaissance' ) : __( 'No', 'wp-reconnaissance' ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Statutory due date', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->due_at->format( 'Y-m-d' ) ) . ( $request->is_overdue() ? ' <strong style="color:#b32d2e">' . esc_html__( 'Overdue', 'wp-reconnaissance' ) . '</strong>' : '' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the trailing fragment is either empty or built entirely from esc_html().
		echo '<tr><th>' . esc_html__( 'Outcome', 'wp-reconnaissance' ) . '</th><td>' . esc_html( $request->outcome_summary ?? $request->refusal_reason ?? '' ) . '</td></tr>';
		echo '</tbody></table>';

		echo '<h2>' . esc_html__( 'Linked data', 'wp-reconnaissance' ) . '</h2>';
		$this->render_privacy_request_data( $request );

		if ( ! $request->status->is_open() ) {
			echo '</div>';
			return;
		}

		$this->render_privacy_request_actions( $request );
		echo '</div>';
	}

	private function render_privacy_request_data( PrivacyRequest $request ): void {
		$groups = $this->privacy_request_service->locate_data( $request );

		if ( array() === $groups ) {
			echo '<p>' . esc_html__( 'No linked data was found.', 'wp-reconnaissance' ) . '</p>';
			return;
		}

		foreach ( $groups as $group ) {
			echo '<h3>' . esc_html( $group['group_label'] ) . '</h3><table class="widefat"><tbody>';
			foreach ( $group['data'] as $field ) {
				echo '<tr><th style="width:220px">' . esc_html( $field['name'] ) . '</th><td>' . esc_html( (string) $field['value'] ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
	}

	private function render_privacy_request_actions( PrivacyRequest $request ): void {
		echo '<h2>' . esc_html__( 'Actions', 'wp-reconnaissance' ) . '</h2>';

		if ( null === $request->identity_verified_at ) {
			echo $this->privacy_action_form( $request->id, 'verify_privacy_request_identity', 'wpr_verify_privacy_request_identity', __( 'Verify identity', 'wp-reconnaissance' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- privacy_action_form() only emits wp_nonce_field()/esc_*()-escaped fragments.
		}

		echo '<form method="post" style="margin-bottom:12px">';
		wp_nonce_field( 'wpr_classify_privacy_request' );
		echo '<input type="hidden" name="wpr_admin_action" value="classify_privacy_request">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $request->id ) . '">';
		echo '<label>' . esc_html__( 'Reclassify as', 'wp-reconnaissance' ) . ' <select name="right_type">' . $this->privacy_right_type_options( $request->right_type ) . '</select> '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- privacy_right_type_options() only emits esc_attr()/esc_html()-escaped <option> markup.
		echo '<button type="submit" class="button">' . esc_html__( 'Save', 'wp-reconnaissance' ) . '</button></label></form>';

		echo $this->privacy_action_form( $request->id, 'toggle_privacy_request_restriction', 'wpr_toggle_privacy_request_restriction', $request->restricted ? __( 'Lift restriction', 'wp-reconnaissance' ) : __( 'Restrict processing', 'wp-reconnaissance' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- privacy_action_form() only emits wp_nonce_field()/esc_*()-escaped fragments.

		echo '<form method="post" style="margin-bottom:12px">';
		wp_nonce_field( 'wpr_assign_privacy_request' );
		echo '<input type="hidden" name="wpr_admin_action" value="assign_privacy_request">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $request->id ) . '">';
		echo '<label>' . esc_html__( 'Assign to (WordPress user ID)', 'wp-reconnaissance' ) . ' <input type="number" name="assigned_to" min="1" value="' . esc_attr( null !== $request->assigned_to ? (string) $request->assigned_to : '' ) . '"> ';
		echo '<button type="submit" class="button">' . esc_html__( 'Assign', 'wp-reconnaissance' ) . '</button></label></form>';

		echo '<form method="post" style="margin-bottom:12px">';
		wp_nonce_field( 'wpr_complete_privacy_request' );
		echo '<input type="hidden" name="wpr_admin_action" value="complete_privacy_request">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $request->id ) . '">';
		echo '<p><label>' . esc_html__( 'Outcome summary (sent to the requester)', 'wp-reconnaissance' ) . '<br><textarea name="outcome_summary" rows="3" class="large-text" required></textarea></label></p>';
		echo '<p><button type="submit" name="wpr_outcome" value="complete" class="button button-primary">' . esc_html__( 'Complete', 'wp-reconnaissance' ) . '</button> ';
		echo '<button type="submit" name="wpr_outcome" value="partial" class="button">' . esc_html__( 'Partially complete', 'wp-reconnaissance' ) . '</button></p>';
		echo '</form>';

		echo '<form method="post" style="margin-bottom:12px">';
		wp_nonce_field( 'wpr_refuse_privacy_request' );
		echo '<input type="hidden" name="wpr_admin_action" value="refuse_privacy_request">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $request->id ) . '">';
		echo '<p><label>' . esc_html__( 'Refusal reason (sent to the requester)', 'wp-reconnaissance' ) . '<br><textarea name="refusal_reason" rows="3" class="large-text" required></textarea></label></p>';
		echo '<p><button type="submit" class="button">' . esc_html__( 'Refuse', 'wp-reconnaissance' ) . '</button></p>';
		echo '</form>';
	}

	private function privacy_action_form( int $id, string $action, string $nonce_action, string $label ): string {
		return '<form method="post" style="margin-bottom:12px">'
			. wp_nonce_field( $nonce_action, '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_admin_action" value="' . esc_attr( $action ) . '">'
			. '<input type="hidden" name="id" value="' . esc_attr( (string) $id ) . '">'
			. '<button type="submit" class="button">' . esc_html( $label ) . '</button>'
			. '</form>';
	}

	private function privacy_right_type_options( ?PrivacyRightType $selected = null ): string {
		$options = '';

		foreach ( PrivacyRightType::cases() as $right_type ) {
			$options .= '<option value="' . esc_attr( $right_type->value ) . '"' . selected( $selected?->value, $right_type->value, false ) . '>' . esc_html( $right_type->label() ) . '</option>';
		}

		return $options;
	}

	private function handle_record_privacy_request(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) || ! $this->verify_nonce( 'wpr_record_privacy_request' ) ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$email      = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$right_type = PrivacyRightType::tryFrom( isset( $_POST['right_type'] ) ? sanitize_key( wp_unslash( $_POST['right_type'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$channel    = isset( $_POST['channel'] ) ? sanitize_text_field( wp_unslash( $_POST['channel'] ) ) : 'manual'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$details    = isset( $_POST['details'] ) ? sanitize_textarea_field( wp_unslash( $_POST['details'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( ! is_email( $email ) || null === $right_type ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'A valid email address and right are required.', 'wp-reconnaissance' ) );
		}

		$user    = get_user_by( 'email', $email );
		$request = $this->privacy_request_service->submit( $email, $right_type, $details, '' !== $channel ? $channel : 'manual', false !== $user ? $user->ID : null );

		$this->redirect_with_notice(
			'privacy-requests',
			'success',
			sprintf(
			/* translators: %d: privacy request ID */
				__( 'Privacy request #%d recorded.', 'wp-reconnaissance' ),
				$request->id
			)
		);
	}

	private function handle_verify_privacy_request_identity(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) || ! $this->verify_nonce( 'wpr_verify_privacy_request_identity' ) ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id = $this->privacy_request_id_from_post();
		$this->privacy_request_service->verify_identity( $id, get_current_user_id() );
		$this->redirect_to_privacy_request_review( $id, __( 'Identity verified.', 'wp-reconnaissance' ) );
	}

	private function handle_classify_privacy_request(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) || ! $this->verify_nonce( 'wpr_classify_privacy_request' ) ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id         = $this->privacy_request_id_from_post();
		$right_type = PrivacyRightType::tryFrom( isset( $_POST['right_type'] ) ? sanitize_key( wp_unslash( $_POST['right_type'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( null === $right_type ) {
			$this->redirect_to_privacy_request_review( $id, __( 'Invalid right selected.', 'wp-reconnaissance' ), 'error' );
		}

		$this->privacy_request_service->classify( $id, $right_type, get_current_user_id() );
		$this->redirect_to_privacy_request_review( $id, __( 'Request reclassified.', 'wp-reconnaissance' ) );
	}

	private function handle_assign_privacy_request(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) || ! $this->verify_nonce( 'wpr_assign_privacy_request' ) ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id          = $this->privacy_request_id_from_post();
		$assignee_id = isset( $_POST['assigned_to'] ) ? (int) $_POST['assigned_to'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		$this->privacy_request_service->assign( $id, $assignee_id > 0 ? $assignee_id : null, get_current_user_id() );
		$this->redirect_to_privacy_request_review( $id, __( 'Assignment updated.', 'wp-reconnaissance' ) );
	}

	private function handle_toggle_privacy_request_restriction(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) || ! $this->verify_nonce( 'wpr_toggle_privacy_request_restriction' ) ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id      = $this->privacy_request_id_from_post();
		$request = $this->privacy_requests->find( $id );

		if ( null === $request ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Request not found.', 'wp-reconnaissance' ) );
		}

		if ( $request->restricted ) {
			$this->privacy_request_service->lift_restriction( $id, get_current_user_id() );
		} else {
			$this->privacy_request_service->restrict( $id, get_current_user_id() );
		}

		$this->redirect_to_privacy_request_review( $id, __( 'Restriction updated.', 'wp-reconnaissance' ) );
	}

	private function handle_complete_privacy_request(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) || ! $this->verify_nonce( 'wpr_complete_privacy_request' ) ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id      = $this->privacy_request_id_from_post();
		$summary = isset( $_POST['outcome_summary'] ) ? sanitize_textarea_field( wp_unslash( $_POST['outcome_summary'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( '' === $summary ) {
			$this->redirect_to_privacy_request_review( $id, __( 'An outcome summary is required.', 'wp-reconnaissance' ), 'error' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		if ( 'partial' === ( $_POST['wpr_outcome'] ?? '' ) ) {
			$this->privacy_request_service->partially_complete( $id, get_current_user_id(), $summary );
		} else {
			$this->privacy_request_service->complete( $id, get_current_user_id(), $summary );
		}

		$this->redirect_to_privacy_request_review( $id, __( 'Outcome recorded and the requester notified.', 'wp-reconnaissance' ) );
	}

	private function handle_refuse_privacy_request(): void {
		if ( ! current_user_can( Capabilities::MANAGE_PRIVACY_REQUESTS ) || ! $this->verify_nonce( 'wpr_refuse_privacy_request' ) ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$id     = $this->privacy_request_id_from_post();
		$reason = isset( $_POST['refusal_reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['refusal_reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( '' === $reason ) {
			$this->redirect_to_privacy_request_review( $id, __( 'A refusal reason is required.', 'wp-reconnaissance' ), 'error' );
		}

		$this->privacy_request_service->refuse( $id, get_current_user_id(), $reason );
		$this->redirect_to_privacy_request_review( $id, __( 'Refusal recorded and the requester notified.', 'wp-reconnaissance' ) );
	}

	private function privacy_request_id_from_post(): int {
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified by the caller before this is read.

		if ( 0 === $id ) {
			$this->redirect_with_notice( 'privacy-requests', 'error', __( 'No privacy request was specified.', 'wp-reconnaissance' ) );
		}

		return $id;
	}

	private function redirect_to_privacy_request_review( int $id, string $message, string $type = 'success' ): never {
		$url = add_query_arg(
			array(
				'page'        => self::MENU_SLUG . '-privacy-requests',
				'action'      => 'review',
				'id'          => $id,
				'wpr_notice'  => $type,
				'wpr_message' => rawurlencode( $message ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	// -----------------------------------------------------------------------------------
	// Reports (not yet implemented - Section 21)
	// -----------------------------------------------------------------------------------

	public function render_reports(): void {
		if ( ! current_user_can( Capabilities::ISSUE_REPORTS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		if ( 'draft' === $action && isset( $_GET['scope_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			$this->render_report_draft( (int) $_GET['scope_id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			return;
		}

		if ( 'view' === $action && isset( $_GET['id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			$this->render_issued_report( (int) $_GET['id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			return;
		}

		if ( 'download' === $action && isset( $_GET['id'], $_GET['token'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing; the download token is verified in render_report_pdf_download().
			$this->render_report_pdf_download( (int) $_GET['id'], sanitize_text_field( wp_unslash( $_GET['token'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			return;
		}

		$this->render_reports_index();
	}

	private function render_reports_index(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Reports', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		echo '<h2>' . esc_html__( 'Generate a draft report', 'wp-reconnaissance' ) . '</h2>';
		echo '<form method="get">';
		echo '<input type="hidden" name="page" value="' . esc_attr( self::MENU_SLUG . '-reports' ) . '">';
		echo '<input type="hidden" name="action" value="draft">';
		echo '<table class="form-table"><tbody><tr><th><label for="wpr_report_scope_id">' . esc_html__( 'Scope', 'wp-reconnaissance' ) . '</label></th><td>' . $this->scope_select() . '</td></tr></tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- scope_select() only emits esc_*()-escaped fragments.
		submit_button( __( 'Generate draft', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Issued reports', 'wp-reconnaissance' ) . '</h2>';
		$this->render_issued_reports_list();
		echo '</div>';
	}

	private function render_issued_reports_list(): void {
		$reports = array();

		foreach ( $this->organisations->list( 200, 1 ) as $organisation ) {
			foreach ( $this->reports->find_latest_by_organisation( (int) $organisation->id ) as $report ) {
				$reports[] = $report;
			}
		}

		if ( array() === $reports ) {
			echo '<p>' . esc_html__( 'No reports have been issued yet.', 'wp-reconnaissance' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'Scope', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Version', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Generated', 'wp-reconnaissance' ) . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>';

		foreach ( $reports as $report ) {
			$view_url = add_query_arg(
				array(
					'page'   => self::MENU_SLUG . '-reports',
					'action' => 'view',
					'id'     => $report->id,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr>'
				. '<td>' . esc_html( (string) $report->scope_id ) . '</td>'
				. '<td>' . esc_html( (string) $report->version ) . '</td>'
				. '<td>' . esc_html( $report->generated_at->format( 'Y-m-d H:i' ) ) . '</td>'
				. '<td><a href="' . esc_url( $view_url ) . '">' . esc_html__( 'View', 'wp-reconnaissance' ) . '</a></td>'
				. '</tr>';
		}

		echo '</tbody></table>';
	}

	private function scope_select(): string {
		$options = '';

		foreach ( $this->scopes->list_all( 200, 1 ) as $scope ) {
			$options .= '<option value="' . esc_attr( (string) $scope->id ) . '">' . esc_html( $scope->domain_display ) . ' (#' . esc_html( (string) $scope->id ) . ')</option>';
		}

		return '<select id="wpr_report_scope_id" name="scope_id" required><option value="">' . esc_html__( '- Select -', 'wp-reconnaissance' ) . '</option>' . $options . '</select>';
	}

	private function render_report_draft( int $scope_id ): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Draft report', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		try {
			$document = $this->report_builder->generate( $scope_id );
		} catch ( ReportException $exception ) {
			echo '<p>' . esc_html( $exception->getMessage() ) . '</p></div>';
			return;
		}

		echo '<p>' . esc_html__( 'This is a preview - nothing has been saved yet. Add or edit the executive summary below, then issue the report to save it as an immutable version.', 'wp-reconnaissance' ) . '</p>';

		if ( current_user_can( Capabilities::ISSUE_REPORTS ) ) {
			echo '<form method="post">';
			wp_nonce_field( 'wpr_issue_report' );
			echo '<input type="hidden" name="wpr_admin_action" value="issue_report">';
			echo '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope_id ) . '">';
			echo '<table class="form-table"><tbody><tr><th><label for="wpr_executive_summary">' . esc_html__( 'Executive summary', 'wp-reconnaissance' ) . '</label></th><td><textarea id="wpr_executive_summary" name="executive_summary" rows="4" class="large-text">' . esc_textarea( (string) $document['executive_summary'] ) . '</textarea></td></tr></tbody></table>';
			submit_button(
				sprintf(
					/* translators: %d: report version number about to be issued */
					__( 'Issue report (version %d)', 'wp-reconnaissance' ),
					(int) $document['version']
				)
			);
			echo '</form>';
		}

		echo '<hr>' . $this->render_document_preview( $document ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_document_preview() delegates to HtmlReportRenderer, which only emits esc_*()-escaped fragments.
		echo '</div>';
	}

	/**
	 * @param array<string,mixed> $document
	 */
	private function render_document_preview( array $document ): string {
		return '<div><h2>' . esc_html__( 'Preview', 'wp-reconnaissance' ) . '</h2>'
			. '<p>' . esc_html__( 'Findings included:', 'wp-reconnaissance' ) . ' ' . esc_html( (string) count( (array) $document['findings'] ) )
			. ' &middot; ' . esc_html__( 'Remediation tasks:', 'wp-reconnaissance' ) . ' ' . esc_html( (string) count( (array) $document['remediation_plan'] ) ) . '</p></div>';
	}

	private function render_issued_report( int $id ): void {
		$report = $this->reports->find( $id );

		echo '<div class="wrap"><h1>' . esc_html__( 'Report', 'wp-reconnaissance' ) . '</h1>';

		if ( null === $report ) {
			echo '<p>' . esc_html__( 'Report not found.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		echo $this->report_renderer->render( $report ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HtmlReportRenderer only emits esc_*()-escaped fragments.

		$download_url = add_query_arg(
			array(
				'page'   => self::MENU_SLUG . '-reports',
				'action' => 'download',
				'id'     => $report->id,
				'token'  => ( new ReportDownloadToken() )->create( $report->id ),
			),
			admin_url( 'admin.php' )
		);

		echo '<p><a class="button" href="' . esc_url( $download_url ) . '">' . esc_html__( 'Download PDF', 'wp-reconnaissance' ) . '</a></p>';
		$this->render_report_version_history( $report );
		echo '</div>';
	}

	/**
	 * Section 33's "issued report versions": every version issued for this report's scope, and -
	 * where an immediately-earlier version exists - a comparison summary of which findings are
	 * new or resolved since it, via {@see ReportComparator}.
	 */
	private function render_report_version_history( Report $report ): void {
		$versions = $this->reports->find_by_scope( $report->scope_id );

		if ( count( $versions ) < 2 ) {
			return;
		}

		echo '<h2>' . esc_html__( 'Version history', 'wp-reconnaissance' ) . '</h2><table class="widefat striped" style="max-width:480px"><thead><tr>'
			. '<th>' . esc_html__( 'Version', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Generated', 'wp-reconnaissance' ) . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>';

		foreach ( $versions as $version ) {
			$view_url = add_query_arg(
				array(
					'page'   => self::MENU_SLUG . '-reports',
					'action' => 'view',
					'id'     => $version->id,
				),
				admin_url( 'admin.php' )
			);

			echo '<tr' . ( $version->id === $report->id ? ' style="font-weight:600"' : '' ) . '>'
				. '<td>' . esc_html( (string) $version->version ) . '</td>'
				. '<td>' . esc_html( $version->generated_at->format( 'Y-m-d H:i' ) ) . '</td>'
				. '<td><a href="' . esc_url( $view_url ) . '">' . esc_html__( 'View', 'wp-reconnaissance' ) . '</a></td>'
				. '</tr>';
		}

		echo '</tbody></table>';

		$previous = null;
		foreach ( $versions as $version ) {
			if ( $version->version < $report->version && ( null === $previous || $version->version > $previous->version ) ) {
				$previous = $version;
			}
		}

		if ( null === $previous ) {
			return;
		}

		$comparison = $this->report_comparator->compare( $previous, $report );

		if ( ! $comparison->has_changes() ) {
			echo '<p>' . esc_html__( 'No findings changed since the previous version.', 'wp-reconnaissance' ) . '</p>';
			return;
		}

		echo '<h3>' . sprintf(
			/* translators: %s: earlier report version number */
			esc_html__( 'What changed since version %s', 'wp-reconnaissance' ),
			esc_html( (string) $previous->version )
		) . '</h3>';

		echo $this->render_finding_comparison_list( __( 'New findings', 'wp-reconnaissance' ), $comparison->new_findings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_finding_comparison_list() only emits esc_*()-escaped fragments.
		echo $this->render_finding_comparison_list( __( 'Resolved findings', 'wp-reconnaissance' ), $comparison->resolved_findings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_finding_comparison_list() only emits esc_*()-escaped fragments.
	}

	/**
	 * @param array<int,array<string,mixed>> $findings
	 */
	private function render_finding_comparison_list( string $heading, array $findings ): string {
		if ( array() === $findings ) {
			return '';
		}

		$items = '';
		foreach ( $findings as $finding ) {
			$items .= '<li>' . esc_html( (string) ( $finding['title'] ?? $finding['rule_id'] ?? '' ) ) . ' (' . esc_html( ucfirst( (string) ( $finding['severity'] ?? '' ) ) ) . ')</li>';
		}

		return '<p><strong>' . esc_html( $heading ) . '</strong></p><ul style="margin-left:1.5em;list-style:disc">' . $items . '</ul>';
	}

	/**
	 * Serves the stored PDF for an issued report as a short-lived, authorised download (Section
	 * 21.2). The signed token is verified before any bytes are sent; the file itself lives in
	 * protected storage and is never a public URL.
	 */
	private function render_report_pdf_download( int $report_id, string $token ): void {
		if ( ! current_user_can( Capabilities::ISSUE_REPORTS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		$report = $this->reports->find( $report_id );

		if ( null === $report || null === ( new ReportDownloadToken() )->verify( $token ) ) {
			wp_die( esc_html__( 'This download link is invalid or has expired.', 'wp-reconnaissance' ) );
		}

		$pdf = ( new ReportPdfService() )->retrieve_pdf( $report );

		if ( null === $pdf ) {
			wp_die( esc_html__( 'The PDF for this report is not ready yet. Please try again shortly.', 'wp-reconnaissance' ) );
		}

		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . esc_attr( 'wp-reconnaissance-report-' . $report->report_uuid . '.pdf' ) . '"' );
		header( 'Content-Length: ' . (string) strlen( $pdf ) );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw PDF bytes, not HTML; escaping would corrupt the file.
		exit;
	}

	private function handle_issue_report(): void {
		if ( ! current_user_can( Capabilities::ISSUE_REPORTS ) || ! $this->verify_nonce( 'wpr_issue_report' ) ) {
			$this->redirect_with_notice( 'reports', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$scope_id          = isset( $_POST['scope_id'] ) ? (int) $_POST['scope_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$executive_summary = isset( $_POST['executive_summary'] ) ? sanitize_textarea_field( wp_unslash( $_POST['executive_summary'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $scope_id ) {
			$this->redirect_with_notice( 'reports', 'error', __( 'No scope was specified.', 'wp-reconnaissance' ) );
		}

		$this->task_generator->generate_for_scope( $scope_id, get_current_user_id() );

		try {
			$document = $this->report_builder->generate( $scope_id, '' !== $executive_summary ? $executive_summary : null );
		} catch ( ReportException $exception ) {
			$this->redirect_with_notice( 'reports', 'error', $exception->getMessage() );
		}

		$report = $this->reports->save(
			(int) $document['organisation_id'],
			$scope_id,
			(int) $document['observation_id'],
			(int) $document['version'],
			$document,
			get_current_user_id()
		);

		$this->audit_logger->log( 'report.issued', 'report', $report->id, get_current_user_id(), summary: "scope #{$scope_id} v{$report->version}" );

		$url = add_query_arg(
			array(
				'page'        => self::MENU_SLUG . '-reports',
				'action'      => 'view',
				'id'          => $report->id,
				'wpr_notice'  => 'success',
				'wpr_message' => rawurlencode( __( 'Report issued.', 'wp-reconnaissance' ) ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	// -----------------------------------------------------------------------------------
	// Abuse review
	// -----------------------------------------------------------------------------------

	public function render_abuse_review(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ABUSE_REVIEW ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		$page = max( 1, (int) ( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.

		echo '<div class="wrap"><h1>' . esc_html__( 'Abuse review', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		echo '<p>' . esc_html__( 'Signals raised by the Section 5.6 anti-abuse controls. A signal holds the affected free assessment until you release, dismiss or block it. Releasing a signal dispatches the held assessment for the account.', 'wp-reconnaissance' ) . '</p>';

		$result = $this->anti_abuse->list_open_signals( self::PER_PAGE, $page );

		if ( 0 === $result['total'] ) {
			echo '<p>' . esc_html__( 'No open signals awaiting review.', 'wp-reconnaissance' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr>'
				. '<th>' . esc_html__( 'ID', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Type', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Subject', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Severity', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Created', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Actions', 'wp-reconnaissance' ) . '</th>'
				. '</tr></thead><tbody>';

			foreach ( $result['items'] as $signal ) {
				echo '<tr>'
					. '<td>' . esc_html( (string) $signal->id ) . '</td>'
					. '<td>' . esc_html( $this->signal_type_label( $signal->type ) ) . '</td>'
					. '<td>' . esc_html( $signal->subject_value ) . '</td>'
					. '<td>' . esc_html( $signal->severity ) . '</td>'
					. '<td>' . esc_html( $signal->created_at->format( 'Y-m-d H:i' ) ) . '</td>'
					. '<td>' . $this->render_signal_actions( $signal->id ) . '</td>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_signal_actions() only emits esc_*()-escaped fragments.
					. '</tr>';
			}

			echo '</tbody></table>';
		}

		echo '<h2>' . esc_html__( 'Block / allow list', 'wp-reconnaissance' ) . '</h2>';
		echo '<form method="post" style="margin-bottom:16px">';
		wp_nonce_field( 'wpr_add_blocklist_entry' );
		echo '<input type="hidden" name="wpr_admin_action" value="add_blocklist_entry">';
		echo '<table class="form-table" style="max-width:720px"><tbody>';
		echo '<tr><th><label for="wpr_bl_type">' . esc_html__( 'List', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_bl_type" name="list_type"><option value="block">' . esc_html__( 'Block', 'wp-reconnaissance' ) . '</option><option value="allow">' . esc_html__( 'Allow', 'wp-reconnaissance' ) . '</option></select></td></tr>';
		echo '<tr><th><label for="wpr_bl_match">' . esc_html__( 'Match', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_bl_match" name="match_type"><option value="email">' . esc_html__( 'Email', 'wp-reconnaissance' ) . '</option><option value="domain">' . esc_html__( 'Domain', 'wp-reconnaissance' ) . '</option><option value="ip">' . esc_html__( 'IP address', 'wp-reconnaissance' ) . '</option></select></td></tr>';
		echo '<tr><th><label for="wpr_bl_value">' . esc_html__( 'Value', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_bl_value" name="value" class="regular-text" required></td></tr>';
		echo '<tr><th><label for="wpr_bl_reason">' . esc_html__( 'Reason', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_bl_reason" name="reason" class="regular-text"></td></tr>';
		echo '</tbody></table>';
		submit_button( __( 'Add entry', 'wp-reconnaissance' ) );
		echo '</form>';

		$entries = $this->anti_abuse->list_blocklist( 100, 1 );

		if ( array() === $entries ) {
			echo '<p>' . esc_html__( 'The block/allow list is empty.', 'wp-reconnaissance' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr>'
				. '<th>' . esc_html__( 'List', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Match', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Value', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Reason', 'wp-reconnaissance' ) . '</th>'
				. '<th>' . esc_html__( 'Expires', 'wp-reconnaissance' ) . '</th>'
				. '<th></th>'
				. '</tr></thead><tbody>';

			foreach ( $entries as $entry ) {
				echo '<tr>'
					. '<td>' . esc_html( $entry->list_type->value ) . '</td>'
					. '<td>' . esc_html( $entry->match_type->value ) . '</td>'
					. '<td>' . esc_html( $entry->value ) . '</td>'
					. '<td>' . esc_html( (string) $entry->reason ) . '</td>'
					. '<td>' . esc_html( $entry->expires_at?->format( 'Y-m-d H:i' ) ?? '' ) . '</td>'
					. '<td><form method="post" style="display:inline">'
					. wp_nonce_field( 'wpr_remove_blocklist_entry', '_wpnonce', true, false ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field() emits a safe hidden nonce field.
					. '<input type="hidden" name="wpr_admin_action" value="remove_blocklist_entry">'
					. '<input type="hidden" name="entry_id" value="' . esc_attr( (string) $entry->id ) . '">'
					. '<button type="submit" class="button-link-delete">' . esc_html__( 'Remove', 'wp-reconnaissance' ) . '</button>'
					. '</form></td>'
					. '</tr>';
			}

			echo '</tbody></table>';
		}

		echo '</div>';
	}

	private function render_signal_actions( int $signal_id ): string {
		$actions = '';

		foreach ( array(
			'release_abuse_signal' => __( 'Release', 'wp-reconnaissance' ),
			'dismiss_abuse_signal' => __( 'Dismiss', 'wp-reconnaissance' ),
			'block_abuse_signal'   => __( 'Block', 'wp-reconnaissance' ),
		) as $action => $label ) {
			$actions .= '<form method="post" style="display:inline">'
				. wp_nonce_field( 'wpr_' . $action, '_wpnonce', true, false )
				. '<input type="hidden" name="wpr_admin_action" value="' . esc_attr( $action ) . '">'
				. '<input type="hidden" name="signal_id" value="' . esc_attr( (string) $signal_id ) . '">'
				. '<button type="submit" class="button">' . esc_html( $label ) . '</button> '
				. '</form>';
		}

		return $actions;
	}

	private function signal_type_label( SignalType $type ): string {
		return match ( $type ) {
			SignalType::DisposableEmail => __( 'Disposable email', 'wp-reconnaissance' ),
			SignalType::DuplicateDomain => __( 'Duplicate domain', 'wp-reconnaissance' ),
			SignalType::MaxQueuedJobs   => __( 'Max queued jobs', 'wp-reconnaissance' ),
			SignalType::BlockedEmail    => __( 'Blocked email', 'wp-reconnaissance' ),
			SignalType::BlockedDomain   => __( 'Blocked domain', 'wp-reconnaissance' ),
			SignalType::BlockedIp       => __( 'Blocked IP', 'wp-reconnaissance' ),
			SignalType::CaptchaFailed   => __( 'Bot challenge failed', 'wp-reconnaissance' ),
		};
	}

	private function handle_release_abuse_signal(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ABUSE_REVIEW ) || ! $this->verify_nonce( 'wpr_release_abuse_signal' ) ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$signal_id = isset( $_POST['signal_id'] ) ? (int) $_POST['signal_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $signal_id ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'No signal was specified.', 'wp-reconnaissance' ) );
		}

		$signal = $this->anti_abuse->release_signal( $signal_id, get_current_user_id() );

		// Deliver the held free assessment for the account that owns the released subject.
		$account = $this->accounts->find_by_email( $signal->subject_value );

		if ( null !== $account ) {
			$this->free_assessment->dispatch_free_assessment_for_account( $account );
		}

		$this->redirect_with_notice( 'abuse-review', 'success', __( 'Signal released.', 'wp-reconnaissance' ) );
	}

	private function handle_dismiss_abuse_signal(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ABUSE_REVIEW ) || ! $this->verify_nonce( 'wpr_dismiss_abuse_signal' ) ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$signal_id = isset( $_POST['signal_id'] ) ? (int) $_POST['signal_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $signal_id ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'No signal was specified.', 'wp-reconnaissance' ) );
		}

		$this->anti_abuse->dismiss_signal( $signal_id, get_current_user_id() );
		$this->redirect_with_notice( 'abuse-review', 'success', __( 'Signal dismissed.', 'wp-reconnaissance' ) );
	}

	private function handle_block_abuse_signal(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ABUSE_REVIEW ) || ! $this->verify_nonce( 'wpr_block_abuse_signal' ) ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$signal_id = isset( $_POST['signal_id'] ) ? (int) $_POST['signal_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $signal_id ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'No signal was specified.', 'wp-reconnaissance' ) );
		}

		$this->anti_abuse->block_signal( $signal_id, get_current_user_id() );
		$this->redirect_with_notice( 'abuse-review', 'success', __( 'Subject blocked.', 'wp-reconnaissance' ) );
	}

	private function handle_add_blocklist_entry(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ABUSE_REVIEW ) || ! $this->verify_nonce( 'wpr_add_blocklist_entry' ) ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$list_type  = isset( $_POST['list_type'] ) ? sanitize_key( wp_unslash( $_POST['list_type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$match_type = isset( $_POST['match_type'] ) ? sanitize_key( wp_unslash( $_POST['match_type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$value      = isset( $_POST['value'] ) ? sanitize_text_field( wp_unslash( $_POST['value'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		$reason     = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		$list_type_enum  = ListType::tryFrom( $list_type );
		$match_type_enum = MatchType::tryFrom( $match_type );

		if ( null === $list_type_enum || null === $match_type_enum || '' === trim( $value ) ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'Invalid blocklist entry.', 'wp-reconnaissance' ) );
		}

		$this->anti_abuse->add_blocklist_entry( $list_type_enum, $match_type_enum, $value, '' !== $reason ? $reason : null, get_current_user_id() );
		$this->redirect_with_notice( 'abuse-review', 'success', __( 'Blocklist entry added.', 'wp-reconnaissance' ) );
	}

	private function handle_remove_blocklist_entry(): void {
		if ( ! current_user_can( Capabilities::MANAGE_ABUSE_REVIEW ) || ! $this->verify_nonce( 'wpr_remove_blocklist_entry' ) ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$entry_id = isset( $_POST['entry_id'] ) ? (int) $_POST['entry_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		if ( 0 === $entry_id ) {
			$this->redirect_with_notice( 'abuse-review', 'error', __( 'No entry was specified.', 'wp-reconnaissance' ) );
		}

		$this->anti_abuse->remove_blocklist_entry( $entry_id, get_current_user_id() );
		$this->redirect_with_notice( 'abuse-review', 'success', __( 'Blocklist entry removed.', 'wp-reconnaissance' ) );
	}

	// -----------------------------------------------------------------------------------
	// Settings
	// -----------------------------------------------------------------------------------

	public function render_settings(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to access this screen.', 'wp-reconnaissance' ) );
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Settings', 'wp-reconnaissance' ) . '</h1>';
		$this->render_notices();

		echo '<h2>' . esc_html__( 'Local process execution adapter', 'wp-reconnaissance' ) . '</h2>';
		echo '<p>' . esc_html__( 'Runs the collection worker as a separate OS process on this server. Validate both paths carefully before enabling - Section 16.', 'wp-reconnaissance' ) . '</p>';

		echo '<form method="post">';
		wp_nonce_field( 'wpr_save_settings' );
		echo '<input type="hidden" name="wpr_admin_action" value="save_settings">';
		echo '<table class="form-table"><tbody>';

		echo '<tr><th><label for="wpr_local_adapter_enabled">' . esc_html__( 'Enabled', 'wp-reconnaissance' ) . '</label></th><td><input type="checkbox" id="wpr_local_adapter_enabled" name="local_adapter_enabled" value="1"' . checked( (bool) get_option( 'wpr_local_adapter_enabled', false ), true, false ) . '></td></tr>';
		echo '<tr><th><label for="wpr_php_binary_path">' . esc_html__( 'PHP CLI binary path', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_php_binary_path" name="php_binary_path" value="' . esc_attr( (string) get_option( 'wpr_php_binary_path', '' ) ) . '" class="regular-text" placeholder="/usr/bin/php"></td></tr>';
		echo '<tr><th><label for="wpr_worker_script_path">' . esc_html__( 'Worker script path', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_worker_script_path" name="worker_script_path" value="' . esc_attr( (string) get_option( 'wpr_worker_script_path', '' ) ) . '" class="regular-text" placeholder="/path/to/worker/collect.php"></td></tr>';
		echo '<tr><th><label for="wpr_worker_work_dir">' . esc_html__( 'Working directory', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_worker_work_dir" name="worker_work_dir" value="' . esc_attr( (string) get_option( 'wpr_worker_work_dir', '' ) ) . '" class="regular-text" placeholder="' . esc_attr( sys_get_temp_dir() ) . '"></td></tr>';
		echo '<tr><th><label for="wpr_worker_max_execution_seconds">' . esc_html__( 'Max execution seconds', 'wp-reconnaissance' ) . '</label></th><td><input type="number" id="wpr_worker_max_execution_seconds" name="worker_max_execution_seconds" value="' . esc_attr( (string) get_option( 'wpr_worker_max_execution_seconds', 120 ) ) . '" min="1" max="600"></td></tr>';
		echo '<tr><th><label for="wpr_worker_max_output_bytes">' . esc_html__( 'Max output bytes', 'wp-reconnaissance' ) . '</label></th><td><input type="number" id="wpr_worker_max_output_bytes" name="worker_max_output_bytes" value="' . esc_attr( (string) get_option( 'wpr_worker_max_output_bytes', 10 * 1024 * 1024 ) ) . '" min="1"></td></tr>';
		echo '</tbody></table>';
		submit_button( __( 'Save settings', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Anti-abuse controls', 'wp-reconnaissance' ) . '</h2>';
		echo '<p>' . esc_html__( 'Section 5.6 layered controls applied to registration and free assessments. A value of 0 for the maximum queued jobs disables that throttle.', 'wp-reconnaissance' ) . '</p>';

		echo '<form method="post">';
		wp_nonce_field( 'wpr_save_settings' );
		echo '<input type="hidden" name="wpr_admin_action" value="save_settings">';
		echo '<table class="form-table"><tbody>';

		echo '<tr><th><label for="wpr_abuse_captcha_enabled">' . esc_html__( 'Enable bot challenge', 'wp-reconnaissance' ) . '</label></th><td><input type="checkbox" id="wpr_abuse_captcha_enabled" name="abuse_captcha_enabled" value="1"' . checked( (bool) get_option( 'wpr_abuse_captcha_enabled', false ), true, false ) . '> <span class="description">' . esc_html__( 'Adds a hidden honeypot and minimum-form-fill-time check to the registration form.', 'wp-reconnaissance' ) . '</span></td></tr>';
		echo '<tr><th><label for="wpr_abuse_min_form_seconds">' . esc_html__( 'Minimum form fill time (seconds)', 'wp-reconnaissance' ) . '</label></th><td><input type="number" id="wpr_abuse_min_form_seconds" name="abuse_min_form_seconds" value="' . esc_attr( (string) get_option( 'wpr_abuse_min_form_seconds', 3 ) ) . '" min="0" max="60"></td></tr>';
		echo '<tr><th><label for="wpr_abuse_max_queued_jobs">' . esc_html__( 'Maximum queued jobs', 'wp-reconnaissance' ) . '</label></th><td><input type="number" id="wpr_abuse_max_queued_jobs" name="abuse_max_queued_jobs" value="' . esc_attr( (string) get_option( 'wpr_abuse_max_queued_jobs', 0 ) ) . '" min="0"> <span class="description">' . esc_html__( 'Hold new free assessments for review when the job backlog reaches this count.', 'wp-reconnaissance' ) . '</span></td></tr>';

		echo '</tbody></table>';
		submit_button( __( 'Save anti-abuse settings', 'wp-reconnaissance' ) );
		echo '</form>';

		$this->render_mail_provider_section();
		$this->render_crm_integration_section();

		echo '</div>';
	}

	/**
	 * Section 33's CRM/service-account integration: read-only REST access for an external system
	 * (e.g. HaloPSA) that calls in periodically to pull contacts, domains/config and reports.
	 * There is nothing to save here - no new credentials this plugin stores or manages - only
	 * documentation of the already-working mechanism (a WordPress Application Password against a
	 * dedicated {@see \Alltime\WPReconnaissance\Support\Roles::INTEGRATION_ROLE} account) and a
	 * live check that the site actually supports it.
	 */
	private function render_crm_integration_section(): void {
		if ( ! current_user_can( Capabilities::MANAGE_INTEGRATIONS ) ) {
			return;
		}

		echo '<h2>' . esc_html__( 'CRM / integration access', 'wp-reconnaissance' ) . '</h2>';

		if ( ! wp_is_application_passwords_available() ) {
			echo '<p>' . esc_html__( 'Application Passwords are not available on this site, so no external system can authenticate against the REST API yet. Check for a plugin or filter disabling them, and that the site is served over HTTPS.', 'wp-reconnaissance' ) . '</p></div>';
			return;
		}

		$new_user_url  = admin_url( 'user-new.php' );
		$users_url     = add_query_arg( 'role', Roles::INTEGRATION_ROLE, admin_url( 'users.php' ) );
		$rest_base_url = rest_url( RestBootstrap::NAMESPACE_V1 );

		echo '<p>' . esc_html__( 'To let an external system such as a CRM or PSA pull data from this site, create a WordPress user with the "Reconnaissance Integration" role (read-only - it cannot create, authorise or change anything), then have that user generate an Application Password from their own profile screen and give it to the external system.', 'wp-reconnaissance' ) . '</p>';
		echo '<p><a href="' . esc_url( $new_user_url ) . '" class="button">' . esc_html__( 'Create a new user', 'wp-reconnaissance' ) . '</a> <a href="' . esc_url( $users_url ) . '" class="button">' . esc_html__( 'View existing integration accounts', 'wp-reconnaissance' ) . '</a></p>';
		echo '<p>' . esc_html__( 'The external system authenticates with HTTP Basic Auth (the account\'s username plus the generated application password) against this base URL and its sub-routes, e.g. /organisations, /organisations/{id}/contacts, /organisations/{id}/scopes and /scopes/{id}/reports:', 'wp-reconnaissance' ) . '</p>';
		echo '<p><code>' . esc_html( $rest_base_url ) . '</code></p>';
	}

	/**
	 * Mail-provider selection and credentials (Section 22). The active provider setting applies
	 * to new queued messages; messages already submitted retain their provider identity.
	 * Secret fields (Gmail refresh token, SES secret access key) are never echoed back after
	 * they have been saved - the field is left blank and a placeholder notes the stored state.
	 */
	private function render_mail_provider_section(): void {
		$active_id = (string) get_option( 'wpr_mail_provider', '' );

		echo '<h2>' . esc_html__( 'Mail provider', 'wp-reconnaissance' ) . '</h2>';
		echo '<p>' . esc_html__( 'Select the transactional mail provider and enter its credentials (Section 22).', 'wp-reconnaissance' ) . '</p>';

		echo '<form method="post">';
		wp_nonce_field( 'wpr_save_mail_provider' );
		echo '<input type="hidden" name="wpr_admin_action" value="save_mail_provider">';
		echo '<table class="form-table"><tbody>';

		echo '<tr><th><label for="wpr_mail_provider">' . esc_html__( 'Active provider', 'wp-reconnaissance' ) . '</label></th><td><select id="wpr_mail_provider" name="mail_provider">'
			. '<option value=""' . selected( $active_id, '', false ) . '>' . esc_html__( 'None', 'wp-reconnaissance' ) . '</option>'
			. '<option value="gmail_api"' . selected( $active_id, 'gmail_api', false ) . '>' . esc_html__( 'Gmail API', 'wp-reconnaissance' ) . '</option>'
			. '<option value="amazon_ses"' . selected( $active_id, 'amazon_ses', false ) . '>' . esc_html__( 'Amazon SES', 'wp-reconnaissance' ) . '</option>'
			. '</select></td></tr>';

		echo '<tr><th colspan="2"><strong>' . esc_html__( 'Gmail API', 'wp-reconnaissance' ) . '</strong></th></tr>';
		echo '<tr><th><label for="wpr_gmail_oauth_client_id">' . esc_html__( 'OAuth client ID', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_gmail_oauth_client_id" name="gmail_oauth_client_id" value="' . esc_attr( (string) get_option( 'wpr_gmail_oauth_client_id', '' ) ) . '" class="regular-text"></td></tr>';
		echo '<tr><th><label for="wpr_gmail_oauth_client_secret">' . esc_html__( 'OAuth client secret', 'wp-reconnaissance' ) . '</label></th><td><input type="password" id="wpr_gmail_oauth_client_secret" name="gmail_oauth_client_secret" value="" class="regular-text" placeholder="' . $this->secret_placeholder( 'wpr_gmail_oauth_client_secret' ) . '"></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- secret_placeholder() returns an esc_attr__()-escaped string.
		echo '<tr><th><label for="wpr_gmail_sender_address">' . esc_html__( 'Authorised sender mailbox', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_gmail_sender_address" name="gmail_sender_address" value="' . esc_attr( (string) get_option( 'wpr_gmail_sender_address', '' ) ) . '" class="regular-text"></td></tr>';
		echo '<tr><th><label for="wpr_gmail_refresh_token">' . esc_html__( 'Refresh token', 'wp-reconnaissance' ) . '</label></th><td><input type="password" id="wpr_gmail_refresh_token" name="gmail_refresh_token" value="" class="regular-text" placeholder="' . $this->secret_placeholder( 'wpr_gmail_refresh_token' ) . '"></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- secret_placeholder() returns an esc_attr__()-escaped string.

		echo '<tr><th colspan="2"><strong>' . esc_html__( 'Amazon SES', 'wp-reconnaissance' ) . '</strong></th></tr>';
		echo '<tr><th><label for="wpr_ses_region">' . esc_html__( 'Region', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_ses_region" name="ses_region" value="' . esc_attr( (string) get_option( 'wpr_ses_region', '' ) ) . '" class="regular-text" placeholder="eu-west-1"></td></tr>';
		echo '<tr><th><label for="wpr_ses_access_key_id">' . esc_html__( 'Access key ID', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_ses_access_key_id" name="ses_access_key_id" value="' . esc_attr( (string) get_option( 'wpr_ses_access_key_id', '' ) ) . '" class="regular-text"></td></tr>';
		echo '<tr><th><label for="wpr_ses_secret_access_key">' . esc_html__( 'Secret access key', 'wp-reconnaissance' ) . '</label></th><td><input type="password" id="wpr_ses_secret_access_key" name="ses_secret_access_key" value="" class="regular-text" placeholder="' . $this->secret_placeholder( 'wpr_ses_secret_access_key' ) . '"></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- secret_placeholder() returns an esc_attr__()-escaped string.
		echo '<tr><th><label for="wpr_ses_sender_address">' . esc_html__( 'Verified sender identity', 'wp-reconnaissance' ) . '</label></th><td><input type="text" id="wpr_ses_sender_address" name="ses_sender_address" value="' . esc_attr( (string) get_option( 'wpr_ses_sender_address', '' ) ) . '" class="regular-text"></td></tr>';

		echo '</tbody></table>';
		submit_button( __( 'Save mail provider', 'wp-reconnaissance' ) );
		echo '</form>';

		echo '<form method="post" style="margin-top:1em;">';
		wp_nonce_field( 'wpr_test_mail_provider' );
		echo '<input type="hidden" name="wpr_admin_action" value="test_mail_provider">';
		echo '<p>' . esc_html__( 'Send a test message to your own address using the currently saved provider and credentials.', 'wp-reconnaissance' ) . '</p>';
		submit_button( __( 'Send test message', 'wp-reconnaissance' ), 'secondary' );
		echo '</form>';
	}

	/**
	 * Placeholder text for a secret field that must not be echoed back after it has been saved.
	 */
	private function secret_placeholder( string $option ): string {
		return '' !== (string) get_option( $option, '' )
			? esc_attr__( 'Stored - leave blank to keep', 'wp-reconnaissance' )
			: '';
	}

	private function handle_save_settings(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) || ! $this->verify_nonce( 'wpr_save_settings' ) ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		update_option( 'wpr_local_adapter_enabled', isset( $_POST['local_adapter_enabled'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		update_option( 'wpr_php_binary_path', isset( $_POST['php_binary_path'] ) ? sanitize_text_field( wp_unslash( $_POST['php_binary_path'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		update_option( 'wpr_worker_script_path', isset( $_POST['worker_script_path'] ) ? sanitize_text_field( wp_unslash( $_POST['worker_script_path'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		update_option( 'wpr_worker_work_dir', isset( $_POST['worker_work_dir'] ) ? sanitize_text_field( wp_unslash( $_POST['worker_work_dir'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		update_option( 'wpr_worker_max_execution_seconds', isset( $_POST['worker_max_execution_seconds'] ) ? max( 1, (int) $_POST['worker_max_execution_seconds'] ) : 120 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		update_option( 'wpr_worker_max_output_bytes', isset( $_POST['worker_max_output_bytes'] ) ? max( 1, (int) $_POST['worker_max_output_bytes'] ) : 10 * 1024 * 1024 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		// Anti-abuse controls (Section 5.6).
		update_option( 'wpr_abuse_captcha_enabled', isset( $_POST['abuse_captcha_enabled'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		update_option( 'wpr_abuse_min_form_seconds', isset( $_POST['abuse_min_form_seconds'] ) ? max( 0, min( 60, (int) $_POST['abuse_min_form_seconds'] ) ) : 3 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
		update_option( 'wpr_abuse_max_queued_jobs', isset( $_POST['abuse_max_queued_jobs'] ) ? max( 0, (int) $_POST['abuse_max_queued_jobs'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().

		$this->audit_logger->log( 'settings.updated', 'settings', null, get_current_user_id() );
		$this->redirect_with_notice( 'settings', 'success', __( 'Settings saved.', 'wp-reconnaissance' ) );
	}

	private function handle_save_mail_provider(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) || ! $this->verify_nonce( 'wpr_save_mail_provider' ) ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$provider = sanitize_key( $this->post_field( 'mail_provider' ) );
		if ( ! in_array( $provider, array( '', 'gmail_api', 'amazon_ses' ), true ) ) {
			$provider = '';
		}
		update_option( 'wpr_mail_provider', $provider );

		// Gmail API credentials (Section 22.2). Secret fields are only overwritten when a new
		// value is supplied, so a blank field preserves the stored secret.
		update_option( 'wpr_gmail_oauth_client_id', $this->post_field( 'gmail_oauth_client_id' ) );
		update_option( 'wpr_gmail_sender_address', $this->post_field( 'gmail_sender_address' ) );
		$gmail_secret = $this->post_field( 'gmail_oauth_client_secret' );
		if ( '' !== $gmail_secret ) {
			update_option( 'wpr_gmail_oauth_client_secret', $gmail_secret );
		}
		$gmail_refresh = $this->post_field( 'gmail_refresh_token' );
		if ( '' !== $gmail_refresh ) {
			update_option( 'wpr_gmail_refresh_token', $gmail_refresh );
		}

		// Amazon SES credentials (Section 22.3).
		update_option( 'wpr_ses_region', $this->post_field( 'ses_region' ) );
		update_option( 'wpr_ses_access_key_id', $this->post_field( 'ses_access_key_id' ) );
		update_option( 'wpr_ses_sender_address', $this->post_field( 'ses_sender_address' ) );
		$ses_secret = $this->post_field( 'ses_secret_access_key' );
		if ( '' !== $ses_secret ) {
			update_option( 'wpr_ses_secret_access_key', $ses_secret );
		}

		$this->audit_logger->log( 'mail_provider.updated', 'settings', null, get_current_user_id() );

		$errors = $this->mail_manager->active_provider()?->validate_configuration() ?? array();
		if ( array() !== $errors ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'Mail provider saved, but its configuration is incomplete: ', 'wp-reconnaissance' ) . implode( ' ', $errors ) );
		}

		$this->redirect_with_notice( 'settings', 'success', __( 'Mail provider saved.', 'wp-reconnaissance' ) );
	}

	private function handle_test_mail_provider(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) || ! $this->verify_nonce( 'wpr_test_mail_provider' ) ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$provider = $this->mail_manager->active_provider();

		if ( null === $provider ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'No active mail provider is configured.', 'wp-reconnaissance' ) );
		}

		$errors = $provider->validate_configuration();
		if ( array() !== $errors ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'Cannot send a test message - configuration is incomplete: ', 'wp-reconnaissance' ) . implode( ' ', $errors ) );
		}

		$user      = wp_get_current_user();
		$recipient = is_email( $user->user_email ) ? $user->user_email : '';

		if ( '' === $recipient ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'Your account has no valid email address to send the test message to.', 'wp-reconnaissance' ) );
		}

		try {
			$provider->send(
				new QueuedMessage(
					'test-' . wp_generate_uuid4(),
					$recipient,
					'test',
					MailPurpose::ServiceDelivery,
					__( 'WP-Reconnaissance test message', 'wp-reconnaissance' ),
					'<p>' . esc_html__( 'This is a test message from WP-Reconnaissance.', 'wp-reconnaissance' ) . '</p>'
				)
			);
		} catch ( MailDeliveryException $exception ) {
			$this->redirect_with_notice( 'settings', 'error', __( 'Test message failed: ', 'wp-reconnaissance' ) . $exception->getMessage() );
		}

		$this->redirect_with_notice( 'settings', 'success', __( 'Test message sent.', 'wp-reconnaissance' ) );
	}

	// -----------------------------------------------------------------------------------
	// Contact merge (Section 18.1.4)
	// -----------------------------------------------------------------------------------

	public function render_contact_merge(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CONTACT_MERGE ) ) {
			wp_die( esc_html__( 'You do not have permission to review contact merges.', 'wp-reconnaissance' ) );
		}

		$merge_service = new ContactMergeService();
		$merge_log     = new ContactMergeLogRepository();
		$contacts      = new ContactRepository();

		echo '<div class="wrap"><h1>' . esc_html__( 'Contact merge', 'wp-reconnaissance' ) . '</h1>';

		$candidates = $merge_service->find_duplicate_candidates();

		echo '<h2>' . esc_html__( 'Duplicate candidates', 'wp-reconnaissance' ) . '</h2>';
		if ( array() === $candidates ) {
			echo '<p>' . esc_html__( 'No contacts currently share an email identity.', 'wp-reconnaissance' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Email', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Contact', 'wp-reconnaissance' ) . '</th></tr></thead><tbody>';
			foreach ( $candidates as $candidate ) {
				$contact = $contacts->find( $candidate['contact_id'] );
				echo '<tr><td>' . esc_html( $candidate['email'] ) . '</td><td>'
					. ( null !== $contact ? esc_html( $contact->given_name . ' ' . $contact->family_name ) . ' (#' . (int) $contact->id . ')' : '#' . (int) $candidate['contact_id'] )
					. '</td></tr>';
			}
			echo '</tbody></table>';
		}

		echo '<h2>' . esc_html__( 'Pending review', 'wp-reconnaissance' ) . '</h2>';
		$pending = $merge_log->find_pending_review();
		if ( array() === $pending ) {
			echo '<p>' . esc_html__( 'No merges awaiting review.', 'wp-reconnaissance' ) . '</p>';
		} else {
			foreach ( $pending as $entry ) {
				$candidate_ids = array_filter( array_map( 'intval', explode( ',', (string) $entry['candidate_contact_ids'] ) ) );
				echo '<div style="border:1px solid #ccd0d4;padding:1em;margin-bottom:1em;">';
				echo '<p><strong>' . esc_html__( 'Source', 'wp-reconnaissance' ) . ':</strong> ' . esc_html( (string) $entry['source'] ) . '</p>';
				echo '<p><strong>' . esc_html__( 'Candidates', 'wp-reconnaissance' ) . ':</strong> ' . esc_html( implode( ', ', $candidate_ids ) ) . '</p>';
				if ( ! empty( $entry['reason'] ) ) {
					echo '<p><strong>' . esc_html__( 'Reason', 'wp-reconnaissance' ) . ':</strong> ' . esc_html( (string) $entry['reason'] ) . '</p>';
				}
				echo '<form method="post" style="display:inline;">';
				wp_nonce_field( 'wpr_approve_contact_merge' );
				echo '<input type="hidden" name="wpr_admin_action" value="approve_contact_merge">';
				echo '<input type="hidden" name="merge_log_id" value="' . esc_attr( (string) $entry['id'] ) . '">';
				echo '<p><label>' . esc_html__( 'Surviving contact ID', 'wp-reconnaissance' ) . ' <input type="number" name="surviving_contact_id" required></label></p>';
				echo '<p><label>' . esc_html__( 'Merged contact ID', 'wp-reconnaissance' ) . ' <input type="number" name="merged_contact_id" required></label></p>';
				echo '<p><label>' . esc_html__( 'Reason', 'wp-reconnaissance' ) . ' <input type="text" name="reason" class="regular-text" required></label></p>';
				submit_button( __( 'Approve merge', 'wp-reconnaissance' ), 'primary', 'submit', false );
				echo '</form>';
				echo '<form method="post" style="display:inline;">';
				wp_nonce_field( 'wpr_reject_contact_merge' );
				echo '<input type="hidden" name="wpr_admin_action" value="reject_contact_merge">';
				echo '<input type="hidden" name="merge_log_id" value="' . esc_attr( (string) $entry['id'] ) . '">';
				echo '<p><label>' . esc_html__( 'Reason', 'wp-reconnaissance' ) . ' <input type="text" name="reason" class="regular-text" required></label></p>';
				submit_button( __( 'Reject', 'wp-reconnaissance' ), 'secondary', 'submit', false );
				echo '</form>';
				echo '</div>';
			}
		}

		echo '<h2>' . esc_html__( 'Completed', 'wp-reconnaissance' ) . '</h2>';
		$completed = $merge_log->find_completed();
		if ( array() === $completed ) {
			echo '<p>' . esc_html__( 'No completed merges.', 'wp-reconnaissance' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'ID', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Surviving', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Merged', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Reason', 'wp-reconnaissance' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $completed as $entry ) {
				echo '<tr><td>' . (int) $entry['id'] . '</td><td>' . esc_html( (string) $entry['status'] ) . '</td><td>' . ( null !== $entry['surviving_contact_id'] ? (int) $entry['surviving_contact_id'] : '-' ) . '</td><td>' . ( null !== $entry['merged_contact_id'] ? (int) $entry['merged_contact_id'] : '-' ) . '</td><td>' . esc_html( (string) $entry['reason'] ) . '</td><td>';
				if ( 'approved' === (string) $entry['status'] ) {
					echo '<form method="post">';
					wp_nonce_field( 'wpr_revert_contact_merge' );
					echo '<input type="hidden" name="wpr_admin_action" value="revert_contact_merge">';
					echo '<input type="hidden" name="merge_log_id" value="' . esc_attr( (string) $entry['id'] ) . '">';
					echo '<input type="hidden" name="reason" value="' . esc_attr__( 'Reverted by administrator', 'wp-reconnaissance' ) . '">';
					submit_button( __( 'Revert', 'wp-reconnaissance' ), 'secondary', 'submit', false );
					echo '</form>';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}

		echo '</div>';
	}

	private function handle_approve_contact_merge(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CONTACT_MERGE ) || ! $this->verify_nonce( 'wpr_approve_contact_merge' ) ) {
			$this->redirect_with_notice( 'contact-merge', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$surviving = (int) $this->post_field( 'surviving_contact_id' );
		$merged    = (int) $this->post_field( 'merged_contact_id' );
		$reason    = $this->post_field( 'reason' );

		try {
			( new ContactMergeService() )->merge( $surviving, $merged, get_current_user_id(), $reason );
		} catch ( \InvalidArgumentException $exception ) {
			$this->redirect_with_notice( 'contact-merge', 'error', $exception->getMessage() );
		}

		$this->redirect_with_notice( 'contact-merge', 'success', __( 'Contacts merged.', 'wp-reconnaissance' ) );
	}

	private function handle_reject_contact_merge(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CONTACT_MERGE ) || ! $this->verify_nonce( 'wpr_reject_contact_merge' ) ) {
			$this->redirect_with_notice( 'contact-merge', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$log_id = (int) $this->post_field( 'merge_log_id' );
		$reason = $this->post_field( 'reason' );

		( new ContactMergeLogRepository() )->mark_rejected( $log_id, get_current_user_id(), $reason );

		$this->redirect_with_notice( 'contact-merge', 'success', __( 'Merge rejected.', 'wp-reconnaissance' ) );
	}

	private function handle_revert_contact_merge(): void {
		if ( ! current_user_can( Capabilities::MANAGE_CONTACT_MERGE ) || ! $this->verify_nonce( 'wpr_revert_contact_merge' ) ) {
			$this->redirect_with_notice( 'contact-merge', 'error', __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$log_id = (int) $this->post_field( 'merge_log_id' );
		$reason = $this->post_field( 'reason' );

		( new ContactMergeService() )->revert( $log_id, get_current_user_id(), $reason );

		$this->redirect_with_notice( 'contact-merge', 'success', __( 'Merge reverted.', 'wp-reconnaissance' ) );
	}

	// -----------------------------------------------------------------------------------
	// Shared helpers
	// -----------------------------------------------------------------------------------

	/**
	 * Deliberately uses {@see wp_verify_nonce()} rather than {@see check_admin_referer()}: the
	 * latter calls wp_nonce_ays()/die() on failure, which would bypass every
	 * redirect_with_notice() call below and show WordPress's generic "Are you sure?" page
	 * instead of this screen's own error message.
	 */
	private function verify_nonce( string $action ): bool {
		$nonce = isset( $_POST['_wpnonce'] ) && is_string( $_POST['_wpnonce'] ) ? wp_unslash( $_POST['_wpnonce'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- this *is* the nonce verification helper.

		return '' !== $nonce && false !== wp_verify_nonce( $nonce, $action );
	}

	private function post_field( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified by the caller before any $_POST field is read.
		return isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : '';
	}

	private function render_notices(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flash-message display; the action that set it already verified its own nonce.
		if ( ! isset( $_GET['wpr_notice'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flash-message display.
		$type = 'error' === $_GET['wpr_notice'] ? 'error' : 'success';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flash-message display.
		$message = isset( $_GET['wpr_message'] ) ? sanitize_text_field( wp_unslash( $_GET['wpr_message'] ) ) : '';

		if ( '' === $message ) {
			return;
		}

		printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $type ), esc_html( $message ) );
	}

	/**
	 * Redirects back to the given admin screen with a flash notice, then terminates the request.
	 * Every caller is inside {@see handle_form_submissions()} (an `admin_init` callback), so no
	 * output has been sent yet.
	 */
	private function redirect_with_notice( string $screen_slug, string $type, string $message ): never {
		$url = add_query_arg(
			array(
				'page'        => self::MENU_SLUG . '-' . $screen_slug,
				'wpr_notice'  => $type,
				'wpr_message' => rawurlencode( $message ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
