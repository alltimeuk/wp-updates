<?php
/**
 * `wp reconnaissance scope ...`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ProfileRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\DomainValidator;
use Alltime\WPReconnaissance\Domain\Exceptions\InvalidDomainException;
use Alltime\WPReconnaissance\Rules\BaselineCaptureException;
use Alltime\WPReconnaissance\Rules\BaselineCaptureService;

final class ScopeCommand {

	/**
	 * Adds an authorised scope.
	 *
	 * ## OPTIONS
	 *
	 * --organisation=<name>
	 * : Name of the organisation. Created if it does not already exist.
	 *
	 * --domain=<domain>
	 * : The domain to assess.
	 *
	 * [--authorise]
	 * : Immediately authorise the scope for collection.
	 *
	 * [--reference=<reference>]
	 * : Authorisation reference or document identifier. Required with --authorise.
	 *
	 * [--collectors=<list>]
	 * : Comma-separated collector list. Defaults to the full core set.
	 *
	 * @param string[]             $args
	 * @param array<string,string> $assoc_args
	 */
	public function add( array $args, array $assoc_args ): void {
		if ( empty( $assoc_args['organisation'] ) || empty( $assoc_args['domain'] ) ) {
			\WP_CLI::error( 'Both --organisation=<name> and --domain=<domain> are required.' );
			return;
		}

		if ( isset( $assoc_args['authorise'] ) && empty( $assoc_args['reference'] ) ) {
			\WP_CLI::error( '--reference=<reference> is required when using --authorise.' );
			return;
		}

		try {
			$validated = ( new DomainValidator() )->validate( (string) $assoc_args['domain'] );
		} catch ( InvalidDomainException $exception ) {
			\WP_CLI::error( "Invalid domain: {$exception->getMessage()}" );
			return;
		}

		$organisation_repository = new OrganisationRepository();
		$organisation            = $organisation_repository->find_by_slug( sanitize_title( (string) $assoc_args['organisation'] ) );

		if ( null === $organisation ) {
			$organisation = $organisation_repository->create(
				(string) $assoc_args['organisation'],
				$organisation_repository->unique_slug( (string) $assoc_args['organisation'] )
			);
		}

		$profile    = ( new ProfileRepository() )->find_or_create_default();
		$collectors = isset( $assoc_args['collectors'] )
			? array_map( 'trim', explode( ',', (string) $assoc_args['collectors'] ) )
			: $profile->enabled_collectors;

		$scope_repository = new ScopeRepository();
		$scope            = $scope_repository->create(
			(int) $organisation->id,
			$validated->display,
			$validated->ascii,
			$validated->display,
			$validated->registrable,
			$collectors,
			$profile->id
		);

		if ( isset( $assoc_args['authorise'] ) ) {
			$scope = $scope_repository->authorise( (int) $scope->id, get_current_user_id(), (string) $assoc_args['reference'] );
		}

		\WP_CLI::success( "Created scope #{$scope->id} for {$validated->display} (organisation #{$organisation->id}), authorisation_status={$scope->authorisation_status}." );
	}

	/**
	 * Lists scopes for an organisation.
	 *
	 * ## OPTIONS
	 *
	 * --organisation-id=<id>
	 * : Numeric organisation ID.
	 *
	 * @param array<string,string> $assoc_args
	 */
	public function list( array $args = array(), array $assoc_args = array() ): void {
		if ( empty( $assoc_args['organisation-id'] ) ) {
			\WP_CLI::error( 'Usage: wp reconnaissance scope list --organisation-id=<id>' );
			return;
		}

		$scopes = ( new ScopeRepository() )->find_by_organisation( (int) $assoc_args['organisation-id'] );

		if ( array() === $scopes ) {
			\WP_CLI::log( 'No scopes found.' );
			return;
		}

		\WP_CLI\Utils\format_items(
			'table',
			array_map(
				static fn ( $scope ): array => array(
					'id'                   => (string) $scope->id,
					'domain'               => $scope->domain_display,
					'status'               => $scope->status,
					'authorisation_status' => $scope->authorisation_status,
				),
				$scopes
			),
			array( 'id', 'domain', 'status', 'authorisation_status' )
		);
	}

	/**
	 * Adopts a scope's most recently observed nameservers/MX/TLS issuer as its baseline (Section
	 * 33) - the same action the admin "Adopt current state as baseline" button performs.
	 *
	 * ## OPTIONS
	 *
	 * --scope-id=<id>
	 * : Numeric scope ID.
	 *
	 * @param array<string,string> $assoc_args
	 */
	public function capture_baseline( array $args = array(), array $assoc_args = array() ): void {
		if ( empty( $assoc_args['scope-id'] ) ) {
			\WP_CLI::error( 'Usage: wp reconnaissance scope capture-baseline --scope-id=<id>' );
			return;
		}

		try {
			( new BaselineCaptureService() )->capture_from_latest_observation( (int) $assoc_args['scope-id'] );
		} catch ( BaselineCaptureException $exception ) {
			\WP_CLI::error( $exception->getMessage() );
			return;
		}

		\WP_CLI::success( 'Current state adopted as the baseline.' );
	}
}
