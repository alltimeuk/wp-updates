<?php
/**
 * Persistence for entitlements against `wpr_entitlements`, per Section 5.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Entitlements\Enums\EntitlementState;

final class EntitlementRepository {

	public function find( int $id ): ?Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Entitlement::from_row( $row ) : null;
	}

	/**
	 * @return Entitlement[] Most recent first.
	 */
	public function find_history( int $contact_id, string $tool_id, string $registrable_domain ): array {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE contact_id = %d AND tool_id = %s AND registrable_domain = %s ORDER BY id DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$contact_id,
				$tool_id,
				$registrable_domain
			),
			ARRAY_A
		);

		return array_map( array( Entitlement::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * The single open (Reserved) entitlement for a contact/tool/domain, if any -
	 * {@see \Alltime\WPReconnaissance\Entitlements\EntitlementPolicy} guarantees at most one can
	 * exist at a time, since a second {@see reserve()} attempt is blocked while one is open. Used
	 * by {@see \Alltime\WPReconnaissance\Entitlements\EntitlementFulfillment} to find the
	 * reservation a completed job should consume or release.
	 */
	public function find_open_reservation( int $contact_id, string $tool_id, string $registrable_domain ): ?Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE contact_id = %d AND tool_id = %s AND registrable_domain = %s AND state = %s ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$contact_id,
				$tool_id,
				$registrable_domain,
				EntitlementState::Reserved->value
			),
			ARRAY_A
		);

		return null !== $row ? Entitlement::from_row( $row ) : null;
	}

	public function reserve( int $contact_id, string $tool_id, string $registrable_domain ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'         => $contact_id,
				'tool_id'            => $tool_id,
				'registrable_domain' => $registrable_domain,
				'state'              => EntitlementState::Reserved->value,
				'reserved_at'        => $now,
				'created_at'         => $now,
				'updated_at'         => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function consume( int $id ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'state'       => EntitlementState::Consumed->value,
				'consumed_at' => current_time( 'mysql', true ),
				'updated_at'  => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	/**
	 * Deletes a reservation outright rather than transitioning it to some "released" state -
	 * Section 5.5: "Do not consume the entitlement for a validation failure or a job that
	 * produces no usable assessment"; a released reservation must leave no trace that would
	 * block the next genuine attempt.
	 */
	public function release( int $id ): void {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$wpdb->delete(
			$table,
			array(
				'id'    => $id,
				'state' => EntitlementState::Reserved->value,
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public function grant( int $contact_id, string $tool_id, string $registrable_domain, int $granted_by, ?string $reason, ?\DateTimeImmutable $expires_at ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'         => $contact_id,
				'tool_id'            => $tool_id,
				'registrable_domain' => $registrable_domain,
				'state'              => EntitlementState::AdministrativelyGranted->value,
				'granted_by'         => $granted_by,
				'reason'             => $reason,
				'expires_at'         => $expires_at?->format( 'Y-m-d H:i:s' ),
				'created_at'         => $now,
				'updated_at'         => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function revoke( int $id ): Entitlement {
		global $wpdb;

		$table = Schema::table( 'entitlements' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'state'      => EntitlementState::Revoked->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): Entitlement {
		$entitlement = $this->find( $id );

		if ( null === $entitlement ) {
			throw new \RuntimeException( esc_html( "Entitlement {$id} was expected to exist but could not be loaded." ) );
		}

		return $entitlement;
	}
}
