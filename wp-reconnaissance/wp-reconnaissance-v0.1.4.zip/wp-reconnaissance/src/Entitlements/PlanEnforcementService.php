<?php
/**
 * Enforces a managed plan's limits (Section 33 "repeat, paid and managed-service entitlements")
 * at the points they actually matter - an organisation with no assigned plan is unrestricted,
 * exactly like today.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;

final class PlanEnforcementService {

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly PlanRepository $plans = new PlanRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository()
	) {}

	/**
	 * A scope only ever counts against a plan's `max_active_scopes` once it is authorised
	 * (status `active`) - a customer may still request/create as many pending scopes as they
	 * like, since nothing runs against them until an operator authorises one. This is therefore
	 * checked at authorisation time, not creation time.
	 *
	 * @throws PlanLimitException When authorising this scope would exceed the organisation's plan.
	 */
	public function assert_can_authorise_scope( int $organisation_id ): void {
		$plan = $this->plan_for_organisation( $organisation_id );

		if ( null === $plan || null === $plan->max_active_scopes ) {
			return;
		}

		if ( $this->scopes->count_active_by_organisation( $organisation_id ) >= $plan->max_active_scopes ) {
			throw new PlanLimitException(
				esc_html(
					sprintf(
						/* translators: %d: maximum active scopes the organisation's plan allows */
						__( 'This organisation\'s plan allows at most %d active scope(s). Authorising this one would exceed that limit.', 'wp-reconnaissance' ),
						$plan->max_active_scopes
					)
				)
			);
		}
	}

	private function plan_for_organisation( int $organisation_id ): ?Plan {
		$plan_id = $this->organisations->find( $organisation_id )?->plan_id;

		return null !== $plan_id ? $this->plans->find( $plan_id ) : null;
	}
}
