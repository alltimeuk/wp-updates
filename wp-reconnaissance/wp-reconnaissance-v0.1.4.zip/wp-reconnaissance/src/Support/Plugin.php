<?php
/**
 * Plugin bootstrap container.
 *
 * The bootstrap file only wires activation/deactivation hooks and defers everything else to
 * this class. No business logic lives here or in the plugin bootstrap file itself.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

use Alltime\CustomerPlatform\Bootstrap as CustomerPlatformBootstrap;
use Alltime\CustomerPlatform\Migrator as CustomerPlatformMigrator;
use Alltime\WPReconnaissance\Admin\AdminBootstrap;
use Alltime\WPReconnaissance\Api\RestBootstrap;
use Alltime\WPReconnaissance\Auth\AuthBootstrap;
use Alltime\WPReconnaissance\Cli\CliBootstrap;
use Alltime\WPReconnaissance\Data\Migrator;
use Alltime\WPReconnaissance\Diagnostics\DiagnosticsBootstrap;
use Alltime\WPReconnaissance\Entitlements\EntitlementFulfillment;
use Alltime\WPReconnaissance\Integrations\IntegrationsBootstrap;
use Alltime\WPReconnaissance\Privacy\PrivacyBootstrap;
use Alltime\WPReconnaissance\Rules\RulesBootstrap;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;
use Alltime\WPReconnaissance\Shortcodes\GetStartedShortcode;
use Alltime\WPReconnaissance\Tools\ToolsBootstrap;
use Alltime\WPReconnaissance\Verification\VerificationBootstrap;

use const Alltime\WPReconnaissance\WPR_PLUGIN_DIR;

/**
 * Coordinates activation, deactivation and runtime boot of the plugin's modules.
 */
final class Plugin {

	private static ?self $instance = null;

	private bool $booted = false;

	private function __construct() {}

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Runs on plugin activation: installs/upgrades the database schema, registers roles and
	 * flushes rewrite rules for the front-end customer routes. Never destroys existing data.
	 */
	public static function activate(): void {
		Migrator::install();
		CustomerPlatformMigrator::install();
		Roles::register();

		add_option( 'wpr_local_adapter_enabled', false );
		add_option( 'wpr_remove_data_on_uninstall', false );

		flush_rewrite_rules();
	}

	/**
	 * Runs on plugin deactivation. Deliberately does not remove data, tables or roles - only
	 * uninstall.php (with explicit administrator opt-in) may do that.
	 */
	public static function deactivate(): void {
		flush_rewrite_rules();
	}

	/**
	 * Boots the plugin at `plugins_loaded`. Idempotent.
	 */
	public function boot(): void {
		if ( $this->booted ) {
			return;
		}

		$this->booted = true;

		// WordPress 6.7+ raises a _load_textdomain_just_in_time notice for any
		// translation call that runs before 'init'. Role display names are this
		// boot path's one pre-init consumer of __(), so textdomain loading and
		// role (re-)registration both wait for init. Roles persist in the DB
		// after their first registration, so nothing that runs between
		// plugins_loaded and init loses sight of them; priority 0 keeps the
		// labels ready before ordinary init-priority consumers.
		add_action(
			'init',
			static function (): void {
				load_plugin_textdomain( 'wp-reconnaissance', false, dirname( plugin_basename( WPR_PLUGIN_DIR . 'wp-reconnaissance.php' ) ) . '/languages' );

				// Idempotent (see Roles::register()'s own docblock) - run on every
				// boot, not only activation, so a role or capability added in a
				// plugin update (like Section 33's wpr_integration role) reaches an
				// already-active install without requiring a deactivate/reactivate
				// cycle.
				Roles::register();
			},
			0
		);

		Migrator::maybe_upgrade();
		CustomerPlatformMigrator::maybe_upgrade();

		Roles::boot();

		// Registers the contact-service provider before any module that might resolve it -
		// notably AuthBootstrap's registration flow, further down this list.
		( new CustomerPlatformBootstrap() )->boot();

		// Visitor-context security events (Section 18.1.3) surface in the audit log.
		add_action( 'alltime_visitor_context_security_event', array( $this, 'on_visitor_context_security_event' ), 10, 3 );

		( new AdminBootstrap() )->boot();
		( new RestBootstrap() )->boot();
		( new AuthBootstrap() )->boot();
		( new CliBootstrap() )->boot();
		( new DiagnosticsBootstrap() )->boot();
		( new EntitlementFulfillment() )->boot();
		( new IntegrationsBootstrap() )->boot();
		( new PrivacyBootstrap() )->boot();
		( new RulesBootstrap() )->boot();
		( new SchedulingBootstrap() )->boot();
		( new ToolsBootstrap() )->boot();
		( new VerificationBootstrap() )->boot();
		( new GetStartedShortcode() )->boot();

		AcfCompatibility::boot();
	}

	/**
	 * Records a visitor-context security event (Section 18.1.3) in the audit log - e.g. a cookie
	 * associated with one contact being presented by an authenticated different contact.
	 */
	public function on_visitor_context_security_event( string $event_type, ?int $contact_id, string $token_hash ): void {
		( new AuditLogger() )->log(
			'visitor_context.' . sanitize_key( $event_type ),
			'visitor_context',
			$contact_id,
			get_current_user_id()
		);
	}
}
