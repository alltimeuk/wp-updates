<?php
/**
 * Fires when the plugin is deleted through the WordPress plugin screen.
 *
 * Data is preserved by default. Destructive removal only happens if an administrator has
 * explicitly opted in via the "wpr_remove_data_on_uninstall" option before deletion.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance;

use Alltime\CustomerPlatform\Migrator as CustomerPlatformMigrator;

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$wpr_autoloader = __DIR__ . '/vendor/autoload.php';

if ( ! file_exists( $wpr_autoloader ) ) {
	return;
}

require_once $wpr_autoloader;

if ( ! get_option( 'wpr_remove_data_on_uninstall', false ) ) {
	return;
}

Data\Migrator::uninstall();

// The Customer Platform (Alltime\CustomerPlatform) is delivered inside this plugin for now (see
// src/CustomerPlatform/Schema.php) - its tables are removed under the same explicit opt-in,
// never independently, since there is no separate plugin yet to own that decision.
CustomerPlatformMigrator::uninstall();
