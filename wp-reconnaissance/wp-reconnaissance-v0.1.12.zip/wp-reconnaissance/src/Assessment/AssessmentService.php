<?php
/**
 * Orchestrates one end-to-end assessment run, per Section 6.4's data flow: creates an
 * immutable job manifest, dispatches it through an execution adapter, validates and ingests the
 * returned evidence, evaluates the rule engine against it, and creates, updates or resolves
 * findings by comparing against the scope's previous state.
 *
 * This is the one place that coordinates Execution, Data\Repositories, Rules and Findings -
 * none of those modules call each other directly, so each stays independently testable.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Assessment;

use Alltime\WPReconnaissance\Data\EvidenceStorage;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\ObservationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ProfileRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Enums\ChangeSignificance;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Finding;
use Alltime\WPReconnaissance\Domain\Job;
use Alltime\WPReconnaissance\Domain\Enums\JobStatus;
use Alltime\WPReconnaissance\Domain\Observation;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Execution\Exceptions\ExecutionException;
use Alltime\WPReconnaissance\Execution\ExecutionAdapterInterface;
use Alltime\WPReconnaissance\Execution\LocalProcessAdapter;
use Alltime\WPReconnaissance\Execution\ManifestBuilder;
use Alltime\WPReconnaissance\Findings\ChangeDetector;
use Alltime\WPReconnaissance\Findings\FindingEventRepository;
use Alltime\WPReconnaissance\Findings\FindingRepository;
use Alltime\WPReconnaissance\Rules\RuleDefinition;
use Alltime\WPReconnaissance\Rules\RuleEngine;
use Alltime\WPReconnaissance\Rules\RuleLoader;
use Alltime\WPReconnaissance\Rules\RuleResult;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Support\StorageExposedException;
use Alltime\WPReconnaissance\Support\StorageUnverifiedException;
use Opis\JsonSchema\Validator;

use const Alltime\WPReconnaissance\WPR_PLUGIN_DIR;

final class AssessmentService {

	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly ProfileRepository $profiles = new ProfileRepository(),
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly ObservationRepository $observations = new ObservationRepository(),
		private readonly FindingRepository $findings = new FindingRepository(),
		private readonly FindingEventRepository $finding_events = new FindingEventRepository(),
		private readonly ChangeDetector $change_detector = new ChangeDetector(),
		private readonly ManifestBuilder $manifest_builder = new ManifestBuilder(),
		private readonly EvidenceStorage $evidence_storage = new EvidenceStorage(),
		private readonly RuleLoader $rule_loader = new RuleLoader(),
		private readonly RuleEngine $rule_engine = new RuleEngine(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly ExecutionAdapterInterface $adapter = new LocalProcessAdapter()
	) {}

	/**
	 * @throws AssessmentException When the scope itself cannot be found. Every other failure
	 *                              mode (authorisation expired, adapter not ready, dispatch
	 *                              failure, invalid evidence) is recorded on the returned Job
	 *                              rather than thrown, so the caller always gets a job to inspect.
	 */
	public function run( int $scope_id, ?int $actor_id = null ): Job {
		$scope = $this->scopes->find( $scope_id );

		if ( null === $scope ) {
			throw new AssessmentException( esc_html( "Scope {$scope_id} was not found." ) );
		}

		$profile   = null !== $scope->monitoring_profile_id ? $this->profiles->find( $scope->monitoring_profile_id ) : null;
		$profile ??= $this->profiles->find_or_create_default();

		$job_uuid = wp_generate_uuid4();
		$job      = $this->jobs->create( $job_uuid, $scope->organisation_id, $scope_id, $actor_id, 'local_process' );
		$this->audit_logger->log( 'job.requested', 'job', $job->id, $actor_id, summary: "scope #{$scope_id}" );

		try {
			$manifest = $this->manifest_builder->build( $scope, $profile, $job_uuid );
		} catch ( ExecutionException $exception ) {
			return $this->fail_job( $job, 'manifest_build_failed', $exception->getMessage(), $actor_id );
		}

		$job = $this->jobs->transition( (int) $job->id, JobStatus::Queued, array( 'manifest_hash' => hash( 'sha256', $manifest->to_json() ) ) );
		$job = $this->jobs->transition( (int) $job->id, JobStatus::Running );

		if ( ! $this->adapter->is_ready() ) {
			return $this->fail_job( $job, 'adapter_not_ready', 'No execution adapter is currently ready to run this job.', $actor_id );
		}

		try {
			$result = $this->adapter->dispatch( $manifest );
		} catch ( ExecutionException $exception ) {
			return $this->fail_job( $job, 'dispatch_failed', $exception->getMessage(), $actor_id );
		}

		if ( ! $result->accepted || null === $result->evidence_json ) {
			return $this->fail_job( $job, $result->error_category ?? 'no_evidence', $result->stderr ?? 'Worker produced no evidence document.', $actor_id, $result->exit_code );
		}

		$evidence = $this->validate_evidence( $result->evidence_json );

		if ( null === $evidence ) {
			return $this->fail_job( $job, 'evidence_schema_invalid', 'Evidence document failed schema validation.', $actor_id, $result->exit_code );
		}

		try {
			[ $job, $observation ] = $this->ingest_and_transition( $job, $scope_id, $job_uuid, $evidence, $result->evidence_json, $result->exit_code, $actor_id );
		} catch ( StorageExposedException $exception ) {
			return $this->fail_job( $job, 'evidence_storage_exposed', $exception->getMessage(), $actor_id, $result->exit_code );
		} catch ( StorageUnverifiedException $exception ) {
			return $this->fail_job( $job, 'evidence_storage_unverified', $exception->getMessage(), $actor_id, $result->exit_code );
		} catch ( \RuntimeException $exception ) {
			return $this->fail_job( $job, 'evidence_storage_failed', $exception->getMessage(), $actor_id, $result->exit_code );
		}

		// A genuine database failure persisting a finding must not violate this method's own
		// documented contract ("every other failure mode is recorded on the Job rather than
		// thrown") - the job itself already transitioned successfully above, so it stays as-is
		// and the rule-evaluation failure is only recorded in the audit log. wpr_job_completed
		// fires after this either way (success or caught failure), preserving the "fires exactly
		// once per collection-succeeding run" guarantee EntitlementFulfillment/NotificationDispatcher
		// depend on, while ensuring it never fires before findings for this run are actually
		// persisted (Section 8.6: a listener querying findings must never see a false "clean scan").
		try {
			$this->evaluate_rules( $scope, $observation, $actor_id );
		} catch ( \Throwable $exception ) {
			$this->audit_logger->log( 'job.rule_evaluation_failed', 'job', $job->id, $actor_id, outcome: 'failure', summary: $exception->getMessage() );
		}

		do_action( 'wpr_job_completed', $job->id );

		return $job;
	}

	/**
	 * @param array<string,mixed> $evidence Decoded evidence.schema.json document.
	 * @return array{0:Job,1:Observation}
	 */
	private function ingest_and_transition( Job $job, int $scope_id, string $job_uuid, array $evidence, string $evidence_json, ?int $exit_code, ?int $actor_id ): array {
		$raw_ref        = $this->evidence_storage->store( $job_uuid, $evidence_json );
		$integrity_hash = hash( 'sha256', $evidence_json );
		$collector_rows = is_array( $evidence['collectors'] ?? null ) ? $evidence['collectors'] : array();

		$collector_versions = array();
		$failed_collectors  = array();
		$succeeded_count    = 0;

		foreach ( $collector_rows as $collector_result ) {
			$collector_versions[ $collector_result['collector'] ] = $collector_result['collector_version'];

			if ( 'succeeded' === $collector_result['status'] ) {
				++$succeeded_count;
			} else {
				$failed_collectors[] = $collector_result['collector'];
			}
		}

		$collector_count   = count( $collector_rows );
		$collection_status = match ( true ) {
			$collector_count > 0 && $succeeded_count === $collector_count => 'succeeded',
			$succeeded_count > 0 => 'partially_succeeded',
			default => 'failed',
		};

		$observation = $this->observations->ingest(
			$scope_id,
			(int) $job->id,
			new \DateTimeImmutable( (string) ( $evidence['generated_at'] ?? 'now' ) ),
			$collector_versions,
			(string) ( $evidence['schema_version'] ?? '1.0.0' ),
			$collection_status,
			$raw_ref,
			is_array( $evidence['limitations'] ?? null ) ? $evidence['limitations'] : array(),
			$failed_collectors,
			$integrity_hash,
			$collector_rows
		);

		$job_status = match ( $collection_status ) {
			'succeeded' => JobStatus::Succeeded,
			'partially_succeeded' => JobStatus::PartiallySucceeded,
			default => JobStatus::Failed,
		};

		$job = $this->jobs->transition(
			(int) $job->id,
			$job_status,
			array(
				'worker_version' => $evidence['worker_version'] ?? null,
				'exit_code'      => $exit_code ?? 0,
			)
		);

		$this->audit_logger->log( 'job.completed', 'job', $job->id, $actor_id, summary: "status={$job_status->value}" );

		return array( $job, $observation );
	}

	private function evaluate_rules( Scope $scope, Observation $observation, ?int $actor_id ): void {
		$evidence_json = null !== $observation->raw_evidence_ref ? $this->evidence_storage->retrieve( $observation->raw_evidence_ref ) : null;

		if ( null === $evidence_json ) {
			return;
		}

		$evidence = json_decode( $evidence_json, true );

		if ( ! is_array( $evidence ) ) {
			return;
		}

		$rule_definitions = $this->rule_loader->load_core_rules();
		$rule_results     = $this->rule_engine->evaluate( $evidence, $scope );

		foreach ( $rule_definitions as $rule_id => $rule_definition ) {
			$current  = $rule_results[ $rule_id ] ?? null;
			$previous = $this->findings->find_latest_by_rule( (int) $scope->id, $rule_id );
			$change   = $this->change_detector->classify( $previous, $current );

			$this->apply_change( $scope, $rule_definition, $observation, $previous, $current, $change, $actor_id );
		}
	}

	private function apply_change(
		Scope $scope,
		RuleDefinition $rule,
		Observation $observation,
		?Finding $previous,
		?RuleResult $current,
		ChangeSignificance $change,
		?int $actor_id
	): void {
		$now     = new \DateTimeImmutable();
		$finding = null;

		$change_only_states = array( ChangeSignificance::Modified, ChangeSignificance::Worsened, ChangeSignificance::Improved );

		if ( ChangeSignificance::Added === $change && null !== $current ) {
			$finding = $this->upsert_active_finding( $scope, $rule, null, $current, FindingStatus::New, $now );
		} elseif ( ChangeSignificance::Reopened === $change && null !== $previous && null !== $current ) {
			$finding = $this->upsert_active_finding( $scope, $rule, $previous, $current, FindingStatus::New, $now );
		} elseif ( in_array( $change, $change_only_states, true ) && null !== $previous && null !== $current ) {
			$finding = $this->upsert_active_finding( $scope, $rule, $previous, $current, $previous->status, $now );
		} elseif ( ChangeSignificance::Unchanged === $change && null !== $previous && null !== $current ) {
			$this->upsert_active_finding( $scope, $rule, $previous, $current, $previous->status, $now );
			return;
		} elseif ( ChangeSignificance::Resolved === $change && null !== $previous ) {
			$finding = $this->resolve_finding( $previous, $now );
		}

		if ( null === $finding ) {
			return;
		}

		$event_id = $this->finding_events->record( (int) $finding->id, $observation->id, $change, $actor_id );

		if ( ChangeSignificance::Added === $change ) {
			do_action( 'wpr_finding_created', $finding->id );
			return;
		}

		do_action( 'wpr_finding_changed', $finding->id, $event_id );
	}

	private function upsert_active_finding( Scope $scope, RuleDefinition $rule, ?Finding $previous, RuleResult $current, FindingStatus $status, \DateTimeImmutable $now ): Finding {
		$is_new = null === $previous;

		return $this->findings->save(
			new Finding(
				id: $is_new ? null : $previous->id,
				finding_uuid: $is_new ? wp_generate_uuid4() : $previous->finding_uuid,
				organisation_id: $scope->organisation_id,
				scope_id: (int) $scope->id,
				rule_id: $rule->rule_id,
				rule_version: $rule->version,
				title: $rule->title,
				category: $rule->category,
				severity: $rule->severity,
				confidence: $current->confidence,
				status: $status,
				first_observed_at: $is_new ? $now : $previous->first_observed_at,
				last_observed_at: $now,
				resolved_at: null,
				evidence_refs: $current->evidence_refs,
				expected_state: $current->expected_state,
				observed_state: $current->observed_state,
				risk_statement: $rule->risk_statement,
				recommendation: $rule->recommendation,
				standards_references: $rule->standards_references,
				assigned_owner: $is_new ? null : $previous->assigned_owner,
				due_date: $is_new ? null : $previous->due_date,
				operator_notes: $is_new ? null : $previous->operator_notes,
				suppression_reason: ( $is_new || FindingStatus::New === $status ) ? null : $previous->suppression_reason,
				suppression_expires_at: ( $is_new || FindingStatus::New === $status ) ? null : $previous->suppression_expires_at,
				risk_accepted_by: ( $is_new || FindingStatus::New === $status ) ? null : $previous->risk_accepted_by,
				risk_accept_review_date: ( $is_new || FindingStatus::New === $status ) ? null : $previous->risk_accept_review_date
			)
		);
	}

	private function resolve_finding( Finding $previous, \DateTimeImmutable $now ): Finding {
		return $this->findings->save(
			new Finding(
				id: $previous->id,
				finding_uuid: $previous->finding_uuid,
				organisation_id: $previous->organisation_id,
				scope_id: $previous->scope_id,
				rule_id: $previous->rule_id,
				rule_version: $previous->rule_version,
				title: $previous->title,
				category: $previous->category,
				severity: $previous->severity,
				confidence: $previous->confidence,
				status: FindingStatus::Resolved,
				first_observed_at: $previous->first_observed_at,
				last_observed_at: $now,
				resolved_at: $now,
				evidence_refs: $previous->evidence_refs,
				expected_state: $previous->expected_state,
				observed_state: $previous->observed_state,
				risk_statement: $previous->risk_statement,
				recommendation: $previous->recommendation,
				standards_references: $previous->standards_references,
				assigned_owner: $previous->assigned_owner,
				due_date: $previous->due_date,
				operator_notes: $previous->operator_notes,
				suppression_reason: $previous->suppression_reason,
				suppression_expires_at: $previous->suppression_expires_at
			)
		);
	}

	private function fail_job( Job $job, string $error_category, string $message, ?int $actor_id, ?int $exit_code = null ): Job {
		$job = $this->jobs->transition(
			(int) $job->id,
			JobStatus::Failed,
			array(
				'error_category' => $error_category,
				'exit_code'      => $exit_code,
			)
		);

		$this->audit_logger->log( 'job.failed', 'job', $job->id, $actor_id, outcome: 'failure', summary: "{$error_category}: {$message}" );
		do_action( 'wpr_job_completed', $job->id );

		return $job;
	}

	/**
	 * @return array<string,mixed>|null The decoded evidence document, or null if it fails
	 *                                   schema validation.
	 */
	private function validate_evidence( string $evidence_json ): ?array {
		$decoded_array = json_decode( $evidence_json, true );

		if ( ! is_array( $decoded_array ) ) {
			return null;
		}

		$schema = json_decode( (string) file_get_contents( WPR_PLUGIN_DIR . 'schemas/evidence.schema.json' ) );

		if ( ! $schema instanceof \stdClass ) {
			return null;
		}

		$decoded_object = json_decode( $evidence_json );
		$validator      = new Validator();
		$result         = $validator->validate( $decoded_object, $schema );

		return $result->isValid() ? $decoded_array : null;
	}
}
