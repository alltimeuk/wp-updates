<?php
/**
 * Generalized evidence-level change engine (Section 33): compares two observations' evidence
 * across a registry of asset kinds - certificates, subdomains, IP addresses, DKIM selectors -
 * rather than the one-off certificate/subdomain diffing this replaces. New asset kinds are added
 * by extending {@see self::KINDS} and {@see self::extract()}, not by duplicating diff logic.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

final class AssetChangeDetector {

	/**
	 * Kind => [collector key the identifiers come from, human-readable singular label].
	 */
	private const KINDS = array(
		'certificate'   => array(
			'collector' => 'ct',
			'label'     => 'certificate',
		),
		'subdomain'     => array(
			'collector' => 'subdomains',
			'label'     => 'subdomain',
		),
		'ip_address'    => array(
			'collector' => 'dns',
			'label'     => 'IP address',
		),
		'dkim_selector' => array(
			'collector' => 'mail',
			'label'     => 'DKIM selector',
		),
	);

	public function __construct(
		private readonly AssetDiffer $differ = new AssetDiffer()
	) {}

	/**
	 * @param array<string,array{status?:string,data?:array<mixed>}> $previous_evidence Keyed by collector, as returned by ObservationRepository::evidence_data_by_collector().
	 * @param array<string,array{status?:string,data?:array<mixed>}> $current_evidence
	 * @return array<string,AssetDiff> Kind => diff, only for kinds where something actually changed.
	 */
	public function detect( array $previous_evidence, array $current_evidence ): array {
		$changes = array();

		foreach ( self::KINDS as $kind => $meta ) {
			$previous_ids = $this->extract( $kind, (array) ( $previous_evidence[ $meta['collector'] ]['data'] ?? array() ) );
			$current_ids  = $this->extract( $kind, (array) ( $current_evidence[ $meta['collector'] ]['data'] ?? array() ) );

			$diff = $this->differ->diff( $previous_ids, $current_ids );

			if ( $diff->has_changes() ) {
				$changes[ $kind ] = $diff;
			}
		}

		return $changes;
	}

	public function label( string $kind ): string {
		return self::KINDS[ $kind ]['label'] ?? $kind;
	}

	/**
	 * @param array<mixed> $data
	 * @return string[]
	 */
	private function extract( string $kind, array $data ): array {
		return match ( $kind ) {
			'certificate' => self::certificate_ids( $data ),
			'subdomain' => self::subdomain_names( $data ),
			'ip_address' => self::ip_addresses( $data ),
			'dkim_selector' => self::dkim_selectors( $data ),
			default => array(),
		};
	}

	/**
	 * Stable identifiers for the certificates in a `ct` collector payload. The collector is
	 * expected to emit a list of certificate objects each carrying a `serial_number` (or
	 * `serial`); where that is absent a deterministic hash of the identifying fields is used so
	 * the same certificate is never reported twice.
	 *
	 * @param array<mixed> $data
	 * @return string[]
	 */
	private static function certificate_ids( array $data ): array {
		$certificates = $data['certificates'] ?? $data;
		$ids          = array();

		foreach ( $certificates as $certificate ) {
			if ( ! is_array( $certificate ) ) {
				continue;
			}

			$serial = $certificate['serial_number'] ?? $certificate['serial'] ?? null;

			if ( is_string( $serial ) && '' !== $serial ) {
				$ids[] = $serial;
				continue;
			}

			$ids[] = hash( 'sha256', (string) wp_json_encode( $certificate ) );
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Subdomain names in a `subdomains` collector payload - either a flat list of name strings
	 * or an object with a `subdomains`/`names` key.
	 *
	 * @param array<mixed> $data
	 * @return string[]
	 */
	private static function subdomain_names( array $data ): array {
		$names = $data['subdomains'] ?? $data['names'] ?? $data;

		$result = array();
		foreach ( $names as $name ) {
			if ( is_string( $name ) && '' !== $name ) {
				$result[] = $name;
			}
		}

		return array_values( array_unique( $result ) );
	}

	/**
	 * A and AAAA record values in a `dns` collector payload, combined into one asset kind - an
	 * unexpected new IP address is equally notable regardless of record family.
	 *
	 * @param array<mixed> $data
	 * @return string[]
	 */
	private static function ip_addresses( array $data ): array {
		$addresses = array_merge( (array) ( $data['a'] ?? array() ), (array) ( $data['aaaa'] ?? array() ) );

		$result = array();
		foreach ( $addresses as $address ) {
			if ( is_string( $address ) && '' !== $address ) {
				$result[] = $address;
			}
		}

		return array_values( array_unique( $result ) );
	}

	/**
	 * Selector names observed in a `mail` collector's `dkim` entries. A selector the collector
	 * could not observe carries no confirmed identity and must never be reported as a "new"
	 * selector (Section 11: absence and non-applicability must never share a representation).
	 *
	 * @param array<mixed> $data
	 * @return string[]
	 */
	private static function dkim_selectors( array $data ): array {
		$entries = (array) ( $data['dkim'] ?? array() );

		$result = array();
		foreach ( $entries as $entry ) {
			if ( ! is_array( $entry ) || 'not_observable' === ( $entry['status'] ?? null ) ) {
				continue;
			}

			$selector = $entry['selector'] ?? null;

			if ( is_string( $selector ) && '' !== $selector ) {
				$result[] = $selector;
			}
		}

		return array_values( array_unique( $result ) );
	}
}
