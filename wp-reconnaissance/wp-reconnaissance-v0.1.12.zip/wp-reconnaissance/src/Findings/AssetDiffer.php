<?php
/**
 * Pure set comparison between two snapshots of an asset kind's stable identifiers, per Section
 * 33's generalized change engine. Deliberately holds no knowledge of what an "asset kind" is or
 * how its identifiers are extracted from evidence - {@see AssetChangeDetector} owns that.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

final class AssetDiffer {

	/**
	 * @param string[] $previous_ids
	 * @param string[] $current_ids
	 */
	public function diff( array $previous_ids, array $current_ids ): AssetDiff {
		$previous = array_unique( $previous_ids );
		$current  = array_unique( $current_ids );

		$added   = array_values( array_diff( $current, $previous ) );
		$removed = array_values( array_diff( $previous, $current ) );

		sort( $added );
		sort( $removed );

		return new AssetDiff( $added, $removed );
	}
}
