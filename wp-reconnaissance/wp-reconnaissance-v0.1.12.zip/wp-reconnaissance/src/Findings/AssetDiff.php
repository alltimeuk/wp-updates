<?php
/**
 * The result of comparing two snapshots of an asset kind's stable identifiers, per Section 33's
 * generalized change engine.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

final class AssetDiff {

	/**
	 * @param string[] $added   Identifiers present now that were not present before.
	 * @param string[] $removed Identifiers present before that are no longer present.
	 */
	public function __construct(
		public readonly array $added,
		public readonly array $removed
	) {}

	public function has_changes(): bool {
		return array() !== $this->added || array() !== $this->removed;
	}
}
