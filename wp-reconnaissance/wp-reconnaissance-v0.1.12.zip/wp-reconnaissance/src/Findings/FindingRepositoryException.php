<?php
/**
 * Thrown when a repository write against `wpr_findings` genuinely fails at the database level.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

final class FindingRepositoryException extends \RuntimeException {}
