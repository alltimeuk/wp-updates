<?php
/**
 * Classifies the change significance between the most recent finding for a rule (regardless of
 * status) and a new rule evaluation result, per Section 8.7.
 *
 * Deliberately does not treat record order, TTL alone or JSON property order as material -
 * comparison is over the rule's declared `observed_state`, not the raw evidence document.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Findings;

use Alltime\WPReconnaissance\Domain\Enums\ChangeSignificance;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Finding;
use Alltime\WPReconnaissance\Rules\RuleResult;

final class ChangeDetector {

	private const TERMINAL_STATUSES = array( FindingStatus::Resolved, FindingStatus::FalsePositive );

	/**
	 * @param Finding|null    $previous The most recent finding for this rule/scope regardless of
	 *                                   status ({@see FindingRepository::find_latest_by_rule()}),
	 *                                   or null if the rule has never fired for this scope before.
	 * @param RuleResult|null $current Result of re-evaluating the rule against the latest
	 *                                  observation, or null if the rule no longer fires.
	 */
	public function classify( ?Finding $previous, ?RuleResult $current ): ChangeSignificance {
		$previous_is_terminal = null !== $previous && in_array( $previous->status, self::TERMINAL_STATUSES, true );

		if ( null === $previous || $previous_is_terminal ) {
			return null !== $current ? ( null === $previous ? ChangeSignificance::Added : ChangeSignificance::Reopened ) : ChangeSignificance::Unchanged;
		}

		// $previous exists and is not resolved/false_positive - i.e. it is currently open in
		// some form (new, open, acknowledged, in_progress, accepted_risk, suppressed).
		if ( null === $current ) {
			return ChangeSignificance::Resolved;
		}

		if ( $previous->observed_state === $current->observed_state ) {
			return ChangeSignificance::Unchanged;
		}

		// Severity is fixed per rule_id, not per evaluation, so it can never itself signal
		// worsening - confidence rising while the same rule still fires is the closest generic
		// proxy this plugin has for "the problem is more certainly real than last time" without
		// every rule defining its own bespoke worse/better comparator for its observed_state
		// shape. A same-rank change (e.g. a different missing subdomain, confidence unchanged)
		// stays Modified rather than being guessed at either way.
		return match ( true ) {
			$current->confidence->rank() > $previous->confidence->rank() => ChangeSignificance::Worsened,
			$current->confidence->rank() < $previous->confidence->rank() => ChangeSignificance::Improved,
			default => ChangeSignificance::Modified,
		};
	}
}
