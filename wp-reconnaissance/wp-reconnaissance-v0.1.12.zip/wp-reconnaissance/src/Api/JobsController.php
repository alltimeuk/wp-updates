<?php
/**
 * REST resource controller for collection jobs, per Section 23.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Job;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;
use Alltime\WPReconnaissance\Support\ActorScope;
use Alltime\WPReconnaissance\Support\Capabilities;

final class JobsController {

	public function __construct(
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly ActorScope $actor_scope = new ActorScope(),
		private readonly SchedulingBootstrap $scheduling = new SchedulingBootstrap()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/scopes/(?P<scope_id>\d+)/jobs',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read_scope' ),
					'args'                => array(
						'scope_id' => array(
							'type'     => 'integer',
							'required' => true,
						),
						'limit'    => array(
							'type'    => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 100,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'can_dispatch_scope' ),
					'args'                => array(
						'scope_id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/jobs/(?P<id>\d+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => array( $this, 'can_read_any' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	public function can_read_scope( \WP_REST_Request $request ): bool {
		$scope = $this->scopes->find( (int) $request->get_param( 'scope_id' ) );

		return null !== $scope && $this->actor_scope->can_access_organisation( $scope->organisation_id );
	}

	public function can_dispatch_scope( \WP_REST_Request $request ): bool {
		if ( ! current_user_can( Capabilities::RUN_ASSESSMENTS ) ) {
			return false;
		}

		return $this->can_read_scope( $request );
	}

	public function can_read_any(): bool {
		return current_user_can( Capabilities::VIEW_ALL_RESULTS ) || current_user_can( Capabilities::VIEW_ASSIGNED_ORG );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$scope_id = (int) $request->get_param( 'scope_id' );
		$limit    = min( 100, max( 1, (int) $request->get_param( 'limit' ) ) );

		return new \WP_REST_Response(
			array( 'items' => array_map( array( self::class, 'to_array' ), $this->jobs->find_by_scope( $scope_id, $limit ) ) )
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$job = $this->jobs->find( (int) $request->get_param( 'id' ) );

		if ( null === $job ) {
			return new \WP_Error( 'wpr_not_found', __( 'Job not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		if ( ! $this->actor_scope->can_access_organisation( $job->organisation_id ) ) {
			return new \WP_Error( 'wpr_forbidden', __( 'You do not have access to this job.', 'wp-reconnaissance' ), array( 'status' => 403 ) );
		}

		return new \WP_REST_Response( self::to_array( $job ) );
	}

	/**
	 * Queues a new assessment run rather than executing it inline (Section 15: PHP web requests
	 * must stay short) - the job record itself is created inside
	 * {@see \Alltime\WPReconnaissance\Assessment\AssessmentService::run()} once the queued
	 * action actually runs, so this returns 202 Accepted with no job resource yet. Poll
	 * `GET /scopes/{scope_id}/jobs` to see it appear.
	 */
	public function create_item( \WP_REST_Request $request ): \WP_REST_Response {
		$scope_id = (int) $request->get_param( 'scope_id' );

		$this->scheduling->schedule_assessment( $scope_id, get_current_user_id() );

		return new \WP_REST_Response(
			array(
				'scope_id' => $scope_id,
				'status'   => 'queued',
			),
			202
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Job $job ): array {
		return array(
			'id'              => $job->id,
			'job_uuid'        => $job->job_uuid,
			'organisation_id' => $job->organisation_id,
			'scope_id'        => $job->scope_id,
			'status'          => $job->status->value,
			'adapter'         => $job->adapter,
			'worker_version'  => $job->worker_version,
			'exit_code'       => $job->exit_code,
			'error_category'  => $job->error_category,
			'requested_at'    => $job->requested_at->format( DATE_ATOM ),
			'started_at'      => $job->started_at?->format( DATE_ATOM ),
			'completed_at'    => $job->completed_at?->format( DATE_ATOM ),
		);
	}
}
