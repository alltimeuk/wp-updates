<?php
/**
 * REST resource controller for authorised scopes, per Section 23.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepositoryException;
use Alltime\WPReconnaissance\Domain\DomainValidator;
use Alltime\WPReconnaissance\Domain\Exceptions\InvalidDomainException;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Entitlements\PlanEnforcementService;
use Alltime\WPReconnaissance\Entitlements\PlanLimitException;
use Alltime\WPReconnaissance\Support\ActorScope;
use Alltime\WPReconnaissance\Support\Capabilities;

final class ScopesController {

	/** Mirrors the default monitoring profile's enabled_collectors ({@see \Alltime\WPReconnaissance\Data\Repositories\ProfileRepository}). */
	private const DEFAULT_COLLECTORS = array( 'rdap', 'dns', 'dnssec', 'mail', 'http', 'tls', 'ct', 'subdomains', 'lookalikes' );

	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly ActorScope $actor_scope = new ActorScope(),
		private readonly DomainValidator $domain_validator = new DomainValidator(),
		private readonly PlanEnforcementService $plan_enforcement = new PlanEnforcementService()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_id>\d+)/scopes',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read_organisation' ),
					'args'                => array(
						'organisation_id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => static fn (): bool => current_user_can( Capabilities::MANAGE_SCOPES ),
					'args'                => array(
						'organisation_id' => array(
							'type'     => 'integer',
							'required' => true,
						),
						'name'            => array(
							'type'     => 'string',
							'required' => true,
						),
						'domain'          => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/scopes/(?P<id>\d+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => array( $this, 'can_read_any' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/scopes/(?P<id>\d+)/authorise',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'authorise_item' ),
				'permission_callback' => static fn (): bool => current_user_can( Capabilities::MANAGE_SCOPES ),
				'args'                => array(
					'id'                      => array(
						'type'     => 'integer',
						'required' => true,
					),
					'authorisation_reference' => array(
						'type'     => 'string',
						'required' => true,
					),
					'authorised_until'        => array( 'type' => 'string' ),
				),
			)
		);
	}

	public function can_read_organisation( \WP_REST_Request $request ): bool {
		return $this->actor_scope->can_access_organisation( (int) $request->get_param( 'organisation_id' ) );
	}

	public function can_read_any(): bool {
		return current_user_can( Capabilities::VIEW_ALL_RESULTS ) || current_user_can( Capabilities::VIEW_ASSIGNED_ORG );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_id = (int) $request->get_param( 'organisation_id' );

		return new \WP_REST_Response(
			array( 'items' => array_map( array( self::class, 'to_array' ), $this->scopes->find_by_organisation( $organisation_id ) ) )
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$scope = $this->scopes->find( (int) $request->get_param( 'id' ) );

		if ( null === $scope ) {
			return new \WP_Error( 'wpr_not_found', __( 'Scope not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		if ( ! $this->actor_scope->can_access_organisation( $scope->organisation_id ) ) {
			return new \WP_Error( 'wpr_forbidden', __( 'You do not have access to this scope.', 'wp-reconnaissance' ), array( 'status' => 403 ) );
		}

		return new \WP_REST_Response( self::to_array( $scope ) );
	}

	/**
	 * Creates a new scope in the "pending" / not-yet-authorised state (Section 8.2, Section 27):
	 * no collection ever runs against it until a subsequent {@see authorise_item()} call.
	 */
	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$organisation_id = (int) $request->get_param( 'organisation_id' );

		try {
			$domain = $this->domain_validator->validate( (string) $request->get_param( 'domain' ) );
		} catch ( InvalidDomainException $exception ) {
			return new \WP_Error( 'wpr_invalid_domain', $exception->getMessage(), array( 'status' => 422 ) );
		}

		try {
			$scope = $this->scopes->create(
				$organisation_id,
				(string) $request->get_param( 'name' ),
				$domain->ascii,
				$domain->display,
				$domain->registrable,
				self::DEFAULT_COLLECTORS
			);
		} catch ( ScopeRepositoryException $exception ) {
			return new \WP_Error( 'wpr_scope_create_failed', $exception->getMessage(), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response( self::to_array( $scope ), 201 );
	}

	/**
	 * Records the authorised-use decision an operator has already confirmed out of band
	 * (Section 27: the plugin displays a clear authorised-use notice, but the actual
	 * authorisation evidence - signed agreement, verified domain control, etc. - is established
	 * outside this endpoint before it is ever called).
	 */
	public function authorise_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$scope = $this->scopes->find( (int) $request->get_param( 'id' ) );

		if ( null === $scope ) {
			return new \WP_Error( 'wpr_not_found', __( 'Scope not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		$authorised_until_raw = $request->get_param( 'authorised_until' );
		$authorised_until     = null !== $authorised_until_raw && '' !== $authorised_until_raw
			? new \DateTimeImmutable( (string) $authorised_until_raw )
			: null;

		try {
			$updated = $this->plan_enforcement->authorise_within_plan_limit(
				$scope->organisation_id,
				fn () => $this->scopes->authorise(
					(int) $scope->id,
					get_current_user_id(),
					(string) $request->get_param( 'authorisation_reference' ),
					null,
					$authorised_until
				)
			);
		} catch ( PlanLimitException $exception ) {
			return new \WP_Error( 'wpr_plan_limit_exceeded', $exception->getMessage(), array( 'status' => 422 ) );
		} catch ( ScopeRepositoryException $exception ) {
			return new \WP_Error( 'wpr_scope_authorise_failed', $exception->getMessage(), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response( self::to_array( $updated ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Scope $scope ): array {
		return array(
			'id'                      => $scope->id,
			'organisation_id'         => $scope->organisation_id,
			'name'                    => $scope->name,
			'domain'                  => $scope->domain_display,
			'registrable_domain'      => $scope->registrable_domain,
			'status'                  => $scope->status,
			'authorisation_status'    => $scope->authorisation_status,
			'authorised_from'         => $scope->authorised_from?->format( DATE_ATOM ),
			'authorised_until'        => $scope->authorised_until?->format( DATE_ATOM ),
			'permitted_collectors'    => $scope->permitted_collectors,
			'is_currently_authorised' => $scope->is_currently_authorised(),
		);
	}
}
