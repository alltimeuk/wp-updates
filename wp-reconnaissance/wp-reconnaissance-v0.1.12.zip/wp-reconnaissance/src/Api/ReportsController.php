<?php
/**
 * REST resource controller for issued reports, per Section 23.
 *
 * Returns the report document as JSON only - Section 21.2's HTML and Markdown renderings are
 * served through the admin and customer portal routes
 * ({@see \Alltime\WPReconnaissance\Reports\HtmlReportRenderer},
 * {@see \Alltime\WPReconnaissance\Reports\MarkdownReportRenderer}), not content-negotiated here,
 * to keep this resource a conventional JSON API.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Report;
use Alltime\WPReconnaissance\Reports\DomainReconnaissanceReportBuilder;
use Alltime\WPReconnaissance\Reports\RemediationTaskGenerator;
use Alltime\WPReconnaissance\Reports\ReportException;
use Alltime\WPReconnaissance\Support\ActorScope;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Support\Capabilities;

final class ReportsController {

	public function __construct(
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly ActorScope $actor_scope = new ActorScope(),
		private readonly DomainReconnaissanceReportBuilder $report_builder = new DomainReconnaissanceReportBuilder(),
		private readonly RemediationTaskGenerator $task_generator = new RemediationTaskGenerator(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_id>\d+)/reports',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_items' ),
				'permission_callback' => array( $this, 'can_read_organisation' ),
				'args'                => array(
					'organisation_id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/scopes/(?P<scope_id>\d+)/reports',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_scope_versions' ),
					'permission_callback' => array( $this, 'can_read_scope' ),
					'args'                => array(
						'scope_id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => static fn (): bool => current_user_can( Capabilities::ISSUE_REPORTS ),
					'args'                => array(
						'scope_id'          => array(
							'type'     => 'integer',
							'required' => true,
						),
						'executive_summary' => array( 'type' => 'string' ),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/reports/(?P<id>\d+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => array( $this, 'can_read_any' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	public function can_read_organisation( \WP_REST_Request $request ): bool {
		return $this->actor_scope->can_access_organisation( (int) $request->get_param( 'organisation_id' ) );
	}

	public function can_read_any(): bool {
		return current_user_can( Capabilities::VIEW_ALL_RESULTS ) || current_user_can( Capabilities::VIEW_ASSIGNED_ORG );
	}

	public function can_read_scope( \WP_REST_Request $request ): bool {
		$scope = $this->scopes->find( (int) $request->get_param( 'scope_id' ) );

		return null !== $scope && $this->actor_scope->can_access_organisation( $scope->organisation_id );
	}

	/**
	 * Every issued version for a scope (Section 33 "issued report versions") - unlike
	 * {@see list_items()}, which only ever returns the single latest version per scope.
	 */
	public function list_scope_versions( \WP_REST_Request $request ): \WP_REST_Response {
		$scope_id = (int) $request->get_param( 'scope_id' );

		return new \WP_REST_Response(
			array( 'items' => array_map( array( self::class, 'to_array' ), $this->reports->find_by_scope( $scope_id ) ) )
		);
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_id = (int) $request->get_param( 'organisation_id' );

		return new \WP_REST_Response(
			array( 'items' => array_map( array( self::class, 'to_array' ), $this->reports->find_latest_by_organisation( $organisation_id ) ) )
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$report = $this->reports->find( (int) $request->get_param( 'id' ) );

		if ( null === $report ) {
			return new \WP_Error( 'wpr_not_found', __( 'Report not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		if ( ! $this->actor_scope->can_access_organisation( $report->organisation_id ) ) {
			return new \WP_Error( 'wpr_forbidden', __( 'You do not have access to this report.', 'wp-reconnaissance' ), array( 'status' => 403 ) );
		}

		return new \WP_REST_Response( self::to_array( $report, true ) );
	}

	/**
	 * Refreshes the scope's remediation tasks, then generates and issues a new report version -
	 * mirrors the two-step admin flow (Section 19.6) in a single request rather than exposing
	 * the intermediate draft over the API.
	 */
	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$scope_id          = (int) $request->get_param( 'scope_id' );
		$executive_summary = $request->get_param( 'executive_summary' );

		if ( null === $this->scopes->find( $scope_id ) ) {
			return new \WP_Error( 'wpr_not_found', __( 'Scope not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		$this->task_generator->generate_for_scope( $scope_id, get_current_user_id() );

		try {
			$document = $this->report_builder->generate( $scope_id, is_string( $executive_summary ) && '' !== $executive_summary ? $executive_summary : null );
		} catch ( ReportException $exception ) {
			return new \WP_Error( 'wpr_report_generation_failed', $exception->getMessage(), array( 'status' => 422 ) );
		}

		$report = $this->reports->save(
			(int) $document['organisation_id'],
			$scope_id,
			(int) $document['observation_id'],
			(int) $document['version'],
			$document,
			get_current_user_id()
		);

		$this->audit_logger->log( 'report.issued', 'report', $report->id, get_current_user_id(), summary: "scope #{$scope_id} v{$report->version}", source: 'rest' );

		return new \WP_REST_Response( self::to_array( $report, true ), 201 );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Report $report, bool $include_document = false ): array {
		$data = array(
			'id'              => $report->id,
			'report_id'       => $report->report_uuid,
			'organisation_id' => $report->organisation_id,
			'scope_id'        => $report->scope_id,
			'observation_id'  => $report->observation_id,
			'version'         => $report->version,
			'generated_at'    => $report->generated_at->format( DATE_ATOM ),
			'generated_by'    => $report->generated_by,
		);

		if ( $include_document ) {
			$data['document'] = $report->document;
		}

		return $data;
	}
}
