<?php
/**
 * REST resource for an organisation's customer accounts, per Section 23 and Section 33's CRM
 * integration (contacts are the one thing a CRM sync needs that no existing REST resource already
 * exposed - domains/config already come from ScopesController, reports from ReportsController).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Auth\CustomerAccount;
use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Support\ActorScope;

final class ContactsController {

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly ActorScope $actor_scope = new ActorScope()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_id>\d+)/contacts',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_items' ),
				'permission_callback' => array( $this, 'can_read_organisation' ),
				'args'                => array(
					'organisation_id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	public function can_read_organisation( \WP_REST_Request $request ): bool {
		return $this->actor_scope->can_access_organisation( (int) $request->get_param( 'organisation_id' ) );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_id = (int) $request->get_param( 'organisation_id' );

		return new \WP_REST_Response(
			array( 'items' => array_map( array( self::class, 'to_array' ), $this->accounts->find_by_organisation( $organisation_id ) ) )
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( CustomerAccount $account ): array {
		return array(
			'user_id'         => $account->user_id,
			'email'           => $account->email,
			'given_name'      => $account->given_name,
			'family_name'     => $account->family_name,
			'organisation_id' => $account->organisation_id,
			'status'          => $account->status->value,
		);
	}
}
