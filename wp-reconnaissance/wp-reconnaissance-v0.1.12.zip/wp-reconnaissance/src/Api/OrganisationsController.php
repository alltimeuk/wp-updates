<?php
/**
 * REST resource controller for organisations, per Section 23.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepositoryException;
use Alltime\WPReconnaissance\Domain\Organisation;
use Alltime\WPReconnaissance\Support\ActorScope;
use Alltime\WPReconnaissance\Support\Capabilities;

final class OrganisationsController {

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly ActorScope $actor_scope = new ActorScope()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_items' ),
					'permission_callback' => array( $this, 'can_read' ),
					'args'                => array(
						'page'     => array(
							'type'    => 'integer',
							'default' => 1,
							'minimum' => 1,
						),
						'per_page' => array(
							'type'    => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 100,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => static fn (): bool => current_user_can( Capabilities::MANAGE_ORGANISATIONS ),
					'args'                => array(
						'name'     => array(
							'type'     => 'string',
							'required' => true,
						),
						'timezone' => array(
							'type'    => 'string',
							'default' => 'UTC',
						),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'can_read' ),
					'args'                => array(
						'id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => static fn (): bool => current_user_can( Capabilities::MANAGE_ORGANISATIONS ),
					'args'                => array(
						'id'       => array(
							'type'     => 'integer',
							'required' => true,
						),
						'name'     => array( 'type' => 'string' ),
						'timezone' => array( 'type' => 'string' ),
						'status'   => array(
							'type' => 'string',
							'enum' => array( 'active', 'suspended', 'closed' ),
						),
					),
				),
			)
		);
	}

	/**
	 * An operator without a specific organisation permission still passes the route-level
	 * permission_callback (list/read are open to any authenticated actor with either
	 * capability); {@see list_items()}/{@see get_item()} apply the actual per-record scoping.
	 */
	public function can_read(): bool {
		return current_user_can( Capabilities::VIEW_ALL_RESULTS ) || current_user_can( Capabilities::VIEW_ASSIGNED_ORG );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		if ( $this->actor_scope->is_operator() ) {
			$page     = max( 1, (int) $request->get_param( 'page' ) );
			$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );

			return new \WP_REST_Response(
				array(
					'items' => array_map( array( self::class, 'to_array' ), $this->organisations->list( $per_page, $page ) ),
					'total' => $this->organisations->count(),
					'page'  => $page,
				)
			);
		}

		$organisation_id = $this->actor_scope->customer_organisation_id();
		$organisation    = null !== $organisation_id ? $this->organisations->find( $organisation_id ) : null;

		return new \WP_REST_Response(
			array(
				'items' => null !== $organisation ? array( self::to_array( $organisation ) ) : array(),
				'total' => null !== $organisation ? 1 : 0,
				'page'  => 1,
			)
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$id = (int) $request->get_param( 'id' );

		if ( ! $this->actor_scope->can_access_organisation( $id ) ) {
			return new \WP_Error( 'wpr_forbidden', __( 'You do not have access to this organisation.', 'wp-reconnaissance' ), array( 'status' => 403 ) );
		}

		$organisation = $this->organisations->find( $id );

		if ( null === $organisation ) {
			return new \WP_Error( 'wpr_not_found', __( 'Organisation not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response( self::to_array( $organisation ) );
	}

	public function create_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$name     = (string) $request->get_param( 'name' );
		$timezone = (string) ( $request->get_param( 'timezone' ) ?? 'UTC' );
		$slug     = $this->organisations->unique_slug( $name );

		try {
			$organisation = $this->organisations->create( $name, $slug, null, $timezone );
		} catch ( OrganisationRepositoryException $exception ) {
			return new \WP_Error( 'wpr_organisation_create_failed', $exception->getMessage(), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response( self::to_array( $organisation ), 201 );
	}

	public function update_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$id           = (int) $request->get_param( 'id' );
		$organisation = $this->organisations->find( $id );

		if ( null === $organisation ) {
			return new \WP_Error( 'wpr_not_found', __( 'Organisation not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		try {
			$updated = $this->organisations->update(
				$id,
				(string) ( $request->get_param( 'name' ) ?? $organisation->name ),
				(string) ( $request->get_param( 'timezone' ) ?? $organisation->timezone ),
				(string) ( $request->get_param( 'status' ) ?? $organisation->status )
			);
		} catch ( OrganisationRepositoryException $exception ) {
			return new \WP_Error( 'wpr_organisation_update_failed', $exception->getMessage(), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response( self::to_array( $updated ) );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Organisation $organisation ): array {
		return array(
			'id'                 => $organisation->id,
			'name'               => $organisation->name,
			'slug'               => $organisation->slug,
			'status'             => $organisation->status,
			'timezone'           => $organisation->timezone,
			'primary_contact_id' => $organisation->primary_contact_id,
			'created_at'         => $organisation->created_at?->format( DATE_ATOM ),
			'updated_at'         => $organisation->updated_at?->format( DATE_ATOM ),
		);
	}
}
