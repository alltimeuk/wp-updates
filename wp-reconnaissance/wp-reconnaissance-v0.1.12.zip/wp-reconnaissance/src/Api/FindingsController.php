<?php
/**
 * REST resource controller for findings, per Section 23.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Finding;
use Alltime\WPReconnaissance\Findings\FindingRepository;
use Alltime\WPReconnaissance\Findings\FindingRepositoryException;
use Alltime\WPReconnaissance\Support\ActorScope;
use Alltime\WPReconnaissance\Support\Capabilities;

final class FindingsController {

	public function __construct(
		private readonly FindingRepository $findings = new FindingRepository(),
		private readonly ActorScope $actor_scope = new ActorScope()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_id>\d+)/findings',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_items' ),
				'permission_callback' => array( $this, 'can_read_organisation' ),
				'args'                => array(
					'organisation_id' => array(
						'type'     => 'integer',
						'required' => true,
					),
					'status'          => array(
						'type' => 'string',
						'enum' => array_map( static fn ( FindingStatus $status ): string => $status->value, FindingStatus::cases() ),
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/findings/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'can_read_any' ),
					'args'                => array(
						'id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => static fn (): bool => current_user_can( Capabilities::MANAGE_FINDINGS ),
					'args'                => array(
						'id'                      => array(
							'type'     => 'integer',
							'required' => true,
						),
						'status'                  => array(
							'type'     => 'string',
							'required' => true,
							'enum'     => array_map( static fn ( FindingStatus $status ): string => $status->value, FindingStatus::cases() ),
						),
						'operator_notes'          => array( 'type' => 'string' ),
						'assigned_owner'          => array( 'type' => 'integer' ),
						'due_date'                => array( 'type' => 'string' ),
						'suppression_reason'      => array( 'type' => 'string' ),
						'suppression_expires_at'  => array( 'type' => 'string' ),
						'risk_accept_review_date' => array( 'type' => 'string' ),
					),
				),
			)
		);
	}

	public function can_read_organisation( \WP_REST_Request $request ): bool {
		return $this->actor_scope->can_access_organisation( (int) $request->get_param( 'organisation_id' ) );
	}

	public function can_read_any(): bool {
		return current_user_can( Capabilities::VIEW_ALL_RESULTS ) || current_user_can( Capabilities::VIEW_ASSIGNED_ORG );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_id = (int) $request->get_param( 'organisation_id' );
		$status_raw      = $request->get_param( 'status' );
		$status          = null !== $status_raw && '' !== $status_raw ? FindingStatus::from( (string) $status_raw ) : null;

		return new \WP_REST_Response(
			array( 'items' => array_map( array( self::class, 'to_array' ), $this->findings->find_by_organisation( $organisation_id, $status ) ) )
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$finding = $this->findings->find( (int) $request->get_param( 'id' ) );

		if ( null === $finding ) {
			return new \WP_Error( 'wpr_not_found', __( 'Finding not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		if ( ! $this->actor_scope->can_access_organisation( $finding->organisation_id ) ) {
			return new \WP_Error( 'wpr_forbidden', __( 'You do not have access to this finding.', 'wp-reconnaissance' ), array( 'status' => 403 ) );
		}

		return new \WP_REST_Response( self::to_array( $finding ) );
	}

	/**
	 * Applies an operator review decision - status transition plus notes/ownership/suppression.
	 * Never touches the change-detection fields; those are only ever written by the assessment
	 * pipeline (Section 8.7).
	 */
	public function update_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$id      = (int) $request->get_param( 'id' );
		$finding = $this->findings->find( $id );

		if ( null === $finding ) {
			return new \WP_Error( 'wpr_not_found', __( 'Finding not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		$status            = FindingStatus::from( (string) $request->get_param( 'status' ) );
		$due_date_raw      = $request->get_param( 'due_date' );
		$suppression_until = $request->get_param( 'suppression_expires_at' );
		$risk_review_raw   = $request->get_param( 'risk_accept_review_date' );

		// Meaningful only while the finding is being marked (or stays marked) accepted-risk - any
		// other status clears both, so a stale reviewer/review-date never survives past the
		// status it was recorded for.
		$is_accepting_risk = FindingStatus::AcceptedRisk === $status;

		try {
			$updated = $this->findings->update_review(
				$id,
				$status,
				$this->nullable_string( $request->get_param( 'operator_notes' ) ) ?? $finding->operator_notes,
				null !== $request->get_param( 'assigned_owner' ) ? (int) $request->get_param( 'assigned_owner' ) : $finding->assigned_owner,
				null !== $due_date_raw && '' !== $due_date_raw ? new \DateTimeImmutable( (string) $due_date_raw ) : $finding->due_date,
				$this->nullable_string( $request->get_param( 'suppression_reason' ) ) ?? $finding->suppression_reason,
				null !== $suppression_until && '' !== $suppression_until ? new \DateTimeImmutable( (string) $suppression_until ) : $finding->suppression_expires_at,
				$is_accepting_risk ? get_current_user_id() : null,
				$is_accepting_risk && null !== $risk_review_raw && '' !== $risk_review_raw ? new \DateTimeImmutable( (string) $risk_review_raw ) : null
			);
		} catch ( FindingRepositoryException $exception ) {
			return new \WP_Error( 'wpr_finding_update_failed', $exception->getMessage(), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response( self::to_array( $updated ) );
	}

	private function nullable_string( mixed $value ): ?string {
		return is_string( $value ) && '' !== $value ? $value : null;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( Finding $finding ): array {
		return array(
			'id'                      => $finding->id,
			'finding_uuid'            => $finding->finding_uuid,
			'organisation_id'         => $finding->organisation_id,
			'scope_id'                => $finding->scope_id,
			'rule_id'                 => $finding->rule_id,
			'title'                   => $finding->title,
			'category'                => $finding->category,
			'severity'                => $finding->severity->value,
			'confidence'              => $finding->confidence->value,
			'status'                  => $finding->status->value,
			'first_observed_at'       => $finding->first_observed_at->format( DATE_ATOM ),
			'last_observed_at'        => $finding->last_observed_at->format( DATE_ATOM ),
			'resolved_at'             => $finding->resolved_at?->format( DATE_ATOM ),
			'risk_statement'          => $finding->risk_statement,
			'recommendation'          => $finding->recommendation,
			'assigned_owner'          => $finding->assigned_owner,
			'due_date'                => $finding->due_date?->format( 'Y-m-d' ),
			'operator_notes'          => $finding->operator_notes,
			'risk_accepted_by'        => $finding->risk_accepted_by,
			'risk_accept_review_date' => $finding->risk_accept_review_date?->format( 'Y-m-d' ),
		);
	}
}
