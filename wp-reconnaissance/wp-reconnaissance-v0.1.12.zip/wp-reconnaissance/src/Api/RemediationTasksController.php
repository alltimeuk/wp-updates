<?php
/**
 * REST resource controller for remediation tasks, per Section 21.3 and Section 23.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Api;

use Alltime\WPReconnaissance\Data\Repositories\RemediationTaskRepository;
use Alltime\WPReconnaissance\Domain\Enums\RemediationTaskStatus;
use Alltime\WPReconnaissance\Domain\RemediationTask;
use Alltime\WPReconnaissance\Support\ActorScope;
use Alltime\WPReconnaissance\Support\Capabilities;

final class RemediationTasksController {

	public function __construct(
		private readonly RemediationTaskRepository $tasks = new RemediationTaskRepository(),
		private readonly ActorScope $actor_scope = new ActorScope()
	) {}

	public function register_routes(): void {
		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/organisations/(?P<organisation_id>\d+)/remediation-tasks',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_items' ),
				'permission_callback' => array( $this, 'can_read_organisation' ),
				'args'                => array(
					'organisation_id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			RestBootstrap::NAMESPACE_V1,
			'/remediation-tasks/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'can_read_any' ),
					'args'                => array(
						'id' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					// Task status/notes updates reuse the same operator capability as finding
					// review (MANAGE_FINDINGS) rather than a new one - both are ongoing
					// operator adjustments to assessment-pipeline output, not a distinct
					// permission area of their own yet.
					'permission_callback' => static fn (): bool => current_user_can( Capabilities::MANAGE_FINDINGS ),
					'callback'            => array( $this, 'update_item' ),
					'args'                => array(
						'id'             => array(
							'type'     => 'integer',
							'required' => true,
						),
						'status'         => array(
							'type'     => 'string',
							'required' => true,
							'enum'     => array_map( static fn ( RemediationTaskStatus $status ): string => $status->value, RemediationTaskStatus::cases() ),
						),
						'customer_notes' => array( 'type' => 'string' ),
						'operator_notes' => array( 'type' => 'string' ),
						'target_date'    => array( 'type' => 'string' ),
					),
				),
			)
		);
	}

	public function can_read_organisation( \WP_REST_Request $request ): bool {
		return $this->actor_scope->can_access_organisation( (int) $request->get_param( 'organisation_id' ) );
	}

	public function can_read_any(): bool {
		return current_user_can( Capabilities::VIEW_ALL_RESULTS ) || current_user_can( Capabilities::VIEW_ASSIGNED_ORG );
	}

	public function list_items( \WP_REST_Request $request ): \WP_REST_Response {
		$organisation_id = (int) $request->get_param( 'organisation_id' );

		return new \WP_REST_Response(
			array( 'items' => array_map( array( self::class, 'to_array' ), $this->tasks->find_by_organisation( $organisation_id ) ) )
		);
	}

	public function get_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$task = $this->tasks->find( (int) $request->get_param( 'id' ) );

		if ( null === $task ) {
			return new \WP_Error( 'wpr_not_found', __( 'Remediation task not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		if ( ! $this->actor_scope->can_access_organisation( $task->organisation_id ) ) {
			return new \WP_Error( 'wpr_forbidden', __( 'You do not have access to this remediation task.', 'wp-reconnaissance' ), array( 'status' => 403 ) );
		}

		return new \WP_REST_Response( self::to_array( $task ) );
	}

	public function update_item( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$id   = (int) $request->get_param( 'id' );
		$task = $this->tasks->find( $id );

		if ( null === $task ) {
			return new \WP_Error( 'wpr_not_found', __( 'Remediation task not found.', 'wp-reconnaissance' ), array( 'status' => 404 ) );
		}

		$target_date_raw = $request->get_param( 'target_date' );

		$updated = $this->tasks->update_status(
			$id,
			RemediationTaskStatus::from( (string) $request->get_param( 'status' ) ),
			$this->nullable_string( $request->get_param( 'customer_notes' ) ) ?? $task->customer_notes,
			$this->nullable_string( $request->get_param( 'operator_notes' ) ) ?? $task->operator_notes,
			null !== $target_date_raw && '' !== $target_date_raw ? new \DateTimeImmutable( (string) $target_date_raw ) : $task->target_date
		);

		return new \WP_REST_Response( self::to_array( $updated ) );
	}

	private function nullable_string( mixed $value ): ?string {
		return is_string( $value ) && '' !== $value ? $value : null;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function to_array( RemediationTask $task ): array {
		return array(
			'id'                   => $task->id,
			'task_id'              => $task->task_uuid,
			'organisation_id'      => $task->organisation_id,
			'scope_id'             => $task->scope_id,
			'finding_id'           => $task->finding_id,
			'title'                => $task->title,
			'technical_subject'    => $task->technical_subject->value,
			'priority_band'        => $task->priority_band->value,
			'recommended_order'    => $task->recommended_order,
			'rationale'            => $task->rationale,
			'implementation_steps' => $task->implementation_steps,
			'validation_steps'     => $task->validation_steps,
			'suggested_owner_type' => $task->suggested_owner_type,
			'target_date'          => $task->target_date?->format( 'Y-m-d' ),
			'status'               => $task->status->value,
			'customer_notes'       => $task->customer_notes,
			'completed_at'         => $task->completed_at?->format( DATE_ATOM ),
		);
	}
}
