<?php
/**
 * An issued report entity, per Section 21.
 *
 * Immutable once created: there is no update path, only {@see \Alltime\WPReconnaissance\Data\Repositories\ReportRepository::save()}
 * inserting a new row for the next version. `document` is the full
 * schemas/report.schema.json-conformant payload - every rendering (HTML, Markdown, JSON) is
 * derived from it, never stored separately.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

final class Report {

	/**
	 * @param array<string,mixed> $document
	 */
	public function __construct(
		public readonly ?int $id,
		public readonly string $report_uuid,
		public readonly int $organisation_id,
		public readonly int $scope_id,
		public readonly int $observation_id,
		public readonly int $version,
		public readonly array $document,
		public readonly \DateTimeImmutable $generated_at,
		public readonly ?int $generated_by
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values, JSON columns as strings).
	 */
	public static function from_row( array $row ): self {
		$decoded = json_decode( (string) $row['document'], true );

		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			report_uuid: (string) $row['report_uuid'],
			organisation_id: (int) $row['organisation_id'],
			scope_id: (int) $row['scope_id'],
			observation_id: (int) $row['observation_id'],
			version: (int) $row['version'],
			document: is_array( $decoded ) ? $decoded : array(),
			generated_at: new \DateTimeImmutable( (string) $row['generated_at'] ),
			generated_by: isset( $row['generated_by'] ) && null !== $row['generated_by'] ? (int) $row['generated_by'] : null
		);
	}
}
