<?php
/**
 * Contract for registrable-domain resolution against a maintained Public Suffix List.
 *
 * Section 12.1 requires a maintained PSL rather than ad hoc suffix guessing. The default
 * implementation, {@see RealPublicSuffixList}, is backed by a bundled, periodically refreshed
 * copy of https://publicsuffix.org/list/public_suffix_list.dat ({@see \bin\update-public-suffix-list}) -
 * this interface exists mainly so tests can substitute a deterministic stub.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

interface PublicSuffixListInterface {

	/**
	 * Returns the registrable domain (public suffix plus one label) for a canonical ASCII
	 * (IDNA) domain, or null if no rule matches.
	 */
	public function registrable_domain( string $ascii_domain ): ?string;
}
