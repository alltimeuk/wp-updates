<?php
/**
 * Recurring assessment cadence, per Section 33 (durable schedules).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum ScheduleFrequency: string {
	case Daily   = 'daily';
	case Weekly  = 'weekly';
	case Monthly = 'monthly';
	case Manual  = 'manual';

	/**
	 * Existing `MonitoringProfile::$schedule`/`Scope::$permitted_schedule` values are free-form
	 * strings, not previously validated against any fixed set - this must never throw on
	 * unrecognised or empty input, only report "no recognised cadence".
	 */
	public static function from_nullable( ?string $value ): ?self {
		if ( null === $value || '' === $value ) {
			return null;
		}

		return self::tryFrom( $value );
	}
}
