<?php
/**
 * Remediation task lifecycle states, per Section 21.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain\Enums;

enum RemediationTaskStatus: string {
	case NotStarted         = 'not_started';
	case Planned            = 'planned';
	case InProgress         = 'in_progress';
	case Blocked            = 'blocked';
	case ReadyForValidation = 'ready_for_validation';
	case Completed          = 'completed';
	case AcceptedRisk       = 'accepted_risk';
	case NotApplicable      = 'not_applicable';

	public function is_terminal(): bool {
		return match ( $this ) {
			self::Completed, self::AcceptedRisk, self::NotApplicable => true,
			default => false,
		};
	}
}
