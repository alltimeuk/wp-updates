<?php
/**
 * Registrable-domain resolution backed by a real, bundled Public Suffix List (Section 12.1),
 * replacing the placeholder fallback implementation this interface's own docblock always
 * anticipated being superseded. Covers both the ICANN section (ccTLD/gTLD suffixes like `co.uk`)
 * and the PRIVATE section (suffixes companies submit for their own shared-hosting platforms, e.g.
 * `github.io`, `herokuapp.com`, `s3.amazonaws.com`) - a customer at `theirname.github.io` must
 * never have `github.io` itself computed as "their" registrable domain, since anti-abuse
 * duplicate-domain detection, entitlement quota and collector targets all key off this value.
 *
 * The list is bundled and pre-compiled at build time ({@see \bin\update-public-suffix-list}), not
 * fetched at runtime - a live fetch of externally-hosted data on every request would reintroduce
 * exactly the kind of untrusted-runtime-fetch surface the SSRF fix elsewhere in this codebase
 * closed, and the actual PSL only changes a few times a year.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

use Pdp\CannotProcessHost;
use Pdp\Rules;

final class RealPublicSuffixList implements PublicSuffixListInterface {

	/**
	 * Parsed once per request (loading the pre-compiled file still costs real time - confirmed
	 * ~10x faster than re-parsing the raw list, but not free), then reused - every
	 * {@see DomainValidator} call site constructs its own instance of this class by default.
	 *
	 * @var ?Rules
	 */
	private static ?Rules $rules = null;

	public function registrable_domain( string $ascii_domain ): ?string {
		try {
			return self::rules()->resolve( $ascii_domain )->registrableDomain()->value();
		} catch ( CannotProcessHost ) {
			// $ascii_domain has already passed DomainValidator's own IDNA/format checks by the
			// time it reaches here, so this is a defensive fallback, not an expected path - a
			// domain this library can't process is not an authorisable scope either way.
			return null;
		}
	}

	private static function rules(): Rules {
		if ( null === self::$rules ) {
			$loaded = require __DIR__ . '/data/public_suffix_list.php';

			if ( ! ( $loaded instanceof Rules ) ) {
				throw new \RuntimeException( 'The bundled Public Suffix List data failed to load correctly.' );
			}

			self::$rules = $loaded;
		}

		return self::$rules;
	}
}
