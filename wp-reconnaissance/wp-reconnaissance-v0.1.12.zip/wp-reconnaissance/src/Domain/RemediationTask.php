<?php
/**
 * Remediation task entity, per Section 21.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Domain;

use Alltime\WPReconnaissance\Domain\Enums\RemediationTaskStatus;
use Alltime\WPReconnaissance\Reports\PriorityBand;
use Alltime\WPReconnaissance\Reports\TechnicalSubject;

final class RemediationTask {

	/**
	 * @param string[]            $implementation_steps
	 * @param string[]            $validation_steps
	 * @param string[]            $dependencies
	 * @param array<string,mixed> $priority_explanation
	 */
	public function __construct(
		public readonly ?int $id,
		public readonly string $task_uuid,
		public readonly int $organisation_id,
		public readonly int $scope_id,
		public readonly int $finding_id,
		public readonly string $rule_id,
		public readonly string $title,
		public readonly TechnicalSubject $technical_subject,
		public readonly PriorityBand $priority_band,
		public readonly int $priority_score,
		public readonly array $priority_explanation,
		public readonly int $recommended_order,
		public readonly ?string $rationale,
		public readonly array $implementation_steps,
		public readonly array $validation_steps,
		public readonly array $dependencies,
		public readonly ?string $suggested_owner_type,
		public readonly ?string $estimated_effort_band,
		public readonly ?\DateTimeImmutable $target_date,
		public readonly bool $reminder_requested,
		public readonly RemediationTaskStatus $status,
		public readonly ?string $customer_notes,
		public readonly ?string $operator_notes,
		public readonly ?\DateTimeImmutable $completed_at,
		public readonly ?\DateTimeImmutable $created_at = null,
		public readonly ?\DateTimeImmutable $updated_at = null,
		public readonly ?int $reminder_days_before = null
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values, JSON columns as strings).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			task_uuid: (string) $row['task_uuid'],
			organisation_id: (int) $row['organisation_id'],
			scope_id: (int) $row['scope_id'],
			finding_id: (int) $row['finding_id'],
			rule_id: (string) $row['rule_id'],
			title: (string) $row['title'],
			technical_subject: TechnicalSubject::from( (string) $row['technical_subject'] ),
			priority_band: PriorityBand::from( (string) $row['priority_band'] ),
			priority_score: (int) $row['priority_score'],
			priority_explanation: self::decode( $row['priority_explanation'] ?? null ),
			recommended_order: (int) $row['recommended_order'],
			rationale: $row['rationale'] ?? null,
			implementation_steps: self::decode( $row['implementation_steps'] ?? null ),
			validation_steps: self::decode( $row['validation_steps'] ?? null ),
			dependencies: self::decode( $row['dependencies'] ?? null ),
			suggested_owner_type: $row['suggested_owner_type'] ?? null,
			estimated_effort_band: $row['estimated_effort_band'] ?? null,
			target_date: ! empty( $row['target_date'] ) ? new \DateTimeImmutable( (string) $row['target_date'] ) : null,
			reminder_requested: ! empty( $row['reminder_requested'] ),
			status: RemediationTaskStatus::from( (string) $row['status'] ),
			customer_notes: $row['customer_notes'] ?? null,
			operator_notes: $row['operator_notes'] ?? null,
			completed_at: ! empty( $row['completed_at'] ) ? new \DateTimeImmutable( (string) $row['completed_at'] ) : null,
			created_at: isset( $row['created_at'] ) ? new \DateTimeImmutable( (string) $row['created_at'] ) : null,
			updated_at: isset( $row['updated_at'] ) ? new \DateTimeImmutable( (string) $row['updated_at'] ) : null,
			reminder_days_before: isset( $row['reminder_days_before'] ) ? (int) $row['reminder_days_before'] : null
		);
	}

	/**
	 * @return array<int|string,mixed>
	 */
	private static function decode( mixed $json ): array {
		if ( ! is_string( $json ) || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}
}
