<?php
/**
 * Evaluation handlers for HTTP/web security-header rules (Section 13, category "web").
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules\Handlers;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Rules\EvidenceAccessor;
use Alltime\WPReconnaissance\Rules\RuleDefinition;
use Alltime\WPReconnaissance\Rules\RuleHandlerInterface;
use Alltime\WPReconnaissance\Rules\RuleResult;

final class WebRuleHandlers implements RuleHandlerInterface {

	public function evaluate( RuleDefinition $rule, array $evidence, Scope $scope ): ?RuleResult {
		if ( ! EvidenceAccessor::usable( $evidence, 'http' ) ) {
			return null;
		}

		$data = EvidenceAccessor::data( $evidence, 'http' );

		return match ( $rule->rule_id ) {
			'WEB.HTTPS.UNAVAILABLE' => $this->https_unavailable( $data ),
			'WEB.HTTP.NO_HTTPS_REDIRECT' => $this->no_https_redirect( $data ),
			'WEB.HSTS.MISSING' => $this->hsts_missing( $data ),
			'WEB.HSTS.WEAK' => $this->hsts_weak( $data ),
			'WEB.CSP.MISSING' => $this->csp_missing( $data ),
			default => null,
		};
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function https_unavailable( array $data ): ?RuleResult {
		if ( true === ( $data['https_available'] ?? true ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'https_available' => true ), array( 'https_available' => false ), array( 'http' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function no_https_redirect( array $data ): ?RuleResult {
		if ( true !== ( $data['https_available'] ?? false ) || true === ( $data['http_redirects_to_https'] ?? false ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'http_redirects_to_https' => true ), array( 'http_redirects_to_https' => false ), array( 'http' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function hsts_missing( array $data ): ?RuleResult {
		if ( true !== ( $data['https_available'] ?? false ) || true === ( $data['hsts']['present'] ?? false ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'hsts' => 'present' ), array( 'hsts' => $data['hsts'] ?? null ), array( 'http' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function hsts_weak( array $data ): ?RuleResult {
		$hsts = $data['hsts'] ?? array();

		if ( true !== ( $data['https_available'] ?? false ) || true !== ( $hsts['present'] ?? false ) || true !== ( $hsts['weak'] ?? false ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'max_age' => '>= 15552000' ), array( 'max_age' => $hsts['max_age'] ?? 0 ), array( 'http' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function csp_missing( array $data ): ?RuleResult {
		$csp = $data['csp'] ?? array();

		if ( true !== ( $data['https_available'] ?? false ) || true === ( $csp['present'] ?? false ) || true === ( $csp['report_only'] ?? false ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'csp' => 'present' ), array( 'csp' => $csp ), array( 'http' ) );
	}
}
