<?php
/**
 * Evaluation handlers for mail-authentication rules (Section 13, category "mail").
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules\Handlers;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Rules\EvidenceAccessor;
use Alltime\WPReconnaissance\Rules\RuleDefinition;
use Alltime\WPReconnaissance\Rules\RuleHandlerInterface;
use Alltime\WPReconnaissance\Rules\RuleResult;

final class MailRuleHandlers implements RuleHandlerInterface {

	public function evaluate( RuleDefinition $rule, array $evidence, Scope $scope ): ?RuleResult {
		if ( ! EvidenceAccessor::usable( $evidence, 'mail' ) ) {
			return null;
		}

		$data = EvidenceAccessor::data( $evidence, 'mail' );

		return match ( $rule->rule_id ) {
			'MAIL.MX.MISSING' => $this->mx_missing( $data ),
			'MAIL.SPF.MISSING' => $this->spf_missing( $data ),
			'MAIL.SPF.PERMISSIVE' => $this->spf_permissive( $data ),
			'MAIL.SPF.LOOKUP_LIMIT' => $this->spf_lookup_limit( $data ),
			'MAIL.DMARC.MISSING' => $this->dmarc_missing( $data ),
			'MAIL.DMARC.MONITOR_ONLY' => $this->dmarc_monitor_only( $data ),
			'MAIL.DMARC.PCT_PARTIAL' => $this->dmarc_pct_partial( $data ),
			'MAIL.DKIM.SELECTOR_NOT_OBSERVABLE' => $this->dkim_selector_not_observable( $data ),
			'MAIL.DKIM.KEY_REVOKED' => $this->dkim_key_revoked( $data ),
			default => null,
		};
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function mx_missing( array $data ): ?RuleResult {
		$hosts = array_filter( (array) ( $data['mx_hosts'] ?? array() ), static fn ( $host ): bool => '' !== $host && '.' !== $host );

		if ( count( $hosts ) > 0 ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'mx' => 'present' ), array( 'mx_hosts' => $data['mx_hosts'] ?? array() ), array( 'mail' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function spf_missing( array $data ): ?RuleResult {
		if ( ! empty( $data['spf']['record'] ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'spf' => 'present' ), array( 'spf' => $data['spf'] ?? null ), array( 'mail' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function spf_permissive( array $data ): ?RuleResult {
		$all_mechanism = $data['spf']['all_mechanism'] ?? null;

		if ( ! in_array( $all_mechanism, array( '+all', 'all' ), true ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'all_mechanism' => '-all or ~all' ), array( 'all_mechanism' => $all_mechanism ), array( 'mail' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function spf_lookup_limit( array $data ): ?RuleResult {
		$count = (int) ( $data['spf']['lookup_count'] ?? 0 );

		if ( $count <= 10 ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'lookup_count' => '<= 10' ), array( 'lookup_count' => $count ), array( 'mail' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function dmarc_missing( array $data ): ?RuleResult {
		if ( null !== ( $data['dmarc'] ?? null ) ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'dmarc' => 'present' ), array( 'dmarc' => null ), array( 'mail' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function dmarc_monitor_only( array $data ): ?RuleResult {
		$policy = $data['dmarc']['policy'] ?? null;

		if ( 'none' !== $policy ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'policy' => 'quarantine or reject' ), array( 'policy' => $policy ), array( 'mail' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function dmarc_pct_partial( array $data ): ?RuleResult {
		if ( null === ( $data['dmarc'] ?? null ) ) {
			return null;
		}

		$pct = (int) ( $data['dmarc']['pct'] ?? 100 );

		if ( $pct >= 100 ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'pct' => 100 ), array( 'pct' => $pct ), array( 'mail' ) );
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function dkim_selector_not_observable( array $data ): ?RuleResult {
		$selectors      = (array) ( $data['dkim'] ?? array() );
		$not_observable = array_filter( $selectors, static fn ( array $entry ): bool => 'not_observable' === ( $entry['status'] ?? null ) );

		if ( 0 === count( $selectors ) || 0 === count( $not_observable ) ) {
			return null;
		}

		// Section 12.1/13.2: absence of an observable DKIM selector is never confirmed absence.
		return new RuleResult(
			Confidence::Low,
			array( 'dkim' => 'observable' ),
			array( 'selectors' => array_column( $not_observable, 'selector' ) ),
			array( 'mail' )
		);
	}

	/**
	 * @param array<string,mixed> $data
	 */
	private function dkim_key_revoked( array $data ): ?RuleResult {
		$selectors = (array) ( $data['dkim'] ?? array() );
		$revoked   = array_filter( $selectors, static fn ( array $entry ): bool => true === ( $entry['revoked'] ?? false ) );

		if ( 0 === count( $revoked ) ) {
			return null;
		}

		return new RuleResult(
			Confidence::Confirmed,
			array( 'dkim' => 'active_key' ),
			array( 'revoked_selectors' => array_column( $revoked, 'selector' ) ),
			array( 'mail' )
		);
	}
}
