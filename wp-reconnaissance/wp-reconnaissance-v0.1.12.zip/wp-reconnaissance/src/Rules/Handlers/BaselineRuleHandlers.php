<?php
/**
 * Evaluation handlers comparing observed evidence against a scope's declared baseline
 * ({@see \Alltime\WPReconnaissance\Domain\Scope::$expected_state}, Section 33 "baselines and
 * expected state") rather than a rule-intrinsic literal.
 *
 * A baseline key that has never been set (a customer/operator has not yet adopted a current
 * state as their expectation, via `BaselineCaptureService`) must never be treated as "expected
 * empty" - these rules simply do not fire until a baseline exists for that key, exactly like an
 * unusable collector (Section 11: absence and non-applicability must never share a
 * representation).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules\Handlers;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Rules\EvidenceAccessor;
use Alltime\WPReconnaissance\Rules\RuleDefinition;
use Alltime\WPReconnaissance\Rules\RuleHandlerInterface;
use Alltime\WPReconnaissance\Rules\RuleResult;

final class BaselineRuleHandlers implements RuleHandlerInterface {

	public function evaluate( RuleDefinition $rule, array $evidence, Scope $scope ): ?RuleResult {
		return match ( $rule->rule_id ) {
			'BASELINE.RDAP.NAMESERVERS_CHANGED' => $this->nameservers_changed( $evidence, $scope ),
			'BASELINE.MAIL.MX_CHANGED' => $this->mx_changed( $evidence, $scope ),
			'BASELINE.TLS.ISSUER_CHANGED' => $this->issuer_changed( $evidence, $scope ),
			default => null,
		};
	}

	private function nameservers_changed( array $evidence, Scope $scope ): ?RuleResult {
		$expected = $scope->expected_state['rdap']['nameservers'] ?? null;

		if ( ! is_array( $expected ) || array() === $expected || ! EvidenceAccessor::usable( $evidence, 'rdap' ) ) {
			return null;
		}

		$observed = (array) ( EvidenceAccessor::data( $evidence, 'rdap' )['nameservers'] ?? array() );

		if ( $this->as_sorted_strings( $expected ) === $this->as_sorted_strings( $observed ) ) {
			return null;
		}

		return new RuleResult(
			Confidence::Confirmed,
			array( 'nameservers' => array_values( $expected ) ),
			array( 'nameservers' => array_values( $observed ) ),
			array( 'rdap' )
		);
	}

	private function mx_changed( array $evidence, Scope $scope ): ?RuleResult {
		$expected = $scope->expected_state['mail']['mx_hosts'] ?? null;

		if ( ! is_array( $expected ) || array() === $expected || ! EvidenceAccessor::usable( $evidence, 'mail' ) ) {
			return null;
		}

		$observed = (array) ( EvidenceAccessor::data( $evidence, 'mail' )['mx_hosts'] ?? array() );

		if ( $this->as_sorted_strings( $expected ) === $this->as_sorted_strings( $observed ) ) {
			return null;
		}

		return new RuleResult(
			Confidence::Confirmed,
			array( 'mx_hosts' => array_values( $expected ) ),
			array( 'mx_hosts' => array_values( $observed ) ),
			array( 'mail' )
		);
	}

	private function issuer_changed( array $evidence, Scope $scope ): ?RuleResult {
		$expected = $scope->expected_state['tls']['issuer'] ?? null;

		if ( ! is_string( $expected ) || '' === $expected || ! EvidenceAccessor::usable( $evidence, 'tls' ) ) {
			return null;
		}

		$data = EvidenceAccessor::data( $evidence, 'tls' );

		if ( empty( $data['certificate']['connected'] ) ) {
			return null;
		}

		$observed = (string) ( $data['certificate']['issuer'] ?? '' );

		if ( $expected === $observed ) {
			return null;
		}

		return new RuleResult(
			Confidence::Confirmed,
			array( 'issuer' => $expected ),
			array( 'issuer' => $observed ),
			array( 'tls' )
		);
	}

	/**
	 * @param array<int|string,mixed> $values
	 * @return string[]
	 */
	private function as_sorted_strings( array $values ): array {
		$strings = array_map( static fn ( $value ): string => strtolower( (string) $value ), $values );
		sort( $strings );

		return $strings;
	}
}
