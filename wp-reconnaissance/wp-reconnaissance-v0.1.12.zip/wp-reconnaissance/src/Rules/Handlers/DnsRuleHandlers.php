<?php
/**
 * Evaluation handlers for DNS-related rules (Section 13, category "dns").
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules\Handlers;

use Alltime\WPReconnaissance\Domain\Enums\Confidence;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Rules\EvidenceAccessor;
use Alltime\WPReconnaissance\Rules\RuleDefinition;
use Alltime\WPReconnaissance\Rules\RuleHandlerInterface;
use Alltime\WPReconnaissance\Rules\RuleResult;

final class DnsRuleHandlers implements RuleHandlerInterface {

	public function evaluate( RuleDefinition $rule, array $evidence, Scope $scope ): ?RuleResult {
		return match ( $rule->rule_id ) {
			'DNS.CAA.MISSING' => $this->caa_missing( $evidence ),
			'DNS.DNSSEC.INSECURE' => $this->dnssec_state( $evidence, 'insecure', Confidence::Medium ),
			'DNS.DNSSEC.BOGUS' => $this->dnssec_state( $evidence, 'bogus', Confidence::High ),
			default => null,
		};
	}

	private function caa_missing( array $evidence ): ?RuleResult {
		if ( ! EvidenceAccessor::usable( $evidence, 'dns' ) ) {
			return null;
		}

		$data = EvidenceAccessor::data( $evidence, 'dns' );

		// null means the collecting PHP build doesn't support CAA lookups at all - that is
		// "not observable", never "missing" (Section 11: absence and non-applicability must
		// never share a representation).
		if ( ! array_key_exists( 'caa', $data ) || null === $data['caa'] ) {
			return null;
		}

		if ( count( (array) $data['caa'] ) > 0 ) {
			return null;
		}

		return new RuleResult( Confidence::Confirmed, array( 'caa' => 'present' ), array( 'caa' => array() ), array( 'dns' ) );
	}

	private function dnssec_state( array $evidence, string $expected_state, Confidence $confidence ): ?RuleResult {
		if ( ! EvidenceAccessor::usable( $evidence, 'dnssec' ) ) {
			return null;
		}

		$data = EvidenceAccessor::data( $evidence, 'dnssec' );

		if ( ( $data['state'] ?? null ) !== $expected_state ) {
			return null;
		}

		return new RuleResult( $confidence, array( 'state' => 'validated' ), array( 'state' => $data['state'] ), array( 'dnssec' ) );
	}
}
