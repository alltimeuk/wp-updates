<?php
/**
 * Adopts a scope's most recently observed state as its baseline (Section 33 "baselines and
 * expected state") - the practical way a customer or operator establishes what
 * {@see \Alltime\WPReconnaissance\Domain\Scope::$expected_state} means for a scope, rather than
 * hand-authoring the JSON structure {@see \Alltime\WPReconnaissance\Rules\Handlers\BaselineRuleHandlers}
 * compares against.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

use Alltime\WPReconnaissance\Data\EvidenceStorage;
use Alltime\WPReconnaissance\Data\Repositories\ObservationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Scope;

final class BaselineCaptureService {

	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly ObservationRepository $observations = new ObservationRepository(),
		private readonly EvidenceStorage $evidence_storage = new EvidenceStorage()
	) {}

	/**
	 * Only overwrites a baseline key when its collector actually succeeded in the latest
	 * observation - a collector that failed or was skipped leaves whatever baseline already
	 * existed for that key untouched, rather than silently disabling the corresponding rule.
	 *
	 * @throws BaselineCaptureException When the scope is unknown, or has no observation with
	 *                                    retrievable evidence to capture a baseline from yet.
	 */
	public function capture_from_latest_observation( int $scope_id ): Scope {
		$scope = $this->scopes->find( $scope_id );

		if ( null === $scope ) {
			throw new BaselineCaptureException( esc_html( "Scope {$scope_id} was not found." ) );
		}

		$observation = $this->observations->find_latest_by_scope( $scope_id );

		if ( null === $observation || null === $observation->raw_evidence_ref ) {
			throw new BaselineCaptureException( esc_html( 'This scope has no completed observation to capture a baseline from yet.' ) );
		}

		$evidence_json = $this->evidence_storage->retrieve( $observation->raw_evidence_ref );
		$evidence      = null !== $evidence_json ? json_decode( $evidence_json, true ) : null;

		if ( ! is_array( $evidence ) ) {
			throw new BaselineCaptureException( esc_html( 'The latest observation for this scope has no retrievable evidence.' ) );
		}

		$expected_state = $scope->expected_state;

		if ( EvidenceAccessor::usable( $evidence, 'rdap' ) ) {
			$expected_state['rdap']['nameservers'] = array_values(
				array_filter( (array) ( EvidenceAccessor::data( $evidence, 'rdap' )['nameservers'] ?? array() ) )
			);
		}

		if ( EvidenceAccessor::usable( $evidence, 'mail' ) ) {
			$expected_state['mail']['mx_hosts'] = array_values(
				array_filter( (array) ( EvidenceAccessor::data( $evidence, 'mail' )['mx_hosts'] ?? array() ) )
			);
		}

		if ( EvidenceAccessor::usable( $evidence, 'tls' ) ) {
			$tls_data = EvidenceAccessor::data( $evidence, 'tls' );

			if ( ! empty( $tls_data['certificate']['connected'] ) && ! empty( $tls_data['certificate']['issuer'] ) ) {
				$expected_state['tls']['issuer'] = (string) $tls_data['certificate']['issuer'];
			}
		}

		return $this->scopes->update_expected_state( $scope_id, $expected_state );
	}
}
