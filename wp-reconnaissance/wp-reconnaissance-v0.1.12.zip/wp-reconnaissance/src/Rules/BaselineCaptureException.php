<?php
/**
 * Thrown when a scope's current state cannot be captured as a baseline (unknown scope, or no
 * observation with usable evidence exists yet).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

final class BaselineCaptureException extends \RuntimeException {}
