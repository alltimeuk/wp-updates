<?php
/**
 * Contract for a rule's evaluation handler, per Section 13.
 *
 * Handlers are looked up by the `evaluation.handler` identifier in the rule definition. Kept
 * as small, named, testable units rather than embedding scoring logic in collectors.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Rules;

use Alltime\WPReconnaissance\Domain\Scope;

interface RuleHandlerInterface {

	/**
	 * Evaluates a rule against a normalised evidence document. `$scope` carries the scope's
	 * declared baseline ({@see Scope::$expected_state}, Section 33) for handlers that compare
	 * observed evidence against a customer/operator-declared expectation rather than (or in
	 * addition to) a rule-intrinsic literal - most handlers ignore it entirely.
	 *
	 * @param array<string,mixed> $evidence Decoded evidence.schema.json document for one observation.
	 */
	public function evaluate( RuleDefinition $rule, array $evidence, Scope $scope ): ?RuleResult;
}
