<?php
/**
 * `wp reconnaissance run <scope-id>`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Assessment\AssessmentException;
use Alltime\WPReconnaissance\Assessment\AssessmentService;
use Alltime\WPReconnaissance\Domain\Enums\JobStatus;

use const Alltime\WPReconnaissance\WPR_SCHEMA_VERSION;

final class ReconnaissanceCommand {

	/**
	 * Runs a manual assessment for a scope synchronously and reports the outcome. WP-CLI is not
	 * an HTTP request, so running it inline here does not conflict with Section 15's
	 * requirement to keep *web* requests short.
	 *
	 * ## OPTIONS
	 *
	 * <scope-id>
	 * : The numeric ID of the scope to assess.
	 *
	 * @param string[] $args
	 */
	public function run( array $args ): void {
		$scope_id = isset( $args[0] ) ? (int) $args[0] : 0;

		if ( $scope_id <= 0 ) {
			\WP_CLI::error( 'Usage: wp reconnaissance run <scope-id>' );
			return;
		}

		try {
			$job = ( new AssessmentService() )->run( $scope_id, $this->current_actor_id() );
		} catch ( AssessmentException $exception ) {
			\WP_CLI::error( $exception->getMessage() );
			return;
		}

		$fields = array(
			'job_id'         => $job->job_uuid,
			'status'         => $job->status->value,
			'error_category' => $job->error_category ?? '',
			'exit_code'      => (string) ( $job->exit_code ?? '' ),
		);

		foreach ( $fields as $label => $value ) {
			\WP_CLI::log( "{$label}: {$value}" );
		}

		match ( $job->status ) {
			JobStatus::Succeeded, JobStatus::PartiallySucceeded => \WP_CLI::success( "Assessment finished with status {$job->status->value}." ),
			default => \WP_CLI::warning( "Assessment did not succeed (status: {$job->status->value})." ),
		};
	}

	/**
	 * Reports the stored database schema version and, if a migration is currently failing, the
	 * same safe classification/occurrence detail Site Health shows (Section 7) - never the raw
	 * database error.
	 */
	public function status(): void {
		$current = (int) get_option( 'wpr_db_schema_version', 0 );

		\WP_CLI::log( "Schema version: {$current} / " . WPR_SCHEMA_VERSION );

		$failure = get_option( 'wpr_migration_failure', null );

		if ( ! is_array( $failure ) ) {
			\WP_CLI::success( 'No recorded schema upgrade failure.' );
			return;
		}

		\WP_CLI\Utils\format_items( 'table', array( array_map( 'strval', $failure ) ), array_keys( $failure ) );
		\WP_CLI::error( 'The database schema upgrade is currently failing. It will keep retrying automatically.' );
	}

	private function current_actor_id(): ?int {
		$user_id = get_current_user_id();

		return $user_id > 0 ? $user_id : null;
	}
}
