<?php
/**
 * `wp reconnaissance schedule run`, per Section 33 and Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;

final class ScheduledAssessmentCommand {

	/**
	 * Runs the same due-assessment sweep the daily maintenance cron already runs automatically -
	 * this command is for triggering it on demand, or previewing what it would dispatch.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : List scopes currently due for assessment without dispatching them.
	 *
	 * ## EXAMPLES
	 *
	 *     wp reconnaissance schedule run --dry-run
	 *     wp reconnaissance schedule run
	 *
	 * @param array<string,string> $assoc_args
	 */
	public function run( array $args = array(), array $assoc_args = array() ): void {
		if ( isset( $assoc_args['dry-run'] ) ) {
			$this->preview();
			return;
		}

		( new SchedulingBootstrap() )->run_due_assessments();

		\WP_CLI::success( 'Due-assessment sweep complete.' );
	}

	private function preview(): void {
		$max = (int) get_option( 'wpr_max_scheduled_assessments_per_sweep', 50 );
		$due = ( new ScopeRepository() )->find_due_for_assessment( $max );

		if ( array() === $due ) {
			\WP_CLI::log( 'No scopes are currently due for assessment.' );
			return;
		}

		\WP_CLI\Utils\format_items(
			'table',
			array_map(
				static fn ( $scope ): array => array(
					'id'     => (string) $scope->id,
					'domain' => $scope->domain_display,
					'due_at' => $scope->next_assessment_due_at?->format( 'Y-m-d H:i:s' ) ?? '',
				),
				$due
			),
			array( 'id', 'domain', 'due_at' )
		);
	}
}
