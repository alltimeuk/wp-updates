<?php
/**
 * `wp reconnaissance retention run`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Retention\RetentionService;

final class RetentionCommand {

	public function __construct(
		private readonly RetentionService $retention = new RetentionService()
	) {}

	/**
	 * Executes retention and deletion rules immediately (Section 26.7) - the same sweep the
	 * daily maintenance cron already runs automatically once the plugin is active; this command
	 * is for triggering it on demand (e.g. right after changing a `wpr_retention_*_days` option)
	 * rather than waiting for the next scheduled run.
	 */
	public function run(): void {
		$summary = $this->retention->run_sweep();

		\WP_CLI\Utils\format_items(
			'table',
			array_map(
				static fn ( string $category, int $count ): array => array(
					'category' => $category,
					'removed'  => (string) $count,
				),
				array_keys( $summary ),
				array_values( $summary )
			),
			array( 'category', 'removed' )
		);

		\WP_CLI::success( 'Retention sweep complete.' );
	}
}
