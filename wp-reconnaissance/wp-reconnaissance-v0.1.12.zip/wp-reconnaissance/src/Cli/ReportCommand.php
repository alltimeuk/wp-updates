<?php
/**
 * `wp reconnaissance report ...`, per Section 24.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Cli;

use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Reports\DomainReconnaissanceReportBuilder;
use Alltime\WPReconnaissance\Reports\RemediationTaskGenerator;
use Alltime\WPReconnaissance\Reports\ReportException;

final class ReportCommand {

	public function __construct(
		private readonly DomainReconnaissanceReportBuilder $report_builder = new DomainReconnaissanceReportBuilder(),
		private readonly RemediationTaskGenerator $task_generator = new RemediationTaskGenerator(),
		private readonly ReportRepository $reports = new ReportRepository()
	) {}

	/**
	 * Refreshes the scope's remediation tasks and issues a new report version, per Section 19.6's
	 * generate/review/issue workflow collapsed into a single command.
	 *
	 * ## OPTIONS
	 *
	 * <scope-id>
	 * : The numeric ID of the scope to report on.
	 *
	 * [--executive-summary=<text>]
	 * : Operator-authored executive summary. When omitted, a short factual summary is generated
	 * instead (Section 19.6's own authoring step still applies for a customer-facing report - use
	 * this flag, or edit the issued report's document directly, when one is needed).
	 *
	 * @param string[]             $args
	 * @param array<string,string> $assoc_args
	 */
	public function generate( array $args, array $assoc_args = array() ): void {
		if ( empty( $args[0] ) || ! ctype_digit( $args[0] ) ) {
			\WP_CLI::error( 'Usage: wp reconnaissance report generate <scope-id> [--executive-summary=<text>]' );
			return;
		}

		$scope_id = (int) $args[0];

		$this->task_generator->generate_for_scope( $scope_id );

		try {
			$document = $this->report_builder->generate( $scope_id, $assoc_args['executive-summary'] ?? null );
		} catch ( ReportException $exception ) {
			\WP_CLI::error( $exception->getMessage() );
			return;
		}

		$report = $this->reports->save(
			(int) $document['organisation_id'],
			$scope_id,
			(int) $document['observation_id'],
			(int) $document['version'],
			$document,
			null
		);

		\WP_CLI::success( "Report #{$report->id} issued for scope {$scope_id} (version {$report->version})." );
	}
}
