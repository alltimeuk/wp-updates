<?php
/**
 * Pure date arithmetic for recurring assessment schedules, per Section 33.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Scheduling;

use Alltime\WPReconnaissance\Domain\Enums\ScheduleFrequency;

final class NextOccurrenceCalculator {

	/**
	 * The next time a scope on the given cadence should be assessed after `$from`. `Manual`
	 * scopes never recur automatically, so this returns null rather than a sentinel date.
	 */
	public function next( ScheduleFrequency $frequency, \DateTimeImmutable $from ): ?\DateTimeImmutable {
		return match ( $frequency ) {
			ScheduleFrequency::Daily   => $from->modify( '+1 day' ),
			ScheduleFrequency::Weekly  => $from->modify( '+7 days' ),
			ScheduleFrequency::Monthly => $this->add_calendar_month( $from ),
			ScheduleFrequency::Manual  => null,
		};
	}

	/**
	 * `modify('+1 month')` overflows short months (Jan 31 -> Mar 3), because DateTime first adds
	 * a full month of days and only then normalises. This instead advances to the target month
	 * directly and clamps the day-of-month to that month's actual length (Jan 31 -> Feb 28/29).
	 */
	private function add_calendar_month( \DateTimeImmutable $from ): \DateTimeImmutable {
		$first_of_next_month  = ( new \DateTimeImmutable( $from->format( 'Y-m-01 H:i:s' ) ) )->modify( '+1 month' );
		$days_in_target_month = (int) $first_of_next_month->format( 't' );
		$day                  = min( (int) $from->format( 'd' ), $days_in_target_month );

		return $first_of_next_month->setDate(
			(int) $first_of_next_month->format( 'Y' ),
			(int) $first_of_next_month->format( 'm' ),
			$day
		);
	}
}
