<?php
/**
 * Scheduling module bootstrap, per Section 15.
 *
 * Durable execution must not rely solely on a single WP-Cron callback. This registers the
 * Action Scheduler hook this plugin will use once job dispatch is implemented; if Action
 * Scheduler is not available (it ships bundled with WooCommerce/Action Scheduler-aware
 * plugins, or must be required as a Composer dependency), the plugin falls back to WP-Cron and
 * an administrator-visible warning rather than failing silently.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Scheduling;

use Alltime\WPReconnaissance\Assessment\AssessmentService;
use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ProfileRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Enums\ScheduleFrequency;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Entitlements\PlanRepository;
use Alltime\WPReconnaissance\Notifications\MailQueueService;
use Alltime\WPReconnaissance\Notifications\NotificationDigestService;
use Alltime\WPReconnaissance\Notifications\NotificationDispatcher;
use Alltime\WPReconnaissance\Diagnostics\SiteHealthChecks;
use Alltime\WPReconnaissance\Reports\ReportPdfService;
use Alltime\WPReconnaissance\Retention\RetentionService;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Support\StorageExposureGuard;

final class SchedulingBootstrap {

	public const RUN_DUE_ASSESSMENTS_HOOK = 'wpr_run_due_assessments';

	/**
	 * A single on-demand assessment run, queued rather than invoked directly: Section 15
	 * requires PHP web requests to stay short, so the admin "run now" action and the REST
	 * "dispatch job" endpoint both queue this hook instead of calling
	 * {@see AssessmentService::run()} inline from the HTTP request that triggered them.
	 */
	public const DISPATCH_ASSESSMENT_HOOK = 'wpr_dispatch_assessment';

	/** A single queued mail send, immediate or backoff-delayed - see {@see schedule_mail_send()}. */
	public const SEND_MAIL_HOOK = 'wpr_send_queued_mail';

	/**
	 * Queued PDF generation for an issued report (Section 21.2). PDF rendering is slow, so it
	 * runs off the HTTP request that issued the report, never inline from it.
	 */
	public const GENERATE_REPORT_PDF_HOOK = 'wpr_generate_report_pdf';

	/** Daily housekeeping: retention sweep, authorisation-expiry check, mail queue retry sweep. */
	public const DAILY_MAINTENANCE_HOOK = 'wpr_run_daily_maintenance';

	/**
	 * Every service used below is constructed fresh per call, matching
	 * {@see dispatch_assessment()}'s existing style, rather than constructor-injected - this
	 * class is purely async-execution glue, never held onto as a long-lived collaborator itself,
	 * so there is no reuse to gain and constructor injection here would only invite a circular
	 * default-parameter relationship with services (like MailQueueService) that need to schedule
	 * work back through this same class.
	 */
	public function boot(): void {
		add_action( self::RUN_DUE_ASSESSMENTS_HOOK, array( $this, 'run_due_assessments' ) );
		add_action( self::DISPATCH_ASSESSMENT_HOOK, array( $this, 'dispatch_assessment' ), 10, 2 );
		add_action( self::SEND_MAIL_HOOK, array( $this, 'send_queued_mail' ) );
		add_action( self::GENERATE_REPORT_PDF_HOOK, array( $this, 'generate_report_pdf' ) );
		add_action( self::DAILY_MAINTENANCE_HOOK, array( $this, 'run_daily_maintenance' ) );
		add_action( StorageExposureGuard::PROBE_HOOK, array( $this, 'probe_storage_exposure' ) );

		add_action( 'wpr_report_issued', array( $this, 'schedule_report_pdf' ) );

		add_action( 'admin_init', array( $this, 'maybe_warn_missing_durable_queue' ) );
		add_action( 'init', array( $this, 'ensure_daily_maintenance_scheduled' ) );
	}

	/**
	 * Schedules the recurring daily maintenance event on first boot after activation. Idempotent:
	 * wp_next_scheduled() prevents piling up duplicate recurring schedules on every request.
	 */
	public function ensure_daily_maintenance_scheduled(): void {
		if ( false === wp_next_scheduled( self::DAILY_MAINTENANCE_HOOK ) ) {
			wp_schedule_event( time(), 'daily', self::DAILY_MAINTENANCE_HOOK );
		}
	}

	/**
	 * Queues a single assessment run for a scope, using Action Scheduler when available (durable,
	 * survives beyond a single WP-Cron tick) and falling back to a one-off WP-Cron event
	 * otherwise. Returns immediately - the caller never waits on the run itself.
	 */
	public function schedule_assessment( int $scope_id, ?int $actor_id = null ): void {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::DISPATCH_ASSESSMENT_HOOK, array( $scope_id, $actor_id ), 'wp-reconnaissance' );
			return;
		}

		wp_schedule_single_event( time(), self::DISPATCH_ASSESSMENT_HOOK, array( $scope_id, $actor_id ) );
	}

	/**
	 * The Action Scheduler/WP-Cron callback for a single dispatched assessment - isolated in its
	 * own try/catch so a failure here (e.g. a database hiccup persisting a finding) is recorded
	 * rather than surfacing as an uncaught fatal with no operator-visible trace, matching
	 * {@see run_due_assessments()}'s own per-scope isolation.
	 */
	public function dispatch_assessment( int $scope_id, ?int $actor_id = null ): void {
		try {
			( new AssessmentService() )->run( $scope_id, $actor_id );
		} catch ( \Throwable $e ) {
			( new AuditLogger() )->log(
				'job.dispatch_failed',
				'scope',
				$scope_id,
				$actor_id,
				outcome: 'failure',
				summary: $e->getMessage(),
				source: 'cron'
			);
		}
	}

	/**
	 * Queues one already-persisted mail-queue row for sending, immediately or (for a bounded
	 * retry backoff, Section 22.5) at a specific future time.
	 */
	public function schedule_mail_send( int $message_id, ?\DateTimeImmutable $at = null ): void {
		$timestamp = $at?->getTimestamp() ?? time();

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( $timestamp, self::SEND_MAIL_HOOK, array( $message_id ), 'wp-reconnaissance' );
			return;
		}

		wp_schedule_single_event( $timestamp, self::SEND_MAIL_HOOK, array( $message_id ) );
	}

	public function send_queued_mail( int $message_id ): void {
		( new MailQueueService() )->send_now( $message_id );
	}

	/**
	 * Queues PDF generation for a just-issued report, using Action Scheduler when available
	 * (durable, survives beyond a single WP-Cron tick) and falling back to a one-off WP-Cron
	 * event otherwise. Returns immediately - the caller never waits on the render.
	 */
	public function schedule_report_pdf( int $report_id ): void {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::GENERATE_REPORT_PDF_HOOK, array( $report_id ), 'wp-reconnaissance' );
			return;
		}

		wp_schedule_single_event( time(), self::GENERATE_REPORT_PDF_HOOK, array( $report_id ) );
	}

	/** Generates and stores the PDF for an issued report (async worker, Section 21.2). */
	public function generate_report_pdf( int $report_id ): void {
		( new ReportPdfService() )->generate_for_report( $report_id );
	}

	/**
	 * Scheduled by {@see StorageExposureGuard::assert_not_exposed()} the moment a write is
	 * refused for lack of a recent verdict, so that gap is bounded to roughly one cron tick rather
	 * than passively waiting on an admin to open Site Health or on WordPress's own weekly
	 * background check. Both calls already record their result via
	 * {@see StorageExposureGuard::record_probe_result()} internally - no separate probe logic
	 * needed here, this just runs the same checks Site Health itself runs from a cron context.
	 */
	public function probe_storage_exposure(): void {
		( new SiteHealthChecks() )->check_evidence_storage();
		( new SiteHealthChecks() )->check_report_storage();
	}

	/**
	 * Daily housekeeping (Section 26.7 retention, Section 22.5 notification triggers that need
	 * periodic scanning rather than firing from a single event, and the mail queue's own retry
	 * sweep for anything a delayed action failed to pick up).
	 */
	public function run_daily_maintenance(): void {
		( new RetentionService() )->run_sweep();
		$dispatcher = new NotificationDispatcher();
		$dispatcher->check_expiring_authorisations();
		$dispatcher->check_task_reminders();
		$this->run_due_assessments();
		( new NotificationDigestService() )->send_due_digests();

		foreach ( ( new MailQueueService() )->due_message_ids() as $message_id ) {
			$this->schedule_mail_send( $message_id );
		}
	}

	/**
	 * Dispatches assessments for scopes whose recurring schedule (Section 33) is due. Runs as
	 * part of {@see run_daily_maintenance()}'s single daily sweep - schedules are coarse-grained
	 * (daily/weekly/monthly), so a once-a-day due-check is precise enough without a second cron
	 * registration. The `RUN_DUE_ASSESSMENTS_HOOK` action stays registered standalone so an
	 * operator can also trigger it on demand via WP-CLI.
	 *
	 * Two passes, both capped by `wpr_max_scheduled_assessments_per_sweep` (default 50) so a
	 * single tick can never dispatch an unbounded number of jobs:
	 *
	 * 1. Seed any scope that has never been through a schedule pass with its next due date
	 *    (or leave it null for a manual cadence) - no dispatch happens in this pass, so turning
	 *    schedules on never causes every existing scope to run at once.
	 * 2. Dispatch every scope whose due date has arrived, each isolated in its own try/catch so
	 *    one failing scope never blocks the rest of the batch.
	 */
	public function run_due_assessments(): void {
		$scopes   = new ScopeRepository();
		$profiles = new ProfileRepository();
		$max      = (int) get_option( 'wpr_max_scheduled_assessments_per_sweep', 50 );
		$now      = new \DateTimeImmutable( current_time( 'mysql', true ) );

		foreach ( $scopes->find_needing_schedule_seed( $max ) as $scope ) {
			try {
				$scopes->mark_scheduled( $scope->id, $this->compute_next_due( $scope, $profiles, $now ) );
			} catch ( \Throwable $e ) {
				( new AuditLogger() )->log(
					'schedule.seed_failed',
					'scope',
					$scope->id,
					null,
					outcome: 'failure',
					summary: $e->getMessage(),
					source: 'cron'
				);
			}
		}

		foreach ( $scopes->find_due_for_assessment( $max ) as $scope ) {
			try {
				$this->schedule_assessment( $scope->id, null );
				$scopes->mark_scheduled( $scope->id, $this->compute_next_due( $scope, $profiles, $now ) );
			} catch ( \Throwable $e ) {
				( new AuditLogger() )->log(
					'schedule.assessment_dispatch_failed',
					'scope',
					$scope->id,
					null,
					outcome: 'failure',
					summary: $e->getMessage(),
					source: 'cron'
				);
			}
		}
	}

	/**
	 * A scope's own `monitoring_schedule` overrides the cadence inherited from its monitoring
	 * profile. Unrecognised or absent cadence (including a manual one) yields null, which the
	 * caller persists as-is - a manual-cadence scope legitimately never becomes due.
	 */
	private function compute_next_due( Scope $scope, ProfileRepository $profiles, \DateTimeImmutable $from ): ?\DateTimeImmutable {
		$schedule  = $scope->monitoring_schedule ?? $this->inherited_schedule( $scope, $profiles );
		$frequency = ScheduleFrequency::from_nullable( $schedule );

		if ( null === $frequency ) {
			return null;
		}

		$frequency = ( new ScheduleFrequencyClamp() )->clamp( $frequency, $this->plan_floor( $scope ) );

		return ( new NextOccurrenceCalculator() )->next( $frequency, $from );
	}

	private function inherited_schedule( Scope $scope, ProfileRepository $profiles ): ?string {
		if ( null === $scope->monitoring_profile_id ) {
			return null;
		}

		return $profiles->find( $scope->monitoring_profile_id )?->schedule;
	}

	/**
	 * The fastest cadence the scope's organisation's managed plan (Section 33) permits, or null
	 * for an unrestricted organisation - exactly like today when no plan is assigned.
	 */
	private function plan_floor( Scope $scope ): ?ScheduleFrequency {
		$plan_id = ( new OrganisationRepository() )->find( $scope->organisation_id )?->plan_id;

		if ( null === $plan_id ) {
			return null;
		}

		return ( new PlanRepository() )->find( $plan_id )?->min_schedule_frequency;
	}

	public function maybe_warn_missing_durable_queue(): void {
		if ( function_exists( 'as_schedule_recurring_action' ) ) {
			return;
		}

		add_action(
			'admin_notices',
			static function (): void {
				if ( ! current_user_can( 'activate_plugins' ) ) {
					return;
				}

				printf(
					'<div class="notice notice-warning"><p>%s</p></div>',
					esc_html__( 'WP Reconnaissance works best with Action Scheduler for durable, long-running job execution. It is currently unavailable, so scheduled assessments will fall back to WP-Cron.', 'wp-reconnaissance' )
				);
			}
		);
	}
}
