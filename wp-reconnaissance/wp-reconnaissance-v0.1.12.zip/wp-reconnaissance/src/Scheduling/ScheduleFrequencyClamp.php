<?php
/**
 * Pure clamping of a requested schedule cadence against a managed plan's floor (Section 33
 * "repeat, paid and managed-service entitlements"): a plan's `min_schedule_frequency` is the
 * fastest cadence it permits, so a scope requesting something faster is slowed down to it: a
 * scope requesting something already at or slower than the floor is left untouched.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Scheduling;

use Alltime\WPReconnaissance\Domain\Enums\ScheduleFrequency;

final class ScheduleFrequencyClamp {

	/**
	 * `$floor` of null means the plan (or the absence of one) imposes no restriction - `$requested`
	 * is returned unchanged.
	 */
	public function clamp( ScheduleFrequency $requested, ?ScheduleFrequency $floor ): ScheduleFrequency {
		if ( null === $floor ) {
			return $requested;
		}

		$rank = self::rank();

		return $rank[ $requested->value ] < $rank[ $floor->value ] ? $floor : $requested;
	}

	/**
	 * Fastest (0) to slowest/never (3). A method rather than a class constant: PHP 8.1 does not
	 * allow enum case member access (`->value`) inside a constant expression - that restriction
	 * was lifted in 8.2, but this codebase supports 8.1 too.
	 *
	 * @return array<string,int>
	 */
	private static function rank(): array {
		return array(
			ScheduleFrequency::Daily->value   => 0,
			ScheduleFrequency::Weekly->value  => 1,
			ScheduleFrequency::Monthly->value => 2,
			ScheduleFrequency::Manual->value  => 3,
		);
	}
}
