<?php
/**
 * A verifiable contact identifier (email or telephone), per Section 8.0.1 - stored separately
 * from the contact record itself so identifiers can be verified, changed and deduplicated
 * without ever using one as the contact's primary key.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\IdentityType;

final class ContactIdentity {

	public function __construct(
		public readonly int $id,
		public readonly int $contact_id,
		public readonly IdentityType $identity_type,
		public readonly string $normalised_value,
		public readonly bool $is_primary,
		public readonly bool $is_verified
	) {}

	/**
	 * @param array<string,mixed> $row
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			contact_id: (int) $row['contact_id'],
			identity_type: IdentityType::from( (string) $row['identity_type'] ),
			normalised_value: (string) $row['normalised_value'],
			is_primary: (bool) $row['is_primary'],
			is_verified: 'unverified' !== (string) $row['verification_status']
		);
	}
}
