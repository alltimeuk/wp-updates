<?php
/**
 * The declared purpose of the cross-tool visitor-context cookie, per Section 18.1.2's consent
 * boundary. A strictly-necessary cookie (multi-step form progress, authenticated tool continuity)
 * may be set and read without a cookie choice; a marketing/attribution cookie may not be set or
 * read until the visitor has granted that purpose.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

enum CookiePurpose: string {
	case StrictlyNecessary = 'strictly_necessary';
	case Marketing         = 'marketing';
}
