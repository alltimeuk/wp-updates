<?php
/**
 * Canonical contact entity, per Section 8.0.
 *
 * Distinct from an organisation, WordPress account, browser, enquiry, submission or assessment -
 * this is the one durable identity a natural person has across every Alltime tool. Never keyed
 * by email: {@see Contact::$contact_uuid} is the immutable, non-sequential, public-safe
 * identifier; {@see Contact::$id} is the internal numeric one.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\ContactLifecycleStatus;

final class Contact {

	public function __construct(
		public readonly int $id,
		public readonly string $contact_uuid,
		public readonly string $given_name,
		public readonly string $family_name,
		public readonly ?int $wp_user_id,
		public readonly ContactLifecycleStatus $lifecycle_status,
		public readonly \DateTimeImmutable $created_at,
		public readonly ?\DateTimeImmutable $verified_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			contact_uuid: (string) $row['contact_uuid'],
			given_name: (string) $row['given_name'],
			family_name: (string) $row['family_name'],
			wp_user_id: isset( $row['wp_user_id'] ) && null !== $row['wp_user_id'] ? (int) $row['wp_user_id'] : null,
			lifecycle_status: ContactLifecycleStatus::from( (string) $row['lifecycle_status'] ),
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			verified_at: ! empty( $row['verified_at'] ) ? new \DateTimeImmutable( (string) $row['verified_at'] ) : null,
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
