<?php
/**
 * Injectable cookie read/write boundary for the visitor-context service, so the service's logic
 * is unit-testable without touching the real HTTP cookie superglobal.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

interface CookieStorageInterface {

	public function get( string $name ): ?string;

	/**
	 * @param array<string,mixed> $options
	 */
	public function set( string $name, string $value, array $options = array() ): void;

	public function delete( string $name ): void;
}
