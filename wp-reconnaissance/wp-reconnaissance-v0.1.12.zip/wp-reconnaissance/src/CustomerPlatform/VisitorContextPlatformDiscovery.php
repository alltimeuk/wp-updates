<?php
/**
 * Service discovery for the visitor-context service, mirroring {@see ContactPlatformDiscovery}
 * (Section 6.1.2/6.1.3). A separate filter keeps the existing v1.0.0 contact-service contract
 * stable while the visitor-context service is independently discoverable by any Alltime tool.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class VisitorContextPlatformDiscovery {

	private const FILTER = 'alltime_customer_platform_visitor_context_service';

	public const CONTRACT_VERSION = '1.0.0';

	public static function provide( VisitorContextService $service, string $version = self::CONTRACT_VERSION ): void {
		add_filter(
			self::FILTER,
			static fn ( mixed $current ): mixed => $current ?? array(
				'service' => $service,
				'version' => $version,
			)
		);
	}

	public static function resolve( string $required_major_version = '1' ): ?VisitorContextService {
		$registration = apply_filters( self::FILTER, null );

		if ( ! is_array( $registration ) || ! ( $registration['service'] ?? null ) instanceof VisitorContextService ) {
			return null;
		}

		$provided_version = (string) ( $registration['version'] ?? '' );

		if ( ! str_starts_with( $provided_version, $required_major_version . '.' ) ) {
			return null;
		}

		return $registration['service'];
	}
}
