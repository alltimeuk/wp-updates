<?php
/**
 * Retention for the Customer Platform's own interaction history, per Section 26.7: "Apply
 * retention to anonymous visitor contexts and cross-tool interaction history."
 *
 * Deliberately owned here, not by WP Reconnaissance's RetentionService, since `atcp_interactions`
 * is this namespace's own table - a consumer reaches this through a plain public method call
 * (infrastructure maintenance, not a contact-resolution business operation), the same way
 * {@see Migrator} is already called directly from Plugin::activate()/uninstall.php, rather than
 * through {@see ContactPlatformDiscovery}'s versioned contract reserved for actual contact data.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class RetentionSweeper {

	/**
	 * Deletes interaction rows older than the retention window. Interactions are event-history
	 * ("questionnaire started", "reconnaissance requested"), not the canonical contact record
	 * itself, so deleting old rows loses no current identity or consent state.
	 */
	public function purge_old_interactions( int $retention_days ): int {
		global $wpdb;

		$table  = Schema::table( 'interactions' );
		$cutoff = ( new \DateTimeImmutable() )->modify( "-{$retention_days} days" )->format( 'Y-m-d H:i:s' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE occurred_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}
