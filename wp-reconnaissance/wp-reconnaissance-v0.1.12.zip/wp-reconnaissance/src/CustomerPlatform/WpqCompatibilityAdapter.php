<?php
/**
 * WP Questionnaires read-only export adapter (Section 6.1.4, Section 26.3). WP Questionnaires
 * v1.15.0+ ships its own `WPQ_Customer_Platform_Bridge`, registering its `wpq_contacts` store as
 * the canonical Customer Platform contact source on any dual-install site - this plugin no longer
 * writes into that store. What remains here is the one still-legitimate read: pulling WPQ's raw
 * submission/enquiry/preference data for `PersonalDataLocator`'s GDPR export, guarded at runtime by
 * {@see WpqCapabilityProbe} so it fails safely if WPQ is absent or an incompatible version.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class WpqCompatibilityAdapter {

	public function __construct(
		private readonly WpqCapabilityProbe $probe = new WpqCapabilityProbe( false, false )
	) {}

	public function is_active(): bool {
		return $this->probe->is_active();
	}

	/**
	 * @return array<string,mixed>
	 */
	public function export_contact_data( string $email ): array {
		if ( ! $this->is_active() ) {
			return array();
		}

		$normalised = $this->normalise_email( $email );

		if ( '' === $normalised ) {
			return array();
		}

		$data = \WPQ_Database::export_contact_data( $normalised );

		return is_array( $data ) ? $data : array();
	}

	private function normalise_email( string $email ): string {
		if ( ! $this->probe->normaliser_class_exists ) {
			return strtolower( trim( $email ) );
		}

		return (string) \WPQ_Contact_Normaliser::normalise_email( $email );
	}
}
