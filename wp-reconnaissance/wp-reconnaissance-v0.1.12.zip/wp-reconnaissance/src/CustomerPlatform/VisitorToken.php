<?php
/**
 * Opaque visitor-context token handling, per Section 18.1.1. The cookie carries only this token
 * (never contact ID, email, name, organisation, consent state or answers); the database stores
 * only a keyed hash of it. The token is 32 random bytes (>= 256 bits of entropy) base64url-encoded.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class VisitorToken {

	/**
	 * Generates a new opaque token. 32 bytes of CSPRNG output, base64url-encoded (43 chars).
	 */
	public static function generate(): string {
		$raw = random_bytes( 32 );

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64url is the standard opaque-token encoding, not code obfuscation.
		return rtrim( strtr( base64_encode( $raw ), '+/', '-_' ), '=' );
	}

	/**
	 * Keyed hash of a token, the only form stored in the database. Uses the site's auth salt so
	 * the hash is not reproducible without WordPress secrets.
	 */
	public static function hash( string $token ): string {
		return hash_hmac( 'sha256', $token, wp_salt( 'at_contact_context' ) );
	}

	/**
	 * Whether a token has the expected opaque format (43 base64url chars). Rejects anything that
	 * could not have been produced by {@see generate()}.
	 */
	public static function is_valid_format( string $token ): bool {
		return 1 === preg_match( '/^[A-Za-z0-9_-]{43}$/', $token );
	}
}
