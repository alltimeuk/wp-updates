<?php
/**
 * Resolves which contact identity wins when several candidate contacts are presented for the same
 * visitor, implementing Section 18.1.3's precedence ladder:
 *
 *   1. An authenticated and verified WordPress-account relationship is authoritative.
 *   2. A single-use, server-created hand-off token may link an immediately preceding form interaction.
 *   3. A verified email identity may support a candidate match.
 *   4. An unverified email or cookie alone must not overwrite or merge an existing verified contact.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class MergePrecedenceResolver {

	/**
	 * @param int|null $authenticated    Contact id from an authenticated, verified account.
	 * @param int|null $handoff          Contact id from a single-use server-created hand-off token.
	 * @param int|null $verified_email   Contact id from a verified email identity.
	 * @param int|null $unverified_email Contact id from an unverified email identity.
	 */
	public function resolve( ?int $authenticated, ?int $handoff, ?int $verified_email, ?int $unverified_email ): ?int {
		if ( null !== $authenticated ) {
			return $authenticated;
		}

		if ( null !== $handoff ) {
			return $handoff;
		}

		if ( null !== $verified_email ) {
			return $verified_email;
		}

		// An unverified email alone must never overwrite or merge an existing verified contact.
		return $unverified_email;
	}
}
