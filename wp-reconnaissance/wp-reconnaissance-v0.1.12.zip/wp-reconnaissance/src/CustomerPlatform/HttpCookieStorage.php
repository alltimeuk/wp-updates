<?php
/**
 * Production {@see CookieStorageInterface} over PHP's cookie superglobal and `setcookie()`. The
 * visitor-context cookie is always Secure (on HTTPS), HttpOnly, SameSite=Lax and Path=/ per
 * Section 18.1.1.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class HttpCookieStorage implements CookieStorageInterface {

	public function get( string $name ): ?string {
		$value = $_COOKIE[ $name ] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- raw cookie value; validated by the caller via VisitorToken::is_valid_format().

		return is_string( $value ) ? $value : null;
	}

	public function set( string $name, string $value, array $options = array() ): void {
		$secure  = (bool) ( $options['secure'] ?? is_ssl() );
		$expires = (int) ( $options['expires'] ?? 0 );

		setcookie(
			$name,
			$value,
			array(
				'expires'  => $expires,
				'path'     => '/',
				'domain'   => '',
				'secure'   => $secure,
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}

	public function delete( string $name ): void {
		$this->set( $name, '', array( 'expires' => time() - 3600 ) );
	}
}
