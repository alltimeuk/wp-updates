<?php
/**
 * Consent decision state, per Section 6.1.3's `alltime_consent_changed` event.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum ConsentState: string {
	case Granted   = 'granted';
	case Withdrawn = 'withdrawn';
}
