<?php
/**
 * Contact lifecycle status, per Section 8.0.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum ContactLifecycleStatus: string {
	case Prospect = 'prospect';
	case Active   = 'active';
	case Inactive = 'inactive';
	case Merged   = 'merged';
	case Deleted  = 'deleted';
}
