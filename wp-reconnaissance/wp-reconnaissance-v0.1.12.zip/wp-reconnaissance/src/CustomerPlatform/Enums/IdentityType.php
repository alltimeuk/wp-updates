<?php
/**
 * Contact identity type, per Section 8.0.1.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Enums;

enum IdentityType: string {
	case Email     = 'email';
	case Telephone = 'telephone';
}
