<?php
/**
 * Why a contact is being created or updated - which product, and under what purpose - carried
 * through to the `alltime_contact_created`/`alltime_contact_updated` events (Section 6.1.3) so a
 * listener can tell a Domain Reconnaissance registration apart from a WP Questionnaires enquiry
 * without inspecting caller state.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class PurposeContext {

	public function __construct(
		public readonly string $product_id,
		public readonly string $purpose,
		public readonly ?string $legal_basis = null
	) {}
}
