<?php
/**
 * Result of {@see ContactServiceInterface::create_or_update_contact()}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class ContactResult {

	public function __construct(
		public readonly Contact $contact,
		public readonly bool $was_created
	) {}
}
