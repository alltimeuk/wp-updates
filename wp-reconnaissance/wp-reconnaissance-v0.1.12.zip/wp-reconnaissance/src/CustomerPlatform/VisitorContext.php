<?php
/**
 * What is currently known about the acting visitor, per {@see ContactServiceInterface::resolve_visitor_context()}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class VisitorContext {

	public function __construct(
		public readonly ?int $contact_id,
		public readonly bool $is_known
	) {}
}
