<?php
/**
 * Decides whether the visitor-context cookie may be set and read for a given purpose, per
 * Section 18.1.2's consent boundary. Declining a purpose never blocks either tool - callers fall
 * back to the authenticated account, an explicit hand-off token or server-side form state.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class CookiePurposeClassifier {

	/**
	 * @param string|null $choice The visitor's cookie choice for the purpose: 'granted',
	 *                            'declined' or null (no choice recorded yet).
	 */
	public function should_set_cookie( CookiePurpose $purpose, ?string $choice ): bool {
		return CookiePurpose::StrictlyNecessary === $purpose || 'granted' === $choice;
	}

	/**
	 * @param string|null $choice The visitor's cookie choice for the purpose.
	 */
	public function should_read_cookie( CookiePurpose $purpose, ?string $choice ): bool {
		return CookiePurpose::StrictlyNecessary === $purpose || 'granted' === $choice;
	}
}
