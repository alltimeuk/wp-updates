<?php
/**
 * Input to {@see ContactServiceInterface::record_interaction()}, per Section 8.0.2.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class InteractionInput {

	public function __construct(
		public readonly string $product_id,
		public readonly string $interaction_type,
		public readonly string $source_object_type,
		public readonly ?int $source_object_id = null,
		public readonly ?int $organisation_id = null,
		public readonly ?string $campaign_reference = null,
		public readonly ?string $purpose = null,
		public readonly ?\DateTimeImmutable $occurred_at = null
	) {}
}
