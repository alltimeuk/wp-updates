<?php
/**
 * Append-only persistence for consent decisions against `atcp_consents`. Never updated or
 * deleted - a withdrawal is a new row with state=withdrawn, so the full history for a purpose is
 * always reconstructable.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\ConsentInput;
use Alltime\CustomerPlatform\Schema;

final class ConsentRepository {

	public function record( int $contact_id, ConsentInput $consent ): int {
		global $wpdb;

		$table = Schema::table( 'consents' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'  => $contact_id,
				'purpose'     => $consent->purpose,
				'state'       => $consent->state->value,
				'source'      => $consent->source,
				'occurred_at' => $now,
				'created_at'  => $now,
			)
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * The most recent decision for a purpose, or null if none has ever been recorded.
	 */
	public function current_state( int $contact_id, string $purpose ): ?string {
		global $wpdb;

		$table = Schema::table( 'consents' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$state = $wpdb->get_var(
			$wpdb->prepare( "SELECT state FROM `{$table}` WHERE contact_id = %d AND purpose = %s ORDER BY id DESC LIMIT 1", $contact_id, $purpose ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		return null !== $state ? (string) $state : null;
	}
}
