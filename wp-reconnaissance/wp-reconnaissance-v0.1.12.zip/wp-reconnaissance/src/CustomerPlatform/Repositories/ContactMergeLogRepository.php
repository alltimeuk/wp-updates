<?php
/**
 * Persistence for the contact merge/review log against `atcp_contact_merge_log` (Section 18.1.4).
 * Ambiguous duplicate candidates land here as `pending_review`; an administrator approves, rejects
 * or reverts each entry, and the before/after snapshots support the documented recovery process.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Schema;

final class ContactMergeLogRepository {

	/**
	 * @param int[] $candidate_contact_ids
	 */
	public function create_review_entry( string $source, array $candidate_contact_ids, ?string $reason = null ): int {
		global $wpdb;

		$table = Schema::table( 'contact_merge_log' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'                => 'pending_review',
				'source'                => $source,
				'candidate_contact_ids' => implode( ',', array_map( 'intval', $candidate_contact_ids ) ),
				'reason'                => $reason,
				'created_at'            => current_time( 'mysql', true ),
			)
		);

		return (int) $wpdb->insert_id;
	}

	public function mark_approved( int $id, int $surviving_id, int $merged_id, int $admin_user_id, string $reason, string $before_snapshot, string $after_snapshot ): void {
		global $wpdb;

		$table = Schema::table( 'contact_merge_log' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'               => 'approved',
				'surviving_contact_id' => $surviving_id,
				'merged_contact_id'    => $merged_id,
				'admin_user_id'        => $admin_user_id,
				'reason'               => $reason,
				'before_snapshot'      => $before_snapshot,
				'after_snapshot'       => $after_snapshot,
				'resolved_at'          => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);
	}

	public function mark_rejected( int $id, int $admin_user_id, string $reason ): void {
		global $wpdb;

		$table = Schema::table( 'contact_merge_log' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'        => 'rejected',
				'admin_user_id' => $admin_user_id,
				'reason'        => $reason,
				'resolved_at'   => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);
	}

	public function mark_reverted( int $id, int $admin_user_id, string $reason ): void {
		global $wpdb;

		$table = Schema::table( 'contact_merge_log' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'        => 'reverted',
				'admin_user_id' => $admin_user_id,
				'reason'        => $reason,
				'reverted_at'   => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function find_pending_review(): array {
		global $wpdb;

		$table = Schema::table( 'contact_merge_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE status = 'pending_review' ORDER BY created_at ASC" ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function find_completed(): array {
		global $wpdb;

		$table = Schema::table( 'contact_merge_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE status != 'pending_review' ORDER BY resolved_at DESC LIMIT 100" ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * @return array<string,mixed>|null
	 */
	public function find( int $id ): ?array {
		global $wpdb;

		$table = Schema::table( 'contact_merge_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return is_array( $row ) ? $row : null;
	}
}
