<?php
/**
 * Persistence for contact-organisation links against `atcp_contact_organisations`. A lightweight
 * CRM-level label, not a foreign key into any product's own organisation table - see
 * {@see \Alltime\CustomerPlatform\ContactInput}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Schema;

final class ContactOrganisationRepository {

	/**
	 * Replaces the contact's primary organisation label. A contact has at most one primary
	 * organisation link in this MVP - multi-organisation contacts are not modelled yet.
	 */
	public function upsert_primary( int $contact_id, string $organisation_name ): void {
		global $wpdb;

		$table = Schema::table( 'contact_organisations' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$existing_id = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM `{$table}` WHERE contact_id = %d AND is_primary = 1", $contact_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		if ( null !== $existing_id ) {
			$wpdb->update( $table, array( 'organisation_name' => $organisation_name ), array( 'id' => (int) $existing_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			return;
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'        => $contact_id,
				'organisation_name' => $organisation_name,
				'is_primary'        => 1,
				'created_at'        => current_time( 'mysql', true ),
			)
		);
	}
}
