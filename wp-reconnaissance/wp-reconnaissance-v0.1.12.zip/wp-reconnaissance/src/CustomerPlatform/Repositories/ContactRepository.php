<?php
/**
 * Persistence for contacts against `atcp_contacts`.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Contact;
use Alltime\CustomerPlatform\Enums\ContactLifecycleStatus;
use Alltime\CustomerPlatform\Schema;

final class ContactRepository {

	public function find( int $id ): ?Contact {
		global $wpdb;

		$table = Schema::table( 'contacts' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d AND deleted_at IS NULL", $id ), ARRAY_A );

		return null !== $row ? Contact::from_row( $row ) : null;
	}

	public function find_by_wp_user( int $wp_user_id ): ?Contact {
		global $wpdb;

		$table = Schema::table( 'contacts' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE wp_user_id = %d AND deleted_at IS NULL", $wp_user_id ), ARRAY_A );

		return null !== $row ? Contact::from_row( $row ) : null;
	}

	public function create( string $given_name, string $family_name ): Contact {
		global $wpdb;

		$table = Schema::table( 'contacts' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'contact_uuid'     => wp_generate_uuid4(),
			'given_name'       => $given_name,
			'family_name'      => $family_name,
			'lifecycle_status' => ContactLifecycleStatus::Prospect->value,
			'created_at'       => $now,
			'updated_at'       => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update_names( int $id, string $given_name, string $family_name ): Contact {
		global $wpdb;

		$table = Schema::table( 'contacts' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'given_name'  => $given_name,
				'family_name' => $family_name,
				'updated_at'  => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function link_wp_user( int $id, int $wp_user_id ): Contact {
		global $wpdb;

		$table = Schema::table( 'contacts' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'wp_user_id'       => $wp_user_id,
				'lifecycle_status' => ContactLifecycleStatus::Active->value,
				'updated_at'       => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	public function mark_verified( int $id ): Contact {
		global $wpdb;

		$table = Schema::table( 'contacts' );
		$now   = current_time( 'mysql', true );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'verified_at' => $now,
				'updated_at'  => $now,
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): Contact {
		$contact = $this->find( $id );

		if ( null === $contact ) {
			throw new \RuntimeException( esc_html( "Contact {$id} was expected to exist but could not be loaded." ) );
		}

		return $contact;
	}
}
