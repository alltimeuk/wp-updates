<?php
/**
 * Persistence for contact preferences against `atcp_preferences` - distinct from consent in
 * `atcp_consents` (Section 22.7). Preferences are append-only; the current value for a key is the
 * most recent row.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Schema;

final class PreferenceRepository {

	public function record( int $contact_id, string $key, string $value, string $source, \DateTimeImmutable $occurred_at ): int {
		global $wpdb;

		$table = Schema::table( 'preferences' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'contact_id'     => $contact_id,
				'preference_key' => $key,
				'value'          => $value,
				'source'         => $source,
				'occurred_at'    => $occurred_at->format( 'Y-m-d H:i:s' ),
				'created_at'     => current_time( 'mysql', true ),
			)
		);

		return (int) $wpdb->insert_id;
	}

	public function current_value( int $contact_id, string $key ): ?string {
		global $wpdb;

		$table = Schema::table( 'preferences' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$value = $wpdb->get_var(
			$wpdb->prepare( "SELECT value FROM `{$table}` WHERE contact_id = %d AND preference_key = %s ORDER BY id DESC LIMIT 1", $contact_id, $key ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		return null !== $value ? (string) $value : null;
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function find_by_contact( int $contact_id ): array {
		global $wpdb;

		$table = Schema::table( 'preferences' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE contact_id = %d ORDER BY id ASC", $contact_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}
}
