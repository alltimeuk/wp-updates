<?php
/**
 * Persistence for the cross-tool visitor-context cookie against `atcp_visitor_contexts`, per
 * Section 18.1.1. Only the keyed hash of the token is stored; the raw token lives solely in the
 * visitor's cookie.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform\Repositories;

use Alltime\CustomerPlatform\Schema;

final class VisitorContextRepository {

	/**
	 * @return array<string,mixed>|null
	 */
	public function find_by_token_hash( string $token_hash ): ?array {
		global $wpdb;

		$table = Schema::table( 'visitor_contexts' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE token_hash = %s LIMIT 1", $token_hash ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return is_array( $row ) ? $row : null;
	}

	public function create( string $token_hash, \DateTimeImmutable $expires_at ): int {
		global $wpdb;

		$now = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'visitor_contexts' ),
			array(
				'token_hash'   => $token_hash,
				'contact_id'   => null,
				'created_at'   => $now,
				'last_used_at' => $now,
				'expires_at'   => $expires_at->format( 'Y-m-d H:i:s' ),
				'revoked_at'   => null,
			)
		);

		return (int) $wpdb->insert_id;
	}

	public function touch_last_used( int $id ): void {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'visitor_contexts' ),
			array( 'last_used_at' => current_time( 'mysql', true ) ),
			array( 'id' => $id )
		);
	}

	public function associate( int $id, int $contact_id ): void {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'visitor_contexts' ),
			array( 'contact_id' => $contact_id ),
			array( 'id' => $id )
		);
	}

	public function revoke( int $id ): void {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'visitor_contexts' ),
			array( 'revoked_at' => current_time( 'mysql', true ) ),
			array( 'id' => $id )
		);
	}

	public function revoke_all_for_contact( int $contact_id ): void {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'visitor_contexts' ),
			array( 'revoked_at' => current_time( 'mysql', true ) ),
			array( 'contact_id' => $contact_id )
		);
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function find_active_by_contact( int $contact_id ): array {
		global $wpdb;

		$table = Schema::table( 'visitor_contexts' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE contact_id = %d AND revoked_at IS NULL", $contact_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return is_array( $rows ) ? $rows : array();
	}
}
