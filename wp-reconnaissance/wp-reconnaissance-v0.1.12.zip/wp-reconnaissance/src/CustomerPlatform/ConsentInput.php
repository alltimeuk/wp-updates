<?php
/**
 * Input to {@see ContactServiceInterface::record_consent()}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Enums\ConsentState;

final class ConsentInput {

	public function __construct(
		public readonly string $purpose,
		public readonly ConsentState $state,
		public readonly string $source
	) {}
}
