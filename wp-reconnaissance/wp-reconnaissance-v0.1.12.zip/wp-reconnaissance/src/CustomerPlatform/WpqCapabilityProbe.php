<?php
/**
 * Read-only capability probe for the WP Questionnaires plugin (Section 6.1.4). The adapter
 * degrades gracefully when WPQ is absent, so this plugin never hard-depends on WPQ being
 * installed.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class WpqCapabilityProbe {

	public function __construct(
		private readonly bool $database_class_exists,
		private readonly bool $normaliser_class_exists
	) {}

	public function is_active(): bool {
		return $this->database_class_exists && $this->normaliser_class_exists;
	}

	/**
	 * Builds a probe from the live environment.
	 */
	public static function probe(): self {
		return new self(
			database_class_exists: class_exists( 'WPQ_Database' ),
			normaliser_class_exists: class_exists( 'WPQ_Contact_Normaliser' )
		);
	}
}
