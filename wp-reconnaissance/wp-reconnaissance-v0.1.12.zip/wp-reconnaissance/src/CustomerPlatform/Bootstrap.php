<?php
/**
 * The Customer Platform's own bootstrap: registers itself as the contact-service provider.
 *
 * Runs before any module that might resolve {@see ContactPlatformDiscovery::resolve()} - see
 * call order in {@see \Alltime\WPReconnaissance\Support\Plugin::boot()}.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class Bootstrap {

	public function boot(): void {
		ContactPlatformDiscovery::provide( new ContactService() );
		VisitorContextPlatformDiscovery::provide( new VisitorContextService() );
	}
}
