<?php
/**
 * Input to {@see ContactServiceInterface::create_or_update_contact()}.
 *
 * $organisation_name is a lightweight CRM-level label (Section 8.0.3's "organisation... values
 * supplied at that time"), not a foreign key into any product's own organisation table - the
 * shared platform's `atcp_contact_organisations` link is deliberately decoupled from
 * product-specific organisation entities like `wpr_organisations`, so renaming or restructuring
 * one never requires touching the other.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class ContactInput {

	public function __construct(
		public readonly string $given_name,
		public readonly string $family_name,
		public readonly string $email,
		public readonly ?string $telephone = null,
		public readonly ?string $organisation_name = null
	) {}
}
