<?php
/**
 * Table naming and dbDelta definitions for the shared Alltime Customer Platform, per Section 9
 * ("The shared Alltime platform component shall own canonical contact tables").
 *
 * Deliberately its own schema/migration surface, separate from
 * {@see \Alltime\WPReconnaissance\Data\Schema} - table names use the `atcp_` prefix the design
 * spec gives (not `wpr_`), signalling that this data belongs to the shared platform even while
 * it is physically installed by this plugin's activation hook. Extracting it into its own plugin
 * later means moving this file and its migration trigger, not renaming a single table.
 *
 * Covers the MVP subset needed to make {@see ContactServiceInterface} genuinely functional:
 * contacts, contact identities, contact-organisation links, interactions and consents (version 1),
 * plus the cross-tool visitor-context cookie, preferences, privacy-request tracking and the
 * contact merge/review log (version 2, Sections 18.1.1-18.1.4 and 22.7).
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

final class Schema {

	/**
	 * @return array<string,string> Unprefixed table key => bare table name.
	 */
	public static function table_names(): array {
		return array(
			'contacts'              => 'atcp_contacts',
			'contact_identities'    => 'atcp_contact_identities',
			'contact_organisations' => 'atcp_contact_organisations',
			'interactions'          => 'atcp_interactions',
			'consents'              => 'atcp_consents',
			'visitor_contexts'      => 'atcp_visitor_contexts',
			'preferences'           => 'atcp_preferences',
			'privacy_requests'      => 'atcp_privacy_requests',
			'contact_merge_log'     => 'atcp_contact_merge_log',
		);
	}

	public static function table( string $key ): string {
		global $wpdb;

		$names = self::table_names();

		if ( ! isset( $names[ $key ] ) ) {
			throw new \InvalidArgumentException( esc_html( "Unknown Customer Platform table key: {$key}" ) );
		}

		return $wpdb->prefix . $names[ $key ];
	}

	/**
	 * @return string[]
	 */
	public static function version_1_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}atcp_contacts (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_uuid VARCHAR(64) NOT NULL,
				given_name VARCHAR(191) NOT NULL,
				family_name VARCHAR(191) NOT NULL,
				wp_user_id BIGINT UNSIGNED NULL,
				lifecycle_status VARCHAR(32) NOT NULL DEFAULT 'prospect',
				created_at DATETIME NOT NULL,
				verified_at DATETIME NULL,
				updated_at DATETIME NOT NULL,
				deleted_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY contact_uuid (contact_uuid),
				UNIQUE KEY wp_user_id (wp_user_id),
				KEY lifecycle_status (lifecycle_status)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_contact_identities (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL,
				identity_type VARCHAR(16) NOT NULL,
				normalised_value VARCHAR(191) NOT NULL,
				is_primary TINYINT(1) NOT NULL DEFAULT 1,
				verification_status VARCHAR(16) NOT NULL DEFAULT 'unverified',
				verified_at DATETIME NULL,
				source VARCHAR(64) NULL,
				first_observed_at DATETIME NOT NULL,
				last_observed_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY identity_type_value (identity_type, normalised_value),
				KEY contact_id (contact_id)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_contact_organisations (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL,
				organisation_name VARCHAR(191) NOT NULL,
				role VARCHAR(64) NULL,
				is_primary TINYINT(1) NOT NULL DEFAULT 1,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY contact_id (contact_id)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_interactions (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL,
				organisation_id BIGINT UNSIGNED NULL,
				product_id VARCHAR(64) NOT NULL,
				interaction_type VARCHAR(64) NOT NULL,
				source_object_type VARCHAR(64) NOT NULL,
				source_object_id BIGINT UNSIGNED NULL,
				occurred_at DATETIME NOT NULL,
				campaign_reference VARCHAR(191) NULL,
				purpose VARCHAR(64) NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY contact_id (contact_id),
				KEY product_id (product_id),
				KEY interaction_type (interaction_type)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_consents (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL,
				purpose VARCHAR(64) NOT NULL,
				state VARCHAR(16) NOT NULL,
				source VARCHAR(64) NOT NULL,
				occurred_at DATETIME NOT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY contact_id_purpose (contact_id, purpose)
			) {$charset_collate};",
		);
	}

	/**
	 * Schema version 2: the cross-tool visitor-context cookie (Section 18.1.1), preferences
	 * (distinct from consent, Section 22.7), privacy-request tracking and the contact merge/review
	 * log (Section 18.1.4). Also adds a unique `(source_object_type, source_object_id)` key to
	 * `atcp_interactions` - the idempotency marker the WP Questionnaires migration relies on so a
	 * submission/enquiry is never linked to a canonical contact twice.
	 *
	 * @return string[]
	 */
	public static function version_2_statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$wpdb->prefix}atcp_visitor_contexts (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				token_hash VARCHAR(64) NOT NULL,
				contact_id BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				last_used_at DATETIME NOT NULL,
				expires_at DATETIME NOT NULL,
				revoked_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY contact_id (contact_id),
				KEY expires_at (expires_at)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_preferences (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL,
				preference_key VARCHAR(64) NOT NULL,
				value VARCHAR(191) NOT NULL,
				source VARCHAR(64) NOT NULL,
				occurred_at DATETIME NOT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY contact_id_key (contact_id, preference_key)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_privacy_requests (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				request_uuid VARCHAR(64) NOT NULL,
				email VARCHAR(191) NOT NULL,
				right_type VARCHAR(32) NOT NULL,
				status VARCHAR(32) NOT NULL,
				channel VARCHAR(32) NOT NULL,
				details TEXT NULL,
				due_at DATETIME NOT NULL,
				completed_at DATETIME NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY request_uuid (request_uuid),
				KEY email (email),
				KEY status (status)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_contact_merge_log (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				status VARCHAR(32) NOT NULL DEFAULT 'pending_review',
				source VARCHAR(64) NOT NULL,
				surviving_contact_id BIGINT UNSIGNED NULL,
				merged_contact_id BIGINT UNSIGNED NULL,
				candidate_contact_ids VARCHAR(255) NULL,
				before_snapshot LONGTEXT NULL,
				after_snapshot LONGTEXT NULL,
				admin_user_id BIGINT UNSIGNED NULL,
				reason TEXT NULL,
				created_at DATETIME NOT NULL,
				resolved_at DATETIME NULL,
				reverted_at DATETIME NULL,
				PRIMARY KEY  (id),
				KEY status (status),
				KEY surviving_contact_id (surviving_contact_id),
				KEY merged_contact_id (merged_contact_id)
			) {$charset_collate};",
			"CREATE TABLE {$wpdb->prefix}atcp_interactions (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL,
				organisation_id BIGINT UNSIGNED NULL,
				product_id VARCHAR(64) NOT NULL,
				interaction_type VARCHAR(64) NOT NULL,
				source_object_type VARCHAR(64) NOT NULL,
				source_object_id BIGINT UNSIGNED NULL,
				occurred_at DATETIME NOT NULL,
				campaign_reference VARCHAR(191) NULL,
				purpose VARCHAR(64) NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY contact_id (contact_id),
				KEY product_id (product_id),
				KEY interaction_type (interaction_type),
				UNIQUE KEY source_object (source_object_type, source_object_id)
			) {$charset_collate};",
		);
	}
}
