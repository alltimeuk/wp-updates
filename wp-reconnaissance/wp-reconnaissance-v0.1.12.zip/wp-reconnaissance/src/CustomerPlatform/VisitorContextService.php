<?php
/**
 * The cross-tool visitor-context cookie service, per Sections 18.1.1-18.1.3. One first-party
 * `at_contact_context` cookie carries an opaque token across WP Questionnaires, WP
 * Reconnaissance and later Alltime tools on the same site. The service sets/reads/rotates the
 * token, keeps its keyed hash in `atcp_visitor_contexts`, and associates it with a canonical
 * contact once the visitor's identity is verified.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

use Alltime\CustomerPlatform\Repositories\VisitorContextRepository;

final class VisitorContextService {

	public const COOKIE_NAME = 'at_contact_context';

	/** Preference key under which the visitor's cookie choice is recorded (Section 18.1.2). */
	public const COOKIE_CHOICE_PREFERENCE = 'cookie_choice';

	public function __construct(
		private readonly VisitorContextRepository $contexts = new VisitorContextRepository(),
		private readonly CookieStorageInterface $cookies = new HttpCookieStorage(),
		private readonly CookiePurposeClassifier $classifier = new CookiePurposeClassifier(),
		private readonly CookiePurpose $purpose = CookiePurpose::StrictlyNecessary,
		private readonly int $lifetime_seconds = 15552000,
		private readonly int $last_used_throttle_seconds = 3600
	) {}

	/**
	 * Ensures a valid visitor-context token exists for the current visitor, setting the cookie if
	 * needed. Returns the token, or null when the cookie purpose is not permitted (Section 18.1.2).
	 */
	public function ensure_context(): ?string {
		if ( ! $this->classifier->should_set_cookie( $this->purpose, $this->get_cookie_choice() ) ) {
			return null;
		}

		$token = $this->cookies->get( self::COOKIE_NAME );

		if ( null !== $token && $this->is_valid_active( $token ) ) {
			$this->maybe_touch( $token );

			return $token;
		}

		return $this->issue_new();
	}

	/**
	 * Resolves the current visitor context from the cookie, or an anonymous context when there is
	 * no valid cookie or the purpose is not permitted.
	 */
	public function resolve_visitor_context(): VisitorContext {
		if ( ! $this->classifier->should_read_cookie( $this->purpose, $this->get_cookie_choice() ) ) {
			return new VisitorContext( null, false );
		}

		$token = $this->cookies->get( self::COOKIE_NAME );

		if ( null === $token || ! VisitorToken::is_valid_format( $token ) ) {
			return new VisitorContext( null, false );
		}

		$row = $this->contexts->find_by_token_hash( VisitorToken::hash( $token ) );

		if ( null === $row || null !== $row['revoked_at'] || $this->is_expired( $row ) ) {
			return new VisitorContext( null, false );
		}

		$contact_id = isset( $row['contact_id'] ) ? (int) $row['contact_id'] : null;

		return new VisitorContext( $contact_id, null !== $contact_id );
	}

	/**
	 * Associates a visitor context with a canonical contact (Section 18.1.3). If the token is
	 * already associated with a different contact, it is rotated and a security event is fired -
	 * the two contacts are never merged automatically.
	 */
	public function associate_with_contact( string $token, int $contact_id ): void {
		if ( ! VisitorToken::is_valid_format( $token ) ) {
			return;
		}

		$row = $this->contexts->find_by_token_hash( VisitorToken::hash( $token ) );

		if ( null === $row || null !== $row['revoked_at'] ) {
			return;
		}

		$existing = isset( $row['contact_id'] ) ? (int) $row['contact_id'] : null;

		if ( null !== $existing && $existing !== $contact_id ) {
			$this->contexts->revoke( (int) $row['id'] );
			$this->fire_security_event( 'visitor_context_contact_mismatch', $contact_id, (string) $row['token_hash'] );

			return;
		}

		$this->contexts->associate( (int) $row['id'], $contact_id );
	}

	/**
	 * Rotates the token: revokes the current one and issues a fresh token/cookie. Called after
	 * login, registration, email verification, contact merge and suspected misuse (Section 18.1.1).
	 */
	public function rotate( string $token ): ?string {
		if ( ! VisitorToken::is_valid_format( $token ) ) {
			return null;
		}

		$row = $this->contexts->find_by_token_hash( VisitorToken::hash( $token ) );

		if ( null !== $row ) {
			$this->contexts->revoke( (int) $row['id'] );
		}

		return $this->issue_new();
	}

	public function revoke( string $token ): void {
		if ( ! VisitorToken::is_valid_format( $token ) ) {
			return;
		}

		$row = $this->contexts->find_by_token_hash( VisitorToken::hash( $token ) );

		if ( null !== $row ) {
			$this->contexts->revoke( (int) $row['id'] );
		}
	}

	public function revoke_all_for_contact( int $contact_id ): void {
		$this->contexts->revoke_all_for_contact( $contact_id );
	}

	/**
	 * Called on login/registration/email-verification: associates the current visitor context with
	 * the authenticated contact, or rotates it on a mismatch (Section 18.1.3 precedence rule 1).
	 */
	public function handle_authenticated_identity( int $contact_id ): void {
		$token = $this->cookies->get( self::COOKIE_NAME );

		if ( null === $token || ! VisitorToken::is_valid_format( $token ) ) {
			return;
		}

		$this->associate_with_contact( $token, $contact_id );
	}

	/**
	 * Records the visitor's cookie choice as a preference (Section 18.1.2) - stored separately
	 * from marketing consent in `atcp_consents`.
	 */
	public function record_cookie_choice( string $choice, ?int $contact_id, string $source ): void {
		$choice = in_array( $choice, array( 'granted', 'declined' ), true ) ? $choice : 'declined';

		do_action( 'alltime_preference_recorded', $contact_id, self::COOKIE_CHOICE_PREFERENCE, $choice, $source );
	}

	public function get_cookie_choice(): ?string {
		return apply_filters( 'alltime_preference_current', null, self::COOKIE_CHOICE_PREFERENCE );
	}

	private function issue_new(): string {
		$token      = VisitorToken::generate();
		$expires_at = new \DateTimeImmutable( '@' . ( time() + $this->lifetime_seconds ) );

		$this->contexts->create( VisitorToken::hash( $token ), $expires_at );
		$this->cookies->set( self::COOKIE_NAME, $token, array( 'expires' => time() + $this->lifetime_seconds ) );

		return $token;
	}

	/**
	 * @param array<string,mixed> $row
	 */
	private function is_expired( array $row ): bool {
		$expires = strtotime( (string) $row['expires_at'] );

		return false === $expires || $expires < time();
	}

	private function is_valid_active( string $token ): bool {
		if ( ! VisitorToken::is_valid_format( $token ) ) {
			return false;
		}

		$row = $this->contexts->find_by_token_hash( VisitorToken::hash( $token ) );

		return null !== $row && null === $row['revoked_at'] && ! $this->is_expired( $row );
	}

	private function maybe_touch( string $token ): void {
		$row = $this->contexts->find_by_token_hash( VisitorToken::hash( $token ) );

		if ( null === $row ) {
			return;
		}

		$last_used = strtotime( (string) $row['last_used_at'] );

		if ( false === $last_used || ( time() - $last_used ) >= $this->last_used_throttle_seconds ) {
			$this->contexts->touch_last_used( (int) $row['id'] );
		}
	}

	private function fire_security_event( string $event_type, ?int $contact_id, string $token_hash ): void {
		do_action( 'alltime_visitor_context_security_event', $event_type, $contact_id, $token_hash );
	}
}
