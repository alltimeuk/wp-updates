<?php
/**
 * A rendered customer-portal screen: the plain page title (for a raw route's <title> tag) and its
 * body HTML (already escaped by whichever render_ or handle_ method in {@see AuthBootstrap} built
 * it). Kept apart rather than pre-joined into one HTML string so the raw-route path and a future
 * shortcode-embedded path can each wrap the same result differently - a raw route needs a full
 * `<!doctype html>` document with `$title` in both `<title>` and an `<h1>`; a shortcode landing
 * inside a real themed page needs neither the document wrapper nor necessarily the `<title>` tag,
 * since the theme's own page title already does that job.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

final class CustomerPageResult {

	public function __construct(
		public readonly string $title,
		public readonly string $body
	) {}
}
