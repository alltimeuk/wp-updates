<?php
/**
 * Handles new customer registration, per Section 18.2 and the journey in Section 5.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\CustomerPlatform\ConsentInput;
use Alltime\CustomerPlatform\ContactInput;
use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\VisitorContextPlatformDiscovery;
use Alltime\CustomerPlatform\Enums\ConsentState;
use Alltime\CustomerPlatform\InteractionInput;
use Alltime\CustomerPlatform\PurposeContext;
use Alltime\WPReconnaissance\AntiAbuse\AntiAbuseService;
use Alltime\WPReconnaissance\AntiAbuse\RegistrationContext;
use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Auth\Exceptions\RegistrationException;
use Alltime\WPReconnaissance\Auth\Exceptions\RegistrationTransactionException;
use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\DomainValidator;
use Alltime\WPReconnaissance\Domain\Exceptions\InvalidDomainException;
use Alltime\WPReconnaissance\Domain\Organisation;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Domain\ValidatedDomain;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class RegistrationService {

	private const MINIMUM_PASSWORD_LENGTH       = 12;
	public const EMAIL_VERIFICATION_TTL_SECONDS = 24 * HOUR_IN_SECONDS;

	/** Mirrors the default collector set {@see \Alltime\WPReconnaissance\Admin\AdminBootstrap} offers for an operator-created scope. */
	private const DEFAULT_COLLECTORS = array( 'rdap', 'dns', 'dnssec', 'mail', 'http', 'tls', 'ct', 'subdomains', 'lookalikes' );

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly DomainValidator $domain_validator = new DomainValidator(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly AntiAbuseService $anti_abuse = new AntiAbuseService()
	) {}

	/**
	 * Section 5.3 steps 5-10: the registration form itself collects the domain and the customer's
	 * confirmation of authority to assess it, and creates the scope immediately - but leaves it
	 * unauthorised until the account's email is verified ({@see
	 * \Alltime\WPReconnaissance\Auth\FreeAssessmentService}), so the free assessment can never be
	 * dispatched against an unverified email address.
	 *
	 * @throws RegistrationException When the submitted input itself is invalid. Never thrown
	 *                                 for an email address that is already registered.
	 */
	public function register(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		string $domain,
		bool $domain_authorisation_confirmed,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged,
		bool $marketing_consent,
		string $client_ip = '0.0.0.0',
		array $captcha_input = array()
	): RegistrationResult {
		$this->validate(
			$given_name,
			$family_name,
			$email,
			$organisation_name,
			$password,
			$password_confirmation,
			$terms_accepted,
			$privacy_acknowledged
		);

		if ( ! $domain_authorisation_confirmed ) {
			throw new RegistrationException( 'You must confirm that you own or have authority to assess this domain.' );
		}

		try {
			$validated_domain = $this->domain_validator->validate( $domain );
		} catch ( InvalidDomainException $exception ) {
			throw new RegistrationException( $exception->getMessage() ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- an exception message is not browser output; AuthBootstrap escapes it via esc_html() when rendering it.
		}

		// Section 5.6 layered anti-abuse: a hard block (blocklist match or failed bot challenge)
		// rejects the registration with a generic message that discloses no detection logic.
		$decision = $this->anti_abuse->evaluate_registration(
			new RegistrationContext(
				email: $email,
				registrable_domain: $validated_domain->registrable,
				ip: $client_ip,
				captcha_input: $captcha_input
			),
			(int) get_option( 'wpr_abuse_max_queued_jobs', 0 )
		);

		if ( $decision->blocks() ) {
			throw new RegistrationException( 'We could not complete your registration. Please contact support if you believe this is in error.' );
		}

		$existing = $this->accounts->find_by_email( $email );

		if ( null !== $existing ) {
			// Section 18.1: do not reveal that this address is already registered. The caller
			// shows the identical "check your email" response either way.
			$this->audit_logger->log( 'registration.duplicate_attempt', 'customer_account', $existing->user_id, outcome: 'rejected' );

			return new RegistrationResult( is_new: false, account: null, verification_token: null );
		}

		[ $organisation, $account, $scope, $verification_token ] = $this->create_registration_records(
			$organisation_name,
			$email,
			$password,
			$given_name,
			$family_name,
			$marketing_consent,
			$validated_domain
		);

		// Deliberately outside the transaction above, and after it has already committed: the
		// Customer Platform contact service (Section 6.1.2) is explicitly designed to eventually
		// become a genuinely separate system, not something this plugin's own registration
		// transaction should be coupled to - a lost contact-platform sync is recoverable, an
		// orphaned, permanently-stuck WordPress account is not. Matches how this method already
		// treats "no provider registered" as an acceptable degrade (see the docblock below); a
		// registered provider erroring degrades the same way.
		try {
			$this->record_contact_platform_registration( $given_name, $family_name, $email, $organisation_name, $account->user_id, (int) $organisation->id, $marketing_consent );
		} catch ( \Throwable $exception ) {
			$this->audit_logger->log( 'registration.contact_platform_sync_failed', 'customer_account', $account->user_id, $account->user_id, outcome: 'failure', summary: $exception->getMessage() );
		}

		return new RegistrationResult( is_new: true, account: $account, verification_token: $verification_token );
	}

	/**
	 * Organisation, account, scope and verification token are created atomically - a failure
	 * partway through (e.g. scope creation failing after the account already exists) previously
	 * left an orphaned WordPress user stuck in PendingEmailVerification forever, since the
	 * verification email is only ever sent by the caller once {@see register()} returns
	 * successfully. Deliberately excludes the Customer Platform contact sync - see the comment at
	 * this method's only call site.
	 *
	 * @return array{0:Organisation,1:CustomerAccount,2:Scope,3:string}
	 * @throws RegistrationTransactionException On a genuine database failure - never for invalid
	 *          input, which {@see validate()} and the domain/anti-abuse checks in {@see register()}
	 *          already reject before this runs.
	 */
	private function create_registration_records(
		string $organisation_name,
		string $email,
		string $password,
		string $given_name,
		string $family_name,
		bool $marketing_consent,
		ValidatedDomain $validated_domain
	): array {
		global $wpdb;

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		try {
			$organisation = $this->organisations->create(
				$organisation_name,
				$this->organisations->unique_slug( $organisation_name )
			);

			$account = $this->accounts->create(
				$email,
				$password,
				$given_name,
				$family_name,
				(int) $organisation->id,
				$marketing_consent
			);

			$this->audit_logger->log( 'registration.created', 'customer_account', $account->user_id, $account->user_id );

			$scope = $this->scopes->create(
				(int) $organisation->id,
				$organisation_name,
				$validated_domain->ascii,
				$validated_domain->display,
				$validated_domain->registrable,
				self::DEFAULT_COLLECTORS
			);

			$this->audit_logger->log( 'scope.created', 'scope', $scope->id, $account->user_id, summary: $scope->domain_display );

			$verification_token = $this->tokens->issue( $account->user_id, TokenType::EmailVerification, self::EMAIL_VERIFICATION_TTL_SECONDS );
		} catch ( \Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			// wp_insert_user() (if it ran before a later step failed) populates WordPress's user
			// object cache as an ordinary side effect - a raw SQL ROLLBACK has no way to know
			// about that cache and doesn't invalidate it, so an immediate retry with the same
			// email would otherwise see a stale "this account exists" result (via get_user_by(),
			// which find_by_email() uses) for a row the database no longer has.
			if ( isset( $account ) ) {
				clean_user_cache( $account->user_id );
			}

			throw new RegistrationTransactionException(
				esc_html__( 'Registration could not be completed due to a temporary problem. Please try again.', 'wp-reconnaissance' ),
				0,
				$exception // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- this is the chained "previous" exception for the stack trace, never displayed/output anywhere; the actual message (the first argument) is already esc_html__()-wrapped.
			);
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return array( $organisation, $account, $scope, $verification_token );
	}

	/**
	 * Creates or links the canonical contact for this registration via the shared Customer
	 * Platform (Section 6.1.2), proving {@see \Alltime\CustomerPlatform\ContactServiceInterface}
	 * end to end from its first real consumer. Section 6.1.3: "Plugins shall fail safely if a
	 * required contract version is unavailable" - if no provider is registered, registration
	 * still succeeds; the WordPress account remains the source of truth either way.
	 */
	private function record_contact_platform_registration(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		int $user_id,
		int $organisation_id,
		bool $marketing_consent
	): void {
		$contact_service = ContactPlatformDiscovery::resolve();

		if ( null === $contact_service ) {
			return;
		}

		$purpose = new PurposeContext( 'wp-reconnaissance', 'customer_registration' );

		$result = $contact_service->create_or_update_contact(
			new ContactInput( $given_name, $family_name, $email, null, $organisation_name ),
			$purpose
		);

		$contact_service->link_wordpress_user( $result->contact->id, $user_id );

		// Associate the cross-tool visitor context with the newly registered contact (Section 18.1.3).
		VisitorContextPlatformDiscovery::resolve()?->handle_authenticated_identity( $result->contact->id );

		$contact_service->record_interaction(
			$result->contact->id,
			new InteractionInput(
				product_id: 'wp-reconnaissance',
				interaction_type: 'registration_completed',
				source_object_type: 'customer_account',
				source_object_id: $user_id,
				organisation_id: $organisation_id
			)
		);

		$contact_service->record_consent(
			$result->contact->id,
			new ConsentInput(
				purpose: 'marketing',
				state: $marketing_consent ? ConsentState::Granted : ConsentState::Withdrawn,
				source: 'registration_form'
			)
		);
	}

	private function validate(
		string $given_name,
		string $family_name,
		string $email,
		string $organisation_name,
		string $password,
		string $password_confirmation,
		bool $terms_accepted,
		bool $privacy_acknowledged
	): void {
		if ( '' === trim( $given_name ) || '' === trim( $family_name ) ) {
			throw new RegistrationException( 'Given name and family name are required.' );
		}

		if ( ! is_email( $email ) ) {
			throw new RegistrationException( 'A valid business email address is required.' );
		}

		if ( '' === trim( $organisation_name ) ) {
			throw new RegistrationException( 'Organisation name is required.' );
		}

		if ( strlen( $password ) < self::MINIMUM_PASSWORD_LENGTH ) {
			throw new RegistrationException( 'Password must be at least ' . self::MINIMUM_PASSWORD_LENGTH . ' characters long.' ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- an exception message is not browser output; AuthBootstrap escapes it via esc_html() when rendering it.
		}

		if ( $password !== $password_confirmation ) {
			throw new RegistrationException( 'Password and confirmation do not match.' );
		}

		if ( ! $terms_accepted ) {
			throw new RegistrationException( 'You must accept the service terms to register.' );
		}

		if ( ! $privacy_acknowledged ) {
			throw new RegistrationException( 'You must acknowledge the privacy notice to register.' );
		}
	}
}
