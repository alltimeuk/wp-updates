<?php
/**
 * Customer notification delivery cadence, per Section 33's customer-configurable notifications.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth\Enums;

enum NotificationFrequency: string {
	case Immediate   = 'immediate';
	case DailyDigest = 'daily_digest';
}
