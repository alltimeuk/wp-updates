<?php
/**
 * Thrown when a genuine database failure occurs partway through {@see \Alltime\WPReconnaissance\Auth\RegistrationService::register()}'s
 * transaction (organisation/account/scope/token creation) - distinct from
 * {@see \Alltime\WPReconnaissance\Auth\Exceptions\RegistrationException}, which covers invalid
 * input the requester can fix. The message is always a fixed, safe string, never raw database
 * detail - it can legitimately reach a customer via the registration form's error message.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth\Exceptions;

final class RegistrationTransactionException extends \RuntimeException {}
