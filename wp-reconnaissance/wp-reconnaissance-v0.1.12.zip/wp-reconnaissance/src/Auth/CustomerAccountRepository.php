<?php
/**
 * Wraps the WordPress user record for a customer account, per Section 18.2-18.3.
 *
 * The underlying identity remains an ordinary WordPress user (core password hashing, session
 * management retained, per Section 18.1); this only layers the plugin-owned attributes on top
 * via user meta, which is the WordPress-native place for lightweight per-user state.
 *
 * The organisation-level consent ledger described in Section 6.1.2/22.7 is a separate, larger
 * shared-platform subsystem that has not been built yet; the single `wpr_marketing_consent`
 * flag here is a minimal stand-in that only covers this one direct-marketing choice, not the
 * full purpose-by-purpose consent record the design specification calls for.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Auth\Enums\AccountStatus;
use Alltime\WPReconnaissance\Auth\Enums\NotificationFrequency;
use Alltime\WPReconnaissance\Support\Roles;

final class CustomerAccountRepository {

	private const META_ORGANISATION_ID        = 'wpr_organisation_id';
	private const META_ACCOUNT_STATUS         = 'wpr_account_status';
	private const META_MARKETING_CONSENT      = 'wpr_marketing_consent';
	private const META_MARKETING_AT           = 'wpr_marketing_consent_at';
	private const META_NOTIFICATION_FREQUENCY = 'wpr_notification_frequency';

	public function find_by_email( string $email ): ?CustomerAccount {
		$user = get_user_by( 'email', $email );

		return false !== $user ? $this->to_account( $user ) : null;
	}

	public function find( int $user_id ): ?CustomerAccount {
		$user = get_user_by( 'id', $user_id );

		return false !== $user ? $this->to_account( $user ) : null;
	}

	/**
	 * Every customer account linked to an organisation - the recipient list for
	 * organisation-wide notifications (Section 22.5).
	 *
	 * @return CustomerAccount[]
	 */
	public function find_by_organisation( int $organisation_id ): array {
		$users = get_users(
			array(
				'role'       => Roles::CUSTOMER_ROLE,
				'meta_key'   => self::META_ORGANISATION_ID, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- customer accounts are a small, bounded set per organisation; no pagination-scale concern here.
				'meta_value' => (string) $organisation_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);

		return array_map( array( $this, 'to_account' ), $users );
	}

	/**
	 * User IDs of customer accounts still stuck in PendingEmailVerification after the given
	 * number of days - Section 26.7's "unverified registrations" retention category. Queried by
	 * WP_User_Query on the plugin's own meta rather than joining `wpr_auth_tokens`, since an
	 * account can be unverified with an already-expired token as easily as a live one.
	 *
	 * @return int[]
	 */
	public function find_stale_unverified_user_ids( int $older_than_days ): array {
		$cutoff = ( new \DateTimeImmutable() )->modify( "-{$older_than_days} days" )->format( 'Y-m-d H:i:s' );

		$users = get_users(
			array(
				'role'       => Roles::CUSTOMER_ROLE,
				'meta_key'   => self::META_ACCOUNT_STATUS, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => AccountStatus::PendingEmailVerification->value, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'date_query' => array( array( 'before' => $cutoff ) ),
				'fields'     => 'ID',
			)
		);

		return array_map( 'intval', $users );
	}

	/**
	 * Permanently removes an unverified customer account. Only ever called by the retention
	 * sweep on an account that never completed verification - a verified account is never
	 * deleted this way, only through the deliberate, capability-controlled workflow Section
	 * 26.7 requires for active accounts.
	 */
	public function delete( int $user_id ): void {
		require_once ABSPATH . 'wp-admin/includes/user.php';

		wp_delete_user( $user_id );
	}

	/**
	 * Whether the account holder has opted in to marketing communications - the suppression
	 * signal {@see \Alltime\WPReconnaissance\Notifications\MailQueueService} checks before
	 * sending any Marketing-purpose queued message (Section 22.5/22.7). Returns false for an
	 * address with no customer account at all, since there is nothing to suppress against.
	 */
	public function has_marketing_consent( string $email ): bool {
		$user = get_user_by( 'email', $email );

		return false !== $user && '1' === get_user_meta( $user->ID, self::META_MARKETING_CONSENT, true );
	}

	/**
	 * Updates the marketing-consent decision after account creation - the customer portal's
	 * "withdraw marketing consent"/"manage communication preferences" actions (Section 26.3) and
	 * {@see \Alltime\WPReconnaissance\Privacy\PrivacyRequestService}'s automatic handling of a
	 * MarketingWithdrawal rights request both go through this rather than writing user meta
	 * directly.
	 */
	public function set_marketing_consent( int $user_id, bool $consent ): void {
		update_user_meta( $user_id, self::META_MARKETING_CONSENT, $consent ? '1' : '0' );
		update_user_meta( $user_id, self::META_MARKETING_AT, current_time( 'mysql', true ) );
	}

	/**
	 * How this account wants transactional notifications delivered (Section 33): one email per
	 * triggering event (the default, unchanged behaviour), or batched into a single daily digest.
	 * Never throws on unrecognised stored meta - falls back to the safer default of Immediate.
	 */
	public function get_notification_frequency( int $user_id ): NotificationFrequency {
		return NotificationFrequency::tryFrom( (string) get_user_meta( $user_id, self::META_NOTIFICATION_FREQUENCY, true ) )
			?? NotificationFrequency::Immediate;
	}

	public function set_notification_frequency( int $user_id, NotificationFrequency $frequency ): void {
		update_user_meta( $user_id, self::META_NOTIFICATION_FREQUENCY, $frequency->value );
	}

	/**
	 * Creates the underlying WordPress user with the customer role and the plugin's
	 * organisation/status/consent meta. Password hashing is entirely WordPress core's - this
	 * never touches password material directly.
	 */
	public function create(
		string $email,
		string $password,
		string $given_name,
		string $family_name,
		int $organisation_id,
		bool $marketing_consent
	): CustomerAccount {
		$user_id = wp_insert_user(
			array(
				'user_login'   => $this->unique_login( $email ),
				'user_email'   => $email,
				'user_pass'    => $password,
				'first_name'   => $given_name,
				'last_name'    => $family_name,
				'display_name' => trim( "{$given_name} {$family_name}" ),
				'role'         => Roles::CUSTOMER_ROLE,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			throw new \RuntimeException( esc_html( $user_id->get_error_message() ) );
		}

		update_user_meta( $user_id, self::META_ORGANISATION_ID, $organisation_id );
		update_user_meta( $user_id, self::META_ACCOUNT_STATUS, AccountStatus::PendingEmailVerification->value );
		update_user_meta( $user_id, self::META_MARKETING_CONSENT, $marketing_consent ? '1' : '0' );
		update_user_meta( $user_id, self::META_MARKETING_AT, current_time( 'mysql', true ) );

		return $this->find_or_fail( $user_id );
	}

	public function set_status( int $user_id, AccountStatus $status ): void {
		update_user_meta( $user_id, self::META_ACCOUNT_STATUS, $status->value );
	}

	/**
	 * Every customer account, newest-first - the "Customers" admin screen's list view (Section
	 * 18.4's `wpr_manage_customers` capability). Optionally filtered by a substring match against
	 * email, display name or login, since paging through every account is impractical once there
	 * are more than a handful.
	 *
	 * @return CustomerAccount[]
	 */
	public function list_all( int $per_page = 20, int $page = 1, ?string $search = null ): array {
		$args = array(
			'role'    => Roles::CUSTOMER_ROLE,
			'number'  => $per_page,
			'offset'  => max( 0, ( max( 1, $page ) - 1 ) * $per_page ),
			'orderby' => 'ID',
			'order'   => 'DESC',
		);

		if ( null !== $search && '' !== $search ) {
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_email', 'display_name', 'user_login' );
		}

		return array_map( array( $this, 'to_account' ), get_users( $args ) );
	}

	/**
	 * Total customer accounts matching the same optional search as {@see list_all()} - the list
	 * screen's count. A second, unpaginated get_users() call rather than reusing a WP_User_Query
	 * object's own total (get_users() doesn't hand that object back), matching
	 * {@see find_stale_unverified_user_ids()}'s existing ID-only unpaginated style.
	 */
	public function count_all( ?string $search = null ): int {
		$args = array(
			'role'   => Roles::CUSTOMER_ROLE,
			'fields' => 'ID',
		);

		if ( null !== $search && '' !== $search ) {
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_email', 'display_name', 'user_login' );
		}

		return count( get_users( $args ) );
	}

	/**
	 * Ensures the account cannot be reused with old sessions after a sensitive change
	 * (password reset, status change) - Section 18.1: "rotate sessions after password and
	 * material security changes."
	 */
	public function destroy_all_sessions( int $user_id ): void {
		\WP_Session_Tokens::get_instance( $user_id )->destroy_all();
	}

	private function find_or_fail( int $user_id ): CustomerAccount {
		$account = $this->find( $user_id );

		if ( null === $account ) {
			throw new \RuntimeException( esc_html( "Customer account {$user_id} was expected to exist but could not be loaded." ) );
		}

		return $account;
	}

	private function to_account( \WP_User $user ): CustomerAccount {
		$status = AccountStatus::tryFrom( (string) get_user_meta( $user->ID, self::META_ACCOUNT_STATUS, true ) )
			?? AccountStatus::PendingEmailVerification;

		return new CustomerAccount(
			user_id: $user->ID,
			email: $user->user_email,
			given_name: $user->first_name,
			family_name: $user->last_name,
			organisation_id: (int) get_user_meta( $user->ID, self::META_ORGANISATION_ID, true ),
			status: $status
		);
	}

	private function unique_login( string $email ): string {
		$local_part = strstr( $email, '@', true );
		$base       = sanitize_user( false !== $local_part ? $local_part : $email, true );
		$base       = '' !== $base ? $base : 'customer';
		$login      = $base;

		$suffix = 2;
		while ( username_exists( $login ) ) {
			$login = "{$base}{$suffix}";
			++$suffix;
		}

		return $login;
	}
}
