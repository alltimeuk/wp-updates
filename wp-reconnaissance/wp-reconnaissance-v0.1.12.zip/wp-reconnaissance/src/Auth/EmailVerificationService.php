<?php
/**
 * Consumes an email-verification token and activates the account, per Section 18.1/18.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\VisitorContextPlatformDiscovery;
use Alltime\WPReconnaissance\Auth\Enums\AccountStatus;
use Alltime\WPReconnaissance\Auth\Enums\TokenType;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class EmailVerificationService {

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly FreeAssessmentService $free_assessment = new FreeAssessmentService()
	) {}

	/**
	 * Returns true only when the token was valid, unused and not expired. Always returns a
	 * plain boolean rather than distinguishing "invalid" from "expired" from "already used" -
	 * Section 18.1's anti-enumeration principle extends to not leaking token state either.
	 */
	public function verify( string $raw_token ): bool {
		$user_id = $this->tokens->consume( $raw_token, TokenType::EmailVerification );

		if ( null === $user_id ) {
			return false;
		}

		$this->accounts->set_status( $user_id, AccountStatus::Active );
		$this->audit_logger->log( 'account.email_verified', 'customer_account', $user_id, $user_id );

		$account = $this->accounts->find( $user_id );

		if ( null !== $account ) {
			$this->free_assessment->provision_for_verified_account( $account );

			// Email verification is a verified-identity event: associate the visitor context
			// (Section 18.1.3 precedence rule 1).
			$contact = ContactPlatformDiscovery::resolve()?->get_contact_for_user( $user_id );
			if ( null !== $contact ) {
				VisitorContextPlatformDiscovery::resolve()?->handle_authenticated_identity( $contact->id );
			}
		}

		return true;
	}
}
