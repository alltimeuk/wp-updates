<?php
/**
 * Self-service account security actions available to an already-authenticated customer, per
 * Section 20's "Security" screen - distinct from {@see PasswordResetService}, which handles the
 * logged-out, token-based forgot-password flow and unconditionally destroys every session
 * (including the one that may have been hijacked), since there's no "current session" worth
 * preserving there. Both flows ultimately change the same `wp_users.user_pass`; this one runs
 * while the customer is already signed in, so it must re-issue the current session's auth cookie
 * after `wp_set_password()` invalidates it, and must be able to keep that one session alive while
 * signing every other one out.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\WPReconnaissance\Support\AuditLogger;

final class AccountSecurityService {

	private const MINIMUM_PASSWORD_LENGTH = 12;

	public function __construct(
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * @throws \InvalidArgumentException When the current password is wrong, or the new password
	 *                                     fails minimum requirements.
	 */
	public function change_password( int $user_id, string $current_password, string $new_password ): void {
		if ( strlen( $new_password ) < self::MINIMUM_PASSWORD_LENGTH ) {
			throw new \InvalidArgumentException( esc_html( 'Password must be at least ' . self::MINIMUM_PASSWORD_LENGTH . ' characters long.' ) );
		}

		$user = get_userdata( $user_id );

		if ( false === $user || ! wp_check_password( $current_password, $user->user_pass, $user_id ) ) {
			throw new \InvalidArgumentException( esc_html__( 'Current password is incorrect.', 'wp-reconnaissance' ) );
		}

		wp_set_password( $new_password, $user_id );

		// wp_set_password() invalidates every existing session's auth-cookie hash, including the
		// one making this request - re-issue it so a successful password change doesn't
		// unexpectedly sign the customer out of their own session (unlike PasswordResetService's
		// token-based reset, which runs while already logged out and expects a fresh sign-in
		// afterwards).
		wp_set_auth_cookie( $user_id );

		$this->audit_logger->log( 'account.password_changed', 'customer_account', $user_id, $user_id );
	}

	/**
	 * Signs the account out of every session except the one making this request - deliberately
	 * NOT {@see CustomerAccountRepository::destroy_all_sessions()}, which kills the current
	 * session too (correct for a logged-out password reset, wrong for "sign out elsewhere" while
	 * still signed in here).
	 */
	public function sign_out_other_sessions( int $user_id ): void {
		\WP_Session_Tokens::get_instance( $user_id )->destroy_others( wp_get_session_token() );

		$this->audit_logger->log( 'account.other_sessions_signed_out', 'customer_account', $user_id, $user_id );
	}
}
