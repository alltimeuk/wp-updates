<?php
/**
 * Completes Section 5.3's self-service journey once a customer's email is verified: starts DNS
 * TXT domain-ownership verification for the scope created at registration, so the free assessment
 * (Section 5.5) can be dispatched the moment that verification succeeds - either through the
 * customer's own DNS record (via {@see \Alltime\WPReconnaissance\Verification\VerificationBootstrap}'s
 * `wpr_scope_domain_verified` listener) or an operator's manual bypass on the admin Scopes screen.
 * Email verification alone no longer authorises a scope: proving control of an email address is
 * not proof of control of the domain being scanned, and an unauthorised, unreconciled scope must
 * never be treated as if it were.
 *
 * Deliberately triggered by email verification, not registration itself (Section 5.6: "Apply
 * layered controls... Email verification"): generating a DNS challenge (and, once verified,
 * dispatching a collection job) before the requester has proven control of the email address they
 * registered with would let anyone start a scan of an arbitrary domain by typing someone else's
 * address into the registration form.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\WPReconnaissance\AntiAbuse\AntiAbuseService;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepositoryException;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Entitlements\EntitlementService;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Tools\ToolsBootstrap;
use Alltime\WPReconnaissance\Verification\DomainVerificationService;
use Alltime\WPReconnaissance\Verification\SchemaNotReadyException;

final class FreeAssessmentService {

	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly EntitlementService $entitlements = new EntitlementService(),
		private readonly SchedulingBootstrap $scheduling = new SchedulingBootstrap(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly AntiAbuseService $anti_abuse = new AntiAbuseService(),
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly DomainVerificationService $domain_verification = new DomainVerificationService()
	) {}

	/**
	 * Starts DNS TXT domain-ownership verification for every still-pending scope belonging to the
	 * newly verified account's organisation (in practice, the single scope
	 * {@see RegistrationService::register()} created) - the customer's dashboard already shows the
	 * TXT record to publish for any not-yet-authorised scope. Never throws: a stuck database
	 * upgrade or a genuine database failure leaves the challenge ungenerated for a later retry
	 * (an operator can still generate and check it manually from the admin Scopes screen) rather
	 * than surfacing upgrade/database detail to a customer mid-registration.
	 */
	public function provision_for_verified_account( CustomerAccount $account ): void {
		foreach ( $this->scopes->find_by_organisation( $account->organisation_id ) as $scope ) {
			if ( 'pending' !== $scope->authorisation_status ) {
				continue;
			}

			try {
				$this->domain_verification->generate_challenge( $scope->id, $account->user_id, 'registration' );
			} catch ( SchemaNotReadyException | ScopeRepositoryException ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- see docblock above.
			}
		}
	}

	/**
	 * Dispatches the free assessment for an account's already-authorised scopes that have not yet
	 * been dispatched. Two callers: the admin Abuse-review screen when an operator releases a held
	 * signal, and {@see \Alltime\WPReconnaissance\Verification\VerificationBootstrap}'s
	 * `wpr_scope_domain_verified` listener once DNS verification authorises a scope - either way,
	 * a legitimate customer gets their result without waiting on an operator to dispatch it by hand.
	 */
	public function dispatch_free_assessment_for_account( CustomerAccount $account ): void {
		foreach ( $this->scopes->find_by_organisation( $account->organisation_id ) as $scope ) {
			if ( 'authorised' !== $scope->authorisation_status ) {
				continue;
			}

			if ( count( $this->jobs->find_by_scope( $scope->id ) ) > 0 ) {
				continue; // Already dispatched - keep both callers idempotent.
			}

			$this->dispatch_free_assessment( $scope, $account );
		}
	}

	/**
	 * Section 5.6: an open review signal (disposable email, duplicate domain, or the max-queued-
	 * jobs throttle) holds the free assessment until an operator releases it - checked here, the
	 * single choke point both public methods above already funnel through, so neither caller can
	 * bypass it by forgetting to check first.
	 */
	private function dispatch_free_assessment( Scope $scope, CustomerAccount $account ): void {
		if ( $this->anti_abuse->has_open_review( $account->email, $scope->registrable_domain ) ) {
			$this->audit_logger->log( 'abuse.assessment_held_for_review', 'scope', $scope->id, $account->user_id, outcome: 'review', summary: 'free_assessment_held' );

			return;
		}

		$contact = ContactPlatformDiscovery::resolve()?->get_contact_for_user( $account->user_id );

		if ( null === $contact ) {
			return;
		}

		$decision = $this->entitlements->check( $contact->id, ToolsBootstrap::DOMAIN_RECONNAISSANCE_TOOL_ID, $scope->registrable_domain, organisation_id: $scope->organisation_id );

		if ( ! $decision->allowed ) {
			return;
		}

		$this->entitlements->reserve( $contact->id, ToolsBootstrap::DOMAIN_RECONNAISSANCE_TOOL_ID, $scope->registrable_domain );
		$this->scheduling->schedule_assessment( $scope->id, $account->user_id );
	}
}
