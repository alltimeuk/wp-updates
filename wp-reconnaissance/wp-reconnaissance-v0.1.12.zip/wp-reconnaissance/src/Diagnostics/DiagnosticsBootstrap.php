<?php
/**
 * Diagnostics module bootstrap, per Section 29.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Diagnostics;

final class DiagnosticsBootstrap {

	public function __construct(
		private readonly SiteHealthChecks $site_health = new SiteHealthChecks()
	) {}

	public function boot(): void {
		$this->site_health->boot();
	}
}
