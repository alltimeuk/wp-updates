<?php
/**
 * Microsoft 365 (Graph API) mail provider, per Section 22.4.
 *
 * Uses OAuth 2.0's client-credentials grant against an Entra ID (Azure AD) app registration - an
 * application ("app-only") permission, not a delegated one, so there's no interactive sign-in and
 * no user-tied refresh token to store. `sender` is the mailbox-enabled UPN the app-only token is
 * authorised against - it's both the `{id}` path segment of Graph's `/users/{id}/sendMail` and the
 * default From address. `from`, when set to something other than `sender`, is injected as an
 * explicit `message.from` address while the URL path segment stays `sender` regardless - this is
 * the "Send As" pattern: `sender` must hold Exchange Online "Send As" (or "Send on Behalf")
 * permission on the `from` mailbox for Graph to accept it. `from` must be a genuine mailbox (a
 * shared, user or room mailbox) - a distribution list does not work here even with "Send As"
 * granted on it: Graph's `sendMail` only supports sending as an actual mailbox, not a mail-enabled
 * group, independent of delegate permissions (confirmed against a real tenant, not just inferred
 * from documentation - the ACL entry existed and the send still failed with a non-transient
 * error).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;

final class M365Provider implements MailProviderInterface {

	private const TOKEN_CACHE_KEY = 'wpr_m365_access_token';
	private const REQUEST_TIMEOUT = 30;

	public function __construct(
		private readonly HttpTransport $transport = new WpHttpTransport()
	) {}

	public function id(): string {
		return 'microsoft_365';
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( '' === (string) get_option( 'wpr_m365_tenant_id', '' ) ) {
			$errors[] = 'Microsoft 365 tenant ID is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_m365_client_id', '' ) ) {
			$errors[] = 'Microsoft 365 application (client) ID is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_m365_client_secret', '' ) ) {
			$errors[] = 'Microsoft 365 client secret is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_m365_sender', '' ) ) {
			$errors[] = 'Microsoft 365 sending mailbox is not configured.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$tenant_id     = (string) get_option( 'wpr_m365_tenant_id', '' );
		$client_id     = (string) get_option( 'wpr_m365_client_id', '' );
		$client_secret = (string) get_option( 'wpr_m365_client_secret', '' );
		$sender        = (string) get_option( 'wpr_m365_sender', '' );
		$from          = (string) get_option( 'wpr_m365_from', '' );

		if ( '' === $tenant_id || '' === $client_id || '' === $client_secret || '' === $sender ) {
			throw new MailDeliveryException( 'Microsoft 365 provider is not fully configured.' );
		}

		$access_token = $this->access_token( $tenant_id, $client_id, $client_secret );

		$graph_message = array(
			'subject'      => $message->subject,
			'body'         => array(
				'contentType' => 'HTML',
				'content'     => $message->html_body,
			),
			'toRecipients' => array(
				array( 'emailAddress' => array( 'address' => $message->recipient ) ),
			),
		);

		// `from` is only sent when it actually differs from `sender` - the mailbox path segment
		// below stays `sender` either way, since that's the identity the app-only token is
		// authorised against, not necessarily a mailbox capable of receiving Graph API calls
		// itself.
		if ( '' !== $from && $from !== $sender ) {
			$graph_message['from'] = array( 'emailAddress' => array( 'address' => $from ) );
		}

		$response = $this->transport->post(
			'https://graph.microsoft.com/v1.0/users/' . rawurlencode( $sender ) . '/sendMail',
			array(
				'timeout' => self::REQUEST_TIMEOUT,
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'application/json',
				),
				'body'    => (string) wp_json_encode(
					array(
						'message'         => $graph_message,
						'saveToSentItems' => false,
					)
				),
			)
		);

		if ( $response['code'] < 200 || $response['code'] >= 300 ) {
			throw new MailDeliveryException(
				esc_html( 'Microsoft Graph returned HTTP ' . $response['code'] . ': ' . $this->error_excerpt( $response['body'] ) ),
				is_transient: $this->is_transient_status( $response['code'] ) // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- this is the boolean is_transient flag, not the message; the message argument above is already esc_html()-wrapped.
			);
		}

		// Graph's sendMail returns 202 Accepted with an empty body on success - there is no
		// message id to report back, unlike Gmail/SES. Honestly reflecting that as an empty
		// string rather than synthesising a fake one.
		return new MailSendResult( $this->id(), '', 'sent' );
	}

	/**
	 * Exchanges the app registration's client credentials for a short-lived, app-only access
	 * token (the "client credentials" OAuth grant - no user ever signs in), reusing a cached one
	 * while it's still valid. Mirrors {@see GmailProvider::access_token()}'s caching shape.
	 */
	private function access_token( string $tenant_id, string $client_id, string $client_secret ): string {
		$cached = get_transient( self::TOKEN_CACHE_KEY );

		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$response = $this->transport->post(
			'https://login.microsoftonline.com/' . rawurlencode( $tenant_id ) . '/oauth2/v2.0/token',
			array(
				'timeout' => self::REQUEST_TIMEOUT,
				'body'    => array(
					'grant_type'    => 'client_credentials',
					'client_id'     => $client_id,
					'client_secret' => $client_secret,
					'scope'         => 'https://graph.microsoft.com/.default',
				),
			)
		);

		$data = json_decode( $response['body'], true );

		if ( $response['code'] < 200 || $response['code'] >= 300 || ! is_array( $data ) || empty( $data['access_token'] ) ) {
			throw new MailDeliveryException(
				esc_html( 'Microsoft 365 token exchange returned HTTP ' . $response['code'] . ': ' . $this->error_excerpt( $response['body'] ) ),
				is_transient: $this->is_transient_status( $response['code'] ) // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- this is the boolean is_transient flag, not the message; the message argument above is already esc_html()-wrapped.
			);
		}

		$token   = (string) $data['access_token'];
		$expires = max( 60, (int) ( $data['expires_in'] ?? 3600 ) - 120 );

		set_transient( self::TOKEN_CACHE_KEY, $token, $expires );

		return $token;
	}

	private function is_transient_status( int $code ): bool {
		return 429 === $code || 503 === $code || 504 === $code;
	}

	/**
	 * Pulls a human-readable message out of Graph's `{"error":{"code":...,"message":...}}` shape,
	 * or the token endpoint's `{"error":"invalid_client","error_description":...}` shape, falling
	 * back to a raw excerpt of the body when neither is present.
	 */
	private function error_excerpt( string $body ): string {
		$data    = json_decode( $body, true );
		$message = is_array( $data ) ? ( $data['error']['message'] ?? $data['error_description'] ?? '' ) : '';

		return '' !== $message ? substr( (string) $message, 0, 300 ) : substr( $body, 0, 300 );
	}
}
