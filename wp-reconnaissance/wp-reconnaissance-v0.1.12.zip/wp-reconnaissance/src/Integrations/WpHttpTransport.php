<?php
/**
 * The real {@see HttpTransport}: a thin wrapper around WordPress's own HTTP API. Every mail
 * provider defaults to this in production; only tests substitute something else.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;

final class WpHttpTransport implements HttpTransport {

	public function post( string $url, array $args ): array {
		$response = wp_remote_post( $url, $args );

		if ( is_wp_error( $response ) ) {
			throw new MailDeliveryException( esc_html( $response->get_error_message() ), is_transient: true );
		}

		return array(
			'code' => (int) wp_remote_retrieve_response_code( $response ),
			'body' => (string) wp_remote_retrieve_body( $response ),
		);
	}
}
