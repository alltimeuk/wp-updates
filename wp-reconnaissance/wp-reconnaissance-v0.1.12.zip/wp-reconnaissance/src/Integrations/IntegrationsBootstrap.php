<?php
/**
 * Integrations module bootstrap, per Section 22.
 *
 * Wires the mail-provider abstraction and the notification action/filter hooks that later
 * modules (Findings, Reports, Scheduling) fire into. The WP Questionnaires compatibility
 * adapter described in Section 6.1.4 is separate, later Phase 1 work.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Notifications\NotificationDispatcher;

final class IntegrationsBootstrap {

	/**
	 * Notification hook surface (Section 22.5), fired from each hook's owning module:
	 *
	 * `do_action( 'wpr_job_completed', $job_id )` - AssessmentService.
	 * `do_action( 'wpr_finding_created', $finding_id )` - AssessmentService.
	 * `do_action( 'wpr_finding_changed', $finding_id, $event_id )` - AssessmentService.
	 * `do_action( 'wpr_report_issued', $report_id )` - ReportRepository.
	 *
	 * NotificationDispatcher is their first subscriber, translating the events above into queued
	 * customer notifications per Section 22.5's trigger list, but any other integration can
	 * listen to the same events independently. `wpr_notification_payload` is not yet applied
	 * anywhere - no filterable payload construction exists to hang it on until a second listener
	 * needs one.
	 */
	public function boot(): void {
		( new NotificationDispatcher() )->boot();
	}
}
