<?php
/**
 * Gmail API mail provider, per Section 22.2.
 *
 * Uses OAuth 2.0's refresh-token grant against a Google Cloud OAuth client - never requests or
 * stores the mailbox owner's Google password. The refresh token itself
 * (`wpr_gmail_refresh_token`) is obtained once, out of band (Google's OAuth consent flow), and
 * stored via the Settings screen; this class only ever exchanges it for short-lived access
 * tokens, cached between sends so a burst of mail doesn't re-authenticate on every message.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;

final class GmailProvider implements MailProviderInterface {

	private const TOKEN_URL       = 'https://oauth2.googleapis.com/token';
	private const SEND_URL        = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send';
	private const TOKEN_CACHE_KEY = 'wpr_gmail_access_token';
	private const REQUEST_TIMEOUT = 30;

	public function __construct(
		private readonly HttpTransport $transport = new WpHttpTransport()
	) {}

	public function id(): string {
		return 'gmail_api';
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( '' === (string) get_option( 'wpr_gmail_oauth_client_id', '' ) ) {
			$errors[] = 'Gmail OAuth client ID is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_gmail_oauth_client_secret', '' ) ) {
			$errors[] = 'Gmail OAuth client secret is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_gmail_sender_address', '' ) ) {
			$errors[] = 'Gmail authorised sender mailbox is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_gmail_refresh_token', '' ) ) {
			$errors[] = 'Gmail account is not connected (no refresh token stored).';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$client_id     = (string) get_option( 'wpr_gmail_oauth_client_id', '' );
		$client_secret = (string) get_option( 'wpr_gmail_oauth_client_secret', '' );
		$refresh_token = (string) get_option( 'wpr_gmail_refresh_token', '' );
		$sender        = (string) get_option( 'wpr_gmail_sender_address', '' );

		if ( '' === $client_id || '' === $client_secret || '' === $refresh_token || '' === $sender ) {
			throw new MailDeliveryException( 'Gmail API provider is not fully configured.' );
		}

		$access_token = $this->access_token( $client_id, $client_secret, $refresh_token );
		$raw_message  = $this->build_raw_message( $sender, $message->recipient, $message->subject, $message->html_body );

		$response = $this->transport->post(
			self::SEND_URL,
			array(
				'timeout' => self::REQUEST_TIMEOUT,
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'application/json',
				),
				'body'    => (string) wp_json_encode( array( 'raw' => $raw_message ) ),
			)
		);

		if ( $response['code'] < 200 || $response['code'] >= 300 ) {
			throw new MailDeliveryException(
				esc_html( 'Gmail API returned HTTP ' . $response['code'] . ': ' . $this->error_excerpt( $response['body'] ) ),
				is_transient: $this->is_transient_status( $response['code'] ) // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- this is the boolean is_transient flag, not the message; the message argument above is already esc_html()-wrapped.
			);
		}

		$data = json_decode( $response['body'], true );
		$id   = is_array( $data ) && isset( $data['id'] ) ? (string) $data['id'] : '';

		return new MailSendResult( $this->id(), $id, 'sent' );
	}

	/**
	 * Exchanges the stored refresh token for a short-lived access token, reusing a cached one
	 * while it's still valid (cached for `expires_in - 120` seconds, floored at 60, so it's
	 * refreshed a couple of minutes before Google would actually reject it).
	 */
	private function access_token( string $client_id, string $client_secret, string $refresh_token ): string {
		$cached = get_transient( self::TOKEN_CACHE_KEY );

		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$response = $this->transport->post(
			self::TOKEN_URL,
			array(
				'timeout' => self::REQUEST_TIMEOUT,
				'body'    => array(
					'grant_type'    => 'refresh_token',
					'client_id'     => $client_id,
					'client_secret' => $client_secret,
					'refresh_token' => $refresh_token,
				),
			)
		);

		$data = json_decode( $response['body'], true );

		if ( $response['code'] < 200 || $response['code'] >= 300 || ! is_array( $data ) || empty( $data['access_token'] ) ) {
			throw new MailDeliveryException(
				esc_html( 'Gmail token exchange returned HTTP ' . $response['code'] . ': ' . $this->error_excerpt( $response['body'] ) ),
				is_transient: $this->is_transient_status( $response['code'] ) // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- this is the boolean is_transient flag, not the message; the message argument above is already esc_html()-wrapped.
			);
		}

		$token   = (string) $data['access_token'];
		$expires = max( 60, (int) ( $data['expires_in'] ?? 3600 ) - 120 );

		set_transient( self::TOKEN_CACHE_KEY, $token, $expires );

		return $token;
	}

	/**
	 * A minimal RFC 5322 message, base64url-encoded per the Gmail API's `messages.send` "raw"
	 * field contract. HTML-only, no attachments/CC/BCC - matches this provider's own send()
	 * signature, which doesn't carry any of those.
	 */
	private function build_raw_message( string $from, string $to, string $subject, string $html_body ): string {
		$headers = array(
			'To: ' . $to,
			'From: ' . $from,
			'Subject: ' . $this->encode_subject( $subject ),
			'MIME-Version: 1.0',
			'Content-Type: text/html; charset=UTF-8',
		);

		$mime = implode( "\r\n", $headers ) . "\r\n\r\n" . $html_body;

		return rtrim( strtr( base64_encode( $mime ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64url encoding is the Gmail API's own required wire format for the "raw" field, not obfuscation.
	}

	/**
	 * RFC 2047 "B" (base64) encoded-word form, required whenever the subject contains non-ASCII
	 * characters - a plain-ASCII subject already round-trips fine unencoded, so it's left as-is.
	 */
	private function encode_subject( string $subject ): string {
		if ( 1 === preg_match( '/^[\x20-\x7E]*$/', $subject ) ) {
			return $subject;
		}

		return '=?UTF-8?B?' . base64_encode( $subject ) . '?='; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- RFC 2047 "B" encoding requires base64; this is a mail header, not obfuscation.
	}

	private function is_transient_status( int $code ): bool {
		return 429 === $code || $code >= 500;
	}

	/**
	 * Pulls a human-readable message out of Gmail's two different error response shapes - the
	 * API's own `{"error":{"message":...}}`, or the OAuth token endpoint's
	 * `{"error":"invalid_grant","error_description":...}` - falling back to a raw excerpt of the
	 * body when neither is present.
	 */
	private function error_excerpt( string $body ): string {
		$data    = json_decode( $body, true );
		$message = is_array( $data ) ? ( $data['error']['message'] ?? $data['error_description'] ?? '' ) : '';

		return '' !== $message ? substr( (string) $message, 0, 300 ) : substr( $body, 0, 300 );
	}
}
