<?php
/**
 * Amazon SES mail provider, per Section 22.3.
 *
 * Sends via SES v2's REST API (`POST /v2/email/outbound-emails`), authenticated with AWS
 * Signature Version 4 - signed by hand rather than pulling in the AWS SDK, which would be a very
 * large dependency for one API call. IAM-role credential support (i.e. not needing a static
 * access key/secret at all, on infrastructure that already has one) is not implemented; this
 * provider only ever signs with the access key/secret stored via the Settings screen.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;

final class SesProvider implements MailProviderInterface {

	private const SERVICE         = 'ses';
	private const REQUEST_TIMEOUT = 30;

	/**
	 * Produces the current UTC instant a request is signed against - real time in production;
	 * overridable so a test can sign against a fixed instant and assert an exact, deterministic
	 * Authorization header. A closure literal isn't a legal PHP default parameter value, so this
	 * is resolved in the constructor body rather than promoted directly.
	 *
	 * @var \Closure
	 */
	private readonly \Closure $now;

	public function __construct(
		private readonly HttpTransport $transport = new WpHttpTransport(),
		?\Closure $now = null
	) {
		$this->now = $now ?? static function (): \DateTimeImmutable {
			return new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );
		};
	}

	public function id(): string {
		return 'amazon_ses';
	}

	public function validate_configuration(): array {
		$errors = array();

		if ( '' === (string) get_option( 'wpr_ses_region', '' ) ) {
			$errors[] = 'Amazon SES region is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_ses_access_key_id', '' ) ) {
			$errors[] = 'Amazon SES access key ID is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_ses_secret_access_key', '' ) ) {
			$errors[] = 'Amazon SES secret access key is not configured.';
		}

		if ( '' === (string) get_option( 'wpr_ses_sender_address', '' ) ) {
			$errors[] = 'Amazon SES verified sender identity is not configured.';
		}

		return $errors;
	}

	public function send( QueuedMessage $message ): MailSendResult {
		$region     = (string) get_option( 'wpr_ses_region', '' );
		$access_key = (string) get_option( 'wpr_ses_access_key_id', '' );
		$secret_key = (string) get_option( 'wpr_ses_secret_access_key', '' );
		$sender     = (string) get_option( 'wpr_ses_sender_address', '' );

		if ( '' === $region || '' === $access_key || '' === $secret_key || '' === $sender ) {
			throw new MailDeliveryException( 'Amazon SES provider is not fully configured.' );
		}

		$host = "email.{$region}.amazonaws.com";
		$path = '/v2/email/outbound-emails';
		$body = (string) wp_json_encode(
			array(
				'FromEmailAddress' => $sender,
				'Destination'      => array( 'ToAddresses' => array( $message->recipient ) ),
				'Content'          => array(
					'Simple' => array(
						'Subject' => array(
							'Data'    => $message->subject,
							'Charset' => 'UTF-8',
						),
						'Body'    => array(
							'Html' => array(
								'Data'    => $message->html_body,
								'Charset' => 'UTF-8',
							),
						),
					),
				),
			)
		);

		$now       = ( $this->now )();
		$signature = $this->sign_request( $now, $region, $access_key, $secret_key, $host, $path, $body );

		$response = $this->transport->post(
			"https://{$host}{$path}",
			array(
				'timeout' => self::REQUEST_TIMEOUT,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'X-Amz-Date'    => $signature['amz_date'],
					'Authorization' => $signature['authorization'],
				),
				'body'    => $body,
			)
		);

		if ( $response['code'] < 200 || $response['code'] >= 300 ) {
			throw new MailDeliveryException(
				esc_html( 'Amazon SES returned HTTP ' . $response['code'] . ': ' . $this->error_excerpt( $response['body'] ) ),
				is_transient: $this->is_transient_status( $response['code'] ) // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- this is the boolean is_transient flag, not the message; the message argument above is already esc_html()-wrapped.
			);
		}

		$data = json_decode( $response['body'], true );
		$id   = is_array( $data ) && isset( $data['MessageId'] ) ? (string) $data['MessageId'] : '';

		return new MailSendResult( $this->id(), $id, 'sent' );
	}

	/**
	 * AWS Signature Version 4: canonical request -> string-to-sign -> a date/region/service
	 * derived signing key (so the raw secret key is never used to sign directly) -> signature.
	 * Only three headers are signed (content-type, host, x-amz-date) - the minimum SES's REST API
	 * requires; SES doesn't need the `x-amz-content-sha256` header some other AWS services do.
	 *
	 * @return array{amz_date:string,authorization:string}
	 */
	private function sign_request(
		\DateTimeImmutable $now,
		string $region,
		string $access_key,
		string $secret_key,
		string $host,
		string $path,
		string $body
	): array {
		$amz_date         = $now->format( 'Ymd\THis\Z' );
		$date             = $now->format( 'Ymd' );
		$credential_scope = "{$date}/{$region}/" . self::SERVICE . '/aws4_request';

		$canonical_headers = "content-type:application/json\nhost:{$host}\nx-amz-date:{$amz_date}\n";
		$signed_headers    = 'content-type;host;x-amz-date';
		$hashed_payload    = hash( 'sha256', $body );

		$canonical_request = "POST\n{$path}\n\n{$canonical_headers}\n{$signed_headers}\n{$hashed_payload}";

		$string_to_sign = "AWS4-HMAC-SHA256\n{$amz_date}\n{$credential_scope}\n" . hash( 'sha256', $canonical_request );

		$k_date    = hash_hmac( 'sha256', $date, 'AWS4' . $secret_key, true );
		$k_region  = hash_hmac( 'sha256', $region, $k_date, true );
		$k_service = hash_hmac( 'sha256', self::SERVICE, $k_region, true );
		$k_signing = hash_hmac( 'sha256', 'aws4_request', $k_service, true );
		$signature = hash_hmac( 'sha256', $string_to_sign, $k_signing );

		$authorization = 'AWS4-HMAC-SHA256 '
			. "Credential={$access_key}/{$credential_scope}, "
			. "SignedHeaders={$signed_headers}, "
			. "Signature={$signature}";

		return array(
			'amz_date'      => $amz_date,
			'authorization' => $authorization,
		);
	}

	private function is_transient_status( int $code ): bool {
		return 429 === $code || $code >= 500;
	}

	/**
	 * Pulls a human-readable message out of SES v2's `{"message": "..."}` error shape, falling
	 * back to a raw excerpt of the body when it isn't present.
	 */
	private function error_excerpt( string $body ): string {
		$data    = json_decode( $body, true );
		$message = is_array( $data ) ? ( $data['message'] ?? '' ) : '';

		return '' !== $message ? substr( (string) $message, 0, 300 ) : substr( $body, 0, 300 );
	}
}
