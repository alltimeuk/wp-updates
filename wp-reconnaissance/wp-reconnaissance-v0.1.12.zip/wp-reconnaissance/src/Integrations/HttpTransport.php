<?php
/**
 * The outbound-HTTP seam every mail provider sends through, per Section 22.1 - mirrors
 * {@see \Alltime\WPReconnaissance\Auth\AuthBootstrap}'s `$terminator` and
 * {@see \Alltime\WPReconnaissance\Verification\DomainVerificationService}'s `$dns_query`:
 * injectable so a test can substitute a fake transport instead of hitting a live network or
 * needing a WordPress runtime, defaulting to {@see WpHttpTransport} in production.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;

interface HttpTransport {

	/**
	 * @param array<string,mixed> $args Same shape as wp_remote_post()'s $args (headers, body, timeout).
	 * @return array{code:int,body:string}
	 * @throws MailDeliveryException On a transport-level failure (e.g. DNS/connection error) -
	 *                                 always constructed with is_transient: true, since a network
	 *                                 error says nothing about whether the request itself was valid.
	 */
	public function post( string $url, array $args ): array;
}
