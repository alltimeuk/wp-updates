<?php
/**
 * Resolves the administrator-selected active mail provider, per Section 22.1.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Integrations;

final class MailManager {

	/**
	 * @return array<string,MailProviderInterface>
	 */
	public function available_providers(): array {
		$providers = array( new GmailProvider(), new SesProvider(), new M365Provider() );

		return array_combine( array_map( static fn ( MailProviderInterface $provider ): string => $provider->id(), $providers ), $providers );
	}

	public function active_provider(): ?MailProviderInterface {
		$active_id = (string) get_option( 'wpr_mail_provider', '' );

		return $this->available_providers()[ $active_id ] ?? null;
	}
}
