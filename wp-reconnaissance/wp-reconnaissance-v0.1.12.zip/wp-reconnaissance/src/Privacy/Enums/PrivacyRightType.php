<?php
/**
 * The data-subject right a request is classified under, per Section 26.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy\Enums;

enum PrivacyRightType: string {
	case Access              = 'access';
	case Rectification       = 'rectification';
	case Erasure             = 'erasure';
	case Restriction         = 'restriction';
	case Portability         = 'portability';
	case Objection           = 'objection';
	case MarketingWithdrawal = 'marketing_withdrawal';

	public function label(): string {
		return match ( $this ) {
			self::Access => __( 'Access (view or download my data)', 'wp-reconnaissance' ),
			self::Rectification => __( 'Rectification (correct my data)', 'wp-reconnaissance' ),
			self::Erasure => __( 'Erasure (delete my data / close my account)', 'wp-reconnaissance' ),
			self::Restriction => __( 'Restriction of processing', 'wp-reconnaissance' ),
			self::Portability => __( 'Portability (machine-readable export)', 'wp-reconnaissance' ),
			self::Objection => __( 'Objection to processing', 'wp-reconnaissance' ),
			self::MarketingWithdrawal => __( 'Withdraw marketing consent', 'wp-reconnaissance' ),
		};
	}

	/**
	 * Whether Section 26.6's "honour marketing withdrawal and objections promptly" applies well
	 * enough to this right that it can be auto-fulfilled immediately on submission, rather than
	 * queued for operator review like every other right.
	 */
	public function auto_fulfillable(): bool {
		return self::MarketingWithdrawal === $this;
	}
}
