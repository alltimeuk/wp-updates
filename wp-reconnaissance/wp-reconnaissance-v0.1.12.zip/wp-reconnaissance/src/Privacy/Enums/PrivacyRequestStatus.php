<?php
/**
 * Lifecycle status of a data-subject rights request, per Section 26.4.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy\Enums;

enum PrivacyRequestStatus: string {
	case Submitted          = 'submitted';
	case Verifying          = 'verifying';
	case InProgress         = 'in_progress';
	case Completed          = 'completed';
	case PartiallyCompleted = 'partially_completed';
	case Refused            = 'refused';
	case Cancelled          = 'cancelled';

	public function is_open(): bool {
		return ! in_array( $this, array( self::Completed, self::PartiallyCompleted, self::Refused, self::Cancelled ), true );
	}
}
