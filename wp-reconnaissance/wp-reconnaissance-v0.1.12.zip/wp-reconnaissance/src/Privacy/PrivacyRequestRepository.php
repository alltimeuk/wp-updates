<?php
/**
 * Persistence for data-subject rights requests against `wpr_privacy_requests`, per Section 26.4.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRequestStatus;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRightType;

final class PrivacyRequestRepository {

	public function find( int $id ): ?PrivacyRequest {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? PrivacyRequest::from_row( $row ) : null;
	}

	public function find_by_uuid( string $request_uuid ): ?PrivacyRequest {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE request_uuid = %s", $request_uuid ), ARRAY_A );

		return null !== $row ? PrivacyRequest::from_row( $row ) : null;
	}

	/**
	 * A customer's own requests, newest first - the "view privacy-request status" portal action
	 * (Section 26.3).
	 *
	 * @return PrivacyRequest[]
	 */
	public function find_by_user( int $user_id ): array {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE user_id = %d ORDER BY id DESC", $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array_map( array( PrivacyRequest::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return array{items: PrivacyRequest[], total: int}
	 */
	public function list_all( int $per_page, int $page, ?PrivacyRequestStatus $status = null ): array {
		global $wpdb;

		$table  = Schema::table( 'privacy_requests' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		if ( null !== $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE status = %s ORDER BY due_at ASC LIMIT %d OFFSET %d", $status->value, $per_page, $offset ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE status = %s", $status->value ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY due_at ASC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		}

		return array(
			'items' => array_map( array( PrivacyRequest::class, 'from_row' ), null !== $rows ? $rows : array() ),
			'total' => $total,
		);
	}

	/**
	 * Open requests whose statutory deadline is within the given number of days (including
	 * already-overdue ones) - Section 26.4: "The system shall flag approaching deadlines."
	 *
	 * @return PrivacyRequest[]
	 */
	public function find_approaching_deadline( int $within_days ): array {
		global $wpdb;

		$table   = Schema::table( 'privacy_requests' );
		$horizon = ( new \DateTimeImmutable() )->modify( "+{$within_days} days" )->format( 'Y-m-d H:i:s' );
		$open    = implode( ',', array_map( static fn ( PrivacyRequestStatus $status ): string => "'" . esc_sql( $status->value ) . "'", array_filter( PrivacyRequestStatus::cases(), static fn ( PrivacyRequestStatus $status ): bool => $status->is_open() ) ) );

		// $table/$open are built entirely from fixed, internally derived identifiers (Schema::table(),
		// PrivacyRequestStatus enum values), never user input.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE status IN ({$open}) AND due_at <= %s ORDER BY due_at ASC", $horizon ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array_map( array( PrivacyRequest::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create(
		string $email,
		?int $user_id,
		PrivacyRightType $right_type,
		string $details,
		string $channel,
		PrivacyRequestStatus $status,
		\DateTimeImmutable $due_at
	): PrivacyRequest {
		global $wpdb;

		$table = Schema::table( 'privacy_requests' );
		$now   = current_time( 'mysql', true );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'request_uuid' => wp_generate_uuid4(),
				'user_id'      => $user_id,
				'email'        => $email,
				'right_type'   => $right_type->value,
				'status'       => $status->value,
				'channel'      => $channel,
				'details'      => '' !== $details ? $details : null,
				'due_at'       => $due_at->format( 'Y-m-d H:i:s' ),
				'created_at'   => $now,
				'updated_at'   => $now,
			)
		);

		if ( false === $inserted ) {
			throw new PrivacyRequestRepositoryException( esc_html( "Failed to create a privacy request for {$email}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function set_status( int $id, PrivacyRequestStatus $status, ?string $outcome_summary = null, ?string $refusal_reason = null ): PrivacyRequest {
		global $wpdb;

		$data = array(
			'status'     => $status->value,
			'updated_at' => current_time( 'mysql', true ),
		);

		if ( null !== $outcome_summary ) {
			$data['outcome_summary'] = $outcome_summary;
		}

		if ( null !== $refusal_reason ) {
			$data['refusal_reason'] = $refusal_reason;
		}

		if ( ! $status->is_open() ) {
			$data['completed_at'] = current_time( 'mysql', true );
		}

		$updated = $wpdb->update( Schema::table( 'privacy_requests' ), $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( false === $updated ) {
			throw new PrivacyRequestRepositoryException( esc_html( "Failed to update the status of privacy request {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	public function set_right_type( int $id, PrivacyRightType $right_type ): PrivacyRequest {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'privacy_requests' ),
			array(
				'right_type' => $right_type->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new PrivacyRequestRepositoryException( esc_html( "Failed to update the right type of privacy request {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	public function mark_identity_verified( int $id ): PrivacyRequest {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'privacy_requests' ),
			array(
				'identity_verified_at' => current_time( 'mysql', true ),
				'updated_at'           => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new PrivacyRequestRepositoryException( esc_html( "Failed to mark identity verified for privacy request {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	public function set_restricted( int $id, bool $restricted ): PrivacyRequest {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'privacy_requests' ),
			array(
				'restricted' => $restricted ? 1 : 0,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new PrivacyRequestRepositoryException( esc_html( "Failed to update the restricted flag for privacy request {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	public function assign( int $id, ?int $assigned_to ): PrivacyRequest {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'privacy_requests' ),
			array(
				'assigned_to' => $assigned_to,
				'updated_at'  => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new PrivacyRequestRepositoryException( esc_html( "Failed to assign privacy request {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): PrivacyRequest {
		$request = $this->find( $id );

		if ( null === $request ) {
			throw new \RuntimeException( esc_html( "Privacy request {$id} was expected to exist but could not be loaded." ) );
		}

		return $request;
	}
}
