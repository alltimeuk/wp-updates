<?php
/**
 * A persisted row from `wpr_privacy_requests`, per Section 26.4.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRequestStatus;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRightType;

final class PrivacyRequest {

	public function __construct(
		public readonly int $id,
		public readonly string $request_uuid,
		public readonly ?int $user_id,
		public readonly string $email,
		public readonly PrivacyRightType $right_type,
		public readonly PrivacyRequestStatus $status,
		public readonly string $channel,
		public readonly ?string $details,
		public readonly bool $restricted,
		public readonly ?\DateTimeImmutable $identity_verified_at,
		public readonly ?int $assigned_to,
		public readonly ?string $outcome_summary,
		public readonly ?string $refusal_reason,
		public readonly \DateTimeImmutable $due_at,
		public readonly ?\DateTimeImmutable $completed_at,
		public readonly \DateTimeImmutable $created_at
	) {}

	/**
	 * @param array<string,mixed> $row
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			request_uuid: (string) $row['request_uuid'],
			user_id: null !== $row['user_id'] ? (int) $row['user_id'] : null,
			email: (string) $row['email'],
			right_type: PrivacyRightType::from( (string) $row['right_type'] ),
			status: PrivacyRequestStatus::from( (string) $row['status'] ),
			channel: (string) $row['channel'],
			details: $row['details'] ?? null,
			restricted: (bool) $row['restricted'],
			identity_verified_at: ! empty( $row['identity_verified_at'] ) ? new \DateTimeImmutable( (string) $row['identity_verified_at'] ) : null,
			assigned_to: null !== $row['assigned_to'] ? (int) $row['assigned_to'] : null,
			outcome_summary: $row['outcome_summary'] ?? null,
			refusal_reason: $row['refusal_reason'] ?? null,
			due_at: new \DateTimeImmutable( (string) $row['due_at'] ),
			completed_at: ! empty( $row['completed_at'] ) ? new \DateTimeImmutable( (string) $row['completed_at'] ) : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] )
		);
	}

	public function is_overdue(): bool {
		return $this->status->is_open() && $this->due_at < new \DateTimeImmutable();
	}
}
