<?php
/**
 * Thrown when a repository write against `wpr_privacy_requests` genuinely fails at the database
 * level - a silently lost status/restriction update here risks missing a statutory DSAR deadline
 * (Section 26.4), so it must surface loudly rather than being discarded.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

final class PrivacyRequestRepositoryException extends \RuntimeException {}
