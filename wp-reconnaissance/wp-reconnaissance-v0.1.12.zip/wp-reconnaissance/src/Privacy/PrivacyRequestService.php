<?php
/**
 * Administrative rights-request workflow, per Section 26.4.
 *
 * Covers submission, identity verification, classification, processing restriction, locating
 * linked data, and completing/partially completing/refusing a request with an outcome notice -
 * every bullet in Section 26.4 except "record verbal or written requests manually", which is
 * simply {@see submit()} called from the admin screen with `channel: 'manual'` rather than a
 * separate method.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

use Alltime\CustomerPlatform\ConsentInput;
use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\Enums\ConsentState;
use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\MailQueueService;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRequestStatus;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRightType;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class PrivacyRequestService {

	/** UK GDPR's default statutory response window: one calendar month, approximated in days. */
	private const DEFAULT_DUE_DAYS = 30;

	public function __construct(
		private readonly PrivacyRequestRepository $requests = new PrivacyRequestRepository(),
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly PersonalDataLocator $locator = new PersonalDataLocator(),
		private readonly MailQueueService $mail_queue = new MailQueueService(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * Receives a request "through the account or other channels" (Section 26.4). A portal
	 * submission from an authenticated customer is treated as identity-verified immediately -
	 * they already proved who they are by logging in; anything submitted through another channel
	 * starts in Submitted and waits for an operator to verify identity proportionately.
	 */
	public function submit( string $email, PrivacyRightType $right_type, string $details, string $channel = 'portal', ?int $user_id = null ): PrivacyRequest {
		$due_at          = ( new \DateTimeImmutable() )->modify( '+' . $this->due_days() . ' days' );
		$identity_proven = 'portal' === $channel && null !== $user_id;

		$request = $this->requests->create( $email, $user_id, $right_type, $details, $channel, $identity_proven ? PrivacyRequestStatus::InProgress : PrivacyRequestStatus::Submitted, $due_at );

		if ( $identity_proven ) {
			$request = $this->requests->mark_identity_verified( $request->id );
		}

		$this->audit_logger->log( 'privacy_request.submitted', 'privacy_request', $request->id, $user_id, summary: $right_type->value );

		if ( $right_type->auto_fulfillable() ) {
			return $this->auto_fulfil_marketing_withdrawal( $request );
		}

		return $request;
	}

	public function verify_identity( int $id, int $operator_id ): PrivacyRequest {
		$this->requests->mark_identity_verified( $id );
		$request = $this->requests->set_status( $id, PrivacyRequestStatus::InProgress );

		$this->audit_logger->log( 'privacy_request.identity_verified', 'privacy_request', $id, $operator_id );

		return $request;
	}

	public function classify( int $id, PrivacyRightType $right_type, int $operator_id ): PrivacyRequest {
		$request = $this->requests->set_right_type( $id, $right_type );

		$this->audit_logger->log( 'privacy_request.classified', 'privacy_request', $id, $operator_id, summary: $right_type->value );

		return $request;
	}

	public function assign( int $id, ?int $assignee_id, int $operator_id ): PrivacyRequest {
		$request = $this->requests->assign( $id, $assignee_id );

		$this->audit_logger->log( 'privacy_request.assigned', 'privacy_request', $id, $operator_id, summary: null !== $assignee_id ? (string) $assignee_id : 'unassigned' );

		return $request;
	}

	/**
	 * "Place processing restrictions while a request is assessed" (Section 26.4). Tracked and
	 * operator-visible; not wired into any processing decision elsewhere in the plugin yet, since
	 * restriction of security-assessment processing and restriction of personal-data processing
	 * are different things and this plugin's processing is predominantly the former - see
	 * CHANGELOG.md.
	 */
	public function restrict( int $id, int $operator_id ): PrivacyRequest {
		$request = $this->requests->set_restricted( $id, true );

		$this->audit_logger->log( 'privacy_request.restriction_applied', 'privacy_request', $id, $operator_id );

		return $request;
	}

	public function lift_restriction( int $id, int $operator_id ): PrivacyRequest {
		$request = $this->requests->set_restricted( $id, false );

		$this->audit_logger->log( 'privacy_request.restriction_lifted', 'privacy_request', $id, $operator_id );

		return $request;
	}

	/**
	 * "Find all linked data" and "Export data in human-readable and machine-readable forms"
	 * (Section 26.4) - the same {@see PersonalDataLocator} output WordPress core's own export tool
	 * uses, in one call an admin screen can render as a table or offer as a JSON download.
	 *
	 * @return array<int,array{group_id:string,group_label:string,item_id:string,data:array<int,array{name:string,value:string}>}>
	 */
	public function locate_data( PrivacyRequest $request ): array {
		return $this->locator->locate( $request->email );
	}

	public function complete( int $id, int $operator_id, string $outcome_summary ): PrivacyRequest {
		$request = $this->requests->set_status( $id, PrivacyRequestStatus::Completed, outcome_summary: $outcome_summary );

		$this->audit_logger->log( 'privacy_request.completed', 'privacy_request', $id, $operator_id, summary: $outcome_summary );
		$this->notify_outcome( $request, __( 'Your privacy request has been completed', 'wp-reconnaissance' ), $outcome_summary );

		return $request;
	}

	public function partially_complete( int $id, int $operator_id, string $outcome_summary ): PrivacyRequest {
		$request = $this->requests->set_status( $id, PrivacyRequestStatus::PartiallyCompleted, outcome_summary: $outcome_summary );

		$this->audit_logger->log( 'privacy_request.partially_completed', 'privacy_request', $id, $operator_id, summary: $outcome_summary );
		$this->notify_outcome( $request, __( 'Your privacy request has been partially completed', 'wp-reconnaissance' ), $outcome_summary );

		return $request;
	}

	/**
	 * "Record exemptions, legal holds, refusals and reasons after authorised review" (Section
	 * 26.4). $refusal_reason is sent to the requester as-is in the outcome notice, so it must
	 * already be the customer-facing explanation, not an internal-only note.
	 */
	public function refuse( int $id, int $operator_id, string $refusal_reason ): PrivacyRequest {
		$request = $this->requests->set_status( $id, PrivacyRequestStatus::Refused, refusal_reason: $refusal_reason );

		$this->audit_logger->log( 'privacy_request.refused', 'privacy_request', $id, $operator_id, summary: $refusal_reason );
		$this->notify_outcome( $request, __( 'Your privacy request has been refused', 'wp-reconnaissance' ), $refusal_reason );

		return $request;
	}

	/**
	 * Requester-initiated withdrawal from the customer portal - only the requester who submitted
	 * it may cancel their own request.
	 */
	public function cancel( int $id, int $user_id ): PrivacyRequest {
		$request = $this->requests->find( $id );

		if ( null === $request || $request->user_id !== $user_id ) {
			throw new \InvalidArgumentException( esc_html( 'Privacy request not found for this account.' ) );
		}

		$request = $this->requests->set_status( $id, PrivacyRequestStatus::Cancelled );

		$this->audit_logger->log( 'privacy_request.cancelled', 'privacy_request', $id, $user_id );

		return $request;
	}

	/**
	 * "The system shall flag approaching deadlines" (Section 26.4) - the admin screen's source for
	 * highlighting due-soon and overdue requests.
	 *
	 * @return PrivacyRequest[]
	 */
	public function approaching_deadline( int $within_days = 5 ): array {
		return $this->requests->find_approaching_deadline( $within_days );
	}

	/**
	 * Section 26.6: "Honour marketing withdrawal... promptly." Applied immediately on submission
	 * rather than waiting for operator review, since there is nothing to assess - unlike every
	 * other right, withdrawing marketing consent has no retention/legal-hold exception to weigh.
	 */
	private function auto_fulfil_marketing_withdrawal( PrivacyRequest $request ): PrivacyRequest {
		$user_id = $request->user_id ?? $this->accounts->find_by_email( $request->email )?->user_id;

		if ( null !== $user_id ) {
			$this->accounts->set_marketing_consent( $user_id, false );

			$contact_service = ContactPlatformDiscovery::resolve();
			$contact         = $contact_service?->get_contact_for_user( $user_id );

			if ( null !== $contact_service && null !== $contact ) {
				$contact_service->record_consent( $contact->id, new ConsentInput( purpose: 'marketing', state: ConsentState::Withdrawn, source: 'privacy_request' ) );
			}
		}

		$outcome_summary = __( 'Marketing consent withdrawn immediately on submission.', 'wp-reconnaissance' );
		$completed       = $this->requests->set_status( $request->id, PrivacyRequestStatus::Completed, outcome_summary: $outcome_summary );

		$this->audit_logger->log( 'privacy_request.auto_fulfilled', 'privacy_request', $request->id, $user_id );

		return $completed;
	}

	private function notify_outcome( PrivacyRequest $request, string $subject, string $body_summary ): void {
		$this->mail_queue->enqueue(
			new QueuedMessage(
				idempotency_key: "privacy_request_outcome:{$request->id}:{$request->status->value}",
				recipient: $request->email,
				template: 'privacy_request_outcome',
				purpose: MailPurpose::PrivacyRequest,
				subject: $subject,
				html_body: '<p>' . esc_html( $body_summary ) . '</p>'
			)
		);
	}

	private function due_days(): int {
		return max( 1, (int) get_option( 'wpr_privacy_request_due_days', self::DEFAULT_DUE_DAYS ) );
	}
}
