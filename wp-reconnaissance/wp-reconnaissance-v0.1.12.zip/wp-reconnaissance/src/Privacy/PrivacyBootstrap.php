<?php
/**
 * Privacy module bootstrap, per Section 26.
 *
 * Registers this plugin with the WordPress core personal-data exporter/eraser tools. Section
 * 26 is explicit that core tools alone are not sufficient (operational data also lives in
 * custom tables and protected files), so the administrative rights-request workflow
 * (Section 26.4) is a separate, larger piece of work; this bootstrap establishes the extension
 * points and the core-tool integration surface.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

final class PrivacyBootstrap {

	public function boot(): void {
		add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'register_exporters' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'register_erasers' ) );
	}

	/**
	 * @param array<string,array<string,mixed>> $exporters
	 * @return array<string,array<string,mixed>>
	 */
	public function register_exporters( array $exporters ): array {
		$exporters['wpr'] = array(
			'exporter_friendly_name' => __( 'WP Reconnaissance', 'wp-reconnaissance' ),
			'callback'               => array( PersonalDataExporter::class, 'export' ),
		);

		return $exporters;
	}

	/**
	 * @param array<string,array<string,mixed>> $erasers
	 * @return array<string,array<string,mixed>>
	 */
	public function register_erasers( array $erasers ): array {
		$erasers['wpr'] = array(
			'eraser_friendly_name' => __( 'WP Reconnaissance', 'wp-reconnaissance' ),
			'callback'             => array( PersonalDataEraser::class, 'erase' ),
		);

		return $erasers;
	}
}
