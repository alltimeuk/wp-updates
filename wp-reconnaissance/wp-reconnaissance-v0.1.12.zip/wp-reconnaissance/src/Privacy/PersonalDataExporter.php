<?php
/**
 * Core personal-data export callback, per Section 26.
 *
 * Delegates entirely to {@see PersonalDataLocator}, so WordPress core's own "Export Personal
 * Data" admin tool and {@see PrivacyRequestService}'s own Access/Portability request fulfilment
 * both return exactly the same data through exactly the same code path.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

final class PersonalDataExporter {

	/**
	 * @return array{data: array<int,array<string,mixed>>, done: bool}
	 */
	public static function export( string $email_address, int $page = 1 ): array {
		if ( $page > 1 ) {
			return array(
				'data' => array(),
				'done' => true,
			);
		}

		return array(
			'data' => ( new PersonalDataLocator() )->locate( $email_address ),
			'done' => true,
		);
	}
}
