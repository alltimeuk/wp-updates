<?php
/**
 * Core personal-data erasure callback, per Section 26.
 *
 * The right to erasure is not absolute (Section 26.4): this only ever removes data that is safe
 * to remove unconditionally - queued/sent email history addressed to the requester. Everything
 * else that names them (their account, the shared contact record, the audit log) is retained,
 * because deleting an active customer account has cross-organisation consequences (other
 * organisation members, in-flight assessments, issued reports) that need the deliberate,
 * capability-controlled review {@see PrivacyRequestService}'s admin workflow provides, and the
 * audit log is itself a record required for security and regulatory accountability. An operator
 * completing an Erasure request through that workflow reviews and actions those retained items
 * manually; this callback (and WordPress core's own "Erase Personal Data" tool, which calls it
 * identically) only ever performs the unconditionally safe part.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Notifications\Repositories\MailEventRepository;
use Alltime\WPReconnaissance\Notifications\Repositories\MailQueueRepository;

final class PersonalDataEraser {

	/**
	 * @return array{items_removed: bool, items_retained: bool, messages: string[], done: bool}
	 */
	public static function erase( string $email_address, int $page = 1 ): array {
		if ( $page > 1 ) {
			return array(
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}

		$mail_queue  = new MailQueueRepository();
		$mail_events = new MailEventRepository();
		$messages    = array();
		$removed     = false;

		$mails = $mail_queue->find_by_recipient( $email_address );

		foreach ( $mails as $mail ) {
			$mail_events->delete_for_message( $mail->id );
			$mail_queue->delete( $mail->id );
		}

		if ( array() !== $mails ) {
			$removed    = true;
			$messages[] = sprintf(
				/* translators: %d: number of removed email messages */
				_n(
					'Removed %d queued/sent email message addressed to this address.',
					'Removed %d queued/sent email messages addressed to this address.',
					count( $mails ),
					'wp-reconnaissance'
				),
				count( $mails )
			);
		}

		if ( null !== ( new CustomerAccountRepository() )->find_by_email( $email_address ) ) {
			$messages[] = __( 'A customer account exists for this address and has not been removed automatically - account and organisation data require review through the administrative privacy-request workflow before erasure.', 'wp-reconnaissance' );
		}

		// Always true: audit log entries naming this address as an actor are never removed here.
		$retained   = true;
		$messages[] = __( 'Audit log entries naming this address as an actor are retained for security and regulatory accountability.', 'wp-reconnaissance' );

		return array(
			'items_removed'  => $removed,
			'items_retained' => $retained,
			'messages'       => $messages,
			'done'           => true,
		);
	}
}
