<?php
/**
 * Renders a stored, immutable report document as protected interactive HTML, per Section 21.1's
 * required ordering and Section 21.2's "protected interactive HTML inside the portal" format.
 *
 * The persisted document (schemas/report.schema.json) deliberately carries only IDs, not
 * customer-facing names - the organisation/scope names shown here are resolved at render time,
 * never baked into the immutable record, since renaming an organisation later should not require
 * regenerating every report that ever referenced it.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Report;

final class HtmlReportRenderer {

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository()
	) {}

	public function render( Report $report ): string {
		$document     = $report->document;
		$scope        = $this->scopes->find( $report->scope_id );
		$organisation = $this->organisations->find( $report->organisation_id );

		$html  = '<div class="wpr-report">';
		$html .= $this->render_cover( $report, $organisation?->name ?? '', $scope?->domain_display ?? '' );
		$html .= $this->render_section( __( 'Executive summary', 'wp-reconnaissance' ), '<p>' . esc_html( (string) ( $document['executive_summary'] ?? '' ) ) . '</p>' );
		$html .= $this->render_immediate_priorities( $document );
		$html .= $this->render_remediation_plan( $document );
		$html .= $this->render_findings_by_subject( $document );
		$html .= $this->render_positive_controls( $document );
		$html .= $this->render_section( __( 'Methodology and limitations', 'wp-reconnaissance' ), '<p>' . esc_html( (string) ( $document['method_and_limitations'] ?? '' ) ) . '</p>' );
		$html .= $this->render_technical_appendix( $document );
		$html .= $this->render_support_options();
		$html .= '</div>';

		return $html;
	}

	private function render_cover( Report $report, string $organisation_name, string $domain ): string {
		return '<header class="wpr-report__cover">'
			. '<h1>' . esc_html__( 'Domain Reconnaissance report', 'wp-reconnaissance' ) . '</h1>'
			. '<p>' . esc_html( $organisation_name ) . ' &mdash; ' . esc_html( $domain ) . '</p>'
			. '<p>' . esc_html__( 'Report', 'wp-reconnaissance' ) . ' ' . esc_html( $report->report_uuid ) . ' (' . esc_html__( 'version', 'wp-reconnaissance' ) . ' ' . esc_html( (string) $report->version ) . ')<br>'
			. esc_html__( 'Generated', 'wp-reconnaissance' ) . ' ' . esc_html( $report->generated_at->format( 'Y-m-d H:i' ) ) . ' UTC</p>'
			. '</header>';
	}

	/**
	 * @param array<string,mixed> $document
	 */
	private function render_immediate_priorities( array $document ): string {
		$plan = is_array( $document['remediation_plan'] ?? null ) ? $document['remediation_plan'] : array();
		$p1   = array_values( array_filter( $plan, static fn ( array $task ): bool => 'P1' === ( $task['priority_band'] ?? '' ) ) );

		if ( array() === $p1 ) {
			return $this->render_section( __( 'Immediate priorities', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No immediate-priority (P1) items were identified.', 'wp-reconnaissance' ) . '</p>' );
		}

		$items = '';
		foreach ( $p1 as $task ) {
			$items .= '<li>' . esc_html( (string) ( $task['title'] ?? '' ) ) . '</li>';
		}

		return $this->render_section( __( 'Immediate priorities', 'wp-reconnaissance' ), '<ul>' . $items . '</ul>' );
	}

	/**
	 * @param array<string,mixed> $document
	 */
	private function render_remediation_plan( array $document ): string {
		$plan = is_array( $document['remediation_plan'] ?? null ) ? $document['remediation_plan'] : array();

		if ( array() === $plan ) {
			return $this->render_section( __( 'Prioritised remediation plan', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No remediation tasks are currently open.', 'wp-reconnaissance' ) . '</p>' );
		}

		$rows = '';
		foreach ( $plan as $task ) {
			$rows .= '<tr>'
				. '<td>' . esc_html( (string) ( $task['priority_band'] ?? '' ) ) . '</td>'
				. '<td>' . esc_html( (string) ( $task['title'] ?? '' ) ) . '</td>'
				. '<td>' . esc_html( ucwords( str_replace( '_', ' ', (string) ( $task['technical_subject'] ?? '' ) ) ) ) . '</td>'
				. '<td>' . esc_html( ucwords( str_replace( '_', ' ', (string) ( $task['status'] ?? '' ) ) ) ) . '</td>'
				. '</tr>';
		}

		$table = '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__( 'Priority', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Task', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Technical subject', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '</tr></thead><tbody>' . $rows . '</tbody></table>';

		return $this->render_section( __( 'Prioritised remediation plan', 'wp-reconnaissance' ), $table );
	}

	/**
	 * @param array<string,mixed> $document
	 */
	private function render_findings_by_subject( array $document ): string {
		$findings = is_array( $document['findings'] ?? null ) ? $document['findings'] : array();

		if ( array() === $findings ) {
			return $this->render_section( __( 'Findings', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No findings were recorded for this assessment.', 'wp-reconnaissance' ) . '</p>' );
		}

		$by_category = array();
		foreach ( $findings as $finding ) {
			$by_category[ (string) ( $finding['category'] ?? 'other' ) ][] = $finding;
		}

		$body = '';
		foreach ( $by_category as $category => $category_findings ) {
			$body .= '<h3>' . esc_html( ucfirst( $category ) ) . '</h3><dl>';

			foreach ( $category_findings as $finding ) {
				$body .= '<dt>' . esc_html( (string) ( $finding['title'] ?? '' ) ) . ' &mdash; '
					. esc_html( ucfirst( (string) ( $finding['severity'] ?? '' ) ) ) . ' / '
					. esc_html( ucfirst( str_replace( '_', ' ', (string) ( $finding['status'] ?? '' ) ) ) ) . '</dt>';
				$body .= '<dd>' . esc_html( (string) ( $finding['risk_statement'] ?? '' ) ) . '<br><em>' . esc_html( (string) ( $finding['recommendation'] ?? '' ) ) . '</em></dd>';
			}

			$body .= '</dl>';
		}

		return $this->render_section( __( 'Findings by technical subject', 'wp-reconnaissance' ), $body );
	}

	/**
	 * @param array<string,mixed> $document
	 */
	private function render_positive_controls( array $document ): string {
		$controls = is_array( $document['positive_controls'] ?? null ) ? $document['positive_controls'] : array();

		if ( array() === $controls ) {
			return '';
		}

		$items = '';
		foreach ( $controls as $control ) {
			$items .= '<li>' . esc_html( (string) $control ) . '</li>';
		}

		return $this->render_section( __( 'Positive controls already observed', 'wp-reconnaissance' ), '<ul>' . $items . '</ul>' );
	}

	/**
	 * @param array<string,mixed> $document
	 */
	private function render_technical_appendix( array $document ): string {
		$appendix = is_array( $document['technical_appendix'] ?? null ) ? $document['technical_appendix'] : array();
		$versions = is_array( $document['versions'] ?? null ) ? $document['versions'] : array();

		$body = '<pre>' . esc_html( (string) wp_json_encode( array_merge( $appendix, array( 'versions' => $versions ) ), JSON_PRETTY_PRINT ) ) . '</pre>';

		return $this->render_section( __( 'Technical appendix', 'wp-reconnaissance' ), $body );
	}

	private function render_support_options(): string {
		return $this->render_section(
			__( 'Need help acting on this report?', 'wp-reconnaissance' ),
			'<p>' . esc_html__( 'This report and its remediation plan are complete and actionable on their own. If you would like Alltime Technologies to help implement any of the above, contact your account representative.', 'wp-reconnaissance' ) . '</p>'
		);
	}

	private function render_section( string $title, string $body_html ): string {
		return '<section class="wpr-report__section"><h2>' . esc_html( $title ) . '</h2>' . $body_html . '</section>';
	}
}
