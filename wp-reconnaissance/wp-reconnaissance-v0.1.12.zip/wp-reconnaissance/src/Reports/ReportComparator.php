<?php
/**
 * Compares two issued report versions for the same scope (Section 33 "issued report versions") -
 * "what changed since your last report." Reuses {@see \Alltime\WPReconnaissance\Findings\AssetDiffer},
 * the same pure set-comparison Section 33's generalized change engine already uses for evidence
 * diffing, applied here to the stable `finding_id` each report document's `findings` entries
 * carry rather than an asset identifier.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Domain\Report;
use Alltime\WPReconnaissance\Findings\AssetDiffer;

final class ReportComparator {

	public function __construct(
		private readonly AssetDiffer $differ = new AssetDiffer()
	) {}

	/**
	 * `$earlier` and `$later` may be passed in either order - the comparison is always earlier
	 * version's absence/presence relative to the later one, not dependent on call order.
	 */
	public function compare( Report $earlier, Report $later ): ReportComparison {
		$earlier_findings = self::findings_by_id( $earlier );
		$later_findings   = self::findings_by_id( $later );

		$diff = $this->differ->diff(
			array_map( 'strval', array_keys( $earlier_findings ) ),
			array_map( 'strval', array_keys( $later_findings ) )
		);

		return new ReportComparison(
			new_findings: array_values( array_map( static fn ( string $id ): array => $later_findings[ (int) $id ], $diff->added ) ),
			resolved_findings: array_values( array_map( static fn ( string $id ): array => $earlier_findings[ (int) $id ], $diff->removed ) )
		);
	}

	/**
	 * @return array<int,array<string,mixed>> finding_id => finding sub-document.
	 */
	private static function findings_by_id( Report $report ): array {
		$result = array();

		foreach ( (array) ( $report->document['findings'] ?? array() ) as $finding ) {
			if ( is_array( $finding ) && isset( $finding['finding_id'] ) ) {
				$result[ (int) $finding['finding_id'] ] = $finding;
			}
		}

		return $result;
	}
}
