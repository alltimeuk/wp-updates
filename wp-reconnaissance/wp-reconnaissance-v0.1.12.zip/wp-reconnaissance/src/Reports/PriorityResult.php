<?php
/**
 * The output of {@see PriorityCalculator::calculate()}: a priority band plus the transparent,
 * inspectable inputs behind it, per Section 21.5 ("store the calculation inputs and explanation
 * so an operator and customer can understand the order").
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

final class PriorityResult {

	/**
	 * @param array<string,mixed> $explanation
	 */
	public function __construct(
		public readonly PriorityBand $band,
		public readonly int $score,
		public readonly array $explanation,
		public readonly bool $is_enabling_control
	) {}
}
