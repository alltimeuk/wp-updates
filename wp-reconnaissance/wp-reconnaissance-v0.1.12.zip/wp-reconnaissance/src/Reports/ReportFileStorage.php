<?php
/**
 * Stores issued-report PDF files in a protected uploads-adjacent subdirectory, per Section 21.2:
 * "Issued files shall be protected from direct public access and delivered using short-lived,
 * authorised download responses."
 *
 * Only the reference returned by {@see store()} is used by download handlers; nothing in this
 * class is a public URL. The filename is derived deterministically from the report UUID (already
 * unique and immutable), so no schema change is needed to track where a report's PDF lives -
 * {@see reference_for()} stays mode-agnostic and recomputable from the UUID alone; where the file
 * actually lives on disk is decided by {@see ProtectedUploadDirectory}, see its own docblock for
 * the outside-the-document-root strategy and its conservative safety gate.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Support\ProtectedUploadDirectory;
use Alltime\WPReconnaissance\Support\StorageExposureGuard;

final class ReportFileStorage implements ReportStorageInterface {

	private const SUBDIRECTORY = 'wpr-reports';

	/**
	 * Writes the PDF bytes and returns a reference like "wpr-reports/{safe_name}.pdf".
	 *
	 * @throws \Alltime\WPReconnaissance\Support\StorageExposedException When storage has fallen
	 *          back to the `wp-content/uploads` location and Site Health's last check confirmed
	 *          it's directly reachable over the web - see {@see StorageExposureGuard}.
	 */
	public function store( string $report_uuid, string $pdf_bytes ): string {
		$resolved = ProtectedUploadDirectory::resolve_directory( self::SUBDIRECTORY );

		if ( ProtectedUploadDirectory::MODE_UPLOADS === $resolved['mode'] ) {
			StorageExposureGuard::assert_not_exposed( self::SUBDIRECTORY );
		}

		$safe_name = $this->safe_name( $report_uuid );
		$path      = $resolved['path'] . DIRECTORY_SEPARATOR . "{$safe_name}.pdf";

		if ( false === file_put_contents( $path, $pdf_bytes, LOCK_EX ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			throw new \RuntimeException( esc_html( 'Unable to write report PDF to protected storage.' ) );
		}

		chmod( $path, 0600 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod

		return $this->reference_for( $report_uuid );
	}

	/**
	 * Removes the stored PDF for a reference, if it still exists - the retention sweep's
	 * counterpart to {@see store()}.
	 */
	public function delete( string $reference ): void {
		$path = $this->existing_path_for( $reference );

		if ( null !== $path ) {
			wp_delete_file( $path );
		}
	}

	public function retrieve( string $reference ): ?string {
		$path = $this->existing_path_for( $reference );

		if ( null === $path ) {
			return null;
		}

		$contents = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		return false !== $contents ? $contents : null;
	}

	public function reference_for( string $report_uuid ): string {
		return self::SUBDIRECTORY . '/' . $this->safe_name( $report_uuid ) . '.pdf';
	}

	private function safe_name( string $report_uuid ): string {
		return (string) preg_replace( '/[^A-Za-z0-9._-]/', '', $report_uuid );
	}

	/**
	 * A reference is never tagged with the mode it was written under - unlike raw evidence,
	 * reference_for() must stay recomputable from the report UUID alone with no persisted state
	 * (see the class docblock), so it can't record that even if it wanted to. Both possible
	 * locations are checked rather than trusting whichever one currently resolves, since the
	 * storage location decision can change between when a file was written and when it's later
	 * read (a host migration, a resolved permission issue).
	 */
	private function existing_path_for( string $reference ): ?string {
		$basename = basename( $reference );

		foreach ( array( ProtectedUploadDirectory::MODE_ESCAPED, ProtectedUploadDirectory::MODE_UPLOADS ) as $mode ) {
			$path = ProtectedUploadDirectory::directory_for_mode( self::SUBDIRECTORY, $mode ) . DIRECTORY_SEPARATOR . $basename;

			if ( is_file( $path ) ) {
				return $path;
			}
		}

		return null;
	}
}
