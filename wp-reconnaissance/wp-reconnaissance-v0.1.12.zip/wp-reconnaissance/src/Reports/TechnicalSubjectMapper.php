<?php
/**
 * Maps a finding to its primary technical subject, per Section 21.4: "Findings group by
 * technical subject, not by DNS domain name... one subject shall be primary for grouping."
 *
 * Matched by rule ID prefix, most specific pattern first, since that is a stable identifier
 * every rule already carries - falls back to the finding's coarser `category` field only if no
 * rule pattern matches, which should not happen for any rule currently shipped in rules/core.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Domain\Finding;

final class TechnicalSubjectMapper {

	/**
	 * Ordered rule_id prefix => subject. Checked top to bottom so more specific prefixes (e.g.
	 * WEB.CSP.) can be listed before a broader one that would otherwise also match.
	 *
	 * @var array<string,TechnicalSubject>
	 */
	private const RULE_PREFIX_MAP = array(
		'REG.'       => TechnicalSubject::DomainRegistration,
		'DNS.'       => TechnicalSubject::DnsArchitecture,
		'MAIL.'      => TechnicalSubject::EmailAuthentication,
		'TLS.'       => TechnicalSubject::WebTransportTls,
		'WEB.CSP.'   => TechnicalSubject::WebSecurityHeaders,
		'WEB.HSTS.'  => TechnicalSubject::WebSecurityHeaders,
		'WEB.HTTP.'  => TechnicalSubject::WebTransportTls,
		'WEB.HTTPS.' => TechnicalSubject::WebTransportTls,
	);

	/**
	 * @var array<string,TechnicalSubject>
	 */
	private const CATEGORY_FALLBACK_MAP = array(
		'registration' => TechnicalSubject::DomainRegistration,
		'dns'          => TechnicalSubject::DnsArchitecture,
		'mail'         => TechnicalSubject::EmailAuthentication,
		'tls'          => TechnicalSubject::WebTransportTls,
		'web'          => TechnicalSubject::WebSecurityHeaders,
	);

	public function for_finding( Finding $finding ): TechnicalSubject {
		foreach ( self::RULE_PREFIX_MAP as $prefix => $subject ) {
			if ( str_starts_with( $finding->rule_id, $prefix ) ) {
				return $subject;
			}
		}

		return self::CATEGORY_FALLBACK_MAP[ $finding->category ] ?? TechnicalSubject::OperationalGovernance;
	}
}
