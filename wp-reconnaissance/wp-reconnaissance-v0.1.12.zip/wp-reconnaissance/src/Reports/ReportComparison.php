<?php
/**
 * The result of comparing two issued report versions for the same scope, per Section 33's
 * "issued report versions" feature - which findings are new since the earlier version, and which
 * have since resolved.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

final class ReportComparison {

	/**
	 * @param array<int,array<string,mixed>> $new_findings      Finding sub-documents present in
	 *                                                            the later report but not the
	 *                                                            earlier one.
	 * @param array<int,array<string,mixed>> $resolved_findings Finding sub-documents present in
	 *                                                            the earlier report but not the
	 *                                                            later one.
	 */
	public function __construct(
		public readonly array $new_findings,
		public readonly array $resolved_findings
	) {}

	public function has_changes(): bool {
		return array() !== $this->new_findings || array() !== $this->resolved_findings;
	}
}
