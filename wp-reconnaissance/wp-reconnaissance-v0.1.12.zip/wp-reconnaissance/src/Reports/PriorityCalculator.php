<?php
/**
 * Calculates a transparent remediation priority for a finding, per Section 21.5: "Do not sort
 * only by severity label. Calculate a transparent priority rank."
 *
 * Every weight below is a plain class constant so the whole calculation is inspectable in one
 * place, and every component's contribution is returned in the explanation so an operator or
 * customer can see exactly why a finding landed in its band - not just the band itself. Pure
 * function of its inputs (plus an injectable "now" for the persistence check), so it is fully
 * unit-tested without touching WordPress or the database.
 *
 * Deliberately narrower than the full list in Section 21.5: "customer-specific applicability"
 * and "dependency order between specific tasks" need data this plugin does not yet capture
 * (an entitlement/applicability model, an explicit task dependency graph) and are left for a
 * later pass rather than approximated here.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Domain\Finding;

final class PriorityCalculator {

	/** Points per Severity::rank() step (0-4), so severity alone spans 0-60 of the 0-100 scale. */
	private const SEVERITY_WEIGHT = 15;

	/** Points per Confidence::rank() step (0-3), so confidence alone spans 0-24. */
	private const CONFIDENCE_WEIGHT = 8;

	/** Flat bonus when the rule signals a hard external deadline (certificate/domain expiry). */
	private const URGENCY_BONUS = 10;

	/** Flat bonus when the finding sits in a foundational technical subject other controls depend on. */
	private const ENABLEMENT_BONUS = 6;

	/** Flat bonus once a finding has stayed open at least this many days, unaddressed. */
	private const PERSISTENCE_BONUS          = 5;
	private const PERSISTENCE_THRESHOLD_DAYS = 30;

	private const BAND_IMMEDIATE_THRESHOLD = 70;
	private const BAND_HIGH_THRESHOLD      = 45;
	private const BAND_PLANNED_THRESHOLD   = 20;

	/**
	 * Domain registration and DNS architecture are treated as enabling: a broken DNS chain or an
	 * expiring domain undermines every control layered on top of it (mail authentication, TLS,
	 * web headers), so fixing these first is what makes the rest of the plan actually stick.
	 */
	private const ENABLING_TECHNICAL_SUBJECTS = array(
		TechnicalSubject::DomainRegistration,
		TechnicalSubject::DnsArchitecture,
	);

	public function calculate( Finding $finding, TechnicalSubject $technical_subject, ?\DateTimeImmutable $now = null ): PriorityResult {
		$now ??= new \DateTimeImmutable();

		$severity_points   = $finding->severity->rank() * self::SEVERITY_WEIGHT;
		$confidence_points = $finding->confidence->rank() * self::CONFIDENCE_WEIGHT;

		$is_urgent      = $this->has_time_bound_urgency( $finding->rule_id );
		$urgency_points = $is_urgent ? self::URGENCY_BONUS : 0;

		$is_enabling       = in_array( $technical_subject, self::ENABLING_TECHNICAL_SUBJECTS, true );
		$enablement_points = $is_enabling ? self::ENABLEMENT_BONUS : 0;

		$days_open          = $now->diff( $finding->first_observed_at )->days;
		$is_persistent      = $days_open >= self::PERSISTENCE_THRESHOLD_DAYS;
		$persistence_points = $is_persistent ? self::PERSISTENCE_BONUS : 0;

		$score = min( 100, $severity_points + $confidence_points + $urgency_points + $enablement_points + $persistence_points );
		$band  = $this->band_for_score( $score );

		$explanation = array(
			'severity'    => array(
				'value'  => $finding->severity->value,
				'rank'   => $finding->severity->rank(),
				'points' => $severity_points,
			),
			'confidence'  => array(
				'value'  => $finding->confidence->value,
				'rank'   => $finding->confidence->rank(),
				'points' => $confidence_points,
			),
			'urgency'     => array(
				'time_bound_deadline' => $is_urgent,
				'points'              => $urgency_points,
			),
			'enablement'  => array(
				'technical_subject'   => $technical_subject->value,
				'is_enabling_control' => $is_enabling,
				'points'              => $enablement_points,
			),
			'persistence' => array(
				'days_open'     => $days_open,
				'is_persistent' => $is_persistent,
				'points'        => $persistence_points,
			),
			'total_score' => $score,
			'band'        => $band->value,
		);

		return new PriorityResult( $band, $score, $explanation, $is_enabling );
	}

	/**
	 * Matches rule IDs such as TLS.CERT.EXPIRING / TLS.CERT.EXPIRED / REG.DOMAIN.EXPIRING - the
	 * two collection-derived deadlines this plugin currently detects. Widen this list as new
	 * time-bound rules are added rather than trying to infer urgency from severity alone.
	 */
	private function has_time_bound_urgency( string $rule_id ): bool {
		return str_contains( $rule_id, 'EXPIR' );
	}

	private function band_for_score( int $score ): PriorityBand {
		return match ( true ) {
			$score >= self::BAND_IMMEDIATE_THRESHOLD => PriorityBand::Immediate,
			$score >= self::BAND_HIGH_THRESHOLD => PriorityBand::High,
			$score >= self::BAND_PLANNED_THRESHOLD => PriorityBand::Planned,
			default => PriorityBand::Improvement,
		};
	}
}
