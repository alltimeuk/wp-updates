<?php
/**
 * Renders a stored, immutable report document as downloadable PDF bytes, per Section 21.2's
 * "Downloadable PDF" format.
 *
 * Reuses {@see HtmlReportRenderer} for the source markup and converts it to PDF via dompdf.
 * dompdf is a hard Composer dependency, but the renderer still guards on the class being
 * autoloadable and returns null if it is not, so a missing vendor directory degrades to a
 * "PDF not ready" state rather than a fatal error.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Domain\Report;
use Dompdf\Dompdf;
use Dompdf\Options;

final class PdfReportRenderer implements PdfRendererInterface {

	public function __construct(
		private readonly HtmlReportRenderer $html = new HtmlReportRenderer()
	) {}

	public function render( Report $report ): ?string {
		if ( ! class_exists( Dompdf::class ) || ! class_exists( Options::class ) ) {
			return null;
		}

		$options = new Options();
		$options->set( 'defaultFont', 'DejaVu Sans' );
		$options->set( 'isRemoteEnabled', false );
		$options->set( 'isPhpEnabled', false );
		$options->set( 'isJavascriptEnabled', false );

		$dompdf = new Dompdf( $options );
		$dompdf->loadHtml( $this->document( $report ) );
		$dompdf->render();

		return $dompdf->output();
	}

	/**
	 * Wraps the interactive HTML in a minimal, self-contained document with print CSS suited to
	 * the PDF context (the WP admin's `widefat striped` table classes do not exist here).
	 */
	private function document( Report $report ): string {
		return '<!DOCTYPE html><html><head><meta charset="utf-8"><style>'
			. 'body{font-family:"DejaVu Sans",sans-serif;font-size:10pt;color:#1d2327;line-height:1.5}'
			. '@page{margin:2cm}'
			. 'h1{font-size:18pt;margin:0 0 4pt}'
			. 'h2{font-size:13pt;border-bottom:1px solid #c3c4c7;padding-bottom:2pt;margin:16pt 0 6pt}'
			. 'h3{font-size:11pt;margin:10pt 0 4pt}'
			. 'table{width:100%;border-collapse:collapse;margin:6pt 0}'
			. 'th,td{border:1px solid #c3c4c7;padding:4pt 6pt;text-align:left;vertical-align:top}'
			. 'th{background:#f0f0f1}'
			. 'pre{font-size:7pt;white-space:pre-wrap;word-wrap:break-word}'
			. 'dl{margin:4pt 0}dt{font-weight:bold;margin-top:6pt}dd{margin:2pt 0 0 12pt}'
			. '</style></head><body>'
			. $this->html->render( $report )
			. '</body></html>';
	}
}
