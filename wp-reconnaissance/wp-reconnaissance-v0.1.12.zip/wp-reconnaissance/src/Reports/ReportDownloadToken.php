<?php
/**
 * Short-lived, signed download tokens for issued-report PDFs, per Section 21.2's "delivered
 * using short-lived, authorised download responses".
 *
 * A token embeds the report id and an expiry timestamp, signed with an HMAC keyed on the site's
 * auth salt. It is stateless (no database row) and survives the issuing user's session, so a
 * download link can be handed to a customer without tying it to a logged-in session. Verification
 * uses hash_equals() to avoid timing attacks.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

final class ReportDownloadToken {

	private const LIFETIME = 15 * MINUTE_IN_SECONDS;

	/**
	 * Builds a signed, expiring token for a report id.
	 */
	public function create( int $report_id ): string {
		$expires   = time() + self::LIFETIME;
		$payload   = "{$report_id}:{$expires}";
		$signature = $this->sign( $payload );

		return $this->encode( "{$payload}:{$signature}" );
	}

	/**
	 * Whether $token is valid, unexpired, and was issued for exactly $expected_report_id. Callers
	 * must use this rather than `null !== verify( $token )` alone - a token embeds its own report
	 * id precisely so it can only ever authorise the one report it was issued for, but checking
	 * only whether verify() returns non-null (discarding the id it returns) silently drops that
	 * binding: any valid, unexpired token for any report would then authorise a request for a
	 * *different* report id substituted into the URL, provided that report happened to also pass
	 * whatever other check (e.g. organisation ownership) the caller applies separately.
	 */
	public function verify_for( string $token, int $expected_report_id, ?int $now = null ): bool {
		return $this->verify( $token, $now ) === $expected_report_id;
	}

	/**
	 * Returns the report id if the token is valid and unexpired, else null.
	 */
	public function verify( string $token, ?int $now = null ): ?int {
		$decoded = $this->decode( $token );

		if ( null === $decoded ) {
			return null;
		}

		$parts = explode( ':', $decoded );

		if ( 3 !== count( $parts ) ) {
			return null;
		}

		[ $report_id, $expires, $signature ] = $parts;

		if ( ! ctype_digit( $report_id ) || ! ctype_digit( $expires ) ) {
			return null;
		}

		$now = $now ?? time();

		if ( (int) $expires < $now ) {
			return null;
		}

		$payload = "{$report_id}:{$expires}";

		if ( ! hash_equals( $this->sign( $payload ), $signature ) ) {
			return null;
		}

		return (int) $report_id;
	}

	private function sign( string $payload ): string {
		return hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
	}

	private function encode( string $value ): string {
		return rtrim( strtr( base64_encode( $value ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- URL-safe encoding of a signed token payload, not obfuscation.
	}

	private function decode( string $value ): ?string {
		$decoded = base64_decode( strtr( $value, '-_', '+/' ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decodes the URL-safe token payload produced by encode().

		return false !== $decoded ? $decoded : null;
	}
}
