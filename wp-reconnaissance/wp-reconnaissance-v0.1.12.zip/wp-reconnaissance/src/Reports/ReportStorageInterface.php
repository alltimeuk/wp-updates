<?php
/**
 * Contract for persisting and retrieving issued-report PDF files in protected storage, per
 * Section 21.2's "Issued files shall be protected from direct public access" requirement.
 *
 * Kept as an interface so {@see ReportPdfService} can be unit-tested with a mocked store without
 * touching the filesystem - the same mockability seam the anti-abuse module uses for its captcha
 * adapter.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

interface ReportStorageInterface {

	/**
	 * Writes PDF bytes and returns a reference to persist. The reference is never a public URL -
	 * access must always go through an authenticated, capability-checked download handler.
	 */
	public function store( string $report_uuid, string $pdf_bytes ): string;

	/** Removes the stored PDF for a reference, if it still exists. */
	public function delete( string $reference ): void;

	/** Returns the stored PDF bytes for a reference, or null if missing. */
	public function retrieve( string $reference ): ?string;

	/** The deterministic storage reference for a report UUID. */
	public function reference_for( string $report_uuid ): string;
}
