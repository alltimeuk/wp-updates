<?php
/**
 * Renders a stored report document as downloadable Markdown for technical reuse, per Section
 * 21.2. Follows the same section ordering as {@see HtmlReportRenderer}.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Report;

final class MarkdownReportRenderer {

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository()
	) {}

	public function render( Report $report ): string {
		$document     = $report->document;
		$scope        = $this->scopes->find( $report->scope_id );
		$organisation = $this->organisations->find( $report->organisation_id );

		$lines   = array();
		$lines[] = '# Domain Reconnaissance report';
		$lines[] = '';
		$lines[] = sprintf( '%s — %s', $organisation?->name ?? '', $scope?->domain_display ?? '' );
		$lines[] = sprintf( 'Report `%s` (version %d), generated %s UTC', $report->report_uuid, $report->version, $report->generated_at->format( 'Y-m-d H:i' ) );
		$lines[] = '';
		$lines[] = '## Executive summary';
		$lines[] = '';
		$lines[] = (string) ( $document['executive_summary'] ?? '' );
		$lines[] = '';
		$lines[] = '## Prioritised remediation plan';
		$lines[] = '';
		$lines[] = '| Priority | Task | Technical subject | Status |';
		$lines[] = '| --- | --- | --- | --- |';

		foreach ( (array) ( $document['remediation_plan'] ?? array() ) as $task ) {
			$lines[] = sprintf(
				'| %s | %s | %s | %s |',
				(string) ( $task['priority_band'] ?? '' ),
				(string) ( $task['title'] ?? '' ),
				str_replace( '_', ' ', (string) ( $task['technical_subject'] ?? '' ) ),
				str_replace( '_', ' ', (string) ( $task['status'] ?? '' ) )
			);
		}

		$lines[] = '';
		$lines[] = '## Findings';
		$lines[] = '';

		foreach ( (array) ( $document['findings'] ?? array() ) as $finding ) {
			$lines[] = sprintf( '### %s (%s / %s)', (string) ( $finding['title'] ?? '' ), (string) ( $finding['severity'] ?? '' ), (string) ( $finding['status'] ?? '' ) );
			$lines[] = '';
			$lines[] = (string) ( $finding['risk_statement'] ?? '' );
			$lines[] = '';
			$lines[] = '_' . (string) ( $finding['recommendation'] ?? '' ) . '_';
			$lines[] = '';
		}

		$positive_controls = (array) ( $document['positive_controls'] ?? array() );

		if ( array() !== $positive_controls ) {
			$lines[] = '## Positive controls already observed';
			$lines[] = '';

			foreach ( $positive_controls as $control ) {
				$lines[] = '- ' . (string) $control;
			}

			$lines[] = '';
		}

		$lines[] = '## Methodology and limitations';
		$lines[] = '';
		$lines[] = (string) ( $document['method_and_limitations'] ?? '' );

		return implode( "\n", $lines );
	}
}
