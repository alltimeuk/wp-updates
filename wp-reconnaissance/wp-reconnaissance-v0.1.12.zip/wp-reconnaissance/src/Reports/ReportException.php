<?php
/**
 * Thrown when a report cannot be generated for a scope (unknown scope, no completed observation
 * yet to report on).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

final class ReportException extends \RuntimeException {}
