<?php
/**
 * Contract for rendering a stored report document as PDF bytes, per Section 21.2's
 * "Downloadable PDF" format.
 *
 * Kept as an interface so {@see ReportPdfService} can be unit-tested with a mocked renderer
 * without invoking the (heavy, third-party) dompdf engine - the same mockability seam the
 * anti-abuse module uses for its captcha adapter.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Domain\Report;

interface PdfRendererInterface {

	/**
	 * Renders a report to PDF bytes, or null if the PDF engine is unavailable or rendering
	 * failed so the caller can degrade gracefully.
	 */
	public function render( Report $report ): ?string;
}
