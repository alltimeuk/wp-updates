<?php
/**
 * Builds a Domain Reconnaissance report document conforming to schemas/report.schema.json, per
 * Section 21.1's required content and ordering.
 *
 * Does not persist anything - {@see \Alltime\WPReconnaissance\Data\Repositories\ReportRepository::save()}
 * is a separate step, deliberately, so a caller can inspect/preview a draft before issuing it
 * (Section 19.6: "Generate draft report... Review included findings... Issue immutable report
 * version" are three distinct actions).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Data\Repositories\ObservationRepository;
use Alltime\WPReconnaissance\Data\Repositories\RemediationTaskRepository;
use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Finding;
use Alltime\WPReconnaissance\Domain\Observation;
use Alltime\WPReconnaissance\Domain\RemediationTask;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Findings\FindingRepository;
use Alltime\WPReconnaissance\Rules\RuleLoader;

final class DomainReconnaissanceReportBuilder implements ReportGeneratorInterface {

	private const RESOLVED_LIKE_STATUSES = array( FindingStatus::Resolved, FindingStatus::AcceptedRisk, FindingStatus::Suppressed, FindingStatus::FalsePositive );

	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly ObservationRepository $observations = new ObservationRepository(),
		private readonly FindingRepository $findings = new FindingRepository(),
		private readonly RemediationTaskRepository $tasks = new RemediationTaskRepository(),
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly RuleLoader $rule_loader = new RuleLoader()
	) {}

	public function generate( int $scope_id, ?string $executive_summary = null ): array {
		$scope = $this->scopes->find( $scope_id );

		if ( null === $scope ) {
			throw new ReportException( esc_html( "Scope {$scope_id} was not found." ) );
		}

		$observation = $this->observations->find_latest_by_scope( $scope_id );

		if ( null === $observation ) {
			throw new ReportException( esc_html( "Scope {$scope_id} has no completed observation to report on yet." ) );
		}

		$all_findings  = $this->findings->find_by_scope( $scope_id );
		$open_findings = array_values( array_filter( $all_findings, static fn ( Finding $finding ): bool => ! in_array( $finding->status, self::RESOLVED_LIKE_STATUSES, true ) ) );
		$remediation   = $this->tasks->find_by_scope( $scope_id );
		$previous      = $this->reports->find_latest_by_scope( $scope_id );

		return array(
			'report_id'              => wp_generate_uuid4(),
			'version'                => $this->reports->next_version( $scope_id ),
			'organisation_id'        => $scope->organisation_id,
			'scope_id'               => $scope_id,
			'observation_id'         => (int) $observation->id,
			'generated_at'           => ( new \DateTimeImmutable() )->format( DATE_ATOM ),
			'assessment_period'      => array(
				'from' => ( $previous?->generated_at ?? $observation->observed_at )->format( DATE_ATOM ),
				'to'   => $observation->observed_at->format( DATE_ATOM ),
			),
			'method_and_limitations' => $this->method_and_limitations( $observation ),
			'executive_summary'      => $executive_summary ?? $this->default_executive_summary( $scope, $open_findings ),
			'findings'               => array_map( array( $this, 'finding_to_document' ), $all_findings ),
			'positive_controls'      => $this->positive_controls( $all_findings ),
			'remediation_plan'       => array_map( array( $this, 'task_to_document' ), $remediation ),
			'technical_appendix'     => array(
				'collector_versions' => $observation->collector_versions,
				'failed_collectors'  => $observation->failed_collectors,
			),
			'versions'               => array(
				'worker_version' => $observation->collector_versions['registration'] ?? null,
				'schema_version' => $observation->schema_version,
			),
		);
	}

	/**
	 * @param Finding[] $open_findings
	 */
	private function default_executive_summary( Scope $scope, array $open_findings ): string {
		if ( array() === $open_findings ) {
			return sprintf(
				/* translators: %s: assessed domain */
				__( 'No open findings were identified for %s at the time of this assessment.', 'wp-reconnaissance' ),
				$scope->domain_display
			);
		}

		$highest = array_reduce(
			$open_findings,
			static fn ( ?Finding $carry, Finding $finding ): Finding => null === $carry || $finding->severity->rank() > $carry->severity->rank() ? $finding : $carry
		);

		return sprintf(
			/* translators: 1: number of open findings, 2: assessed domain, 3: highest observed severity */
			__( '%1$d open finding(s) were identified for %2$s. The highest-severity finding observed is rated "%3$s". See the prioritised remediation plan below.', 'wp-reconnaissance' ),
			count( $open_findings ),
			$scope->domain_display,
			ucfirst( $highest?->severity->value ?? 'informational' )
		);
	}

	private function method_and_limitations( Observation $observation ): string {
		$parts = array(
			__( 'This assessment is limited to externally observable, passive checks: DNS, mail authentication, HTTP/TLS configuration, certificate transparency, subdomain discovery and lookalike-domain detection. It does not perform port scanning beyond explicitly implemented protocol connections, vulnerability exploitation, credential testing or any active takeover attempt.', 'wp-reconnaissance' ),
		);

		if ( array() !== $observation->limitations ) {
			$parts[] = __( 'Limitations noted during collection:', 'wp-reconnaissance' ) . ' ' . implode( '; ', $observation->limitations ) . '.';
		}

		if ( array() !== $observation->failed_collectors ) {
			$parts[] = __( 'The following collectors did not complete successfully and are excluded from this report:', 'wp-reconnaissance' ) . ' ' . implode( ', ', $observation->failed_collectors ) . '.';
		}

		return implode( ' ', $parts );
	}

	/**
	 * Rules that were evaluated for this scope but did not produce an open finding - a factual,
	 * cheap-to-compute stand-in for a fuller "positive controls" narrative, per Section 21 point 9.
	 *
	 * @param Finding[] $all_findings
	 * @return string[]
	 */
	private function positive_controls( array $all_findings ): array {
		$open_rule_ids = array_map(
			static fn ( Finding $finding ): string => $finding->rule_id,
			array_filter( $all_findings, static fn ( Finding $finding ): bool => ! in_array( $finding->status, self::RESOLVED_LIKE_STATUSES, true ) )
		);

		$controls = array();

		foreach ( $this->rule_loader->load_core_rules() as $rule_id => $rule ) {
			if ( ! in_array( $rule_id, $open_rule_ids, true ) ) {
				$controls[] = $rule->title;
			}
		}

		return $controls;
	}

	/**
	 * @return array<string,mixed>
	 */
	private function finding_to_document( Finding $finding ): array {
		return array(
			'finding_id'          => $finding->finding_uuid,
			'rule_id'             => $finding->rule_id,
			'rule_version'        => $finding->rule_version,
			'title'               => $finding->title,
			'category'            => $finding->category,
			'severity'            => $finding->severity->value,
			'confidence'          => $finding->confidence->value,
			'status'              => $finding->status->value,
			'risk_statement'      => $finding->risk_statement ?? '',
			'recommendation'      => $finding->recommendation ?? '',
			'evidence_references' => $finding->evidence_refs,
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private function task_to_document( RemediationTask $task ): array {
		return array(
			'task_id'           => $task->task_uuid,
			'finding_id'        => (string) $task->finding_id,
			'title'             => $task->title,
			'technical_subject' => $task->technical_subject->value,
			'priority_band'     => $task->priority_band->value,
			'recommended_order' => $task->recommended_order,
			'status'            => $task->status->value,
		);
	}
}
