<?php
/**
 * Generates or refreshes remediation tasks for a scope's current findings, per Section 21.3.
 *
 * Every actionable finding maps to exactly one task, kept updated across re-scans rather than
 * duplicated (Section 21.3: "must not silently destroy the task history") -
 * {@see \Alltime\WPReconnaissance\Data\Repositories\RemediationTaskRepository::upsert_for_finding()}
 * never touches a task's `status`, `customer_notes` or `operator_notes` on an update, only its
 * priority/content fields, so an operator's manual progress is never clobbered by a re-scan.
 *
 * A finding that has since resolved, been accepted as risk, suppressed or marked a false
 * positive transitions its linked task to the matching terminal status instead of being
 * re-prioritised - there is nothing left to prioritise once the underlying finding is gone.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

use Alltime\WPReconnaissance\Data\Repositories\RemediationTaskRepository;
use Alltime\WPReconnaissance\Data\Repositories\TaskEventRepository;
use Alltime\WPReconnaissance\Domain\Enums\FindingStatus;
use Alltime\WPReconnaissance\Domain\Enums\RemediationTaskStatus;
use Alltime\WPReconnaissance\Domain\Finding;
use Alltime\WPReconnaissance\Domain\RemediationTask;
use Alltime\WPReconnaissance\Findings\FindingRepository;

final class RemediationTaskGenerator {

	/**
	 * Finding status => the remediation task status a linked task should move to once the
	 * finding itself is no longer actionable.
	 *
	 * @var array<string,RemediationTaskStatus>
	 */
	private const TERMINAL_FINDING_STATUS_MAP = array(
		'resolved'       => RemediationTaskStatus::Completed,
		'accepted_risk'  => RemediationTaskStatus::AcceptedRisk,
		'suppressed'     => RemediationTaskStatus::NotApplicable,
		'false_positive' => RemediationTaskStatus::NotApplicable,
	);

	/**
	 * @var array<string,string>
	 */
	private const OWNER_TYPE_BY_SUBJECT = array(
		'domain_registration_and_ownership'               => 'Domain administrator',
		'dns_architecture_and_resilience'                 => 'DNS/Infrastructure administrator',
		'email_authentication_and_deliverability'         => 'Email/Messaging administrator',
		'web_transport_and_tls_pki'                       => 'Web/Infrastructure administrator',
		'web_security_headers_and_browser_controls'       => 'Web/Infrastructure administrator',
		'public_asset_and_subdomain_governance'           => 'IT asset owner',
		'brand_protection_and_lookalike_domains'          => 'Security/Brand protection owner',
		'monitoring_ownership_and_operational_governance' => 'Security owner',
	);

	public function __construct(
		private readonly FindingRepository $findings = new FindingRepository(),
		private readonly RemediationTaskRepository $tasks = new RemediationTaskRepository(),
		private readonly TaskEventRepository $task_events = new TaskEventRepository(),
		private readonly PriorityCalculator $priority_calculator = new PriorityCalculator(),
		private readonly TechnicalSubjectMapper $subject_mapper = new TechnicalSubjectMapper()
	) {}

	/**
	 * @return RemediationTask[] Every task now linked to the scope, ordered as recommended.
	 */
	public function generate_for_scope( int $scope_id, ?int $actor_id = null ): array {
		$findings = $this->findings->find_by_scope( $scope_id );
		$queue    = array();

		foreach ( $findings as $finding ) {
			$terminal_status = self::TERMINAL_FINDING_STATUS_MAP[ $finding->status->value ] ?? null;

			if ( null !== $terminal_status ) {
				$this->close_task_if_present( $finding, $terminal_status, $actor_id );
				continue;
			}

			if ( ! $this->is_actionable( $finding->status ) ) {
				continue;
			}

			$technical_subject = $this->subject_mapper->for_finding( $finding );
			$priority          = $this->priority_calculator->calculate( $finding, $technical_subject );

			$queue[] = array( $finding, $technical_subject, $priority );
		}

		// Highest score first; ties broken by enabling-control status (Section 21.5: "order
		// enabling controls before dependent improvements"), then by raw severity as a final,
		// stable tiebreaker.
		usort(
			$queue,
			static function ( array $a, array $b ): int {
				[ $finding_a, , $priority_a ] = $a;
				[ $finding_b, , $priority_b ] = $b;

				return array( $priority_b->score, $priority_b->is_enabling_control, $finding_b->severity->rank() )
					<=> array( $priority_a->score, $priority_a->is_enabling_control, $finding_a->severity->rank() );
			}
		);

		$tasks = array();
		$order = 1;

		foreach ( $queue as [ $finding, $technical_subject, $priority ] ) {
			$tasks[] = $this->upsert_task( $finding, $technical_subject, $priority, $order, $actor_id );
			++$order;
		}

		return $tasks;
	}

	private function is_actionable( FindingStatus $status ): bool {
		return in_array( $status, array( FindingStatus::New, FindingStatus::Open, FindingStatus::Acknowledged, FindingStatus::InProgress ), true );
	}

	private function close_task_if_present( Finding $finding, RemediationTaskStatus $target_status, ?int $actor_id ): void {
		$existing = $this->tasks->find_by_finding( (int) $finding->id );

		if ( null === $existing || $existing->status === $target_status ) {
			return;
		}

		$this->tasks->update_status( (int) $existing->id, $target_status, $existing->customer_notes, $existing->operator_notes, $existing->target_date );
		$this->task_events->record( (int) $existing->id, 'finding_' . $finding->status->value, $actor_id, "Finding {$finding->rule_id} moved to {$finding->status->value}" );
	}

	private function upsert_task( Finding $finding, TechnicalSubject $technical_subject, PriorityResult $priority, int $recommended_order, ?int $actor_id ): RemediationTask {
		$existed_before = null !== $this->tasks->find_by_finding( (int) $finding->id );

		$task = $this->tasks->upsert_for_finding(
			$finding->organisation_id,
			$finding->scope_id,
			(int) $finding->id,
			$finding->rule_id,
			$finding->title,
			$technical_subject,
			$priority->band,
			$priority->score,
			$priority->explanation,
			$recommended_order,
			$finding->risk_statement,
			null !== $finding->recommendation ? array( $finding->recommendation ) : array(),
			array( __( 'Re-run the Domain Reconnaissance assessment for this scope and confirm the finding no longer recurs.', 'wp-reconnaissance' ) ),
			array(),
			self::OWNER_TYPE_BY_SUBJECT[ $technical_subject->value ],
			null
		);

		$this->task_events->record(
			(int) $task->id,
			$existed_before ? 'refreshed' : 'created',
			$actor_id,
			"Priority {$priority->band->value} (score {$priority->score}) from finding {$finding->rule_id}"
		);

		return $task;
	}
}
