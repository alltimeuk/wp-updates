<?php
/**
 * Contract for generating an immutable, versioned report from a reviewed observation and its
 * findings, per Section 21.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Reports;

interface ReportGeneratorInterface {

	/**
	 * Generates a new report document (see `schemas/report.schema.json`) for a scope's latest
	 * reviewed observation. A correction to an issued report must call this again to create a
	 * new version rather than mutating the existing one.
	 *
	 * $executive_summary is the operator-authored plain-language summary Section 19.6 requires
	 * as its own review step before a report is issued; when omitted, a short factual summary is
	 * generated instead so the document is still schema-valid and meaningful on its own.
	 *
	 * @return array<string,mixed> A document conforming to schemas/report.schema.json.
	 */
	public function generate( int $scope_id, ?string $executive_summary = null ): array;
}
