<?php
/**
 * A persisted row from `wpr_notification_digest_entries` - one pending line item for an account
 * that chose daily-digest delivery over immediate, per Section 33.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications;

final class DigestEntry {

	public function __construct(
		public readonly int $id,
		public readonly int $organisation_id,
		public readonly int $user_id,
		public readonly string $idempotency_key,
		public readonly string $subject,
		public readonly string $summary,
		public readonly \DateTimeImmutable $created_at,
		public readonly ?\DateTimeImmutable $sent_at
	) {}

	/**
	 * @param array<string,mixed> $row
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: (int) $row['id'],
			organisation_id: (int) $row['organisation_id'],
			user_id: (int) $row['user_id'],
			idempotency_key: (string) $row['idempotency_key'],
			subject: (string) $row['subject'],
			summary: (string) $row['summary'],
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			sent_at: ! empty( $row['sent_at'] ) ? new \DateTimeImmutable( (string) $row['sent_at'] ) : null
		);
	}
}
