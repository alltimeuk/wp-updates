<?php
/**
 * Translates domain events into queued customer notifications, per Section 22.5's trigger list.
 *
 * Listens to the plain action hooks Section 22.5 itself specifies
 * (`wpr_finding_created`, `wpr_finding_changed`, `wpr_report_issued`, `wpr_job_completed`) so any
 * other integration can listen to the same events independently - this class has no special
 * access, it is just the first (and, today, only) subscriber. Every enqueue call carries a
 * stable, event-derived idempotency key, never a random one, so a hook firing twice (or a cron
 * tick re-scanning the same still-expiring scope tomorrow) can never double-send.
 *
 * Implements Section 22.5's trigger list: new high/critical finding, existing finding worsened,
 * report ready / free report ready, repeated collection failure, authorisation approaching
 * expiry, new assets - certificates, subdomains, IP addresses, DKIM selectors - via
 * {@see \Alltime\WPReconnaissance\Findings\AssetChangeDetector}'s generalized evidence-level
 * diffing between observations (Section 33), and the customer-requested task reminder (daily
 * sweep). The new mail-enabled lookalike domain trigger remains unimplemented - it needs the
 * lookalike collector to emit evidence, which the worker does not produce yet.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications;

use Alltime\WPReconnaissance\Auth\CustomerAccount;
use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Auth\Enums\NotificationFrequency;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\ObservationRepository;
use Alltime\WPReconnaissance\Data\Repositories\RemediationTaskRepository;
use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Enums\ChangeSignificance;
use Alltime\WPReconnaissance\Domain\Enums\JobStatus;
use Alltime\WPReconnaissance\Domain\Enums\Severity;
use Alltime\WPReconnaissance\Domain\Job;
use Alltime\WPReconnaissance\Findings\AssetChangeDetector;
use Alltime\WPReconnaissance\Findings\FindingEventRepository;
use Alltime\WPReconnaissance\Findings\FindingRepository;
use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\Repositories\DigestEntryRepository;

final class NotificationDispatcher {

	private const EXPIRY_WARNING_DAYS        = 14;
	private const REPEATED_FAILURE_THRESHOLD = 3;

	public function __construct(
		private readonly FindingRepository $findings = new FindingRepository(),
		private readonly FindingEventRepository $finding_events = new FindingEventRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly MailQueueService $mail_queue = new MailQueueService(),
		private readonly RemediationTaskRepository $tasks = new RemediationTaskRepository(),
		private readonly ObservationRepository $observations = new ObservationRepository(),
		private readonly AssetChangeDetector $asset_changes = new AssetChangeDetector(),
		private readonly DigestEntryRepository $digest_entries = new DigestEntryRepository()
	) {}

	public function boot(): void {
		add_action( 'wpr_finding_created', array( $this, 'on_finding_created' ) );
		add_action( 'wpr_finding_changed', array( $this, 'on_finding_changed' ), 10, 2 );
		add_action( 'wpr_report_issued', array( $this, 'on_report_issued' ) );
		add_action( 'wpr_job_completed', array( $this, 'on_job_completed' ) );
		add_action( 'wpr_job_completed', array( $this, 'check_new_assets' ) );
	}

	public function on_finding_created( int $finding_id ): void {
		$finding = $this->findings->find( $finding_id );

		if ( null === $finding || ! in_array( $finding->severity, array( Severity::High, Severity::Critical ), true ) ) {
			return;
		}

		$this->notify_organisation(
			$finding->organisation_id,
			static fn ( CustomerAccount $account ): string => "finding_created:{$finding_id}:{$account->user_id}",
			__( 'New security finding requires attention', 'wp-reconnaissance' ),
			'<p>' . sprintf(
				/* translators: 1: severity, 2: finding title (HTML) */
				esc_html__( 'A new %1$s-severity finding has been identified: %2$s.', 'wp-reconnaissance' ),
				esc_html( ucfirst( $finding->severity->value ) ),
				'<strong>' . esc_html( $finding->title ) . '</strong>'
			) . '</p><p>' . esc_html__( 'Sign in to your account to review the details and recommended remediation.', 'wp-reconnaissance' ) . '</p>',
			'new_high_critical_finding'
		);
	}

	public function on_finding_changed( int $finding_id, int $event_id ): void {
		if ( ChangeSignificance::Worsened !== $this->finding_events->find_event_type( $event_id ) ) {
			return;
		}

		$finding = $this->findings->find( $finding_id );

		if ( null === $finding ) {
			return;
		}

		$this->notify_organisation(
			$finding->organisation_id,
			static fn ( CustomerAccount $account ): string => "finding_worsened:{$event_id}:{$account->user_id}",
			__( 'A finding has worsened', 'wp-reconnaissance' ),
			'<p>' . sprintf(
				/* translators: %s: finding title (HTML) */
				esc_html__( 'A previously identified finding has worsened: %s.', 'wp-reconnaissance' ),
				'<strong>' . esc_html( $finding->title ) . '</strong>'
			) . '</p><p>' . esc_html__( 'Sign in to your account to review the updated details.', 'wp-reconnaissance' ) . '</p>',
			'finding_worsened'
		);
	}

	public function on_report_issued( int $report_id ): void {
		$report = $this->reports->find( $report_id );

		if ( null === $report ) {
			return;
		}

		$is_first_report = 1 === $report->version;

		$this->notify_organisation(
			$report->organisation_id,
			static fn ( CustomerAccount $account ): string => "report_issued:{$report_id}:{$account->user_id}",
			$is_first_report ? __( 'Your free assessment report is ready', 'wp-reconnaissance' ) : __( 'A new assessment report is ready', 'wp-reconnaissance' ),
			'<p>' . esc_html__( 'Your Domain Reconnaissance report is ready to view.', 'wp-reconnaissance' ) . '</p><p>' . esc_html__( 'Sign in to your account to review the findings and remediation plan.', 'wp-reconnaissance' ) . '</p>',
			$is_first_report ? 'free_report_ready' : 'report_ready'
		);
	}

	public function on_job_completed( int $job_id ): void {
		$job = $this->jobs->find( $job_id );

		if ( null === $job || JobStatus::Failed !== $job->status ) {
			return;
		}

		$recent = $this->jobs->find_by_scope( $job->scope_id, self::REPEATED_FAILURE_THRESHOLD );

		if ( count( $recent ) < self::REPEATED_FAILURE_THRESHOLD || $this->any_succeeded( $recent ) ) {
			return;
		}

		$this->notify_organisation(
			$job->organisation_id,
			static fn ( CustomerAccount $account ): string => "repeated_failure:{$job->scope_id}:{$job_id}:{$account->user_id}",
			__( 'Repeated assessment failures', 'wp-reconnaissance' ),
			'<p>' . esc_html__( 'Your last several assessment attempts have failed. This may indicate a configuration issue with your domain or DNS. Contact support if this continues.', 'wp-reconnaissance' ) . '</p>',
			'repeated_collection_failure'
		);
	}

	/**
	 * Daily-sweep trigger (called from {@see \Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap::run_daily_maintenance()})
	 * rather than a single event - authorisation expiry is a fact about the passage of time, not
	 * something that happens at one instant this plugin already observes.
	 */
	public function check_expiring_authorisations(): void {
		foreach ( $this->scopes->find_expiring_authorisations( self::EXPIRY_WARNING_DAYS ) as $scope ) {
			$this->notify_organisation(
				$scope->organisation_id,
				static fn ( CustomerAccount $account ): string => 'auth_expiring:' . $scope->id . ':' . ( new \DateTimeImmutable() )->format( 'Y-m-d' ) . ":{$account->user_id}",
				__( 'Authorisation approaching expiry', 'wp-reconnaissance' ),
				'<p>' . sprintf(
					/* translators: %s: assessed domain */
					esc_html__( 'Your authorisation for assessing %s is approaching its expiry date. Renew it to keep monitoring active.', 'wp-reconnaissance' ),
					esc_html( $scope->domain_display )
				) . '</p>',
				'authorisation_expiring'
			);
		}
	}

	/**
	 * Daily-sweep trigger (called from {@see \Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap::run_daily_maintenance()})
	 * for the customer-requested remediation task reminder (Section 22.5). Sends one reminder per
	 * task per account - the idempotency key is stable per task, so a task that stays overdue
	 * across several daily sweeps is reminded once, not spammed daily.
	 */
	public function check_task_reminders(): void {
		foreach ( $this->tasks->find_due_reminders() as $task ) {
			$this->notify_organisation(
				$task->organisation_id,
				static fn ( CustomerAccount $account ): string => "task_reminder:{$task->id}:{$account->user_id}",
				__( 'Reminder: remediation task target date', 'wp-reconnaissance' ),
				'<p>' . sprintf(
					/* translators: 1: task title (HTML), 2: target date */
					esc_html__( 'You asked to be reminded about the remediation task %1$s. Its target date is %2$s.', 'wp-reconnaissance' ),
					'<strong>' . esc_html( $task->title ) . '</strong>',
					esc_html( $task->target_date?->format( 'Y-m-d' ) ?? '' )
				) . '</p><p>' . esc_html__( 'Sign in to your account to review the task and update its status.', 'wp-reconnaissance' ) . '</p>',
				'task_reminder'
			);
		}
	}

	/**
	 * Evidence-level diffing trigger (Section 22.5 "New certificate or subdomain"): compares the
	 * just-completed observation's Certificate Transparency and subdomain evidence against the
	 * preceding observation and notifies the organisation of anything newly seen. Fires on the
	 * same `wpr_job_completed` hook as {@see on_job_completed()} but only for successful runs.
	 */
	public function check_new_assets( int $job_id ): void {
		$job = $this->jobs->find( $job_id );

		if ( null === $job || ! in_array( $job->status, array( JobStatus::Succeeded, JobStatus::PartiallySucceeded ), true ) ) {
			return;
		}

		$current = $this->observations->find_latest_by_scope( $job->scope_id );

		if ( null === $current ) {
			return;
		}

		$previous = $this->observations->find_previous( $job->scope_id, (int) $current->id );

		if ( null === $previous ) {
			return;
		}

		$current_evidence  = $this->observations->evidence_data_by_collector( (int) $current->id );
		$previous_evidence = $this->observations->evidence_data_by_collector( (int) $previous->id );

		$changes = $this->asset_changes->detect( $previous_evidence, $current_evidence );

		$details = array();
		foreach ( $changes as $kind => $diff ) {
			foreach ( $diff->added as $identifier ) {
				$details[] = esc_html__( 'New ', 'wp-reconnaissance' ) . esc_html( $this->asset_changes->label( $kind ) ) . ': ' . esc_html( $identifier );
			}
		}

		if ( array() === $details ) {
			return;
		}

		$this->notify_organisation(
			$job->organisation_id,
			static fn ( CustomerAccount $account ): string => "new_assets:{$job_id}:{$account->user_id}",
			__( 'New assets detected', 'wp-reconnaissance' ),
			'<p>' . esc_html__( 'The latest assessment found assets that were not present before:', 'wp-reconnaissance' ) . '</p><ul><li>'
				. implode( '</li><li>', $details )
				. '</li></ul><p>' . esc_html__( 'Sign in to your account to review the details.', 'wp-reconnaissance' ) . '</p>',
			'new_certificate_or_subdomain'
		);
	}

	/**
	 * @param Job[] $jobs
	 */
	private function any_succeeded( array $jobs ): bool {
		foreach ( $jobs as $job ) {
			if ( JobStatus::Failed !== $job->status ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Delivers immediately for an account on the default {@see NotificationFrequency::Immediate}
	 * preference (unchanged behaviour), or - for one that chose
	 * {@see NotificationFrequency::DailyDigest} (Section 33) - records a pending digest line
	 * instead of enqueueing mail at all; {@see NotificationDigestService} folds it into that
	 * account's next combined email. Both paths use the same idempotency key, so a hook firing
	 * twice can never duplicate a notification regardless of which delivery mode an account uses.
	 *
	 * @param callable(CustomerAccount):string $idempotency_key
	 */
	private function notify_organisation( int $organisation_id, callable $idempotency_key, string $subject, string $html_body, string $template ): void {
		foreach ( $this->accounts->find_by_organisation( $organisation_id ) as $account ) {
			$key = $idempotency_key( $account );

			if ( NotificationFrequency::DailyDigest === $this->accounts->get_notification_frequency( $account->user_id ) ) {
				$this->digest_entries->add_if_new( $organisation_id, $account->user_id, $key, $subject, wp_strip_all_tags( $html_body ) );
				continue;
			}

			$this->mail_queue->enqueue(
				new QueuedMessage(
					idempotency_key: $key,
					recipient: $account->email,
					template: $template,
					purpose: MailPurpose::ServiceDelivery,
					subject: $subject,
					html_body: $html_body
				)
			);
		}
	}
}
