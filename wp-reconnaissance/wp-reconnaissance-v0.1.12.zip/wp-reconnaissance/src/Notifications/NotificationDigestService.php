<?php
/**
 * Folds an account's pending digest entries (Section 33) into a single combined email, for
 * customers who chose {@see \Alltime\WPReconnaissance\Auth\Enums\NotificationFrequency::DailyDigest}
 * over immediate per-event delivery. Runs as part of the existing daily maintenance sweep, not
 * its own cron - one batched send per account per day is exactly the cadence that sweep already
 * runs at.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications;

use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\Repositories\DigestEntryRepository;

final class NotificationDigestService {

	public function __construct(
		private readonly DigestEntryRepository $entries = new DigestEntryRepository(),
		private readonly MailQueueService $mail_queue = new MailQueueService()
	) {}

	public function send_due_digests(): void {
		foreach ( $this->entries->find_user_ids_with_pending_entries() as $user_id ) {
			$this->send_digest_for_user( $user_id );
		}
	}

	private function send_digest_for_user( int $user_id ): void {
		$entries = $this->entries->find_pending_by_user( $user_id );

		if ( array() === $entries ) {
			return;
		}

		$user = get_userdata( $user_id );

		if ( false === $user ) {
			return;
		}

		$items = array();
		foreach ( $entries as $entry ) {
			$items[] = '<li><strong>' . esc_html( $entry->subject ) . '</strong>: ' . esc_html( $entry->summary ) . '</li>';
		}

		$this->mail_queue->enqueue(
			new QueuedMessage(
				idempotency_key: 'notification_digest:' . $user_id . ':' . gmdate( 'Y-m-d' ),
				recipient: $user->user_email,
				template: 'notification_digest',
				purpose: MailPurpose::ServiceDelivery,
				subject: __( 'Your WP Reconnaissance daily digest', 'wp-reconnaissance' ),
				html_body: '<p>' . esc_html__( 'Here is a summary of what happened since your last digest:', 'wp-reconnaissance' ) . '</p><ul>'
					. implode( '', $items )
					. '</ul><p>' . esc_html__( 'Sign in to your account to review the details.', 'wp-reconnaissance' ) . '</p>'
			)
		);

		$this->entries->mark_sent( array_map( static fn ( DigestEntry $entry ): int => $entry->id, $entries ) );
	}
}
