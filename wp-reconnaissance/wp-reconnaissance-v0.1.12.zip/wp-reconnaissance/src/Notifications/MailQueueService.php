<?php
/**
 * The persistent transactional mail queue, per Section 22.5.
 *
 * Enqueuing only ever persists a row and schedules its send as a separate action (Section 15:
 * PHP web requests must stay short) - never sends inline from the request that triggered it.
 * {@see \Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap} owns the actual scheduling
 * mechanism (Action Scheduler or WP-Cron), mirroring how job dispatch already works.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications;

use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Integrations\Exceptions\MailDeliveryException;
use Alltime\WPReconnaissance\Integrations\MailManager;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\Enums\MailState;
use Alltime\WPReconnaissance\Notifications\Repositories\MailEventRepository;
use Alltime\WPReconnaissance\Notifications\Repositories\MailQueueRepository;
use Alltime\WPReconnaissance\Scheduling\SchedulingBootstrap;

final class MailQueueService {

	private const MAX_ATTEMPTS = 3;

	/** Minutes to wait before each successive retry (Section 22.5: "bounded backoff"). */
	private const RETRY_BACKOFF_MINUTES = array( 5, 30, 120 );

	public function __construct(
		private readonly MailQueueRepository $queue = new MailQueueRepository(),
		private readonly MailEventRepository $events = new MailEventRepository(),
		private readonly MailManager $mail_manager = new MailManager(),
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository()
	) {}

	/**
	 * Persists the message (or returns the existing one, per its idempotency key - Section 22.5:
	 * "Prevent duplicate sends") and schedules its send. Never sends synchronously.
	 */
	public function enqueue( QueuedMessage $message ): QueuedMail {
		$existing = $this->queue->find_active_by_idempotency_key( $message->idempotency_key );

		if ( null !== $existing ) {
			return $existing;
		}

		$mail = $this->queue->enqueue( $message );
		$this->events->record( $mail->id, 'queued' );

		( new SchedulingBootstrap() )->schedule_mail_send( $mail->id );

		return $mail;
	}

	/**
	 * The actual send worker, invoked only via the scheduled action - never called directly from
	 * a web request.
	 */
	public function send_now( int $id ): void {
		$mail = $this->queue->find( $id );

		if ( null === $mail || MailState::Pending !== $mail->state ) {
			return;
		}

		if ( $mail->purpose->is_suppressible() && $this->accounts->has_marketing_consent( $mail->recipient ) === false ) {
			$this->queue->mark_suppressed( $id );
			$this->events->record( $id, 'suppressed', 'Marketing consent not granted or withdrawn.' );
			return;
		}

		$mail = $this->queue->mark_sending( $id );

		if ( null === $mail ) {
			// Already claimed (and possibly already sent) by a concurrent run - e.g. an
			// overlapping cron tick. Not this call's mail to send.
			return;
		}

		$this->events->record( $id, 'sending' );

		$provider = $this->mail_manager->active_provider();

		if ( null === $provider ) {
			$this->queue->mark_failed( $id );
			$this->events->record( $id, 'failed', 'No active mail provider is configured.' );
			return;
		}

		try {
			$result = $provider->send(
				new QueuedMessage( $mail->idempotency_key, $mail->recipient, $mail->template, $mail->purpose, $mail->subject, $mail->html_body, $mail->merge_fields )
			);
		} catch ( MailDeliveryException $exception ) {
			$this->handle_failure( $mail, $exception );
			return;
		}

		$this->queue->mark_sent( $id, $result->provider_id, $result->provider_message_id );
		$this->events->record( $id, 'sent', $result->provider_message_id );
	}

	private function handle_failure( QueuedMail $mail, MailDeliveryException $exception ): void {
		if ( ! self::should_retry( $exception->is_transient, $mail->attempt_count ) ) {
			$this->queue->mark_failed( $mail->id );
			$this->events->record( $mail->id, 'failed', $exception->getMessage() );
			return;
		}

		$next_attempt_at = ( new \DateTimeImmutable() )->modify( '+' . self::backoff_delay_minutes( $mail->attempt_count ) . ' minutes' );

		$this->queue->schedule_retry( $mail->id, $next_attempt_at );
		$this->events->record( $mail->id, 'retry_scheduled', $exception->getMessage() );
		( new SchedulingBootstrap() )->schedule_mail_send( $mail->id, $next_attempt_at );
	}

	/**
	 * Whether a failed send should be retried at all - Section 22.5: "Retry only transient
	 * failures with bounded backoff." Pure and public so it can be exercised directly by tests
	 * without a database.
	 */
	public static function should_retry( bool $is_transient, int $completed_attempt_count ): bool {
		return $is_transient && $completed_attempt_count < self::MAX_ATTEMPTS;
	}

	/**
	 * How many minutes to wait before the next attempt, given how many attempts have already
	 * been made. Bounded: once the backoff schedule is exhausted, every further retry waits the
	 * same (longest) interval rather than growing without limit.
	 */
	public static function backoff_delay_minutes( int $completed_attempt_count ): int {
		$steps = self::RETRY_BACKOFF_MINUTES;

		return $steps[ $completed_attempt_count - 1 ] ?? $steps[ count( $steps ) - 1 ];
	}

	/**
	 * IDs of pending messages whose retry backoff has elapsed - the daily maintenance sweep's
	 * safety net for anything a delayed scheduled action failed to fire (Section 15: durable
	 * execution must not rely on a single callback).
	 *
	 * @return int[]
	 */
	public function due_message_ids(): array {
		return array_map( static fn ( QueuedMail $mail ): int => $mail->id, $this->queue->find_due() );
	}
}
