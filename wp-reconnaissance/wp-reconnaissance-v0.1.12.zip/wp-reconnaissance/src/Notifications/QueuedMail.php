<?php
/**
 * A persisted row from `wpr_mail_queue`, per Section 22.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications;

use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Notifications\Enums\MailState;

final class QueuedMail {

	/**
	 * @param array<string,mixed> $merge_fields
	 */
	public function __construct(
		public readonly int $id,
		public readonly string $idempotency_key,
		public readonly string $recipient,
		public readonly string $template,
		public readonly MailPurpose $purpose,
		public readonly string $subject,
		public readonly string $html_body,
		public readonly array $merge_fields,
		public readonly MailState $state,
		public readonly ?string $provider_id,
		public readonly ?string $provider_message_id,
		public readonly int $attempt_count,
		public readonly ?\DateTimeImmutable $next_attempt_at,
		public readonly \DateTimeImmutable $created_at,
		public readonly ?\DateTimeImmutable $sent_at
	) {}

	/**
	 * @param array<string,mixed> $row
	 */
	public static function from_row( array $row ): self {
		$decoded = null !== $row['merge_fields'] ? json_decode( (string) $row['merge_fields'], true ) : array();

		return new self(
			id: (int) $row['id'],
			idempotency_key: (string) $row['idempotency_key'],
			recipient: (string) $row['recipient'],
			template: (string) $row['template'],
			purpose: MailPurpose::from( (string) $row['purpose'] ),
			subject: (string) $row['subject'],
			html_body: (string) $row['html_body'],
			merge_fields: is_array( $decoded ) ? $decoded : array(),
			state: MailState::from( (string) $row['state'] ),
			provider_id: $row['provider_id'] ?? null,
			provider_message_id: $row['provider_message_id'] ?? null,
			attempt_count: (int) $row['attempt_count'],
			next_attempt_at: ! empty( $row['next_attempt_at'] ) ? new \DateTimeImmutable( (string) $row['next_attempt_at'] ) : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			sent_at: ! empty( $row['sent_at'] ) ? new \DateTimeImmutable( (string) $row['sent_at'] ) : null
		);
	}
}
