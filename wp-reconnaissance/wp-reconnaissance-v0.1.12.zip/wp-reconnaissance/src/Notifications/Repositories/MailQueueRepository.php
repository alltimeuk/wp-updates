<?php
/**
 * Persistence for the transactional mail queue against `wpr_mail_queue`, per Section 22.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\Enums\MailState;
use Alltime\WPReconnaissance\Notifications\QueuedMail;

final class MailQueueRepository {

	public function find( int $id ): ?QueuedMail {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? QueuedMail::from_row( $row ) : null;
	}

	/**
	 * Section 22.5: "Prevent duplicate sends through idempotency keys." A message already
	 * pending, sending or sent for this key is never re-queued; only a previously Failed attempt
	 * may be retried by enqueuing again (a fresh row - failures keep their own history).
	 */
	public function find_active_by_idempotency_key( string $idempotency_key ): ?QueuedMail {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE idempotency_key = %s AND state IN ('pending','sending','sent') ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$idempotency_key
			),
			ARRAY_A
		);

		return null !== $row ? QueuedMail::from_row( $row ) : null;
	}

	/**
	 * Unlike {@see find_active_by_idempotency_key()}, matches a row in *any* state - used only to
	 * find what {@see enqueue()} collided with, since `idempotency_key` carries a plain,
	 * state-unaware UNIQUE constraint (see that method for why).
	 */
	private function find_by_idempotency_key( string $idempotency_key ): ?QueuedMail {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE idempotency_key = %s ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$idempotency_key
			),
			ARRAY_A
		);

		return null !== $row ? QueuedMail::from_row( $row ) : null;
	}

	/**
	 * `idempotency_key` carries a plain, unconditional UNIQUE constraint (not scoped to "active"
	 * states) - so a retry after a prior Failed attempt with the *same* key (the one case
	 * {@see find_active_by_idempotency_key()} deliberately allows through, per its own docblock:
	 * "failures keep their own history") would collide with that still-present failed row.
	 * Checked and resolved *before* attempting the insert, not after a failure - renaming the
	 * failed row's key out of the way first (preserving its history under a still-queryable,
	 * no-longer-colliding key) means the expected retry case never actually triggers the
	 * constraint violation at all, only a genuinely unexpected collision does.
	 *
	 * @throws MailQueueRepositoryException On a genuine, unresolvable insert failure - a real
	 *          active-message collision {@see find_active_by_idempotency_key()} should already
	 *          have caught before this ever runs, or an unrelated database failure.
	 */
	public function enqueue( QueuedMessage $message ): QueuedMail {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		$conflicting = $this->find_by_idempotency_key( $message->idempotency_key );

		if ( null !== $conflicting && MailState::Failed === $conflicting->state ) {
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$table,
				array( 'idempotency_key' => $conflicting->idempotency_key . '-superseded-' . $conflicting->id ),
				array( 'id' => $conflicting->id )
			);
		}

		$now = current_time( 'mysql', true );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'idempotency_key' => $message->idempotency_key,
				'recipient'       => $message->recipient,
				'template'        => $message->template,
				'purpose'         => $message->purpose->value,
				'subject'         => $message->subject,
				'html_body'       => $message->html_body,
				'merge_fields'    => wp_json_encode( $message->merge_fields ),
				'state'           => MailState::Pending->value,
				'created_at'      => $now,
				'updated_at'      => $now,
			)
		);

		if ( false === $inserted ) {
			throw new MailQueueRepositoryException( esc_html( "Failed to enqueue a message with idempotency key \"{$message->idempotency_key}\"." ) );
		}

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Claims a pending message for sending, or returns null if it's no longer pending - already
	 * claimed and sent (or being sent) by a concurrent run, for instance an overlapping cron tick
	 * and a manually-triggered send. Conditioned on the row's *currently persisted* state, not
	 * merely the caller's possibly-stale belief that it's still pending, via a single conditional
	 * UPDATE with a `state = 'pending'` guard rather than an unconditional write - the same
	 * discipline {@see \Alltime\WPReconnaissance\Data\Repositories\ScopeRepository::verify_and_authorise()}
	 * already uses for DNS verification. A losing concurrent caller must never also send the mail.
	 */
	public function mark_sending( int $id ): ?QueuedMail {
		global $wpdb;

		$mail = $this->find( $id );

		if ( null === $mail ) {
			return null;
		}

		$claimed = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'         => MailState::Sending->value,
				'attempt_count' => $mail->attempt_count + 1,
				'updated_at'    => current_time( 'mysql', true ),
			),
			array(
				'id'    => $id,
				'state' => MailState::Pending->value,
			)
		);

		return $claimed > 0 ? $this->find_or_fail( $id ) : null;
	}

	public function mark_sent( int $id, string $provider_id, string $provider_message_id ): QueuedMail {
		global $wpdb;

		$now = current_time( 'mysql', true );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'               => MailState::Sent->value,
				'provider_id'         => $provider_id,
				'provider_message_id' => $provider_message_id,
				'sent_at'             => $now,
				'updated_at'          => $now,
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new MailQueueRepositoryException( esc_html( "Failed to mark queued mail {$id} as sent." ) );
		}

		return $this->find_or_fail( $id );
	}

	public function mark_failed( int $id ): QueuedMail {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'           => MailState::Failed->value,
				'next_attempt_at' => null,
				'updated_at'      => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new MailQueueRepositoryException( esc_html( "Failed to mark queued mail {$id} as failed." ) );
		}

		return $this->find_or_fail( $id );
	}

	public function schedule_retry( int $id, \DateTimeImmutable $next_attempt_at ): QueuedMail {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'           => MailState::Pending->value,
				'next_attempt_at' => $next_attempt_at->format( 'Y-m-d H:i:s' ),
				'updated_at'      => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new MailQueueRepositoryException( esc_html( "Failed to schedule a retry for queued mail {$id}." ) );
		}

		return $this->find_or_fail( $id );
	}

	public function mark_suppressed( int $id ): QueuedMail {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_queue' ),
			array(
				'state'      => MailState::Suppressed->value,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new MailQueueRepositoryException( esc_html( "Failed to mark queued mail {$id} as suppressed." ) );
		}

		return $this->find_or_fail( $id );
	}

	/**
	 * Pending messages whose retry backoff has elapsed (or that have never been attempted),
	 * for the retry sweep.
	 *
	 * @return QueuedMail[]
	 */
	public function find_due( int $limit = 50 ): array {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE state = 'pending' AND (next_attempt_at IS NULL OR next_attempt_at <= %s) ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$limit
			),
			ARRAY_A
		);

		return array_map( array( QueuedMail::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Rows older than a cutoff, in a terminal state - for the retention sweep.
	 *
	 * @return int[] IDs only, to keep this cheap for a potentially large purge.
	 */
	public function find_terminal_ids_before( \DateTimeImmutable $cutoff, int $limit = 500 ): array {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM `{$table}` WHERE state IN ('sent','failed','suppressed') AND updated_at < %s LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$cutoff->format( 'Y-m-d H:i:s' ),
				$limit
			)
		);

		return array_map( 'intval', $rows );
	}

	/**
	 * Every queued message ever sent to an address - the personal-data locator/eraser's source
	 * for "mail events" (Section 26.4: "find all linked data across... mail events").
	 *
	 * @return QueuedMail[]
	 */
	public function find_by_recipient( string $email ): array {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE recipient = %s ORDER BY id DESC", $email ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array_map( array( QueuedMail::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Count of messages currently in a Failed state - the Site Health "queue operation" check's
	 * signal that something needs operator attention (Section 29).
	 */
	public function count_failed(): int {
		global $wpdb;

		$table = Schema::table( 'mail_queue' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE state = %s", MailState::Failed->value ) );
	}

	public function delete( int $id ): void {
		global $wpdb;

		$wpdb->delete( Schema::table( 'mail_queue' ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	private function find_or_fail( int $id ): QueuedMail {
		$mail = $this->find( $id );

		if ( null === $mail ) {
			throw new \RuntimeException( esc_html( "Queued mail {$id} was expected to exist but could not be loaded." ) );
		}

		return $mail;
	}
}
