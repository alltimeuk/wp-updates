<?php
/**
 * Append-only persistence for mail delivery events against `wpr_mail_events`, per Section 22.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications\Repositories;

use Alltime\WPReconnaissance\Data\Schema;

final class MailEventRepository {

	public function record( int $message_id, string $event_type, ?string $detail = null ): void {
		global $wpdb;

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'mail_events' ),
			array(
				'message_id'  => $message_id,
				'event_type'  => $event_type,
				'detail'      => $detail,
				'occurred_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function delete_for_message( int $message_id ): void {
		global $wpdb;

		$wpdb->delete( Schema::table( 'mail_events' ), array( 'message_id' => $message_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * The most recent 'failed' event's detail (the provider's own error message, recorded by
	 * {@see \Alltime\WPReconnaissance\Notifications\MailQueueService::handle_failure()}) for a
	 * given message - nothing previously read this back anywhere, so a failed send's actual cause
	 * was recorded but never surfaced.
	 */
	public function find_latest_failure_detail( int $message_id ): ?string {
		global $wpdb;

		$table = Schema::table( 'mail_events' );

		$detail = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT detail FROM `{$table}` WHERE message_id = %d AND event_type = 'failed' ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
				$message_id
			)
		);

		return null !== $detail ? (string) $detail : null;
	}
}
