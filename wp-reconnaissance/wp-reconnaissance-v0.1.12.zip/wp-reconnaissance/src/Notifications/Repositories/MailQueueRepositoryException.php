<?php
/**
 * Thrown when a repository write against the mail queue genuinely fails at the database level
 * (Section 22.5) - distinct from an ordinary claim-lost no-op (see
 * {@see MailQueueRepository::mark_sending()}), which is expected, not a failure. The message is
 * always a fixed, safe string with only the message ID interpolated - never $wpdb->last_error's
 * raw text.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications\Repositories;

final class MailQueueRepositoryException extends \RuntimeException {}
