<?php
/**
 * Queued mail delivery state, per Section 22.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Notifications\Enums;

enum MailState: string {
	case Pending    = 'pending';
	case Sending    = 'sending';
	case Sent       = 'sent';
	case Failed     = 'failed';
	case Suppressed = 'suppressed';
}
