<?php
/**
 * Thrown when domain verification is attempted before its own required schema version has
 * successfully applied (Section 7). The message is always a fixed, translated, safe string - never
 * built from $wpdb->last_error - since it can legitimately reach an admin via a redirect notice.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Verification;

final class SchemaNotReadyException extends \RuntimeException {}
