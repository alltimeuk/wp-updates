<?php
/**
 * Automatic retention and deletion sweep, per Section 26.7.
 *
 * Covers unverified registrations, raw evidence, audit records, the mail queue, and (via
 * {@see \Alltime\CustomerPlatform\RetentionSweeper}) cross-tool interaction history - the
 * categories this plugin can act on automatically today. Deliberately does NOT purge issued
 * reports: Section 26.7 says to "retain issued reports according to the organisation policy",
 * and silently deleting a customer's historical deliverables is a higher-stakes decision than
 * clearing raw collection evidence - it deserves its own careful implementation (parsing
 * `Organisation::$retention_policy`, likely anonymising rather than hard-deleting) rather than a
 * rushed addition here. Also not covered: CRM leads (no lead entity exists yet), legal hold, and
 * organisation deletion (its own deliberate, capability-controlled workflow) - see CHANGELOG.md.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Retention;

use Alltime\CustomerPlatform\RetentionSweeper as CustomerPlatformRetentionSweeper;
use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Data\EvidenceStorage;
use Alltime\WPReconnaissance\Data\Repositories\ObservationRepository;
use Alltime\WPReconnaissance\Notifications\Repositories\MailEventRepository;
use Alltime\WPReconnaissance\Notifications\Repositories\MailQueueRepository;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class RetentionService {

	private const DEFAULT_UNVERIFIED_REGISTRATION_DAYS = 7;
	private const DEFAULT_EVIDENCE_DAYS                = 365;
	private const DEFAULT_AUDIT_LOG_DAYS               = 730;
	private const DEFAULT_MAIL_QUEUE_DAYS              = 180;
	private const DEFAULT_INTERACTION_DAYS             = 730;

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly ObservationRepository $observations = new ObservationRepository(),
		private readonly EvidenceStorage $evidence_storage = new EvidenceStorage(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly MailQueueRepository $mail_queue = new MailQueueRepository(),
		private readonly MailEventRepository $mail_events = new MailEventRepository(),
		private readonly CustomerPlatformRetentionSweeper $customer_platform = new CustomerPlatformRetentionSweeper()
	) {}

	/**
	 * Runs every configured sweep and returns a summary of what was removed, for the WP-CLI
	 * command and the audit log entry it records - Section 26.7: "Record deletion outcomes
	 * without retaining the deleted content."
	 *
	 * @return array<string,int>
	 */
	public function run_sweep(): array {
		$summary = array(
			'unverified_registrations' => $this->purge_unverified_registrations(),
			'evidence_anonymised'      => $this->anonymise_stale_evidence(),
			'audit_log_purged'         => $this->purge_audit_log(),
			'mail_queue_purged'        => $this->purge_mail_queue(),
			'interactions_purged'      => $this->customer_platform->purge_old_interactions( $this->days( 'interaction', self::DEFAULT_INTERACTION_DAYS ) ),
		);

		$encoded_summary = wp_json_encode( $summary );

		$this->audit_logger->log( 'retention.swept', 'retention', null, null, summary: false !== $encoded_summary ? $encoded_summary : '' );

		// The Site Health "retention-task status" check's freshness signal (Section 29).
		update_option( 'wpr_retention_last_run_at', current_time( 'mysql', true ) );

		return $summary;
	}

	public function purge_unverified_registrations(): int {
		$user_ids = $this->accounts->find_stale_unverified_user_ids( $this->days( 'unverified_registration', self::DEFAULT_UNVERIFIED_REGISTRATION_DAYS ) );

		foreach ( $user_ids as $user_id ) {
			$this->accounts->delete( $user_id );
		}

		return count( $user_ids );
	}

	public function anonymise_stale_evidence(): int {
		$cutoff          = ( new \DateTimeImmutable() )->modify( '-' . $this->days( 'evidence', self::DEFAULT_EVIDENCE_DAYS ) . ' days' );
		$stale           = $this->observations->find_stale_with_evidence_ref( $cutoff );
		$observation_ids = array();

		foreach ( $stale as $row ) {
			$this->evidence_storage->delete( $row['raw_evidence_ref'] );
			$this->observations->clear_evidence_ref( $row['id'] );
			$observation_ids[] = $row['id'];
		}

		$this->observations->anonymise_evidence_rows( $observation_ids );

		return count( $observation_ids );
	}

	public function purge_audit_log(): int {
		$cutoff = ( new \DateTimeImmutable() )->modify( '-' . $this->days( 'audit_log', self::DEFAULT_AUDIT_LOG_DAYS ) . ' days' );

		return $this->audit_logger->purge_older_than( $cutoff );
	}

	public function purge_mail_queue(): int {
		$cutoff = ( new \DateTimeImmutable() )->modify( '-' . $this->days( 'mail_queue', self::DEFAULT_MAIL_QUEUE_DAYS ) . ' days' );
		$ids    = $this->mail_queue->find_terminal_ids_before( $cutoff );

		foreach ( $ids as $id ) {
			$this->mail_events->delete_for_message( $id );
			$this->mail_queue->delete( $id );
		}

		return count( $ids );
	}

	private function days( string $category, int $default_days ): int {
		return max( 0, (int) get_option( "wpr_retention_{$category}_days", $default_days ) );
	}
}
