<?php
/**
 * Self-hosted plugin updater.
 *
 * Polls `update.json` on the shared `alltimeuk/wp-updates` GitHub Pages site, injects version
 * info into WordPress's built-in update mechanism, and exposes a kill-switch constant for
 * staging. This deliberately mirrors `WPQ_Updater` in alltimeuk/wp-questionnaires - both
 * plugins are onboarded onto the same self-hosted update server
 * (https://alltimeuk.github.io/wp-updates/), so a WordPress install running several Alltime
 * plugins gets one consistent update experience rather than a bespoke mechanism per plugin.
 *
 * Define WPR_DISABLE_AUTO_UPDATE = true in wp-config.php to prevent automatic background
 * updates on a given environment (staging, local, etc.).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

use const Alltime\WPReconnaissance\WPR_PLUGIN_BASENAME;
use const Alltime\WPReconnaissance\WPR_VERSION;

final class Updater {

	private const UPDATE_URL  = 'https://alltimeuk.github.io/wp-updates/wp-reconnaissance/update.json';
	private const UPDATE_HOST = 'alltimeuk.github.io';
	private const UPDATE_PATH = '/wp-updates/wp-reconnaissance/';
	private const CACHE_KEY   = 'wpr_remote_update_info';
	private const CACHE_TTL   = 1800; // 30 minutes.

	public function __construct() {
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
		add_filter( 'site_transient_update_plugins', array( $this, 'suppress_stale_update_offer' ), 20 );
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 10, 3 );
		add_filter( 'upgrader_pre_download', array( $this, 'verify_package_download' ), 10, 4 );
		add_action( 'upgrader_process_complete', array( $this, 'after_update' ), 10, 2 );
		add_filter( 'auto_update_plugin', array( $this, 'auto_update_gate' ), 10, 2 );
		add_action( 'delete_site_transient_update_plugins', array( $this, 'clear_remote_cache' ) );
		add_action( 'load-update-core.php', array( $this, 'clear_remote_cache' ) );
	}

	// -----------------------------------------------------------------------------------
	// Update injection
	// -----------------------------------------------------------------------------------

	/**
	 * Injects this plugin into the update_plugins transient when a newer version is available
	 * on the self-hosted update endpoint.
	 */
	public function inject_update( mixed $transient ): mixed {
		if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
			return $transient;
		}

		$this->clear_update_entries( $transient );

		$remote = $this->get_remote_info();

		if ( null === $remote ) {
			return $transient;
		}

		$update               = new \stdClass();
		$update->id           = 'alltimeuk/wp-reconnaissance';
		$update->slug         = 'wp-reconnaissance';
		$update->plugin       = WPR_PLUGIN_BASENAME;
		$update->new_version  = $remote->version;
		$update->url          = $remote->homepage ?? '';
		$update->package      = $remote->download_url ?? '';
		$update->icons        = array();
		$update->banners      = array();
		$update->tested       = $remote->tested ?? '';
		$update->requires_php = $remote->requires_php ?? '';

		if ( version_compare( WPR_VERSION, $remote->version, '<' ) ) {
			$transient->response[ WPR_PLUGIN_BASENAME ] = $update;
		} else {
			$update->package                             = '';
			$transient->no_update[ WPR_PLUGIN_BASENAME ] = $update;
		}

		return $transient;
	}

	/**
	 * Removes cached update offers that are not newer than the loaded plugin. WordPress can
	 * keep a stale `update_plugins` response around after a successful manual update; scrub it
	 * on read as well as write so the Plugins screen cannot advertise an update to the same
	 * version.
	 */
	public function suppress_stale_update_offer( mixed $transient ): mixed {
		if ( ! is_object( $transient ) || empty( $transient->response ) || ! is_array( $transient->response ) ) {
			return $transient;
		}

		$offer = $transient->response[ WPR_PLUGIN_BASENAME ] ?? null;

		if ( ! is_object( $offer ) ) {
			return $transient;
		}

		$offered_version = (string) ( $offer->new_version ?? '' );

		if ( '' === $offered_version || version_compare( WPR_VERSION, $offered_version, '<' ) ) {
			return $transient;
		}

		unset( $transient->response[ WPR_PLUGIN_BASENAME ] );

		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}

		$offer->new_version = WPR_VERSION;
		$offer->package     = '';

		$transient->no_update[ WPR_PLUGIN_BASENAME ] = $offer;

		return $transient;
	}

	private function clear_update_entries( object $transient ): void {
		foreach ( array( 'response', 'no_update' ) as $property ) {
			if ( ! isset( $transient->{$property} ) ) {
				$transient->{$property} = array();
			}

			if ( is_array( $transient->{$property} ) ) {
				unset( $transient->{$property}[ WPR_PLUGIN_BASENAME ] );
			}
		}
	}

	// -----------------------------------------------------------------------------------
	// Plugin info popup
	// -----------------------------------------------------------------------------------

	/**
	 * Supplies plugin details for the "View version x.x.x details" popup.
	 */
	public function plugin_info( mixed $result, string $action, object $args ): mixed {
		if ( 'plugin_information' !== $action || 'wp-reconnaissance' !== ( $args->slug ?? '' ) ) {
			return $result;
		}

		$remote = $this->get_remote_info();

		if ( null === $remote ) {
			return $result;
		}

		$info                = new \stdClass();
		$info->name          = $remote->name ?? 'WP Reconnaissance';
		$info->slug          = 'wp-reconnaissance';
		$info->version       = $remote->version;
		$info->author        = '<a href="' . esc_url( $remote->author_homepage ?? '' ) . '">'
			. esc_html( $remote->author ?? 'Alltime Technologies Ltd' ) . '</a>';
		$info->requires      = $remote->requires ?? '6.6';
		$info->tested        = $remote->tested ?? '';
		$info->requires_php  = $remote->requires_php ?? '8.2';
		$info->last_updated  = $remote->last_updated ?? '';
		$info->download_link = $remote->download_url ?? '';
		$info->sections      = (array) ( $remote->sections ?? new \stdClass() );
		$info->icons         = array();
		$info->banners       = array();

		return $info;
	}

	// -----------------------------------------------------------------------------------
	// Post-update cache bust
	// -----------------------------------------------------------------------------------

	/**
	 * Clears the cached update info after any plugin update completes, so the next admin page
	 * load fetches fresh data.
	 *
	 * @param array<string,mixed> $hook_extra Array describing what was upgraded.
	 */
	public function after_update( object $upgrader, array $hook_extra ): void {
		unset( $upgrader );

		if (
			isset( $hook_extra['type'], $hook_extra['action'] )
			&& 'plugin' === $hook_extra['type']
			&& 'update' === $hook_extra['action']
		) {
			$this->clear_remote_cache();
			delete_site_transient( 'update_plugins' );
		}
	}

	public function clear_remote_cache(): void {
		delete_transient( self::CACHE_KEY );
	}

	// -----------------------------------------------------------------------------------
	// Auto-update gate
	// -----------------------------------------------------------------------------------

	/**
	 * Prevents automatic background updates when WPR_DISABLE_AUTO_UPDATE is true (set this in
	 * wp-config.php on staging/local environments). Otherwise defers to WordPress's own
	 * per-plugin auto-update toggle in the plugin list.
	 */
	public function auto_update_gate( ?bool $update, object $item ): ?bool {
		if ( ! isset( $item->plugin ) || WPR_PLUGIN_BASENAME !== $item->plugin ) {
			return $update;
		}

		// A plain, unqualified global constant so it can be set from wp-config.php with a
		// simple define( 'WPR_DISABLE_AUTO_UPDATE', true ) - defined()/constant() resolve by
		// the literal name given, independent of this class's own namespace.
		if ( defined( 'WPR_DISABLE_AUTO_UPDATE' ) && constant( 'WPR_DISABLE_AUTO_UPDATE' ) ) {
			return false;
		}

		return $update; // WordPress's built-in per-plugin toggle takes effect.
	}

	// -----------------------------------------------------------------------------------
	// Package verification
	// -----------------------------------------------------------------------------------

	/**
	 * Downloads update packages through WordPress, verifies the advertised SHA-256 checksum,
	 * and returns the verified local ZIP to the upgrader. Section 27's "verify package
	 * integrity in release workflows" requirement extends to the install path, not only the
	 * build path - an update is never installed without a matching checksum.
	 *
	 * @param array<string,mixed> $hook_extra Details describing the upgrade.
	 */
	public function verify_package_download( mixed $reply, string $package, object $upgrader, array $hook_extra ): mixed {
		unset( $upgrader );

		if ( false !== $reply || ! $this->is_own_plugin_update( $hook_extra ) ) {
			return $reply;
		}

		$remote = $this->get_remote_info();

		if ( null === $remote || empty( $remote->download_url ) || $package !== $remote->download_url ) {
			return new \WP_Error( 'wpr_update_metadata_unavailable', 'WP Reconnaissance update metadata could not be verified.' );
		}

		if ( empty( $remote->sha256 ) || ! $this->is_valid_sha256( (string) $remote->sha256 ) ) {
			return new \WP_Error( 'wpr_update_checksum_missing', 'WP Reconnaissance update package checksum is missing or invalid.' );
		}

		if ( ! function_exists( 'download_url' ) ) {
			return new \WP_Error( 'wpr_update_download_unavailable', 'WordPress package download support is unavailable.' );
		}

		$file = download_url( $package, 300 );

		if ( is_wp_error( $file ) ) {
			return $file;
		}

		$actual = is_string( $file ) && is_readable( $file ) ? hash_file( 'sha256', $file ) : false;

		if ( ! is_string( $actual ) || ! hash_equals( strtolower( (string) $remote->sha256 ), strtolower( $actual ) ) ) {
			if ( is_string( $file ) && is_file( $file ) ) {
				wp_delete_file( $file );
			}

			return new \WP_Error( 'wpr_update_checksum_mismatch', 'WP Reconnaissance update package checksum verification failed.' );
		}

		return $file;
	}

	// -----------------------------------------------------------------------------------
	// Remote fetch with caching
	// -----------------------------------------------------------------------------------

	/**
	 * Fetches update.json from the update endpoint, caching the result (30 minutes on success,
	 * 1 hour on failure) to avoid hammering the remote.
	 */
	private function get_remote_info(): ?object {
		$cached = get_transient( self::CACHE_KEY );

		if ( is_array( $cached ) ) {
			return $cached['data'] instanceof \stdClass ? $cached['data'] : null;
		}

		$response = wp_remote_get(
			self::UPDATE_URL,
			array(
				'timeout'    => 10,
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; WPR/' . WPR_VERSION . '; ' . get_bloginfo( 'url' ),
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			set_transient( self::CACHE_KEY, array( 'data' => null ), HOUR_IN_SECONDS );
			return null;
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ) );

		if ( ! is_object( $data ) || ! $this->validate_remote_info( $data ) ) {
			set_transient( self::CACHE_KEY, array( 'data' => null ), HOUR_IN_SECONDS );
			return null;
		}

		set_transient( self::CACHE_KEY, array( 'data' => $data ), self::CACHE_TTL );

		return $data;
	}

	private function validate_remote_info( object $data ): bool {
		if ( empty( $data->version ) || ! $this->is_valid_version( (string) $data->version ) ) {
			return false;
		}

		if ( empty( $data->download_url ) || ! $this->is_allowed_package_url( (string) $data->download_url ) ) {
			return false;
		}

		return ! empty( $data->sha256 ) && $this->is_valid_sha256( (string) $data->sha256 );
	}

	public function is_valid_version( string $version ): bool {
		return 1 === preg_match( '/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9_.-]+)?$/', $version );
	}

	public function is_allowed_package_url( string $url ): bool {
		$parts = wp_parse_url( $url );

		if ( ! is_array( $parts ) ) {
			return false;
		}

		$scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
		$host   = strtolower( (string) ( $parts['host'] ?? '' ) );
		$path   = (string) ( $parts['path'] ?? '' );

		// str_starts_with()/str_ends_with() below are plain string prefix/suffix checks, not
		// path normalisation - a path containing "../" segments could still textually satisfy
		// both while resolving (once actually fetched) to a different location on the same
		// trusted host, e.g. escaping into another product's /wp-updates/<slug>/ folder.
		// Explicitly reject any ".." segment rather than relying on prefix/suffix matching alone.
		if ( false !== strpos( $path, '..' ) ) {
			return false;
		}

		return 'https' === $scheme
			&& self::UPDATE_HOST === $host
			&& str_starts_with( $path, self::UPDATE_PATH )
			&& str_ends_with( $path, '.zip' );
	}

	public function is_valid_sha256( string $hash ): bool {
		return 1 === preg_match( '/^[a-f0-9]{64}$/i', $hash );
	}

	/**
	 * @param array<string,mixed> $hook_extra
	 */
	private function is_own_plugin_update( array $hook_extra ): bool {
		if ( isset( $hook_extra['plugin'] ) && WPR_PLUGIN_BASENAME === $hook_extra['plugin'] ) {
			return true;
		}

		if ( isset( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ) {
			return in_array( WPR_PLUGIN_BASENAME, $hook_extra['plugins'], true );
		}

		return false;
	}
}
