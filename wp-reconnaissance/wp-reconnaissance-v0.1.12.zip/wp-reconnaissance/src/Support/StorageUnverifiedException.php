<?php
/**
 * Thrown by {@see StorageExposureGuard::assert_not_exposed()} when a write to the uploads
 * fallback location is refused because its exposure has never been positively confirmed safe -
 * missing, expired, or otherwise unverified, as distinct from {@see StorageExposedException}'s
 * positively-confirmed-exposed case. Both extend `\RuntimeException` so a caller that only cares
 * "did the storage write fail" can still catch either without knowing about the distinction.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

final class StorageUnverifiedException extends \RuntimeException {}
