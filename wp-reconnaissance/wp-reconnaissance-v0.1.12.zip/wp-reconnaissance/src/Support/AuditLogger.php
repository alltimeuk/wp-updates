<?php
/**
 * Append-only audit logging against `wpr_audit_log`, per Section 25.
 *
 * Never pass passwords, tokens, complete manifests containing secrets, or raw evidence into
 * `$summary` - the audit log records that an action happened, not the sensitive payload it
 * happened to.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

use Alltime\WPReconnaissance\Data\Schema;

class AuditLogger {

	/**
	 * Deliberately never throws: the action `log()` is called alongside has, in every existing
	 * caller, already happened (or is about to, unconditionally) by the time this runs - a lost
	 * audit entry must never also silently undo or abort an otherwise-successful operation, which
	 * is what letting this method throw into dozens of call sites across the codebase (several
	 * now inside their own transactions, see PRs M/N this session) would risk. A failed write is
	 * still never silently swallowed: it's written to PHP's own error log (the same visibility
	 * mechanism WordPress core itself uses for unexpected internal failures) and fired as a
	 * WordPress action other code can listen to (e.g. a future Site Health check, matching the
	 * pattern {@see \Alltime\WPReconnaissance\Data\Migrator} already established for migration
	 * failures) - just not treated as fatal to the caller.
	 */
	public function log(
		string $action,
		string $object_type,
		?int $object_id = null,
		?int $actor_id = null,
		string $outcome = 'success',
		?string $summary = null,
		string $source = 'admin'
	): void {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'actor_id'    => $actor_id,
				'action'      => $action,
				'object_type' => $object_type,
				'object_id'   => $object_id,
				'source'      => $source,
				'outcome'     => $outcome,
				'summary'     => $summary,
				'occurred_at' => current_time( 'mysql', true ),
			)
		);

		if ( false === $inserted ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate, the one place this codebase intentionally surfaces a failure this way; see the docblock above for why this can't throw instead.
			error_log( "WP Reconnaissance: failed to write an audit log entry for action \"{$action}\" (object_type={$object_type}, object_id=" . ( $object_id ?? 'null' ) . ').' );
			do_action( 'wpr_audit_log_write_failed', $action, $object_type, $object_id );
		}
	}

	/**
	 * Every entry recorded against a given actor - the personal-data locator's source for audit
	 * trail data (Section 26.4: "find all linked data across... custom tables"). Returned as raw
	 * rows rather than a domain object: nothing outside this read consumes the audit log as
	 * anything other than a display list.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function find_by_actor( int $actor_id ): array {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE actor_id = %d ORDER BY id DESC", $actor_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return null !== $rows ? $rows : array();
	}

	/**
	 * Deletes audit log entries older than the cutoff - Section 26.7's "operational logs" and
	 * "audit records" retention category.
	 */
	public function purge_older_than( \DateTimeImmutable $cutoff ): int {
		global $wpdb;

		$table = Schema::table( 'audit_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM `{$table}` WHERE occurred_at < %s", $cutoff->format( 'Y-m-d H:i:s' ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}
