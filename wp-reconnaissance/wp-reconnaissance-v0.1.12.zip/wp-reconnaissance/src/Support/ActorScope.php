<?php
/**
 * Resolves which organisation(s) the current request's authenticated user may access, per
 * Section 18.4's capability model: an operator (VIEW_ALL_RESULTS) sees every organisation; a
 * customer (VIEW_ASSIGNED_ORG) is confined to the single organisation their account is linked
 * to, resolved via {@see CustomerAccountRepository} rather than trusted from request input.
 *
 * Used by the REST API resource controllers, which are the one surface both roles can reach -
 * the admin UI is operator-only ({@see \Alltime\WPReconnaissance\Support\Roles} blocks customer
 * accounts from /wp-admin/ entirely, so it never needs this distinction.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;

final class ActorScope {

	public function __construct(
		private readonly CustomerAccountRepository $customer_accounts = new CustomerAccountRepository()
	) {}

	public function is_operator(): bool {
		return current_user_can( Capabilities::VIEW_ALL_RESULTS );
	}

	/**
	 * The organisation ID a customer is confined to, or null for an operator (no restriction) or
	 * a user with neither capability (no access at all - callers must check {@see can_access()}
	 * or {@see is_operator()} before treating a null return as "unrestricted").
	 */
	public function customer_organisation_id(): ?int {
		if ( ! is_user_logged_in() || ! current_user_can( Capabilities::VIEW_ASSIGNED_ORG ) ) {
			return null;
		}

		$account = $this->customer_accounts->find( get_current_user_id() );

		return $account?->organisation_id;
	}

	/**
	 * Whether the current user may access data belonging to the given organisation: true for
	 * any operator, or for a customer whose linked organisation matches.
	 */
	public function can_access_organisation( int $organisation_id ): bool {
		if ( $this->is_operator() ) {
			return true;
		}

		return $this->customer_organisation_id() === $organisation_id;
	}
}
