<?php
/**
 * Thrown by {@see StorageExposureGuard::assert_not_exposed()} when a write to a confirmed-exposed
 * fallback storage location is refused.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

final class StorageExposedException extends \RuntimeException {}
