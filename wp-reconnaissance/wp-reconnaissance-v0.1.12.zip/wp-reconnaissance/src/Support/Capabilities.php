<?php
/**
 * Custom capability identifiers, per Section 18.4 of the design specification.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

/**
 * Central registry of the plugin's custom WordPress capabilities.
 *
 * These are checked explicitly on every admin action and REST endpoint; nonces authenticate
 * the request origin but are never treated as authorisation on their own.
 */
final class Capabilities {

	public const MANAGE_SETTINGS         = 'wpr_manage_settings';
	public const MANAGE_ORGANISATIONS    = 'wpr_manage_organisations';
	public const MANAGE_SCOPES           = 'wpr_manage_scopes';
	public const RUN_ASSESSMENTS         = 'wpr_run_assessments';
	public const VIEW_ALL_RESULTS        = 'wpr_view_all_results';
	public const REVIEW_FINDINGS         = 'wpr_review_findings';
	public const MANAGE_FINDINGS         = 'wpr_manage_findings';
	public const ISSUE_REPORTS           = 'wpr_issue_reports';
	public const VIEW_ASSIGNED_ORG       = 'wpr_view_assigned_organisation';
	public const MANAGE_INTEGRATIONS     = 'wpr_manage_integrations';
	public const VIEW_AUDIT_LOG          = 'wpr_view_audit_log';
	public const MANAGE_CUSTOMERS        = 'wpr_manage_customers';
	public const MANAGE_LEADS            = 'wpr_manage_leads';
	public const MANAGE_CONSENTS         = 'wpr_manage_consents';
	public const MANAGE_PRIVACY_REQUESTS = 'wpr_manage_privacy_requests';
	public const MANAGE_ENTITLEMENTS     = 'wpr_manage_entitlements';
	public const MANAGE_ABUSE_REVIEW     = 'wpr_manage_abuse_review';
	public const MANAGE_CONTACT_MERGE    = 'wpr_manage_contact_merge';

	/**
	 * All capabilities granted to the administrator/operator role.
	 *
	 * @return string[]
	 */
	public static function operator_capabilities(): array {
		return array(
			self::MANAGE_SETTINGS,
			self::MANAGE_ORGANISATIONS,
			self::MANAGE_SCOPES,
			self::RUN_ASSESSMENTS,
			self::VIEW_ALL_RESULTS,
			self::REVIEW_FINDINGS,
			self::MANAGE_FINDINGS,
			self::ISSUE_REPORTS,
			self::MANAGE_INTEGRATIONS,
			self::VIEW_AUDIT_LOG,
			self::MANAGE_CUSTOMERS,
			self::MANAGE_LEADS,
			self::MANAGE_CONSENTS,
			self::MANAGE_PRIVACY_REQUESTS,
			self::MANAGE_ENTITLEMENTS,
			self::MANAGE_ABUSE_REVIEW,
			self::MANAGE_CONTACT_MERGE,
		);
	}

	/**
	 * Capabilities granted to the dedicated customer role. Deliberately minimal: a customer
	 * only ever sees their own assigned organisation, enforced at the query layer rather than
	 * through capability checks alone.
	 *
	 * @return string[]
	 */
	public static function customer_capabilities(): array {
		return array(
			self::VIEW_ASSIGNED_ORG,
		);
	}
}
