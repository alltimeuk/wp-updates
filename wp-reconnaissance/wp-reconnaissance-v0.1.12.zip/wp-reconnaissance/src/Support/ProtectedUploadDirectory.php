<?php
/**
 * Resolves where a wp-content/uploads-adjacent subdirectory that must never be servable directly
 * actually lives, and applies "deny direct web access" hardening to it - used by both raw
 * evidence storage (Section 9) and issued report storage (Section 21.2), which need identical
 * treatment.
 *
 * Two layers, in order of preference:
 *
 * 1. **Outside the document root** ({@see resolve_directory()}'s `'escaped'` mode) - a sibling
 *    directory of the WordPress installation itself, `dirname( ABSPATH ) . '/wpr-protected-storage'`.
 *    Nothing maps a URL to this location on any web server, Apache or nginx alike, so there is
 *    nothing to protect *from* in the first place. Only ever claimed when it can be positively
 *    verified: `$_SERVER['DOCUMENT_ROOT']` must be available (an HTTP request - never CLI/WP-Cron
 *    invoked via a real system cron, where this superglobal doesn't exist) and, once both paths
 *    are resolved to their real, normalised form, the candidate must genuinely fall outside the
 *    document root - not equal to it, not a subdirectory of it. This is deliberately conservative:
 *    `dirname( ABSPATH )` is *not* reliably outside the docroot in general - it is identical to it
 *    in the well-documented "give WordPress its own directory" layout and in Bedrock-style stacks,
 *    both common enough to matter - so the gate defaults to refusing escape whenever it can't be
 *    positively proven safe, never the other way around. A write/read/delete probe on the
 *    candidate then confirms it's actually usable (catches `open_basedir` and similar
 *    restrictions the gate alone can't).
 * 2. **Inside `wp-content/uploads`** (`'uploads'` mode, today's only behaviour) - `.htaccess`
 *    (Apache-only) plus a live-probed canary file ({@see \Alltime\WPReconnaissance\Diagnostics\SiteHealthChecks})
 *    are the only protection; nginx needs a manually-added server-block deny rule this plugin
 *    cannot add on its own.
 *
 * The chosen mode is cached (an option plus a short-TTL transient gating re-validation) rather
 * than recomputed on every call, and deliberately re-validated in *both* directions on expiry -
 * a resolved permission issue or host migration should be picked up automatically, not just a
 * newly-broken escape. A CLI/WP-Cron-via-cron invocation, which never has `DOCUMENT_ROOT`
 * available to re-verify anything, always defers to whatever the most recent HTTP request already
 * established rather than wrongly flipping the decision.
 *
 * Callers must not assume a file written under one mode stays reachable if the mode later flips -
 * {@see EvidenceStorage::retrieve()}/{@see ReportFileStorage::retrieve()} check both possible
 * locations rather than trusting the currently-resolved one alone.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

final class ProtectedUploadDirectory {

	public const MODE_ESCAPED = 'escaped';

	public const MODE_UPLOADS = 'uploads';

	private const CANARY_TOKEN_OPTION = 'wpr_canary_token';

	private const MODE_OPTION = 'wpr_storage_location_mode';

	private const REVALIDATE_TRANSIENT = 'wpr_storage_location_revalidate';

	private const REVALIDATE_INTERVAL = 15 * MINUTE_IN_SECONDS;

	/**
	 * Resolves the directory $subdirectory should be written to *right now*, and ensures it's
	 * protected. Callers writing a new file use this; callers reading/deleting an existing one
	 * must not assume the mode is unchanged since it was written - see {@see directory_for_mode()}.
	 *
	 * @return array{path: string, mode: 'escaped'|'uploads'}
	 */
	public static function resolve_directory( string $subdirectory ): array {
		$mode = self::current_mode();
		$path = self::directory_for_mode( $subdirectory, $mode );

		self::ensure_protected( $path );

		return array(
			'path' => $path,
			'mode' => $mode,
		);
	}

	/**
	 * The directory $subdirectory would live in under a specific mode, regardless of which mode
	 * is currently active - used by retrieve()/delete() to check both possible locations for a
	 * file that may have been written before the cached mode last changed.
	 */
	public static function directory_for_mode( string $subdirectory, string $mode ): string {
		return self::MODE_ESCAPED === $mode
			? self::escaped_base_directory() . '/' . $subdirectory
			: trailingslashit( wp_upload_dir()['basedir'] ) . $subdirectory;
	}

	/**
	 * Ensures $dir exists, is Apache-denied, and carries a live-probe canary file.
	 */
	private static function ensure_protected( string $dir ): void {
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		$htaccess = $dir . DIRECTORY_SEPARATOR . '.htaccess';
		if ( ! is_file( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$index = $dir . DIRECTORY_SEPARATOR . 'index.php';
		if ( ! is_file( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$canary_path = $dir . DIRECTORY_SEPARATOR . self::canary_filename();
		if ( ! is_file( $canary_path ) ) {
			file_put_contents( $canary_path, self::canary_content() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}

	/**
	 * The canary's bare filename - stable across calls and across directories once the per-site
	 * token exists, so a live probe can compute it without needing to read the filesystem first.
	 */
	public static function canary_filename(): string {
		return '.wpr-canary-' . self::token();
	}

	/** The exact content a successfully-fetched canary file must contain to count as "exposed". */
	public static function canary_content(): string {
		return 'wpr-canary-' . self::token();
	}

	private static function current_mode(): string {
		$cached = get_option( self::MODE_OPTION );

		if ( ! isset( $_SERVER['DOCUMENT_ROOT'] ) || '' === $_SERVER['DOCUMENT_ROOT'] ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only presence/equality check against a filesystem path, never output or used in a query.
			// CLI/WP-Cron-via-cron never has DOCUMENT_ROOT - only an HTTP request can establish or
			// re-verify escape safety, so this context always defers to what one already decided,
			// rather than wrongly falling back to 'uploads' just because *this* invocation can't
			// verify anything either way.
			return is_string( $cached ) && '' !== $cached ? $cached : self::MODE_UPLOADS;
		}

		if ( false !== get_transient( self::REVALIDATE_TRANSIENT ) && is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$mode = self::determine_mode();

		update_option( self::MODE_OPTION, $mode, false );
		set_transient( self::REVALIDATE_TRANSIENT, '1', self::REVALIDATE_INTERVAL );

		return $mode;
	}

	private static function determine_mode(): string {
		if ( ! self::escape_gate_passes() ) {
			return self::MODE_UPLOADS;
		}

		$candidate = self::escaped_base_directory();

		if ( ! wp_mkdir_p( $candidate ) ) {
			return self::MODE_UPLOADS;
		}

		$probe_path = $candidate . '/.wpr-write-test';
		$written    = file_put_contents( $probe_path, 'ok' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		if ( false === $written ) {
			return self::MODE_UPLOADS;
		}

		$read_back = file_get_contents( $probe_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		wp_delete_file( $probe_path );

		return 'ok' === $read_back ? self::MODE_ESCAPED : self::MODE_UPLOADS;
	}

	/**
	 * Positively verifies the escape candidate is genuinely outside the document root - default
	 * is always "no", never "yes", when this can't be established either way. See the class
	 * docblock for why `dirname( ABSPATH )` alone is not a reliable signal.
	 */
	private static function escape_gate_passes(): bool {
		if ( ! isset( $_SERVER['DOCUMENT_ROOT'] ) || '' === $_SERVER['DOCUMENT_ROOT'] ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only presence/equality check against a filesystem path, never output or used in a query.
			return false;
		}

		$document_root = realpath( (string) $_SERVER['DOCUMENT_ROOT'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only presence/equality check against a filesystem path, never output or used in a query.
		$parent        = realpath( dirname( ABSPATH ) );

		if ( false === $document_root || false === $parent ) {
			return false;
		}

		$document_root = self::normalize_for_comparison( $document_root );
		$candidate     = self::normalize_for_comparison( $parent . '/wpr-protected-storage' );

		// Safe only if the candidate is genuinely outside (not equal to, not a subdirectory of)
		// the document root - being a sibling of it, or anywhere else outside it, is fine. The
		// trailing slash on both sides before the prefix check avoids a sibling directory whose
		// name happens to start with the same characters (e.g. "/var/www/htmlfoo" is not inside
		// "/var/www/html") from matching as a false positive.
		return $candidate !== $document_root && ! str_starts_with( $candidate . '/', $document_root . '/' );
	}

	private static function normalize_for_comparison( string $path ): string {
		$path = untrailingslashit( wp_normalize_path( $path ) );

		return '\\' === DIRECTORY_SEPARATOR ? strtolower( $path ) : $path;
	}

	private static function escaped_base_directory(): string {
		return wp_normalize_path( dirname( ABSPATH ) ) . '/wpr-protected-storage';
	}

	/**
	 * A random, per-site component generated once and reused - never a fixed literal shipped in
	 * this plugin's own source, which would make the canary filename mass-scannable across every
	 * site running this plugin rather than something only a site already probing this exact
	 * install could find.
	 */
	private static function token(): string {
		$token = get_option( self::CANARY_TOKEN_OPTION );

		if ( is_string( $token ) && '' !== $token ) {
			return $token;
		}

		$generated = wp_generate_password( 32, false, false );

		if ( add_option( self::CANARY_TOKEN_OPTION, $generated, '', false ) ) {
			return $generated;
		}

		// Lost the race to a concurrent request that added the option first - use its value, not
		// the one generated here, so every directory's canary ends up under the same token.
		$token = get_option( self::CANARY_TOKEN_OPTION );

		return is_string( $token ) && '' !== $token ? $token : $generated;
	}
}
