<?php
/**
 * Stores the full raw evidence document in a protected uploads-adjacent subdirectory, per
 * Section 9: "Raw evidence may be stored in a protected uploads subdirectory... Direct web
 * access must be denied. Downloads must pass WordPress authentication and authorisation."
 *
 * Only the reference returned by {@see store()} is persisted in `wpr_observations`; access to
 * the file itself must always go through an authenticated, capability-checked download handler
 * - nothing in this class is a public URL. Where the file actually lives on disk is decided by
 * {@see ProtectedUploadDirectory} - see its own docblock for the outside-the-document-root
 * strategy and its conservative safety gate.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data;

use Alltime\WPReconnaissance\Support\ProtectedUploadDirectory;
use Alltime\WPReconnaissance\Support\StorageExposureGuard;

final class EvidenceStorage {

	private const SUBDIRECTORY = 'wpr-evidence';

	/**
	 * Writes the evidence document and returns a reference to store in `raw_evidence_ref`.
	 *
	 * @throws \Alltime\WPReconnaissance\Support\StorageExposedException When storage has fallen
	 *          back to the `wp-content/uploads` location and Site Health's last check confirmed
	 *          it's directly reachable over the web - see {@see StorageExposureGuard}.
	 */
	public function store( string $job_uuid, string $evidence_json ): string {
		$resolved = ProtectedUploadDirectory::resolve_directory( self::SUBDIRECTORY );

		if ( ProtectedUploadDirectory::MODE_UPLOADS === $resolved['mode'] ) {
			StorageExposureGuard::assert_not_exposed( self::SUBDIRECTORY );
		}

		$safe_name = preg_replace( '/[^A-Za-z0-9._-]/', '', $job_uuid );
		$path      = $resolved['path'] . DIRECTORY_SEPARATOR . "{$safe_name}.json";

		if ( false === file_put_contents( $path, $evidence_json, LOCK_EX ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			throw new \RuntimeException( esc_html( 'Unable to write evidence document to protected storage.' ) );
		}

		chmod( $path, 0600 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod

		return self::SUBDIRECTORY . "/{$safe_name}.json";
	}

	/**
	 * Removes the stored evidence file for a reference, if it still exists - the retention
	 * sweep's counterpart to {@see store()} (Section 26.7).
	 */
	public function delete( string $reference ): void {
		$path = $this->existing_path_for( $reference );

		if ( null !== $path ) {
			wp_delete_file( $path );
		}
	}

	public function retrieve( string $reference ): ?string {
		$path = $this->existing_path_for( $reference );

		if ( null === $path ) {
			return null;
		}

		$contents = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		return false !== $contents ? $contents : null;
	}

	/**
	 * A reference is never tagged with the mode it was written under - the storage location
	 * decision can change between when a file was written and when it's later read (a host
	 * migration, a resolved permission issue) - so both possible locations are checked rather
	 * than trusting whichever one currently resolves.
	 */
	private function existing_path_for( string $reference ): ?string {
		$basename = basename( $reference );

		foreach ( array( ProtectedUploadDirectory::MODE_ESCAPED, ProtectedUploadDirectory::MODE_UPLOADS ) as $mode ) {
			$path = ProtectedUploadDirectory::directory_for_mode( self::SUBDIRECTORY, $mode ) . DIRECTORY_SEPARATOR . $basename;

			if ( is_file( $path ) ) {
				return $path;
			}
		}

		return null;
	}
}
