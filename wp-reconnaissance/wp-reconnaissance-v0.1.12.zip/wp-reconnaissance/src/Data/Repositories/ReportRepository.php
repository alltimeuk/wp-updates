<?php
/**
 * Persistence for issued reports against `wpr_reports`, per Section 21.
 *
 * Insert-only: issued reports are immutable, so there is deliberately no update method here - a
 * correction calls {@see save()} again with the next version number, never mutates a row.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Report;

class ReportRepository {

	public function find( int $id ): ?Report {
		global $wpdb;

		$table = Schema::table( 'reports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Report::from_row( $row ) : null;
	}

	public function find_latest_by_scope( int $scope_id ): ?Report {
		global $wpdb;

		$table = Schema::table( 'reports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE scope_id = %d ORDER BY version DESC LIMIT 1", $scope_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return null !== $row ? Report::from_row( $row ) : null;
	}

	/**
	 * @return Report[] Every issued version for a scope, most recent first.
	 */
	public function find_by_scope( int $scope_id ): array {
		global $wpdb;

		$table = Schema::table( 'reports' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE scope_id = %d ORDER BY version DESC", $scope_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return array_map( array( Report::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return Report[] Latest issued report per scope, for an organisation-wide listing.
	 */
	public function find_latest_by_organisation( int $organisation_id ): array {
		global $wpdb;

		$table = Schema::table( 'reports' );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table (used twice below) is a fixed, internally derived identifier, not user input; the only user-supplied value is bound via $wpdb->prepare().
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT r.* FROM `{$table}` r
				INNER JOIN (
					SELECT scope_id, MAX(version) AS max_version FROM `{$table}` WHERE organisation_id = %d GROUP BY scope_id
				) latest ON latest.scope_id = r.scope_id AND latest.max_version = r.version
				ORDER BY r.generated_at DESC",
				$organisation_id
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array_map( array( Report::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function next_version( int $scope_id ): int {
		$latest = $this->find_latest_by_scope( $scope_id );

		return null !== $latest ? $latest->version + 1 : 1;
	}

	/**
	 * @param array<string,mixed> $document A schemas/report.schema.json-conformant document.
	 */
	public function save( int $organisation_id, int $scope_id, int $observation_id, int $version, array $document, ?int $generated_by ): Report {
		global $wpdb;

		$table = Schema::table( 'reports' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'report_uuid'     => (string) ( $document['report_id'] ?? wp_generate_uuid4() ),
			'organisation_id' => $organisation_id,
			'scope_id'        => $scope_id,
			'observation_id'  => $observation_id,
			'version'         => $version,
			'document'        => wp_json_encode( $document ),
			'generated_at'    => $now,
			'generated_by'    => $generated_by,
			'created_at'      => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$report = $this->find( (int) $wpdb->insert_id );

		if ( null === $report ) {
			throw new \RuntimeException( esc_html( 'Report was expected to exist immediately after being saved but could not be loaded.' ) );
		}

		do_action( 'wpr_report_issued', $report->id );

		return $report;
	}
}
