<?php
/**
 * Thrown when a repository write against the scopes table genuinely fails at the database level
 * (Section 8) - distinct from a conditional write matching zero rows, which is an expected no-op,
 * not a failure. The message is always a fixed, safe string with only the scope ID interpolated -
 * never $wpdb->last_error's raw text - since it can legitimately reach an admin via a redirect
 * notice or an audit-log summary.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

final class ScopeRepositoryException extends \RuntimeException {}
