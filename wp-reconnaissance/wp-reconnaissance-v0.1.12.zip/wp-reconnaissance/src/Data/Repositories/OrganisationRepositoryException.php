<?php
/**
 * Thrown when a repository write against `wpr_organisations` genuinely fails at the database
 * level.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

final class OrganisationRepositoryException extends \RuntimeException {}
