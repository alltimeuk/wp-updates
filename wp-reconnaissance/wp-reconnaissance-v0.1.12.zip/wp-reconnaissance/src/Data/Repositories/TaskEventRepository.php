<?php
/**
 * Persistence for remediation task event history against `wpr_task_events`, per Section 21.3:
 * "Tasks shall remain linked to the evidence and rule version from which they were generated...
 * it must not silently destroy the task history."
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;

final class TaskEventRepository {

	public function record( int $task_id, string $event_type, ?int $actor_id = null, ?string $summary = null ): void {
		global $wpdb;

		$table = Schema::table( 'task_events' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'task_id'     => $task_id,
				'event_type'  => $event_type,
				'actor_id'    => $actor_id,
				'summary'     => $summary,
				'occurred_at' => current_time( 'mysql', true ),
			)
		);
	}

	/**
	 * @return array<int,array{event_type:string,actor_id:?int,summary:?string,occurred_at:string}>
	 */
	public function find_by_task( int $task_id ): array {
		global $wpdb;

		$table = Schema::table( 'task_events' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT event_type, actor_id, summary, occurred_at FROM `{$table}` WHERE task_id = %d ORDER BY id ASC", $task_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return null !== $rows ? $rows : array();
	}
}
