<?php
/**
 * Persistence for authorised scopes against `wpr_scopes`, per Section 8.2.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Scope;

class ScopeRepository {

	public function find( int $id ): ?Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Scope::from_row( $row ) : null;
	}

	/**
	 * @return Scope[]
	 */
	public function find_by_organisation( int $organisation_id ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_id = %d ORDER BY id DESC", $organisation_id ), ARRAY_A );

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Every scope across every organisation, for the operator-facing admin screen. Never
	 * exposed to customers - callers must restrict to {@see find_by_organisation()} for any
	 * customer-facing surface.
	 *
	 * @return Scope[]
	 */
	public function list_all( int $per_page = 20, int $page = 1 ): array {
		global $wpdb;

		$table  = Schema::table( 'scopes' );
		$offset = max( 0, ( max( 1, $page ) - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A );

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function count_all(): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
	}

	/**
	 * Active scopes whose authorisation expires within the given window - Section 22.5's
	 * "Authorisation approaching expiry" notification trigger.
	 *
	 * @return Scope[]
	 */
	public function find_expiring_authorisations( int $within_days ): array {
		global $wpdb;

		$table   = Schema::table( 'scopes' );
		$now     = current_time( 'mysql', true );
		$horizon = ( new \DateTimeImmutable( $now ) )->modify( "+{$within_days} days" )->format( 'Y-m-d H:i:s' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE authorisation_status = 'authorised' AND authorised_until IS NOT NULL AND authorised_until BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$horizon
			),
			ARRAY_A
		);

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Counts scopes already covering the given registrable domain - the duplicate-domain signal
	 * the anti-abuse review queue uses (Section 5.6).
	 */
	public function count_by_registrable_domain( string $registrable_domain ): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE registrable_domain = %s", $registrable_domain ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function count_by_status( string $status ): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE status = %s", $status ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * Active scopes belonging to one organisation - Section 33's managed-plan `max_active_scopes`
	 * enforcement measures against this, not the global {@see count_by_status()}.
	 */
	public function count_active_by_organisation( int $organisation_id ): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE organisation_id = %d AND status = 'active'", $organisation_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * Active, authorised scopes whose recurring assessment is due - Section 33's durable
	 * schedules sweep. Excludes scopes that have never been seeded with a due date; those are
	 * picked up by {@see find_needing_schedule_seed()} first.
	 *
	 * @return Scope[]
	 */
	public function find_due_for_assessment( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE status = 'active' AND authorisation_status = 'authorised' AND next_assessment_due_at IS NOT NULL AND next_assessment_due_at <= %s ORDER BY next_assessment_due_at ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$limit
			),
			ARRAY_A
		);

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Active, authorised scopes that have never been through a schedule-seed pass - either newly
	 * authorised, or existing scopes from before schema version 9. The sweep seeds these with a
	 * due date (or leaves it null for a manual cadence) but does not dispatch a run on the same
	 * pass, so enabling schedules never causes a mass dispatch the instant it ships.
	 *
	 * Gated on `last_scheduled_at`, not `next_assessment_due_at`: a manual-cadence scope
	 * legitimately keeps `next_assessment_due_at` null forever, and must still only be seeded
	 * once rather than being re-selected by this query on every sweep.
	 *
	 * @return Scope[]
	 */
	public function find_needing_schedule_seed( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE status = 'active' AND authorisation_status = 'authorised' AND last_scheduled_at IS NULL ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Records that a scope's recurring assessment has been dispatched (or its due date seeded)
	 * and stores when it is next due. `$next_due_at` is always computed from now, never from the
	 * missed due date, so a late sweep never compounds drift into ever-earlier due dates.
	 */
	public function mark_scheduled( int $scope_id, ?\DateTimeImmutable $next_due_at ): void {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'next_assessment_due_at' => $next_due_at?->format( 'Y-m-d H:i:s' ),
				'last_scheduled_at'      => current_time( 'mysql', true ),
				'updated_at'             => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		if ( false === $updated ) {
			throw new ScopeRepositoryException( esc_html( "Failed to mark scope {$scope_id} as scheduled." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}
	}

	/**
	 * Creates a new scope. Domain canonicalisation (ASCII/display/registrable) must already
	 * have happened via {@see \Alltime\WPReconnaissance\Domain\DomainValidator} before calling
	 * this - the repository persists what it is given, it does not validate.
	 *
	 * @param string[]            $permitted_collectors
	 * @param string[]            $known_subdomains
	 * @param string[]            $known_dkim_selectors
	 * @param array<string,mixed> $expected_state
	 */
	public function create(
		int $organisation_id,
		string $name,
		string $domain_ascii,
		string $domain_display,
		string $registrable_domain,
		array $permitted_collectors,
		?int $monitoring_profile_id = null,
		array $known_subdomains = array(),
		array $known_dkim_selectors = array(),
		array $expected_state = array()
	): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'organisation_id'       => $organisation_id,
			'name'                  => $name,
			'domain_ascii'          => $domain_ascii,
			'domain_display'        => $domain_display,
			'registrable_domain'    => $registrable_domain,
			'status'                => 'pending',
			'authorisation_status'  => 'pending',
			'permitted_collectors'  => wp_json_encode( $permitted_collectors ),
			'known_subdomains'      => wp_json_encode( $known_subdomains ),
			'known_dkim_selectors'  => wp_json_encode( $known_dkim_selectors ),
			'expected_state'        => wp_json_encode( $expected_state ),
			'monitoring_profile_id' => $monitoring_profile_id,
			'created_at'            => $now,
			'updated_at'            => $now,
		);

		$inserted = $wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( false === $inserted ) {
			throw new ScopeRepositoryException( esc_html( "Failed to create a scope for organisation {$organisation_id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Authorises a pending scope. Section 27: the plugin must display a clear authorised-use
	 * notice during scope creation - enforced by the caller (the admin/CLI action invoking
	 * this), not by the repository.
	 *
	 * `$authorised_by = null` records a system/cron-triggered authorisation with no acting WP
	 * user - e.g. automatic authorisation on successful DNS TXT domain verification.
	 */
	public function authorise(
		int $scope_id,
		?int $authorised_by,
		string $authorisation_reference,
		?\DateTimeImmutable $authorised_from = null,
		?\DateTimeImmutable $authorised_until = null
	): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'                  => 'active',
				'authorisation_status'    => 'authorised',
				'authorised_by'           => $authorised_by,
				'authorisation_reference' => $authorisation_reference,
				'authorised_from'         => ( $authorised_from ?? new \DateTimeImmutable() )->format( 'Y-m-d H:i:s' ),
				'authorised_until'        => $authorised_until?->format( 'Y-m-d H:i:s' ),
				'updated_at'              => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		if ( false === $updated ) {
			throw new ScopeRepositoryException( esc_html( "Failed to authorise scope {$scope_id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $scope_id );
	}

	/**
	 * Scopes with an outstanding DNS TXT verification challenge - the 30-minute verification
	 * sweep's query, mirroring {@see find_due_for_assessment()}'s shape.
	 *
	 * @return Scope[]
	 */
	public function find_pending_domain_verification( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE domain_verification_status = 'pending' ORDER BY domain_verification_requested_at ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Records a freshly generated DNS TXT verification challenge, superseding any prior one -
	 * `domain_verified_at` is cleared since it applied to the old hash, not this one.
	 */
	public function start_domain_verification( int $scope_id, string $secret_hash, int $requested_by ): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'domain_verification_status'       => 'pending',
				'domain_verification_secret_hash'  => $secret_hash,
				'domain_verification_requested_at' => current_time( 'mysql', true ),
				'domain_verification_requested_by' => $requested_by,
				'domain_verified_at'               => null,
				'updated_at'                       => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		if ( false === $updated ) {
			throw new ScopeRepositoryException( esc_html( "Failed to start domain verification for scope {$scope_id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $scope_id );
	}

	/**
	 * Records a successful DNS TXT verification check. Does not itself authorise the scope -
	 * callers pair this with {@see authorise()}.
	 *
	 * @deprecated Use {@see verify_and_authorise()} for the DNS TXT verification path - two
	 *             separate writes leave a window where a scope can be left `verified` without
	 *             being `authorised` if the second write fails. Retained for any other caller
	 *             that genuinely wants only the verified-timestamp update.
	 */
	public function mark_domain_verified( int $scope_id ): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'domain_verification_status' => 'verified',
				'domain_verified_at'         => current_time( 'mysql', true ),
				'updated_at'                 => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		if ( false === $updated ) {
			throw new ScopeRepositoryException( esc_html( "Failed to mark domain verified for scope {$scope_id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $scope_id );
	}

	/**
	 * Atomically transitions a scope from a pending DNS TXT challenge straight to verified and
	 * authorised in one write, conditioned on the row's *currently persisted*
	 * `domain_verification_status` still being `pending` - not the caller's possibly-stale
	 * in-memory {@see Scope} object. This is what makes two concurrent successful checks for the
	 * same scope (e.g. an overlapping cron sweep and a customer-triggered "check now") safe: only
	 * one `UPDATE` can ever match the WHERE clause, so only one caller sees `true` and logs the
	 * success audit events: the other sees `false` and treats it as an ordinary no-op repeat
	 * check, exactly like an already-verified scope. Works identically on MySQL/MariaDB and
	 * SQLite - both give a WHERE-conditioned `UPDATE` the same all-or-nothing semantics for a
	 * single statement, without needing a database-specific transaction.
	 *
	 * @return bool True if this call performed the transition; false if the scope was not in
	 *              `pending` verification status by the time this write ran (already
	 *              verified/authorised by a concurrent caller, or never started) - an expected,
	 *              benign no-op, not a failure.
	 * @throws ScopeRepositoryException If the `UPDATE` itself fails at the database level (`false`
	 *                                   from $wpdb->update() - distinct from the row-count `0` case
	 *                                   above), so a caller can never mistake a genuine database
	 *                                   failure for an ordinary concurrent-no-op repeat check.
	 */
	public function verify_and_authorise( int $scope_id ): bool {
		global $wpdb;

		$table = Schema::table( 'scopes' );
		$now   = current_time( 'mysql', true );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'domain_verification_status' => 'verified',
				'domain_verified_at'         => $now,
				'status'                     => 'active',
				'authorisation_status'       => 'authorised',
				'authorised_by'              => null,
				'authorisation_reference'    => 'DNS TXT verification',
				'authorised_from'            => $now,
				// Matches authorise()'s own default: an automatic DNS-triggered authorisation is
				// unlimited-duration, clearing any earlier manually-set expiry rather than
				// silently inheriting a stale (possibly already-past) one from before this
				// verification cycle started.
				'authorised_until'           => null,
				'updated_at'                 => $now,
			),
			array(
				'id'                         => $scope_id,
				'domain_verification_status' => 'pending',
			)
		);

		if ( false === $updated ) {
			throw new ScopeRepositoryException( esc_html( "Failed to verify and authorise scope {$scope_id}." ) );
		}

		return $updated > 0;
	}

	/**
	 * Replaces a scope's baseline (Section 33 "baselines and expected state") wholesale - callers
	 * that only want to update one collector's baseline must read the current
	 * {@see Scope::$expected_state} first and merge, since this is not a partial update.
	 *
	 * @param array<string,mixed> $expected_state
	 */
	public function update_expected_state( int $scope_id, array $expected_state ): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'expected_state' => wp_json_encode( $expected_state ),
				'updated_at'     => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		if ( false === $updated ) {
			throw new ScopeRepositoryException( esc_html( "Failed to update the expected state for scope {$scope_id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $scope_id );
	}

	private function find_or_fail( int $id ): Scope {
		$scope = $this->find( $id );

		if ( null === $scope ) {
			throw new \RuntimeException( esc_html( "Scope {$id} was expected to exist but could not be loaded." ) );
		}

		return $scope;
	}
}
