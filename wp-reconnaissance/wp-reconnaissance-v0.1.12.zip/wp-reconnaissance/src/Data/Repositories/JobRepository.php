<?php
/**
 * Persistence for jobs against `wpr_jobs`, per Section 8.4.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\JobStatus;
use Alltime\WPReconnaissance\Domain\Job;

final class JobRepository {

	public function find( int $id ): ?Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Job::from_row( $row ) : null;
	}

	public function find_by_uuid( string $job_uuid ): ?Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE job_uuid = %s", $job_uuid ), ARRAY_A );

		return null !== $row ? Job::from_row( $row ) : null;
	}

	/**
	 * @return Job[] Most recent first.
	 */
	public function find_by_scope( int $scope_id, int $limit = 50 ): array {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE scope_id = %d ORDER BY id DESC LIMIT %d", $scope_id, $limit ), ARRAY_A );

		return array_map( array( Job::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return Job[] Most recent first, across every organisation - for the operator-facing
	 *               admin overview only.
	 */
	public function list_recent( int $limit = 50 ): array {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );

		return array_map( array( Job::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Count of jobs created since the given time, for the admin overview's "jobs today" tile.
	 */
	public function count_since( \DateTimeImmutable $since ): int {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE created_at >= %s", $since->format( 'Y-m-d H:i:s' ) ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * Counts jobs that are still in the pipeline (pending, authorised or queued) - the backlog
	 * the anti-abuse maximum-queued-jobs throttle measures (Section 5.6).
	 */
	public function count_queued(): int {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE status IN (%s, %s, %s)", JobStatus::Pending->value, JobStatus::Authorised->value, JobStatus::Queued->value ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Count of jobs in a given status created since the given time - Section 33's operator-facing
	 * failure-monitoring "jobs failed today" tile.
	 */
	public function count_by_status_since( JobStatus $status, \DateTimeImmutable $since ): int {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE status = %s AND created_at >= %s", $status->value, $since->format( 'Y-m-d H:i:s' ) ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * Scope IDs whose most recent `$threshold` jobs are all failures - Section 33's operator-facing
	 * failure-monitoring view of the same signal
	 * {@see \Alltime\WPReconnaissance\Notifications\NotificationDispatcher::on_job_completed()}'s
	 * customer-facing "repeated collection failure" trigger already reacts to per scope, computed
	 * proactively across the whole fleet rather than only at the moment one job completes.
	 * `$candidate_scan_limit` bounds the initial distinct-scope scan so this stays cheap on a
	 * large fleet, at the cost of possibly missing a repeatedly-failing scope whose most recent
	 * failure is older than that many failed-job rows back.
	 *
	 * @return int[]
	 */
	public function find_scopes_with_repeated_failures( int $threshold, int $candidate_scan_limit = 200 ): array {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$candidates = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT scope_id FROM `{$table}` WHERE status = %s ORDER BY id DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				JobStatus::Failed->value,
				$candidate_scan_limit
			)
		);

		$repeatedly_failing = array();

		foreach ( null !== $candidates ? $candidates : array() as $candidate ) {
			$scope_id = (int) $candidate;
			$recent   = $this->find_by_scope( $scope_id, $threshold );

			if ( count( $recent ) >= $threshold && self::all_failed( $recent ) ) {
				$repeatedly_failing[] = $scope_id;
			}
		}

		return $repeatedly_failing;
	}

	/**
	 * @param Job[] $jobs
	 */
	private static function all_failed( array $jobs ): bool {
		foreach ( $jobs as $job ) {
			if ( JobStatus::Failed !== $job->status ) {
				return false;
			}
		}

		return true;
	}

	public function create( string $job_uuid, int $organisation_id, int $scope_id, ?int $actor_id, string $adapter ): Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'job_uuid'        => $job_uuid,
			'organisation_id' => $organisation_id,
			'scope_id'        => $scope_id,
			'status'          => JobStatus::Pending->value,
			'adapter'         => $adapter,
			'actor_id'        => $actor_id,
			'requested_at'    => $now,
			'created_at'      => $now,
			'updated_at'      => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * @param array<string,mixed> $extra Additional columns to set alongside the status
	 *                                    transition (manifest_hash, worker_version, exit_code,
	 *                                    error_category, timestamps).
	 */
	public function transition( int $job_id, JobStatus $status, array $extra = array() ): Job {
		global $wpdb;

		$table = Schema::table( 'jobs' );

		$data             = array_merge(
			$extra,
			array(
				'status'     => $status->value,
				'updated_at' => current_time( 'mysql', true ),
			)
		);
		$timestamp_column = match ( $status ) {
			JobStatus::Queued => 'queued_at',
			JobStatus::Running => 'started_at',
			JobStatus::Succeeded, JobStatus::PartiallySucceeded, JobStatus::Failed, JobStatus::Cancelled, JobStatus::Expired => 'completed_at',
			default => null,
		};

		if ( null !== $timestamp_column && ! isset( $data[ $timestamp_column ] ) ) {
			$data[ $timestamp_column ] = current_time( 'mysql', true );
		}

		$wpdb->update( $table, $data, array( 'id' => $job_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( $job_id );
	}

	private function find_or_fail( int $id ): Job {
		$job = $this->find( $id );

		if ( null === $job ) {
			throw new \RuntimeException( esc_html( "Job {$id} was expected to exist but could not be loaded." ) );
		}

		return $job;
	}
}
