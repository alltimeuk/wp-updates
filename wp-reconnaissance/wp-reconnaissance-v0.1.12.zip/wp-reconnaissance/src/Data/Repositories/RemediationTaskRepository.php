<?php
/**
 * Persistence for remediation tasks against `wpr_remediation_tasks`, per Section 21.3.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\RemediationTaskStatus;
use Alltime\WPReconnaissance\Domain\RemediationTask;
use Alltime\WPReconnaissance\Reports\PriorityBand;
use Alltime\WPReconnaissance\Reports\TechnicalSubject;

final class RemediationTaskRepository {

	/** How far ahead of the target date a requested reminder is sent (Section 22.5). */
	private const REMINDER_LOOKAHEAD_DAYS = 7;

	public function find( int $id ): ?RemediationTask {
		global $wpdb;

		$table = Schema::table( 'remediation_tasks' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? $this->hydrate( $row ) : null;
	}

	/**
	 * The task already generated for a finding, if any - findings map to at most one task, kept
	 * updated (not duplicated) across re-scans (Section 21.3: "must not silently destroy task
	 * history").
	 */
	public function find_by_finding( int $finding_id ): ?RemediationTask {
		global $wpdb;

		$table = Schema::table( 'remediation_tasks' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE finding_id = %d", $finding_id ), ARRAY_A );

		return null !== $row ? $this->hydrate( $row ) : null;
	}

	/**
	 * @return RemediationTask[] Ordered by recommended_order within priority band, most urgent first.
	 */
	public function find_by_scope( int $scope_id ): array {
		global $wpdb;

		$table = Schema::table( 'remediation_tasks' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE scope_id = %d ORDER BY priority_band ASC, recommended_order ASC", $scope_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	/**
	 * @return RemediationTask[]
	 */
	public function find_by_organisation( int $organisation_id ): array {
		global $wpdb;

		$table = Schema::table( 'remediation_tasks' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_id = %d ORDER BY priority_band ASC, recommended_order ASC", $organisation_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Counts of not-yet-terminal tasks grouped by priority band, for the admin/customer
	 * dashboard's "highest-priority open tasks" tile (Section 20.1).
	 *
	 * @return array<string,int> Priority band value => count.
	 */
	public function count_open_by_priority( ?int $organisation_id = null ): array {
		global $wpdb;

		$table         = Schema::table( 'remediation_tasks' );
		$open_statuses = array(
			RemediationTaskStatus::NotStarted->value,
			RemediationTaskStatus::Planned->value,
			RemediationTaskStatus::InProgress->value,
			RemediationTaskStatus::Blocked->value,
			RemediationTaskStatus::ReadyForValidation->value,
		);
		$placeholders  = implode( ',', array_fill( 0, count( $open_statuses ), '%s' ) );

		$sql    = "SELECT priority_band, COUNT(*) as total FROM `{$table}` WHERE status IN ({$placeholders})"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table/$placeholders are fixed, internally derived identifiers, not user input.
		$params = $open_statuses;

		if ( null !== $organisation_id ) {
			$sql     .= ' AND organisation_id = %d';
			$params[] = $organisation_id;
		}

		$sql .= ' GROUP BY priority_band';

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql is built above from fixed fragments only; every value is bound via $wpdb->prepare().
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$counts = array_fill_keys( array_map( static fn ( PriorityBand $band ): string => $band->value, PriorityBand::cases() ), 0 );

		foreach ( null !== $rows ? $rows : array() as $row ) {
			$counts[ (string) $row['priority_band'] ] = (int) $row['total'];
		}

		return $counts;
	}

	/**
	 * Inserts a new task or updates the existing one for the same finding_id, per {@see find_by_finding()}.
	 *
	 * @param string[]            $implementation_steps
	 * @param string[]            $validation_steps
	 * @param string[]            $dependencies
	 * @param array<string,mixed> $priority_explanation
	 */
	public function upsert_for_finding(
		int $organisation_id,
		int $scope_id,
		int $finding_id,
		string $rule_id,
		string $title,
		TechnicalSubject $technical_subject,
		PriorityBand $priority_band,
		int $priority_score,
		array $priority_explanation,
		int $recommended_order,
		?string $rationale,
		array $implementation_steps,
		array $validation_steps,
		array $dependencies,
		?string $suggested_owner_type,
		?string $estimated_effort_band
	): RemediationTask {
		global $wpdb;

		$table    = Schema::table( 'remediation_tasks' );
		$now      = current_time( 'mysql', true );
		$existing = $this->find_by_finding( $finding_id );

		$data = array(
			'organisation_id'       => $organisation_id,
			'scope_id'              => $scope_id,
			'finding_id'            => $finding_id,
			'rule_id'               => $rule_id,
			'title'                 => $title,
			'technical_subject'     => $technical_subject->value,
			'priority_band'         => $priority_band->value,
			'priority_score'        => $priority_score,
			'priority_explanation'  => wp_json_encode( $priority_explanation ),
			'recommended_order'     => $recommended_order,
			'rationale'             => $rationale,
			'implementation_steps'  => wp_json_encode( $implementation_steps ),
			'validation_steps'      => wp_json_encode( $validation_steps ),
			'dependencies'          => wp_json_encode( $dependencies ),
			'suggested_owner_type'  => $suggested_owner_type,
			'estimated_effort_band' => $estimated_effort_band,
			'updated_at'            => $now,
		);

		if ( null === $existing ) {
			$data['task_uuid']  = wp_generate_uuid4();
			$data['status']     = RemediationTaskStatus::NotStarted->value;
			$data['created_at'] = $now;
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			return $this->find_or_fail( (int) $wpdb->insert_id );
		}

		$wpdb->update( $table, $data, array( 'id' => $existing->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $existing->id );
	}

	public function update_status(
		int $id,
		RemediationTaskStatus $status,
		?string $customer_notes,
		?string $operator_notes,
		?\DateTimeImmutable $target_date
	): RemediationTask {
		global $wpdb;

		$table = Schema::table( 'remediation_tasks' );
		$now   = current_time( 'mysql', true );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'         => $status->value,
				'customer_notes' => $customer_notes,
				'operator_notes' => $operator_notes,
				'target_date'    => $target_date?->format( 'Y-m-d' ),
				'completed_at'   => $status->is_terminal() ? $now : null,
				'updated_at'     => $now,
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	/**
	 * Sets whether the customer has asked to be reminded about this task, and how many days
	 * before the target date (Section 22.5 "Remediation reminder where requested", Section 33
	 * customer-configurable notifications). `$days_before` of null falls back to
	 * {@see self::REMINDER_LOOKAHEAD_DAYS} at query time. The reminder itself is sent by the
	 * daily sweep in {@see \Alltime\WPReconnaissance\Notifications\NotificationDispatcher::check_task_reminders()}.
	 */
	public function set_reminder_preferences( int $id, bool $requested, ?int $days_before ): void {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'remediation_tasks' ),
			array(
				'reminder_requested'   => $requested ? 1 : 0,
				'reminder_days_before' => $days_before,
				'updated_at'           => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);
	}

	/**
	 * Tasks the customer has asked to be reminded about whose target date is due now or within
	 * that task's own reminder lookahead (its `reminder_days_before`, or
	 * {@see self::REMINDER_LOOKAHEAD_DAYS} where the customer never chose one) - the daily
	 * sweep's candidate list. Terminal tasks and tasks without a target date are excluded (a
	 * reminder needs a date to key off).
	 *
	 * @return RemediationTask[]
	 */
	public function find_due_reminders(): array {
		global $wpdb;

		$table         = Schema::table( 'remediation_tasks' );
		$open_statuses = array(
			RemediationTaskStatus::NotStarted->value,
			RemediationTaskStatus::Planned->value,
			RemediationTaskStatus::InProgress->value,
			RemediationTaskStatus::Blocked->value,
			RemediationTaskStatus::ReadyForValidation->value,
		);
		$placeholders  = implode( ',', array_fill( 0, count( $open_statuses ), '%s' ) );

		// $table/$placeholders are fixed, internally derived identifiers; every value is bound via $wpdb->prepare().
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE reminder_requested = 1 AND status IN ({$placeholders}) AND target_date IS NOT NULL AND target_date <= DATE_ADD(CURDATE(), INTERVAL COALESCE(reminder_days_before, %d) DAY) ORDER BY target_date ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_merge( $open_statuses, array( self::REMINDER_LOOKAHEAD_DAYS ) )
			),
			ARRAY_A
		);

		return array_map( array( $this, 'hydrate' ), null !== $rows ? $rows : array() );
	}

	private function find_or_fail( int $id ): RemediationTask {
		$task = $this->find( $id );

		if ( null === $task ) {
			throw new \RuntimeException( esc_html( "Remediation task {$id} was expected to exist but could not be loaded." ) );
		}

		return $task;
	}

	/**
	 * @param array<string,mixed> $row
	 */
	private function hydrate( array $row ): RemediationTask {
		return RemediationTask::from_row( $row );
	}
}
