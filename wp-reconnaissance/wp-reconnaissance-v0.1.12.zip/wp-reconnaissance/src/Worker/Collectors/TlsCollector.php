<?php
/**
 * Connects with SNI, captures the certificate, and records the actual chain-trust and
 * hostname-matching outcome from two separate probes rather than assuming validity from a
 * successful handshake alone (Section 12.1: "do not use an accept-all callback as evidence of
 * hostname validity").
 *
 * One connection is made with peer verification disabled purely to capture the certificate
 * even when it is invalid; a second, independent connection with the system's default CA
 * bundle verifies chain trust only (verify_peer_name is deliberately left off that probe -
 * PHP has no equivalent to .NET's independent SslPolicyErrors flags, so a hostname mismatch
 * would otherwise fail that connection too and get misreported as chain distrust). Hostname
 * matching is evaluated entirely separately via hostname_matches() against the captured
 * certificate's SAN/CN, so the two outcomes stay independent all the way through. This mirrors
 * the previous engine's approach of always capturing the certificate while recording the real
 * policy-error outcome separately, adapted to PHP's stream-socket TLS API.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;

final class TlsCollector extends AbstractCollector {
    public function key(): string {
        return 'tls';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $timeout = $context->timeout_for($this->key());

        $certificate = $this->capture_certificate($context->domain, $timeout);

        if (null === $certificate) {
            return $this->result(
                CollectorStatus::Failed,
                $started,
                'direct_tls_connection',
                errors: [ "Unable to establish a TLS connection to {$context->domain}:443." ]
            );
        }

        $parsed = openssl_x509_parse($certificate);

        if (false === $parsed) {
            return $this->result(CollectorStatus::Failed, $started, 'direct_tls_connection', errors: [ 'Unable to parse the presented certificate.' ]);
        }

        $chain_trusted    = $this->probe_chain_trust($context->domain, $timeout);
        $san              = $this->extract_san($parsed);
        $hostname_matches = $this->hostname_matches($context->domain, $parsed['subject']['CN'] ?? '', $san);

        $not_after = (int) $parsed['validTo_time_t'];

        $data = [
            'certificate' => [
                'connected'        => true,
                'subject'          => $this->format_dn($parsed['subject'] ?? []),
                'issuer'           => $this->format_dn($parsed['issuer'] ?? []),
                'not_before'       => gmdate(DATE_ATOM, (int) $parsed['validFrom_time_t']),
                'not_after'        => gmdate(DATE_ATOM, $not_after),
                'san'              => $san,
                'hostname_matches' => $hostname_matches,
                'chain_trusted'    => $chain_trusted,
            ],
            'expires_in_days' => (int) floor(( $not_after - time() ) / 86400),
        ];

        return $this->result(
            CollectorStatus::Succeeded,
            $started,
            'direct_tls_connection',
            $data,
            [ 'Certificate revocation status is not checked; only chain trust and hostname matching are evaluated.' ]
        );
    }

    /**
     * @return \OpenSSLCertificate|null Null if the handshake failed entirely.
     */
    private function capture_certificate( string $domain, int $timeout ): ?\OpenSSLCertificate {
        $context = stream_context_create(
            [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'capture_peer_cert' => true,
                    'SNI_enabled'       => true,
                    'peer_name'         => $domain,
                ],
            ]
        );

        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- failure is reported via the null return, not the emitted warning.
        $socket = @stream_socket_client("ssl://{$domain}:443", $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $context);

        if (false === $socket) {
            return null;
        }

        $options = stream_context_get_options($context);
        fclose($socket);

        return $options['ssl']['peer_certificate'] ?? null;
    }

    private function probe_chain_trust( string $domain, int $timeout ): bool {
        // verify_peer_name is intentionally false: this probe must answer "is the chain
        // trusted" in isolation. With it true, a domain with a perfectly valid chain but
        // a merely-mismatched hostname would fail this connection too and get reported as
        // chain_trusted=false, misattributing a hostname problem as a chain-trust one.
        // hostname_matches() is the sole, independent source of truth for the hostname
        // question. peer_name/SNI_enabled are unaffected by this - SNI is still sent.
        $context = stream_context_create(
            [
                'ssl' => [
                    'verify_peer'      => true,
                    'verify_peer_name' => false,
                    'SNI_enabled'      => true,
                    'peer_name'        => $domain,
                ],
            ]
        );

        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- failure means "not trusted", reflected in the boolean return.
        $socket = @stream_socket_client("ssl://{$domain}:443", $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $context);

        if (false === $socket) {
            return false;
        }

        fclose($socket);

        return true;
    }

    /**
     * @param array<string,mixed> $parsed
     * @return string[]
     */
    private function extract_san( array $parsed ): array {
        $raw = $parsed['extensions']['subjectAltName'] ?? '';

        if ('' === $raw) {
            return [];
        }

        return array_map('trim', explode(',', $raw));
    }

    /**
     * @param string[] $san
     */
    private function hostname_matches( string $domain, string $common_name, array $san ): bool {
        $candidates = array_merge([ $common_name ], array_map(static fn ( string $entry ): string => preg_replace('/^DNS:/', '', $entry) ?? $entry, $san));

        foreach ($candidates as $candidate) {
            if ('' === $candidate) {
                continue;
            }

            $pattern = '/^' . str_replace('\*', '[^.]+', preg_quote($candidate, '/')) . '$/i';

            if (1 === preg_match($pattern, $domain)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string,string> $dn
     */
    private function format_dn( array $dn ): string {
        $parts = [];

        foreach ($dn as $key => $value) {
            $parts[] = "{$key}={$value}";
        }

        return implode(', ', $parts);
    }
}
