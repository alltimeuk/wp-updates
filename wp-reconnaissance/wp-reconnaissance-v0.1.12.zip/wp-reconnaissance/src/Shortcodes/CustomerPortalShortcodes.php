<?php
/**
 * `[wpr_customer_*]`: themed-page-compatible equivalents of the customer portal's raw
 * `/customer/*` routes, so a site can embed the same registration/login/account/etc. screens
 * inside ordinary WordPress Pages - real navigation, theme header/footer, styling - instead of
 * only reaching them via the plugin's own unthemed routes. Both mechanisms work permanently side
 * by side; this class adds the shortcode side without changing anything about the raw routes.
 *
 * Purely presentational: every actual nonce/rate-limit/ownership check and every byte of form
 * markup lives in {@see \Alltime\WPReconnaissance\Auth\AuthBootstrap}, which already owns all of
 * it for the raw-route path. This class only registers the shortcode tags and forwards each one's
 * `$atts` into {@see \Alltime\WPReconnaissance\Auth\AuthBootstrap::render_customer_shortcode()} -
 * matching the file-per-shortcode convention {@see GetStartedShortcode} already established,
 * without duplicating or fragmenting any security-sensitive logic out of AuthBootstrap.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Shortcodes;

use Alltime\WPReconnaissance\Auth\AuthBootstrap;

final class CustomerPortalShortcodes {

	/**
	 * Shortcode tag => the AuthBootstrap route slug it renders.
	 *
	 * @var array<string,string>
	 */
	private const ROUTES_BY_TAG = array(
		'wpr_customer_register'        => 'register',
		'wpr_customer_verify_email'    => 'verify-email',
		'wpr_customer_login'           => 'login',
		'wpr_customer_forgot_password' => 'forgot-password',
		'wpr_customer_reset_password'  => 'reset-password',
		'wpr_customer_account'         => 'account',
		'wpr_customer_security'        => 'security',
		'wpr_customer_privacy'         => 'privacy',
		'wpr_customer_tools'           => 'tools',
		'wpr_customer_reports'         => 'reports',
		'wpr_customer_tasks'           => 'tasks',
	);

	public function __construct(
		private readonly AuthBootstrap $auth_bootstrap = new AuthBootstrap()
	) {}

	public function boot(): void {
		foreach ( self::ROUTES_BY_TAG as $tag => $route ) {
			add_shortcode( $tag, array( $this, 'render' ) );
		}
	}

	/**
	 * @param array<string,mixed>|string $atts
	 */
	public function render( $atts, ?string $content = null, string $tag = '' ): string {
		$route = self::ROUTES_BY_TAG[ $tag ] ?? '';

		if ( '' === $route ) {
			return '';
		}

		return $this->auth_bootstrap->render_customer_shortcode( $route, (array) $atts );
	}
}
