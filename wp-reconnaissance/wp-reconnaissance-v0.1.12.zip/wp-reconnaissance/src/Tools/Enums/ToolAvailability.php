<?php
/**
 * Tool availability state, per Section 5.4/20.2.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Tools\Enums;

enum ToolAvailability: string {
	case Available  = 'available';
	case ComingSoon = 'coming_soon';
	case Disabled   = 'disabled';
}
