<?php
/**
 * Tool registry, per Section 5.4: "so later Alltime tools can reuse the platform... Do not
 * hard-code all portal navigation, entitlements or reports to this single tool."
 *
 * Populated entirely through the `wpr_register_tools` action - {@see ToolsBootstrap} fires it
 * and is itself the first (and, today, only) listener, registering `domain-reconnaissance`
 * through the exact same public API a later tool would use. Nothing in Admin, the customer
 * portal or REST should ever hard-code that tool's ID outside of that one registration call.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Tools;

use Alltime\WPReconnaissance\Tools\Enums\ToolAvailability;

final class ToolRegistry {

	public const REGISTER_HOOK = 'wpr_register_tools';

	/** @var array<string,ToolDefinition> */
	private array $tools = array();

	private bool $loaded = false;

	public function register( ToolDefinition $tool ): void {
		$this->tools[ $tool->id ] = $tool;
	}

	public function get( string $id ): ?ToolDefinition {
		$this->ensure_loaded();

		return $this->tools[ $id ] ?? null;
	}

	/**
	 * @return ToolDefinition[]
	 */
	public function all(): array {
		$this->ensure_loaded();

		return array_values( $this->tools );
	}

	/**
	 * @return ToolDefinition[] Only tools currently offered to customers.
	 */
	public function available(): array {
		return array_values(
			array_filter(
				$this->all(),
				static fn ( ToolDefinition $tool ): bool => ToolAvailability::Available === $tool->availability
			)
		);
	}

	/**
	 * Fires {@see REGISTER_HOOK} on first use rather than at construction, so registration order
	 * never depends on when a caller happens to instantiate the registry.
	 */
	private function ensure_loaded(): void {
		if ( $this->loaded ) {
			return;
		}

		$this->loaded = true;

		do_action( self::REGISTER_HOOK, $this ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- self::REGISTER_HOOK is the literal, properly-prefixed 'wpr_register_tools'; the sniff cannot verify a constant reference statically.
	}
}
