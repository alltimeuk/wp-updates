<?php
/**
 * A registered self-service tool, per Section 5.4.
 *
 * `job_provider` and `report_provider` are class-strings rather than instances: the registry
 * only describes what a tool is, it never constructs the (potentially expensive) services that
 * run it - a caller resolves and instantiates them only once a customer actually invokes the
 * tool.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Tools;

use Alltime\WPReconnaissance\Tools\Enums\ToolAvailability;

final class ToolDefinition {

	/**
	 * @param string[]     $required_customer_fields
	 * @param string[]     $applicable_remediation_taxonomies Section 21.4 TechnicalSubject values this tool's findings can map to.
	 * @param string[]     $privacy_purpose_references
	 * @param class-string $job_provider Fully-qualified class name of the service that runs this tool's jobs (e.g. AssessmentService).
	 * @param class-string $report_provider Fully-qualified class name implementing ReportGeneratorInterface for this tool.
	 */
	public function __construct(
		public readonly string $id,
		public readonly string $version,
		public readonly string $name,
		public readonly string $description,
		public readonly ?string $icon,
		public readonly ToolAvailability $availability,
		public readonly array $required_customer_fields,
		public readonly string $required_scope_type,
		public readonly string $authorisation_statement,
		public readonly string $entitlement_rule_id,
		public readonly string $job_provider,
		public readonly string $evidence_schema,
		public readonly string $report_provider,
		public readonly array $applicable_remediation_taxonomies,
		public readonly array $privacy_purpose_references,
		public readonly string $estimated_completion_behaviour
	) {}
}
