<?php
/**
 * Registers the built-in `domain-reconnaissance` tool (Section 5.4) through
 * {@see ToolRegistry::REGISTER_HOOK} - the same public API any later Alltime tool would use, so
 * this module never gets special-cased access the registry doesn't offer everyone else.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Tools;

use Alltime\WPReconnaissance\Assessment\AssessmentService;
use Alltime\WPReconnaissance\Reports\DomainReconnaissanceReportBuilder;
use Alltime\WPReconnaissance\Tools\Enums\ToolAvailability;

final class ToolsBootstrap {

	public const DOMAIN_RECONNAISSANCE_TOOL_ID = 'domain-reconnaissance';

	public function boot(): void {
		add_action( ToolRegistry::REGISTER_HOOK, array( $this, 'register_domain_reconnaissance' ) );
	}

	public function register_domain_reconnaissance( ToolRegistry $registry ): void {
		$registry->register(
			new ToolDefinition(
				id: self::DOMAIN_RECONNAISSANCE_TOOL_ID,
				version: '1.0.0',
				name: __( 'Domain Reconnaissance', 'wp-reconnaissance' ),
				description: __( 'A self-service assessment of your domain, DNS, mail authentication, web and certificate configuration, with a prioritised remediation plan.', 'wp-reconnaissance' ),
				icon: 'dashicons-shield',
				availability: ToolAvailability::Available,
				required_customer_fields: array( 'given_name', 'family_name', 'email', 'organisation_name' ),
				required_scope_type: 'domain',
				authorisation_statement: __( 'You confirm you are authorised to request an external assessment of this domain on behalf of its owner.', 'wp-reconnaissance' ),
				entitlement_rule_id: 'domain_reconnaissance_free_report',
				job_provider: AssessmentService::class,
				evidence_schema: 'schemas/evidence.schema.json',
				report_provider: DomainReconnaissanceReportBuilder::class,
				applicable_remediation_taxonomies: array(
					'domain_registration_and_ownership',
					'dns_architecture_and_resilience',
					'email_authentication_and_deliverability',
					'web_transport_and_tls_pki',
					'web_security_headers_and_browser_controls',
				),
				privacy_purpose_references: array( 'domain_reconnaissance_assessment' ),
				estimated_completion_behaviour: __( 'Runs in the background and typically completes within a few minutes.', 'wp-reconnaissance' )
			)
		);
	}
}
