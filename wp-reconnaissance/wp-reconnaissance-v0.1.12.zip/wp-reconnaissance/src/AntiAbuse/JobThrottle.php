<?php
/**
 * Maximum-queued-jobs throttle, per Section 5.6. When the global job backlog is at or above the
 * configured ceiling, new free assessments are held for operator review rather than dispatched,
 * protecting the worker from being overwhelmed by a burst of registrations.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse;

use Alltime\WPReconnaissance\Data\Repositories\JobRepository;

class JobThrottle {

	public function __construct(
		private readonly JobRepository $jobs = new JobRepository()
	) {}

	/**
	 * Returns true when the current queued-job count is at or above the ceiling, i.e. the
	 * throttle is engaged. A ceiling of zero or less disables the throttle.
	 */
	public function is_throttled( int $max_queued_jobs ): bool {
		if ( $max_queued_jobs <= 0 ) {
			return false;
		}

		return $this->jobs->count_queued() >= $max_queued_jobs;
	}
}
