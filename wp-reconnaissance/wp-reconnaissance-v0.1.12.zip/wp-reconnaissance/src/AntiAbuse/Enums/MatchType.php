<?php
/**
 * The kind of subject a blocklist entry matches, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Enums;

enum MatchType: string {
	case Email  = 'email';
	case Domain = 'domain';
	case Ip     = 'ip';
}
