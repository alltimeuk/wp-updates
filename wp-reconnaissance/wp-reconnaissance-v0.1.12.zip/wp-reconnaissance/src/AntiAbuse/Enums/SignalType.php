<?php
/**
 * The kinds of anti-abuse signal the review queue can hold, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Enums;

enum SignalType: string {
	/** The submitted email's domain is a known disposable-email provider - a review signal, not a rejection. */
	case DisposableEmail = 'disposable_email';

	/** The registrable domain already has a scope in the system - a duplicate-domain signal. */
	case DuplicateDomain = 'duplicate_domain';

	/** The global queued-job count is at or above the configured maximum - a throttle signal. */
	case MaxQueuedJobs = 'max_queued_jobs';

	/** The submitted email address matches a blocklist entry. */
	case BlockedEmail = 'blocked_email';

	/** The submitted domain matches a blocklist entry. */
	case BlockedDomain = 'blocked_domain';

	/** The client IP matches a blocklist entry. */
	case BlockedIp = 'blocked_ip';

	/** The bot-challenge (CAPTCHA/honeypot) check failed. */
	case CaptchaFailed = 'captcha_failed';
}
