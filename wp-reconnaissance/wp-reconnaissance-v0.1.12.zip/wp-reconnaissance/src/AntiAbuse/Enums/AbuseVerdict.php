<?php
/**
 * The outcome of an anti-abuse eligibility evaluation, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Enums;

enum AbuseVerdict: string {
	/** No adverse signal - the request proceeds normally. */
	case Allow = 'allow';

	/** One or more review signals were raised - the request proceeds but is held for operator review. */
	case Review = 'review';

	/** A hard block applies - the request is rejected outright. */
	case Block = 'block';
}
