<?php
/**
 * Lifecycle states of an anti-abuse review signal, per Section 5.6's review-and-release queue.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Enums;

enum SignalState: string {
	/** Awaiting operator review. An open review signal holds the affected free assessment. */
	case Open = 'open';

	/** An operator reviewed and released the signal - the held work may proceed. */
	case Released = 'released';

	/** An operator reviewed and blocked the subject - a blocklist entry was created. */
	case Blocked = 'blocked';

	/** An operator reviewed and dismissed the signal as a false positive. */
	case Dismissed = 'dismissed';

	public function is_open(): bool {
		return self::Open === $this;
	}
}
