<?php
/**
 * Whether a blocklist entry blocks or allows a subject, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Enums;

enum ListType: string {
	case Block = 'block';
	case Allow = 'allow';
}
