<?php
/**
 * No-op bot-challenge adapter used when no CAPTCHA is configured, per Section 5.6. It never
 * challenges a request, so the registration flow is unchanged until an operator enables one.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Captcha;

final class NoopCaptchaAdapter implements CaptchaAdapterInterface {

	public function is_configured(): bool {
		return false;
	}

	public function verify( array $input, string $ip ): bool {
		return true;
	}

	public function render(): string {
		return '';
	}
}
