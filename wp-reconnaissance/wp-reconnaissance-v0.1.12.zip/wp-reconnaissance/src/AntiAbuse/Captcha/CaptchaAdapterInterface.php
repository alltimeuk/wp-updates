<?php
/**
 * Configurable CAPTCHA or bot-challenge adapter, per Section 5.6.
 *
 * The interface is deliberately small so a real CAPTCHA provider (hCaptcha, Cloudflare Turnstile,
 * reCAPTCHA) can be swapped in later without touching the registration flow. The bundled
 * HoneypotCaptchaAdapter is a zero-dependency bot challenge that works out of the box.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Captcha;

interface CaptchaAdapterInterface {

	/**
	 * Whether this adapter is enabled and ready to challenge requests.
	 */
	public function is_configured(): bool;

	/**
	 * Verifies a submitted challenge. Returns true when the request is human (or no challenge is
	 * required). The $input array is the raw form submission; $ip is the client IP.
	 *
	 * @param array<string,mixed> $input
	 */
	public function verify( array $input, string $ip ): bool;

	/**
	 * Returns the markup (hidden fields / widget) to embed in the form. Empty when not configured.
	 */
	public function render(): string;
}
