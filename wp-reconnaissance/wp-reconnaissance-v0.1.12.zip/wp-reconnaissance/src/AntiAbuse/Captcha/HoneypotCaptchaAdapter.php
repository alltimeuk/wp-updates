<?php
/**
 * Zero-dependency bot-challenge adapter, per Section 5.6. Combines a hidden honeypot field that
 * bots tend to fill in with a minimum-form-fill-time check. No external service or API key is
 * required, so it works out of the box and can be replaced by a real CAPTCHA provider later.
 *
 * The honeypot field is hidden with CSS and labelled "leave this field empty" for assistive
 * technology; a human never sees or fills it, so a filled value is a strong bot signal.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Captcha;

final class HoneypotCaptchaAdapter implements CaptchaAdapterInterface {

	public const HONEYPOT_FIELD = 'wpr_website';
	public const STARTED_FIELD  = 'wpr_form_started';

	public function __construct(
		private readonly bool $enabled = true,
		private readonly int $min_form_seconds = 3
	) {}

	public function is_configured(): bool {
		return $this->enabled;
	}

	public function verify( array $input, string $ip ): bool {
		if ( ! $this->enabled ) {
			return true;
		}

		$honeypot = isset( $input[ self::HONEYPOT_FIELD ] ) ? (string) $input[ self::HONEYPOT_FIELD ] : '';

		if ( '' !== trim( $honeypot ) ) {
			return false;
		}

		$started = isset( $input[ self::STARTED_FIELD ] ) ? (int) $input[ self::STARTED_FIELD ] : 0;

		if ( $started > 0 && $this->min_form_seconds > 0 ) {
			$elapsed = time() - $started;

			if ( $elapsed < $this->min_form_seconds ) {
				return false;
			}
		}

		return true;
	}

	public function render(): string {
		if ( ! $this->enabled ) {
			return '';
		}

		$started = time();

		return sprintf(
			'<p class="wpr-hp" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true">' .
			'<label for="%1$s">Leave this field empty</label>' .
			'<input type="text" id="%1$s" name="%1$s" tabindex="-1" autocomplete="off" />' .
			'</p>' .
			'<input type="hidden" name="%2$s" value="%3$d" />',
			esc_attr( self::HONEYPOT_FIELD ),
			esc_attr( self::STARTED_FIELD ),
			$started
		);
	}
}
