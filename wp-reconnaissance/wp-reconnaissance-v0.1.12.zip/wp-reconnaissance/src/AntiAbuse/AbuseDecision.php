<?php
/**
 * The outcome of an anti-abuse eligibility evaluation, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse;

use Alltime\WPReconnaissance\AntiAbuse\Enums\AbuseVerdict;

final class AbuseDecision {

	/**
	 * @param string[] $reasons Human-readable reasons for the verdict, for the audit log and
	 *                          operator review - never shown verbatim to a customer.
	 */
	public function __construct(
		public readonly AbuseVerdict $verdict,
		public readonly array $reasons
	) {}

	public function allows(): bool {
		return AbuseVerdict::Allow === $this->verdict;
	}

	public function blocks(): bool {
		return AbuseVerdict::Block === $this->verdict;
	}

	public function needs_review(): bool {
		return AbuseVerdict::Review === $this->verdict;
	}
}
