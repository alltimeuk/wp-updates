<?php
/**
 * The inputs an anti-abuse eligibility evaluation needs, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse;

final class RegistrationContext {

	/**
	 * @param array<string,mixed> $captcha_input Raw form submission passed to the bot-challenge adapter.
	 */
	public function __construct(
		public readonly string $email,
		public readonly string $registrable_domain,
		public readonly string $ip,
		public readonly array $captcha_input = array()
	) {}
}
