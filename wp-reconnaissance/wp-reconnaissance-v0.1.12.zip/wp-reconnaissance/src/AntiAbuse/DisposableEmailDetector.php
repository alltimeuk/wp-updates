<?php
/**
 * Detects disposable-email domains, per Section 5.6: "Disposable-email detection as a review
 * signal, not an infallible rejection rule."
 *
 * Uses a bundled, curated list of well-known disposable/temporary-email providers. The list is
 * deliberately conservative - it favours missing a provider over falsely flagging a legitimate
 * one, because the outcome is a review signal, never an automatic rejection. Operators can
 * extend coverage by adding a domain to the blocklist, and can allow-list a false positive.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse;

class DisposableEmailDetector {

	/**
	 * Well-known disposable/temporary-email domains. Lower-cased, no leading dot.
	 *
	 * @var string[]
	 */
	private const DISPOSABLE_DOMAINS = array(
		'0-mail.com',
		'0815.ru',
		'10minutemail.com',
		'20minutemail.com',
		'33mail.com',
		'anonaddy.com',
		'armyspy.com',
		'awdrt.org',
		'bestmail.us',
		'burnermail.io',
		'cuvox.de',
		'dayrep.com',
		'dispostable.com',
		'emailondeck.com',
		'einrot.com',
		'fakemail.net',
		'getairmail.com',
		'getnada.com',
		'guerrillamail.com',
		'guerrillamailblock.com',
		'hide-my-email.com',
		'hushmail.com',
		'inboxbear.com',
		'inboxkitten.com',
		'jetable.org',
		'jourrapide.com',
		'kuku.lu',
		'last-chance.pro',
		'maildrop.cc',
		'mailinator.com',
		'mailnesia.com',
		'mailnull.com',
		'mailtemp.net',
		'mintemail.com',
		'mohmal.com',
		'moakt.com',
		'mytemp.email',
		'nowmymail.com',
		'one-time.email',
		'owlymail.com',
		'pokemail.net',
		'reallymymail.com',
		'recipient.com',
		'sharklasers.com',
		'spam4.me',
		'spamgourmet.com',
		'temp-mail.com',
		'temp-mail.io',
		'temp-mail.net',
		'temp-mail.org',
		'temp-mail.top',
		'tempinbox.com',
		'tempmail.com',
		'tempmailo.com',
		'throwaway.email',
		'throwawaymail.com',
		'trashmail.com',
		'trashymail.com',
		'wegwerfmail.de',
		'wegwerfmail.net',
		'wegwerfmail.org',
		'yopmail.com',
		'yopmail.fr',
		'yuurok.com',
		'zehnminutenmail.de',
		'zoaxe.com',
	);

	/**
	 * Returns true when the email's domain is a known disposable-email provider.
	 */
	public function is_disposable( string $email ): bool {
		$domain = $this->extract_domain( $email );

		if ( '' === $domain ) {
			return false;
		}

		return in_array( $domain, self::DISPOSABLE_DOMAINS, true );
	}

	/**
	 * Extracts the lower-cased registrable-looking domain from an email address. Returns an
	 * empty string when the address has no usable domain part.
	 */
	private function extract_domain( string $email ): string {
		$email = strtolower( trim( $email ) );
		$at    = strrpos( $email, '@' );

		if ( false === $at || strlen( $email ) - 1 === $at ) {
			return '';
		}

		$domain = substr( $email, $at + 1 );

		return trim( $domain, " \t\n\r\0\x0B." );
	}
}
