<?php
/**
 * A single anti-abuse review signal, per Section 5.6's review-and-release queue.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse;

use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalState;
use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalType;

final class AbuseSignal {

	/**
	 * @param array<string,mixed> $context JSON-decoded context payload (names, organisation,
	 *                                     domain, IP, user id) needed to act on the signal.
	 */
	public function __construct(
		public readonly ?int $id,
		public readonly SignalType $type,
		public readonly string $subject_type,
		public readonly string $subject_value,
		public readonly string $severity,
		public readonly SignalState $state,
		public readonly array $context,
		public readonly ?int $reviewed_by,
		public readonly ?\DateTimeImmutable $reviewed_at,
		public readonly ?string $review_note,
		public readonly \DateTimeImmutable $created_at
	) {}

	public static function from_row( array $row ): self {
		$context = json_decode( (string) ( $row['context'] ?? '' ), true );

		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			type: SignalType::from( (string) $row['signal_type'] ),
			subject_type: (string) $row['subject_type'],
			subject_value: (string) $row['subject_value'],
			severity: (string) $row['severity'],
			state: SignalState::from( (string) $row['state'] ),
			context: is_array( $context ) ? $context : array(),
			reviewed_by: isset( $row['reviewed_by'] ) ? (int) $row['reviewed_by'] : null,
			reviewed_at: ! empty( $row['reviewed_at'] ) ? new \DateTimeImmutable( (string) $row['reviewed_at'] ) : null,
			review_note: $row['review_note'] ?? null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] )
		);
	}
}
