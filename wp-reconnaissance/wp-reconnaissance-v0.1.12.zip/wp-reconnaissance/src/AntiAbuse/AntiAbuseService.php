<?php
/**
 * Orchestrates the layered anti-abuse controls for registration and free assessments, per
 * Section 5.6: block/allow lists, disposable-email detection, duplicate-domain signals, a
 * maximum-queued-jobs throttle, a configurable bot-challenge adapter, an administrative
 * review-and-release queue, and audit events for automated and manual eligibility decisions.
 *
 * The evaluation never discloses detection logic to a customer - callers translate the verdict
 * into a generic message.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse;

use Alltime\WPReconnaissance\AntiAbuse\Captcha\CaptchaAdapterInterface;
use Alltime\WPReconnaissance\AntiAbuse\Captcha\HoneypotCaptchaAdapter;
use Alltime\WPReconnaissance\AntiAbuse\Captcha\NoopCaptchaAdapter;
use Alltime\WPReconnaissance\AntiAbuse\Enums\AbuseVerdict;
use Alltime\WPReconnaissance\AntiAbuse\Enums\ListType;
use Alltime\WPReconnaissance\AntiAbuse\Enums\MatchType;
use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalState;
use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalType;
use Alltime\WPReconnaissance\AntiAbuse\Repositories\AbuseSignalRepository;
use Alltime\WPReconnaissance\AntiAbuse\Repositories\BlockListRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class AntiAbuseService {

	private ?CaptchaAdapterInterface $captcha;

	public function __construct(
		private readonly BlockListRepository $blocklist = new BlockListRepository(),
		private readonly AbuseSignalRepository $signals = new AbuseSignalRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly DisposableEmailDetector $disposable = new DisposableEmailDetector(),
		private readonly JobThrottle $job_throttle = new JobThrottle(),
		?CaptchaAdapterInterface $captcha = null,
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {
		$this->captcha = $captcha;
	}

	/**
	 * Resolves the configured bot-challenge adapter from the anti-abuse settings, lazily so the
	 * constructor has no WordPress dependency (unit tests construct the service without WP
	 * loaded). When the honeypot challenge is enabled the zero-dependency adapter is used;
	 * otherwise a no-op adapter leaves the flow unchanged until an operator enables one.
	 */
	private function captcha(): CaptchaAdapterInterface {
		if ( null === $this->captcha ) {
			$this->captcha = (bool) get_option( 'wpr_abuse_captcha_enabled', false )
				? new HoneypotCaptchaAdapter( true, (int) get_option( 'wpr_abuse_min_form_seconds', 3 ) )
				: new NoopCaptchaAdapter();
		}

		return $this->captcha;
	}

	/**
	 * Evaluates a registration attempt and returns a verdict. Review signals are persisted to the
	 * review queue; block verdicts are audit-logged only (there is no account to release).
	 */
	public function evaluate_registration( RegistrationContext $context, int $max_queued_jobs ): AbuseDecision {
		$reasons = array();

		// Hard blocklist checks - an allow-list entry for the same subject overrides a block.
		if ( $this->blocklist->is_blocked( MatchType::Email, strtolower( $context->email ) ) ) {
			$reasons[] = 'blocked_email';
		}

		if ( $this->blocklist->is_blocked( MatchType::Domain, strtolower( $context->registrable_domain ) ) ) {
			$reasons[] = 'blocked_domain';
		}

		if ( $this->blocklist->is_blocked( MatchType::Ip, $context->ip ) ) {
			$reasons[] = 'blocked_ip';
		}

		if ( count( $reasons ) > 0 ) {
			$this->audit_logger->log(
				'abuse.registration_blocked',
				'registration',
				0,
				0,
				'blocked',
				wp_json_encode(
					array(
						'reasons' => $reasons,
						'ip'      => $context->ip,
					)
				)
			);

			return new AbuseDecision( AbuseVerdict::Block, $reasons );
		}

		// Bot-challenge check - a failed challenge is a hard block.
		if ( ! $this->captcha()->verify( $context->captcha_input, $context->ip ) ) {
			$this->audit_logger->log( 'abuse.captcha_failed', 'registration', 0, 0, 'blocked', wp_json_encode( array( 'ip' => $context->ip ) ) );

			return new AbuseDecision( AbuseVerdict::Block, array( 'captcha_failed' ) );
		}

		// Review signals - each is a review signal, not an infallible rejection.
		$review_reasons = array();

		if ( $this->disposable->is_disposable( $context->email ) ) {
			$this->signals->create(
				SignalType::DisposableEmail,
				'email',
				strtolower( $context->email ),
				'review',
				array(
					'registrable_domain' => $context->registrable_domain,
					'ip'                 => $context->ip,
				)
			);
			$review_reasons[] = 'disposable_email';
		}

		if ( $this->scopes->count_by_registrable_domain( $context->registrable_domain ) > 0 ) {
			$this->signals->create(
				SignalType::DuplicateDomain,
				'domain',
				strtolower( $context->registrable_domain ),
				'review',
				array(
					'email' => $context->email,
					'ip'    => $context->ip,
				)
			);
			$review_reasons[] = 'duplicate_domain';
		}

		if ( $this->job_throttle->is_throttled( $max_queued_jobs ) ) {
			$this->signals->create(
				SignalType::MaxQueuedJobs,
				'domain',
				strtolower( $context->registrable_domain ),
				'review',
				array(
					'email' => $context->email,
					'ip'    => $context->ip,
				)
			);
			$review_reasons[] = 'max_queued_jobs';
		}

		if ( count( $review_reasons ) > 0 ) {
			$this->audit_logger->log(
				'abuse.registration_flagged_review',
				'registration',
				0,
				0,
				'review',
				wp_json_encode(
					array(
						'reasons' => $review_reasons,
						'ip'      => $context->ip,
					)
				)
			);

			return new AbuseDecision( AbuseVerdict::Review, $review_reasons );
		}

		return new AbuseDecision( AbuseVerdict::Allow, array() );
	}

	/**
	 * Whether the account's email or registrable domain has an open review signal - the gate that
	 * holds a free assessment until an operator releases it.
	 */
	public function has_open_review( string $email, string $registrable_domain ): bool {
		return $this->signals->has_open_for_subject( 'email', strtolower( $email ) )
			|| $this->signals->has_open_for_subject( 'domain', strtolower( $registrable_domain ) );
	}

	/**
	 * Operator review actions. Each returns the updated signal and records a manual eligibility
	 * decision in the audit log.
	 */
	public function release_signal( int $signal_id, int $reviewed_by, ?string $note = null ): AbuseSignal {
		$signal = $this->signals->review( $signal_id, SignalState::Released, $reviewed_by, $note );
		$this->audit_logger->log( 'abuse.signal_released', 'abuse_signal', $signal_id, $reviewed_by, 'released', wp_json_encode( array( 'type' => $signal->type->value ) ) );

		return $signal;
	}

	public function dismiss_signal( int $signal_id, int $reviewed_by, ?string $note = null ): AbuseSignal {
		$signal = $this->signals->review( $signal_id, SignalState::Dismissed, $reviewed_by, $note );
		$this->audit_logger->log( 'abuse.signal_dismissed', 'abuse_signal', $signal_id, $reviewed_by, 'dismissed', wp_json_encode( array( 'type' => $signal->type->value ) ) );

		return $signal;
	}

	/**
	 * Blocks the signal's subject and marks the signal blocked. The subject is added to the
	 * blocklist so future attempts are rejected outright.
	 */
	public function block_signal( int $signal_id, int $reviewed_by, ?string $note = null ): AbuseSignal {
		$signal = $this->signals->find( $signal_id );

		if ( null === $signal ) {
			throw new \RuntimeException( esc_html( "Abuse signal {$signal_id} could not be loaded." ) );
		}

		$match_type = match ( $signal->subject_type ) {
			'email'  => MatchType::Email,
			'domain' => MatchType::Domain,
			'ip'     => MatchType::Ip,
			default  => MatchType::Email,
		};

		$this->blocklist->add( ListType::Block, $match_type, $signal->subject_value, $note, $reviewed_by );
		$updated = $this->signals->review( $signal_id, SignalState::Blocked, $reviewed_by, $note );
		$this->audit_logger->log(
			'abuse.signal_blocked',
			'abuse_signal',
			$signal_id,
			$reviewed_by,
			'blocked',
			wp_json_encode(
				array(
					'type'    => $signal->type->value,
					'subject' => $signal->subject_value,
				)
			)
		);

		return $updated;
	}

	public function add_blocklist_entry( ListType $list_type, MatchType $match_type, string $value, ?string $reason, ?int $created_by, ?\DateTimeImmutable $expires_at = null ): BlockListEntry {
		$entry = $this->blocklist->add( $list_type, $match_type, strtolower( $value ), $reason, $created_by, $expires_at );
		$this->audit_logger->log(
			'abuse.blocklist_added',
			'blocklist',
			$entry->id ?? 0,
			$created_by,
			'added',
			wp_json_encode(
				array(
					'list_type'  => $list_type->value,
					'match_type' => $match_type->value,
					'value'      => $entry->value,
				)
			)
		);

		return $entry;
	}

	public function remove_blocklist_entry( int $entry_id, int $actor_id ): void {
		$this->blocklist->remove( $entry_id );
		$this->audit_logger->log( 'abuse.blocklist_removed', 'blocklist', $entry_id, $actor_id );
	}

	/**
	 * @return array{items: AbuseSignal[], total: int}
	 */
	public function list_open_signals( int $per_page = 20, int $page = 1 ): array {
		return $this->signals->list_open( $per_page, $page );
	}

	/**
	 * @return BlockListEntry[]
	 */
	public function list_blocklist( int $per_page = 50, int $page = 1 ): array {
		return $this->blocklist->list_all( $per_page, $page );
	}
}
