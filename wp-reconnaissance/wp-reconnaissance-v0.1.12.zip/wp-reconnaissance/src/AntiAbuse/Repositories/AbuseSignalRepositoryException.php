<?php
/**
 * Thrown when a repository write against `wpr_abuse_signals` genuinely fails at the database
 * level.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Repositories;

final class AbuseSignalRepositoryException extends \RuntimeException {}
