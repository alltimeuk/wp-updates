<?php
/**
 * Persistence for the anti-abuse review queue against `wpr_abuse_signals`, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Repositories;

use Alltime\WPReconnaissance\AntiAbuse\AbuseSignal;
use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalState;
use Alltime\WPReconnaissance\AntiAbuse\Enums\SignalType;
use Alltime\WPReconnaissance\Data\Schema;

class AbuseSignalRepository {

	public function find( int $id ): ?AbuseSignal {
		global $wpdb;

		$table = Schema::table( 'abuse_signals' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? AbuseSignal::from_row( $row ) : null;
	}

	/**
	 * Open signals awaiting operator review, newest first - the admin review-and-release queue.
	 *
	 * @return array{items: AbuseSignal[], total: int}
	 */
	public function list_open( int $per_page, int $page ): array {
		global $wpdb;

		$table  = Schema::table( 'abuse_signals' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE state = %s ORDER BY id DESC LIMIT %d OFFSET %d", SignalState::Open->value, $per_page, $offset ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE state = %s", SignalState::Open->value ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array(
			'items' => array_map( array( AbuseSignal::class, 'from_row' ), null !== $rows ? $rows : array() ),
			'total' => $total,
		);
	}

	/**
	 * Whether any open review signal exists for the given subject - the gate that holds a free
	 * assessment until an operator releases it.
	 */
	public function has_open_for_subject( string $subject_type, string $subject_value ): bool {
		global $wpdb;

		$table = Schema::table( 'abuse_signals' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE subject_type = %s AND subject_value = %s AND state = %s", $subject_type, $subject_value, SignalState::Open->value ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $count > 0;
	}

	/**
	 * Records a new open signal. Returns the persisted signal.
	 *
	 * @param array<string,mixed> $context JSON-encodable context payload.
	 */
	public function create( SignalType $type, string $subject_type, string $subject_value, string $severity, array $context ): AbuseSignal {
		global $wpdb;

		$table = Schema::table( 'abuse_signals' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'signal_type'   => $type->value,
				'subject_type'  => $subject_type,
				'subject_value' => $subject_value,
				'severity'      => $severity,
				'state'         => SignalState::Open->value,
				'context'       => wp_json_encode( $context ),
				'created_at'    => $now,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Transitions a signal to a terminal state as part of an operator review decision.
	 */
	public function review( int $id, SignalState $state, int $reviewed_by, ?string $note = null ): AbuseSignal {
		global $wpdb;

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			Schema::table( 'abuse_signals' ),
			array(
				'state'       => $state->value,
				'reviewed_by' => $reviewed_by,
				'reviewed_at' => current_time( 'mysql', true ),
				'review_note' => null !== $note && '' !== $note ? $note : null,
			),
			array( 'id' => $id )
		);

		if ( false === $updated ) {
			throw new AbuseSignalRepositoryException( esc_html( "Failed to record a review decision for abuse signal {$id}." ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- esc_html() is applied to the interpolated message above.
		}

		return $this->find_or_fail( $id );
	}

	private function find_or_fail( int $id ): AbuseSignal {
		$signal = $this->find( $id );

		if ( null === $signal ) {
			throw new \RuntimeException( esc_html( "Abuse signal {$id} was expected to exist but could not be loaded." ) );
		}

		return $signal;
	}
}
