<?php
/**
 * Persistence for the block/allow list against `wpr_blocklist`, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse\Repositories;

use Alltime\WPReconnaissance\AntiAbuse\BlockListEntry;
use Alltime\WPReconnaissance\AntiAbuse\Enums\ListType;
use Alltime\WPReconnaissance\AntiAbuse\Enums\MatchType;
use Alltime\WPReconnaissance\Data\Schema;

class BlockListRepository {

	/**
	 * Whether the given subject is blocked, honouring allow-list overrides and expiries.
	 * An `allow` entry for the same match_type/value overrides a `block`; an expired entry is
	 * treated as absent.
	 */
	public function is_blocked( MatchType $match_type, string $value ): bool {
		global $wpdb;

		$table = Schema::table( 'blocklist' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT list_type FROM `{$table}` WHERE match_type = %s AND value = %s AND (expires_at IS NULL OR expires_at > %s)", $match_type->value, $value, $now ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$blocked = false;

		foreach ( null !== $rows ? $rows : array() as $row ) {
			if ( ListType::Allow->value === $row['list_type'] ) {
				return false;
			}

			if ( ListType::Block->value === $row['list_type'] ) {
				$blocked = true;
			}
		}

		return $blocked;
	}

	/**
	 * @return BlockListEntry[] Newest first.
	 */
	public function list_all( int $per_page, int $page ): array {
		global $wpdb;

		$table  = Schema::table( 'blocklist' );
		$offset = max( 0, ( $page - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array_map( array( BlockListEntry::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function add( ListType $list_type, MatchType $match_type, string $value, ?string $reason, ?int $created_by, ?\DateTimeImmutable $expires_at = null ): BlockListEntry {
		global $wpdb;

		$table = Schema::table( 'blocklist' );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'list_type'  => $list_type->value,
				'match_type' => $match_type->value,
				'value'      => $value,
				'reason'     => null !== $reason && '' !== $reason ? $reason : null,
				'created_by' => $created_by,
				'created_at' => current_time( 'mysql', true ),
				'expires_at' => null !== $expires_at ? $expires_at->format( 'Y-m-d H:i:s' ) : null,
			)
		);

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function remove( int $id ): void {
		global $wpdb;

		$wpdb->delete( Schema::table( 'blocklist' ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	private function find_or_fail( int $id ): BlockListEntry {
		global $wpdb;

		$table = Schema::table( 'blocklist' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( null === $row ) {
			throw new \RuntimeException( esc_html( "Blocklist entry {$id} was expected to exist but could not be loaded." ) );
		}

		return BlockListEntry::from_row( $row );
	}
}
