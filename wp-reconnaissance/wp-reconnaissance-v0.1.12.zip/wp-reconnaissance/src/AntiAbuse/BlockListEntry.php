<?php
/**
 * A single block/allow list entry, per Section 5.6.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\AntiAbuse;

use Alltime\WPReconnaissance\AntiAbuse\Enums\ListType;
use Alltime\WPReconnaissance\AntiAbuse\Enums\MatchType;

final class BlockListEntry {

	public function __construct(
		public readonly ?int $id,
		public readonly ListType $list_type,
		public readonly MatchType $match_type,
		public readonly string $value,
		public readonly ?string $reason,
		public readonly ?int $created_by,
		public readonly \DateTimeImmutable $created_at,
		public readonly ?\DateTimeImmutable $expires_at
	) {}

	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			list_type: ListType::from( (string) $row['list_type'] ),
			match_type: MatchType::from( (string) $row['match_type'] ),
			value: (string) $row['value'],
			reason: $row['reason'] ?? null,
			created_by: isset( $row['created_by'] ) ? (int) $row['created_by'] : null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			expires_at: ! empty( $row['expires_at'] ) ? new \DateTimeImmutable( (string) $row['expires_at'] ) : null
		);
	}
}
