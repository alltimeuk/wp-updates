<?php
/**
 * Pure entitlement decision logic, per Section 5.5. Deliberately separate from
 * {@see EntitlementService} (which does the actual database reads/writes) so the decision itself
 * is fully unit-tested without a database: given a contact's entitlement history for one
 * tool/domain, is a new run currently allowed, and if not, when will it be?
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Entitlements\Enums\EntitlementState;

final class EntitlementPolicy {

	/**
	 * @param Entitlement[] $history Every entitlement row for this contact/tool/domain, most
	 *                                 recent first. Empty means never used before.
	 */
	public function decide( array $history, bool $is_exempt, int $rerun_interval_days, ?\DateTimeImmutable $now = null ): EntitlementDecision {
		$now = $now ?? new \DateTimeImmutable();

		if ( $is_exempt ) {
			return new EntitlementDecision( true, 'exempt_account' );
		}

		$active_grant = $this->find_active_administrative_grant( $history, $now );

		if ( null !== $active_grant ) {
			return new EntitlementDecision( true, 'administratively_granted', $active_grant );
		}

		$open_reservation = $this->find_open_reservation( $history );

		if ( null !== $open_reservation ) {
			return new EntitlementDecision( false, 'reservation_in_progress', $open_reservation );
		}

		$last_consumed = $this->find_last_consumed( $history );

		if ( null === $last_consumed ) {
			return new EntitlementDecision( true, 'first_free_use' );
		}

		$next_eligible_at = $last_consumed->consumed_at?->modify( "+{$rerun_interval_days} days" );

		if ( null !== $next_eligible_at && $now >= $next_eligible_at ) {
			return new EntitlementDecision( true, 'rerun_interval_elapsed', $last_consumed );
		}

		return new EntitlementDecision( false, 'free_report_already_consumed', $last_consumed, $next_eligible_at );
	}

	/**
	 * @param Entitlement[] $history
	 */
	private function find_active_administrative_grant( array $history, \DateTimeImmutable $now ): ?Entitlement {
		foreach ( $history as $entitlement ) {
			if ( EntitlementState::AdministrativelyGranted !== $entitlement->state ) {
				continue;
			}

			if ( null !== $entitlement->expires_at && $now > $entitlement->expires_at ) {
				continue;
			}

			return $entitlement;
		}

		return null;
	}

	/**
	 * @param Entitlement[] $history
	 */
	private function find_open_reservation( array $history ): ?Entitlement {
		foreach ( $history as $entitlement ) {
			if ( EntitlementState::Reserved === $entitlement->state ) {
				return $entitlement;
			}
		}

		return null;
	}

	/**
	 * @param Entitlement[] $history
	 */
	private function find_last_consumed( array $history ): ?Entitlement {
		foreach ( $history as $entitlement ) {
			if ( EntitlementState::Consumed === $entitlement->state ) {
				return $entitlement;
			}
		}

		return null;
	}
}
