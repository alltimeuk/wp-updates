<?php
/**
 * Entitlement lifecycle state, per Section 5.5: "A clear state for available, reserved,
 * consumed, expired, revoked and administratively granted entitlements."
 *
 * "Available" has no row of its own - the absence of any entitlement record for a
 * contact/tool/domain combination *is* the available state (Section 5.5's default: "One free
 * completed report per verified account and registrable domain by default"). Every other state
 * is represented by a row.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements\Enums;

enum EntitlementState: string {
	case Reserved                = 'reserved';
	case Consumed                = 'consumed';
	case Expired                 = 'expired';
	case Revoked                 = 'revoked';
	case AdministrativelyGranted = 'administratively_granted';
}
