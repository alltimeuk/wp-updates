<?php
/**
 * Thrown when an action would exceed a managed plan's limit (Section 33).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

final class PlanLimitException extends \RuntimeException {}
