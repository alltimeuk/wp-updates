<?php
/**
 * Thrown when a repository write against `wpr_entitlements` genuinely fails at the database
 * level - a failed {@see EntitlementRepository::release()} permanently blocks re-entry for the
 * affected contact/tool/domain, and a failed {@see EntitlementRepository::revoke()} leaves access
 * live, so both must surface loudly rather than being silently discarded.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

final class EntitlementRepositoryException extends \RuntimeException {}
