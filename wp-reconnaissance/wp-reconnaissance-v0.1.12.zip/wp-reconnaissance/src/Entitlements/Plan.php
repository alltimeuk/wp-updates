<?php
/**
 * A managed entitlement plan, per Section 33 ("repeat, paid and managed-service entitlements").
 * Admin-assignable to an organisation; there is deliberately no payment/billing processing here -
 * `external_billing_reference` is a reserved slot for a future integration (a Stripe subscription
 * or customer ID, say) to write into without a later schema change, nothing in this codebase
 * reads or writes it yet.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Domain\Enums\ScheduleFrequency;

final class Plan {

	public function __construct(
		public readonly ?int $id,
		public readonly string $name,
		public readonly string $slug,
		public readonly ?int $max_active_scopes,
		public readonly ?int $rerun_interval_days,
		public readonly ?ScheduleFrequency $min_schedule_frequency,
		public readonly ?string $external_billing_reference,
		public readonly ?\DateTimeImmutable $created_at = null,
		public readonly ?\DateTimeImmutable $updated_at = null
	) {}

	/**
	 * @param array<string,mixed> $row Row as returned by $wpdb (associative, string values).
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			name: (string) $row['name'],
			slug: (string) $row['slug'],
			max_active_scopes: isset( $row['max_active_scopes'] ) ? (int) $row['max_active_scopes'] : null,
			rerun_interval_days: isset( $row['rerun_interval_days'] ) ? (int) $row['rerun_interval_days'] : null,
			min_schedule_frequency: ScheduleFrequency::from_nullable( $row['min_schedule_frequency'] ?? null ),
			external_billing_reference: $row['external_billing_reference'] ?? null,
			created_at: isset( $row['created_at'] ) ? new \DateTimeImmutable( (string) $row['created_at'] ) : null,
			updated_at: isset( $row['updated_at'] ) ? new \DateTimeImmutable( (string) $row['updated_at'] ) : null
		);
	}
}
