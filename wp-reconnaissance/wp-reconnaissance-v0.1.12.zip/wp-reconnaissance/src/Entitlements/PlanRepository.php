<?php
/**
 * Persistence for managed entitlement plans against `wpr_plans`, per Section 33.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Enums\ScheduleFrequency;

final class PlanRepository {

	public function find( int $id ): ?Plan {
		global $wpdb;

		$table = Schema::table( 'plans' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Plan::from_row( $row ) : null;
	}

	/**
	 * @return Plan[]
	 */
	public function list_all(): array {
		global $wpdb;

		$table = Schema::table( 'plans' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( "SELECT * FROM `{$table}` ORDER BY name ASC", ARRAY_A );

		return array_map( array( Plan::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function create(
		string $name,
		string $slug,
		?int $max_active_scopes,
		?int $rerun_interval_days,
		?ScheduleFrequency $min_schedule_frequency,
		?string $external_billing_reference
	): Plan {
		global $wpdb;

		$table = Schema::table( 'plans' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'name'                       => $name,
			'slug'                       => $slug,
			'max_active_scopes'          => $max_active_scopes,
			'rerun_interval_days'        => $rerun_interval_days,
			'min_schedule_frequency'     => $min_schedule_frequency?->value,
			'external_billing_reference' => $external_billing_reference,
			'created_at'                 => $now,
			'updated_at'                 => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	public function update(
		int $id,
		string $name,
		?int $max_active_scopes,
		?int $rerun_interval_days,
		?ScheduleFrequency $min_schedule_frequency,
		?string $external_billing_reference
	): Plan {
		global $wpdb;

		$table = Schema::table( 'plans' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'name'                       => $name,
				'max_active_scopes'          => $max_active_scopes,
				'rerun_interval_days'        => $rerun_interval_days,
				'min_schedule_frequency'     => $min_schedule_frequency?->value,
				'external_billing_reference' => $external_billing_reference,
				'updated_at'                 => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		return $this->find_or_fail( $id );
	}

	/**
	 * Derives a unique slug from a plan name, appending a numeric suffix on collision - mirrors
	 * {@see \Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository::unique_slug()}.
	 */
	public function unique_slug( string $name ): string {
		$base   = sanitize_title( $name );
		$base   = '' !== $base ? $base : 'plan';
		$slug   = $base;
		$suffix = 2;

		while ( null !== $this->find_by_slug( $slug ) ) {
			$slug = "{$base}-{$suffix}";
			++$suffix;
		}

		return $slug;
	}

	private function find_by_slug( string $slug ): ?Plan {
		global $wpdb;

		$table = Schema::table( 'plans' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE slug = %s", $slug ), ARRAY_A );

		return null !== $row ? Plan::from_row( $row ) : null;
	}

	private function find_or_fail( int $id ): Plan {
		$plan = $this->find( $id );

		if ( null === $plan ) {
			throw new \RuntimeException( esc_html( "Plan {$id} was expected to exist but could not be loaded." ) );
		}

		return $plan;
	}
}
