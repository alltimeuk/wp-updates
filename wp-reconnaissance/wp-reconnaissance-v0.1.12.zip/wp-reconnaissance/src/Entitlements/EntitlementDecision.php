<?php
/**
 * The result of {@see EntitlementPolicy::decide()}.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

final class EntitlementDecision {

	public function __construct(
		public readonly bool $allowed,
		public readonly string $reason,
		public readonly ?Entitlement $existing = null,
		public readonly ?\DateTimeImmutable $next_eligible_at = null
	) {}
}
