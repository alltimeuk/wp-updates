<?php
/**
 * Resolves an open entitlement reservation once its job finishes, per Section 5.5: "Do not
 * consume the entitlement for a validation failure or a job that produces no usable assessment
 * because of an internal system failure."
 *
 * Listens to the same plain `wpr_job_completed` hook {@see
 * \Alltime\WPReconnaissance\Notifications\NotificationDispatcher} does - this is just another
 * subscriber, not a special case. A job with no actor, or whose actor cannot be resolved to a
 * Customer Platform contact (an operator-dispatched run, for example), is silently ignored: only
 * {@see \Alltime\WPReconnaissance\Auth\FreeAssessmentService}'s self-service reservations are ever
 * found here, since only it ever creates one.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Enums\JobStatus;
use Alltime\WPReconnaissance\Support\AuditLogger;
use Alltime\WPReconnaissance\Tools\ToolsBootstrap;

final class EntitlementFulfillment {

	public function __construct(
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly EntitlementRepository $entitlements = new EntitlementRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	public function boot(): void {
		add_action( 'wpr_job_completed', array( $this, 'on_job_completed' ) );
	}

	/**
	 * A broken listener must never take down the `wpr_job_completed` action's firer (whichever
	 * code path that turns out to be - direct dispatch, cron sweep, WP-CLI) - genuine database
	 * failures resolving the reservation are logged and swallowed here rather than propagated.
	 */
	public function on_job_completed( int $job_id ): void {
		try {
			$this->resolve_reservation( $job_id );
		} catch ( EntitlementRepositoryException $exception ) {
			$this->audit_logger->log( 'entitlement.fulfillment_failed', 'job', $job_id, null, outcome: 'failure', summary: $exception->getMessage(), source: 'cron' );
		}
	}

	private function resolve_reservation( int $job_id ): void {
		$job = $this->jobs->find( $job_id );

		if ( null === $job || null === $job->actor_id ) {
			return;
		}

		$scope = $this->scopes->find( $job->scope_id );

		if ( null === $scope ) {
			return;
		}

		$contact = ContactPlatformDiscovery::resolve()?->get_contact_for_user( $job->actor_id );

		if ( null === $contact ) {
			return;
		}

		$reservation = $this->entitlements->find_open_reservation( $contact->id, ToolsBootstrap::DOMAIN_RECONNAISSANCE_TOOL_ID, $scope->registrable_domain );

		if ( null === $reservation || null === $reservation->id ) {
			return;
		}

		if ( self::job_produced_usable_assessment( $job->status ) ) {
			$this->entitlements->consume( $reservation->id );
		} else {
			$this->entitlements->release( $reservation->id );
		}
	}

	/**
	 * Pure and public so it can be exercised directly by tests without a database - Section 5.5:
	 * only a job that actually produced usable evidence should consume the free-use entitlement.
	 */
	public static function job_produced_usable_assessment( JobStatus $status ): bool {
		return in_array( $status, array( JobStatus::Succeeded, JobStatus::PartiallySucceeded ), true );
	}
}
