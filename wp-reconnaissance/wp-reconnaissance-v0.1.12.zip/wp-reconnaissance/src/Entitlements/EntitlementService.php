<?php
/**
 * Entitlement service, per Section 5.5 and Section 6.1.1 ("Entitlement service" - a shared
 * platform service, kept inside WP Reconnaissance for now like the Customer Platform contact
 * service, and designed the same way: pure decision logic in {@see EntitlementPolicy}, I/O here.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;

final class EntitlementService {

	private const DEFAULT_RERUN_INTERVAL_DAYS = 30;

	public function __construct(
		private readonly EntitlementRepository $entitlements = new EntitlementRepository(),
		private readonly EntitlementPolicy $policy = new EntitlementPolicy(),
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly PlanRepository $plans = new PlanRepository()
	) {}

	/**
	 * Whether $contact_id may start a new $tool_id run against $registrable_domain right now.
	 * $is_exempt covers Section 5.5's "test and internal accounts excluded from public limits" -
	 * the caller decides exemption (today: any account holding an operator capability), this
	 * service only applies the resulting policy. `$organisation_id`, when given, lets a managed
	 * plan's own `rerun_interval_days` (Section 33) override the system-wide default; an
	 * organisation with no plan, or a plan that leaves the interval unset, falls back to it
	 * exactly as before.
	 */
	public function check( int $contact_id, string $tool_id, string $registrable_domain, bool $is_exempt = false, ?int $organisation_id = null ): EntitlementDecision {
		$history  = $this->entitlements->find_history( $contact_id, $tool_id, $registrable_domain );
		$interval = $this->rerun_interval_days( $organisation_id );

		return $this->policy->decide( $history, $is_exempt, $interval );
	}

	private function rerun_interval_days( ?int $organisation_id ): int {
		$default = max( 0, (int) get_option( 'wpr_entitlement_rerun_interval_days', self::DEFAULT_RERUN_INTERVAL_DAYS ) );

		if ( null === $organisation_id ) {
			return $default;
		}

		$plan_id = $this->organisations->find( $organisation_id )?->plan_id;

		if ( null === $plan_id ) {
			return $default;
		}

		return $this->plans->find( $plan_id )?->rerun_interval_days ?? $default;
	}

	/**
	 * Claims the entitlement before a job is dispatched. Callers must {@see consume()} on
	 * success or {@see release()} on failure - never leave a reservation dangling.
	 */
	public function reserve( int $contact_id, string $tool_id, string $registrable_domain ): Entitlement {
		return $this->entitlements->reserve( $contact_id, $tool_id, $registrable_domain );
	}

	public function consume( int $entitlement_id ): Entitlement {
		return $this->entitlements->consume( $entitlement_id );
	}

	public function release( int $entitlement_id ): void {
		$this->entitlements->release( $entitlement_id );
	}

	public function grant( int $contact_id, string $tool_id, string $registrable_domain, int $granted_by, ?string $reason = null, ?\DateTimeImmutable $expires_at = null ): Entitlement {
		return $this->entitlements->grant( $contact_id, $tool_id, $registrable_domain, $granted_by, $reason, $expires_at );
	}

	public function revoke( int $entitlement_id ): Entitlement {
		return $this->entitlements->revoke( $entitlement_id );
	}
}
