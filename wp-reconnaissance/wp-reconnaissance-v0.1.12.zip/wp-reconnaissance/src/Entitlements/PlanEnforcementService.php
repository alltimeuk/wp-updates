<?php
/**
 * Enforces a managed plan's limits (Section 33 "repeat, paid and managed-service entitlements")
 * at the points they actually matter - an organisation with no assigned plan is unrestricted,
 * exactly like today.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;

final class PlanEnforcementService {

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly PlanRepository $plans = new PlanRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository()
	) {}

	/**
	 * A scope only ever counts against a plan's `max_active_scopes` once it is authorised
	 * (status `active`) - a customer may still request/create as many pending scopes as they
	 * like, since nothing runs against them until an operator authorises one. This is therefore
	 * checked at authorisation time, not creation time.
	 *
	 * A plain, unlocked check - useful on its own for a fast pre-flight or a UI hint, but two
	 * concurrent callers can both pass it before either's write commits. Anything that goes on to
	 * actually authorise a scope off the back of this check should use
	 * {@see authorise_within_plan_limit()} instead, which closes that race.
	 *
	 * @throws PlanLimitException When authorising this scope would exceed the organisation's plan.
	 */
	public function assert_can_authorise_scope( int $organisation_id ): void {
		$plan = $this->plan_for_organisation( $organisation_id );

		if ( null === $plan || null === $plan->max_active_scopes ) {
			return;
		}

		if ( $this->scopes->count_active_by_organisation( $organisation_id ) >= $plan->max_active_scopes ) {
			throw $this->limit_exception( $plan->max_active_scopes ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- limit_exception() already wraps its message in esc_html(); the sniff can't see through the indirection.
		}
	}

	/**
	 * Atomically checks the plan limit and performs the caller-supplied authorisation write in
	 * one transaction, locking the organisation row ({@see \Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository::find_for_update()})
	 * for its duration - closing the race where two concurrent authorisations for different
	 * scopes of the same organisation could both pass the count check before either write
	 * commits. $write is the actual `ScopeRepository::authorise()`/`verify_and_authorise()` call
	 * the caller would otherwise have made separately, straight after its own now-removed
	 * `assert_can_authorise_scope()` call; its return value is passed straight through.
	 *
	 * `SELECT ... FOR UPDATE` is a confirmed silent no-op under the SQLite emulation this
	 * project's CI runs (the locking clause is stripped entirely, per that plugin's own source) -
	 * this method's check-and-write *logic* is what CI can verify (via a forced-sequential-call
	 * test, the same technique used elsewhere in this codebase for other atomicity fixes). Do not
	 * read a green CI run as proof the lock itself works - genuine concurrent-lock contention is
	 * verified separately, against real MariaDB/InnoDB, by
	 * `bin/verify-plan-enforcement-concurrency/run.sh` (not wired into CI; a pre-release gate to
	 * re-run before any release touching this method).
	 *
	 * @template T
	 * @param callable(): T $write
	 * @return T
	 * @throws \Throwable A PlanLimitException when authorising this scope would exceed the
	 *                     organisation's plan; otherwise, whatever $write itself throws (e.g.
	 *                     ScopeRepositoryException on a genuine database failure) is rolled back
	 *                     and re-thrown unmodified.
	 */
	public function authorise_within_plan_limit( int $organisation_id, callable $write ): mixed {
		global $wpdb;

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		try {
			$plan = $this->plan_for_organisation_locked( $organisation_id );

			if ( null !== $plan && null !== $plan->max_active_scopes
				&& $this->scopes->count_active_by_organisation( $organisation_id ) >= $plan->max_active_scopes ) {
				throw $this->limit_exception( $plan->max_active_scopes ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- limit_exception() already wraps its message in esc_html(); the sniff can't see through the indirection.
			}

			$result = $write();
		} catch ( \Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			throw $exception;
		}

		$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $result;
	}

	private function plan_for_organisation( int $organisation_id ): ?Plan {
		$plan_id = $this->organisations->find( $organisation_id )?->plan_id;

		return null !== $plan_id ? $this->plans->find( $plan_id ) : null;
	}

	private function plan_for_organisation_locked( int $organisation_id ): ?Plan {
		$plan_id = $this->organisations->find_for_update( $organisation_id )?->plan_id;

		return null !== $plan_id ? $this->plans->find( $plan_id ) : null;
	}

	private function limit_exception( int $max_active_scopes ): PlanLimitException {
		return new PlanLimitException(
			esc_html(
				sprintf(
					/* translators: %d: maximum active scopes the organisation's plan allows */
					__( 'This organisation\'s plan allows at most %d active scope(s). Authorising this one would exceed that limit.', 'wp-reconnaissance' ),
					$max_active_scopes
				)
			)
		);
	}
}
