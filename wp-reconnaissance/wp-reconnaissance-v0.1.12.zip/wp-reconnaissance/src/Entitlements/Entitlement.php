<?php
/**
 * An entitlement record, per Section 5.5.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Entitlements;

use Alltime\WPReconnaissance\Entitlements\Enums\EntitlementState;

final class Entitlement {

	public function __construct(
		public readonly ?int $id,
		public readonly int $contact_id,
		public readonly string $tool_id,
		public readonly string $registrable_domain,
		public readonly EntitlementState $state,
		public readonly ?\DateTimeImmutable $reserved_at,
		public readonly ?\DateTimeImmutable $consumed_at,
		public readonly ?\DateTimeImmutable $expires_at,
		public readonly ?int $granted_by,
		public readonly ?string $reason,
		public readonly \DateTimeImmutable $created_at,
		public readonly \DateTimeImmutable $updated_at
	) {}

	/**
	 * @param array<string,mixed> $row
	 */
	public static function from_row( array $row ): self {
		return new self(
			id: isset( $row['id'] ) ? (int) $row['id'] : null,
			contact_id: (int) $row['contact_id'],
			tool_id: (string) $row['tool_id'],
			registrable_domain: (string) $row['registrable_domain'],
			state: EntitlementState::from( (string) $row['state'] ),
			reserved_at: ! empty( $row['reserved_at'] ) ? new \DateTimeImmutable( (string) $row['reserved_at'] ) : null,
			consumed_at: ! empty( $row['consumed_at'] ) ? new \DateTimeImmutable( (string) $row['consumed_at'] ) : null,
			expires_at: ! empty( $row['expires_at'] ) ? new \DateTimeImmutable( (string) $row['expires_at'] ) : null,
			granted_by: isset( $row['granted_by'] ) && null !== $row['granted_by'] ? (int) $row['granted_by'] : null,
			reason: $row['reason'] ?? null,
			created_at: new \DateTimeImmutable( (string) $row['created_at'] ),
			updated_at: new \DateTimeImmutable( (string) $row['updated_at'] )
		);
	}
}
