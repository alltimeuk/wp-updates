<?php
/**
 * An optional capability of a Customer Platform provider, deliberately kept separate from
 * {@see ContactServiceInterface} rather than added to it directly.
 *
 * A new method on a PHP `interface` is a hard breaking change for every existing implementer -
 * unlike a versioned HTTP API, where an unrecognised endpoint can simply be ignored, PHP fatals
 * at class-declaration time ("Class X contains N abstract methods and must therefore be declared
 * abstract or implement the remaining methods") the moment any class anywhere declares
 * `implements ContactServiceInterface` without every one of its methods - before any of
 * {@see ContactPlatformDiscovery::resolve()}'s own runtime version-compatibility logic ever gets
 * a chance to run. This is exactly what happened when `delete_contact()` was added directly to
 * `ContactServiceInterface`: a sibling plugin's own provider implementation, which only expects
 * the original contract, fataled on load. `ContactServiceInterface` itself is unchanged from its
 * original shape as a result - every existing implementer, in this plugin or any other, stays
 * valid without modification.
 *
 * A provider that also supports this - currently only this plugin's own {@see ContactService} -
 * declares `implements ContactServiceInterface, ContactDeletionInterface`. A consumer that needs
 * the capability checks for it with `instanceof` after resolving the base provider, and degrades
 * gracefully (skips the deletion, or fails safely) when it is not present - exactly as
 * {@see ContactPlatformDiscovery::resolve()} already expects callers to degrade when no provider
 * is registered at all.
 *
 * @package Alltime\CustomerPlatform
 */

declare( strict_types = 1 );

namespace Alltime\CustomerPlatform;

interface ContactDeletionInterface {

	/**
	 * Permanently deletes a contact and every `atcp_*` row linked to it. Never called for any
	 * reason other than a deliberate, capability-controlled organisation purge - there is no
	 * "soft delete" or recovery path once this returns.
	 */
	public function delete_contact( int $contact_id ): void;
}
