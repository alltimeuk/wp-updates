<?php
/**
 * Queries crt.sh for certificates covering the apex and its subdomains, deterministically
 * deduplicating certificates and SAN entries (Section 12.1).
 *
 * Crt.sh's own `q=%.example.com` search matches a certificate the instant *any* of its logged
 * SAN entries ends with `.example.com` - on shared hosting, where each customer typically gets
 * their own individually issued, SNI-scoped certificate (not one certificate whose SAN list is
 * shared across customers), this alone doesn't pull in other customers' certificates. What it
 * does return, unfiltered until this collector processes it, is every certificate crt.sh has
 * ever logged that is genuinely related to the domain - including certificates for other
 * services/subdomains on the same account, and every historical reissuance, which on an
 * actively-renewed shared-hosting account can add up to dozens of entries. Certificates and SAN
 * names are kept only when at least one SAN entry is the registrable domain itself, a genuine
 * subdomain of it, or a wildcard covering it - {@see is_related_to_domain()}. A certificate that
 * fails this check (crt.sh returned it for a reason this collector cannot otherwise explain -
 * e.g. a CN/SAN mismatch in how crt.sh indexed it) is dropped entirely rather than partially
 * kept, and the count of dropped certificates is recorded rather than silently discarded.
 *
 * Crt.sh has no formal SLA and rate-limits aggressively; this collector treats a non-200
 * response or malformed JSON as rate_limited/failed rather than "no certificates found". A
 * single transient 502/timeout is retried once ({@see HttpClient::request_with_retry()}); a
 * persistent problem still surfaces as failed/timed_out rather than being retried indefinitely.
 * # TODO(12.1): add a local result cache and consider a second CT search provider for
 * redundancy.
 *
 * @package Alltime\WPReconnaissance
 */

declare(strict_types=1);

namespace Alltime\WPReconnaissance\Worker\Collectors;

use Alltime\WPReconnaissance\Domain\Enums\CollectorStatus;
use Alltime\WPReconnaissance\Worker\Evidence\CollectorResult;
use Alltime\WPReconnaissance\Worker\ScopeContext;
use Alltime\WPReconnaissance\Worker\Support\HttpClient;

final class CertificateTransparencyCollector extends AbstractCollector {
    public function key(): string {
        return 'ct';
    }

    protected function run( ScopeContext $context, float $started ): CollectorResult {
        $timeout = $context->timeout_for($this->key(), 30);

        try {
            $response = HttpClient::request_with_retry(
                'GET',
                'https://crt.sh/?q=%25.' . $context->registrable_domain . '&output=json',
                [],
                $timeout
            );
        } catch (\Throwable $exception) {
            return $this->result(
                HttpClient::is_timeout_error($exception) ? CollectorStatus::TimedOut : CollectorStatus::Failed,
                $started,
                'crt.sh',
                errors: [ $exception->getMessage() ]
            );
        }

        if (429 === $response->status) {
            return $this->result(CollectorStatus::RateLimited, $started, 'crt.sh', errors: [ 'crt.sh rate-limited this request.' ]);
        }

        $entries = json_decode($response->body, true);

        if (! is_array($entries)) {
            return $this->result(CollectorStatus::Failed, $started, 'crt.sh', errors: [ 'crt.sh response could not be parsed as JSON.' ]);
        }

        $data = self::filter_and_deduplicate($entries, $context->registrable_domain);

        return $this->result(CollectorStatus::Succeeded, $started, 'crt.sh', $data);
    }

    /**
     * Deduplicates crt.sh's raw entries into one row per certificate (keyed on
     * issuer_ca_id|serial_number, since crt.sh logs the same certificate once per CT log it
     * appears in) and filters both certificates and their SAN lists down to what's actually
     * related to the domain being assessed - see the class docblock for why this is needed at
     * all. Pure and side-effect-free (no HTTP, no collector state) so it can be exercised
     * directly against hand-built crt.sh-shaped fixtures.
     *
     * @param array<int,array<string,mixed>> $entries Raw crt.sh JSON rows.
     * @return array{certificates:array<int,array{id:mixed,serial_number:mixed,issuer_name:mixed,common_name:mixed,not_before:mixed,not_after:mixed,san_entries:string[]}>,discovered_names:string[],unrelated_certificate_count:int}
     */
    public static function filter_and_deduplicate( array $entries, string $registrable_domain ): array {
        $registrable_domain          = strtolower($registrable_domain);
        $deduped_certificates        = [];
        $discovered_names            = [];
        $unrelated_certificate_count = 0;

        foreach ($entries as $entry) {
            $dedup_key = ( $entry['issuer_ca_id'] ?? '' ) . '|' . ( $entry['serial_number'] ?? '' );

            if (isset($deduped_certificates[ $dedup_key ])) {
                continue;
            }

            $names = [];
            foreach (explode("\n", (string) ( $entry['name_value'] ?? '' )) as $name) {
                $normalised = strtolower(trim($name));

                if ('' !== $normalised) {
                    $names[ $normalised ] = true;
                }
            }

            $related_names = array_values(array_filter(
                array_keys($names),
                static fn ( string $name ): bool => self::is_related_to_domain($name, $registrable_domain)
            ));

            if ([] === $related_names) {
                // crt.sh returned this certificate for the query, but none of its own SAN
                // entries actually relate to the domain being assessed - e.g. a CN/SAN mismatch
                // in how crt.sh indexed it. Dropped wholesale rather than kept with an empty or
                // misleading SAN list.
                ++$unrelated_certificate_count;
                continue;
            }

            $deduped_certificates[ $dedup_key ] = [
                'id'             => $entry['id'] ?? null,
                'serial_number'  => $entry['serial_number'] ?? null,
                'issuer_name'    => $entry['issuer_name'] ?? null,
                'common_name'    => $entry['common_name'] ?? null,
                'not_before'     => $entry['not_before'] ?? null,
                'not_after'      => $entry['not_after'] ?? null,
                'san_entries' => $related_names,
            ];

            foreach ($related_names as $name) {
                $discovered_names[ $name ] = true;
            }
        }

        usort($deduped_certificates, static fn ( array $a, array $b ): int => strcmp((string) ( $b['not_before'] ?? '' ), (string) ( $a['not_before'] ?? '' )));

        return [
            'certificates'                => array_values($deduped_certificates),
            'discovered_names'            => array_keys($discovered_names),
            'unrelated_certificate_count' => $unrelated_certificate_count,
        ];
    }

    /**
     * Whether a certificate SAN/CN entry actually relates to the domain being assessed - an
     * exact match, a genuine subdomain, or a wildcard covering either. Deliberately does not
     * treat "shares a suffix" as related in the other direction: a SAN for `example.com` is not
     * related to a scope for `sub.example.com` (the certificate wasn't issued to cover that
     * subdomain specifically), matching the same directionality {@see AssetChangeDetector} and
     * the domain-verification flow already apply elsewhere in this codebase.
     */
    private static function is_related_to_domain( string $name, string $registrable_domain ): bool {
        if (str_starts_with($name, '*.')) {
            $name = substr($name, 2);
        }

        return $name === $registrable_domain || str_ends_with($name, '.' . $registrable_domain);
    }
}
