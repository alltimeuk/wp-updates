<?php
/**
 * Permanently deletes an organisation and everything linked to it, per the "purge organisation"
 * design: a genuine, capability-controlled destructive action - not the cosmetic
 * active/suspended/archived status toggle that already exists on `wpr_organisations.status`.
 *
 * No real `FOREIGN KEY` constraint exists anywhere in this schema, so cascade ordering is a pure
 * code-level convention. Every child id set this method needs downstream (scope ids, observation
 * ids and their evidence file references, finding ids, task ids, report UUIDs, customer account
 * ids and their linked contact ids) is captured up front, before any write happens, since none of
 * it is recoverable once the rows naming it are gone.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Organisations;

use Alltime\CustomerPlatform\ContactDeletionInterface;
use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\ContactServiceInterface;
use Alltime\WPReconnaissance\Auth\CustomerAccount;
use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Auth\TokenService;
use Alltime\WPReconnaissance\Data\EvidenceStorage;
use Alltime\WPReconnaissance\Data\Repositories\JobRepository;
use Alltime\WPReconnaissance\Data\Repositories\ObservationRepository;
use Alltime\WPReconnaissance\Data\Repositories\OrganisationRepository;
use Alltime\WPReconnaissance\Data\Repositories\ProfileRepository;
use Alltime\WPReconnaissance\Data\Repositories\RemediationTaskRepository;
use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Data\Repositories\TaskEventRepository;
use Alltime\WPReconnaissance\Entitlements\EntitlementRepository;
use Alltime\WPReconnaissance\Findings\FindingEventRepository;
use Alltime\WPReconnaissance\Findings\FindingRepository;
use Alltime\WPReconnaissance\Notifications\Repositories\DigestEntryRepository;
use Alltime\WPReconnaissance\Reports\ReportFileStorage;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class OrganisationPurgeService {

	public function __construct(
		private readonly OrganisationRepository $organisations = new OrganisationRepository(),
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly JobRepository $jobs = new JobRepository(),
		private readonly ObservationRepository $observations = new ObservationRepository(),
		private readonly FindingRepository $findings = new FindingRepository(),
		private readonly FindingEventRepository $finding_events = new FindingEventRepository(),
		private readonly RemediationTaskRepository $tasks = new RemediationTaskRepository(),
		private readonly TaskEventRepository $task_events = new TaskEventRepository(),
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly ProfileRepository $profiles = new ProfileRepository(),
		private readonly DigestEntryRepository $digest_entries = new DigestEntryRepository(),
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly EntitlementRepository $entitlements = new EntitlementRepository(),
		private readonly TokenService $tokens = new TokenService(),
		private readonly EvidenceStorage $evidence_storage = new EvidenceStorage(),
		private readonly ReportFileStorage $report_storage = new ReportFileStorage(),
		private readonly AuditLogger $audit_logger = new AuditLogger()
	) {}

	/**
	 * Safe to call more than once against the same id: every step in every phase treats "nothing
	 * left to delete" as a benign no-op, so a retry after a partial failure (e.g. the process dying
	 * mid-Phase-2) simply re-runs the remaining steps rather than throwing on tables Phase 1 already
	 * emptied on a prior attempt.
	 */
	public function purge( int $organisation_id, int $actor_id ): OrganisationPurgeSummary {
		$this->audit_logger->log( 'organisation.purge_started', 'organisation', $organisation_id, $actor_id );

		// Every id this method needs downstream, captured before any write - none of it is
		// recoverable once the rows naming it are gone.
		$scope_ids       = array_map( static fn ( $scope ): int => (int) $scope->id, $this->scopes->find_by_organisation( $organisation_id ) );
		$finding_ids     = array_map( static fn ( $finding ): int => (int) $finding->id, $this->findings->find_by_organisation( $organisation_id ) );
		$task_ids        = array_map( static fn ( $task ): int => (int) $task->id, $this->tasks->find_by_organisation( $organisation_id ) );
		$observations    = $this->observations->find_by_scope_ids( $scope_ids );
		$observation_ids = array_map( static fn ( array $row ): int => $row['id'], $observations );
		$evidence_refs   = array_values( array_filter( array_map( static fn ( array $row ): ?string => $row['raw_evidence_ref'], $observations ) ) );
		$report_uuids    = $this->reports->find_all_uuids_by_organisation( $organisation_id );
		$accounts        = $this->accounts->find_by_organisation( $organisation_id );

		$contact_platform = ContactPlatformDiscovery::resolve();
		$contact_ids      = array();

		foreach ( $accounts as $account ) {
			$contact = $contact_platform?->get_contact_for_user( $account->user_id );

			if ( null !== $contact ) {
				$contact_ids[] = $contact->id;
			}
		}

		$counts = $this->delete_wpr_rows( $organisation_id, $scope_ids, $finding_ids, $task_ids, $observation_ids, $contact_ids, $accounts );

		$this->delete_file_and_account_side_effects( $evidence_refs, $report_uuids, $accounts, $contact_ids, $contact_platform );

		$this->organisations->delete( $organisation_id );

		$summary = new OrganisationPurgeSummary(
			scopes: count( $scope_ids ),
			jobs: $counts['jobs'],
			observations: $counts['observations'],
			evidence_rows: $counts['evidence_rows'],
			evidence_files: count( $evidence_refs ),
			findings: $counts['findings'],
			finding_events: $counts['finding_events'],
			remediation_tasks: $counts['remediation_tasks'],
			task_events: $counts['task_events'],
			reports: $counts['reports'],
			report_files: count( $report_uuids ),
			digest_entries: $counts['digest_entries'],
			profiles: $counts['profiles'],
			entitlements: $counts['entitlements'],
			auth_tokens: $counts['auth_tokens'],
			customer_accounts: count( $accounts ),
			contacts: count( $contact_ids )
		);

		$this->audit_logger->log( 'organisation.purged', 'organisation', $organisation_id, $actor_id, summary: $summary->to_summary_line() );

		return $summary;
	}

	/**
	 * Phase 1: every `wpr_*` row delete in one transaction, innermost-child first. Ordering matters
	 * only because no real `FOREIGN KEY` constraint enforces it - a crash partway through still
	 * leaves the database internally consistent (no row ever references an id that no longer
	 * exists), just with the purge incomplete, which a retry safely continues.
	 *
	 * @param int[]             $scope_ids
	 * @param int[]             $finding_ids
	 * @param int[]             $task_ids
	 * @param int[]             $observation_ids
	 * @param int[]             $contact_ids
	 * @param CustomerAccount[] $accounts
	 * @return array<string,int>
	 */
	private function delete_wpr_rows( int $organisation_id, array $scope_ids, array $finding_ids, array $task_ids, array $observation_ids, array $contact_ids, array $accounts ): array {
		global $wpdb;

		$user_ids = array_map( static fn ( $account ): int => $account->user_id, $accounts );

		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		try {
			$counts = array(
				'task_events'       => $this->task_events->delete_by_task_ids( $task_ids ),
				'remediation_tasks' => $this->tasks->delete_by_organisation( $organisation_id ),
				'finding_events'    => $this->finding_events->delete_by_finding_ids( $finding_ids ),
				'findings'          => $this->findings->delete_by_organisation( $organisation_id ),
				'evidence_rows'     => $this->observations->delete_evidence_by_observation_ids( $observation_ids ),
				'observations'      => $this->observations->delete_by_scope_ids( $scope_ids ),
				'jobs'              => $this->jobs->delete_by_organisation( $organisation_id ),
				'reports'           => $this->reports->delete_by_organisation( $organisation_id ),
				'digest_entries'    => $this->digest_entries->delete_by_organisation( $organisation_id ),
				'scopes'            => $this->scopes->delete_by_organisation( $organisation_id ),
				'profiles'          => $this->profiles->delete_by_organisation( $organisation_id ),
				'entitlements'      => $this->entitlements->delete_by_contact_ids( $contact_ids ),
				'auth_tokens'       => $this->tokens->delete_by_user_ids( $user_ids ),
			);

			$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		} catch ( \Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			throw $exception;
		}

		return $counts;
	}

	/**
	 * Phase 2: non-transactional side effects, only after Phase 1 has committed. Deliberately
	 * outside the transaction above, and after it has already committed - matching
	 * {@see \Alltime\WPReconnaissance\Auth\RegistrationService}'s own documented rationale for
	 * keeping the Customer Platform call outside its transaction boundary: a lost file cleanup or
	 * contact-platform delete is recoverable (a small number of orphaned files/contacts, low
	 * severity), a purge that never actually removes the organisation's `wpr_*` data because it
	 * got rolled back by an unrelated file-system failure is not.
	 *
	 * A contact-platform delete failure is caught and audit-logged rather than allowed to abort the
	 * rest of this phase, for the same reason - one contact's failure must not leave every other
	 * account's session/user cleanup undone.
	 *
	 * @param string[]          $evidence_refs
	 * @param string[]          $report_uuids
	 * @param CustomerAccount[] $accounts
	 * @param int[]             $contact_ids
	 */
	private function delete_file_and_account_side_effects( array $evidence_refs, array $report_uuids, array $accounts, array $contact_ids, ?ContactServiceInterface $contact_platform ): void {
		foreach ( $evidence_refs as $reference ) {
			$this->evidence_storage->delete( $reference );
		}

		foreach ( $report_uuids as $report_uuid ) {
			$this->report_storage->delete( $this->report_storage->reference_for( $report_uuid ) );
		}

		foreach ( $accounts as $account ) {
			$this->accounts->destroy_all_sessions( $account->user_id );
			$this->accounts->delete( $account->user_id );
		}

		// A registered provider is not guaranteed to support deletion - ContactDeletionInterface
		// is a separate, optional capability precisely so the base ContactServiceInterface never
		// gains a required method an existing provider (e.g. a sibling plugin's own
		// implementation) doesn't already implement. A provider that can't delete simply leaves
		// these contacts in place; there is no other degrade path available here.
		if ( $contact_platform instanceof ContactDeletionInterface ) {
			foreach ( $contact_ids as $contact_id ) {
				try {
					$contact_platform->delete_contact( $contact_id );
				} catch ( \Throwable $exception ) {
					$this->audit_logger->log( 'organisation.purge_contact_delete_failed', 'contact', $contact_id, null, outcome: 'failure', summary: $exception->getMessage() );
				}
			}
		}
	}
}
