<?php
/**
 * Plugin Name:       WP Reconnaissance
 * Plugin URI:        https://github.com/alltimeuk/wp-reconnaissance
 * Description:       Self-service domain reconnaissance customer portal with authorised-scope collection, versioned rule evaluation, finding management and remediation reporting.
 * Version:           0.1.16
 * Requires at least: 6.6
 * Requires PHP:      8.1
 * Author:            Simon Jackson @ Alltime Technologies Ltd
 * Author URI:        https://alltimetech.co.uk
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-reconnaissance
 * Domain Path:       /languages
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WPR_VERSION        = '0.1.16';
const WPR_SCHEMA_VERSION = 13;

if ( ! defined( __NAMESPACE__ . '\WPR_PLUGIN_FILE' ) ) {
	define( __NAMESPACE__ . '\WPR_PLUGIN_FILE', __FILE__ );
	define( __NAMESPACE__ . '\WPR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
	define( __NAMESPACE__ . '\WPR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	define( __NAMESPACE__ . '\WPR_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}

$wpr_autoloader = WPR_PLUGIN_DIR . 'vendor/autoload.php';

if ( ! file_exists( $wpr_autoloader ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html__( 'WP Reconnaissance cannot start because its Composer dependencies are not installed. Run "composer install" in the plugin directory.', 'wp-reconnaissance' )
			);
		}
	);
	return;
}

require_once $wpr_autoloader;

register_activation_hook( __FILE__, array( Support\Plugin::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( Support\Plugin::class, 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function (): void {
		Support\Plugin::instance()->boot();
	}
);

// Plugin updater - runs in admin and WP-Cron contexts only, which is where WordPress's update
// checks actually fire; no need to load it on every public request.
if ( is_admin() || wp_doing_cron() ) {
	add_action(
		'plugins_loaded',
		static function (): void {
			new Support\Updater();
		}
	);
}
