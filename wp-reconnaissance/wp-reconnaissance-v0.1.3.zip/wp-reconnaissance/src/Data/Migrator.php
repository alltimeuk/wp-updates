<?php
/**
 * Incremental, idempotent schema migrations driven by `dbDelta()`.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data;

use const Alltime\WPReconnaissance\WPR_SCHEMA_VERSION;

/**
 * Installs and upgrades the plugin's database schema.
 *
 * Each schema version is a self-contained, additive step. Steps never drop columns or tables;
 * destructive changes belong to an explicit, separately reviewed later migration.
 */
final class Migrator {

	private const SCHEMA_VERSION_OPTION = 'wpr_db_schema_version';

	/**
	 * Runs on activation. Applies every migration step up to the current schema version.
	 */
	public static function install(): void {
		self::maybe_upgrade();
	}

	/**
	 * Runs on every boot; a no-op unless the stored schema version is behind the current one,
	 * which covers plugin upgrades without a re-activation step.
	 */
	public static function maybe_upgrade(): void {
		$current = (int) get_option( self::SCHEMA_VERSION_OPTION, 0 );

		if ( $current >= WPR_SCHEMA_VERSION ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		for ( $version = $current + 1; $version <= WPR_SCHEMA_VERSION; $version++ ) {
			$method = "apply_version_{$version}";

			if ( method_exists( self::class, $method ) ) {
				self::$method();
			}

			update_option( self::SCHEMA_VERSION_OPTION, $version, true );
		}
	}

	/**
	 * Removes plugin tables and options. Only invoked from uninstall.php after an explicit
	 * administrator opt-in via the "wpr_remove_data_on_uninstall" option.
	 */
	public static function uninstall(): void {
		global $wpdb;

		// Drop in dependency order (children before parents).
		$drop_order = array( 'notification_digest_entries', 'plans', 'abuse_signals', 'blocklist', 'privacy_requests', 'mail_events', 'mail_queue', 'entitlements', 'reports', 'task_events', 'remediation_tasks', 'auth_tokens', 'finding_events', 'findings', 'evidence', 'observations', 'jobs', 'scopes', 'profiles', 'audit_log', 'organisations' );

		foreach ( $drop_order as $key ) {
			$table = Schema::table( $key );
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $table is a fixed, internally derived identifier (Schema::table()), never user input.
		}

		delete_option( self::SCHEMA_VERSION_OPTION );
		delete_option( 'wpr_local_adapter_enabled' );
		delete_option( 'wpr_remove_data_on_uninstall' );

		// Mail-provider credentials (Section 22) - secrets must not survive uninstall.
		delete_option( 'wpr_mail_provider' );
		delete_option( 'wpr_gmail_oauth_client_id' );
		delete_option( 'wpr_gmail_oauth_client_secret' );
		delete_option( 'wpr_gmail_sender_address' );
		delete_option( 'wpr_gmail_refresh_token' );
		delete_option( 'wpr_ses_region' );
		delete_option( 'wpr_ses_access_key_id' );
		delete_option( 'wpr_ses_secret_access_key' );
		delete_option( 'wpr_ses_sender_address' );
	}

	/**
	 * Schema version 1: the Phase 1 core tables (organisations, scopes, profiles, jobs,
	 * observations, evidence, findings, finding_events, audit_log).
	 */
	private static function apply_version_1(): void {
		foreach ( Schema::version_1_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 2: the customer authentication token store (Section 18.1).
	 */
	private static function apply_version_2(): void {
		foreach ( Schema::version_2_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 3: remediation tasks, their event history, and issued reports (Section 21).
	 */
	private static function apply_version_3(): void {
		foreach ( Schema::version_3_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 4: entitlements (Section 5.5).
	 */
	private static function apply_version_4(): void {
		foreach ( Schema::version_4_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 5: the persistent mail queue and its delivery-state history (Section 22.5).
	 */
	private static function apply_version_5(): void {
		foreach ( Schema::version_5_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 6: data-subject rights requests (Section 26.3/26.4).
	 */
	private static function apply_version_6(): void {
		foreach ( Schema::version_6_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 7: the anti-abuse review queue and block/allow lists (Section 5.6).
	 */
	private static function apply_version_7(): void {
		foreach ( Schema::version_7_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	private static function apply_version_8(): void {
		foreach ( Schema::version_8_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 9: durable recurring assessment schedules (Section 33).
	 */
	private static function apply_version_9(): void {
		foreach ( Schema::version_9_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 10: customer-configurable notifications (Section 33).
	 */
	private static function apply_version_10(): void {
		foreach ( Schema::version_10_statements() as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Schema version 11: managed entitlement plans (Section 33).
	 */
	private static function apply_version_11(): void {
		foreach ( Schema::version_11_statements() as $statement ) {
			dbDelta( $statement );
		}
	}
}
