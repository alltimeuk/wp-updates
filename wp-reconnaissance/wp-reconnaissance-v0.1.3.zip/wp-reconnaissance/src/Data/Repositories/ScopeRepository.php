<?php
/**
 * Persistence for authorised scopes against `wpr_scopes`, per Section 8.2.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Data\Repositories;

use Alltime\WPReconnaissance\Data\Schema;
use Alltime\WPReconnaissance\Domain\Scope;

class ScopeRepository {

	public function find( int $id ): ?Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A );

		return null !== $row ? Scope::from_row( $row ) : null;
	}

	/**
	 * @return Scope[]
	 */
	public function find_by_organisation( int $organisation_id ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE organisation_id = %d ORDER BY id DESC", $organisation_id ), ARRAY_A );

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Every scope across every organisation, for the operator-facing admin screen. Never
	 * exposed to customers - callers must restrict to {@see find_by_organisation()} for any
	 * customer-facing surface.
	 *
	 * @return Scope[]
	 */
	public function list_all( int $per_page = 20, int $page = 1 ): array {
		global $wpdb;

		$table  = Schema::table( 'scopes' );
		$offset = max( 0, ( max( 1, $page ) - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A );

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	public function count_all(): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
	}

	/**
	 * Active scopes whose authorisation expires within the given window - Section 22.5's
	 * "Authorisation approaching expiry" notification trigger.
	 *
	 * @return Scope[]
	 */
	public function find_expiring_authorisations( int $within_days ): array {
		global $wpdb;

		$table   = Schema::table( 'scopes' );
		$now     = current_time( 'mysql', true );
		$horizon = ( new \DateTimeImmutable( $now ) )->modify( "+{$within_days} days" )->format( 'Y-m-d H:i:s' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE authorisation_status = 'authorised' AND authorised_until IS NOT NULL AND authorised_until BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$horizon
			),
			ARRAY_A
		);

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Counts scopes already covering the given registrable domain - the duplicate-domain signal
	 * the anti-abuse review queue uses (Section 5.6).
	 */
	public function count_by_registrable_domain( string $registrable_domain ): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE registrable_domain = %s", $registrable_domain ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public function count_by_status( string $status ): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE status = %s", $status ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * Active scopes belonging to one organisation - Section 33's managed-plan `max_active_scopes`
	 * enforcement measures against this, not the global {@see count_by_status()}.
	 */
	public function count_active_by_organisation( int $organisation_id ): int {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
			$wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE organisation_id = %d AND status = 'active'", $organisation_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * Active, authorised scopes whose recurring assessment is due - Section 33's durable
	 * schedules sweep. Excludes scopes that have never been seeded with a due date; those are
	 * picked up by {@see find_needing_schedule_seed()} first.
	 *
	 * @return Scope[]
	 */
	public function find_due_for_assessment( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );
		$now   = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE status = 'active' AND authorisation_status = 'authorised' AND next_assessment_due_at IS NOT NULL AND next_assessment_due_at <= %s ORDER BY next_assessment_due_at ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$limit
			),
			ARRAY_A
		);

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Active, authorised scopes that have never been through a schedule-seed pass - either newly
	 * authorised, or existing scopes from before schema version 9. The sweep seeds these with a
	 * due date (or leaves it null for a manual cadence) but does not dispatch a run on the same
	 * pass, so enabling schedules never causes a mass dispatch the instant it ships.
	 *
	 * Gated on `last_scheduled_at`, not `next_assessment_due_at`: a manual-cadence scope
	 * legitimately keeps `next_assessment_due_at` null forever, and must still only be seeded
	 * once rather than being re-selected by this query on every sweep.
	 *
	 * @return Scope[]
	 */
	public function find_needing_schedule_seed( int $limit ): array {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is a fixed, internally derived identifier, not user input.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE status = 'active' AND authorisation_status = 'authorised' AND last_scheduled_at IS NULL ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return array_map( array( Scope::class, 'from_row' ), null !== $rows ? $rows : array() );
	}

	/**
	 * Records that a scope's recurring assessment has been dispatched (or its due date seeded)
	 * and stores when it is next due. `$next_due_at` is always computed from now, never from the
	 * missed due date, so a late sweep never compounds drift into ever-earlier due dates.
	 */
	public function mark_scheduled( int $scope_id, ?\DateTimeImmutable $next_due_at ): void {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'next_assessment_due_at' => $next_due_at?->format( 'Y-m-d H:i:s' ),
				'last_scheduled_at'      => current_time( 'mysql', true ),
				'updated_at'             => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);
	}

	/**
	 * Creates a new scope. Domain canonicalisation (ASCII/display/registrable) must already
	 * have happened via {@see \Alltime\WPReconnaissance\Domain\DomainValidator} before calling
	 * this - the repository persists what it is given, it does not validate.
	 *
	 * @param string[]            $permitted_collectors
	 * @param string[]            $known_subdomains
	 * @param string[]            $known_dkim_selectors
	 * @param array<string,mixed> $expected_state
	 */
	public function create(
		int $organisation_id,
		string $name,
		string $domain_ascii,
		string $domain_display,
		string $registrable_domain,
		array $permitted_collectors,
		?int $monitoring_profile_id = null,
		array $known_subdomains = array(),
		array $known_dkim_selectors = array(),
		array $expected_state = array()
	): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );
		$now   = current_time( 'mysql', true );

		$data = array(
			'organisation_id'       => $organisation_id,
			'name'                  => $name,
			'domain_ascii'          => $domain_ascii,
			'domain_display'        => $domain_display,
			'registrable_domain'    => $registrable_domain,
			'status'                => 'pending',
			'authorisation_status'  => 'pending',
			'permitted_collectors'  => wp_json_encode( $permitted_collectors ),
			'known_subdomains'      => wp_json_encode( $known_subdomains ),
			'known_dkim_selectors'  => wp_json_encode( $known_dkim_selectors ),
			'expected_state'        => wp_json_encode( $expected_state ),
			'monitoring_profile_id' => $monitoring_profile_id,
			'created_at'            => $now,
			'updated_at'            => $now,
		);

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $this->find_or_fail( (int) $wpdb->insert_id );
	}

	/**
	 * Authorises a pending scope. Section 27: the plugin must display a clear authorised-use
	 * notice during scope creation - enforced by the caller (the admin/CLI action invoking
	 * this), not by the repository.
	 */
	public function authorise(
		int $scope_id,
		int $authorised_by,
		string $authorisation_reference,
		?\DateTimeImmutable $authorised_from = null,
		?\DateTimeImmutable $authorised_until = null
	): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'status'                  => 'active',
				'authorisation_status'    => 'authorised',
				'authorised_by'           => $authorised_by,
				'authorisation_reference' => $authorisation_reference,
				'authorised_from'         => ( $authorised_from ?? new \DateTimeImmutable() )->format( 'Y-m-d H:i:s' ),
				'authorised_until'        => $authorised_until?->format( 'Y-m-d H:i:s' ),
				'updated_at'              => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		return $this->find_or_fail( $scope_id );
	}

	/**
	 * Replaces a scope's baseline (Section 33 "baselines and expected state") wholesale - callers
	 * that only want to update one collector's baseline must read the current
	 * {@see Scope::$expected_state} first and merge, since this is not a partial update.
	 *
	 * @param array<string,mixed> $expected_state
	 */
	public function update_expected_state( int $scope_id, array $expected_state ): Scope {
		global $wpdb;

		$table = Schema::table( 'scopes' );

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$table,
			array(
				'expected_state' => wp_json_encode( $expected_state ),
				'updated_at'     => current_time( 'mysql', true ),
			),
			array( 'id' => $scope_id )
		);

		return $this->find_or_fail( $scope_id );
	}

	private function find_or_fail( int $id ): Scope {
		$scope = $this->find( $id );

		if ( null === $scope ) {
			throw new \RuntimeException( esc_html( "Scope {$id} was expected to exist but could not be loaded." ) );
		}

		return $scope;
	}
}
