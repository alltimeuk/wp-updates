<?php
/**
 * Pure clamping of a requested schedule cadence against a managed plan's floor (Section 33
 * "repeat, paid and managed-service entitlements"): a plan's `min_schedule_frequency` is the
 * fastest cadence it permits, so a scope requesting something faster is slowed down to it: a
 * scope requesting something already at or slower than the floor is left untouched.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Scheduling;

use Alltime\WPReconnaissance\Domain\Enums\ScheduleFrequency;

final class ScheduleFrequencyClamp {

	/** Fastest (0) to slowest/never (3). */
	private const RANK = array(
		ScheduleFrequency::Daily->value   => 0,
		ScheduleFrequency::Weekly->value  => 1,
		ScheduleFrequency::Monthly->value => 2,
		ScheduleFrequency::Manual->value  => 3,
	);

	/**
	 * `$floor` of null means the plan (or the absence of one) imposes no restriction - `$requested`
	 * is returned unchanged.
	 */
	public function clamp( ScheduleFrequency $requested, ?ScheduleFrequency $floor ): ScheduleFrequency {
		if ( null === $floor ) {
			return $requested;
		}

		return self::RANK[ $requested->value ] < self::RANK[ $floor->value ] ? $floor : $requested;
	}
}
