<?php
/**
 * Finds personal data linked to an email address, per Section 26.4: "Find all linked data across
 * WordPress users, custom tables, evidence files, mail events, reports and integrations."
 *
 * Deliberately scoped to genuine personal data about the individual, not the organisational
 * security data WP Reconnaissance exists to produce: findings, evidence and reports describe a
 * domain's security posture, not the requester, so they are out of scope here even though they
 * are linked to the requester's organisation. The one exception already covered by this locator
 * is the audit log, which does name the requester as an actor.
 *
 * The Customer Platform's interaction/consent ledger (`atcp_interactions`, `atcp_consents`) is
 * not included: {@see \Alltime\CustomerPlatform\ContactServiceInterface} does not yet expose a
 * read method for either, and this locator only ever reaches the Customer Platform through that
 * versioned contract, never its repositories directly (Section 6.1.3). Only the canonical contact
 * record itself (name, lifecycle status, verification date) is included via
 * {@see \Alltime\CustomerPlatform\ContactServiceInterface::get_contact_for_user()}.
 *
 * Section 26.3 requires linked WP Questionnaires data in the same download/request workflow; that
 * is included here via {@see \Alltime\CustomerPlatform\WpqCompatibilityAdapter::export_contact_data()}
 * when WP Questionnaires is active (Section 6.1.4).
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Privacy;

use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\WpqCompatibilityAdapter;
use Alltime\WPReconnaissance\Auth\CustomerAccountRepository;
use Alltime\WPReconnaissance\Notifications\QueuedMail;
use Alltime\WPReconnaissance\Notifications\Repositories\MailQueueRepository;
use Alltime\WPReconnaissance\Support\AuditLogger;

final class PersonalDataLocator {

	public function __construct(
		private readonly CustomerAccountRepository $accounts = new CustomerAccountRepository(),
		private readonly MailQueueRepository $mail_queue = new MailQueueRepository(),
		private readonly AuditLogger $audit_logger = new AuditLogger(),
		private readonly WpqCompatibilityAdapter $wpq = new WpqCompatibilityAdapter()
	) {}

	/**
	 * @return array<int,array{group_id:string,group_label:string,item_id:string,data:array<int,array{name:string,value:string}>}>
	 */
	public function locate( string $email ): array {
		$groups = array();

		$account = $this->accounts->find_by_email( $email );

		if ( null !== $account ) {
			$groups[] = array(
				'group_id'    => 'wpr-account',
				'group_label' => __( 'WP Reconnaissance account', 'wp-reconnaissance' ),
				'item_id'     => 'account',
				'data'        => array(
					array(
						'name'  => __( 'Given name', 'wp-reconnaissance' ),
						'value' => $account->given_name,
					),
					array(
						'name'  => __( 'Family name', 'wp-reconnaissance' ),
						'value' => $account->family_name,
					),
					array(
						'name'  => __( 'Email', 'wp-reconnaissance' ),
						'value' => $account->email,
					),
					array(
						'name'  => __( 'Account status', 'wp-reconnaissance' ),
						'value' => $account->status->value,
					),
					array(
						'name'  => __( 'Organisation ID', 'wp-reconnaissance' ),
						'value' => (string) $account->organisation_id,
					),
				),
			);

			$contact = ContactPlatformDiscovery::resolve()?->get_contact_for_user( $account->user_id );

			if ( null !== $contact ) {
				$groups[] = array(
					'group_id'    => 'wpr-contact',
					'group_label' => __( 'Shared contact record', 'wp-reconnaissance' ),
					'item_id'     => 'contact-' . $contact->contact_uuid,
					'data'        => array(
						array(
							'name'  => __( 'Contact reference', 'wp-reconnaissance' ),
							'value' => $contact->contact_uuid,
						),
						array(
							'name'  => __( 'Given name', 'wp-reconnaissance' ),
							'value' => $contact->given_name,
						),
						array(
							'name'  => __( 'Family name', 'wp-reconnaissance' ),
							'value' => $contact->family_name,
						),
						array(
							'name'  => __( 'Lifecycle status', 'wp-reconnaissance' ),
							'value' => $contact->lifecycle_status->value,
						),
						array(
							'name'  => __( 'Created', 'wp-reconnaissance' ),
							'value' => $contact->created_at->format( 'Y-m-d H:i:s' ) . ' UTC',
						),
					),
				);
			}

			foreach ( $this->audit_logger->find_by_actor( $account->user_id ) as $entry ) {
				$groups[] = array(
					'group_id'    => 'wpr-audit-log',
					'group_label' => __( 'Audit log entries', 'wp-reconnaissance' ),
					'item_id'     => 'audit-log-' . $entry['id'],
					'data'        => array(
						array(
							'name'  => __( 'Action', 'wp-reconnaissance' ),
							'value' => (string) $entry['action'],
						),
						array(
							'name'  => __( 'Object type', 'wp-reconnaissance' ),
							'value' => (string) $entry['object_type'],
						),
						array(
							'name'  => __( 'Outcome', 'wp-reconnaissance' ),
							'value' => (string) $entry['outcome'],
						),
						array(
							'name'  => __( 'Occurred at', 'wp-reconnaissance' ),
							'value' => (string) $entry['occurred_at'] . ' UTC',
						),
					),
				);
			}
		}

		foreach ( $this->mail_queue->find_by_recipient( $email ) as $mail ) {
			$groups[] = $this->mail_group( $mail );
		}

		$wpq_data = $this->wpq->export_contact_data( $email );

		if ( array() !== $wpq_data ) {
			$groups[] = array(
				'group_id'    => 'wpq-data',
				'group_label' => __( 'WP Questionnaires data', 'wp-reconnaissance' ),
				'item_id'     => 'wpq-export',
				'data'        => $this->flatten_wpq_data( $wpq_data ),
			);
		}

		return $groups;
	}

	/**
	 * Flattens the nested WPQ export payload into the locator's flat name/value rows.
	 *
	 * @param array<mixed> $data
	 *
	 * @return array<int,array{name:string,value:string}>
	 */
	private function flatten_wpq_data( array $data ): array {
		$rows = array();

		foreach ( $data as $key => $value ) {
			if ( is_array( $value ) ) {
				$rows[] = array(
					'name'  => (string) $key,
					'value' => wp_json_encode( $value ),
				);
				continue;
			}

			$rows[] = array(
				'name'  => (string) $key,
				'value' => null !== $value ? (string) $value : '',
			);
		}

		return $rows;
	}

	/**
	 * @return array{group_id:string,group_label:string,item_id:string,data:array<int,array{name:string,value:string}>}
	 */
	private function mail_group( QueuedMail $mail ): array {
		return array(
			'group_id'    => 'wpr-mail-queue',
			'group_label' => __( 'Email messages sent to this address', 'wp-reconnaissance' ),
			'item_id'     => 'mail-' . $mail->id,
			'data'        => array(
				array(
					'name'  => __( 'Template', 'wp-reconnaissance' ),
					'value' => $mail->template,
				),
				array(
					'name'  => __( 'Purpose', 'wp-reconnaissance' ),
					'value' => $mail->purpose->value,
				),
				array(
					'name'  => __( 'Subject', 'wp-reconnaissance' ),
					'value' => $mail->subject,
				),
				array(
					'name'  => __( 'State', 'wp-reconnaissance' ),
					'value' => $mail->state->value,
				),
				array(
					'name'  => __( 'Sent at', 'wp-reconnaissance' ),
					'value' => $mail->sent_at?->format( 'Y-m-d H:i:s' ) . ( null !== $mail->sent_at ? ' UTC' : '' ),
				),
			),
		);
	}
}
