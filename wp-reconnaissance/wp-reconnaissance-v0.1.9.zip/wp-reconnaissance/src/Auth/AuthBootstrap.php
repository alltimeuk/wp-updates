<?php
/**
 * Dedicated customer authentication route bootstrap, per Section 18.1.
 *
 * Customers never register, sign in, reset passwords or manage their account through the
 * native wp-login.php presentation. The underlying identity records remain ordinary WordPress
 * users (core password hashing and session handling are retained via wp_insert_user(),
 * wp_signon(), wp_set_password()); this class owns the public routes, form handling, validation
 * messages and redirections.
 *
 * Rendering here is deliberately minimal inline HTML - not the branded, ACF-driven templates
 * Section 9.3 describes. It exists so the routes are genuinely functional end-to-end; a real
 * template/theme layer is later Phase 1 work.
 *
 * Every route/handler below builds its screen as a {@see CustomerPageResult} (title + body,
 * unwrapped) rather than echoing a full HTML document itself - {@see dispatch()} is the one place
 * that wraps a result in the bare `<!doctype html>` document these raw `/customer/*` routes have
 * always rendered. This split exists so the same title/body-building logic can also be reused by a
 * shortcode-embedded rendering path (added separately) that needs the result unwrapped, since it
 * lands inside a real theme's own page rather than owning the whole response.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Auth;

use Alltime\CustomerPlatform\ContactPlatformDiscovery;
use Alltime\CustomerPlatform\VisitorContextPlatformDiscovery;
use Alltime\WPReconnaissance\Auth\Enums\AccountStatus;
use Alltime\WPReconnaissance\Auth\Enums\NotificationFrequency;
use Alltime\WPReconnaissance\AntiAbuse\Captcha\HoneypotCaptchaAdapter;
use Alltime\WPReconnaissance\Auth\Exceptions\RegistrationException;
use Alltime\WPReconnaissance\Auth\Exceptions\RegistrationTransactionException;
use Alltime\WPReconnaissance\Data\Repositories\RemediationTaskRepository;
use Alltime\WPReconnaissance\Data\Repositories\ReportRepository;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepository;
use Alltime\WPReconnaissance\Domain\Enums\RemediationTaskStatus;
use Alltime\WPReconnaissance\Domain\RemediationTask;
use Alltime\WPReconnaissance\Domain\Report;
use Alltime\WPReconnaissance\Domain\Scope;
use Alltime\WPReconnaissance\Entitlements\EntitlementService;
use Alltime\WPReconnaissance\Data\Repositories\ScopeRepositoryException;
use Alltime\WPReconnaissance\Entitlements\PlanLimitException;
use Alltime\WPReconnaissance\Verification\SchemaNotReadyException;
use Alltime\WPReconnaissance\Integrations\Enums\MailPurpose;
use Alltime\WPReconnaissance\Integrations\QueuedMessage;
use Alltime\WPReconnaissance\Notifications\MailQueueService;
use Alltime\WPReconnaissance\Privacy\Enums\PrivacyRightType;
use Alltime\WPReconnaissance\Privacy\PersonalDataLocator;
use Alltime\WPReconnaissance\Privacy\PrivacyRequest;
use Alltime\WPReconnaissance\Privacy\PrivacyRequestRepository;
use Alltime\WPReconnaissance\Privacy\PrivacyRequestRepositoryException;
use Alltime\WPReconnaissance\Privacy\PrivacyRequestService;
use Alltime\WPReconnaissance\Reports\HtmlReportRenderer;
use Alltime\WPReconnaissance\Reports\ReportComparator;
use Alltime\WPReconnaissance\Reports\ReportDownloadToken;
use Alltime\WPReconnaissance\Reports\ReportPdfService;
use Alltime\WPReconnaissance\Support\Capabilities;
use Alltime\WPReconnaissance\Support\Roles;
use Alltime\WPReconnaissance\Tools\ToolRegistry;
use Alltime\WPReconnaissance\Verification\DomainVerificationService;

use const Alltime\WPReconnaissance\WPR_VERSION;

final class AuthBootstrap {

	private const QUERY_VAR = 'wpr_customer_route';

	/** @var string[] */
	private const ROUTES = array(
		'register',
		'verify-email',
		'login',
		'forgot-password',
		'reset-password',
		'account',
		'security',
		'privacy',
		'tools',
		'reports',
		'tasks',
	);

	/**
	 * The hidden field a shortcode-rendered form carries to identify which route its POST is for,
	 * read by {@see dispatch_shortcode_post()} - independent of which page/URL the POST actually
	 * arrives at, unlike the raw-route dispatch which keys off {@see QUERY_VAR}.
	 */
	private const SHORTCODE_ROUTE_FIELD = 'wpr_shortcode_route';

	/**
	 * The hidden field {@see render_login_form()} embeds when rendered with a non-empty
	 * `$redirect_path` (the `[wpr_customer_login redirect="..."]` shortcode attribute), read by
	 * {@see handle_login()}'s success path in place of its hardcoded default.
	 */
	private const LOGIN_REDIRECT_FIELD = 'wpr_login_redirect';

	/**
	 * Populated by {@see dispatch_shortcode_post()} when a shortcode-originated POST produces a
	 * result instead of redirecting (e.g. "wrong password") - consumed by the shortcode-rendering
	 * path added in a follow-up change, so that result reaches the same request's page render
	 * instead of being discarded. Static, not instance-scoped: {@see \Alltime\WPReconnaissance\Support\Plugin::boot()}
	 * and the shortcode-registration class each hold their own separate `AuthBootstrap` instance,
	 * so an instance property here wouldn't be visible to both.
	 *
	 * @var array<string,CustomerPageResult>
	 */
	private static array $pending_shortcode_render = array();

	private RateLimiter $rate_limiter;

	/**
	 * Set for the duration of a request handled by {@see dispatch_shortcode_post()}, read by
	 * {@see redirect_target()} to decide whether a successful action should redirect back to the
	 * page that hosted the shortcode (via the HTTP referer) or to the raw route's own hardcoded
	 * URL, as it always has. Left false for the raw-route path, so redirect_target() behaves
	 * identically to the hardcoded URLs it replaces there.
	 *
	 * @var bool
	 */
	private bool $shortcode_context = false;

	/**
	 * Read-only for a customer: Section 20 lists "Remediation status" as something a customer
	 * user may view, not something the portal currently lets them change themselves - updating a
	 * task's status/notes still goes through an operator (admin) today.
	 */
	/**
	 * @param callable $terminator Should never return - defaults to a real `exit`, overridable so
	 *        a test can substitute a catchable signal instead of tearing down the PHPUnit process
	 *        itself (the class is `final`, so a test subclass overriding a method isn't an
	 *        option). Not typed `callable(): never` - {@see terminate()} always falls through to
	 *        a real `exit` regardless, so nothing actually depends on this being statically
	 *        provable, and that stricter shape only made PHPStan misidentify the fallback as
	 *        unreachable. See {@see terminate()}.
	 */
	public function __construct(
		private readonly ScopeRepository $scopes = new ScopeRepository(),
		private readonly ReportRepository $reports = new ReportRepository(),
		private readonly RemediationTaskRepository $tasks = new RemediationTaskRepository(),
		private readonly HtmlReportRenderer $report_renderer = new HtmlReportRenderer(),
		private readonly ToolRegistry $tool_registry = new ToolRegistry(),
		private readonly EntitlementService $entitlements = new EntitlementService(),
		private readonly MailQueueService $mail_queue = new MailQueueService(),
		private readonly DomainVerificationService $domain_verification = new DomainVerificationService(),
		private $terminator = array( self::class, 'default_terminate' )
	) {
		$this->rate_limiter = new RateLimiter();
	}

	private static function default_terminate(): never {
		exit;
	}

	public function boot(): void {
		add_action( 'init', array( $this, 'register_rewrite_rules' ) );
		add_filter( 'query_vars', array( $this, 'register_query_var' ) );
		add_action( 'template_redirect', array( $this, 'dispatch' ) );
		add_action( 'template_redirect', array( $this, 'dispatch_shortcode_post' ) );
		add_action( 'wp_loaded', array( $this, 'maybe_flush_rewrite_rules' ) );
	}

	public function register_rewrite_rules(): void {
		foreach ( self::ROUTES as $slug ) {
			add_rewrite_rule(
				'^customer/' . preg_quote( $slug, '/' ) . '/?$',
				'index.php?' . self::QUERY_VAR . '=' . $slug,
				'top'
			);
		}
	}

	/**
	 * Self-healing companion to {@see \Alltime\WPReconnaissance\Support\Plugin::activate()}'s
	 * one-time `flush_rewrite_rules()` call, which WordPress never re-runs on a plugin *update* -
	 * only a fresh activation triggers `register_activation_hook()`'s callback. Without this, every
	 * one of the 10 `/customer/*` routes above would 404 after any update that changed the route
	 * set (or, in practice, after any update at all - the rules option can drift for other reasons
	 * too), until an administrator happened to notice and manually re-save Settings > Permalinks.
	 *
	 * Runs on every request (`wp_loaded`, after {@see register_rewrite_rules()} has already fired
	 * on `init` and re-registered the current rule set) but the check itself is a single cheap
	 * `get_option()` call - the actual flush only happens the first request after `WPR_VERSION`
	 * changes, and this remembers that version so it doesn't repeat the flush on every subsequent
	 * request.
	 */
	public function maybe_flush_rewrite_rules(): void {
		if ( WPR_VERSION === get_option( 'wpr_rewrite_rules_version', '' ) ) {
			return;
		}

		flush_rewrite_rules();
		update_option( 'wpr_rewrite_rules_version', WPR_VERSION );
	}

	/**
	 * @param string[] $vars
	 * @return string[]
	 */
	public function register_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	public function dispatch(): void {
		$route = get_query_var( self::QUERY_VAR );

		if ( ! is_string( $route ) || '' === $route || ! in_array( $route, self::ROUTES, true ) ) {
			return;
		}

		status_header( 200 );
		nocache_headers();

		$result = match ( $route ) {
			'register' => $this->handle_register(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->handle_login(),
			'forgot-password' => $this->handle_forgot_password(),
			'reset-password' => $this->handle_reset_password(),
			'account' => $this->handle_account(),
			'security' => $this->handle_security(),
			'privacy' => $this->handle_privacy(),
			'reports' => $this->handle_reports(),
			'tasks' => $this->handle_tasks(),
			'tools' => $this->handle_tools(),
		};

		echo '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html( $result->title ) . '</title></head><body>';
		echo '<h1>' . esc_html( $result->title ) . '</h1>';
		echo $result->body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $result->body is assembled from esc_html()/esc_attr()/esc_url()-escaped fragments and wp_nonce_field() by every caller.
		echo '</body></html>';

		$this->terminate();
	}

	/**
	 * The page-agnostic counterpart to {@see dispatch()}: recognises a shortcode-rendered form's
	 * POST purely from {@see SHORTCODE_ROUTE_FIELD}, regardless of which page/URL it was submitted
	 * to, so the same handler logic works whether a screen is reached via its raw `/customer/*`
	 * route or embedded as a shortcode on an ordinary themed page. Hooked on the same
	 * `template_redirect` action as dispatch() (confirmed to fire before any theme output, well
	 * before `the_content`/`do_shortcode()` - safe to `wp_safe_redirect()` from here exactly as
	 * dispatch() already does).
	 *
	 * The guard below is a hard invariant, not a convenience: without it, a crafted request to a
	 * real `/customer/*` URL that also carries a forged {@see SHORTCODE_ROUTE_FIELD} field could
	 * fire both dispatchers. This must hold regardless of `add_action()` registration order.
	 *
	 * Adds no new bypass of anything a raw route already required: every nonce
	 * ({@see verify_nonce()}), rate limit and ownership check inside the `handle_*()` methods this
	 * calls runs exactly as it does for the raw route, since it's the same method either way. The
	 * hidden route field carries no authority of its own - it only selects which already-guarded
	 * handler runs.
	 */
	public function dispatch_shortcode_post(): void {
		if ( '' !== (string) get_query_var( self::QUERY_VAR ) ) {
			return;
		}

		if ( ! $this->is_post() ) {
			return;
		}

		$route = $this->post_field( self::SHORTCODE_ROUTE_FIELD );

		if ( '' === $route || ! in_array( $route, self::ROUTES, true ) ) {
			return;
		}

		$this->shortcode_context = true;

		$result = match ( $route ) {
			'register' => $this->handle_register(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->handle_login(),
			'forgot-password' => $this->handle_forgot_password(),
			'reset-password' => $this->handle_reset_password(),
			'account' => $this->handle_account(),
			'security' => $this->handle_security(),
			'privacy' => $this->handle_privacy(),
			'reports' => $this->handle_reports(),
			'tasks' => $this->handle_tasks(),
			'tools' => $this->handle_tools(),
		};

		// A handler that redirected (the common case for a successful action) already terminated
		// the request inside the call above via a `never`-returning path and control never reaches
		// this line at all. Only a non-terminating outcome (e.g. a validation error rendered
		// inline) gets here, and needs stashing for the shortcode's own render callback
		// ({@see render_customer_shortcode()}) to pick up instead of doing a fresh GET-render.
		self::$pending_shortcode_render[ $route ] = $result;
	}

	/**
	 * Where a successful action should redirect to: the page that hosted the shortcode (via the
	 * HTTP referer - {@see wp_get_referer()} already restricts this to the site's own domain, the
	 * same protection wp-admin itself relies on) when invoked through
	 * {@see dispatch_shortcode_post()}, or the raw route's own hardcoded URL otherwise - identical
	 * to the hardcoded `home_url()` calls this replaces for every raw-route request, since
	 * {@see $shortcode_context} is false there.
	 */
	private function redirect_target( string $default_route ): string {
		if ( $this->shortcode_context ) {
			$referer = wp_get_referer();

			if ( false !== $referer ) {
				return $referer;
			}
		}

		return home_url( '/customer/' . $default_route . '/' );
	}

	/**
	 * Routes that require {@see require_customer_account()} - reused here to decide which shortcode
	 * calls need {@see require_customer_account_or_null()} instead, since a redirecting auth gate is
	 * unsafe to call from a shortcode's render callback (see require_customer_account_or_null()'s
	 * own docblock).
	 *
	 * @var string[]
	 */
	private const GATED_ROUTES = array( 'account', 'security', 'privacy', 'reports', 'tasks', 'tools' );

	/**
	 * Renders one of the 11 customer-portal screens as a themed-page-compatible fragment, for a
	 * `[wpr_customer_*]` shortcode (registered separately, in
	 * {@see \Alltime\WPReconnaissance\Shortcodes\CustomerPortalShortcodes}) to embed inside
	 * ordinary page content. Returns only the body - no `<!doctype html>` wrapper and no `<h1>`
	 * title, unlike {@see dispatch()}'s raw-route rendering, since the theme's own page (and the
	 * site builder's own surrounding heading, if any) already provide that context.
	 *
	 * Deliberately never branches on {@see is_post()} or reads `$_POST` fields directly: by the
	 * time a shortcode's content renders (during `the_content`, well after `template_redirect`),
	 * any POST this request carried has already been fully handled by
	 * {@see dispatch_shortcode_post()} - which knows exactly which one shortcode's form (if any)
	 * was actually submitted, via {@see SHORTCODE_ROUTE_FIELD}. `is_post()` alone cannot answer
	 * that: a themed page can host more than one of these shortcodes at once, and the HTTP
	 * request's method is a property of the whole request, not of any one shortcode on the page -
	 * naively re-running a `handle_*()` method's own POST branch here would process (or mis-nonce)
	 * a different shortcode's submission. So this only ever calls the pure, GET-only rendering
	 * methods, after first checking {@see $pending_shortcode_render} for a result
	 * dispatch_shortcode_post() already produced for this exact route.
	 */
	public function render_customer_shortcode( string $route, array $atts = array() ): string {
		if ( ! in_array( $route, self::ROUTES, true ) ) {
			return '';
		}

		$stashed = self::$pending_shortcode_render[ $route ] ?? null;

		if ( null !== $stashed ) {
			unset( self::$pending_shortcode_render[ $route ] );
			return $stashed->body;
		}

		$account = null;

		if ( in_array( $route, self::GATED_ROUTES, true ) ) {
			$account = $this->require_customer_account_or_null();

			if ( null === $account ) {
				return $this->sign_in_prompt_fragment();
			}
		}

		$result = match ( $route ) {
			'register' => $this->render_register_form(),
			'verify-email' => $this->handle_verify_email(),
			'login' => $this->render_login_form( null, isset( $atts['redirect'] ) ? (string) $atts['redirect'] : '' ),
			'forgot-password' => $this->render_forgot_password_form(),
			'reset-password' => $this->render_reset_password_screen(),
			'account' => $this->render_account_dashboard( $account ),
			'security' => $this->render_security_screen( $account ),
			'privacy' => $this->render_privacy_centre( $account ),
			'reports' => $this->render_reports_view( $account ),
			'tasks' => $this->render_tasks_list( $account ),
			'tools' => $this->build_tools_result( $account ),
		};

		return $result->body;
	}

	private function sign_in_prompt_fragment(): string {
		return '<p>' . esc_html__( 'Please sign in to view this.', 'wp-reconnaissance' ) . ' <a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Sign in', 'wp-reconnaissance' ) . '</a></p>';
	}

	// -----------------------------------------------------------------------------------
	// Registration
	// -----------------------------------------------------------------------------------

	private function handle_register(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_register_form();
		}

		if ( ! $this->verify_nonce( 'wpr_register' ) || ! $this->rate_limiter->allow( 'register', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS ) ) {
			return $this->render_register_form( __( 'Please try again in a little while.', 'wp-reconnaissance' ) );
		}

		try {
			$result = ( new RegistrationService() )->register(
				$this->post_field( 'given_name' ),
				$this->post_field( 'family_name' ),
				$this->post_field( 'email' ),
				$this->post_field( 'organisation_name' ),
				$this->post_field( 'domain' ),
				$this->post_checked( 'domain_authorisation_confirmed' ),
				$this->post_field( 'password' ),
				$this->post_field( 'password_confirmation' ),
				$this->post_checked( 'terms_accepted' ),
				$this->post_checked( 'privacy_acknowledged' ),
				$this->post_checked( 'marketing_consent' ),
				$this->rate_limiter->client_ip(),
				$this->post_captcha_input()
			);
		} catch ( RegistrationException | RegistrationTransactionException $exception ) {
			return $this->render_register_form( $exception->getMessage() );
		}

		// Section 18.1: identical response whether or not the address was already registered.
		if ( $result->is_new && null !== $result->account && null !== $result->verification_token ) {
			$this->send_verification_email( $result->account, $result->verification_token );
		}

		return $this->render_result(
			__( 'Check your email', 'wp-reconnaissance' ),
			'<p>' . esc_html__( 'If your details were accepted, we have sent a verification link to the email address you provided. Follow it to activate your account and start your free assessment.', 'wp-reconnaissance' ) . '</p>'
		);
	}

	private function render_register_form( ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpr_register', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Given name', 'wp-reconnaissance' ) . '<br><input type="text" name="given_name" required></label></p>
				<p><label>' . esc_html__( 'Family name', 'wp-reconnaissance' ) . '<br><input type="text" name="family_name" required></label></p>
				<p><label>' . esc_html__( 'Business email address', 'wp-reconnaissance' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Organisation name', 'wp-reconnaissance' ) . '<br><input type="text" name="organisation_name" required></label></p>
				<p><label>' . esc_html__( 'Domain to assess', 'wp-reconnaissance' ) . '<br><input type="text" name="domain" placeholder="example.com" required></label></p>
				<p><label><input type="checkbox" name="domain_authorisation_confirmed" value="1" required> ' . esc_html__( 'I own this domain, or have authority from its owner to request an external assessment of it.', 'wp-reconnaissance' ) . '</label></p>
				<p><label>' . esc_html__( 'Password', 'wp-reconnaissance' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm password', 'wp-reconnaissance' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><label><input type="checkbox" name="terms_accepted" value="1" required> ' . esc_html__( 'I accept the service terms.', 'wp-reconnaissance' ) . '</label></p>
				<p><label><input type="checkbox" name="privacy_acknowledged" value="1" required> ' . esc_html__( 'I acknowledge the privacy notice.', 'wp-reconnaissance' ) . '</label></p>
				<p><label><input type="checkbox" name="marketing_consent" value="1"> ' . esc_html__( 'I would like to receive occasional marketing updates (optional).', 'wp-reconnaissance' ) . '</label></p>
				' . ( new HoneypotCaptchaAdapter( (bool) get_option( 'wpr_abuse_captcha_enabled', false ), (int) get_option( 'wpr_abuse_min_form_seconds', 3 ) ) )->render() . '
				<p><button type="submit">' . esc_html__( 'Create account', 'wp-reconnaissance' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Already have an account? Sign in.', 'wp-reconnaissance' ) . '</a></p>';

		return $this->render_result( __( 'Create your account', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Email verification
	// -----------------------------------------------------------------------------------

	private function handle_verify_email(): CustomerPageResult {
		$token = $this->get_field( 'token' );

		if ( '' === $token ) {
			return $this->render_result( __( 'Verify your email', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No verification token was supplied.', 'wp-reconnaissance' ) . '</p>' );
		}

		$verified = ( new EmailVerificationService() )->verify( $token );

		$body = $verified
			? '<p>' . esc_html__( 'Your email address has been verified. You can now sign in.', 'wp-reconnaissance' ) . '</p><p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Sign in', 'wp-reconnaissance' ) . '</a></p>'
			: '<p>' . esc_html__( 'This verification link is invalid or has expired.', 'wp-reconnaissance' ) . '</p>';

		return $this->render_result( __( 'Verify your email', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Login
	// -----------------------------------------------------------------------------------

	private function handle_login(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_login_form();
		}

		if ( ! $this->verify_nonce( 'wpr_login' ) || ! $this->rate_limiter->allow( 'login', $this->rate_limiter->client_ip(), 10, 15 * MINUTE_IN_SECONDS ) ) {
			return $this->render_login_form( __( 'Too many attempts. Please try again shortly.', 'wp-reconnaissance' ) );
		}

		$generic_error = __( 'Incorrect email address or password.', 'wp-reconnaissance' );

		$user = wp_signon(
			array(
				'user_login'    => $this->post_field( 'email' ),
				'user_password' => $this->post_field( 'password' ),
				'remember'      => true,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			return $this->render_login_form( $generic_error );
		}

		if ( ! in_array( Roles::CUSTOMER_ROLE, (array) $user->roles, true ) ) {
			wp_logout();
			return $this->render_login_form( $generic_error );
		}

		$account = ( new CustomerAccountRepository() )->find( $user->ID );

		if ( null === $account || ! $account->status->permits_login() ) {
			wp_logout();

			$message = null !== $account && AccountStatus::PendingEmailVerification === $account->status
				? __( 'Please verify your email address before signing in.', 'wp-reconnaissance' )
				: __( 'This account is not currently available. Contact support for help.', 'wp-reconnaissance' );

			return $this->render_login_form( $message );
		}

		// Associate the cross-tool visitor context with the authenticated contact (Section 18.1.3
		// precedence rule 1: an authenticated, verified account relationship is authoritative).
		$contact = ContactPlatformDiscovery::resolve()?->get_contact_for_user( $user->ID );
		if ( null !== $contact ) {
			VisitorContextPlatformDiscovery::resolve()?->handle_authenticated_identity( $contact->id );
		}

		// Deliberately NOT redirect_target(): the referer for a shortcode-embedded login form is
		// the login page itself (forms here have no action= attribute, so they self-submit) -
		// sending a just-authenticated visitor back there would show them the login form again
		// instead of anywhere useful. Defaults to the account dashboard regardless of dispatch
		// context; a site embedding [wpr_customer_login redirect="..."] can override that via the
		// hidden field render_login_form() embeds, re-validated here rather than trusted as-is
		// since a hidden field's value is still attacker-editable on the client.
		$override = $this->post_field( self::LOGIN_REDIRECT_FIELD );
		$target   = '' !== $override ? wp_validate_redirect( $override, home_url( '/customer/account/' ) ) : home_url( '/customer/account/' );

		wp_safe_redirect( $target );
		$this->terminate();
	}

	private function render_login_form( ?string $error = null, string $redirect_path = '' ): CustomerPageResult {
		$redirect_field = '' !== $redirect_path
			? '<input type="hidden" name="' . esc_attr( self::LOGIN_REDIRECT_FIELD ) . '" value="' . esc_attr( home_url( $redirect_path ) ) . '">'
			: '';

		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpr_login', '_wpnonce', true, false ) . '
				' . $redirect_field . '
				<p><label>' . esc_html__( 'Email address', 'wp-reconnaissance' ) . '<br><input type="email" name="email" required></label></p>
				<p><label>' . esc_html__( 'Password', 'wp-reconnaissance' ) . '<br><input type="password" name="password" required></label></p>
				<p><button type="submit">' . esc_html__( 'Sign in', 'wp-reconnaissance' ) . '</button></p>
			</form>
			<p><a href="' . esc_url( home_url( '/customer/forgot-password/' ) ) . '">' . esc_html__( 'Forgotten your password?', 'wp-reconnaissance' ) . '</a></p>
			<p><a href="' . esc_url( home_url( '/customer/register/' ) ) . '">' . esc_html__( 'Create an account', 'wp-reconnaissance' ) . '</a></p>';

		return $this->render_result( __( 'Sign in', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Forgot / reset password
	// -----------------------------------------------------------------------------------

	private function handle_forgot_password(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_forgot_password_form();
		}

		$generic_notice = __( 'If an account exists for that address, we have sent password reset instructions.', 'wp-reconnaissance' );

		if ( ! $this->verify_nonce( 'wpr_forgot_password' ) || ! $this->rate_limiter->allow( 'forgot_password', $this->rate_limiter->client_ip(), 5, HOUR_IN_SECONDS ) ) {
			return $this->render_result( __( 'Forgotten password', 'wp-reconnaissance' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
		}

		$email = $this->post_field( 'email' );
		$token = ( new PasswordResetService() )->request( $email );

		if ( null !== $token ) {
			$account = ( new CustomerAccountRepository() )->find_by_email( $email );

			if ( null !== $account ) {
				$this->send_password_reset_email( $account, $token );
			}
		}

		return $this->render_result( __( 'Forgotten password', 'wp-reconnaissance' ), '<p>' . esc_html( $generic_notice ) . '</p>' );
	}

	private function render_forgot_password_form(): CustomerPageResult {
		$body = '
			<form method="post">
				' . wp_nonce_field( 'wpr_forgot_password', '_wpnonce', true, false ) . '
				<p><label>' . esc_html__( 'Email address', 'wp-reconnaissance' ) . '<br><input type="email" name="email" required></label></p>
				<p><button type="submit">' . esc_html__( 'Send reset instructions', 'wp-reconnaissance' ) . '</button></p>
			</form>';

		return $this->render_result( __( 'Forgotten password', 'wp-reconnaissance' ), $body );
	}

	private function handle_reset_password(): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_reset_password_screen();
		}

		if ( ! $this->verify_nonce( 'wpr_reset_password' ) ) {
			return $this->render_result( __( 'Reset password', 'wp-reconnaissance' ), '<p>' . esc_html__( 'This link is invalid or has expired.', 'wp-reconnaissance' ) . '</p>' );
		}

		$token        = $this->post_field( 'token' );
		$password     = $this->post_field( 'password' );
		$confirmation = $this->post_field( 'password_confirmation' );

		if ( $password !== $confirmation ) {
			return $this->render_reset_password_form( $token, __( 'Password and confirmation do not match.', 'wp-reconnaissance' ) );
		}

		try {
			$succeeded = ( new PasswordResetService() )->reset( $token, $password );
		} catch ( \InvalidArgumentException $exception ) {
			return $this->render_reset_password_form( $token, $exception->getMessage() );
		}

		$body = $succeeded
			? '<p>' . esc_html__( 'Your password has been updated. You can now sign in.', 'wp-reconnaissance' ) . '</p><p><a href="' . esc_url( home_url( '/customer/login/' ) ) . '">' . esc_html__( 'Sign in', 'wp-reconnaissance' ) . '</a></p>'
			: '<p>' . esc_html__( 'This link is invalid or has expired.', 'wp-reconnaissance' ) . '</p>';

		return $this->render_result( __( 'Reset password', 'wp-reconnaissance' ), $body );
	}

	/**
	 * The GET-only view: the token-check + form, with no `is_post()` branching - reused by
	 * {@see handle_reset_password()}'s own GET branch and by the shortcode-rendering path
	 * ({@see render_customer_shortcode()}), which must never re-run POST detection based on the
	 * request's overall method (a different shortcode's form on the same themed page may be what
	 * was actually submitted - see render_customer_shortcode()'s docblock).
	 */
	private function render_reset_password_screen(): CustomerPageResult {
		$token = $this->get_field( 'token' );

		if ( '' === $token ) {
			return $this->render_result( __( 'Reset password', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No reset token was supplied.', 'wp-reconnaissance' ) . '</p>' );
		}

		return $this->render_reset_password_form( $token );
	}

	private function render_reset_password_form( string $token, ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error ) . '
			<form method="post">
				' . wp_nonce_field( 'wpr_reset_password', '_wpnonce', true, false ) . '
				<input type="hidden" name="token" value="' . esc_attr( $token ) . '">
				<p><label>' . esc_html__( 'New password', 'wp-reconnaissance' ) . '<br><input type="password" name="password" required minlength="12"></label></p>
				<p><label>' . esc_html__( 'Confirm new password', 'wp-reconnaissance' ) . '<br><input type="password" name="password_confirmation" required minlength="12"></label></p>
				<p><button type="submit">' . esc_html__( 'Update password', 'wp-reconnaissance' ) . '</button></p>
			</form>';

		return $this->render_result( __( 'Reset password', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Account
	// -----------------------------------------------------------------------------------

	private function handle_account(): CustomerPageResult {
		return $this->build_account_result( $this->require_customer_account() );
	}

	private function build_account_result( CustomerAccount $account ): CustomerPageResult {
		if ( 'logout' === $this->get_field( 'wpr_action' ) && $this->verify_nonce( 'wpr_logout', '_wpnonce', 'GET' ) ) {
			wp_logout();
			wp_safe_redirect( home_url( '/customer/login/' ) );
			$this->terminate();
		}

		if ( $this->is_post() ) {
			match ( $this->post_field( 'wpr_action' ) ) {
				'start_domain_verification' => $this->handle_start_domain_verification( $account ),
				'check_domain_verification' => $this->handle_check_domain_verification( $account ),
				default => null,
			};
		}

		return $this->render_account_dashboard( $account );
	}

	/**
	 * The GET-only dashboard view, with no `is_post()`/logout branching - reused by
	 * {@see build_account_result()}'s own tail and by the shortcode-rendering path
	 * ({@see render_customer_shortcode()}). The "Sign out" link still points at the raw
	 * `/customer/account/?wpr_action=logout` URL regardless of context - logging out always
	 * lands on the plain, unthemed login page, which is an acceptable UX wrinkle Section 20's
	 * plan deliberately left as-is rather than threading redirect-target logic through a GET link.
	 */
	private function render_account_dashboard( CustomerAccount $account ): CustomerPageResult {
		$logout_url = wp_nonce_url( home_url( '/customer/account/?wpr_action=logout' ), 'wpr_logout' );

		$body = '
			<p>' . esc_html__( 'Name', 'wp-reconnaissance' ) . ': ' . esc_html( trim( "{$account->given_name} {$account->family_name}" ) ) . '</p>
			<p>' . esc_html__( 'Email', 'wp-reconnaissance' ) . ': ' . esc_html( $account->email ) . '</p>
			<p>' . esc_html__( 'Account status', 'wp-reconnaissance' ) . ': ' . esc_html( $account->status->value ) . '</p>
			<p><a href="' . esc_url( $logout_url ) . '">' . esc_html__( 'Sign out', 'wp-reconnaissance' ) . '</a></p>'
			. $this->render_dashboard_summary( $account->organisation_id );

		return $this->render_result( __( 'Your account', 'wp-reconnaissance' ), $body );
	}

	/**
	 * The dashboard's assessment/task overview, per Section 20.1: "active job progress, latest
	 * report, highest-priority open tasks".
	 */
	private function render_dashboard_summary( int $organisation_id ): string {
		$scopes = $this->scopes->find_by_organisation( $organisation_id );

		if ( array() === $scopes ) {
			return '<h2>' . esc_html__( 'Your domains', 'wp-reconnaissance' ) . '</h2><p>' . esc_html__( 'No domains have been added to your organisation yet.', 'wp-reconnaissance' ) . '</p>';
		}

		$rows = '';
		foreach ( $scopes as $scope ) {
			$latest_report = $this->reports->find_latest_by_scope( (int) $scope->id );
			$report_cell   = null !== $latest_report
				? '<a href="' . esc_url( add_query_arg( 'id', (int) $latest_report->id, home_url( '/customer/reports/' ) ) ) . '">' . esc_html__( 'View latest report', 'wp-reconnaissance' ) . '</a>'
				: esc_html__( 'No report yet', 'wp-reconnaissance' );

			$rows .= '<tr><td>' . esc_html( $scope->domain_display ) . '</td><td>' . esc_html( ucfirst( $scope->authorisation_status ) ) . '</td><td>' . $report_cell . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $report_cell is built from esc_url()/esc_html() fragments above.
		}

		$verification_sections = '';
		foreach ( $scopes as $scope ) {
			if ( 'authorised' === $scope->authorisation_status ) {
				continue;
			}

			$verification_sections .= $this->domain_verification_section( $scope );
		}

		$open_by_priority = $this->tasks->count_open_by_priority( $organisation_id );
		$priority_summary = '';
		foreach ( $open_by_priority as $band => $count ) {
			if ( $count > 0 ) {
				$priority_summary .= '<li>' . esc_html( strtoupper( $band ) ) . ': ' . esc_html( (string) $count ) . '</li>';
			}
		}

		$tasks_url = esc_url( home_url( '/customer/tasks/' ) );

		return '<h2>' . esc_html__( 'Your domains', 'wp-reconnaissance' ) . '</h2>'
			. '<table><thead><tr><th>' . esc_html__( 'Domain', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Authorisation', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Latest report', 'wp-reconnaissance' ) . '</th></tr></thead><tbody>' . $rows . '</tbody></table>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rows is built from esc_*()-escaped fragments above.
			. $verification_sections // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- domain_verification_section() only emits esc_*()-escaped fragments and wp_nonce_field() output.
			. '<h2>' . esc_html__( 'Open remediation tasks by priority', 'wp-reconnaissance' ) . '</h2>'
			. ( '' !== $priority_summary ? '<ul>' . $priority_summary . '</ul>' : '<p>' . esc_html__( 'No open remediation tasks.', 'wp-reconnaissance' ) . '</p>' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $priority_summary is built from esc_html()-escaped fragments above.
			. '<p><a href="' . $tasks_url . '">' . esc_html__( 'View all remediation tasks', 'wp-reconnaissance' ) . '</a></p>';
	}

	/**
	 * A self-service DNS TXT verification block for one not-yet-authorised scope, mirroring the
	 * admin Scopes screen's equivalent - see
	 * {@see \Alltime\WPReconnaissance\Verification\DomainVerificationService}.
	 */
	private function domain_verification_section( Scope $scope ): string {
		/* translators: %s: the domain awaiting verification */
		$heading = sprintf( __( 'Verify %s', 'wp-reconnaissance' ), $scope->domain_display );
		$html    = '<h3>' . esc_html( $heading ) . '</h3>';

		if ( null === $scope->domain_verification_secret_hash ) {
			$html .= '<p>' . esc_html__( 'Generate a verification code to prove you control this domain via DNS - once verified, it is authorised automatically.', 'wp-reconnaissance' ) . '</p>';
		} else {
			$txt_value = $this->domain_verification->txt_record_value( $scope->domain_verification_secret_hash, $scope->domain_verification_requested_at );
			$html     .= '<p>' . esc_html__( 'Publish this TXT record on the domain itself (not a subdomain), then check back once it has propagated:', 'wp-reconnaissance' ) . '</p>'
				. '<p><code style="user-select:all">' . esc_html( $scope->domain_ascii ) . ' TXT "' . esc_html( $txt_value ) . '"</code></p>';

			if ( $this->domain_verification->is_verification_window_expired( $scope ) ) {
				$html .= '<p>' . esc_html__( 'The verification window for this code has expired. Generate a new one below once the record is in place.', 'wp-reconnaissance' ) . '</p>';
			}
		}

		$html .= '<form method="post" style="display:inline-block;margin-right:8px">'
			. wp_nonce_field( 'wpr_start_domain_verification', '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_action" value="start_domain_verification">'
			. '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope->id ) . '">'
			. '<button type="submit">' . esc_html__( 'Generate verification code', 'wp-reconnaissance' ) . '</button>'
			. '</form>';

		if ( 'pending' === $scope->domain_verification_status ) {
			$html .= '<form method="post" style="display:inline-block">'
				. wp_nonce_field( 'wpr_check_domain_verification', '_wpnonce', true, false )
				. '<input type="hidden" name="wpr_action" value="check_domain_verification">'
				. '<input type="hidden" name="scope_id" value="' . esc_attr( (string) $scope->id ) . '">'
				. '<button type="submit">' . esc_html__( 'Check now', 'wp-reconnaissance' ) . '</button>'
				. '</form>';
		}

		return $html;
	}

	/**
	 * Confirms $scope_id both exists and belongs to $account's own organisation, before any
	 * verification action acts on it - a customer must never be able to trigger or check
	 * verification for a scope that isn't theirs. Deliberately returns null (silent rejection,
	 * same "no information leak" posture as {@see handle_register()}) rather than distinguishing
	 * "not found" from "not yours".
	 */
	private function customers_own_scope( int $scope_id, CustomerAccount $account ): ?Scope {
		$scope = $this->scopes->find( $scope_id );

		return ( null !== $scope && $scope->organisation_id === $account->organisation_id ) ? $scope : null;
	}

	private function handle_start_domain_verification( CustomerAccount $account ): void {
		if ( ! $this->verify_nonce( 'wpr_start_domain_verification' ) ) {
			wp_safe_redirect( $this->redirect_target( 'account' ) );
			$this->terminate();
		}

		$scope = $this->customers_own_scope( (int) $this->post_field( 'scope_id' ), $account );

		// A stuck database upgrade or a genuine database failure (Section 7/8) leaves the
		// challenge ungenerated for a later retry rather than surfacing upgrade/database detail to
		// the customer - same "no information leak" posture as the plan-limit catch below.
		if ( null !== $scope ) {
			try {
				$this->domain_verification->generate_challenge( $scope->id, $account->user_id, 'customer' );
			} catch ( SchemaNotReadyException | ScopeRepositoryException ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- see comment above.
			}
		}

		wp_safe_redirect( $this->redirect_target( 'account' ) );
		$this->terminate();
	}

	private function handle_check_domain_verification( CustomerAccount $account ): void {
		if ( ! $this->verify_nonce( 'wpr_check_domain_verification' )
			|| ! $this->rate_limiter->allow( 'domain_verification_check', (string) $account->user_id, 10, HOUR_IN_SECONDS ) ) {
			wp_safe_redirect( $this->redirect_target( 'account' ) );
			$this->terminate();
		}

		$scope = $this->customers_own_scope( (int) $this->post_field( 'scope_id' ), $account );

		// A plan limit, a stuck database upgrade, or a genuine database failure (Section 7/8)
		// leaves the challenge pending for a later retry rather than surfacing plan/billing or
		// database detail to the customer.
		if ( null !== $scope ) {
			try {
				$this->domain_verification->check( $scope, 'customer' );
			} catch ( PlanLimitException | SchemaNotReadyException | ScopeRepositoryException ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- see comment above.
			}
		}

		wp_safe_redirect( $this->redirect_target( 'account' ) );
		$this->terminate();
	}

	// -----------------------------------------------------------------------------------
	// Security (Section 20)
	// -----------------------------------------------------------------------------------

	private function handle_security(): CustomerPageResult {
		return $this->build_security_result( $this->require_customer_account() );
	}

	private function build_security_result( CustomerAccount $account ): CustomerPageResult {
		if ( ! $this->is_post() ) {
			return $this->render_security_screen( $account );
		}

		return match ( $this->post_field( 'wpr_action' ) ) {
			'change_password' => $this->handle_change_password( $account ),
			'sign_out_other_sessions' => $this->handle_sign_out_other_sessions( $account ),
			default => $this->render_security_screen( $account ),
		};
	}

	private function handle_change_password( CustomerAccount $account ): CustomerPageResult {
		if ( ! $this->verify_nonce( 'wpr_change_password' ) || ! $this->rate_limiter->allow( 'change_password', (string) $account->user_id, 10, HOUR_IN_SECONDS ) ) {
			return $this->render_security_screen( $account, __( 'Your session expired or too many attempts were made; please try again shortly.', 'wp-reconnaissance' ) );
		}

		$new_password = $this->post_field( 'new_password' );

		if ( $new_password !== $this->post_field( 'new_password_confirmation' ) ) {
			return $this->render_security_screen( $account, __( 'New password and confirmation do not match.', 'wp-reconnaissance' ) );
		}

		try {
			( new AccountSecurityService() )->change_password( $account->user_id, $this->post_field( 'current_password' ), $new_password );
		} catch ( \InvalidArgumentException $exception ) {
			return $this->render_security_screen( $account, $exception->getMessage() );
		}

		wp_safe_redirect( $this->redirect_target( 'security' ) );
		$this->terminate();
	}

	private function handle_sign_out_other_sessions( CustomerAccount $account ): CustomerPageResult {
		if ( ! $this->verify_nonce( 'wpr_sign_out_other_sessions' ) ) {
			wp_safe_redirect( $this->redirect_target( 'security' ) );
			$this->terminate();
		}

		( new AccountSecurityService() )->sign_out_other_sessions( $account->user_id );

		wp_safe_redirect( $this->redirect_target( 'security' ) );
		$this->terminate();
	}

	/**
	 * The GET-only view, with no `is_post()` branching - reused by {@see build_security_result()}'s
	 * own tail and by the shortcode-rendering path ({@see render_customer_shortcode()}), for the
	 * same reason as {@see render_reset_password_screen()}.
	 */
	private function render_security_screen( CustomerAccount $account, ?string $error = null ): CustomerPageResult {
		$body = $this->error_html( $error );

		$body .= '<h2>' . esc_html__( 'Change password', 'wp-reconnaissance' ) . '</h2>'
			. '<form method="post">'
			. wp_nonce_field( 'wpr_change_password', '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_action" value="change_password">'
			. '<p><label>' . esc_html__( 'Current password', 'wp-reconnaissance' ) . '<br><input type="password" name="current_password" required></label></p>'
			. '<p><label>' . esc_html__( 'New password', 'wp-reconnaissance' ) . '<br><input type="password" name="new_password" required minlength="12"></label></p>'
			. '<p><label>' . esc_html__( 'Confirm new password', 'wp-reconnaissance' ) . '<br><input type="password" name="new_password_confirmation" required minlength="12"></label></p>'
			. '<p><button type="submit">' . esc_html__( 'Update password', 'wp-reconnaissance' ) . '</button></p>'
			. '</form>';

		$body .= '<h2>' . esc_html__( 'Sessions', 'wp-reconnaissance' ) . '</h2>'
			. '<p>' . esc_html__( 'If you believe your account has been signed in somewhere you do not recognise, sign out of every other session while keeping this one.', 'wp-reconnaissance' ) . '</p>'
			. '<form method="post">'
			. wp_nonce_field( 'wpr_sign_out_other_sessions', '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_action" value="sign_out_other_sessions">'
			. '<p><button type="submit">' . esc_html__( 'Sign out of all other sessions', 'wp-reconnaissance' ) . '</button></p>'
			. '</form>';

		return $this->render_result( __( 'Security', 'wp-reconnaissance' ), $body );
	}

	// -----------------------------------------------------------------------------------
	// Privacy centre (Section 26.3)
	// -----------------------------------------------------------------------------------

	private function handle_privacy(): CustomerPageResult {
		return $this->build_privacy_result( $this->require_customer_account() );
	}

	private function build_privacy_result( CustomerAccount $account ): CustomerPageResult {
		if ( 'download' === $this->get_field( 'wpr_action' ) ) {
			$this->render_privacy_data_download( $account );
		}

		if ( ! $this->is_post() ) {
			return $this->render_privacy_centre( $account );
		}

		return match ( $this->post_field( 'wpr_action' ) ) {
			'toggle_marketing' => $this->handle_toggle_marketing( $account ),
			'set_notification_frequency' => $this->handle_set_notification_frequency( $account ),
			'submit_request' => $this->handle_submit_privacy_request( $account ),
			'cancel_request' => $this->handle_cancel_privacy_request( $account ),
			default => $this->render_privacy_centre( $account ),
		};
	}

	/**
	 * "Download personal data" (Section 26.3) - a direct, self-service JSON export of the
	 * customer's own linked data. Bypasses {@see CustomerPageResult} entirely: this response is a
	 * file download, not an HTML page - it terminates the request itself rather than falling
	 * through to {@see dispatch()}'s own trailing terminate(), since a caller further up (like a
	 * future shortcode-rendering path) must never treat this as "produced a body to embed".
	 */
	private function render_privacy_data_download( CustomerAccount $account ): void {
		$data = ( new PersonalDataLocator() )->locate( $account->email );

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wpr-personal-data.json"' );
		echo wp_json_encode( $data, JSON_PRETTY_PRINT );
		$this->terminate();
	}

	private function handle_toggle_marketing( CustomerAccount $account ): CustomerPageResult {
		if ( ! $this->verify_nonce( 'wpr_privacy_marketing' ) ) {
			return $this->render_privacy_centre( $account, __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		( new CustomerAccountRepository() )->set_marketing_consent( $account->user_id, $this->post_checked( 'marketing_consent' ) );

		wp_safe_redirect( $this->redirect_target( 'privacy' ) );
		$this->terminate();
	}

	private function handle_set_notification_frequency( CustomerAccount $account ): CustomerPageResult {
		if ( ! $this->verify_nonce( 'wpr_notification_frequency' ) ) {
			return $this->render_privacy_centre( $account, __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		$frequency = NotificationFrequency::tryFrom( $this->post_field( 'notification_frequency' ) ) ?? NotificationFrequency::Immediate;

		( new CustomerAccountRepository() )->set_notification_frequency( $account->user_id, $frequency );

		wp_safe_redirect( $this->redirect_target( 'privacy' ) );
		$this->terminate();
	}

	private function handle_submit_privacy_request( CustomerAccount $account ): CustomerPageResult {
		if ( ! $this->verify_nonce( 'wpr_privacy_request' ) || ! $this->rate_limiter->allow( 'privacy_request', (string) $account->user_id, 5, HOUR_IN_SECONDS ) ) {
			return $this->render_privacy_centre( $account, __( 'Your session expired or too many requests were submitted; please try again shortly.', 'wp-reconnaissance' ) );
		}

		$right_type = PrivacyRightType::tryFrom( $this->post_field( 'right_type' ) );

		if ( null === $right_type || PrivacyRightType::MarketingWithdrawal === $right_type ) {
			return $this->render_privacy_centre( $account, __( 'Please choose a valid request type.', 'wp-reconnaissance' ) );
		}

		try {
			( new PrivacyRequestService() )->submit( $account->email, $right_type, $this->post_field( 'details' ), 'portal', $account->user_id );
		} catch ( PrivacyRequestRepositoryException $exception ) {
			return $this->render_privacy_centre( $account, $exception->getMessage() );
		}

		wp_safe_redirect( $this->redirect_target( 'privacy' ) );
		$this->terminate();
	}

	private function handle_cancel_privacy_request( CustomerAccount $account ): CustomerPageResult {
		if ( ! $this->verify_nonce( 'wpr_privacy_cancel' ) ) {
			return $this->render_privacy_centre( $account, __( 'Your session expired; please try again.', 'wp-reconnaissance' ) );
		}

		try {
			( new PrivacyRequestService() )->cancel( (int) $this->post_field( 'request_id' ), $account->user_id );
		} catch ( \InvalidArgumentException | PrivacyRequestRepositoryException $exception ) {
			return $this->render_privacy_centre( $account, $exception->getMessage() );
		}

		wp_safe_redirect( $this->redirect_target( 'privacy' ) );
		$this->terminate();
	}

	private function render_privacy_centre( CustomerAccount $account, ?string $error = null ): CustomerPageResult {
		$has_marketing = ( new CustomerAccountRepository() )->has_marketing_consent( $account->email );
		$own_requests  = ( new PrivacyRequestRepository() )->find_by_user( $account->user_id );

		$body = $this->error_html( $error );

		$body .= '<h2>' . esc_html__( 'Your information', 'wp-reconnaissance' ) . '</h2>'
			. '<p><a href="' . esc_url( home_url( '/customer/privacy/?wpr_action=download' ) ) . '">' . esc_html__( 'Download my personal data (JSON)', 'wp-reconnaissance' ) . '</a></p>'
			. $this->render_own_data_summary( $account->email ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_own_data_summary() only emits esc_*()-escaped fragments.

		$body .= '<h2>' . esc_html__( 'Communication preferences', 'wp-reconnaissance' ) . '</h2>'
			. '<form method="post">'
			. wp_nonce_field( 'wpr_privacy_marketing', '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_action" value="toggle_marketing">'
			. '<p><label><input type="checkbox" name="marketing_consent" value="1"' . checked( $has_marketing, true, false ) . '> ' . esc_html__( 'I would like to receive occasional marketing updates.', 'wp-reconnaissance' ) . '</label></p>'
			. '<p><button type="submit">' . esc_html__( 'Save preference', 'wp-reconnaissance' ) . '</button></p>'
			. '</form>';

		$frequency = ( new CustomerAccountRepository() )->get_notification_frequency( $account->user_id );

		$body .= '<h2>' . esc_html__( 'Notification delivery', 'wp-reconnaissance' ) . '</h2>'
			. '<p>' . esc_html__( 'Choose whether assessment notifications (new findings, reports ready, task reminders and similar) arrive as they happen, or once a day as a single combined email.', 'wp-reconnaissance' ) . '</p>'
			. '<form method="post">'
			. wp_nonce_field( 'wpr_notification_frequency', '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_action" value="set_notification_frequency">'
			. '<p><label><input type="radio" name="notification_frequency" value="' . esc_attr( NotificationFrequency::Immediate->value ) . '"' . checked( $frequency->value, NotificationFrequency::Immediate->value, false ) . '> ' . esc_html__( 'Send each notification as it happens', 'wp-reconnaissance' ) . '</label></p>'
			. '<p><label><input type="radio" name="notification_frequency" value="' . esc_attr( NotificationFrequency::DailyDigest->value ) . '"' . checked( $frequency->value, NotificationFrequency::DailyDigest->value, false ) . '> ' . esc_html__( 'Combine them into one daily digest email', 'wp-reconnaissance' ) . '</label></p>'
			. '<p><button type="submit">' . esc_html__( 'Save preference', 'wp-reconnaissance' ) . '</button></p>'
			. '</form>';

		$body .= '<h2>' . esc_html__( 'Submit a privacy request', 'wp-reconnaissance' ) . '</h2>'
			. '<p>' . esc_html__( 'Use this for correcting your data, restricting or objecting to processing, requesting a portable export, or closing your account. To withdraw marketing consent, use the preference above instead.', 'wp-reconnaissance' ) . '</p>'
			. '<form method="post">'
			. wp_nonce_field( 'wpr_privacy_request', '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_action" value="submit_request">'
			. '<p><label>' . esc_html__( 'Request type', 'wp-reconnaissance' ) . '<br><select name="right_type">' . $this->right_type_options() . '</select></label></p>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- right_type_options() only emits esc_attr()/esc_html()-escaped <option> markup.
			. '<p><label>' . esc_html__( 'Details', 'wp-reconnaissance' ) . '<br><textarea name="details" rows="4" class="large-text"></textarea></label></p>'
			. '<p><button type="submit">' . esc_html__( 'Submit request', 'wp-reconnaissance' ) . '</button></p>'
			. '</form>';

		$body .= '<h2>' . esc_html__( 'Your privacy requests', 'wp-reconnaissance' ) . '</h2>' . $this->render_own_privacy_requests( $own_requests ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_own_privacy_requests() only emits esc_*()-escaped fragments and wp_nonce_field() output.

		$body .= '<h2>' . esc_html__( 'Contact the privacy team', 'wp-reconnaissance' ) . '</h2>'
			. '<p>' . esc_html__( 'Alltime Technologies Ltd', 'wp-reconnaissance' ) . '<br>'
			. esc_html__( 'Email:', 'wp-reconnaissance' ) . ' <a href="mailto:privacy@alltimetech.co.uk">privacy@alltimetech.co.uk</a></p>';

		return $this->render_result( __( 'Privacy', 'wp-reconnaissance' ), $body );
	}

	private function right_type_options(): string {
		$options = '';

		foreach ( PrivacyRightType::cases() as $right_type ) {
			if ( PrivacyRightType::MarketingWithdrawal === $right_type ) {
				continue;
			}

			$options .= '<option value="' . esc_attr( $right_type->value ) . '">' . esc_html( $right_type->label() ) . '</option>';
		}

		return $options;
	}

	private function render_own_data_summary( string $email ): string {
		$groups = ( new PersonalDataLocator() )->locate( $email );

		if ( array() === $groups ) {
			return '<p>' . esc_html__( 'No linked data was found.', 'wp-reconnaissance' ) . '</p>';
		}

		$counts = array();
		foreach ( $groups as $group ) {
			$counts[ $group['group_label'] ] = ( $counts[ $group['group_label'] ] ?? 0 ) + 1;
		}

		$rows = '';
		foreach ( $counts as $label => $count ) {
			$rows .= '<li>' . esc_html( $label ) . ': ' . esc_html( (string) $count ) . '</li>';
		}

		return '<ul>' . $rows . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rows is built from esc_html()-escaped fragments above.
	}

	/**
	 * @param PrivacyRequest[] $requests
	 */
	private function render_own_privacy_requests( array $requests ): string {
		if ( array() === $requests ) {
			return '<p>' . esc_html__( 'You have not submitted any privacy requests.', 'wp-reconnaissance' ) . '</p>';
		}

		$rows = '';
		foreach ( $requests as $request ) {
			$cancel = $request->status->is_open()
				? '<form method="post" style="display:inline">' . wp_nonce_field( 'wpr_privacy_cancel', '_wpnonce', true, false ) . '<input type="hidden" name="wpr_action" value="cancel_request"><input type="hidden" name="request_id" value="' . esc_attr( (string) $request->id ) . '"><button type="submit" class="button">' . esc_html__( 'Cancel', 'wp-reconnaissance' ) . '</button></form>'
				: '';

			$rows .= '<tr>'
				. '<td>' . esc_html( $request->right_type->label() ) . '</td>'
				. '<td>' . esc_html( ucwords( str_replace( '_', ' ', $request->status->value ) ) ) . '</td>'
				. '<td>' . esc_html( $request->due_at->format( 'Y-m-d' ) ) . '</td>'
				. '<td>' . $cancel . '</td>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $cancel is built from wp_nonce_field()/esc_*()-escaped fragments above.
				. '</tr>';
		}

		return '<table><thead><tr>'
			. '<th>' . esc_html__( 'Type', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Due', 'wp-reconnaissance' ) . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>' . $rows . '</tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rows is built from esc_*()-escaped fragments and wp_nonce_field() output above.
	}

	// -----------------------------------------------------------------------------------
	// Reports (customer, read-only, own organisation only)
	// -----------------------------------------------------------------------------------

	private function handle_reports(): CustomerPageResult {
		return $this->build_reports_result( $this->require_customer_account() );
	}

	private function build_reports_result( CustomerAccount $account ): CustomerPageResult {
		$id = $this->get_field( 'id' );

		if ( '' !== $id && 'download' === $this->get_field( 'wpr_action' ) ) {
			$this->render_report_pdf_download( $account->organisation_id, (int) $id, $this->get_field( 'token' ) );
		}

		return $this->render_reports_view( $account );
	}

	/**
	 * The GET-only view (a single report, or the report list) - deliberately excludes the
	 * PDF-download branch above, reused by {@see build_reports_result()}'s own tail and by the
	 * shortcode-rendering path ({@see render_customer_shortcode()}). A file download can't be
	 * embedded page content (it needs its own `header()`/exit response, not a string to insert
	 * into `the_content`), so the shortcode path calls this directly instead of
	 * build_reports_result(), skipping the download branch entirely rather than attempting and
	 * failing it - `header()` calls after theme output has already started would silently fail.
	 */
	private function render_reports_view( CustomerAccount $account ): CustomerPageResult {
		$id = $this->get_field( 'id' );

		if ( '' !== $id ) {
			return $this->render_single_report( $account->organisation_id, (int) $id );
		}

		$reports = $this->reports->find_latest_by_organisation( $account->organisation_id );

		if ( array() === $reports ) {
			return $this->render_result( __( 'Your reports', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No reports have been issued yet.', 'wp-reconnaissance' ) . '</p>' );
		}

		$rows = '';
		foreach ( $reports as $report ) {
			$view_url = esc_url( add_query_arg( 'id', (int) $report->id, home_url( '/customer/reports/' ) ) );
			$rows    .= '<tr><td>' . esc_html( (string) $report->version ) . '</td><td>' . esc_html( $report->generated_at->format( 'Y-m-d' ) ) . '</td><td><a href="' . $view_url . '">' . esc_html__( 'View', 'wp-reconnaissance' ) . '</a></td></tr>';
		}

		$body = '<table><thead><tr><th>' . esc_html__( 'Version', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Date', 'wp-reconnaissance' ) . '</th><th></th></tr></thead><tbody>' . $rows . '</tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rows is built from esc_*()-escaped fragments above.

		return $this->render_result( __( 'Your reports', 'wp-reconnaissance' ), $body );
	}

	private function render_single_report( int $organisation_id, int $report_id ): CustomerPageResult {
		$report = $this->reports->find( $report_id );

		if ( null === $report || $report->organisation_id !== $organisation_id ) {
			return $this->render_result( __( 'Report', 'wp-reconnaissance' ), '<p>' . esc_html__( 'Report not found.', 'wp-reconnaissance' ) . '</p>' );
		}

		$download_url = esc_url(
			add_query_arg(
				array(
					'id'         => $report->id,
					'wpr_action' => 'download',
					'token'      => ( new ReportDownloadToken() )->create( $report->id ),
				),
				home_url( '/customer/reports/' )
			)
		);

		$body = $this->report_renderer->render( $report )
			. '<p><a href="' . $download_url . '">' . esc_html__( 'Download PDF', 'wp-reconnaissance' ) . '</a></p>'
			. $this->render_report_version_history( $report ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_report_version_history() only emits esc_*()-escaped fragments.

		return $this->render_result( __( 'Your report', 'wp-reconnaissance' ), $body );
	}

	/**
	 * Section 33's "issued report versions": every version issued for this report's scope, and -
	 * where an immediately-earlier version exists - a comparison summary of which findings are
	 * new or resolved since it, via {@see ReportComparator}.
	 */
	private function render_report_version_history( Report $report ): string {
		$versions = $this->reports->find_by_scope( $report->scope_id );

		if ( count( $versions ) < 2 ) {
			return '';
		}

		$rows = '';
		foreach ( $versions as $version ) {
			$view_url = esc_url( add_query_arg( 'id', (int) $version->id, home_url( '/customer/reports/' ) ) );
			$rows    .= '<tr><td>' . esc_html( (string) $version->version ) . '</td><td>' . esc_html( $version->generated_at->format( 'Y-m-d' ) ) . '</td><td><a href="' . $view_url . '">' . esc_html__( 'View', 'wp-reconnaissance' ) . '</a></td></tr>';
		}

		$html = '<h2>' . esc_html__( 'Version history', 'wp-reconnaissance' ) . '</h2>'
			. '<table><thead><tr><th>' . esc_html__( 'Version', 'wp-reconnaissance' ) . '</th><th>' . esc_html__( 'Date', 'wp-reconnaissance' ) . '</th><th></th></tr></thead><tbody>' . $rows . '</tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rows is built from esc_*()-escaped fragments above.

		$previous = null;
		foreach ( $versions as $version ) {
			if ( $version->version < $report->version && ( null === $previous || $version->version > $previous->version ) ) {
				$previous = $version;
			}
		}

		if ( null === $previous ) {
			return $html;
		}

		$comparison = ( new ReportComparator() )->compare( $previous, $report );

		if ( ! $comparison->has_changes() ) {
			return $html . '<p>' . esc_html__( 'No findings changed since your previous report.', 'wp-reconnaissance' ) . '</p>';
		}

		$html .= '<h3>' . sprintf(
			/* translators: %s: earlier report version number */
			esc_html__( 'What changed since version %s', 'wp-reconnaissance' ),
			esc_html( (string) $previous->version )
		) . '</h3>';

		$html .= $this->render_finding_comparison_list( __( 'New findings', 'wp-reconnaissance' ), $comparison->new_findings );
		$html .= $this->render_finding_comparison_list( __( 'Resolved findings', 'wp-reconnaissance' ), $comparison->resolved_findings );

		return $html;
	}

	/**
	 * @param array<int,array<string,mixed>> $findings
	 */
	private function render_finding_comparison_list( string $heading, array $findings ): string {
		if ( array() === $findings ) {
			return '';
		}

		$items = '';
		foreach ( $findings as $finding ) {
			$items .= '<li>' . esc_html( (string) ( $finding['title'] ?? $finding['rule_id'] ?? '' ) ) . '</li>';
		}

		return '<p><strong>' . esc_html( $heading ) . '</strong></p><ul>' . $items . '</ul>';
	}

	/**
	 * Serves the stored PDF for an issued report as a short-lived, authorised download (Section
	 * 21.2). The signed token is verified and the report must belong to the caller's own
	 * organisation before any bytes are sent; the file lives in protected storage and is never a
	 * public URL.
	 */
	private function render_report_pdf_download( int $organisation_id, int $report_id, string $token ): void {
		$report = $this->reports->find( $report_id );

		if ( null === $report || $report->organisation_id !== $organisation_id || ! ( new ReportDownloadToken() )->verify_for( $token, $report_id ) ) {
			wp_die( esc_html__( 'This download link is invalid or has expired.', 'wp-reconnaissance' ), '', array( 'response' => 403 ) );
		}

		$pdf = ( new ReportPdfService() )->retrieve_pdf( $report );

		if ( null === $pdf ) {
			wp_die( esc_html__( 'The PDF for this report is not ready yet. Please try again shortly.', 'wp-reconnaissance' ), '', array( 'response' => 404 ) );
		}

		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . esc_attr( 'wpr-report-' . $report->report_uuid . '.pdf' ) . '"' );
		header( 'Content-Length: ' . (string) strlen( $pdf ) );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw PDF bytes, not HTML; escaping would corrupt the file.
		$this->terminate();
	}

	// -----------------------------------------------------------------------------------
	// Remediation tasks (customer, own organisation only)
	// -----------------------------------------------------------------------------------

	private function handle_tasks(): CustomerPageResult {
		return $this->build_tasks_result( $this->require_customer_account() );
	}

	private function build_tasks_result( CustomerAccount $account ): CustomerPageResult {
		if ( $this->is_post() && 'update_task_notes' === $this->post_field( 'wpr_action' ) ) {
			$this->handle_update_task_notes( $account );
		}

		return $this->render_tasks_list( $account );
	}

	/**
	 * The GET-only listing view, with no `is_post()` branching - reused by
	 * {@see build_tasks_result()}'s own tail and by the shortcode-rendering path
	 * ({@see render_customer_shortcode()}), for the same reason as
	 * {@see render_reset_password_screen()}.
	 */
	private function render_tasks_list( CustomerAccount $account ): CustomerPageResult {
		$tasks = $this->tasks->find_by_organisation( $account->organisation_id );

		if ( array() === $tasks ) {
			return $this->render_result( __( 'Remediation tasks', 'wp-reconnaissance' ), '<p>' . esc_html__( 'No remediation tasks yet - run an assessment to generate a plan.', 'wp-reconnaissance' ) . '</p>' );
		}

		$rows = '';
		foreach ( $tasks as $task ) {
			$rows .= '<tr>'
				. '<td>' . esc_html( $task->priority_band->value ) . '</td>'
				. '<td>' . esc_html( $task->title ) . '</td>'
				. '<td>' . esc_html( ucwords( str_replace( '_', ' ', $task->technical_subject->value ) ) ) . '</td>'
				. '<td>' . esc_html( ucwords( str_replace( '_', ' ', $task->status->value ) ) ) . '</td>'
				. '<td>' . $this->render_task_notes_cell( $task ) . '</td>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_task_notes_cell() only emits esc_*()-escaped fragments and wp_nonce_field() output.
				. '</tr>';
		}

		$body = '<table><thead><tr>'
			. '<th>' . esc_html__( 'Priority', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Task', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Technical subject', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Status', 'wp-reconnaissance' ) . '</th>'
			. '<th>' . esc_html__( 'Your notes', 'wp-reconnaissance' ) . '</th>'
			. '</tr></thead><tbody>' . $rows . '</tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rows is built from esc_*()-escaped fragments above.

		return $this->render_result( __( 'Remediation tasks', 'wp-reconnaissance' ), $body );
	}

	/**
	 * Section 21.3 names "Customer notes" as a field distinct from operator-only "Alltime notes".
	 * A customer may update their own note and the task status (Section 34 item 21); target date
	 * and operator notes remain operator-only.
	 */
	private function render_task_notes_cell( RemediationTask $task ): string {
		$current = '' !== ( $task->customer_notes ?? '' )
			? '<p>' . esc_html( $task->customer_notes ) . '</p>'
			: '<p><em>' . esc_html__( 'No notes yet.', 'wp-reconnaissance' ) . '</em></p>';

		$status_options = '';
		foreach ( RemediationTaskStatus::cases() as $status ) {
			$selected        = $status === $task->status ? ' selected' : '';
			$status_options .= '<option value="' . esc_attr( $status->value ) . '"' . $selected . '>'
				. esc_html( ucwords( str_replace( '_', ' ', $status->value ) ) )
				. '</option>';
		}

		return $current . '<details><summary>' . esc_html__( 'Update task', 'wp-reconnaissance' ) . '</summary>'
			. '<form method="post">'
			. wp_nonce_field( 'wpr_update_task_notes', '_wpnonce', true, false )
			. '<input type="hidden" name="wpr_action" value="update_task_notes">'
			. '<input type="hidden" name="task_id" value="' . esc_attr( (string) $task->id ) . '">'
			. '<p><label>' . esc_html__( 'Status', 'wp-reconnaissance' ) . ' <select name="status">' . $status_options . '</select></label></p>'
			. '<p><textarea name="customer_notes" rows="3">' . esc_textarea( $task->customer_notes ?? '' ) . '</textarea></p>'
			. '<p><label><input type="checkbox" name="request_reminder" value="1"' . checked( $task->reminder_requested, true, false ) . '> '
			. esc_html__( "Email me a reminder when this task's target date approaches", 'wp-reconnaissance' )
			. '</label> <label>' . esc_html__( 'Remind me', 'wp-reconnaissance' ) . ' <select name="reminder_days_before">' . $this->reminder_days_before_options( $task->reminder_days_before ) . '</select> ' . esc_html__( 'days before', 'wp-reconnaissance' ) . '</label></p>'
			. '<p><button type="submit">' . esc_html__( 'Save', 'wp-reconnaissance' ) . '</button></p>'
			. '</form></details>';
	}

	private function handle_update_task_notes( CustomerAccount $account ): void {
		if ( ! $this->verify_nonce( 'wpr_update_task_notes' ) ) {
			wp_safe_redirect( $this->redirect_target( 'tasks' ) );
			$this->terminate();
		}

		$task_id = (int) $this->post_field( 'task_id' );
		$task    = $this->tasks->find( $task_id );

		if ( null !== $task && $task->organisation_id === $account->organisation_id ) {
			$notes       = isset( $_POST['customer_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['customer_notes'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified above via $this->verify_nonce().
			$status      = RemediationTaskStatus::tryFrom( $this->post_field( 'status' ) ) ?? $task->status;
			$days_before = (int) $this->post_field( 'reminder_days_before' );

			$this->tasks->update_status( $task_id, $status, '' !== $notes ? $notes : null, $task->operator_notes, $task->target_date );
			$this->tasks->set_reminder_preferences( $task_id, $this->post_checked( 'request_reminder' ), $days_before > 0 ? $days_before : null );
		}

		wp_safe_redirect( $this->redirect_target( 'tasks' ) );
		$this->terminate();
	}

	/**
	 * @return string HTML <option> elements for the reminder-lookahead select.
	 */
	private function reminder_days_before_options( ?int $current ): string {
		$options = '';

		foreach ( array( 1, 3, 7, 14, 30 ) as $days ) {
			$options .= '<option value="' . esc_attr( (string) $days ) . '"' . selected( $current ?? 7, $days, false ) . '>' . esc_html( (string) $days ) . '</option>';
		}

		return $options;
	}

	// -----------------------------------------------------------------------------------
	// Tool catalogue (Section 20.2)
	// -----------------------------------------------------------------------------------

	private function handle_tools(): CustomerPageResult {
		return $this->build_tools_result( $this->require_customer_account() );
	}

	private function build_tools_result( CustomerAccount $account ): CustomerPageResult {
		$scopes  = $this->scopes->find_by_organisation( $account->organisation_id );
		$contact = ContactPlatformDiscovery::resolve()?->get_contact_for_user( $account->user_id );

		$body = '';
		foreach ( $this->tool_registry->available() as $tool ) {
			$body .= '<div class="wpr-tool-card">'
				. '<h2>' . esc_html( $tool->name ) . '</h2>'
				. '<p>' . esc_html( $tool->description ) . '</p>'
				. '<p><em>' . esc_html( $tool->estimated_completion_behaviour ) . '</em></p>'
				. $this->render_tool_entitlement_summary( $tool->id, $contact?->id, $scopes ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_tool_entitlement_summary() only emits esc_*()-escaped fragments.
				. '</div>';
		}

		if ( '' === $body ) {
			$body = '<p>' . esc_html__( 'No tools are currently available.', 'wp-reconnaissance' ) . '</p>';
		}

		return $this->render_result( __( 'Tools', 'wp-reconnaissance' ), $body );
	}

	/**
	 * @param Scope[] $scopes
	 */
	private function render_tool_entitlement_summary( string $tool_id, ?int $contact_id, array $scopes ): string {
		if ( null === $contact_id || array() === $scopes ) {
			return '<p>' . esc_html__( 'Contact us to add a domain to your organisation and start an assessment.', 'wp-reconnaissance' ) . '</p>';
		}

		$rows = '';
		foreach ( $scopes as $scope ) {
			$decision = $this->entitlements->check( $contact_id, $tool_id, $scope->registrable_domain, organisation_id: $scope->organisation_id );
			$state    = $decision->allowed ? __( 'Available', 'wp-reconnaissance' ) : __( 'Already used', 'wp-reconnaissance' );
			$rows    .= '<li>' . esc_html( $scope->domain_display ) . ': ' . esc_html( $state ) . '</li>';
		}

		return '<ul>' . $rows . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rows is built from esc_html()-escaped fragments above.
	}

	/**
	 * Redirects to login and terminates the request unless the current user is a signed-in
	 * customer with a resolvable account; every route above except register/login/reset-password
	 * calls this first. Delegates the actual check to {@see require_customer_account_or_null()} so
	 * there is exactly one place that decides "who is the current customer".
	 */
	private function require_customer_account(): CustomerAccount {
		$account = $this->require_customer_account_or_null();

		if ( null === $account ) {
			wp_safe_redirect( home_url( '/customer/login/' ) );
			$this->terminate();
		}

		return $account;
	}

	/**
	 * The shortcode-safe counterpart to {@see require_customer_account()}: returns null instead of
	 * redirecting when the visitor isn't a signed-in customer with a resolvable account, rather
	 * than calling wp_safe_redirect(). A shortcode's own render callback runs during `the_content`
	 * - well after a theme has already started writing output - where a redirect would either warn
	 * and do nothing or corrupt the page; only a caller that owns the whole response (like
	 * {@see dispatch()}, via require_customer_account()) may redirect. Not yet called by anything
	 * in this class; the shortcode-rendering path that uses it lands in a follow-up change.
	 */
	private function require_customer_account_or_null(): ?CustomerAccount {
		if ( ! is_user_logged_in() || ! current_user_can( Capabilities::VIEW_ASSIGNED_ORG ) ) {
			return null;
		}

		return ( new CustomerAccountRepository() )->find( get_current_user_id() );
	}

	// -----------------------------------------------------------------------------------
	// Mail delivery (Section 22.5: queued, never sent inline from the request)
	// -----------------------------------------------------------------------------------

	private function send_verification_email( CustomerAccount $account, string $token ): void {
		$link = home_url( '/customer/verify-email/?token=' . rawurlencode( $token ) );

		$this->mail_queue->enqueue(
			new QueuedMessage(
				idempotency_key: 'verify_email:' . hash( 'sha256', $token ),
				recipient: $account->email,
				template: 'verify_email',
				purpose: MailPurpose::AccountSecurity,
				subject: __( 'Verify your email address', 'wp-reconnaissance' ),
				html_body: sprintf( '<p>Follow this link to verify your email address: <a href="%1$s">%1$s</a></p>', esc_url( $link ) )
			)
		);
	}

	private function send_password_reset_email( CustomerAccount $account, string $token ): void {
		$link = home_url( '/customer/reset-password/?token=' . rawurlencode( $token ) );

		$this->mail_queue->enqueue(
			new QueuedMessage(
				idempotency_key: 'password_reset:' . hash( 'sha256', $token ),
				recipient: $account->email,
				template: 'password_reset',
				purpose: MailPurpose::AccountSecurity,
				subject: __( 'Reset your password', 'wp-reconnaissance' ),
				html_body: sprintf( '<p>Follow this link to reset your password: <a href="%1$s">%1$s</a></p>', esc_url( $link ) )
			)
		);
	}

	// -----------------------------------------------------------------------------------
	// Shared helpers
	// -----------------------------------------------------------------------------------

	/**
	 * Every route/handler in this class ends a request with this, always immediately after
	 * wp_safe_redirect()/status_header() has already set the actual response - never anything
	 * production behaviour depends on beyond "stop here". Routed through one injected callable
	 * (mirroring {@see \Alltime\WPReconnaissance\Verification\DomainVerificationService}'s
	 * `$dns_query` seam) rather than a bare `exit;` at each call site, purely so a test can
	 * substitute a catchable signal instead of tearing down the PHPUnit process itself; every
	 * production code path still terminates exactly as before, since the class is `final` and so
	 * cannot be subclassed to override a method instead.
	 */
	private function terminate(): never {
		( $this->terminator )();

		// Only reached if $this->terminator returned normally instead of exiting/throwing (a
		// misbehaving override) - still guarantees this method's own `never` contract.
		exit;
	}

	private function render_result( string $title, string $body ): CustomerPageResult {
		return new CustomerPageResult( $title, $body );
	}

	private function error_html( ?string $error ): string {
		return null !== $error ? '<p role="alert">' . esc_html( $error ) . '</p>' : '';
	}

	private function is_post(): bool {
		return 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' );
	}

	private function post_field( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified by the caller before any $_POST field is read.
		return isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : '';
	}

	private function post_checked( string $name ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified by the caller before any $_POST field is read.
		return isset( $_POST[ $name ] ) && '' !== $_POST[ $name ];
	}

	/**
	 * The bot-challenge fields from the form submission, passed to the anti-abuse evaluation.
	 * Read-only in the adapter; never echoed back.
	 *
	 * @return array<string,mixed>
	 */
	private function post_captcha_input(): array {
		$input = array();

		foreach ( array( HoneypotCaptchaAdapter::HONEYPOT_FIELD, HoneypotCaptchaAdapter::STARTED_FIELD ) as $field ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified by the caller before any $_POST field is read.
			if ( isset( $_POST[ $field ] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified by the caller before any $_POST field is read.
				$input[ $field ] = wp_unslash( $_POST[ $field ] );
			}
		}

		return $input;
	}

	private function get_field( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only lookup routes (verify-email/reset-password token, logout confirmation); state-changing actions verify their own nonce separately.
		return isset( $_GET[ $name ] ) && is_string( $_GET[ $name ] ) ? sanitize_text_field( wp_unslash( $_GET[ $name ] ) ) : '';
	}

	private function verify_nonce( string $action, string $field = '_wpnonce', string $method = 'POST' ): bool {
		$source = 'GET' === $method ? $_GET : $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing -- this *is* the nonce verification helper.
		$nonce  = isset( $source[ $field ] ) && is_string( $source[ $field ] ) ? wp_unslash( $source[ $field ] ) : '';

		return '' !== $nonce && false !== wp_verify_nonce( $nonce, $action );
	}
}
