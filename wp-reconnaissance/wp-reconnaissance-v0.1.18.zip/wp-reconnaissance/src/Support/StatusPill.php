<?php
/**
 * Renders the small coloured status indicator ("pill") used consistently for anything that's
 * fundamentally a state - active/suspended, authorised/pending, verified/pending - across the
 * admin screens (ported from alltimeuk/wp-phishing's own StatusPill, adapted to this plugin's
 * wpr_/Alltime\WPReconnaissance conventions).
 *
 * The tones are deliberately generic (good/warn/bad/muted), not tied to any one domain concept
 * (organisation status, job status, finding severity) - each call site decides which tone a given
 * state maps to.
 *
 * @package Alltime\WPReconnaissance
 */

declare( strict_types = 1 );

namespace Alltime\WPReconnaissance\Support;

final class StatusPill {

	public const GOOD  = 'good';
	public const WARN  = 'warn';
	public const BAD   = 'bad';
	public const MUTED = 'muted';

	public static function render( string $label, string $tone ): string {
		return '<span class="wpr-pill wpr-pill--' . esc_attr( $tone ) . '">' . esc_html( $label ) . '</span>';
	}
}
