/**
 * Admin screen behaviour: the Settings screen's tab navigation (matching the nav-tab/data-tab
 * pattern WP Questionnaires already uses for its own Settings tabs), and the mail-provider
 * section's per-provider field toggle.
 *
 * The tab click handler scopes its panel/tab lookups to the clicked bar's own `.wpr-admin-wrap`
 * (ported from alltimeuk/wp-phishing's equivalent fix) rather than querying `.wpr-nav-tabs
 * .nav-tab`/`.wpr-tab-panel` globally across the whole page - harmless today since only one tabbed
 * screen (Settings) exists, but a global selector would incorrectly hide/deselect a second,
 * independent tab bar's own panels the day one is added elsewhere on the same screen.
 */
( function ( $ ) {
	'use strict';

	$( function () {
		$( document ).on( 'click', '.wpr-nav-tabs .nav-tab', function ( e ) {
			e.preventDefault();

			var tab = $( this ).data( 'tab' );
			var $scope = $( this ).closest( '.wpr-admin-wrap' );

			$scope.find( '.wpr-nav-tabs .nav-tab' ).removeClass( 'nav-tab-active' );
			$( this ).addClass( 'nav-tab-active' );

			$scope.find( '.wpr-tab-panel' ).addClass( 'wpr-hidden' );
			$scope.find( '#tab-' + tab ).removeClass( 'wpr-hidden' );

			if ( window.history && window.history.replaceState ) {
				var url = new URL( window.location.href );
				url.searchParams.set( 'tab', tab );
				window.history.replaceState( null, '', url.toString() );
			}
		} );

		// Deep-linking: admin.php?page=wpr-settings&tab=shortcodes opens directly
		// on that tab.
		var initial = new URLSearchParams( window.location.search ).get( 'tab' );

		if ( initial && $( '#tab-' + initial ).length ) {
			$( '.wpr-nav-tabs .nav-tab[data-tab="' + initial + '"]' ).trigger( 'click' );
		}

		// Mail provider section: only the selected provider's own fields (Gmail/SES/M365) are
		// shown - the server already renders the correct initial visibility from the saved
		// option, so this only needs to react to the <select> changing, not run once unprompted
		// on load too (unlike the tab-navigation deep-link above, there's no URL state to restore
		// here).
		$( document ).on( 'change', '#wpr_mail_provider', function () {
			var selected = $( this ).val();

			$( '.wpr-mail-provider-rows' ).addClass( 'wpr-hidden' );
			$( '#wpr-mail-provider-rows-' + selected ).removeClass( 'wpr-hidden' );
		} );
	} );
}( jQuery ) );
