<?php if ( ! defined( 'ABSPATH' ) ) exit;
// $submission is set by the page_submissions() dispatcher.
/** @var object $submission */

$answers       = $submission->answers_json       ? json_decode( $submission->answers_json,       true ) : [];
$domain_scores = $submission->domain_scores_json ? json_decode( $submission->domain_scores_json, true ) : [];
$findings      = $submission->findings_json      ? json_decode( $submission->findings_json,      true ) : [];
$payment_session = ! empty( $submission->stripe_session_id ) ? WPQ_Database::get_payment_session( (string) $submission->stripe_session_id ) : null;
$purchased_product = ! empty( $submission->product_id ) ? WPQ_Database::get_product_admin( (int) $submission->product_id ) : null;
$latest_payment_event = WPQ_Database::get_latest_payment_event_for_submission( (int) $submission->id );
$report_tokens = WPQ_Database::get_report_tokens_for_submission( (int) $submission->id );

// Load questionnaire structure for per-question breakdown and grade display.
$q_structure   = [];
$q_thresholds  = [];
$q_grade_match = null;
if ( ! empty( $submission->questionnaire_id ) ) {
	$q_struct_data = WPQ_Database::get_questionnaire_structure( (int) $submission->questionnaire_id );
	$q_structure   = $q_struct_data['domains']    ?? [];
	$q_thresholds  = $q_struct_data['thresholds'] ?? [];
}
foreach ( $q_thresholds as $qt ) {
	if ( ( $qt['grade_id'] ?? '' ) === ( $submission->grade_id ?? '' ) ) {
		$q_grade_match = $qt;
		break;
	}
}

// Answer display helper - returns human-readable label for a raw answer.
$wpq_fmt_answer = function ( $raw, array $q ): string {
	if ( $raw === null || $raw === '' ) return '-';
	$type = $q['question_type'] ?? 'tri_state';
	if ( $type === 'tri_state' ) {
		return match ( $raw ) { 'yes' => 'Yes', 'partial' => 'Partial', 'no' => 'No', default => (string) $raw };
	}
	if ( $type === 'boolean' ) {
		return $raw === 'yes' ? 'Yes' : 'No';
	}
	if ( in_array( $type, [ 'select', 'radio' ], true ) ) {
		foreach ( $q['options'] ?? [] as $opt ) {
			if ( ( $opt['key'] ?? '' ) === $raw ) return (string) ( $opt['label'] ?? $raw );
		}
		return (string) $raw;
	}
	if ( $type === 'checkbox' ) {
		$sel  = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
		$lbls = [];
		if ( is_array( $sel ) ) {
			foreach ( $sel as $sk ) {
				foreach ( $q['options'] ?? [] as $opt ) {
					if ( ( $opt['key'] ?? '' ) !== $sk ) {
						continue;
					}
					$lbls[] = (string) ( $opt['label'] ?? $sk );
					break;
				}
			}
		}
		return $lbls ? implode( ', ', $lbls ) : (string) $raw;
	}
	$s = (string) $raw;
	return mb_strlen( $s ) > 80 ? mb_substr( $s, 0, 77 ) . '…' : $s;
};

$list_url = admin_url( 'admin.php?page=wpq-submissions' );
$delete_url = wp_nonce_url(
	admin_url( 'admin.php?page=wpq-submissions&wpq_action=delete_submission&id=' . (int) $submission->id ),
	'wpq_delete_submission'
);
$claude_error = isset( $_GET['claude_error'] ) ? sanitize_key( wp_unslash( $_GET['claude_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin feedback flag only.
$remediation_download_url = ! empty( $submission->ai_report_docx_path )
	? wp_nonce_url(
		admin_url( 'admin-post.php?action=wpq_download_remediation_plan&submission_id=' . (int) $submission->id ),
		'wpq_download_remediation_plan'
	)
	: '';
$claude_error_messages = [
	'invalid_submission'            => 'Invalid submission ID.',
	'submission_not_found'          => 'Submission record not found.',
	'incomplete_submission'         => 'Remediation plans require a completed assessment.',
	'remediation_not_configured'    => 'Claude remediation plan generation is not configured.',
	'remediation_disabled'          => 'Remediation plan downloads are disabled for this questionnaire.',
	'session_initialisation_failed' => 'Could not initialise the Claude analysis session for this submission.',
	'generation_failed'             => 'Could not generate the remediation plan. Enable Claude debug logging in Settings -> AI for response details.',
	'empty_workbook'                => 'Claude remediation generation returned an empty workbook.',
	'download_failed'               => 'Could not download the generated artefact.',
	'questionnaire_report_disabled'      => 'Report generation is disabled for this questionnaire.',
	'questionnaire_report_not_configured' => 'Report generation is not configured (check the DOCX template, Claude API key, and PHPWord library).',
	'questionnaire_report_request_failed' => 'Could not queue Report generation.',
	'questionnaire_report_retry_failed'   => 'Could not queue a PDF conversion retry - the report must be in a partial state with a stored DOCX.',
];
$questionnaire_report_queued = isset( $_GET['questionnaire_report_queued'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin feedback flag only.
$qr_state = class_exists( 'WPQ_Questionnaire_Report' ) ? WPQ_Questionnaire_Report::state_snapshot( $submission ) : [];
$qr_docx_download_url = ! empty( $submission->qr_docx_path )
	? wp_nonce_url( admin_url( 'admin-post.php?action=wpq_download_questionnaire_report_docx&submission_id=' . (int) $submission->id ), 'wpq_download_questionnaire_report_docx' )
	: '';
$qr_pdf_download_url = ! empty( $submission->qr_pdf_path )
	? wp_nonce_url( admin_url( 'admin-post.php?action=wpq_download_questionnaire_report_pdf&submission_id=' . (int) $submission->id ), 'wpq_download_questionnaire_report_pdf' )
	: '';
?>
<div class="wrap wpq-admin-wrap">
  <h1 class="wp-heading-inline">Submission: <?php echo esc_html( $submission->ref ); ?></h1>
  <a href="<?php echo esc_url( $list_url ); ?>" class="page-title-action">← Back to list</a>
  <hr class="wp-header-end">

  <?php if ( $claude_error && isset( $claude_error_messages[ $claude_error ] ) ) : ?>
    <div class="notice notice-error"><p><?php echo esc_html( $claude_error_messages[ $claude_error ] ); ?></p></div>
  <?php endif; ?>
  <?php if ( $questionnaire_report_queued ) : ?>
    <div class="notice notice-success"><p>Report job queued and started in the background. Refresh this page in a minute or two to see progress.</p></div>
  <?php endif; ?>
  <?php
  // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Admin feedback flags only; the actions themselves are nonce-checked.
  $wpq_token_flag  = isset( $_GET['wpq_token'] ) ? sanitize_key( (string) $_GET['wpq_token'] ) : '';
  $wpq_resend_flag = isset( $_GET['wpq_resend'] ) ? sanitize_key( (string) $_GET['wpq_resend'] ) : '';
  // phpcs:enable WordPress.Security.NonceVerification.Recommended
  $wpq_reissued_link = '';
  if ( 'issued' === $wpq_token_flag ) {
	  $wpq_reissued_link = (string) get_transient( 'wpq_reissued_link_' . get_current_user_id() );
	  delete_transient( 'wpq_reissued_link_' . get_current_user_id() );
  }
  ?>
  <?php if ( 'issued' === $wpq_token_flag && '' !== $wpq_reissued_link ) : ?>
    <div class="notice notice-success">
      <p><strong>Fresh download link issued.</strong> Shown once - copy it now. It expires and has limited uses like any customer link.</p>
      <p><input type="text" readonly value="<?php echo esc_attr( $wpq_reissued_link ); ?>" style="width:100%;max-width:720px;font-family:monospace;font-size:12px;" onfocus="this.select();"></p>
    </div>
  <?php elseif ( in_array( $wpq_token_flag, [ 'error', 'unavailable' ], true ) || ( 'issued' === $wpq_token_flag && '' === $wpq_reissued_link ) ) : ?>
    <div class="notice notice-error"><p>Could not issue a download link - the report artefact may not exist yet<?php echo 'issued' === $wpq_token_flag ? ', or the one-time display window expired' : ''; ?>.</p></div>
  <?php endif; ?>
  <?php if ( 'sent' === $wpq_resend_flag ) : ?>
    <div class="notice notice-success"><p>Report delivery email re-sent with a fresh download link.</p></div>
  <?php elseif ( '' !== $wpq_resend_flag ) : ?>
    <div class="notice notice-error"><p>Could not re-send the report email (<?php echo esc_html( str_replace( '_', ' ', $wpq_resend_flag ) ); ?>).</p></div>
  <?php endif; ?>
  <?php
  // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Admin feedback flags only; the actions themselves are nonce-checked.
  $wpq_paid_report_flag = isset( $_GET['wpq_paid_report'] ) ? sanitize_key( (string) $_GET['wpq_paid_report'] ) : '';
  $wpq_replay_flag      = isset( $_GET['wpq_replay'] ) ? sanitize_key( (string) $_GET['wpq_replay'] ) : '';
  // phpcs:enable WordPress.Security.NonceVerification.Recommended
  ?>
  <?php if ( 'regenerated' === $wpq_paid_report_flag ) : ?>
    <div class="notice notice-success"><p>Paid report regenerated. Existing download tokens remain valid.</p></div>
  <?php elseif ( '' !== $wpq_paid_report_flag ) : ?>
    <div class="notice notice-error"><p>Paid report regeneration <?php echo 'failed' === $wpq_paid_report_flag ? 'failed - the error has been recorded on the submission' : 'is unavailable - it requires a paid submission with a linked product'; ?>.</p></div>
  <?php endif; ?>
  <?php if ( 'replayed' === $wpq_replay_flag ) : ?>
    <div class="notice notice-success"><p>Webhook event replayed successfully - payment state and report generation have been re-processed.</p></div>
  <?php elseif ( 'already_processed' === $wpq_replay_flag ) : ?>
    <div class="notice notice-info"><p>That webhook event was already fully processed - nothing to replay.</p></div>
  <?php elseif ( '' !== $wpq_replay_flag ) : ?>
    <div class="notice notice-error"><p>Webhook replay did not complete (<?php echo esc_html( str_replace( '_', ' ', $wpq_replay_flag ) ); ?>) - details are in the PHP error log.</p></div>
  <?php endif; ?>

  <div class="wpq-detail-grid">

    <!-- ===== Left column ===== -->
    <div>

      <!-- Contact -->
      <div class="wpq-card">
        <h3 style="margin:0 0 12px;">Contact</h3>
        <table class="widefat striped" style="max-width:600px;">
          <tbody>
            <tr><th style="width:160px;">Name</th><td><?php echo esc_html( $submission->contact_name ); ?></td></tr>
            <tr><th>Email</th><td><a href="mailto:<?php echo esc_attr( $submission->contact_email ); ?>"><?php echo esc_html( $submission->contact_email ); ?></a></td></tr>
            <tr><th>Company</th><td><?php echo esc_html( $submission->contact_company ); ?></td></tr>
            <?php if ( $submission->contact_phone ) : ?>
            <tr><th>Phone</th><td><?php echo esc_html( $submission->contact_phone ); ?></td></tr>
            <?php endif; ?>
            <tr><th>IP Address</th><td><?php echo esc_html( $submission->ip_address ?? '-' ); ?></td></tr>
          </tbody>
        </table>
      </div>

      <!-- Domain scores -->
      <?php if ( ! empty( $domain_scores ) ) : ?>
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Domain Scores</h3>
        <table class="widefat striped">
          <thead><tr><th>Domain</th><th style="width:80px;">Score</th><th style="width:80px;">%</th></tr></thead>
          <tbody>
          <?php foreach ( $domain_scores as $di => $ds ) : ?>
            <tr>
              <td><?php echo esc_html( $ds['name'] ?? $ds['slug'] ?? '' ); ?></td>
              <td><?php echo esc_html( ( $ds['score'] ?? '-' ) . ' / ' . ( $ds['max'] ?? '-' ) ); ?></td>
              <td><?php echo isset( $ds['pct'] ) ? esc_html( $ds['pct'] ) . '%' : '-'; ?></td>
            </tr>
            <?php if ( ! empty( $q_structure[ $di ]['questions'] ) ) : ?>
            <tr>
              <td colspan="3" style="padding:0 0 6px 0;background:transparent;">
                <details style="padding:0 8px;">
                  <summary style="cursor:pointer;padding:6px 0;color:#0073aa;font-size:0.8em;list-style:none;user-select:none;">
                    &#9656; <?php echo count( $q_structure[ $di ]['questions'] ); ?> question<?php echo count( $q_structure[ $di ]['questions'] ) !== 1 ? 's' : ''; ?>
                  </summary>
                  <table style="width:100%;border-collapse:collapse;font-size:0.8em;margin:4px 0 8px;">
                    <thead>
                      <tr style="background:#f9f9f9;">
                        <th style="width:52px;padding:4px 8px;text-align:left;border-bottom:1px solid #e0e0e0;font-weight:600;">Ref</th>
                        <th style="padding:4px 8px;text-align:left;border-bottom:1px solid #e0e0e0;font-weight:600;">Question</th>
                        <th style="width:180px;padding:4px 8px;text-align:left;border-bottom:1px solid #e0e0e0;font-weight:600;">Answer</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ( $q_structure[ $di ]['questions'] as $qi => $q ) :
                        $raw_ans  = $answers[ "{$di}_{$qi}" ] ?? null;
                        $mode     = $q['scoring_mode'] ?? '';
                        $is_ns    = $mode === 'non_scoring';
                        $ans_lbl  = $wpq_fmt_answer( $raw_ans, $q );
                        $ans_col  = '';
                        if ( ! $is_ns && $raw_ans !== null ) {
                          if ( in_array( $mode, [ 'legacy_tri_state', 'boolean' ], true ) ) {
                            if ( $raw_ans === 'yes' )     $ans_col = '#1a5e35';
                            elseif ( $raw_ans === 'no' )  $ans_col = '#c0392b';
                            elseif ( $raw_ans === 'partial' ) $ans_col = '#c87c00';
                          } elseif ( $mode === 'reverse_boolean' ) {
                            $ans_col = $raw_ans === 'yes' ? '#c0392b' : '#1a5e35';
                          }
                        }
                      ?>
                      <tr style="border-bottom:1px solid #f5f5f5;">
                        <td style="padding:4px 8px;color:#888;font-family:monospace;white-space:nowrap;"><?php echo esc_html( $q['question_ref'] ?? "{$di}.{$qi}" ); ?></td>
                        <td style="padding:4px 8px;<?php echo $is_ns ? 'color:#aaa;' : ''; ?>"><?php echo esc_html( $q['question'] ); ?></td>
                        <td style="padding:4px 8px;">
                          <?php if ( $raw_ans === null ) : ?>
                            <span style="color:#bbb;">-</span>
                          <?php else : ?>
                            <span style="<?php echo $ans_col ? 'color:' . esc_attr( $ans_col ) . ';font-weight:600;' : ''; ?><?php echo $is_ns ? 'color:#888;' : ''; ?>"><?php echo esc_html( $ans_lbl ); ?></span>
                          <?php endif; ?>
                        </td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </details>
              </td>
            </tr>
            <?php endif; ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>

      <!-- Findings -->
      <?php if ( ! empty( $findings ) ) : ?>
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Findings</h3>
        <table class="widefat striped">
          <thead><tr><th>Priority</th><th>Domain</th><th>Action</th></tr></thead>
          <tbody>
          <?php foreach ( $findings as $f ) : ?>
            <tr>
              <td><?php echo esc_html( ucfirst( $f['priority'] ?? '' ) ); ?></td>
              <td><?php echo esc_html( $f['domain'] ?? '' ); ?></td>
              <td><?php echo esc_html( $f['action'] ?? '' ); ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>

    </div>

    <!-- ===== Right column ===== -->
    <div>

      <!-- Meta -->
      <div class="wpq-card">
        <h3 style="margin:0 0 12px;">Details</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Status</th>
              <td><?php
                $ab = (int) $submission->abandoned;
                if ( $ab === 0 )      echo '<span class="wpq-status-completed">&#10003; Completed</span>';
                elseif ( $ab === 2 )  echo '<span class="wpq-status-deleted">&#128465; Deleted (soft)</span>';
                else                  echo '<span class="wpq-status-partial">&#8987; Partial</span>';
              ?></td>
            </tr>
            <tr><th>Started</th><td><?php echo $submission->started_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $submission->started_at ) ) ) : '-'; ?></td></tr>
            <tr><th>Completed</th><td><?php echo $submission->completed_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $submission->completed_at ) ) ) : '-'; ?></td></tr>
            <tr><th>Duration</th><td><?php echo $submission->duration_seconds !== null ? esc_html( gmdate( 'i\m s\s', (int) $submission->duration_seconds ) ) : '-'; ?></td></tr>
            <?php if ( $submission->last_question_answered ) : ?>
            <tr><th>Last Q answered</th><td><?php echo esc_html( $submission->last_question_answered ); ?></td></tr>
            <?php endif; ?>
            <?php if ( $submission->overall_score !== null ) : ?>
            <tr>
              <th>Result</th>
              <td>
                <span style="font-size:1.1em;font-weight:700;"><?php echo (int) $submission->overall_score; ?></span><span style="color:#888;font-size:0.85em;">&thinsp;/&thinsp;100</span>
                <?php if ( $q_grade_match ) : ?>
                  <span style="display:inline-block;background:<?php echo esc_attr( $q_grade_match['bg'] ); ?>;color:<?php echo esc_attr( $q_grade_match['color'] ); ?>;padding:2px 10px;border-radius:10px;font-weight:700;font-size:0.85em;margin-left:8px;">
                    <?php echo esc_html( $q_grade_match['grade_label'] ); ?>
                  </span>
                  <span style="font-size:0.8em;color:#888;margin-left:4px;"><?php echo esc_html( $q_grade_match['verdict'] ); ?></span>
                <?php elseif ( $submission->grade_id ) : ?>
                  <span style="display:inline-block;background:#f5f5f5;color:#333;padding:2px 10px;border-radius:10px;font-weight:700;font-size:0.85em;margin-left:8px;"><?php echo esc_html( $submission->grade_id ); ?></span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- HaloPSA -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">HaloPSA Sync</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Status</th>
              <td><?php
                $sync_map = [
                  'synced'        => '<span class="wpq-status-completed">&#10003; Synced</span>',
                  'pending'       => '<span class="wpq-status-partial">&#8987; Pending</span>',
                  'processing'    => '<span style="color:#0073aa;">&#8635; Processing</span>',
                  'failed'        => '<span style="color:#e84855;">&#10007; Failed</span>',
                  'retry_pending' => '<span style="color:#d63638;">&#8635; Retry pending</span>',
                  'ignored'       => '<span class="wpq-status-inactive">&#8212; Ignored</span>',
                  'manual_review' => '<span style="color:#dba617;">&#9888; Manual review</span>',
                  'skipped'       => '<span class="wpq-status-inactive">&#8212; Skipped</span>',
                ];
                echo wp_kses_post( $sync_map[ $submission->halopsa_sync_status ?? 'pending' ] ?? esc_html( $submission->halopsa_sync_status ) );
              ?></td>
            </tr>
            <?php if ( $submission->halopsa_lead_id ) : ?>
            <tr><th>HaloPSA ID</th><td><?php echo esc_html( $submission->halopsa_lead_id ); ?></td></tr>
            <?php endif; ?>
            <?php if ( $submission->halopsa_synced_at ) : ?>
            <tr><th>Synced at</th><td><?php echo esc_html( wp_date( 'd M Y H:i', strtotime( $submission->halopsa_synced_at ) ) ); ?></td></tr>
            <?php endif; ?>
            <?php if ( ! empty( $submission->halopsa_last_attempted_at ) ) : ?>
            <tr><th>Last attempt</th><td><?php echo esc_html( wp_date( 'd M Y H:i', strtotime( $submission->halopsa_last_attempted_at ) ) ); ?></td></tr>
            <?php endif; ?>
            <?php if ( ! empty( $submission->halopsa_retry_count ) ) : ?>
            <tr><th>Retry count</th><td><?php echo esc_html( (string) (int) $submission->halopsa_retry_count ); ?></td></tr>
            <?php endif; ?>
            <?php if ( ! empty( $submission->halopsa_sync_error ) ) : ?>
            <tr><th>Last sync error</th><td style="color:#d63638;word-break:break-word;"><?php echo esc_html( $submission->halopsa_sync_error ); ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Claude -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Claude Analysis</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Provider mode</th><td><?php echo esc_html( $submission->claude_provider_mode ?: 'not configured' ); ?></td></tr>
            <tr><th>Status</th><td><?php echo esc_html( $submission->claude_status ?? 'not_started' ); ?></td></tr>
            <tr><th>Project name</th><td><?php echo esc_html( $submission->questionnaire_claude_project_name ?: '-' ); ?></td></tr>
            <tr>
              <th>Project ID</th>
              <td style="word-break:break-all;">
                <?php echo esc_html( $submission->claude_project_id ?: '-' ); ?>
              </td>
            </tr>
            <tr><th>Conversation title</th><td><?php echo esc_html( $submission->claude_conversation_title ?: '-' ); ?></td></tr>
            <tr><th>Claude conversation ID</th><td style="word-break:break-all;"><?php echo esc_html( $submission->claude_conversation_id ?: '-' ); ?></td></tr>
            <tr><th>Created</th><td><?php echo ! empty( $submission->claude_created_at ) ? esc_html( wp_date( 'd M Y H:i', strtotime( (string) $submission->claude_created_at ) ) ) : '-'; ?></td></tr>
            <tr><th>Last operation</th><td><?php echo ! empty( $submission->claude_last_success_at ) ? esc_html( wp_date( 'd M Y H:i', strtotime( (string) $submission->claude_last_success_at ) ) ) : '-'; ?></td></tr>
            <tr><th>Model</th><td><?php echo esc_html( $submission->claude_model_used ?: '-' ); ?></td></tr>
            <tr><th>Prompt version</th><td><?php echo esc_html( $submission->claude_prompt_version ?: '-' ); ?></td></tr>
            <tr><th>AI report status</th><td><?php echo esc_html( $submission->ai_report_status ?? 'not_requested' ); ?></td></tr>
            <tr>
              <th>Remediation workbook</th>
              <td>
                <?php echo esc_html( ! empty( $submission->ai_report_docx_path ) ? basename( (string) $submission->ai_report_docx_path ) : '-' ); ?>
                <?php if ( $remediation_download_url ) : ?>
                  <br><a class="button button-secondary" href="<?php echo esc_url( $remediation_download_url ); ?>">Download the Plan</a>
                <?php endif; ?>
              </td>
            </tr>
            <tr><th>PDF output</th><td><?php echo esc_html( ! empty( $submission->ai_report_pdf_path ) ? basename( (string) $submission->ai_report_pdf_path ) : '-' ); ?></td></tr>
            <?php if ( ! empty( $submission->claude_last_error ) ) : ?>
              <tr><th>Last error</th><td style="color:#d63638;word-break:break-word;"><?php echo esc_html( $submission->claude_last_error ); ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
        <p class="description">The Anthropic Messages API does not currently create a Claude.ai chat conversation ID. This field is only populated when Anthropic returns a provider-generated conversation or session identifier.</p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
          <?php wp_nonce_field( 'wpq_generate_remediation_plan' ); ?>
          <input type="hidden" name="action" value="wpq_generate_remediation_plan">
          <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
          <label for="wpq-admin-remediation-days" class="screen-reader-text">Plan length</label>
          <select id="wpq-admin-remediation-days" name="days">
            <option value="30">30 days</option>
            <option value="60">60 days</option>
            <option value="90" selected>90 days</option>
          </select>
          <button type="submit" class="button button-primary">Generate Remediation Plan</button>
          <span class="description">Downloads the generated remediation workbook using the same generator as the public result page.</span>
        </form>
      </div>

      <!-- Report -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Report</h3>
        <p class="description">A separate AI-generated analytical assessment report, produced from a questionnaire-specific DOCX template and converted to PDF. This is distinct from the Remediation Plan above.</p>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Status</th><td><?php echo esc_html( $qr_state['status'] ?? 'not_requested' ); ?></td></tr>
            <tr><th>Renderer mode</th><td><?php echo esc_html( $qr_state['renderer_mode'] ?: '-' ); ?></td></tr>
            <tr><th>Model</th><td><?php echo esc_html( $submission->qr_model_used ?: '-' ); ?></td></tr>
            <tr><th>Prompt version</th><td><?php echo esc_html( $submission->qr_prompt_version ?: '-' ); ?></td></tr>
            <tr><th>Context version</th><td><?php echo esc_html( $submission->qr_context_version ?: '-' ); ?></td></tr>
            <tr><th>Template checksum</th><td><code style="word-break:break-all;"><?php echo esc_html( $submission->qr_template_checksum ?: '-' ); ?></code></td></tr>
            <tr><th>Last successful stage</th><td><?php echo esc_html( $qr_state['last_stage'] ?: '-' ); ?></td></tr>
            <tr><th>Generated</th><td><?php echo ! empty( $submission->qr_generated_at ) ? esc_html( wp_date( 'd M Y H:i', strtotime( (string) $submission->qr_generated_at ) ) ) : '-'; ?></td></tr>
            <tr>
              <th>DOCX</th>
              <td>
                <?php echo esc_html( ! empty( $submission->qr_docx_path ) ? basename( (string) $submission->qr_docx_path ) : '-' ); ?>
                <?php if ( $qr_docx_download_url ) : ?>
                  <br><a class="button button-secondary" href="<?php echo esc_url( $qr_docx_download_url ); ?>">Download DOCX</a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <th>PDF</th>
              <td>
                <?php echo esc_html( ! empty( $submission->qr_pdf_path ) ? basename( (string) $submission->qr_pdf_path ) : '-' ); ?>
                <?php if ( $qr_pdf_download_url ) : ?>
                  <br><a class="button button-secondary" href="<?php echo esc_url( $qr_pdf_download_url ); ?>">Download PDF</a>
                <?php endif; ?>
              </td>
            </tr>
            <?php if ( ! empty( $qr_state['failure_message'] ) ) : ?>
              <tr><th>Last error</th><td style="color:#d63638;word-break:break-word;"><?php echo esc_html( (string) $qr_state['failure_message'] ); ?> <span style="color:#888;">(<?php echo esc_html( (string) $qr_state['failure_code'] ); ?>)</span></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
          <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'wpq_generate_questionnaire_report' ); ?>
            <input type="hidden" name="action" value="wpq_generate_questionnaire_report">
            <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
            <button type="submit" class="button button-primary" <?php disabled( in_array( $qr_state['status'] ?? '', [ 'queued', 'analysing', 'rendering_docx', 'converting_pdf' ], true ) ); ?>>
              <?php echo in_array( $qr_state['status'] ?? '', [ 'completed', 'partial', 'failed' ], true ) ? esc_html( 'Regenerate Report' ) : esc_html( 'Generate Report' ); ?>
            </button>
          </form>
          <?php if ( 'partial' === ( $qr_state['status'] ?? '' ) ) : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <?php wp_nonce_field( 'wpq_retry_questionnaire_report_pdf' ); ?>
              <input type="hidden" name="action" value="wpq_retry_questionnaire_report_pdf">
              <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
              <button type="submit" class="button">Retry PDF Conversion</button>
            </form>
          <?php endif; ?>
          <?php if (
            in_array( $qr_state['status'] ?? '', [ 'completed', 'partial', 'failed' ], true )
            && class_exists( 'WPQ_Questionnaire_Report' )
            && WPQ_Questionnaire_Report::has_stored_analysis( $submission )
          ) : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <?php wp_nonce_field( 'wpq_rerender_questionnaire_report' ); ?>
              <input type="hidden" name="action" value="wpq_rerender_questionnaire_report">
              <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
              <button type="submit" class="button" title="Re-renders the DOCX/PDF from the stored analysis against the current template. No Claude call - the report content stays identical.">Re-render from Stored Analysis</button>
            </form>
          <?php endif; ?>
          <?php if ( ! empty( $submission->qr_pdf_path ) ) : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <?php wp_nonce_field( 'wpq_reissue_report_token' ); ?>
              <input type="hidden" name="action" value="wpq_reissue_report_token">
              <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
              <input type="hidden" name="purpose" value="questionnaire_report">
              <button type="submit" class="button" title="Mints a fresh customer download link (30 days / 10 uses) - for when the original link expired or ran out of uses.">Issue Fresh Download Link</button>
            </form>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <?php wp_nonce_field( 'wpq_resend_report_link' ); ?>
              <input type="hidden" name="action" value="wpq_resend_report_link">
              <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
              <button type="submit" class="button" title="Emails the customer a fresh secure download link, even if a delivery email was already sent.">Re-send Delivery Email</button>
            </form>
          <?php endif; ?>
          <?php if ( ! empty( $submission->report_path ) ) : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <?php wp_nonce_field( 'wpq_reissue_report_token' ); ?>
              <input type="hidden" name="action" value="wpq_reissue_report_token">
              <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
              <input type="hidden" name="purpose" value="paid_report">
              <button type="submit" class="button" title="Mints a fresh download link for the paid report (7 days / 5 uses).">Issue Fresh Paid-Report Link</button>
            </form>
          <?php endif; ?>
        </div>
      </div>

      <?php
      $wpq_radar_svg = '';
      if ( class_exists( 'WPQ_Framework_Radar' ) ) {
          $wpq_radar_rows = WPQ_Framework_Radar::rows_from_analysis( WPQ_Framework_Radar::stored_frameworks( $submission ) );
          $wpq_radar_svg  = WPQ_Framework_Radar::render_svg( $wpq_radar_rows );
      }
      ?>
      <?php if ( '' !== $wpq_radar_svg ) : ?>
      <!-- Framework readiness radar -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 4px;">Framework Readiness</h3>
        <p class="description" style="margin-top:0;">The customer's relative position against each framework selected for this questionnaire, from the stored report analysis. A "≈" percentage is derived from cited control strengths vs gaps (or the readiness level) where the standard's methodology does not yield a defensible figure.</p>
        <div class="wpq-radar-wrap" style="max-width:600px;">
          <?php echo $wpq_radar_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plugin-generated SVG; all embedded text is XML-escaped by the renderer. ?>
        </div>
      </div>
      <?php endif; ?>

      <!-- Attribution -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Attribution</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <?php foreach ( [ 'utm_source' => 'Source', 'utm_medium' => 'Medium', 'utm_campaign' => 'Campaign', 'utm_term' => 'Term', 'utm_content' => 'Content' ] as $field => $label ) : ?>
              <?php if ( $submission->$field ) : ?>
              <tr><th style="width:130px;"><?php echo esc_html( $label ); ?></th><td><?php echo esc_html( $submission->$field ); ?></td></tr>
              <?php endif; ?>
            <?php endforeach; ?>
            <?php if ( $submission->referrer_url ) : ?>
            <tr><th>Referrer</th><td style="word-break:break-all;"><a href="<?php echo esc_url( $submission->referrer_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $submission->referrer_url ); ?></a></td></tr>
            <?php endif; ?>
            <?php if ( $submission->landing_page ) : ?>
            <tr><th>Landing page</th><td style="word-break:break-all;"><a href="<?php echo esc_url( $submission->landing_page ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $submission->landing_page ); ?></a></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Payment & report -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Payment & Report</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Payment status</th><td><?php echo esc_html( $submission->payment_status ?? 'none' ); ?></td></tr>
            <tr><th>Stripe session</th><td style="word-break:break-all;"><?php echo esc_html( $submission->stripe_session_id ?? '-' ); ?></td></tr>
            <tr><th>Product</th><td><?php echo $purchased_product ? esc_html( $purchased_product->name ) : '-'; ?></td></tr>
            <?php if ( $payment_session ) : ?>
              <tr><th>Expected amount</th><td><?php echo esc_html( strtoupper( (string) ( $payment_session->currency ?? 'gbp' ) ) . ' ' . number_format( (int) ( $payment_session->amount_total ?? 0 ) / 100, 2 ) ); ?></td></tr>
              <tr><th>Session status</th><td><?php echo esc_html( $payment_session->payment_status ?? '-' ); ?></td></tr>
            <?php endif; ?>
            <?php if ( $latest_payment_event ) : ?>
              <tr><th>Latest event</th><td><?php echo esc_html( $latest_payment_event->event_type ?? '-' ); ?></td></tr>
              <tr><th>Event processed</th><td><?php echo $latest_payment_event->processed_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $latest_payment_event->processed_at ) ) ) : '-'; ?></td></tr>
            <?php endif; ?>
            <tr><th>Report generated</th><td><?php echo $submission->report_generated_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $submission->report_generated_at ) ) ) : '-'; ?></td></tr>
            <tr><th>Report file</th><td style="word-break:break-all;"><?php echo esc_html( $submission->report_path ? basename( (string) $submission->report_path ) : '-' ); ?></td></tr>
            <?php if ( ! empty( $submission->report_error ) ) : ?>
              <tr><th>Report error</th><td><?php echo esc_html( $submission->report_error ); ?></td></tr>
            <?php endif; ?>
            <tr><th>Report tokens</th><td><?php echo esc_html( (string) count( $report_tokens ) ); ?> issued</td></tr>
          </tbody>
        </table>
        <?php
        $wpq_payment_events = method_exists( 'WPQ_Database', 'get_payment_events_for_submission' )
          ? WPQ_Database::get_payment_events_for_submission( (int) $submission->id )
          : [];
        $wpq_unprocessed_events = array_filter( $wpq_payment_events, static fn( $e ) => empty( $e->processed_at ) );
        ?>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
          <?php if ( 'paid' === (string) ( $submission->payment_status ?? '' ) && (int) ( $submission->report_product_id ?: $submission->product_id ) > 0 ) : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <?php wp_nonce_field( 'wpq_regenerate_paid_report' ); ?>
              <input type="hidden" name="action" value="wpq_regenerate_paid_report">
              <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
              <button type="submit" class="button" title="Re-renders the paid HTML/Dompdf report through the same path the webhook uses. Existing download tokens keep working.">Regenerate Paid Report</button>
            </form>
          <?php endif; ?>
          <?php foreach ( $wpq_unprocessed_events as $wpq_event ) : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <?php wp_nonce_field( 'wpq_replay_payment_event' ); ?>
              <input type="hidden" name="action" value="wpq_replay_payment_event">
              <input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) (int) $submission->id ); ?>">
              <input type="hidden" name="stripe_event_id" value="<?php echo esc_attr( (string) $wpq_event->stripe_event_id ); ?>">
              <button type="submit" class="button" title="Re-runs this stored, never-completed webhook event through the idempotent handler.">
                Replay <?php echo esc_html( (string) $wpq_event->event_type ); ?> (<?php echo esc_html( substr( (string) $wpq_event->stripe_event_id, 0, 14 ) ); ?>…)
              </button>
            </form>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Actions -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Actions</h3>
        <a href="<?php echo esc_url( $delete_url ); ?>" class="button button-secondary wpq-confirm-delete"
           style="color:#e84855;border-color:#e84855;">Delete submission</a>
      </div>

    </div>
  </div>
</div>
