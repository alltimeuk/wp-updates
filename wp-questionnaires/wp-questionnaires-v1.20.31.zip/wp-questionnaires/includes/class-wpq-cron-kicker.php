<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Fires WP-Cron on hosts where nothing else will.
 *
 * The managed hosting container has DISABLE_WP_CRON set and offers no system
 * crontab (and no sudo to add one), so core never spawns wp-cron.php and
 * scheduled jobs - report generation queued from the public results flow,
 * retention automation, contact migration batches - sit at "queued" forever.
 * The wp-cron.php endpoint itself works (the Readiness loopback probe returns
 * HTTP 200); the only missing piece is something to request it:
 *
 *  - kick() sends the same non-blocking loopback POST core's spawn_cron()
 *    would, immediately after a job is scheduled, so the job starts within a
 *    second in a separate request instead of waiting for a cron that never
 *    comes. It deliberately ignores DISABLE_WP_CRON - that constant stops
 *    core auto-spawning on page views; explicitly queued work is exactly the
 *    case where firing anyway is wanted.
 *  - maybe_kick_overdue() runs on admin page views (throttled to once a
 *    minute) and kicks when any due scheduled event exists, sweeping up
 *    recurring jobs like retention that have no request-time trigger.
 *
 * wp-cron.php holds its own doing_cron lock, so a redundant kick while a run
 * is already in flight is a cheap no-op.
 */
class WPQ_Cron_Kicker {

	private const THROTTLE_TRANSIENT = 'wpq_cron_kicker_last_sweep';

	public static function register(): void {
		add_action( 'admin_init', [ __CLASS__, 'maybe_kick_overdue' ] );
	}

	public static function kick(): void {
		if ( ! function_exists( 'wp_remote_post' ) || ! function_exists( 'site_url' ) ) {
			return;
		}

		$url = add_query_arg( 'doing_wp_cron', sprintf( '%.22F', microtime( true ) ), site_url( 'wp-cron.php' ) );

		wp_remote_post(
			$url,
			[
				'timeout'   => 0.01,
				'blocking'  => false,
				// Match core spawn_cron(): a loopback to our own host may sit
				// behind a certificate that fails strict verification.
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
			]
		);
	}

	/**
	 * Throttled sweep for due events nothing else will fire. Only needed when
	 * DISABLE_WP_CRON is set - otherwise core already spawns on every request.
	 */
	public static function maybe_kick_overdue(): void {
		if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
			return;
		}
		if ( ! defined( 'DISABLE_WP_CRON' ) || ! DISABLE_WP_CRON ) {
			return;
		}
		if ( false !== get_transient( self::THROTTLE_TRANSIENT ) ) {
			return;
		}
		set_transient( self::THROTTLE_TRANSIENT, time(), MINUTE_IN_SECONDS );

		if ( function_exists( 'wp_get_ready_cron_jobs' ) && [] === wp_get_ready_cron_jobs() ) {
			return;
		}

		self::kick();
	}
}
