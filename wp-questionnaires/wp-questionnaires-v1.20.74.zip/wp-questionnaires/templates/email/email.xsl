<?xml version="1.0" encoding="UTF-8"?>
<!--
  WP Questionnaires - default email layout.

  Transforms the small <email> XML document built by WPQ_Email_Template into
  the HTML email body every WPQ_Mailer::send() call now delivers. The look
  and structure mirror templates/test_email.html; the shared signature lives
  in signature.xsl so future layouts can reuse it without duplicating the
  brand assets.

  Recognised <email> child elements (all optional except title):
    subject         - used as the <title> of the HTML document
    badge           - small pill shown top-right of the header
    department      - sub-line under the company name, and the signature's job title
    title           - large coloured heading
    recipient_line  - small italic caption line under the title (e.g. "Recipient: jane@example.com") - not a greeting, see greeting
    greeting        - normal-weight "Hello {name}" line under the title, styled like an intro paragraph
    intro/p         - one or more body paragraphs
    cta_url/cta_label - a button-style call to action link
    details/item[@label] - a two-column key/value table
    footnote        - small print under the details table
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method="html" encoding="UTF-8" indent="no" doctype-system="about:legacy-compat"/>
<xsl:include href="signature.xsl"/>

<xsl:template match="/email">
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<title><xsl:value-of select="subject"/></title>
</head>
<body style="margin:0;padding:0;background:#f5f5f5;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;">

<div style="background:#f5f5f5;padding:20px 0;">
<div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:4px;overflow:hidden;border:1px solid #e0e0e0;">

  <!-- HEADER -->
  <div style="background:#ffffff;padding:0px;">
    <table style="border-bottom:3px solid #E20979;width:100%;">
      <tr>
        <td style="border-right:0px solid #E20979;padding-top:1px;padding-bottom:1px;padding-left:0px;padding-right:0px;">
          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHkAAABQCAYAAAA9Wdq3AAAIT0lEQVR4nOydC2wUxxnH/7P32rNJSbGDCbbvSCix2iZVQ4MsGhJVaZuoskpTKGmaGilADaEItagFbEKlS4R9NimgmAqBoUgJLxMJh4Q+lIKSKI0JooWoBJrYDgXujGlpYhSM7d177JdvHR0xfhA72JfZ2/3Jdzc7O2vN7X9n9pvv25lT4JDxKHDIeByRbYAjsg1wRLYBjsg2wBHZBjgi2wBHZBvgiGwDHJFtgCOyDXBEtgGOyDbAjQwiimV+xe+92zDEVAImQYhcEsgBIUeAcnk7h4uN63NYO79aiNAsgGYSotmVQHM87n3vNoQ0ZAACFqbVXzE9aaAYgr4lIL7J3+ZOjCRE7/DF8hYnGklzHZyEqguwIJYTOaKuvJ9b5BxOzuLqT0Qa4db+Fl9QL3nIVT9RqzwHi2AJkc/7V347CfFzgvgxV/hWyADhFX5tCujhlyE50opMWOiJqDmPcg1/zZWcClkhNgWAzW4tVjcR6z6AhEgn8jmUf1mo+CUbQEukabVDhWizoonVBQh/CImQSuSoWlFmALVCQIV1aScDq4J6eAskQZohlNmCebhTZyVLkECXBImjnDzLVvhZIeiMSBhnfHG3VEaZNCIrXiogye1AImriGjZystFFRmO+vrYJFkAakUl4uoAkZIOFfZfH4DtdQtmRr1VGYUGkEVnV9U7NL011TC/Y80gou4Lxyn/23lH7g1qfvzC4wZ+I7S/dPudvsADSnFU3lG58wbCz4zK/bxijqetzELqcyt9RuuPWjuwxf2jpTH5/7+lLN3W0RrG6OPAMLIJUN8GIWhHnGqX/wiN0sRG1UdH0tYXY0J7K3rngxe++m6TdB09dHN/dnbha/Gu332zsfbnUBYsgVYCCT3SE73+3I13wDZeNvZ2kiZWTEL7ql64va3j0H93JzeuOXRibSBj9DpuWd9OxvbAOUonM3UqEP9IiMl9Qx9xJZWF+vOp4330bT36453KHPuBxWVkeTOhKzIKFkCyeLNIyvmRnxRPB7up7UgJv+eGWrMr5Dc1mek/ZS2WDCWwy6xu3nCzdNbsVFkIqkbl1je64k+iUYqCotzeqbuH+zQdi6pX6o21TXpjfMOMsGcsGO3xyYCz5z7feA4shV3dNynF+w2jAd9+6oFa9KLW9e37D9NeuJF7beLjVl8rTFWXKm5GPvjrQ8dnZHszOz14xd+tcHRZDqpbs1WNvYzQgPNlb4O1lDU9tff/S4SP/vujrXSwKY0WkraPf4WPGeLH4rrwn526d9XtYEPmiUP6KthGLPhEM/psX1GqeT2VV/+LFE3uOtt1lGNf2GIoikJebhQsXO6/Jz7slC6WTx/3q8W0P18KiSPeMlyB6A0L8FCOAMOiRQKxmn5net2BX8C8d7uZdR857Byprit5X4K9/ZVxyTk72A7O3/egNWBgJH+QTr/DbjYncM/xVHiuMhfelsg585Go59t7/PUM5PD8vGyWTb/7r0rqHS+pHy0hII9KJ7NZiBxJ+L24EIrE4qFXV9857aKy7eEpx/t5oV7zwfLvmi/63QySTn+jndisoCow1inL9bUEP6iNNJyqW1s1LIEOQMrZ3zl9+nD1fd+PzQBQOaNWrPquYOTZWJ+Q+zhKrZ1rerg29HsoYUfsip8hqeYUQogrDhHvpQyzwg8I0uRyuIuUMCpcwdvTcV4cDUYSjR7MdgfsjpcgF3WtNt+Hfh1qeL4eYkqSZvcODDp8i8zSZ5/h1/5BKkrGiIF7zr6EUjWLZOOHzTk8KMU0ITAX1zLwoHPDfms9wAU1cpqnH5SqU0+4E3vfEvc3jEboCiyD1Q1VsgP2PDbDx1y1EOBjQwg9e//+sekSQUcJf917+xpMxAvQ87yXEISWJ1ymmvdo7Di0bUk94EySeZVEqB9vPJzrug3vRYPuj/vLlHA3+rQCNZwcLRrRuQhTxR5HhwhKovkpoWA1JkVpkVfPVaqq2ms+of6D93MqfmaCtOdM3P6JW3Mcf29gCu2PUuyqiTqHp6yExUs9PNu97LNTaQXa3uzVfv1Ye8ZevZ/XZNYo7kBbEszJ31SbSz08OaGpV1K+V9Z/BSGsmItSV2mrDb3LZU/YnThYjXXzSitdBcqRfaUAgFOM48/Jrc6kt0F29IbVlWsxx1WvOZEifwD3VwArZW7GJJZaTKNSqdrORdTi1LQyEe+8nVd3PdtVtSCN8Gzke0Ks3wQJYZs0QF4l53D0mzWejC3S1LpXPRtY2bu73Ic2IhLIIFsEyIhfo4WYW2DSqnjO7cDOv1VvxE95egHRjBkH6zKyQGUstDOPR1VDS15mf2k66UPsFeHNODCXKJROWErnHmtbRYqYjvlVLuEmlfZI6JY3HYDGsu46XMBYj3RAtCMZqTsFiWFZk9na9gLRCm7ib3g4LYlmRC7Xw0zyO+SPSABt8jYXd6lJYFEsv1sZjVRH1V+zn5EyMFkTvZGvqDCvHqi0tcopzavlBjgp9DyMN4aSi4TuyreYzXDJiAVVF02eyR+xVjCDmMhIeDQ9YXWCTjGjJJoSlvqiafYjDkjNwoxC9yV10SaY8TpQxIpu0IZSVUPUG/lYP4fNCqA9o4Z8hg8gokVNE1PKnuUX/DsOEu+inglp1CBlGRops0upbWZIUym6OTn3pMwsTdStEcwr0mj8jA8nYletNwQS5prKCR65Xjlvvf8igaZkqsElG/zxBQF9zmp0Y93JyOTs0rl2FnpBggWvYMr/Tiq7K4ZCx3XVfor7lU0i4tpvWt+nBEoZ4IhCrOgkbYBuR7YzzazI2wBHZBjgi2wBHZBvgiGwDHJFtgCOyDXBEtgGOyDbAEdkGOCLbAEdkG+CIbAM+BgAA//9WJ9AwAAAABklEQVQDAEwB+RC+q6xMAAAAAElFTkSuQmCC" alt="Alltime Technologies Ltd" height="80" style="height:80px;width:121px;float:left;"/>
        </td>
        <td style="vertical-align:middle;">
          <div style="font-family:Poppins,Arial,sans-serif;font-size:16px;font-weight:700;color:#2D2C94;line-height:1.2;">
            Alltime Technologies Ltd
          </div>
          <xsl:if test="department">
            <div style="font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#888888;margin-top:2px;"><xsl:value-of select="department"/></div>
          </xsl:if>
        </td>
        <td style="text-align:right;vertical-align:middle;padding-left:16px;">
          <xsl:if test="badge">
            <span style="display:inline-block;background:#2D2C94;color:#ffffff;font-family:Poppins,Arial,sans-serif;font-size:10px;font-weight:700;padding:3px 10px;border-radius:2px;letter-spacing:1px;vertical-align:middle;"><xsl:value-of select="badge"/></span>
          </xsl:if>
        </td>
      </tr>
    </table>
  </div>

  <!-- BODY -->
  <div style="padding:28px 28px 20px;">

    <div style="font-family:Poppins,Arial,sans-serif;font-size:18px;font-weight:700;color:#E20979;margin-bottom:4px;line-height:1.3;"><xsl:value-of select="title"/></div>

    <xsl:if test="recipient_line">
      <div style="margin-bottom:16px;"><span style="font-size:11px;color:#888;font-style:italic;"><xsl:value-of select="recipient_line"/></span></div>
    </xsl:if>

    <xsl:if test="greeting">
      <div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;line-height:1.7;margin-bottom:16px;"><xsl:value-of select="greeting"/></div>
    </xsl:if>

    <xsl:for-each select="intro/p">
      <div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;line-height:1.7;margin-bottom:16px;"><xsl:value-of select="."/></div>
    </xsl:for-each>

    <xsl:if test="cta_url">
      <div style="text-align:center;margin:8px 0 24px;">
        <a style="display:inline-block;background:#E20979;color:#ffffff;font-family:Poppins,Arial,sans-serif;font-size:14px;font-weight:700;padding:12px 28px;border-radius:4px;text-decoration:none;">
          <xsl:attribute name="href"><xsl:value-of select="cta_url"/></xsl:attribute>
          <xsl:value-of select="cta_label"/>
        </a>
      </div>
    </xsl:if>

    <xsl:if test="details/item">
      <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
        <xsl:for-each select="details/item">
          <tr>
            <td style="font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#888;padding:4px 12px 4px 0;white-space:nowrap;vertical-align:top;"><xsl:value-of select="@label"/>:</td>
            <td style="font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#333;padding:4px 0;"><xsl:value-of select="."/></td>
          </tr>
        </xsl:for-each>
      </table>
    </xsl:if>

    <xsl:if test="footnote">
      <div style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#888;line-height:1.6;">
        <xsl:value-of select="footnote"/>
      </div>
    </xsl:if>

  </div><!-- /body -->

  <!-- REGARDS + SIGNATURE -->
  <div style="padding:0 28px 24px;">
    <p style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;margin:0 0 4px;">Thank you,</p>
    <p style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;margin:0 0 20px;"></p>
    <xsl:call-template name="signature">
      <xsl:with-param name="department">
        <xsl:choose>
          <xsl:when test="department"><xsl:value-of select="department"/></xsl:when>
          <xsl:otherwise>Service Desk Team</xsl:otherwise>
        </xsl:choose>
      </xsl:with-param>
    </xsl:call-template>
  </div>

</div><!-- /card -->
</div><!-- /wrapper -->

</body>
</html>
</xsl:template>

</xsl:stylesheet>
