<?php
/**
 * Batched, resumable, idempotent migration of historic submissions,
 * enquiries and email preferences into the canonical contact model.
 *
 * Design (spec §8): only records with contact_id IS NULL are candidates, so
 * re-running never duplicates contacts or links; interaction uniqueness is
 * guaranteed by the interactions table's dedupe key; a transient lock keeps
 * two workers from running concurrently; state (checkpoints + counters) lives
 * in a non-autoloaded option; batches are bounded by count and wall-clock so
 * no browser request is held open; a cron single-event chains batches until
 * the run completes. Legacy data is never removed.
 *
 * Ambiguity handling comes from WPQ_Contact_Service itself: role mailboxes,
 * material name conflicts and multi-candidate emails create a provisional
 * contact plus a wpq_contact_match_review row instead of auto-merging.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Contact_Migration {

	public const CRON_HOOK = 'wpq_contact_migration_batch';

	private const STATE_OPTION  = 'wpq_contact_migration_state';
	private const LOCK_KEY      = 'wpq_contact_migration_lock';
	private const LOCK_TTL      = 300;
	private const BATCH_SIZE    = 100;
	private const TIME_BUDGET_S = 20;

	/** @return array<string, mixed> */
	public static function get_state(): array {
		$state = get_option( self::STATE_OPTION, [] );
		return is_array( $state ) ? array_merge( self::default_state(), $state ) : self::default_state();
	}

	/** @return array<string, mixed> */
	private static function default_state(): array {
		return [
			'status'               => 'not_started', // not_started | running | completed
			'started_at'           => '',
			'completed_at'         => '',
			'last_submission_id'   => 0,
			'last_enquiry_id'      => 0,
			'preferences_done'     => false,
			'submissions_examined' => 0,
			'enquiries_examined'   => 0,
			'contacts_created'     => 0,
			'records_linked'       => 0,
			'reviews_queued'       => 0,
			'preferences_migrated' => 0,
			'preferences_ambiguous' => 0,
			'skipped'              => 0,
			'errors'               => 0,
			'last_error'           => '',
		];
	}

	/** @param array<string, mixed> $state */
	private static function save_state( array $state ): void {
		update_option( self::STATE_OPTION, $state, false );
	}

	public static function reset(): void {
		delete_option( self::STATE_OPTION );
	}

	/**
	 * Process one bounded batch. Returns the updated state; schedules a cron
	 * continuation while work remains.
	 *
	 * @return array<string, mixed>
	 */
	public static function run_batch(): array {
		$state = self::get_state();
		if ( 'completed' === $state['status'] ) {
			// Reconciliation: records that failed live resolution (or arrived
			// while the flag was off) re-enter the run. Checkpoints restart
			// from zero — already-linked records are excluded by the
			// contact_id IS NULL predicate, so nothing is reprocessed.
			$fresh = self::default_state();
			$fresh['status']     = self::work_remaining( $fresh ) ? 'running' : 'completed';
			$fresh['started_at'] = current_time( 'mysql', true );
			if ( 'completed' === $fresh['status'] ) {
				return $state;
			}
			$state = $fresh;
		}

		// Single-worker guard: a stale lock expires with the transient TTL.
		if ( false !== get_transient( self::LOCK_KEY ) ) {
			return $state;
		}
		set_transient( self::LOCK_KEY, 1, self::LOCK_TTL );

		try {
			if ( 'not_started' === $state['status'] ) {
				$state['status']     = 'running';
				$state['started_at'] = current_time( 'mysql', true );
			}

			$deadline = microtime( true ) + self::TIME_BUDGET_S;
			$budget   = self::BATCH_SIZE;

			$budget = self::migrate_submissions( $state, $budget, $deadline );
			if ( $budget > 0 && microtime( true ) < $deadline ) {
				$budget = self::migrate_enquiries( $state, $budget, $deadline );
			}
			if ( $budget > 0 && microtime( true ) < $deadline && ! $state['preferences_done'] ) {
				self::migrate_preferences( $state );
			}

			if ( self::work_remaining( $state ) ) {
				if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
					wp_schedule_single_event( time() + 30, self::CRON_HOOK );
				}
			} else {
				$state['status']       = 'completed';
				$state['completed_at'] = current_time( 'mysql', true );
			}
		} catch ( Throwable $e ) {
			++$state['errors'];
			$state['last_error'] = mb_substr( $e->getMessage(), 0, 300 );
		} finally {
			self::save_state( $state );
			delete_transient( self::LOCK_KEY );
		}

		return $state;
	}

	private static function work_remaining( array $state ): bool {
		global $wpdb;

		$more_submissions = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions
			 WHERE contact_id IS NULL AND deleted_at IS NULL AND contact_email <> '' AND id > %d",
			(int) $state['last_submission_id']
		) );
		if ( $more_submissions > 0 ) {
			return true;
		}

		$more_enquiries = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_enquiries
			 WHERE contact_id IS NULL AND contact_email <> '' AND id > %d",
			(int) $state['last_enquiry_id']
		) );

		return $more_enquiries > 0 || ! $state['preferences_done'];
	}

	/** @param array<string, mixed> $state */
	private static function migrate_submissions( array &$state, int $budget, float $deadline ): int {
		global $wpdb;
		$service = WPQ_Contact_Service::instance();

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, questionnaire_id, contact_name, contact_email, contact_company, contact_phone,
			        started_at, completed_at, created_at
			 FROM {$wpdb->prefix}wpq_submissions
			 WHERE contact_id IS NULL AND deleted_at IS NULL AND contact_email <> '' AND id > %d
			 ORDER BY id ASC LIMIT %d",
			(int) $state['last_submission_id'],
			$budget
		) ) ?: [];

		foreach ( $rows as $row ) {
			if ( microtime( true ) >= $deadline ) {
				break;
			}
			$state['last_submission_id'] = (int) $row->id;
			++$state['submissions_examined'];
			--$budget;

			try {
				$observed = (string) ( $row->started_at ?: $row->created_at ?: current_time( 'mysql', true ) );
				$result   = $service->resolve_or_create( [
					'name'         => (string) $row->contact_name,
					'email'        => (string) $row->contact_email,
					'telephone'    => (string) ( $row->contact_phone ?? '' ),
					'organisation' => (string) ( $row->contact_company ?? '' ),
				], [
					'source'      => 'migration',
					'source_type' => 'submission',
					'source_id'   => (int) $row->id,
					'observed_at' => $observed,
				] );

				$contact_id = (int) $result['contact_id'];
				if ( $contact_id <= 0 ) {
					++$state['skipped'];
					continue;
				}

				WPQ_Database::link_submission_contact( (int) $row->id, $contact_id );
				++$state['records_linked'];
				if ( ! empty( $result['created'] ) ) {
					++$state['contacts_created'];
				}
				if ( 'review' === (string) $result['decision'] ) {
					++$state['reviews_queued'];
				}

				$ref = sprintf( 'WPQ-%s-%04d', gmdate( 'Ymd', strtotime( $observed ) ?: time() ), (int) $row->id );
				$service->record_interaction( $contact_id, [
					'interaction_type' => 'questionnaire_started',
					'source_type'      => 'submission',
					'source_id'        => (int) $row->id,
					'source_ref'       => $ref,
					'questionnaire_id' => (int) $row->questionnaire_id,
					'occurred_at'      => $observed,
					'completion_state' => 'started',
					'organisation'     => (string) ( $row->contact_company ?? '' ),
				] );
				if ( ! empty( $row->completed_at ) ) {
					$service->record_interaction( $contact_id, [
						'interaction_type' => 'questionnaire_completed',
						'source_type'      => 'submission',
						'source_id'        => (int) $row->id,
						'source_ref'       => $ref,
						'questionnaire_id' => (int) $row->questionnaire_id,
						'occurred_at'      => (string) $row->completed_at,
						'completion_state' => 'completed',
						'organisation'     => (string) ( $row->contact_company ?? '' ),
					] );
				}
			} catch ( Throwable $e ) {
				++$state['errors'];
				$state['last_error'] = 'submission ' . (int) $row->id . ': ' . mb_substr( $e->getMessage(), 0, 200 );
			}
		}

		return $budget;
	}

	/** @param array<string, mixed> $state */
	private static function migrate_enquiries( array &$state, int $budget, float $deadline ): int {
		global $wpdb;
		$service = WPQ_Contact_Service::instance();

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, ref, contact_name, contact_email, contact_company, contact_phone, created_at
			 FROM {$wpdb->prefix}wpq_enquiries
			 WHERE contact_id IS NULL AND contact_email <> '' AND id > %d
			 ORDER BY id ASC LIMIT %d",
			(int) $state['last_enquiry_id'],
			$budget
		) ) ?: [];

		foreach ( $rows as $row ) {
			if ( microtime( true ) >= $deadline ) {
				break;
			}
			$state['last_enquiry_id'] = (int) $row->id;
			++$state['enquiries_examined'];
			--$budget;

			try {
				$observed = (string) ( $row->created_at ?: current_time( 'mysql', true ) );
				$result   = $service->resolve_or_create( [
					'name'         => (string) $row->contact_name,
					'email'        => (string) $row->contact_email,
					'telephone'    => (string) ( $row->contact_phone ?? '' ),
					'organisation' => (string) ( $row->contact_company ?? '' ),
				], [
					'source'      => 'migration',
					'source_type' => 'enquiry',
					'source_id'   => (int) $row->id,
					'observed_at' => $observed,
				] );

				$contact_id = (int) $result['contact_id'];
				if ( $contact_id <= 0 ) {
					++$state['skipped'];
					continue;
				}

				WPQ_Database::link_enquiry_contact( (int) $row->id, $contact_id );
				++$state['records_linked'];
				if ( ! empty( $result['created'] ) ) {
					++$state['contacts_created'];
				}
				if ( 'review' === (string) $result['decision'] ) {
					++$state['reviews_queued'];
				}

				$service->record_interaction( $contact_id, [
					'interaction_type' => 'enquiry_submitted',
					'source_type'      => 'enquiry',
					'source_id'        => (int) $row->id,
					'source_ref'       => (string) $row->ref,
					'occurred_at'      => $observed,
					'completion_state' => 'completed',
					'organisation'     => (string) ( $row->contact_company ?? '' ),
				] );
			} catch ( Throwable $e ) {
				++$state['errors'];
				$state['last_error'] = 'enquiry ' . (int) $row->id . ': ' . mb_substr( $e->getMessage(), 0, 200 );
			}
		}

		return $budget;
	}

	/**
	 * Migrate legacy email-level opt-outs into consent events. The legacy
	 * table is left untouched (suppression must survive regardless), and an
	 * opt-out is never converted into anything less restrictive: a safe
	 * single-contact mapping records a 'suppressed' event for
	 * direct_marketing_email; ambiguous or orphaned emails are counted and
	 * left as the legacy global suppression pending Phase 3 review.
	 *
	 * @param array<string, mixed> $state
	 */
	private static function migrate_preferences( array &$state ): void {
		global $wpdb;
		$service = WPQ_Contact_Service::instance();

		$rows = $wpdb->get_results(
			"SELECT id, email, opted_out, opted_out_at, opted_out_by_user_id
			 FROM {$wpdb->prefix}wpq_contact_preferences WHERE opted_out = 1"
		) ?: [];

		foreach ( $rows as $row ) {
			try {
				$normalised = WPQ_Contact_Normaliser::normalise_email( (string) $row->email );
				if ( '' === $normalised ) {
					++$state['preferences_ambiguous'];
					continue;
				}
				$candidates = WPQ_Contact_Repository::find_contacts_by_identity(
					'email',
					WPQ_Contact_Normaliser::identity_hash( 'email', $normalised )
				);
				if ( count( $candidates ) !== 1 ) {
					++$state['preferences_ambiguous'];
					continue;
				}

				// Idempotency across reset-and-rerun: one migrated suppression
				// per legacy preference row per contact.
				$already = (int) $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contact_consent_events
					 WHERE contact_id = %d AND purpose = 'direct_marketing_email'
					   AND source = 'legacy_preference_migration'",
					(int) $candidates[0]->id
				) );
				if ( $already > 0 ) {
					++$state['preferences_migrated'];
					continue;
				}

				$service->record_consent_event( (int) $candidates[0]->id, [
					'identity_id' => (int) $candidates[0]->identity_id,
					'purpose'     => 'direct_marketing_email',
					'event'       => 'suppressed',
					'source'      => 'legacy_preference_migration',
					'actor'       => (int) ( $row->opted_out_by_user_id ?? 0 ) > 0 ? 'admin:' . (int) $row->opted_out_by_user_id : 'system',
					'occurred_at' => (string) ( $row->opted_out_at ?: current_time( 'mysql', true ) ),
					'evidence'    => [ 'legacy_preference_id' => (int) $row->id, 'email' => $normalised ],
				] );
				++$state['preferences_migrated'];
			} catch ( Throwable $e ) {
				++$state['errors'];
				$state['last_error'] = 'preference ' . (int) $row->id . ': ' . mb_substr( $e->getMessage(), 0, 200 );
			}
		}

		$state['preferences_done'] = true;
	}
}
