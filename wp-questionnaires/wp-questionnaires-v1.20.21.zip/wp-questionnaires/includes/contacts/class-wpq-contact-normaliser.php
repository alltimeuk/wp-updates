<?php
/**
 * Pure string normalisation for contact identities and names. No database,
 * no WordPress state — fully unit-testable.
 *
 * Deliberately conservative: email domains are lowercased for comparison but
 * provider-specific rewrites (Gmail dot removal, plus-addressing) are never
 * applied, because they assert identity facts this plugin cannot know.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Contact_Normaliser {

	/**
	 * Local parts that identify a shared role mailbox rather than a person.
	 * A role mailbox is an ambiguity signal, never proof of shared identity.
	 */
	public const ROLE_MAILBOX_LOCAL_PARTS = [
		'info', 'sales', 'admin', 'accounts', 'support', 'contact', 'office',
		'enquiries', 'inquiries', 'hello', 'help', 'billing', 'noreply',
		'no-reply', 'mail', 'team', 'reception', 'service', 'it',
	];

	/**
	 * Comparison form of an email: trimmed, domain lowercased. The local part's
	 * case is also folded for comparison (RFC-permitted case sensitivity is
	 * ignored by every real provider), but no other rewriting happens.
	 */
	public static function normalise_email( string $email ): string {
		$email = trim( $email );
		if ( '' === $email || ! str_contains( $email, '@' ) ) {
			return '';
		}

		[ $local, $domain ] = array_pad( explode( '@', $email, 2 ), 2, '' );
		if ( '' === $local || '' === $domain ) {
			return '';
		}

		return mb_strtolower( $local ) . '@' . mb_strtolower( $domain );
	}

	/**
	 * Telephone comparison form: strip spacing/punctuation but keep the leading
	 * '+'. Without a reliable country context we make no equivalence claims
	 * between local and international forms — two different strings stay two
	 * different identities.
	 */
	public static function normalise_telephone( string $telephone ): string {
		$telephone = trim( $telephone );
		$plus      = str_starts_with( $telephone, '+' );
		$digits    = preg_replace( '/\D+/', '', $telephone ) ?? '';
		if ( '' === $digits ) {
			return '';
		}

		return ( $plus ? '+' : '' ) . $digits;
	}

	/** Indexed exact-match key for an identity value. */
	public static function identity_hash( string $type, string $normalised ): string {
		return hash( 'sha256', $type . ':' . $normalised );
	}

	public static function is_role_mailbox( string $email ): bool {
		$normalised = self::normalise_email( $email );
		if ( '' === $normalised ) {
			return false;
		}
		$local = explode( '@', $normalised, 2 )[0];

		return in_array( $local, self::ROLE_MAILBOX_LOCAL_PARTS, true );
	}

	/** Unicode-aware comparison form of a person name. */
	public static function normalise_name( string $name ): string {
		$name = trim( preg_replace( '/\s+/u', ' ', $name ) ?? '' );

		return mb_strtolower( $name );
	}

	/**
	 * Whether two supplied names disagree enough to block an automatic link.
	 * Same string, either side empty, or one containing the other (e.g.
	 * "Simon" vs "Simon Jackson") is not material; different people's names
	 * on the same mailbox are.
	 */
	public static function names_conflict_materially( string $a, string $b ): bool {
		$a = self::normalise_name( $a );
		$b = self::normalise_name( $b );

		if ( '' === $a || '' === $b || $a === $b ) {
			return false;
		}
		if ( str_contains( $a, $b ) || str_contains( $b, $a ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Split a display name into given/family halves. Best-effort — the last
	 * word is the family name, everything before it the given name(s).
	 *
	 * @return array{given: string, family: string}
	 */
	public static function split_name( string $display_name ): array {
		$display_name = trim( preg_replace( '/\s+/u', ' ', $display_name ) ?? '' );
		if ( '' === $display_name ) {
			return [ 'given' => '', 'family' => '' ];
		}

		$parts = explode( ' ', $display_name );
		if ( count( $parts ) === 1 ) {
			return [ 'given' => $parts[0], 'family' => '' ];
		}

		$family = (string) array_pop( $parts );

		return [ 'given' => implode( ' ', $parts ), 'family' => $family ];
	}

	/** RFC 4122 v4 shape check for UUIDs received from trusted integrations. */
	public static function is_valid_uuid( string $uuid ): bool {
		return 1 === preg_match(
			'/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',
			$uuid
		);
	}
}
