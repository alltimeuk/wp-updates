<?php
/**
 * Adapter implementing wp-reconnaissance's Alltime\CustomerPlatform contact
 * contract on top of wp-questionnaires' canonical contact service.
 *
 * This file is ONLY loaded when the Alltime\CustomerPlatform interfaces are
 * present (i.e. wp-reconnaissance is active) — see
 * WPQ_Customer_Platform_Bridge::register(). It must never be required
 * unconditionally: the `implements` clause resolves at class-definition time.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

use Alltime\CustomerPlatform\Contact;
use Alltime\CustomerPlatform\ConsentInput;
use Alltime\CustomerPlatform\ContactInput;
use Alltime\CustomerPlatform\ContactResult;
use Alltime\CustomerPlatform\ContactServiceInterface;
use Alltime\CustomerPlatform\Enums\ConsentState;
use Alltime\CustomerPlatform\InteractionInput;
use Alltime\CustomerPlatform\PurposeContext;
use Alltime\CustomerPlatform\VisitorContext;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One canonical contact across both products: recon's registration and
 * report flows resolve this adapter through ContactPlatformDiscovery and
 * write into the wpq_* canonical tables (the richer model, and the one
 * HaloPSA reconciles against) instead of a parallel per-product store.
 */
final class WPQ_Customer_Platform_Adapter implements ContactServiceInterface {

	public function resolve_visitor_context(): VisitorContext {
		$user_id = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		if ( $user_id > 0 ) {
			$contact = WPQ_Contact_Service::instance()->get_for_wordpress_user( $user_id );
			if ( $contact ) {
				return new VisitorContext( (int) $contact->id, true );
			}
		}

		return new VisitorContext( null, false );
	}

	public function create_or_update_contact( ContactInput $input, PurposeContext $purpose ): ContactResult {
		$result = WPQ_Contact_Service::instance()->resolve_or_create(
			[
				'name'         => trim( $input->given_name . ' ' . $input->family_name ),
				'email'        => $input->email,
				'telephone'    => (string) ( $input->telephone ?? '' ),
				'organisation' => (string) ( $input->organisation_name ?? '' ),
			],
			[
				'source'      => sanitize_key( $purpose->product_id ),
				'source_type' => sanitize_key( $purpose->purpose ),
			]
		);

		$contact_id = (int) ( $result['contact_id'] ?? 0 );
		$row        = $contact_id > 0 ? WPQ_Contact_Service::instance()->get_by_id( $contact_id ) : null;
		if ( ! $row ) {
			throw new RuntimeException( 'Canonical contact could not be resolved.' );
		}

		return new ContactResult( self::to_platform_contact( $row ), (bool) ( $result['created'] ?? false ) );
	}

	public function link_wordpress_user( int $contact_id, int $user_id ): void {
		WPQ_Contact_Service::instance()->link_wordpress_user( $contact_id, $user_id );
	}

	public function record_interaction( int $contact_id, InteractionInput $interaction ): int {
		return WPQ_Contact_Service::instance()->record_interaction( $contact_id, [
			'product'          => $interaction->product_id,
			'interaction_type' => $interaction->interaction_type,
			'source_type'      => $interaction->source_object_type,
			'source_id'        => (int) ( $interaction->source_object_id ?? 0 ),
			'source_ref'       => (string) ( $interaction->campaign_reference ?? '' ),
			'occurred_at'      => $interaction->occurred_at ? $interaction->occurred_at->format( 'Y-m-d H:i:s' ) : current_time( 'mysql', true ),
			'attribution'      => (string) ( $interaction->purpose ?? '' ),
		] );
	}

	public function record_consent( int $contact_id, ConsentInput $consent ): int {
		return WPQ_Contact_Service::instance()->record_consent_event( $contact_id, [
			'purpose' => $consent->purpose,
			'event'   => ConsentState::Granted === $consent->state ? 'granted' : 'withdrawn',
			'source'  => $consent->source,
		] );
	}

	public function get_contact_for_user( int $user_id ): ?Contact {
		$row = WPQ_Contact_Service::instance()->get_for_wordpress_user( $user_id );
		return $row ? self::to_platform_contact( $row ) : null;
	}

	public function get_contact_for_email( string $email ): ?Contact {
		$normalised = WPQ_Contact_Normaliser::normalise_email( $email );
		if ( '' === $normalised ) {
			return null;
		}

		$candidates = WPQ_Contact_Repository::find_contacts_by_identity(
			'email',
			WPQ_Contact_Normaliser::identity_hash( 'email', $normalised )
		);
		if ( empty( $candidates ) ) {
			return null;
		}

		$row = WPQ_Contact_Repository::resolve_merged( $candidates[0] );
		return self::to_platform_contact( $row );
	}

	/**
	 * Maps a wpq_contacts row onto the platform Contact DTO. Status mapping is
	 * explicit because ContactLifecycleStatus::from() throws on unknown values:
	 * provisional→prospect, merged→merged, deleted/anonymised→deleted,
	 * everything else→active (verified) or prospect.
	 */
	private static function to_platform_contact( object $row ): Contact {
		$status = (string) ( $row->status ?? 'provisional' );
		$lifecycle = match ( $status ) {
			'provisional'          => 'prospect',
			'merged'               => 'merged',
			'deleted', 'anonymised' => 'deleted',
			default                => empty( $row->verified_at ) ? 'prospect' : 'active',
		};

		return Contact::from_row( [
			'id'               => (int) $row->id,
			'contact_uuid'     => (string) ( $row->uuid ?? '' ),
			'given_name'       => (string) ( $row->given_name ?? '' ),
			'family_name'      => (string) ( $row->family_name ?? '' ),
			'wp_user_id'       => isset( $row->wp_user_id ) && null !== $row->wp_user_id ? (int) $row->wp_user_id : null,
			'lifecycle_status' => $lifecycle,
			'created_at'       => (string) ( $row->created_at ?? current_time( 'mysql', true ) ),
			'verified_at'      => (string) ( $row->verified_at ?? '' ),
			'updated_at'       => (string) ( $row->updated_at ?? current_time( 'mysql', true ) ),
		] );
	}
}
