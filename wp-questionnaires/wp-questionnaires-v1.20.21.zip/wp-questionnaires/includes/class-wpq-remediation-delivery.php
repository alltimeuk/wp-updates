<?php
/**
 * Customer delivery for AI remediation workbooks, mirroring the Questionnaire
 * Report delivery architecture: a configurable global channel list, a
 * per-questionnaire override, and purpose-scoped tokenised download links.
 *
 * The workbook itself is generated on demand (WPQ_Remediation_Plan); this
 * class decides how a generated workbook reaches the customer.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Remediation_Delivery {

	/** Direct download from the results screen — the original behaviour. */
	public const CHANNEL_RESULTS_DOWNLOAD = 'results_download';

	/** Email the customer a secure link to the stored workbook. */
	public const CHANNEL_EMAIL = 'email';

	public const TOKEN_PURPOSE     = 'remediation_workbook';
	public const TOKEN_TTL_SECONDS = 30 * DAY_IN_SECONDS;
	public const TOKEN_MAX_USES    = 10;

	private const OPTION_CHANNELS = 'wpq_remediation_delivery_channels';

	/**
	 * @return array<string, array{label: string, description: string, pull: bool}>
	 */
	public static function channels(): array {
		return [
			self::CHANNEL_RESULTS_DOWNLOAD => [
				'label'       => 'Direct download on the results screen',
				'description' => 'The customer generates and downloads the workbook from the results screen.',
				'pull'        => true,
			],
			self::CHANNEL_EMAIL => [
				'label'       => 'Email the customer a secure link',
				'description' => 'Stores the generated workbook and emails the customer a tokenised download link. The workbook itself is never attached.',
				'pull'        => false,
			],
		];
	}

	/** @return array<int, string> */
	public static function channel_keys(): array {
		return array_keys( self::channels() );
	}

	/**
	 * Channels enabled site-wide. Defaults to the results-screen download so
	 * existing installs keep their behaviour until an admin changes it.
	 *
	 * @return array<int, string>
	 */
	public static function global_channels(): array {
		return self::normalise( (string) get_option( self::OPTION_CHANNELS, self::CHANNEL_RESULTS_DOWNLOAD ) );
	}

	/**
	 * Channels for one questionnaire: its own list when defined, the global list
	 * otherwise. '' means inherit; 'none' disables customer delivery entirely.
	 *
	 * @return array<int, string>
	 */
	public static function channels_for_questionnaire( ?object $questionnaire ): array {
		$override = trim( (string) ( $questionnaire->remediation_delivery_channels ?? '' ) );
		if ( '' === $override ) {
			return self::global_channels();
		}
		if ( 'none' === strtolower( $override ) ) {
			return [];
		}

		return self::normalise( $override );
	}

	public static function channel_enabled( ?object $questionnaire, string $channel ): bool {
		return in_array( $channel, self::channels_for_questionnaire( $questionnaire ), true );
	}

	/** True when any channel would put a workbook in front of a customer. */
	public static function delivery_enabled( ?object $questionnaire ): bool {
		if ( ! $questionnaire || ! class_exists( 'WPQ_Feature_Flags' ) ) {
			return false;
		}
		if ( ! WPQ_Feature_Flags::remediation_plan_download_enabled_for_questionnaire( $questionnaire ) ) {
			return false;
		}

		return ! empty( self::channels_for_questionnaire( $questionnaire ) );
	}

	/**
	 * Normalise a stored channel list to known keys in canonical order.
	 *
	 * @return array<int, string>
	 */
	public static function normalise( string $stored ): array {
		$stored = trim( $stored );
		if ( '' === $stored ) {
			return [];
		}

		$decoded = json_decode( $stored, true );
		$values  = is_array( $decoded ) ? $decoded : explode( ',', $stored );

		$clean = [];
		foreach ( $values as $value ) {
			if ( ! is_scalar( $value ) ) {
				continue;
			}
			$key = sanitize_key( (string) $value );
			if ( '' !== $key && ! in_array( $key, $clean, true ) ) {
				$clean[] = $key;
			}
		}

		return array_values( array_intersect( self::channel_keys(), $clean ) );
	}

	/**
	 * @param array<int, string> $channels
	 */
	public static function to_storage( array $channels ): string {
		return implode( ',', self::normalise( implode( ',', array_map( 'strval', $channels ) ) ) );
	}

	// ------------------------------------------------------------------ //
	// Push delivery
	// ------------------------------------------------------------------ //

	/**
	 * Run the email channel for a workbook that has just been generated: store
	 * the artefact, mint a purpose-scoped link, and email it to the customer.
	 *
	 * @param array{filename: string, binary: string} $workbook
	 * @return array{email_sent: bool, reason: string}
	 */
	public static function deliver_workbook( object $submission, ?object $questionnaire, array $workbook ): array {
		if ( ! self::channel_enabled( $questionnaire, self::CHANNEL_EMAIL ) ) {
			return [ 'email_sent' => false, 'reason' => 'email_channel_disabled' ];
		}
		if ( class_exists( 'WPQ_Mailer' ) && ! WPQ_Mailer::allowed_for_questionnaire( $questionnaire ) ) {
			return [ 'email_sent' => false, 'reason' => 'mail_delivery_disabled' ];
		}

		$email = sanitize_email( (string) ( $submission->contact_email ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return [ 'email_sent' => false, 'reason' => 'no_contact_email' ];
		}

		$stored = class_exists( 'WPQ_Questionnaire_Report_Storage' )
			? WPQ_Questionnaire_Report_Storage::store_remediation_xlsx( (int) $submission->id, (string) ( $workbook['binary'] ?? '' ) )
			: [];
		if ( empty( $stored['path'] ) ) {
			return [ 'email_sent' => false, 'reason' => 'store_failed' ];
		}

		WPQ_Database::update_submission_remediation( (int) $submission->id, [
			'remediation_xlsx_path' => (string) $stored['path'],
		] );

		$link = self::mint_link( (int) $submission->id );
		if ( '' === $link ) {
			return [ 'email_sent' => false, 'reason' => 'link_unavailable' ];
		}

		$name    = trim( (string) ( $submission->contact_name ?? '' ) );
		$subject = 'Your remediation plan is ready';
		$body    = ( '' !== $name ? "Hello {$name},\n\n" : "Hello,\n\n" )
			. "Your cyber security remediation plan workbook is ready to download:\n\n"
			. $link . "\n\n"
			. 'The link expires after ' . (int) round( self::TOKEN_TTL_SECONDS / DAY_IN_SECONDS )
			. ' days or ' . self::TOKEN_MAX_USES . " downloads.\n";

		$sent = class_exists( 'WPQ_Mailer' )
			? WPQ_Mailer::send( $email, $subject, $body )
			: (bool) wp_mail( $email, $subject, $body );

		return [ 'email_sent' => $sent, 'reason' => $sent ? 'sent' : 'send_failed' ];
	}

	/** Mint a fresh tokenised download URL for the stored workbook. */
	public static function mint_link( int $submission_id ): string {
		if ( $submission_id <= 0 ) {
			return '';
		}

		$token = WPQ_Database::create_report_token(
			$submission_id,
			self::TOKEN_TTL_SECONDS,
			self::TOKEN_MAX_USES,
			self::TOKEN_PURPOSE
		);
		if ( empty( $token['token'] ) ) {
			return '';
		}

		return add_query_arg(
			[ 'token' => (string) $token['token'] ],
			rest_url( WPQ_REST_NAMESPACE . '/remediation-workbook/' . $submission_id )
		);
	}
}
