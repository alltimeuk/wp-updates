<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var object{id:int, ref:string, name:string, description:string, status:string,
 *             stripe_product_id:string|null} $questionnaire
 * @var array<int, object{id:int, icon:string, name:string, slug:string, sort_order:int, domain_weight:int, brief:string|null}> $domains
 * @var array<int, object{id:int, min_score:int, grade_id:string, grade_label:string, verdict_text:string, color_hex:string, bg_hex:string}> $thresholds
 * @var array<int, object{id:int, name:string, price_gbp:float, stripe_price_id:string, billing_type:string, status:string}> $q_products
 */

$q_id = (int) $questionnaire->id;
$claude_project_name = class_exists( 'WPQ_Claude' ) ? WPQ_Claude::project_name_for_questionnaire( $questionnaire ) : (string) $questionnaire->name;
$claude_template_id  = (int) ( $questionnaire->claude_template_attachment_id ?? 0 );
$claude_template_path = $claude_template_id > 0 && function_exists( 'get_attached_file' ) ? get_attached_file( $claude_template_id ) : '';
$claude_template_name = is_string( $claude_template_path ) && '' !== $claude_template_path ? basename( $claude_template_path ) : '';
$billing_labels = [
	'one_off'               => 'One-off',
	'subscription_annual'   => 'Annual subscription',
	'subscription_monthly'  => 'Monthly subscription',
];

// Build domain label map: sorted by sort_order → A, B, C...
$domain_labels = [];
foreach ( $domains as $di => $domain ) {
	$domain_labels[ (int) $domain->id ] = chr( 65 + $di );
}

// Load all questions for the Questions and Scoring tabs.
$all_questions        = WPQ_Database::get_questions_for_questionnaire( $q_id );
$domain_q_counters    = [];
foreach ( $all_questions as $aq ) {
	$did = (int) $aq->domain_id;
	if ( ! isset( $domain_q_counters[ $did ] ) ) {
		$domain_q_counters[ $did ] = 0;
	}
	$domain_q_counters[ $did ]++;
	$aq->label = ( $domain_labels[ $did ] ?? '?' ) . $domain_q_counters[ $did ];
}
?>
<div class="wrap wpq-admin-wrap">
  <h1>
    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-library' ) ); ?>">← Questionnaires</a>
    &nbsp;/&nbsp; <?php echo esc_html( $questionnaire->name ); ?>
  </h1>

  <!-- Nav tabs -->
  <nav class="nav-tab-wrapper wpq-nav-tabs">
    <a href="#tab-details"   class="nav-tab nav-tab-active" data-tab="details">Details</a>
    <a href="#tab-domains"   class="nav-tab" data-tab="domains">Domains</a>
    <a href="#tab-questions" class="nav-tab" data-tab="questions">Questions</a>
    <a href="#tab-scoring"   class="nav-tab" data-tab="scoring">Scoring</a>
    <a href="#tab-grades"    class="nav-tab" data-tab="grades">Grades</a>
  </nav>

  <!-- ---------------------------------------------------------------- -->
  <!-- TAB: DETAILS                                                      -->
  <!-- ---------------------------------------------------------------- -->
  <div id="tab-details" class="wpq-tab-panel">
    <div class="wpq-card">
      <table class="form-table">
        <tr>
          <th>Reference</th>
          <td><code><?php echo esc_html( $questionnaire->ref ); ?></code></td>
        </tr>
        <tr>
          <th><label for="wpq-q-name">Name</label></th>
          <td><input type="text" id="wpq-q-name" class="regular-text" value="<?php echo esc_attr( $questionnaire->name ); ?>" data-field="name"></td>
        </tr>
        <tr>
          <th><label for="wpq-q-desc">Description</label></th>
          <td><textarea id="wpq-q-desc" class="large-text" rows="4" data-field="description"><?php echo esc_textarea( $questionnaire->description ); ?></textarea></td>
        </tr>
        <tr>
          <th><label for="wpq-q-status">Status</label></th>
          <td>
            <select id="wpq-q-status" data-field="status">
              <?php foreach ( [ 'draft' => 'Draft', 'preview' => 'Preview', 'live' => 'Live', 'retired' => 'Retired' ] as $k => $v ) : ?>
                <option value="<?php echo esc_attr( $k ); ?>" <?php selected( $questionnaire->status, $k ); ?>><?php echo esc_html( $v ); ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <tr>
          <th><label for="wpq-stripe-product-id">Stripe Product ID</label></th>
          <td>
            <input type="text" id="wpq-stripe-product-id" class="regular-text"
                   value="<?php echo esc_attr( $questionnaire->stripe_product_id ?? '' ); ?>"
                   placeholder="prod_XXXXXXXXXXXXXXXX">
          </td>
        </tr>
        <tr>
          <th>Claude project name</th>
          <td><code><?php echo esc_html( $claude_project_name ); ?></code></td>
        </tr>
        <tr>
          <th><label for="wpq-claude-project-id">Claude project ID</label></th>
          <td>
            <input type="text" id="wpq-claude-project-id" class="regular-text"
                   value="<?php echo esc_attr( $questionnaire->claude_project_id ?? '' ); ?>"
                   placeholder="Enter an existing Claude/Anthropic project identifier">
            <p class="description">Automatic Claude.ai Project creation is not available through the supported public Anthropic API. Enter a known identifier for internal traceability.</p>
          </td>
        </tr>
        <tr>
          <th>Claude status</th>
          <td>
            <strong><?php echo esc_html( (string) ( $questionnaire->claude_project_status ?? 'not_started' ) ); ?></strong>
            <?php if ( ! empty( $questionnaire->claude_project_verified_at ) ) : ?>
              <span class="description">Last checked <?php echo esc_html( wp_date( 'd M Y H:i', strtotime( (string) $questionnaire->claude_project_verified_at ) ) ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $questionnaire->claude_project_last_error ) ) : ?>
              <p class="description" style="color:#b32d2e;"><?php echo esc_html( (string) $questionnaire->claude_project_last_error ); ?></p>
            <?php endif; ?>
          </td>
        </tr>
      </table>
      <p class="submit">
        <button class="button button-primary" id="wpq-save-questionnaire" data-id="<?php echo (int) $questionnaire->id; ?>">Save details</button>
        <span class="wpq-save-status" id="wpq-q-save-status"></span>
      </p>
      <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:-8px;">
        <?php wp_nonce_field( 'wpq_verify_claude_project' ); ?>
        <input type="hidden" name="action" value="wpq_verify_claude_project">
        <input type="hidden" name="questionnaire_id" value="<?php echo (int) $questionnaire->id; ?>">
        <button type="submit" class="button">Verify Claude project state</button>
      </form>
    </div>

    <div class="wpq-card" style="margin-top:16px;">
      <h3 style="margin-top:0;">
        Pricing
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-products' ) ); ?>" style="font-size:.75em;font-weight:400;margin-left:12px;">Manage in Pricing &#8599;</a>
      </h3>
      <?php if ( empty( $q_products ) ) : ?>
        <p style="color:#888;font-style:italic;">No price tiers configured for this questionnaire.</p>
      <?php else : ?>
        <table class="wp-list-table widefat striped" style="margin-top:8px;">
          <thead>
            <tr>
              <th>Name</th>
              <th>Billing</th>
              <th style="width:80px;">Price</th>
              <th>Stripe Price ID</th>
              <th style="width:80px;">Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ( $q_products as $qp ) : ?>
              <tr>
                <td><?php echo esc_html( $qp->name ); ?></td>
                <td><?php echo esc_html( $billing_labels[ $qp->billing_type ] ?? $qp->billing_type ); ?></td>
                <td>£<?php echo esc_html( number_format( (float) $qp->price_gbp, 2 ) ); ?></td>
                <td><code><?php echo esc_html( $qp->stripe_price_id ?: '—' ); ?></code></td>
                <td><?php echo esc_html( ucfirst( $qp->status ) ); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

    <div class="wpq-card" style="margin-top:16px;">
      <h3 style="margin-top:0;">Claude report template</h3>
      <p class="description" style="max-width:780px;">Upload a questionnaire-specific <code>.docx</code> template. The template is tracked by attachment ID and checksum for future AI report generation; the plugin does not claim Claude can directly edit and return Word documents through unsupported Claude.ai Project APIs.</p>
      <table class="widefat striped" style="max-width:900px;margin:12px 0;">
        <tbody>
          <tr><th style="width:180px;">Current template</th><td><?php echo $claude_template_name ? esc_html( $claude_template_name ) : esc_html( 'None uploaded' ); ?></td></tr>
          <tr><th>Checksum</th><td><code><?php echo esc_html( (string) ( $questionnaire->claude_template_checksum ?? '' ) ); ?></code></td></tr>
          <tr><th>Updated</th><td><?php echo ! empty( $questionnaire->claude_template_updated_at ) ? esc_html( wp_date( 'd M Y H:i', strtotime( (string) $questionnaire->claude_template_updated_at ) ) ) : esc_html( 'Never' ); ?></td></tr>
        </tbody>
      </table>
      <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <?php wp_nonce_field( 'wpq_upload_claude_template' ); ?>
        <input type="hidden" name="action" value="wpq_upload_claude_template">
        <input type="hidden" name="questionnaire_id" value="<?php echo (int) $questionnaire->id; ?>">
        <input type="file" name="claude_template" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
        <button type="submit" class="button button-primary"><?php echo $claude_template_name ? esc_html( 'Replace template' ) : esc_html( 'Upload template' ); ?></button>
      </form>
      <?php if ( $claude_template_id > 0 ) : ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;">
          <?php wp_nonce_field( 'wpq_remove_claude_template' ); ?>
          <input type="hidden" name="action" value="wpq_remove_claude_template">
          <input type="hidden" name="questionnaire_id" value="<?php echo (int) $questionnaire->id; ?>">
          <button type="submit" class="button" style="color:#a00;">Remove template</button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- TAB: DOMAINS                                                      -->
  <!-- ---------------------------------------------------------------- -->
  <div id="tab-domains" class="wpq-tab-panel wpq-hidden">
    <div class="wpq-card">
      <p class="description">Domains are labelled A, B, C… by sort order. Changing sort order or adding/removing domains re-labels all questions — click save after reordering.</p>
      <div style="display:flex;justify-content:flex-end;align-items:center;gap:10px;margin:10px 4px 4px;">
        <span class="wpq-save-status wpq-domains-status" aria-live="polite"></span>
        <button type="button" class="button button-primary wpq-save-domains">Save domains</button>
      </div>
      <table class="wp-list-table widefat fixed striped" style="margin-top:12px;">
        <thead>
          <tr>
            <th style="width:40px;">Label</th>
            <th style="width:56px;">Icon</th>
            <th style="width:200px;">Name</th>
            <th style="padding-left:12px;">Brief</th>
            <th style="width:80px;">Questions</th>
            <th style="width:80px;">Sort order</th>
            <th style="width:160px;">Actions</th>
          </tr>
        </thead>
        <tbody id="wpq-domains-tbody">
          <?php foreach ( $domains as $di => $domain ) : ?>
            <?php $d_label = chr( 65 + $di ); ?>
            <tr data-id="<?php echo (int) $domain->id; ?>">
              <td><strong style="font-size:1.2em;color:#2D2C94;"><?php echo esc_html( $d_label ); ?></strong></td>
              <td><input type="text" class="small-text wpq-domain-field" data-field="icon" value="<?php echo esc_attr( $domain->icon ); ?>" style="width:44px;"></td>
              <td><input type="text" class="wpq-domain-field" data-field="name" value="<?php echo esc_attr( $domain->name ); ?>" style="width:100%;box-sizing:border-box;"></td>
              <td style="padding-left:12px;"><textarea class="wpq-domain-field wpq-domain-brief-field" data-field="brief" rows="3" placeholder="Optional intro shown before domain questions…" style="width:100%;resize:vertical;"><?php echo esc_textarea( $domain->brief ?? '' ); ?></textarea></td>
              <td><?php echo count( WPQ_Database::get_questions( (int) $domain->id ) ); ?></td>
              <td><input type="number" class="small-text wpq-domain-field" data-field="sort_order" value="<?php echo (int) $domain->sort_order; ?>" style="width:56px;"></td>
              <td>
                <button class="button button-small wpq-delete-domain" data-id="<?php echo (int) $domain->id; ?>" style="color:#a00;">Delete</button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <!-- Add domain form -->
      <div style="margin-top:16px;padding-top:16px;border-top:1px solid #eee;">
        <strong>Add domain</strong>
        <div style="display:flex;gap:8px;align-items:flex-end;margin-top:8px;flex-wrap:wrap;">
          <label style="display:flex;flex-direction:column;font-size:.8em;font-weight:600;color:#555;">
            Icon <input type="text" id="wpq-new-domain-icon" class="small-text" placeholder="🔒" style="width:44px;">
          </label>
          <label style="display:flex;flex-direction:column;font-size:.8em;font-weight:600;color:#555;flex:1;min-width:160px;">
            Name <input type="text" id="wpq-new-domain-name" class="regular-text" placeholder="Domain name" style="width:100%;">
          </label>
          <button class="button button-primary" id="wpq-add-domain-btn" data-q-id="<?php echo (int) $questionnaire->id; ?>">+ Add Domain</button>
          <span class="wpq-save-status" id="wpq-add-domain-status"></span>
        </div>
      </div>
    </div>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- TAB: QUESTIONS                                                    -->
  <!-- ---------------------------------------------------------------- -->
  <div id="tab-questions" class="wpq-tab-panel wpq-hidden">
    <?php if ( empty( $domains ) ) : ?>
      <div class="wpq-card"><p>Add domains first before creating questions.</p></div>
    <?php else : ?>
      <?php
      // Re-build per-domain view from $all_questions.
      $questions_by_domain = [];
      foreach ( $all_questions as $aq ) {
        $did = (int) $aq->domain_id;
        if ( ! isset( $questions_by_domain[ $did ] ) ) {
          $questions_by_domain[ $did ] = [];
        }
        $questions_by_domain[ $did ][] = $aq;
      }
      ?>
      <!-- Mass-insert toolbar -->
      <div class="wpq-card wpq-mass-toolbar">
        <button type="button" class="button wpq-reset-questions-btn" data-q-id="<?php echo (int) $q_id; ?>">&#9888; Reset Questions</button>
        <button type="button" class="button button-primary wpq-create-questions-btn">+ Create Questions</button>
        <div class="wpq-create-questions-form wpq-hidden" style="margin-top:12px;display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;">
          <span style="display:flex;flex-direction:column;gap:4px;">
            <label style="font-size:.8em;font-weight:600;color:#555;">Domain</label>
            <select class="wpq-cq-domain">
              <?php foreach ( $domains as $dci => $dcd ) : ?>
                <option value="<?php echo (int) $dcd->id; ?>"><?php echo esc_html( chr( 65 + $dci ) . ' — ' . $dcd->name ); ?></option>
              <?php endforeach; ?>
            </select>
          </span>
          <span style="display:flex;flex-direction:column;gap:4px;">
            <label style="font-size:.8em;font-weight:600;color:#555;">Number of questions</label>
            <input type="number" class="small-text wpq-cq-count" min="1" max="100" value="1">
          </span>
          <button type="button" class="button button-primary wpq-cq-go-btn" data-q-id="<?php echo (int) $q_id; ?>">Create</button>
          <button type="button" class="button wpq-cq-cancel-btn">Cancel</button>
          <span class="wpq-save-status wpq-cq-status"></span>
        </div>
      </div>

      <?php foreach ( $domains as $di => $domain ) : ?>
        <?php
          $d_label    = chr( 65 + $di );
          $d_qs       = $questions_by_domain[ (int) $domain->id ] ?? [];
        ?>
        <div class="wpq-card wpq-domain-section">
          <h2 class="wpq-domain-title wpq-domain-toggle" data-domain-id="<?php echo (int) $domain->id; ?>">
            <span class="wpq-domain-chevron">&#9660;</span>
            <?php echo esc_html( $domain->icon ); ?> <?php echo esc_html( $d_label . ' — ' . $domain->name ); ?>
            <span class="wpq-domain-qcount">(<?php echo count( $d_qs ); ?> question<?php echo count( $d_qs ) === 1 ? '' : 's'; ?>)</span>
          </h2>
          <div class="wpq-domain-body">

          <?php foreach ( $d_qs as $question ) : ?>
            <?php
              $q_type       = $question->question_type ?? 'tri_state';
              $scoring_mode = $question->scoring_mode   ?? 'legacy_tri_state';
              $is_required  = (bool) ( $question->is_required ?? 1 );
              $max_score    = '';
              if ( isset( $question->max_score ) && (int) $question->max_score > 0 ) {
                $max_score = (int) $question->max_score;
              }
              $help_text    = $question->help_text ?? '';
              $q_options    = WPQ_Database::get_question_options_all( (int) $question->id );
              $show_scores  = in_array( $q_type, [ 'tri_state', 'boolean' ], true );
              $recommendation = $question->recommendation ?? '';
              $show_options = in_array( $q_type, [ 'select', 'radio', 'checkbox' ], true );
              $show_max     = in_array( $scoring_mode, [ 'sum_selected', 'max_selected' ], true );
            ?>
            <div class="wpq-question-editor" data-id="<?php echo (int) $question->id; ?>" data-type="<?php echo esc_attr( $q_type ); ?>">
              <div class="wpq-q-num">
                <strong style="color:#2D2C94;"><?php echo esc_html( $question->label ); ?></strong>
              </div>

              <div class="wpq-q-fields">
                <input type="hidden" class="wpq-q-field" data-field="domain_id" value="<?php echo (int) $question->domain_id; ?>">
                <!-- Save/Delete pulled out to wpq-q-actions column below -->

                <div class="wpq-q-top-row">
                  <div class="wpq-q-row">
                    <label>Question</label>
                    <div class="wpq-q-text-wrap">
                      <textarea class="large-text wpq-q-field" rows="3" data-field="question_text"><?php echo esc_textarea( $question->question_text ); ?></textarea>
                    </div>
                  </div>
                  <div class="wpq-q-row wpq-q-recommendation<?php echo $show_scores ? '' : ' wpq-hidden'; ?>">
                    <label>Recommendation <span style="font-weight:400;color:#888;">(report — answer is No)</span></label>
                    <textarea class="large-text wpq-q-field" rows="3" data-field="recommendation" placeholder="Actionable text shown in the results report. Defaults to Recommendation — No if left blank."><?php echo esc_textarea( $recommendation ); ?></textarea>
                  </div>
                </div>

                <div class="wpq-q-row">
                  <span class="wpq-behaviour-group">
                    <span class="wpq-behaviour-cell">
                      <label for="wpq-qtype-<?php echo (int) $question->id; ?>">Type</label>
                      <select id="wpq-qtype-<?php echo (int) $question->id; ?>" data-field="question_type" class="wpq-q-field wpq-q-type-select">
                        <?php foreach ( [ 'tri_state' => 'Tri-state (Yes/Partial/No)', 'boolean' => 'Boolean (Yes/No)', 'select' => 'Select (dropdown)', 'radio' => 'Radio (one option)', 'checkbox' => 'Checkbox (multi-option)', 'memo' => 'Memo (free text)', 'short_text' => 'Short text', 'number' => 'Number' ] as $tv => $tl ) : ?>
                          <option value="<?php echo esc_attr( $tv ); ?>" <?php selected( $q_type, $tv ); ?>><?php echo esc_html( $tl ); ?></option>
                        <?php endforeach; ?>
                      </select>
                    </span>
                    <span class="wpq-behaviour-cell">
                      <label for="wpq-qmode-<?php echo (int) $question->id; ?>">Scoring mode</label>
                      <select id="wpq-qmode-<?php echo (int) $question->id; ?>" data-field="scoring_mode" class="wpq-q-field wpq-q-mode-select">
                        <?php foreach ( [ 'legacy_tri_state' => 'Legacy tri-state', 'boolean' => 'Boolean', 'reverse_boolean' => 'Reverse boolean', 'single_option' => 'Single option', 'sum_selected' => 'Sum selected', 'max_selected' => 'Max selected', 'non_scoring' => 'Non-scoring' ] as $mv => $ml ) : ?>
                          <option value="<?php echo esc_attr( $mv ); ?>" <?php selected( $scoring_mode, $mv ); ?>><?php echo esc_html( $ml ); ?></option>
                        <?php endforeach; ?>
                      </select>
                    </span>
                    <span class="wpq-behaviour-cell">
                      <label>Required?</label>
                      <span class="wpq-req-ctrl"><input type="checkbox" data-field="is_required" class="wpq-q-field" value="1" <?php checked( $is_required ); ?>> Required</span>
                    </span>
                    <span class="wpq-behaviour-cell wpq-behaviour-tip">
                      <label>Tip</label>
                      <input type="text" class="wpq-q-field" data-field="help_text" value="<?php echo esc_attr( $help_text ); ?>" placeholder="Optional hint shown to respondents">
                    </span>
                  </span>
                </div>

                <div class="wpq-q-row wpq-q-scores<?php echo $show_scores ? '' : ' wpq-hidden'; ?>">
                  <label>Scores: &nbsp;
                    Yes <input type="number" class="small-text wpq-q-field" min="0" max="10" data-field="score_yes" value="<?php echo (int) $question->score_yes; ?>">
                    &nbsp; Partial <input type="number" class="small-text wpq-q-field wpq-partial-score" min="0" max="10" data-field="score_partial" value="<?php echo (int) $question->score_partial; ?>"<?php echo $q_type === 'boolean' ? ' disabled style="opacity:.4"' : ''; ?>>
                    &nbsp; No <input type="number" class="small-text wpq-q-field" min="0" max="10" data-field="score_no" value="<?php echo (int) $question->score_no; ?>">
                  </label>
                </div>

                <div class="wpq-q-row wpq-q-maxscore<?php echo $show_max ? '' : ' wpq-hidden'; ?>">
                  <label>Max score cap (leave blank for no cap)
                    <input type="number" class="small-text wpq-q-field" min="0" max="100" data-field="max_score" value="<?php echo esc_attr( (string) $max_score ); ?>">
                  </label>
                </div>

                <div class="wpq-q-row wpq-q-options-manager<?php echo $show_options ? '' : ' wpq-hidden'; ?>">
                  <h4 style="margin:8px 0 4px;">Answer options</h4>
                  <table class="wp-list-table widefat wpq-options-table" data-question-id="<?php echo (int) $question->id; ?>">
                    <thead>
                      <tr>
                        <th>Key</th><th>Label</th><th>Score</th><th>Priority</th><th>Recommendation</th><th>Order</th><th>Default</th><th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ( $q_options as $opt ) : ?>
                      <tr data-option-id="<?php echo (int) $opt->id; ?>">
                        <td><input type="text" class="small-text wpq-opt-field" data-field="option_key" value="<?php echo esc_attr( $opt->option_key ); ?>"></td>
                        <td><input type="text" class="regular-text wpq-opt-field" data-field="option_label" value="<?php echo esc_attr( $opt->option_label ); ?>"></td>
                        <td><input type="number" class="small-text wpq-opt-field" min="0" max="100" data-field="score" value="<?php echo (int) $opt->score; ?>"></td>
                        <td>
                          <select class="wpq-opt-field" data-field="finding_priority">
                            <?php foreach ( [ '' => '—', 'critical' => 'Critical', 'high' => 'High', 'medium' => 'Medium', 'low' => 'Low' ] as $pv => $pl ) : ?>
                              <option value="<?php echo esc_attr( $pv ); ?>" <?php selected( $opt->finding_priority ?? '', $pv ); ?>><?php echo esc_html( $pl ); ?></option>
                            <?php endforeach; ?>
                            <option value="good_practice" <?php selected( in_array( (string) ( $opt->finding_priority ?? '' ), [ 'good', 'good_practice', 'informational', 'information', 'info' ], true ) ); ?>>Good Practice</option>
                          </select>
                        </td>
                        <td><input type="text" class="regular-text wpq-opt-field" data-field="finding_action" value="<?php echo esc_attr( $opt->finding_action ?? '' ); ?>"></td>
                        <td><input type="number" class="small-text wpq-opt-field" min="0" data-field="sort_order" value="<?php echo (int) $opt->sort_order; ?>"></td>
                        <td><input type="checkbox" class="wpq-opt-field" data-field="is_default" value="1" <?php checked( $opt->is_default, 1 ); ?>></td>
                        <td>
                          <button class="button button-small wpq-delete-option" data-option-id="<?php echo (int) $opt->id; ?>" style="color:#a00;">Remove</button>
                        </td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                      <tr><td colspan="8"><button class="button button-small wpq-add-option" data-question-id="<?php echo (int) $question->id; ?>">+ Add option</button></td></tr>
                    </tfoot>
                  </table>
                </div>
              </div><!-- /wpq-q-fields -->

              <div class="wpq-q-actions">
                <button class="button button-primary button-small wpq-save-question" data-id="<?php echo (int) $question->id; ?>">Save</button>
                <button class="button button-small wpq-delete-question" data-id="<?php echo (int) $question->id; ?>">Delete</button>
                <span class="wpq-save-status wpq-q-status-<?php echo (int) $question->id; ?>"></span>
              </div>
            </div><!-- /wpq-question-editor -->
          <?php endforeach; ?>

          <!-- Add question to this domain -->
          <div style="margin-top:12px;">
            <button class="button wpq-add-question-btn" data-domain-id="<?php echo (int) $domain->id; ?>">+ Add Question to <?php echo esc_html( $d_label ); ?></button>
            <span class="wpq-save-status wpq-addq-status-<?php echo (int) $domain->id; ?>"></span>
          </div>
          </div><!-- /wpq-domain-body -->
        </div><!-- /wpq-card wpq-domain-section -->
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- TAB: SCORING                                                      -->
  <!-- ---------------------------------------------------------------- -->
  <div id="tab-scoring" class="wpq-tab-panel wpq-hidden">
    <!-- Domain weights -->
    <div class="wpq-card">
      <h3 style="margin-top:0;">Domain Weights</h3>
      <p class="description">Relative weighting for each domain's contribution to the overall score. Default 100 = equal weight.</p>
      <table class="wp-list-table widefat" style="margin-top:12px;">
        <thead>
          <tr>
            <th style="width:48px;">Label</th>
            <th>Domain</th>
            <th style="width:100px;">Weight</th>
            <th style="width:80px;"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ( $domains as $di => $domain ) : ?>
            <tr>
              <td><strong style="color:#2D2C94;"><?php echo esc_html( chr( 65 + $di ) ); ?></strong></td>
              <td><?php echo esc_html( $domain->icon . ' ' . $domain->name ); ?></td>
              <td><input type="number" class="small-text wpq-domain-weight-input" min="0" max="9999" value="<?php echo (int) ( $domain->domain_weight ?? 100 ); ?>" data-id="<?php echo (int) $domain->id; ?>"></td>
              <td>
                <button class="button button-small wpq-save-domain-weight" data-id="<?php echo (int) $domain->id; ?>">Save</button>
                <span class="wpq-save-status wpq-dw-status-<?php echo (int) $domain->id; ?>"></span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Question scoring matrix -->
    <div class="wpq-card" style="margin-top:16px;">
      <h3 style="margin-top:0;">Question Scoring Matrix</h3>
      <p class="description">Set individual question weights and answer scores. Notation: A1:0 = question A1, answer value 0.</p>
      <?php if ( empty( $all_questions ) ) : ?>
        <p>No questions yet.</p>
      <?php else : ?>
        <table class="wp-list-table widefat" style="margin-top:12px;">
          <thead>
            <tr>
              <th style="width:48px;">Label</th>
              <th style="min-width:112px;width:20%;">Question</th>
              <th>Recommendations &amp; Scores</th>
              <th style="width:72px;">Weight</th>
              <th style="width:80px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php
            $s_d_counters = [];
            foreach ( $all_questions as $sq ) :
              $sdid = (int) $sq->domain_id;
              if ( ! isset( $s_d_counters[ $sdid ] ) ) {
                $s_d_counters[ $sdid ] = 0;
              }
              $s_d_counters[ $sdid ]++;
              $s_label      = ( $domain_labels[ $sdid ] ?? '?' ) . $s_d_counters[ $sdid ];
              $s_mode       = $sq->scoring_mode ?? 'legacy_tri_state';
              $non_scoring  = $s_mode === 'non_scoring';
              $is_bool      = in_array( $s_mode, [ 'boolean', 'reverse_boolean' ], true ) || $sq->question_type === 'boolean';
              $is_option    = in_array( $sq->question_type, [ 'select', 'radio', 'checkbox' ], true );
            ?>
            <?php
              $sq_q_type = $sq->question_type ?? 'tri_state';
              $sq_is_memo = in_array( $sq_q_type, [ 'memo', 'short_text' ], true );
              if ( $is_option ) {
                $sq_opts = WPQ_Database::get_question_options_all( (int) $sq->id );
              }
            ?>
            <tr data-id="<?php echo (int) $sq->id; ?>">
              <td><strong style="color:#2D2C94;"><?php echo esc_html( $s_label ); ?></strong></td>
              <td style="font-size:.9em;"><?php echo esc_html( mb_substr( $sq->question_text, 0, 80 ) . ( mb_strlen( $sq->question_text ) > 80 ? '…' : '' ) ); ?></td>

              <?php if ( $non_scoring || $sq_is_memo ) : ?>
                <td style="color:#aaa;font-style:italic;font-size:.85em;text-align:center;">—</td>
              <?php elseif ( $sq_q_type === 'boolean' ) : ?>
                <td>
                  <div style="display:grid;grid-template-columns:4em 1fr 38px;gap:3px 6px;align-items:start;">
                    <span style="font-size:.8em;font-weight:600;padding-top:5px;">True</span>
                    <textarea class="wpq-qs-guidance" data-field="guidance_yes" rows="2" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq->guidance_yes ?? '' ); ?></textarea>
                    <input type="number" class="small-text wpq-qs-score" data-field="score_yes" min="0" max="10" value="<?php echo (int) $sq->score_yes; ?>" title="Score (0–10)">
                    <span style="font-size:.8em;font-weight:600;padding-top:5px;">False</span>
                    <textarea class="wpq-qs-guidance" data-field="guidance_no" rows="2" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq->guidance_no ?? '' ); ?></textarea>
                    <input type="number" class="small-text wpq-qs-score" data-field="score_no" min="0" max="10" value="<?php echo (int) $sq->score_no; ?>" title="Score (0–10)">
                  </div>
                </td>
              <?php elseif ( $is_option ) : ?>
                <td>
                  <?php if ( empty( $sq_opts ) ) : ?>
                    <span style="color:#aaa;font-size:.85em;">No options</span>
                  <?php else : ?>
                    <div style="display:grid;grid-template-columns:auto 1fr;gap:3px 6px;align-items:start;">
                      <?php foreach ( $sq_opts as $sq_oi => $sq_opt ) : ?>
                        <span style="font-size:.8em;font-weight:600;padding-top:5px;white-space:nowrap;"><?php echo esc_html( chr( 97 + $sq_oi ) . ': ' . mb_substr( (string) $sq_opt->option_label, 0, 20 ) . ( mb_strlen( (string) $sq_opt->option_label ) > 20 ? '…' : '' ) ); ?></span>
                        <textarea class="wpq-qs-opt-guidance" data-option-id="<?php echo (int) $sq_opt->id; ?>" rows="1" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq_opt->guidance ?? '' ); ?></textarea>
                      <?php endforeach; ?>
                    </div>
                    <p style="margin:4px 0 0;font-size:.8em;color:#888;">Score: options-based</p>
                  <?php endif; ?>
                </td>
              <?php elseif ( $is_bool ) : ?>
                <td>
                  <div style="display:grid;grid-template-columns:4em 1fr 38px;gap:3px 6px;align-items:start;">
                    <span style="font-size:.8em;font-weight:600;padding-top:5px;">Yes</span>
                    <textarea class="wpq-qs-guidance" data-field="guidance_yes" rows="2" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq->guidance_yes ?? '' ); ?></textarea>
                    <input type="number" class="small-text wpq-qs-score" data-field="score_yes" min="0" max="10" value="<?php echo (int) $sq->score_yes; ?>" title="Score (0–10)">
                    <span style="font-size:.8em;font-weight:600;padding-top:5px;">No</span>
                    <textarea class="wpq-qs-guidance" data-field="guidance_no" rows="2" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq->guidance_no ?? '' ); ?></textarea>
                    <input type="number" class="small-text wpq-qs-score" data-field="score_no" min="0" max="10" value="<?php echo (int) $sq->score_no; ?>" title="Score (0–10)">
                  </div>
                </td>
              <?php else : // tri_state ?>
                <td>
                  <div style="display:grid;grid-template-columns:4em 1fr 38px;gap:3px 6px;align-items:start;">
                    <span style="font-size:.8em;font-weight:600;padding-top:5px;">Yes</span>
                    <textarea class="wpq-qs-guidance" data-field="guidance_yes" rows="2" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq->guidance_yes ?? '' ); ?></textarea>
                    <input type="number" class="small-text wpq-qs-score" data-field="score_yes" min="0" max="10" value="<?php echo (int) $sq->score_yes; ?>" title="Score (0–10)">
                    <span style="font-size:.8em;font-weight:600;padding-top:5px;">Partial</span>
                    <textarea class="wpq-qs-guidance" data-field="guidance_partial" rows="2" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq->guidance_partial ?? '' ); ?></textarea>
                    <input type="number" class="small-text wpq-qs-score" data-field="score_partial" min="0" max="10" value="<?php echo (int) $sq->score_partial; ?>" title="Score (0–10)">
                    <span style="font-size:.8em;font-weight:600;padding-top:5px;">No</span>
                    <textarea class="wpq-qs-guidance" data-field="guidance_no" rows="2" style="width:100%;font-size:.9em;font-weight:400;"><?php echo esc_textarea( $sq->guidance_no ?? '' ); ?></textarea>
                    <input type="number" class="small-text wpq-qs-score" data-field="score_no" min="0" max="10" value="<?php echo (int) $sq->score_no; ?>" title="Score (0–10)">
                  </div>
                </td>
              <?php endif; ?>

              <td><input type="number" class="small-text wpq-qs-weight" min="0" max="9999" value="<?php echo (int) ( $sq->question_weight ?? 100 ); ?>"></td>
              <td>
                <button class="button button-small wpq-save-question-scoring" data-id="<?php echo (int) $sq->id; ?>">Save</button>
                <span class="wpq-save-status wpq-qs-status-<?php echo (int) $sq->id; ?>"></span>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- TAB: GRADES                                                       -->
  <!-- ---------------------------------------------------------------- -->
  <div id="tab-grades" class="wpq-tab-panel wpq-hidden">
    <div class="wpq-card">
      <p class="description">Grades are evaluated highest to lowest. The first grade where the overall score meets or exceeds <code>min_score</code> is applied.</p>
      <div style="display:flex;justify-content:flex-end;align-items:center;gap:10px;margin:10px 4px 4px;">
        <span class="wpq-save-status wpq-grades-status" aria-live="polite"></span>
        <button type="button" class="button button-primary wpq-save-grades">Save grades</button>
      </div>
      <table class="wp-list-table widefat wpq-scoring-table" style="margin-top:16px;">
        <thead>
          <tr>
            <th>Min score (%)</th>
            <th>Grade ID</th>
            <th>Label</th>
            <th>Verdict text</th>
            <th>Text colour</th>
            <th>Background</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ( $thresholds as $t ) : ?>
            <tr data-id="<?php echo (int) $t->id; ?>">
              <td><input type="number" class="small-text wpq-grade-field" min="0" max="100" data-field="min_score" value="<?php echo (int) $t->min_score; ?>"></td>
              <td><code><?php echo esc_html( $t->grade_id ); ?></code></td>
              <td><input type="text" class="regular-text wpq-grade-field" data-field="grade_label" value="<?php echo esc_attr( $t->grade_label ); ?>"></td>
              <td><textarea class="wpq-grade-field" rows="2" data-field="verdict_text"><?php echo esc_textarea( $t->verdict_text ); ?></textarea></td>
              <td><input type="color" class="wpq-grade-field" data-field="color_hex" value="<?php echo esc_attr( $t->color_hex ); ?>"></td>
              <td><input type="color" class="wpq-grade-field" data-field="bg_hex" value="<?php echo esc_attr( $t->bg_hex ); ?>"></td>
              <td>
                <button class="button button-small wpq-delete-grade" data-id="<?php echo (int) $t->id; ?>">Remove</button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <p style="margin-top:12px;">
        <button type="button" class="button wpq-add-grade" data-q-id="<?php echo (int) $questionnaire->id; ?>">+ Add Grade</button>
      </p>
    </div>
  </div>

</div><!-- /.wrap -->

<script>
document.addEventListener('DOMContentLoaded', function() {
  var ref = '<?php echo esc_js( $questionnaire->ref ); ?>';
  if (document.getElementById('wpq-shortcode-helper')) {
    document.getElementById('wpq-shortcode-helper').textContent = '[wpq_questionnaire ref="' + ref + '"]';
  }
});
</script>
