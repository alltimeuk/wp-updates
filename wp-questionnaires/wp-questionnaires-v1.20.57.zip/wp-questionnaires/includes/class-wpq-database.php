<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Database {

	// ------------------------------------------------------------------ //
	// Logging
	// ------------------------------------------------------------------ //

	/**
	 * Record an operational failure to the PHP error log, gated behind
	 * WP_DEBUG_LOG per WordPress convention. Sole call site for error_log()
	 * in the plugin, so every caller only needs a phpcs:ignore once, here.
	 */
	public static function log_error( string $message ): void {
		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- sole call site; gated behind WP_DEBUG_LOG.
			error_log( $message );
		}
	}

	// ------------------------------------------------------------------ //
	// Stabilisation helpers
	// ------------------------------------------------------------------ //

	public static function begin_transaction(): bool {
		global $wpdb;
		return $wpdb->query( 'START TRANSACTION' ) !== false;
	}

	public static function commit_transaction(): bool {
		global $wpdb;
		return $wpdb->query( 'COMMIT' ) !== false;
	}

	public static function rollback_transaction(): bool {
		global $wpdb;
		return $wpdb->query( 'ROLLBACK' ) !== false;
	}

	/**
	 * Run a callback inside a database transaction.
	 *
	 * @param callable $callback Callback returning false to trigger rollback.
	 * @return mixed Callback result, or false when the transaction could not commit.
	 */
	public static function transaction( callable $callback ) {
		if ( ! self::begin_transaction() ) {
			return false;
		}

		try {
			$result = $callback();
			if ( $result === false ) {
				self::rollback_transaction();
				return false;
			}

			if ( ! self::commit_transaction() ) {
				self::rollback_transaction();
				return false;
			}

			return $result;
		} catch ( \Throwable $e ) {
			self::rollback_transaction();
			throw $e;
		}
	}

	public static function insert_audit_log( array $data ): int {
		global $wpdb;

		$before = self::normalise_audit_summary( $data['before_summary'] ?? null );
		$after  = self::normalise_audit_summary( $data['after_summary'] ?? null );
		$ip_hash = isset( $data['ip_address'] ) && $data['ip_address'] !== ''
			? hash_hmac( 'sha256', (string) $data['ip_address'], wp_salt( 'auth' ) )
			: ( isset( $data['ip_hash'] ) ? substr( sanitize_text_field( (string) $data['ip_hash'] ), 0, 64 ) : null );

		$row = [
			'event_type'     => substr( sanitize_key( (string) ( $data['event_type'] ?? '' ) ), 0, 100 ),
			'actor_user_id'  => isset( $data['actor_user_id'] ) ? (int) $data['actor_user_id'] : null,
			'actor_email'    => isset( $data['actor_email'] ) ? substr( sanitize_email( (string) $data['actor_email'] ), 0, 190 ) : null,
			'object_type'    => substr( sanitize_key( (string) ( $data['object_type'] ?? '' ) ), 0, 100 ),
			'object_id'      => isset( $data['object_id'] ) ? (int) $data['object_id'] : null,
			'before_summary' => $before,
			'after_summary'  => $after,
			'ip_hash'        => $ip_hash,
			'user_agent'     => isset( $data['user_agent'] ) ? substr( sanitize_text_field( (string) $data['user_agent'] ), 0, 255 ) : null,
			'created_at'     => $data['created_at'] ?? current_time( 'mysql', true ),
		];

		if ( $row['event_type'] === '' || $row['object_type'] === '' ) {
			return 0;
		}

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_audit_log", $row );
		if ( $inserted === false ) {
			self::log_error( 'WPQ insert_audit_log failed: ' . $wpdb->last_error );
			return 0;
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Daily retention automation (wpq_retention_daily cron): applies the same
	 * purge/anonymise thresholds the Settings -> Advanced buttons run manually,
	 * without requiring an administrator to remember to press them. Explicit
	 * double opt-in - the automation toggle AND a positive threshold - and
	 * every run that touched rows leaves an audit trail.
	 */
	public static function run_retention_automation(): void {
		if ( 'yes' !== get_option( 'wpq_retention_automation_enabled', 'no' ) ) {
			return;
		}

		$purge_days     = (int) get_option( 'wpq_purge_abandoned_days', 0 );
		$anonymise_days = (int) get_option( 'wpq_anonymise_completed_days', 0 );

		if ( $purge_days > 0 ) {
			$purged = self::purge_abandoned_submissions( $purge_days );
			if ( $purged > 0 ) {
				self::insert_audit_log( [
					'event_type'    => 'retention_purge_abandoned',
					'object_type'   => 'submission',
					'after_summary' => [ 'purged' => $purged, 'threshold_days' => $purge_days, 'actor' => 'retention_automation' ],
				] );
			}
		}

		if ( $anonymise_days > 0 ) {
			$anonymised = self::anonymise_old_submissions( $anonymise_days );
			if ( $anonymised > 0 ) {
				self::insert_audit_log( [
					'event_type'    => 'retention_anonymise_completed',
					'object_type'   => 'submission',
					'after_summary' => [ 'anonymised' => $anonymised, 'threshold_days' => $anonymise_days, 'actor' => 'retention_automation' ],
				] );
			}
		}
	}

	public static function rate_limit_storage_status(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'wpq_rate_limits';
		$previous_error = $wpdb->last_error;
		$wpdb->last_error = '';
		$available = $wpdb->query( $wpdb->prepare( 'SELECT 1 FROM %i LIMIT 0', $table ) ) !== false;
		$error = $wpdb->last_error;
		$wpdb->last_error = $previous_error;

		return [
			'table'     => $table,
			'available' => $available,
			'error'     => $available ? '' : $error,
		];
	}

	public static function check_rate_limit( string $endpoint, string $client_ip, int $limit, int $window_seconds, array $dimensions = [] ): ?bool {
		global $wpdb;

		if ( $limit <= 0 || $window_seconds <= 0 ) {
			return false;
		}

		$status = self::rate_limit_storage_status();
		if ( empty( $status['available'] ) ) {
			return null;
		}

		$endpoint = substr( sanitize_key( $endpoint ), 0, 100 );
		$client_hash = hash_hmac( 'sha256', $client_ip, wp_salt( 'auth' ) );
		$questionnaire_ref = isset( $dimensions['questionnaire_ref'] ) ? substr( sanitize_text_field( (string) $dimensions['questionnaire_ref'] ), 0, 50 ) : null;
		$submission_id = isset( $dimensions['submission_id'] ) ? max( 0, (int) $dimensions['submission_id'] ) : null;
		$email_hash = isset( $dimensions['email'] ) && is_email( (string) $dimensions['email'] )
			? hash_hmac( 'sha256', strtolower( (string) $dimensions['email'] ), wp_salt( 'auth' ) )
			: ( isset( $dimensions['email_hash'] ) ? substr( sanitize_text_field( (string) $dimensions['email_hash'] ), 0, 64 ) : null );

		$bucket_key = hash( 'sha256', implode( '|', [
			$endpoint,
			$client_hash,
			(string) $questionnaire_ref,
			(string) $submission_id,
			(string) $email_hash,
		] ) );
		$now = current_time( 'mysql', true );
		$expires_at = gmdate( 'Y-m-d H:i:s', time() + $window_seconds );
		$table = $wpdb->prefix . 'wpq_rate_limits';

		$sql = $wpdb->prepare(
			'INSERT INTO %i
				(bucket_key, endpoint, client_hash, questionnaire_ref, submission_id, email_hash, window_start, request_count, expires_at, created_at, updated_at)
			 VALUES (%s, %s, %s, %s, %d, %s, %s, 1, %s, %s, %s)
			 ON DUPLICATE KEY UPDATE
				request_count = IF(expires_at <= VALUES(window_start), 1, request_count + 1),
				window_start = IF(expires_at <= VALUES(window_start), VALUES(window_start), window_start),
				expires_at = IF(expires_at <= VALUES(window_start), VALUES(expires_at), expires_at),
				updated_at = VALUES(updated_at)',
			$table,
			$bucket_key,
			$endpoint,
			$client_hash,
			$questionnaire_ref,
			$submission_id,
			$email_hash,
			$now,
			$expires_at,
			$now,
			$now
		);
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared immediately above with value and identifier placeholders.
		$updated = $wpdb->query( $sql );

		if ( $updated === false ) {
			self::log_error( 'WPQ check_rate_limit failed: ' . $wpdb->last_error );
			return null;
		}

		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT request_count, expires_at FROM %i WHERE bucket_key = %s',
			$table,
			$bucket_key
		) );

		if ( ! $row ) {
			return null;
		}

		return (int) $row->request_count <= $limit;
	}

	private static function normalise_audit_summary( $summary ): ?string {
		if ( is_array( $summary ) || is_object( $summary ) ) {
			$encoded = wp_json_encode( $summary );
			return is_string( $encoded ) ? $encoded : null;
		}
		if ( $summary === null ) {
			return null;
		}
		return (string) $summary;
	}

	// ------------------------------------------------------------------ //
	// Questionnaires
	// ------------------------------------------------------------------ //

	public static function questionnaire_exists(): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( "SELECT id FROM {$wpdb->prefix}wpq_questionnaires LIMIT 1" );
	}

	public static function get_questionnaire_by_ref( string $ref ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_questionnaires WHERE ref = %s AND status IN ('preview', 'live')",
			$ref
		) ) ?: null;
	}

	public static function get_questionnaire_any_status_by_ref( string $ref ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_questionnaires WHERE ref = %s",
			$ref
		) ) ?: null;
	}

	public static function get_questionnaire( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_questionnaires WHERE id = %d",
			$id
		) ) ?: null;
	}

	public static function get_questionnaire_list( array $args = [] ): array {
		global $wpdb;
		$status = $args['status'] ?? null;
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- All interpolated values are $wpdb->prefix table-name constants, never user input.
		// Each count uses a non-correlated derived table that aggregates only from child
		// tables (never from wpq_questionnaires itself). This avoids MySQL's
		// "Can't reopen table" error, which fires whenever the same physical table
		// appears in both an outer query and a correlated/nested subquery.
		$where = $status ? $wpdb->prepare( ' WHERE q.status = %s', $status ) : '';
		// wpq_domains must appear only once - WordPress tests use TEMPORARY TABLEs
		// and MySQL forbids referencing the same temporary table more than once per query.
		// domain_count, question_count, and scored_question_count are all derived from
		// a single JOIN of domains → questions so wpq_domains is referenced exactly once.
		$sql   = "SELECT q.*,
		  COALESCE( sub.submission_count,      0 ) AS submission_count,
		  COALESCE( dq.domain_count,           0 ) AS domain_count,
		  COALESCE( dq.question_count,         0 ) AS question_count,
		  COALESCE( gr.grade_count,            0 ) AS grade_count,
		  COALESCE( dq.scored_question_count,  0 ) AS scored_question_count
		FROM {$wpdb->prefix}wpq_questionnaires q
		LEFT JOIN (
		  SELECT questionnaire_id, COUNT(*) AS submission_count
		  FROM   {$wpdb->prefix}wpq_submissions
		  WHERE  deleted_at IS NULL
		  GROUP BY questionnaire_id
		) sub ON sub.questionnaire_id = q.id
		LEFT JOIN (
		  SELECT
		    d.questionnaire_id,
		    COUNT( DISTINCT d.id ) AS domain_count,
		    COUNT( qn.id ) AS question_count,
		    SUM( CASE WHEN qn.scoring_mode != 'non_scoring' THEN 1 ELSE 0 END ) AS scored_question_count
		  FROM      {$wpdb->prefix}wpq_domains   d
		  LEFT JOIN {$wpdb->prefix}wpq_questions qn ON qn.domain_id = d.id
		  GROUP BY d.questionnaire_id
		) dq ON dq.questionnaire_id = q.id
		LEFT JOIN (
		  SELECT questionnaire_id, COUNT(*) AS grade_count
		  FROM   {$wpdb->prefix}wpq_grade_thresholds
		  GROUP BY questionnaire_id
		) gr ON gr.questionnaire_id = q.id
		{$where}
		ORDER BY q.category, q.ref";
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query is static plus a prepared status clause via $where ($wpdb->prepare() output assigned above); no unescaped user input reaches $sql.
		return $wpdb->get_results( $sql ) ?: [];
	}

	public static function update_questionnaire( int $id, array $data ): bool {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql', true );
		$result = $wpdb->update( "{$wpdb->prefix}wpq_questionnaires", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	public static function update_questionnaire_claude_template( int $id, int $attachment_id, string $checksum ): bool {
		if ( $id <= 0 || $attachment_id <= 0 || ! preg_match( '/^[a-f0-9]{64}$/', $checksum ) ) {
			return false;
		}

		return self::update_questionnaire( $id, [
			'claude_template_attachment_id' => $attachment_id,
			'claude_template_checksum'      => $checksum,
			'claude_template_updated_at'    => current_time( 'mysql', true ),
		] );
	}

	public static function clear_questionnaire_claude_template( int $id ): bool {
		if ( $id <= 0 ) {
			return false;
		}

		return self::update_questionnaire( $id, [
			'claude_template_attachment_id' => null,
			'claude_template_checksum'      => null,
			'claude_template_updated_at'    => null,
		] );
	}

	public static function update_questionnaire_remediation_template( int $id, int $attachment_id, string $checksum ): bool {
		if ( $id <= 0 || $attachment_id <= 0 || ! preg_match( '/^[a-f0-9]{64}$/', $checksum ) ) {
			return false;
		}

		return self::update_questionnaire( $id, [
			'remediation_template_attachment_id' => $attachment_id,
			'remediation_template_checksum'      => $checksum,
			'remediation_template_updated_at'    => current_time( 'mysql', true ),
		] );
	}

	public static function clear_questionnaire_remediation_template( int $id ): bool {
		if ( $id <= 0 ) {
			return false;
		}

		return self::update_questionnaire( $id, [
			'remediation_template_attachment_id' => null,
			'remediation_template_checksum'      => null,
			'remediation_template_updated_at'    => null,
		] );
	}

	public static function insert_questionnaire( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$data['created_at'] = $now;
		$data['updated_at'] = $now;
		$wpdb->insert( "{$wpdb->prefix}wpq_questionnaires", $data );
		return (int) $wpdb->insert_id;
	}

	// ------------------------------------------------------------------ //
	// Domains
	// ------------------------------------------------------------------ //

	public static function get_domains( int $questionnaire_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_domains WHERE questionnaire_id = %d ORDER BY sort_order ASC",
			$questionnaire_id
		) ) ?: [];
	}

	public static function insert_domain( array $data ): int {
		global $wpdb;
		$wpdb->insert( "{$wpdb->prefix}wpq_domains", $data );
		return (int) $wpdb->insert_id;
	}

	public static function update_domain( int $id, array $data ): bool {
		global $wpdb;
		$result = $wpdb->update( "{$wpdb->prefix}wpq_domains", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	public static function delete_domain( int $id ): bool {
		global $wpdb;
		// Cascade: question options → questions → domain.
		$wpdb->query( $wpdb->prepare(
			"DELETE qo FROM {$wpdb->prefix}wpq_question_options qo
			 JOIN {$wpdb->prefix}wpq_questions q ON q.id = qo.question_id
			 WHERE q.domain_id = %d",
			$id
		) );
		$wpdb->delete( "{$wpdb->prefix}wpq_questions", [ 'domain_id' => $id ] );
		return (bool) $wpdb->delete( "{$wpdb->prefix}wpq_domains", [ 'id' => $id ] );
	}

	// ------------------------------------------------------------------ //
	// Questions
	// ------------------------------------------------------------------ //

	public static function get_questions( int $domain_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_questions WHERE domain_id = %d ORDER BY sort_order ASC",
			$domain_id
		) ) ?: [];
	}

	// ------------------------------------------------------------------ //
	// Question Options
	// ------------------------------------------------------------------ //

	public static function get_question_options( int $question_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_question_options WHERE question_id = %d AND is_active = 1 ORDER BY sort_order ASC, id ASC",
			$question_id
		) ) ?: [];
	}

	public static function get_question_options_all( int $question_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_question_options WHERE question_id = %d ORDER BY sort_order ASC, id ASC",
			$question_id
		) ) ?: [];
	}

	public static function insert_question_option( array $data ): int {
		global $wpdb;
		$wpdb->insert( "{$wpdb->prefix}wpq_question_options", $data );
		return (int) $wpdb->insert_id;
	}

	public static function update_question_option( int $id, array $data ): bool {
		global $wpdb;
		$result = $wpdb->update( "{$wpdb->prefix}wpq_question_options", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	public static function delete_question_option( int $id ): bool {
		global $wpdb;
		$result = $wpdb->delete( "{$wpdb->prefix}wpq_question_options", [ 'id' => $id ] );
		return $result !== false;
	}

	public static function get_questions_for_questionnaire( int $questionnaire_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT q.*, d.slug AS domain_slug, d.name AS domain_name, d.sort_order AS domain_order
			 FROM {$wpdb->prefix}wpq_questions q
			 JOIN {$wpdb->prefix}wpq_domains d ON d.id = q.domain_id
			 WHERE d.questionnaire_id = %d
			 ORDER BY d.sort_order ASC, q.sort_order ASC",
			$questionnaire_id
		) ) ?: [];
	}

	public static function count_questions_for_questionnaire( int $questionnaire_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_questions q
			 JOIN {$wpdb->prefix}wpq_domains d ON d.id = q.domain_id
			 WHERE d.questionnaire_id = %d",
			$questionnaire_id
		) );
	}

	public static function count_submissions_for_questionnaire( int $questionnaire_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions
			 WHERE questionnaire_id = %d
			   AND deleted_at IS NULL",
			$questionnaire_id
		) );
	}

	public static function insert_question( array $data ): int {
		global $wpdb;
		$wpdb->insert( "{$wpdb->prefix}wpq_questions", $data );
		return (int) $wpdb->insert_id;
	}

	public static function update_question( int $id, array $data ): bool {
		global $wpdb;
		$result = $wpdb->update( "{$wpdb->prefix}wpq_questions", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	public static function delete_question( int $id ): bool {
		global $wpdb;
		$wpdb->delete( "{$wpdb->prefix}wpq_question_options", [ 'question_id' => $id ] );
		return (bool) $wpdb->delete( "{$wpdb->prefix}wpq_questions", [ 'id' => $id ] );
	}

	public static function delete_questionnaire( int $id ): bool {
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"DELETE qo FROM {$wpdb->prefix}wpq_question_options qo
			 JOIN {$wpdb->prefix}wpq_questions q ON q.id = qo.question_id
			 JOIN {$wpdb->prefix}wpq_domains d ON d.id = q.domain_id
			 WHERE d.questionnaire_id = %d",
			$id
		) );
		$wpdb->query( $wpdb->prepare(
			"DELETE q FROM {$wpdb->prefix}wpq_questions q
			 JOIN {$wpdb->prefix}wpq_domains d ON d.id = q.domain_id
			 WHERE d.questionnaire_id = %d",
			$id
		) );
		$wpdb->delete( "{$wpdb->prefix}wpq_domains",          [ 'questionnaire_id' => $id ] );
		$wpdb->delete( "{$wpdb->prefix}wpq_grade_thresholds", [ 'questionnaire_id' => $id ] );
		return (bool) $wpdb->delete( "{$wpdb->prefix}wpq_questionnaires", [ 'id' => $id ] );
	}

	public static function duplicate_questionnaire( int $source_id ): int {
		global $wpdb;
		$source = self::get_questionnaire( $source_id );
		if ( ! $source ) {
			return 0;
		}
		$now = current_time( 'mysql', true );

		// Generate a unique ref.
		$base_ref = rtrim( strtoupper( $source->ref ), '_' ) . '_COPY';
		$new_ref  = $base_ref;
		$n        = 1;
		while ( self::get_questionnaire_any_status_by_ref( $new_ref ) ) {
			$n++;
			$new_ref = $base_ref . $n;
		}

		$wpdb->insert( "{$wpdb->prefix}wpq_questionnaires", [
			'organisation_id' => $source->organisation_id,
			'ref'             => $new_ref,
			'category'        => $source->category,
			'name'            => $source->name . ' (Copy)',
			'description'     => $source->description,
			'status'          => 'draft',
			'created_at'      => $now,
			'updated_at'      => $now,
		] );
		$new_q_id = (int) $wpdb->insert_id;
		if ( ! $new_q_id ) {
			return 0;
		}

		foreach ( self::get_domains( $source_id ) as $domain ) {
			$wpdb->insert( "{$wpdb->prefix}wpq_domains", [
				'questionnaire_id' => $new_q_id,
				'sort_order'       => $domain->sort_order,
				'slug'             => $domain->slug,
				'name'             => $domain->name,
				'icon'             => $domain->icon,
				'brief'            => $domain->brief ?? '',
				'domain_weight'    => $domain->domain_weight ?? 100,
			] );
			$new_domain_id = (int) $wpdb->insert_id;
			if ( ! $new_domain_id ) {
				continue;
			}
			foreach ( self::get_questions( (int) $domain->id ) as $question ) {
				$wpdb->insert( "{$wpdb->prefix}wpq_questions", [
					'domain_id'        => $new_domain_id,
					'sort_order'       => $question->sort_order,
					'question_text'    => $question->question_text,
					'guidance_yes'     => $question->guidance_yes,
					'guidance_no'      => $question->guidance_no,
					'guidance_partial' => $question->guidance_partial ?? '',
					'score_yes'        => $question->score_yes,
					'score_partial'    => $question->score_partial,
					'score_no'         => $question->score_no,
					'question_type'    => $question->question_type,
					'is_required'      => $question->is_required,
					'scoring_mode'     => $question->scoring_mode,
					'max_score'        => $question->max_score,
					'help_text'        => $question->help_text,
					'question_weight'  => $question->question_weight ?? 100,
				] );
				$new_question_id = (int) $wpdb->insert_id;
				if ( ! $new_question_id ) {
					continue;
				}
				foreach ( self::get_question_options_all( (int) $question->id ) as $opt ) {
					$wpdb->insert( "{$wpdb->prefix}wpq_question_options", [
						'question_id'      => $new_question_id,
						'option_key'       => $opt->option_key,
						'option_label'     => $opt->option_label,
						'score'            => $opt->score,
						'risk_level'       => $opt->risk_level,
						'finding_priority' => $opt->finding_priority,
						'finding_action'   => $opt->finding_action,
						'guidance'         => $opt->guidance ?? null,
						'sort_order'       => $opt->sort_order,
						'is_default'       => $opt->is_default,
						'is_active'        => $opt->is_active,
					] );
				}
			}
		}

		foreach ( self::get_grade_thresholds( $source_id ) as $t ) {
			$wpdb->insert( "{$wpdb->prefix}wpq_grade_thresholds", [
				'questionnaire_id' => $new_q_id,
				'min_score'        => $t->min_score,
				'grade_id'         => $t->grade_id,
				'grade_label'      => $t->grade_label,
				'verdict_text'     => $t->verdict_text,
				'color_hex'        => $t->color_hex,
				'bg_hex'           => $t->bg_hex,
			] );
		}

		return $new_q_id;
	}

	// ------------------------------------------------------------------ //
	// Grade Thresholds
	// ------------------------------------------------------------------ //

	public static function get_default_grade_thresholds(): array {
		return [
			[
				'min_score'    => 80,
				'grade_id'     => 'strong',
				'grade_label'  => 'Strong',
				'verdict_text' => 'Your organisation has strong controls across the assessed areas. Keep maintaining, testing, and documenting what works.',
				'color_hex'    => '#16A34A',
				'bg_hex'       => '#F0FDF4',
			],
			[
				'min_score'    => 60,
				'grade_id'     => 'moderate',
				'grade_label'  => 'Moderate',
				'verdict_text' => 'You have some good controls in place, but meaningful gaps remain. Addressing the findings will reduce your risk.',
				'color_hex'    => '#F59E0B',
				'bg_hex'       => '#FFFBEB',
			],
			[
				'min_score'    => 40,
				'grade_id'     => 'needs_attention',
				'grade_label'  => 'Needs Attention',
				'verdict_text' => 'Several important controls need attention. Prioritise the findings and close the most material gaps first.',
				'color_hex'    => '#DC2626',
				'bg_hex'       => '#FEF2F2',
			],
			[
				'min_score'    => 0,
				'grade_id'     => 'high_risk',
				'grade_label'  => 'High Risk',
				'verdict_text' => 'Critical gaps are present. Act on the highest-risk findings as soon as possible.',
				'color_hex'    => '#2563EB',
				'bg_hex'       => '#EFF6FF',
			],
		];
	}

	public static function insert_default_grade_thresholds( int $questionnaire_id ): bool {
		foreach ( self::get_default_grade_thresholds() as $threshold ) {
			$inserted = self::insert_grade_threshold( array_merge(
				$threshold,
				[ 'questionnaire_id' => $questionnaire_id ]
			) );

			if ( ! $inserted ) {
				return false;
			}
		}

		return true;
	}

	public static function get_grade_thresholds( int $questionnaire_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_grade_thresholds WHERE questionnaire_id = %d ORDER BY min_score DESC",
			$questionnaire_id
		) ) ?: [];
	}

	public static function insert_grade_threshold( array $data ): int {
		global $wpdb;
		$wpdb->insert( "{$wpdb->prefix}wpq_grade_thresholds", $data );
		return (int) $wpdb->insert_id;
	}

	public static function update_grade_threshold( int $id, array $data ): bool {
		global $wpdb;
		$result = $wpdb->update( "{$wpdb->prefix}wpq_grade_thresholds", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	public static function delete_grade_threshold( int $id ): bool {
		global $wpdb;
		$result = $wpdb->delete( "{$wpdb->prefix}wpq_grade_thresholds", [ 'id' => $id ] );
		return $result !== false;
	}

	// ------------------------------------------------------------------ //
	// Calls to action
	// ------------------------------------------------------------------ //

	public static function get_ctas(): array {
		global $wpdb;
		return $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}wpq_ctas ORDER BY category_slug ASC, domain_slug = '' DESC, domain_slug ASC"
		) ?: [];
	}

	public static function get_ctas_for_export( array $ids = [] ): array {
		global $wpdb;
		if ( ! empty( $ids ) ) {
			$ids_int = array_values( array_filter( array_map( 'intval', $ids ) ) );
			if ( empty( $ids_int ) ) {
				return [];
			}
			$placeholders = implode( ',', array_fill( 0, count( $ids_int ), '%d' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is an internal placeholder string, not user input.
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpq_ctas WHERE id IN ({$placeholders}) ORDER BY category_slug ASC, domain_slug = '' DESC, domain_slug ASC", ...$ids_int ) ) ?: [];
		}

		return self::get_ctas();
	}

	public static function get_cta( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_ctas WHERE id = %d",
			$id
		) ) ?: null;
	}

	public static function get_cta_by_scope( string $category_slug, string $domain_slug = '' ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_ctas WHERE category_slug = %s AND domain_slug = %s LIMIT 1",
			sanitize_key( $category_slug ),
			sanitize_key( $domain_slug )
		) ) ?: null;
	}

	public static function upsert_cta( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$id = isset( $data['id'] ) ? (int) $data['id'] : 0;
		$row = [
			'category_slug' => sanitize_key( $data['category_slug'] ?? '' ),
			'domain_slug'   => ! empty( $data['domain_slug'] ) ? sanitize_key( $data['domain_slug'] ) : '',
			'body_html'     => wp_kses_post( (string) ( $data['body_html'] ?? '' ) ),
			'status'        => in_array( (string) ( $data['status'] ?? 'active' ), [ 'active', 'inactive' ], true ) ? (string) $data['status'] : 'active',
			'updated_at'    => $now,
		];

		if ( $id > 0 ) {
			$result = $wpdb->update( "{$wpdb->prefix}wpq_ctas", $row, [ 'id' => $id ] );
			return $result === false ? 0 : $id;
		}

		$existing_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_ctas WHERE category_slug = %s AND domain_slug = %s LIMIT 1",
			$row['category_slug'],
			$row['domain_slug']
		) );
		if ( $existing_id > 0 ) {
			$result = $wpdb->update( "{$wpdb->prefix}wpq_ctas", $row, [ 'id' => $existing_id ] );
			return $result === false ? 0 : $existing_id;
		}

		$row['created_at'] = $now;
		if ( $wpdb->insert( "{$wpdb->prefix}wpq_ctas", $row ) === false ) {
			return 0;
		}
		return (int) $wpdb->insert_id;
	}

	public static function delete_cta( int $id ): bool {
		global $wpdb;
		$result = $wpdb->delete( "{$wpdb->prefix}wpq_ctas", [ 'id' => $id ] );
		return $result !== false;
	}

	public static function get_unique_domains_for_category( string $category_slug ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT d.slug, MIN(d.name) AS name
			 FROM {$wpdb->prefix}wpq_domains d
			 INNER JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = d.questionnaire_id
			 WHERE q.category = %s
			 GROUP BY d.slug
			 ORDER BY name ASC, d.slug ASC",
			$category_slug
		) ) ?: [];
	}

	public static function get_result_ctas( string $category_slug, array $domain_slugs ): array {
		global $wpdb;
		$category_slug = sanitize_key( $category_slug );
		if ( $category_slug === '' ) {
			return [
				'category' => null,
				'domains'  => [],
			];
		}
		$domain_slugs = array_values( array_unique( array_filter( array_map( 'sanitize_key', $domain_slugs ) ) ) );
		if ( count( $domain_slugs ) > 1 ) {
			shuffle( $domain_slugs );
		}

		$category = $wpdb->get_row( $wpdb->prepare(
			"SELECT id, category_slug, domain_slug, body_html
			 FROM {$wpdb->prefix}wpq_ctas
			 WHERE category_slug = %s AND domain_slug = '' AND status = 'active'
			 LIMIT 1",
			$category_slug
		) );

		$domain_ctas = [];
		foreach ( $domain_slugs as $domain_slug ) {
			$row = $wpdb->get_row( $wpdb->prepare(
				"SELECT id, category_slug, domain_slug, body_html
				 FROM {$wpdb->prefix}wpq_ctas
				 WHERE category_slug = %s AND domain_slug = %s AND status = 'active'
				 LIMIT 1",
				$category_slug,
				$domain_slug
			) );
			if ( $row ) {
				$domain_ctas[] = [
					'domain_slug' => (string) $row->domain_slug,
					'html'        => wp_kses_post( (string) $row->body_html ),
				];
			}
			if ( count( $domain_ctas ) >= 3 ) {
				break;
			}
		}

		return [
			'category' => $category ? [ 'html' => wp_kses_post( (string) $category->body_html ) ] : null,
			'domains'  => $domain_ctas,
		];
	}

	// ------------------------------------------------------------------ //
	// Products
	// ------------------------------------------------------------------ //

	public static function get_products_for_questionnaire( int $questionnaire_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_products WHERE questionnaire_id = %d AND status = 'active' AND stripe_price_id IS NOT NULL AND stripe_price_id != '' ORDER BY price_gbp ASC",
			$questionnaire_id
		) ) ?: [];
	}

	public static function get_all_products_for_questionnaire( int $questionnaire_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_products WHERE questionnaire_id = %d ORDER BY price_gbp ASC",
			$questionnaire_id
		) ) ?: [];
	}

	public static function get_product( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_products WHERE id = %d AND status = 'active'",
			$id
		) ) ?: null;
	}

	public static function get_product_admin( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_products WHERE id = %d",
			$id
		) ) ?: null;
	}

	public static function slug_exists( string $slug, int $exclude_id = 0 ): bool {
		global $wpdb;
		if ( $exclude_id ) {
			return (bool) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}wpq_products WHERE slug = %s AND id != %d LIMIT 1",
				$slug, $exclude_id
			) );
		}
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_products WHERE slug = %s LIMIT 1",
			$slug
		) );
	}

	public static function get_all_products(): array {
		global $wpdb;
		return $wpdb->get_results(
			"SELECT p.*, q.name AS questionnaire_name FROM {$wpdb->prefix}wpq_products p
			 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = p.questionnaire_id
			 ORDER BY p.questionnaire_id, p.price_gbp"
		) ?: [];
	}

	public static function insert_product( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$data['created_at'] = $now;
		$data['updated_at'] = $now;
		$wpdb->insert( "{$wpdb->prefix}wpq_products", $data );
		return (int) $wpdb->insert_id;
	}

	public static function update_product( int $id, array $data ): bool {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql', true );
		$result = $wpdb->update( "{$wpdb->prefix}wpq_products", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	public static function delete_product( int $id ): bool {
		global $wpdb;
		return (bool) $wpdb->delete( "{$wpdb->prefix}wpq_products", [ 'id' => $id ] );
	}

	// ------------------------------------------------------------------ //
	// Coupons
	// ------------------------------------------------------------------ //

	public static function insert_coupon( array $data ): int {
		global $wpdb;
		$wpdb->insert( "{$wpdb->prefix}wpq_coupons", $data );
		return (int) $wpdb->insert_id;
	}

	public static function get_all_coupons(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table-name prefix is not user input.
		return $wpdb->get_results(
			"SELECT c.*,
			    q.name AS questionnaire_name, q.ref AS questionnaire_ref,
			    p.name AS product_name
			 FROM {$wpdb->prefix}wpq_coupons c
			 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = c.questionnaire_id
			 LEFT JOIN {$wpdb->prefix}wpq_products p ON p.id = c.product_id
			 ORDER BY c.created_at DESC"
		) ?: [];
	}

	public static function get_coupon( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table-name prefix is not user input.
			"SELECT * FROM {$wpdb->prefix}wpq_coupons WHERE id = %d",
			$id
		) ) ?: null;
	}

	public static function update_coupon( int $id, array $data ): bool {
		global $wpdb;
		$result = $wpdb->update( "{$wpdb->prefix}wpq_coupons", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	// ------------------------------------------------------------------ //
	// Submissions
	// ------------------------------------------------------------------ //

	public static function create_submission( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$data['created_at'] = $now;
		$data['updated_at'] = $now;
		unset( $data['ref'] ); // Ref is derived from the auto-increment ID after insert.
		$data['ref'] = substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 20 ); // Unique placeholder, fits VARCHAR(20).
		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_submissions", $data );
		if ( $inserted === false ) {
			self::log_error( 'WPQ create_submission insert failed: ' . $wpdb->last_error );
			return 0;
		}

		$id = (int) $wpdb->insert_id;
		if ( $id ) {
			$ref = sprintf( 'WPQ-%s-%04d', gmdate( 'Ymd' ), $id );
			$updated = $wpdb->update( "{$wpdb->prefix}wpq_submissions", [ 'ref' => $ref ], [ 'id' => $id ] );
			if ( $updated !== 1 ) {
				self::log_error( 'WPQ create_submission ref update failed for submission ' . $id . ': ' . $wpdb->last_error );
				$wpdb->delete( "{$wpdb->prefix}wpq_submissions", [ 'id' => $id ] );
				return 0;
			}
		}
		return $id;
	}

	public static function delete_submission( int $id ): bool {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT qr_docx_path, qr_pdf_path FROM {$wpdb->prefix}wpq_submissions WHERE id = %d AND deleted_at IS NULL",
			$id
		) );
		if ( ! $row ) {
			return false;
		}

		$result = $wpdb->update(
			"{$wpdb->prefix}wpq_submissions",
			[
				'deleted_at'         => current_time( 'mysql', true ),
				'deleted_by_user_id' => get_current_user_id() ?: null,
				'updated_at'         => current_time( 'mysql', true ),
			],
			[ 'id' => $id ]
		);

		if ( $result === 1 && class_exists( 'WPQ_Questionnaire_Report_Storage' ) ) {
			// Deleted submissions must not leave a customer-identifiable generated
			// report silently accessible; the DB row is retained (soft delete) but
			// the private DOCX/PDF artefacts are removed immediately, and any
			// delivery link already in a customer's inbox stops working.
			WPQ_Questionnaire_Report_Storage::delete_stored_files( $row->qr_docx_path ?? null, $row->qr_pdf_path ?? null );
			self::revoke_report_tokens( $id );
		}

		return $result === 1;
	}

	public static function count_purgeable_abandoned( int $days ): int {
		global $wpdb;
		if ( $days <= 0 ) {
			return 0;
		}
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions
			 WHERE abandoned = 1
			   AND completed_at IS NULL
			   AND deleted_at IS NULL
			   AND started_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
			$days
		) );
	}

	public static function purge_abandoned_submissions( int $days ): int {
		global $wpdb;
		if ( $days <= 0 ) {
			return 0;
		}
		$now    = current_time( 'mysql', true );
		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_submissions
			    SET deleted_at = %s, updated_at = %s
			  WHERE abandoned = 1
			    AND completed_at IS NULL
			    AND deleted_at IS NULL
			    AND started_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
			$now,
			$now,
			$days
		) );
		return is_int( $result ) ? $result : 0;
	}

	public static function count_anonymisable_completed( int $days ): int {
		global $wpdb;
		if ( $days <= 0 ) {
			return 0;
		}
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions
			 WHERE abandoned = 0
			   AND completed_at IS NOT NULL
			   AND deleted_at IS NULL
			   AND contact_email != 'anonymous@deleted.invalid'
			   AND completed_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
			$days
		) );
	}

	public static function anonymise_old_submissions( int $days ): int {
		global $wpdb;
		if ( $days <= 0 ) {
			return 0;
		}
		$now = current_time( 'mysql', true );

		// Generated Questionnaire Report documents embed the customer's name and
		// company in their content, so anonymising the row alone would leave a
		// customer-identifiable document still downloadable. Remove the files
		// (and their DB references) for every row this pass will anonymise.
		self::purge_questionnaire_report_artefacts_where(
			"abandoned = 0 AND completed_at IS NOT NULL AND deleted_at IS NULL
			 AND contact_email != 'anonymous@deleted.invalid'
			 AND completed_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
			[ $days ]
		);

		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_submissions
			    SET contact_name    = 'Anonymous',
			        contact_email   = 'anonymous@deleted.invalid',
			        contact_company = NULL,
			        contact_phone   = NULL,
			        ip_address      = NULL,
			        session_token   = '',
			        updated_at      = %s
			  WHERE abandoned = 0
			    AND completed_at IS NOT NULL
			    AND deleted_at IS NULL
			    AND contact_email != 'anonymous@deleted.invalid'
			    AND completed_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
			$now,
			$days
		) );
		return is_int( $result ) ? $result : 0;
	}

	/**
	 * Deletes stored Questionnaire Report DOCX/PDF files (and clears their DB
	 * references) for every non-deleted submission matching $where_sql, which
	 * must only ever be a fixed internal clause - never built from user input.
	 *
	 * @param array<int, mixed> $where_values
	 */
	private static function purge_questionnaire_report_artefacts_where( string $where_sql, array $where_values ): void {
		global $wpdb;
		if ( ! class_exists( 'WPQ_Questionnaire_Report_Storage' ) ) {
			return;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where_sql is a fixed internal clause (never user input); every value is bound via $wpdb->prepare() below.
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, qr_docx_path, qr_pdf_path FROM {$wpdb->prefix}wpq_submissions
			 WHERE (qr_docx_path IS NOT NULL OR qr_pdf_path IS NOT NULL OR qr_analysis_json IS NOT NULL) AND ({$where_sql})",
			$where_values
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		foreach ( (array) $rows as $row ) {
			WPQ_Questionnaire_Report_Storage::delete_stored_files( $row->qr_docx_path, $row->qr_pdf_path );
			self::update_submission_questionnaire_report( (int) $row->id, [
				'qr_docx_path'     => null,
				'qr_pdf_path'      => null,
				// The stored analysis is customer-derived narrative; it must not outlive the artefacts.
				'qr_analysis_json' => null,
			] );
			// Any outstanding delivery link points at a file that no longer exists.
			self::revoke_report_tokens( (int) $row->id );
		}
	}

	/**
	 * Returns a summary array of abandoned submissions eligible for purging.
	 * Used to generate an export CSV before committing to the purge.
	 *
	 * @return array<int, object>
	 */
	public static function get_purgeable_abandoned_summaries( int $days ): array {
		global $wpdb;
		if ( $days <= 0 ) {
			return [];
		}
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT s.id, s.ref, s.contact_name, s.contact_email, s.contact_company,
			        s.contact_phone, s.ip_address, q.ref AS questionnaire_ref, s.started_at
			   FROM {$wpdb->prefix}wpq_submissions s
			   LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			  WHERE s.abandoned = 1
			    AND s.completed_at IS NULL
			    AND s.deleted_at IS NULL
			    AND s.started_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)
			  ORDER BY s.started_at ASC",
			$days
		) ) ?: [];
	}

	public static function update_submission( int $id, array $data ): bool {
		global $wpdb;
		// Refuse to write to soft-deleted submissions; wpdb->update WHERE can't express IS NULL natively.
		$active = $wpdb->get_var( $wpdb->prepare(
			"SELECT 1 FROM {$wpdb->prefix}wpq_submissions WHERE id = %d AND deleted_at IS NULL",
			$id
		) );
		if ( ! $active ) {
			return false;
		}
		$data['updated_at'] = current_time( 'mysql', true );
		$result = $wpdb->update( "{$wpdb->prefix}wpq_submissions", $data, [ 'id' => $id ] );
		return $result !== false;
	}

	public static function get_submission( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT s.*, q.name AS questionnaire_name, q.ref AS questionnaire_ref,
			        q.claude_project_name AS questionnaire_claude_project_name,
			        gt.grade_label
			 FROM {$wpdb->prefix}wpq_submissions s
			 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			 LEFT JOIN {$wpdb->prefix}wpq_grade_thresholds gt
			        ON gt.questionnaire_id = s.questionnaire_id AND gt.grade_id = s.grade_id
			 WHERE s.id = %d AND s.deleted_at IS NULL",
			$id
		) ) ?: null;
	}

	public static function initialise_claude_conversation( int $submission_id ): bool {
		global $wpdb;
		if ( $submission_id <= 0 ) {
			return false;
		}

		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT s.id, s.contact_name, s.contact_company,
			        q.claude_project_id, q.claude_project_name
			   FROM {$wpdb->prefix}wpq_submissions s
			   LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			  WHERE s.id = %d AND s.deleted_at IS NULL",
			$submission_id
		) );

		if ( ! $row ) {
			return false;
		}

		$title      = class_exists( 'WPQ_Claude' ) ? WPQ_Claude::conversation_title_for_submission( $row ) : 'Submission ' . $submission_id;
		$project_id = substr( sanitize_text_field( (string) ( $row->claude_project_id ?? '' ) ), 0, 200 );
		$now        = current_time( 'mysql', true );

		if ( '' === $project_id ) {
			$result = $wpdb->query( $wpdb->prepare(
				"UPDATE {$wpdb->prefix}wpq_submissions
				    SET claude_provider_mode = %s,
				        claude_project_id = NULL,
				        claude_conversation_id = NULL,
				        claude_conversation_title = %s,
				        claude_status = %s,
				        claude_last_error = %s,
				        ai_report_status = %s,
				        updated_at = %s
				  WHERE id = %d
				    AND deleted_at IS NULL",
				class_exists( 'WPQ_Claude' ) ? WPQ_Claude::PROVIDER_MODE_MESSAGES_API_INTERNAL_SESSION : 'messages_api_internal_session',
				$title,
				class_exists( 'WPQ_Claude' ) ? WPQ_Claude::STATUS_MANUAL_CONFIGURATION_REQUIRED : 'manual_configuration_required',
				'Questionnaire has no Claude project ID configured. Anthropic API project creation is not available through the supported public API.',
				class_exists( 'WPQ_Claude' ) ? WPQ_Claude::REPORT_STATUS_NOT_REQUESTED : 'not_requested',
				$now,
				$submission_id
			) );

			return $result !== false;
		}

		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_submissions
			    SET claude_provider_mode = %s,
			        claude_project_id = %s,
			        claude_conversation_title = %s,
			        claude_status = %s,
			        claude_created_at = %s,
			        claude_last_success_at = %s,
			        claude_last_error = NULL,
			        ai_report_status = %s,
			        updated_at = %s
			  WHERE id = %d
			    AND deleted_at IS NULL",
			class_exists( 'WPQ_Claude' ) ? WPQ_Claude::PROVIDER_MODE_MESSAGES_API_INTERNAL_SESSION : 'messages_api_internal_session',
			$project_id,
			$title,
			class_exists( 'WPQ_Claude' ) ? WPQ_Claude::STATUS_READY : 'ready',
			$now,
			$now,
			class_exists( 'WPQ_Claude' ) ? WPQ_Claude::REPORT_STATUS_NOT_REQUESTED : 'not_requested',
			$now,
			$submission_id
		) );

		if ( $result === false ) {
			self::log_error( 'WPQ initialise_claude_conversation failed: ' . $wpdb->last_error );
			return false;
		}

		return true;
	}

	public static function update_submission_claude_report( int $submission_id, array $data ): bool {
		$allowed = [
			'claude_status',
			'claude_last_success_at',
			'claude_last_error',
			'claude_request_id',
			'claude_model_used',
			'claude_prompt_version',
			'ai_report_status',
			'ai_report_docx_path',
			'ai_report_pdf_path',
			'ai_report_generated_at',
			'ai_report_template_checksum',
			'ai_report_output_checksum',
		];
		$clean = [];

		foreach ( $data as $key => $value ) {
			if ( ! in_array( (string) $key, $allowed, true ) ) {
				continue;
			}
			$clean[ (string) $key ] = is_string( $value ) ? sanitize_text_field( $value ) : $value;
		}

		return ! empty( $clean ) && self::update_submission( $submission_id, $clean );
	}

	public static function update_submission_questionnaire_report( int $submission_id, array $data ): bool {
		$allowed = [
			'qr_status',
			'qr_renderer_mode',
			'qr_claude_request_id',
			'qr_model_used',
			'qr_prompt_version',
			'qr_context_version',
			'qr_template_checksum',
			'qr_docx_path',
			'qr_docx_checksum',
			'qr_pdf_path',
			'qr_pdf_checksum',
			'qr_generated_at',
			'qr_requested_at',
			'qr_last_stage',
			'qr_failure_code',
			'qr_failure_message',
			'qr_generation_token',
			'qr_analysis_json',
			'qr_email_sent_at',
			'qr_last_attempt_at',
			'qr_attempt_count',
		];
		$clean = [];

		foreach ( $data as $key => $value ) {
			if ( ! in_array( (string) $key, $allowed, true ) ) {
				continue;
			}
			// qr_analysis_json holds an already-validated, already-sanitised JSON document;
			// sanitize_text_field() would strip its newlines and any "<" it contains, corrupting it.
			if ( 'qr_analysis_json' === (string) $key ) {
				$clean[ (string) $key ] = is_string( $value ) ? $value : null;
				continue;
			}
			$clean[ (string) $key ] = is_string( $value ) ? sanitize_text_field( $value ) : $value;
		}

		return ! empty( $clean ) && self::update_submission( $submission_id, $clean );
	}

	/**
	 * @param array<string, mixed> $data
	 */
	public static function update_submission_framework_readiness( int $submission_id, array $data ): bool {
		$allowed = [
			'fr_status',
			'fr_generation_token',
			'fr_requested_at',
			'fr_completed_at',
			'fr_results_json',
			'fr_failure_code',
			'fr_failure_message',
		];
		$clean = [];

		foreach ( $data as $key => $value ) {
			if ( ! in_array( (string) $key, $allowed, true ) ) {
				continue;
			}
			// fr_results_json holds an already-validated, already-sanitised JSON document;
			// sanitize_text_field() would strip its newlines and any "<" it contains, corrupting it.
			if ( 'fr_results_json' === (string) $key ) {
				$clean[ (string) $key ] = is_string( $value ) ? $value : null;
				continue;
			}
			$clean[ (string) $key ] = is_string( $value ) ? sanitize_text_field( $value ) : $value;
		}

		return ! empty( $clean ) && self::update_submission( $submission_id, $clean );
	}

	public static function link_submission_contact( int $submission_id, int $contact_id ): bool {
		global $wpdb;
		if ( $submission_id <= 0 || $contact_id <= 0 ) {
			return false;
		}
		return false !== $wpdb->update(
			"{$wpdb->prefix}wpq_submissions",
			[ 'contact_id' => $contact_id ],
			[ 'id' => $submission_id ]
		);
	}

	public static function link_enquiry_contact( int $enquiry_id, int $contact_id ): bool {
		global $wpdb;
		if ( $enquiry_id <= 0 || $contact_id <= 0 ) {
			return false;
		}
		return false !== $wpdb->update(
			"{$wpdb->prefix}wpq_enquiries",
			[ 'contact_id' => $contact_id ],
			[ 'id' => $enquiry_id ]
		);
	}

	public static function update_submission_remediation( int $submission_id, array $data ): bool {
		$allowed = [ 'remediation_xlsx_path', 'remediation_last_generated_at' ];
		$clean   = [];

		foreach ( $data as $key => $value ) {
			if ( in_array( (string) $key, $allowed, true ) ) {
				$clean[ (string) $key ] = is_string( $value ) ? sanitize_text_field( $value ) : $value;
			}
		}

		return ! empty( $clean ) && self::update_submission( $submission_id, $clean );
	}

	// ------------------------------------------------------------------ //
	// Enquiry forms and enquiries
	// ------------------------------------------------------------------ //

	/**
	 * Create or update an enquiry form. Returns the form id.
	 *
	 * @param array{id?: int, name: string, description: string, status: string, fields_json: string, mail_enabled: string, notify_email: string, send_ack: string} $data
	 */
	public static function save_enquiry_form( array $data ): int {
		global $wpdb;

		$row = [
			'name'         => mb_substr( sanitize_text_field( (string) ( $data['name'] ?? '' ) ), 0, 200 ),
			'description'  => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'status'       => in_array( $data['status'] ?? '', [ 'draft', 'published' ], true ) ? (string) $data['status'] : 'draft',
			'fields_json'  => (string) ( $data['fields_json'] ?? '[]' ),
			'mail_enabled' => in_array( $data['mail_enabled'] ?? '', [ 'inherit', 'enabled', 'disabled' ], true ) ? (string) $data['mail_enabled'] : 'inherit',
			'notify_email' => sanitize_email( (string) ( $data['notify_email'] ?? '' ) ) ?: null,
			'send_ack'     => ( $data['send_ack'] ?? '' ) === 'yes' ? 'yes' : 'no',
			'turnstile_enabled' => in_array( $data['turnstile_enabled'] ?? '', [ 'inherit', 'enabled', 'disabled' ], true ) ? (string) $data['turnstile_enabled'] : 'inherit',
			'updated_at'   => current_time( 'mysql', true ),
		];
		if ( '' === $row['name'] ) {
			return 0;
		}

		$id = (int) ( $data['id'] ?? 0 );
		if ( $id > 0 ) {
			$updated = $wpdb->update( "{$wpdb->prefix}wpq_enquiry_forms", $row, [ 'id' => $id ] );
			return false === $updated ? 0 : $id;
		}

		$row['ref']        = 'EF-' . strtoupper( substr( bin2hex( random_bytes( 4 ) ), 0, 6 ) );
		$row['created_at'] = current_time( 'mysql', true );
		$inserted          = $wpdb->insert( "{$wpdb->prefix}wpq_enquiry_forms", $row );
		return false === $inserted ? 0 : (int) $wpdb->insert_id;
	}

	public static function get_enquiry_form( int $form_id ): ?object {
		global $wpdb;
		if ( $form_id <= 0 ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_enquiry_forms WHERE id = %d",
			$form_id
		) ) ?: null;
	}

	public static function get_enquiry_form_by_ref( string $ref ): ?object {
		global $wpdb;
		$ref = sanitize_text_field( $ref );
		if ( '' === $ref ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_enquiry_forms WHERE ref = %s",
			$ref
		) ) ?: null;
	}

	/** @return array<int, object> Forms with received-enquiry counts, newest first. */
	public static function get_enquiry_forms_with_counts(): array {
		global $wpdb;
		return $wpdb->get_results(
			"SELECT f.*, COUNT(e.id) AS enquiry_count
			 FROM {$wpdb->prefix}wpq_enquiry_forms f
			 LEFT JOIN {$wpdb->prefix}wpq_enquiries e ON e.form_id = f.id
			 GROUP BY f.id
			 ORDER BY f.created_at DESC"
		) ?: [];
	}

	public static function delete_enquiry_form( int $form_id ): bool {
		global $wpdb;
		if ( $form_id <= 0 ) {
			return false;
		}
		$wpdb->delete( "{$wpdb->prefix}wpq_enquiries", [ 'form_id' => $form_id ], [ '%d' ] );
		return false !== $wpdb->delete( "{$wpdb->prefix}wpq_enquiry_forms", [ 'id' => $form_id ], [ '%d' ] );
	}

	/**
	 * Store a received enquiry. Returns the enquiry id.
	 *
	 * @param array{form_id: int, ref: string, contact_name: string, contact_email: string, contact_company: string, contact_phone: string, consent: bool, fields_json: string} $data
	 */
	public static function insert_enquiry( array $data ): int {
		global $wpdb;
		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_enquiries", [
			'form_id'         => (int) ( $data['form_id'] ?? 0 ),
			'ref'             => mb_substr( sanitize_text_field( (string) ( $data['ref'] ?? '' ) ), 0, 50 ),
			'contact_name'    => mb_substr( sanitize_text_field( (string) ( $data['contact_name'] ?? '' ) ), 0, 200 ),
			'contact_email'   => sanitize_email( (string) ( $data['contact_email'] ?? '' ) ),
			'contact_company' => mb_substr( sanitize_text_field( (string) ( $data['contact_company'] ?? '' ) ), 0, 200 ) ?: null,
			'contact_phone'   => mb_substr( sanitize_text_field( (string) ( $data['contact_phone'] ?? '' ) ), 0, 50 ) ?: null,
			'consent'         => empty( $data['consent'] ) ? 0 : 1,
			'fields_json'     => (string) ( $data['fields_json'] ?? '{}' ),
			'status'          => 'new',
			'created_at'      => current_time( 'mysql', true ),
		] );
		return false === $inserted ? 0 : (int) $wpdb->insert_id;
	}

	public static function get_enquiry( int $enquiry_id ): ?object {
		global $wpdb;
		if ( $enquiry_id <= 0 ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT e.*, f.name AS form_name, f.ref AS form_ref
			 FROM {$wpdb->prefix}wpq_enquiries e
			 LEFT JOIN {$wpdb->prefix}wpq_enquiry_forms f ON f.id = e.form_id
			 WHERE e.id = %d",
			$enquiry_id
		) ) ?: null;
	}

	/** @return array<int, object> */
	public static function get_enquiries( int $form_id = 0, int $limit = 200 ): array {
		global $wpdb;
		$limit = max( 1, min( 1000, $limit ) );
		if ( $form_id > 0 ) {
			return $wpdb->get_results( $wpdb->prepare(
				"SELECT e.*, f.name AS form_name FROM {$wpdb->prefix}wpq_enquiries e
				 LEFT JOIN {$wpdb->prefix}wpq_enquiry_forms f ON f.id = e.form_id
				 WHERE e.form_id = %d ORDER BY e.created_at DESC LIMIT %d",
				$form_id,
				$limit
			) ) ?: [];
		}
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT e.*, f.name AS form_name FROM {$wpdb->prefix}wpq_enquiries e
			 LEFT JOIN {$wpdb->prefix}wpq_enquiry_forms f ON f.id = e.form_id
			 ORDER BY e.created_at DESC LIMIT %d",
			$limit
		) ) ?: [];
	}

	public static function mark_enquiry_seen( int $enquiry_id ): bool {
		global $wpdb;
		if ( $enquiry_id <= 0 ) {
			return false;
		}
		return false !== $wpdb->update( "{$wpdb->prefix}wpq_enquiries", [ 'status' => 'seen' ], [ 'id' => $enquiry_id ] );
	}

	public static function delete_enquiry( int $enquiry_id ): bool {
		global $wpdb;
		if ( $enquiry_id <= 0 ) {
			return false;
		}
		return false !== $wpdb->delete( "{$wpdb->prefix}wpq_enquiries", [ 'id' => $enquiry_id ], [ '%d' ] );
	}

	// ------------------------------------------------------------------ //
	// Framework registry (ATLAS skill imports)
	// ------------------------------------------------------------------ //

	/**
	 * Create or update a framework row, keyed by slug. Returns the framework id.
	 *
	 * @param array{slug: string, name: string, version: string, description: string, skill_checksum: string, skill_bundle: string} $data
	 */
	public static function upsert_framework( array $data ): int {
		global $wpdb;

		$slug = sanitize_key( (string) ( $data['slug'] ?? '' ) );
		if ( '' === $slug ) {
			return 0;
		}

		$row = [
			'slug'              => $slug,
			'name'              => sanitize_text_field( (string) ( $data['name'] ?? $slug ) ),
			'version'           => sanitize_text_field( (string) ( $data['version'] ?? '' ) ),
			'description'       => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'status'            => 'active',
			'skill_checksum'    => substr( sanitize_text_field( (string) ( $data['skill_checksum'] ?? '' ) ), 0, 64 ),
			'skill_bundle'      => sanitize_file_name( (string) ( $data['skill_bundle'] ?? '' ) ),
			'skill_imported_at' => current_time( 'mysql', true ),
		];

		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_frameworks WHERE slug = %s",
			$slug
		) );

		if ( $existing ) {
			$updated = $wpdb->update( "{$wpdb->prefix}wpq_frameworks", $row, [ 'id' => (int) $existing ] );
			return false === $updated ? 0 : (int) $existing;
		}

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_frameworks", $row );
		return false === $inserted ? 0 : (int) $wpdb->insert_id;
	}

	/**
	 * Replace a framework's control catalogue wholesale. Re-imports are
	 * idempotent: the catalogue always reflects exactly the latest bundle.
	 *
	 * @param array<int, array{control_ref: string, control_name: string, domain: string, description: string}> $controls
	 */
	public static function replace_framework_controls( int $framework_id, array $controls ): int {
		global $wpdb;
		if ( $framework_id <= 0 ) {
			return 0;
		}

		$wpdb->delete( "{$wpdb->prefix}wpq_framework_controls", [ 'framework_id' => $framework_id ], [ '%d' ] );

		$count = 0;
		foreach ( $controls as $control ) {
			if ( ! is_array( $control ) ) {
				continue;
			}
			$ref = sanitize_text_field( (string) ( $control['control_ref'] ?? '' ) );
			if ( '' === $ref ) {
				continue;
			}
			$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_framework_controls", [
				'framework_id' => $framework_id,
				'control_ref'  => substr( $ref, 0, 50 ),
				'control_name' => substr( sanitize_text_field( (string) ( $control['control_name'] ?? '' ) ), 0, 200 ),
				'domain'       => substr( sanitize_text_field( (string) ( $control['domain'] ?? '' ) ), 0, 100 ),
				'description'  => sanitize_textarea_field( (string) ( $control['description'] ?? '' ) ),
			] );
			if ( false !== $inserted ) {
				$count++;
			}
		}

		return $count;
	}

	public static function get_framework( int $framework_id ): ?object {
		global $wpdb;
		if ( $framework_id <= 0 ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_frameworks WHERE id = %d",
			$framework_id
		) ) ?: null;
	}

	/** @return array<int, object> Frameworks with their control counts, name order. */
	public static function get_frameworks_with_counts(): array {
		global $wpdb;
		return $wpdb->get_results(
			"SELECT f.*, COUNT(c.id) AS control_count
			 FROM {$wpdb->prefix}wpq_frameworks f
			 LEFT JOIN {$wpdb->prefix}wpq_framework_controls c ON c.framework_id = f.id
			 GROUP BY f.id
			 ORDER BY f.name ASC"
		) ?: [];
	}

	/** @return array<int, object> A framework's control catalogue, ref order. */
	public static function get_framework_controls( int $framework_id ): array {
		global $wpdb;
		if ( $framework_id <= 0 ) {
			return [];
		}
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_framework_controls WHERE framework_id = %d ORDER BY id ASC",
			$framework_id
		) ) ?: [];
	}

	public static function rename_framework( int $framework_id, string $name ): bool {
		global $wpdb;
		$name = sanitize_text_field( $name );
		if ( $framework_id <= 0 || '' === $name ) {
			return false;
		}
		$updated = $wpdb->update(
			"{$wpdb->prefix}wpq_frameworks",
			[ 'name' => mb_substr( $name, 0, 191 ) ],
			[ 'id' => $framework_id ]
		);
		return false !== $updated;
	}

	public static function update_framework_skill_registration( int $framework_id, string $skill_id, string $skill_version ): bool {
		global $wpdb;
		if ( $framework_id <= 0 ) {
			return false;
		}
		$updated = $wpdb->update(
			"{$wpdb->prefix}wpq_frameworks",
			[
				'skill_id'      => substr( sanitize_text_field( $skill_id ), 0, 100 ),
				'skill_version' => substr( sanitize_text_field( $skill_version ), 0, 50 ),
			],
			[ 'id' => $framework_id ]
		);
		return false !== $updated;
	}

	public static function delete_framework( int $framework_id ): bool {
		global $wpdb;
		if ( $framework_id <= 0 ) {
			return false;
		}
		$wpdb->delete( "{$wpdb->prefix}wpq_framework_controls", [ 'framework_id' => $framework_id ], [ '%d' ] );
		return false !== $wpdb->delete( "{$wpdb->prefix}wpq_frameworks", [ 'id' => $framework_id ], [ '%d' ] );
	}

	/**
	 * The validated Questionnaire Report analysis stored for a submission, if any.
	 * This is the canonical issue list the remediation workbook builds on, so the
	 * two artefacts describe the same findings instead of being independently
	 * re-generated from two separate Claude calls.
	 *
	 * @return array<string, mixed> Empty when no analysis has been stored yet.
	 */
	public static function get_submission_report_analysis( int $submission_id ): array {
		if ( $submission_id <= 0 ) {
			return [];
		}

		$submission = self::get_submission( $submission_id );
		$json       = is_object( $submission ) ? (string) ( $submission->qr_analysis_json ?? '' ) : '';
		if ( '' === $json ) {
			return [];
		}

		$decoded = json_decode( $json, true );
		return is_array( $decoded ) ? $decoded : [];
	}

	/**
	 * Atomically transition a submission's Questionnaire Report state, only when
	 * it is currently in one of $from_states. The affected-row count of this
	 * single UPDATE is the concurrency check, avoiding a SELECT-then-UPDATE race
	 * between a duplicate "Generate" click and an in-flight background job.
	 *
	 * @param array<int,string> $from_states
	 */
	public static function claim_questionnaire_report_job( int $submission_id, string $token, array $from_states, string $to_state ): bool {
		global $wpdb;
		if ( $submission_id <= 0 || '' === $token || empty( $from_states ) ) {
			return false;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $from_states ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is a fixed run of %s placeholder tokens (never user input); every value is bound via $wpdb->prepare() below.
		$sql = $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_submissions
			 SET qr_status = %s, qr_generation_token = %s, qr_requested_at = %s, updated_at = %s,
			     qr_failure_code = NULL, qr_failure_message = NULL
			 WHERE id = %d AND deleted_at IS NULL AND qr_status IN ({$placeholders})",
			array_merge(
				[ $to_state, $token, current_time( 'mysql', true ), current_time( 'mysql', true ), $submission_id ],
				$from_states
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql was built via $wpdb->prepare() immediately above.
		return (int) $wpdb->query( $sql ) === 1;
	}

	/**
	 * Atomically transition a submission's Framework Readiness state, only when
	 * it is currently in one of $from_states. Independent state machine from
	 * claim_questionnaire_report_job() - see fr_status's migration comment.
	 *
	 * @param array<int,string> $from_states
	 */
	public static function claim_framework_readiness_job( int $submission_id, string $token, array $from_states, string $to_state ): bool {
		global $wpdb;
		if ( $submission_id <= 0 || '' === $token || empty( $from_states ) ) {
			return false;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $from_states ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is a fixed run of %s placeholder tokens (never user input); every value is bound via $wpdb->prepare() below.
		$sql = $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_submissions
			 SET fr_status = %s, fr_generation_token = %s, fr_requested_at = %s, updated_at = %s,
			     fr_failure_code = NULL, fr_failure_message = NULL
			 WHERE id = %d AND deleted_at IS NULL AND fr_status IN ({$placeholders})",
			array_merge(
				[ $to_state, $token, current_time( 'mysql', true ), current_time( 'mysql', true ), $submission_id ],
				$from_states
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql was built via $wpdb->prepare() immediately above.
		return (int) $wpdb->query( $sql ) === 1;
	}

	/**
	 * Records that a cron/process() invocation actually ran for this job, distinct
	 * from qr_requested_at (when it was queued). Atomic increment so concurrent
	 * duplicate cron firings (e.g. a stale WP-Cron event alongside an admin's
	 * synchronous run) never lose a count under a read-modify-write race.
	 */
	public static function record_questionnaire_report_attempt( int $submission_id ): bool {
		global $wpdb;
		if ( $submission_id <= 0 ) {
			return false;
		}

		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_submissions
			 SET qr_attempt_count = qr_attempt_count + 1,
			     qr_last_attempt_at = %s,
			     updated_at = %s
			 WHERE id = %d AND deleted_at IS NULL",
			current_time( 'mysql', true ),
			current_time( 'mysql', true ),
			$submission_id
		) );

		return $result !== false;
	}

	public static function update_submission_claude_conversation_id( int $submission_id, string $conversation_id ): bool {
		$clean = substr( sanitize_text_field( $conversation_id ), 0, 100 );
		if ( '' === $clean || str_starts_with( $clean, 'wpqconv_' ) ) {
			return false;
		}

		return self::update_submission( $submission_id, [
			'claude_conversation_id' => $clean,
		] );
	}

	public static function get_submissions( array $args = [] ): array {
		global $wpdb;

		$per_page        = max( 1, (int) ( $args['per_page'] ?? 20 ) );
		$page            = max( 1, (int) ( $args['page'] ?? 1 ) );
		$offset          = ( $page - 1 ) * $per_page;
		$questionnaire   = isset( $args['questionnaire_id'] ) ? (int) $args['questionnaire_id'] : null;
		$grade           = isset( $args['grade_id'] ) ? sanitize_text_field( $args['grade_id'] ) : null;
		$sync_status     = isset( $args['halopsa_sync_status'] ) ? sanitize_text_field( $args['halopsa_sync_status'] ) : null;
		$abandoned_only  = isset( $args['abandoned'] ) ? (bool) $args['abandoned'] : null;
		$search          = isset( $args['search'] ) ? sanitize_text_field( $args['search'] ) : null;

		$where = [ '1=1', 's.deleted_at IS NULL' ];
		$values = [];

		if ( $questionnaire ) {
			$where[]  = 's.questionnaire_id = %d';
			$values[] = $questionnaire;
		}
		if ( $grade ) {
			$where[]  = 's.grade_id = %s';
			$values[] = $grade;
		}
		if ( $sync_status ) {
			$where[]  = 's.halopsa_sync_status = %s';
			$values[] = $sync_status;
		}
		if ( $abandoned_only !== null ) {
			$where[]  = 's.abandoned = %d';
			$values[] = (int) $abandoned_only;
		}
		if ( $search ) {
			$where[]  = '(s.contact_name LIKE %s OR s.contact_email LIKE %s OR s.contact_company LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$values[] = $like;
			$values[] = $like;
			$values[] = $like;
		}

		$allowed_orderby = [
			'ref'                 => 's.ref',
			'contact'             => 's.contact_name',
			'questionnaire'       => 'q.name',
			'overall_score'       => 's.overall_score',
			'grade_id'            => 's.grade_id',
			'abandoned'           => 's.abandoned',
			'halopsa_sync_status' => 's.halopsa_sync_status',
			'utm_source'          => 's.utm_source',
			'created_at'          => 's.created_at',
		];
		$orderby_col = $allowed_orderby[ $args['orderby'] ?? 'created_at' ] ?? 's.created_at';
		$order_dir   = ( $args['order'] ?? 'DESC' ) === 'ASC' ? 'ASC' : 'DESC';

		$where_sql = implode( ' AND ', $where );
		$base_sql  = "FROM {$wpdb->prefix}wpq_submissions s
		              LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
		              LEFT JOIN {$wpdb->prefix}wpq_grade_thresholds gt
		                     ON gt.questionnaire_id = s.questionnaire_id AND gt.grade_id = s.grade_id
		              WHERE $where_sql";

		$count_sql = "SELECT COUNT(*) $base_sql";
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- orderby_col is from an internal whitelist, not user input.
		$data_sql  = "SELECT s.*, q.name AS questionnaire_name, q.ref AS questionnaire_ref,
		                     gt.grade_label
		              $base_sql ORDER BY $orderby_col $order_dir LIMIT %d OFFSET %d";

		$values_for_data   = array_merge( $values, [ $per_page, $offset ] );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- WHERE fragments are selected from internal templates and values are prepared.
		$prepared_count    = $values ? $wpdb->prepare( $count_sql, $values ) : $count_sql;
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- WHERE fragments are selected from internal templates and values are prepared.
		$prepared_data     = $wpdb->prepare( $data_sql, $values_for_data );

		return [
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared above.
			'items' => $wpdb->get_results( $prepared_data ) ?: [],
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared above when dynamic values are present.
			'total' => (int) $wpdb->get_var( $prepared_count ),
		];
	}

	public static function get_submissions_pending_halopsa_sync( int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$per_page = min( 100, max( 1, $per_page ) );
		$offset   = ( max( 1, $page ) - 1 ) * $per_page;

		$items = $wpdb->get_results( $wpdb->prepare(
			"SELECT s.*, q.name AS questionnaire_name, q.ref AS questionnaire_ref,
			        gt.grade_label
			 FROM {$wpdb->prefix}wpq_submissions s
			 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			 LEFT JOIN {$wpdb->prefix}wpq_grade_thresholds gt
			        ON gt.questionnaire_id = s.questionnaire_id AND gt.grade_id = s.grade_id
			 WHERE s.halopsa_sync_status IN ('pending','retry_pending')
			   AND s.abandoned = 0
			   AND s.deleted_at IS NULL
			 ORDER BY s.created_at ASC
			 LIMIT %d OFFSET %d",
			$per_page, $offset
		) ) ?: [];

		$total = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions
			 WHERE halopsa_sync_status IN ('pending','retry_pending')
			   AND abandoned = 0
			   AND deleted_at IS NULL"
		);

		return [ 'items' => $items, 'total' => $total ];
	}

	/**
	 * In-flight Questionnaire Report generation jobs (Readiness -> Cron Task
	 * Backlog): submissions whose qr_status is one of
	 * WPQ_Questionnaire_Report::ACTIVE_STATES. A row lingering here well past
	 * qr_requested_at with no qr_last_attempt_at almost always means WP-Cron
	 * never fired the queued event.
	 *
	 * @return array<int, object>
	 */
	public static function get_pending_cron_tasks(): array {
		global $wpdb;

		$active_states = class_exists( 'WPQ_Questionnaire_Report' ) ? WPQ_Questionnaire_Report::ACTIVE_STATES : [ 'queued', 'analysing', 'rendering_docx', 'converting_pdf' ];

		$placeholders = implode( ', ', array_fill( 0, count( $active_states ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is a fixed run of %s tokens; every value is bound via $wpdb->prepare() below.
		$sql = $wpdb->prepare(
			"SELECT s.id, s.ref, s.contact_name, s.contact_email, s.contact_company,
			        s.qr_status, s.qr_last_stage, s.qr_requested_at, s.qr_last_attempt_at,
			        s.qr_attempt_count, s.qr_failure_code, s.qr_failure_message,
			        s.qr_analysis_json, s.qr_generation_token,
			        q.name AS questionnaire_name, q.ref AS questionnaire_ref
			   FROM {$wpdb->prefix}wpq_submissions s
			   LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			  WHERE s.deleted_at IS NULL AND s.qr_status IN ({$placeholders})
			  ORDER BY s.qr_requested_at ASC",
			$active_states
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql was built via $wpdb->prepare() immediately above.
		return $wpdb->get_results( $sql ) ?: [];
	}

	// ------------------------------------------------------------------ //
	// Payment Sessions
	// ------------------------------------------------------------------ //

	// Low-level atomic status update only. Phase 3 webhook handling must validate
	// signature, event idempotency, session/product/amount/currency, and audit logs
	// before calling this transition helper.
	public static function transition_payment_status( int $submission_id, string $from, string $to ): bool {
		global $wpdb;

		$allowed = [
			'none'    => [ 'pending' ],
			'pending' => [ 'paid', 'failed', 'expired' ],
			'paid'    => [],
			'failed'  => [ 'pending' ],
			'expired' => [ 'pending' ],
		];

		if ( ! isset( $allowed[ $from ] ) || ! in_array( $to, $allowed[ $from ], true ) ) {
			return false;
		}

		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_submissions
			 SET payment_status = %s, updated_at = %s
			 WHERE id = %d AND payment_status = %s AND deleted_at IS NULL",
			$to,
			current_time( 'mysql', true ),
			$submission_id,
			$from
		) );

		return $result === 1;
	}

	public static function upsert_payment_session( string $session_id, array $data ): bool {
		global $wpdb;
		$now = current_time( 'mysql', true );
		if ( isset( $data['payment_status'] ) ) {
			$data['payment_status'] = self::normalise_payment_status( (string) $data['payment_status'] );
		}
		if ( isset( $data['currency'] ) ) {
			$data['currency'] = self::normalise_currency( (string) $data['currency'] );
		}
		if ( isset( $data['amount_total'] ) ) {
			$data['amount_total'] = max( 0, (int) $data['amount_total'] );
		}
		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT session_id FROM {$wpdb->prefix}wpq_payment_sessions WHERE session_id = %s",
			$session_id
		) );
		if ( $existing ) {
			$data['updated_at'] = $now;
			$result = $wpdb->update( "{$wpdb->prefix}wpq_payment_sessions", $data, [ 'session_id' => $session_id ] );
			return $result !== false;
		}
		$data['session_id'] = $session_id;
		$data['created_at'] = $now;
		$data['updated_at'] = $now;
		$result = $wpdb->insert( "{$wpdb->prefix}wpq_payment_sessions", $data );
		return $result !== false;
	}

	public static function get_payment_session( string $session_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_payment_sessions WHERE session_id = %s",
			$session_id
		) ) ?: null;
	}

	public static function update_payment_session_status( string $session_id, string $status ): bool {
		global $wpdb;
		$status = self::normalise_payment_status( $status );
		if ( ! in_array( $status, [ 'none', 'pending', 'paid', 'failed', 'expired' ], true ) ) {
			return false;
		}

		$result = $wpdb->update(
			"{$wpdb->prefix}wpq_payment_sessions",
			[
				'payment_status' => $status,
				'updated_at'     => current_time( 'mysql', true ),
			],
			[ 'session_id' => $session_id ]
		);

		return $result !== false;
	}

	public static function answers_hash( string $answers_json ): string {
		$decoded = json_decode( $answers_json, true );
		if ( is_array( $decoded ) ) {
			ksort( $decoded );
			$answers_json = (string) wp_json_encode( $decoded );
		}

		return hash( 'sha256', $answers_json );
	}

	private static function normalise_payment_status( string $status ): string {
		return $status === 'unpaid' ? 'pending' : $status;
	}

	private static function normalise_currency( string $currency ): string {
		return substr( strtolower( preg_replace( '/[^a-z]/i', '', $currency ) ), 0, 10 );
	}

	public static function payment_event_exists( string $stripe_event_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_payment_events WHERE stripe_event_id = %s LIMIT 1",
			$stripe_event_id
		) );
	}

	public static function get_payment_event( string $stripe_event_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_payment_events WHERE stripe_event_id = %s",
			$stripe_event_id
		) ) ?: null;
	}

	/**
	 * All stored Stripe webhook events for one submission, newest first - the
	 * admin replay surface. Never includes payload_json in list context; the
	 * replay handler re-fetches the single event it needs.
	 *
	 * @return array<int, object>
	 */
	public static function get_payment_events_for_submission( int $submission_id ): array {
		global $wpdb;
		if ( $submission_id <= 0 ) {
			return [];
		}
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT id, stripe_event_id, stripe_session_id, event_type, previous_status,
			        new_status, amount_total, currency, processed_at, created_at
			   FROM {$wpdb->prefix}wpq_payment_events
			  WHERE submission_id = %d
			  ORDER BY created_at DESC",
			$submission_id
		) ) ?: [];
	}

	public static function insert_payment_event( array $data ): int {
		global $wpdb;
		if ( empty( $data['stripe_event_id'] ) || empty( $data['stripe_session_id'] ) || empty( $data['submission_id'] ) ) {
			return 0;
		}
		if ( self::payment_event_exists( (string) $data['stripe_event_id'] ) ) {
			return 0;
		}

		$payload_json = $data['payload_json'] ?? null;
		if ( is_array( $payload_json ) || is_object( $payload_json ) ) {
			$payload_json = wp_json_encode( $payload_json );
		}

		$row = [
			'stripe_event_id'   => substr( sanitize_text_field( (string) $data['stripe_event_id'] ), 0, 255 ),
			'stripe_session_id' => substr( sanitize_text_field( (string) $data['stripe_session_id'] ), 0, 255 ),
			'submission_id'     => (int) $data['submission_id'],
			'product_id'        => isset( $data['product_id'] ) ? (int) $data['product_id'] : null,
			'event_type'        => substr( sanitize_text_field( (string) ( $data['event_type'] ?? '' ) ), 0, 100 ),
			'previous_status'   => isset( $data['previous_status'] ) ? self::normalise_payment_status( (string) $data['previous_status'] ) : null,
			'new_status'        => self::normalise_payment_status( sanitize_text_field( (string) ( $data['new_status'] ?? '' ) ) ),
			'amount_total'      => isset( $data['amount_total'] ) ? max( 0, (int) $data['amount_total'] ) : null,
			'currency'          => isset( $data['currency'] ) ? self::normalise_currency( (string) $data['currency'] ) : null,
			'payload_json'      => is_string( $payload_json ) ? $payload_json : null,
			'processed_at'      => isset( $data['processed_at'] ) ? sanitize_text_field( (string) $data['processed_at'] ) : null,
			'created_at'        => $data['created_at'] ?? current_time( 'mysql', true ),
		];

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_payment_events", $row );
		if ( $inserted === false ) {
			self::log_error( 'WPQ insert_payment_event failed: ' . $wpdb->last_error );
			return 0;
		}

		return (int) $wpdb->insert_id;
	}

	public static function mark_payment_event_processed( string $stripe_event_id, ?string $previous_status, string $new_status ): bool {
		global $wpdb;

		if ( $previous_status !== null ) {
			$allowed = [
				'none'    => [ 'pending' ],
				'pending' => [ 'paid', 'failed', 'expired' ],
				'paid'    => [],
				'failed'  => [ 'pending' ],
				'expired' => [ 'pending' ],
			];
			$from = self::normalise_payment_status( $previous_status );
			$to   = self::normalise_payment_status( $new_status );
			if ( ! isset( $allowed[ $from ] ) || ! in_array( $to, $allowed[ $from ], true ) ) {
				return false;
			}
		}

		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_payment_events
			 SET previous_status = %s, new_status = %s, processed_at = %s
			 WHERE stripe_event_id = %s AND processed_at IS NULL",
			$previous_status !== null ? self::normalise_payment_status( $previous_status ) : null,
			self::normalise_payment_status( $new_status ),
			current_time( 'mysql', true ),
			$stripe_event_id
		) );

		return $result === 1;
	}

	public static function update_submission_report( int $submission_id, int $product_id, string $report_path, ?string $error = null ): bool {
		$data = [
			'report_product_id'   => $product_id,
			'report_path'         => $report_path,
			'report_generated_at' => $error === null ? current_time( 'mysql', true ) : null,
			'report_error'        => $error,
		];

		return self::update_submission( $submission_id, $data );
	}

	/**
	 * @param string $purpose Scopes the token to one artefact, so a token minted for
	 *                        the paid HTML report cannot redeem the Questionnaire
	 *                        Report PDF or vice versa.
	 */
	public static function create_report_token( int $submission_id, int $ttl_seconds = 604800, int $max_uses = 5, string $purpose = 'paid_report' ): array {
		global $wpdb;
		$raw_token = bin2hex( random_bytes( 32 ) );
		$token_hash = hash_hmac( 'sha256', $raw_token, wp_salt( 'auth' ) );
		$expires_at = gmdate( 'Y-m-d H:i:s', time() + max( 60, $ttl_seconds ) );
		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_report_tokens", [
			'submission_id' => $submission_id,
			'token_hash'    => $token_hash,
			'purpose'       => sanitize_key( $purpose ) ?: 'paid_report',
			'expires_at'    => $expires_at,
			'use_count'     => 0,
			'max_uses'      => max( 1, $max_uses ),
			'created_at'    => current_time( 'mysql', true ),
		] );

		if ( $inserted === false ) {
			self::log_error( 'WPQ create_report_token failed: ' . $wpdb->last_error );
			return [];
		}

		return [
			'id'         => (int) $wpdb->insert_id,
			'token'      => $raw_token,
			'token_hash' => $token_hash,
			'expires_at' => $expires_at,
		];
	}

	public static function get_report_token( string $raw_token ): ?object {
		global $wpdb;
		$token_hash = hash_hmac( 'sha256', $raw_token, wp_salt( 'auth' ) );
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_report_tokens WHERE token_hash = %s",
			$token_hash
		) ) ?: null;
	}

	public static function validate_report_token( int $submission_id, string $raw_token ): ?object {
		$token = self::get_report_token( $raw_token );
		if ( ! $token || (int) $token->submission_id !== $submission_id ) {
			return null;
		}
		if ( ! empty( $token->revoked_at ) || (int) $token->use_count >= (int) $token->max_uses ) {
			return null;
		}
		if ( strtotime( (string) $token->expires_at ) <= time() ) {
			return null;
		}

		return $token;
	}

	/**
	 * @param string $purpose Must match the purpose the token was minted with; a
	 *                        token issued for another artefact is rejected rather
	 *                        than silently accepted.
	 */
	public static function consume_report_token( int $submission_id, string $raw_token, string $purpose = 'paid_report' ): ?object {
		global $wpdb;

		if ( $submission_id <= 0 || $raw_token === '' ) {
			return null;
		}

		$token_hash = hash_hmac( 'sha256', $raw_token, wp_salt( 'auth' ) );
		$purpose    = sanitize_key( $purpose ) ?: 'paid_report';
		$now        = current_time( 'mysql', true );
		$result     = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_report_tokens
			 SET use_count = use_count + 1,
			     used_at = %s
			 WHERE submission_id = %d
			   AND token_hash = %s
			   AND purpose = %s
			   AND revoked_at IS NULL
			   AND expires_at > %s
			   AND use_count < max_uses",
			$now,
			$submission_id,
			$token_hash,
			$purpose,
			$now
		) );

		if ( $result !== 1 ) {
			return null;
		}

		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_report_tokens WHERE submission_id = %d AND token_hash = %s",
			$submission_id,
			$token_hash
		) ) ?: null;
	}

	public static function increment_report_token_use( int $token_id ): bool {
		global $wpdb;
		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_report_tokens
			 SET use_count = use_count + 1,
			     used_at = %s
			 WHERE id = %d
			   AND revoked_at IS NULL
			   AND use_count < max_uses",
			current_time( 'mysql', true ),
			$token_id
		) );

		return $result === 1;
	}

	/**
	 * Revoke every unused download token for a submission. Called whenever the
	 * artefacts a token points at are deleted, so an already-delivered link stops
	 * working rather than resolving to a missing file.
	 */
	public static function revoke_report_tokens( int $submission_id ): int {
		global $wpdb;
		if ( $submission_id <= 0 ) {
			return 0;
		}

		$result = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_report_tokens
			 SET revoked_at = %s
			 WHERE submission_id = %d AND revoked_at IS NULL",
			current_time( 'mysql', true ),
			$submission_id
		) );

		return is_int( $result ) ? $result : 0;
	}

	public static function get_report_tokens_for_submission( int $submission_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_report_tokens WHERE submission_id = %d ORDER BY created_at DESC",
			$submission_id
		) ) ?: [];
	}

	public static function get_latest_payment_event_for_submission( int $submission_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_payment_events WHERE submission_id = %d ORDER BY created_at DESC, id DESC LIMIT 1",
			$submission_id
		) ) ?: null;
	}

	public static function verify_submission_session_token( object $submission, string $token ): bool {
		$stored = (string) ( $submission->session_token ?? '' );
		if ( $stored === '' || $token === '' ) {
			return false;
		}

		$token_hash = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
		return hash_equals( $stored, $token_hash );
	}

	// ------------------------------------------------------------------ //
	// Operational statistics
	// ------------------------------------------------------------------ //

	public static function get_submission_sync_counts(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'wpq_submissions';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sync_rows = $wpdb->get_results( "SELECT halopsa_sync_status AS s, COUNT(*) AS n FROM {$table} WHERE deleted_at IS NULL GROUP BY halopsa_sync_status", ARRAY_A ) ?: [];
		$sync = [ 'pending' => 0, 'processing' => 0, 'synced' => 0, 'failed' => 0, 'retry_pending' => 0, 'ignored' => 0, 'manual_review' => 0, 'skipped' => 0 ];
		foreach ( $sync_rows as $row ) {
			if ( array_key_exists( $row['s'], $sync ) ) {
				$sync[ $row['s'] ] = (int) $row['n'];
			}
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$pay_rows = $wpdb->get_results( "SELECT payment_status AS s, COUNT(*) AS n FROM {$table} WHERE deleted_at IS NULL GROUP BY payment_status", ARRAY_A ) ?: [];
		$payment = [ 'none' => 0, 'pending' => 0, 'paid' => 0, 'failed' => 0, 'expired' => 0 ];
		foreach ( $pay_rows as $row ) {
			if ( array_key_exists( $row['s'], $payment ) ) {
				$payment[ $row['s'] ] = (int) $row['n'];
			}
		}

		return [
			'sync'    => $sync,
			'payment' => $payment,
			'total'   => array_sum( $sync ),
		];
	}

	// ------------------------------------------------------------------ //
	// Helpers
	// ------------------------------------------------------------------ //

	public static function get_questionnaire_structure( int $questionnaire_id ): array {
		$domains    = self::get_domains( $questionnaire_id );
		$thresholds = self::get_grade_thresholds( $questionnaire_id );
		$result     = [];

		// First pass: build raw question data and a ref → "di_qi" index for condition resolution.
		$ref_to_key = []; // e.g. [ 'A1.6' => '1_0', 'A4.9' => '5_7' ]
		$raw_domains = [];

		foreach ( $domains as $di => $domain ) {
			$questions   = self::get_questions( (int) $domain->id );
			$raw_questions = [];
			foreach ( $questions as $qi => $q ) {
				$q_ref = isset( $q->question_ref ) && $q->question_ref !== '' ? (string) $q->question_ref : null;
				if ( $q_ref !== null ) {
					$ref_to_key[ $q_ref ] = "{$di}_{$qi}";
				}
				$raw_questions[ $qi ] = $q;
			}
			$raw_domains[ $di ] = [ 'domain' => $domain, 'questions' => $raw_questions ];
		}

		// Second pass: build final structure with resolved conditions.
		foreach ( $raw_domains as $di => $entry ) {
			$domain    = $entry['domain'];
			$questions = $entry['questions'];

			$built_questions = [];
			foreach ( $questions as $qi => $q ) {
				$options    = self::get_question_options( (int) $q->id );
				$condition  = null;
				$cond_ref   = isset( $q->condition_on_ref ) && $q->condition_on_ref !== '' ? (string) $q->condition_on_ref : null;
				if ( $cond_ref !== null && isset( $ref_to_key[ $cond_ref ] ) ) {
					$condition = [
						'key'   => $ref_to_key[ $cond_ref ],
						'value' => (string) ( $q->condition_value ?? '' ),
						'op'    => (string) ( $q->condition_op ?? 'eq' ),
					];
				}

				$max_score = null;
				if ( isset( $q->max_score ) && $q->max_score !== null && (int) $q->max_score > 0 ) {
					$max_score = (int) $q->max_score;
				}

				$built_questions[] = [
					'id'             => (int) $q->id,
					'question_ref'   => isset( $q->question_ref ) && $q->question_ref !== '' ? (string) $q->question_ref : null,
					'question'       => $q->question_text,
					'guidance_yes'     => $q->guidance_yes,
					'guidance_no'      => $q->guidance_no,
					'guidance_partial' => $q->guidance_partial ?? '',
					'recommendation'   => $q->recommendation ?? '',
					'score_yes'      => (int) $q->score_yes,
					'score_partial'  => (int) $q->score_partial,
					'score_no'       => (int) $q->score_no,
					'question_type'  => $q->question_type ?? 'tri_state',
					'is_required'    => (bool) ( $q->is_required ?? 1 ),
					'scoring_mode'   => $q->scoring_mode ?? 'legacy_tri_state',
					'max_score'      => $max_score,
					'help_text'      => $q->help_text ?? '',
					'min_selections' => isset( $q->min_selections ) && $q->min_selections !== null ? (int) $q->min_selections : null,
					'max_selections' => isset( $q->max_selections ) && $q->max_selections !== null ? (int) $q->max_selections : null,
					'condition'      => $condition,
					'options'        => array_map( fn( $o ) => [
						'key'              => $o->option_key,
						'label'            => $o->option_label,
						'score'            => (int) $o->score,
						'risk_level'       => $o->risk_level ?? null,
						'finding_priority' => $o->finding_priority ?? null,
						'finding_action'   => $o->finding_action ?? null,
						'is_default'       => (bool) $o->is_default,
						'requires_notes'   => (bool) ( $o->requires_notes ?? 0 ),
						'exclusive'        => (bool) ( $o->exclusive ?? 0 ),
					], $options ),
				];
			}

			$result[] = [
				'id'        => (int) $domain->id,
				'slug'      => $domain->slug,
				'name'      => $domain->name,
				'icon'      => $domain->icon,
				'brief'     => $domain->brief ?? '',
				'questions' => $built_questions,
			];
		}

		return [
			'domains'    => $result,
			'thresholds' => array_map( fn( $t ) => [
				'min_score'   => (int) $t->min_score,
				'grade_id'    => $t->grade_id,
				'grade_label' => $t->grade_label,
				'verdict'     => $t->verdict_text,
				'color'       => $t->color_hex,
				'bg'          => $t->bg_hex,
			], $thresholds ),
		];
	}

	// ------------------------------------------------------------------ //
	// Categories
	// ------------------------------------------------------------------ //

	/** Default categories seeded on install/upgrade. Idempotent - skips existing slugs. */
	public static function seed_categories(): void {
		global $wpdb;
		$defaults = [
			[ 'slug' => 'cyber_security',        'name' => 'Cyber Security',         'sort_order' => 10 ],
			[ 'slug' => 'data_privacy',           'name' => 'Data Privacy',            'sort_order' => 20 ],
			[ 'slug' => 'business_continuity',    'name' => 'Business Continuity',     'sort_order' => 30 ],
			[ 'slug' => 'risk_compliance',        'name' => 'Risk & Compliance',       'sort_order' => 40 ],
			[ 'slug' => 'operational_resilience', 'name' => 'Operational Resilience',  'sort_order' => 50 ],
			[ 'slug' => 'it_governance',          'name' => 'IT Governance',           'sort_order' => 60 ],
			[ 'slug' => 'supplier_risk',          'name' => 'Supplier Risk',           'sort_order' => 70 ],
			[ 'slug' => 'cloud_security',         'name' => 'Cloud Security',          'sort_order' => 80 ],
			[ 'slug' => 'physical_security',      'name' => 'Physical Security',       'sort_order' => 90 ],
			[ 'slug' => 'hr_people_security',     'name' => 'HR & People Security',    'sort_order' => 100 ],
		];
		foreach ( $defaults as $cat ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- seeder, idempotent
			$exists = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}wpq_categories WHERE slug = %s",
				$cat['slug']
			) );
			if ( ! $exists ) {
				$wpdb->insert( "{$wpdb->prefix}wpq_categories", $cat, [ '%s', '%s', '%d' ] );
			}
		}
	}

	public static function get_categories(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_results(
			"SELECT id, slug, name, sort_order FROM {$wpdb->prefix}wpq_categories ORDER BY sort_order ASC, name ASC"
		) ?: [];
	}

	public static function insert_category( string $slug, string $name, int $sort_order ): int {
		global $wpdb;
		$wpdb->insert(
			"{$wpdb->prefix}wpq_categories",
			[ 'slug' => $slug, 'name' => $name, 'sort_order' => $sort_order ],
			[ '%s', '%s', '%d' ]
		);
		return (int) $wpdb->insert_id;
	}

	public static function update_category( int $id, string $name, int $sort_order ): bool {
		global $wpdb;
		$result = $wpdb->update(
			"{$wpdb->prefix}wpq_categories",
			[ 'name' => $name, 'sort_order' => $sort_order ],
			[ 'id' => $id ],
			[ '%s', '%d' ],
			[ '%d' ]
		);
		return $result !== false;
	}

	public static function delete_category( int $id ): bool {
		global $wpdb;
		$result = $wpdb->delete( "{$wpdb->prefix}wpq_categories", [ 'id' => $id ], [ '%d' ] );
		return $result !== false;
	}

	public static function category_slug_exists( string $slug ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_categories WHERE slug = %s",
			$slug
		) );
	}

	// ------------------------------------------------------------------ //
	// Contacts
	// ------------------------------------------------------------------ //

	/**
	 * Returns one row per unique contact email with aggregated submission stats
	 * and the opt-out flag from wpq_contact_preferences.
	 *
	 * @return array<int, object>
	 */
	public static function get_contacts( array $args = [] ): array {
		global $wpdb;
		$per_page = max( 1, (int) ( $args['per_page'] ?? 50 ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$offset   = ( $page - 1 ) * $per_page;
		$search   = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';

		$where = "WHERE s.deleted_at IS NULL
		            AND s.contact_email != ''
		            AND s.contact_email != 'anonymous@deleted.invalid'";
		$params = [];
		if ( $search !== '' ) {
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where  .= ' AND (s.contact_email LIKE %s OR s.contact_name LIKE %s OR s.contact_company LIKE %s OR s.contact_phone LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$params[] = $per_page;
		$params[] = $offset;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where uses only internal safe values + wpdb->prepare for user input
		$results = $wpdb->get_results( $wpdb->prepare(
			"SELECT
				s.contact_email,
				MAX(s.contact_name)    AS contact_name,
				MAX(s.contact_company) AS contact_company,
				MAX(s.contact_phone)   AS contact_phone,
				COUNT(*)               AS submission_count,
				SUM(CASE WHEN s.abandoned = 0 AND s.completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed_count,
				SUM(CASE WHEN s.payment_status = 'paid' THEN 1 ELSE 0 END)                      AS paid_count,
				MAX(s.created_at)      AS last_submission_at,
				cp.opted_out           AS opted_out,
				cp.opted_out_at        AS opted_out_at
			FROM {$wpdb->prefix}wpq_submissions s
			LEFT JOIN {$wpdb->prefix}wpq_contact_preferences cp ON cp.email = s.contact_email
			{$where}
			GROUP BY s.contact_email
			ORDER BY last_submission_at DESC
			LIMIT %d OFFSET %d",
			...$params
		) ) ?: [];
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $results;
	}

	public static function count_contacts( string $search = '' ): int {
		global $wpdb;
		$where  = "WHERE s.deleted_at IS NULL
		             AND s.contact_email != ''
		             AND s.contact_email != 'anonymous@deleted.invalid'";
		$params = [];
		if ( $search !== '' ) {
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where  .= ' AND (s.contact_email LIKE %s OR s.contact_name LIKE %s OR s.contact_company LIKE %s OR s.contact_phone LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- $sql is built from internal prefix constants; user input goes through esc_like + prepare
		$sql = "SELECT COUNT(DISTINCT s.contact_email)
		        FROM {$wpdb->prefix}wpq_submissions s
		        {$where}";
		if ( empty( $params ) ) {
			$count = (int) $wpdb->get_var( $sql );
		} else {
			$count = (int) $wpdb->get_var( $wpdb->prepare( $sql, ...$params ) );
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared

		return $count;
	}

	/** @return array<int, object> */
	public static function get_orders( array $args = [] ): array {
		global $wpdb;
		$per_page = max( 1, (int) ( $args['per_page'] ?? 50 ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$offset   = ( $page - 1 ) * $per_page;
		$search   = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';

		$allowed_orderby = [ 'created_at', 'amount_total', 'payment_status', 'contact_email' ];
		$orderby = in_array( $args['orderby'] ?? '', $allowed_orderby, true ) ? $args['orderby'] : 'created_at';
		$order   = strtoupper( $args['order'] ?? 'DESC' ) === 'ASC' ? 'ASC' : 'DESC';

		$orderby_col = match ( $orderby ) {
			'contact_email'  => 's.contact_email',
			'amount_total'   => 'ps.amount_total',
			'payment_status' => 'ps.payment_status',
			default          => 'ps.created_at',
		};

		$where  = 'WHERE 1=1';
		$params = [];
		if ( $search !== '' ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (s.contact_email LIKE %s OR s.contact_name LIKE %s OR ps.session_id LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$params[] = $per_page;
		$params[] = $offset;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where/$orderby_col are internal-only; user input goes through esc_like + prepare
		$results = $wpdb->get_results( $wpdb->prepare(
			"SELECT ps.session_id, ps.payment_status, ps.amount_total, ps.currency,
			        ps.created_at, ps.updated_at,
			        s.ref AS submission_ref, s.id AS submission_id,
			        s.contact_name, s.contact_email,
			        q.name AS questionnaire_name, q.ref AS questionnaire_ref,
			        p.name AS product_name
			   FROM {$wpdb->prefix}wpq_payment_sessions ps
			   JOIN {$wpdb->prefix}wpq_submissions s ON s.id = ps.submission_id
			  LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			  LEFT JOIN {$wpdb->prefix}wpq_products p ON p.id = ps.product_id
			  {$where}
			  ORDER BY {$orderby_col} {$order}
			  LIMIT %d OFFSET %d",
			...$params
		) ) ?: [];
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $results;
	}

	public static function count_orders( string $search = '' ): int {
		global $wpdb;
		$where  = 'WHERE 1=1';
		$params = [];
		if ( $search !== '' ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (s.contact_email LIKE %s OR s.contact_name LIKE %s OR ps.session_id LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- $sql is built from internal prefix constants; user input goes through esc_like + prepare
		$sql = "SELECT COUNT(*)
		        FROM {$wpdb->prefix}wpq_payment_sessions ps
		        JOIN {$wpdb->prefix}wpq_submissions s ON s.id = ps.submission_id
		        {$where}";
		if ( empty( $params ) ) {
			$count = (int) $wpdb->get_var( $sql );
		} else {
			$count = (int) $wpdb->get_var( $wpdb->prepare( $sql, ...$params ) );
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared

		return $count;
	}

	/**
	 * Paid-order totals per currency, for the Revenue dashboard's summary
	 * header. Grouped by currency rather than assuming a single one, since
	 * coupons already support GBP/USD/EUR/AUD/CAD.
	 *
	 * @return array<int, object{currency:string, paid_count:int, total_amount:int}>
	 */
	public static function get_revenue_summary(): array {
		global $wpdb;

		return $wpdb->get_results(
			"SELECT currency, COUNT(*) AS paid_count, SUM(amount_total) AS total_amount
			   FROM {$wpdb->prefix}wpq_payment_sessions
			  WHERE payment_status = 'paid'
			  GROUP BY currency"
		) ?: [];
	}

	/** @return array<int, object> */
	public static function get_contact_submissions( string $email ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT s.id, s.ref, s.overall_score, s.grade_id, s.abandoned, s.completed_at,
			        s.payment_status, s.stripe_session_id, s.halopsa_sync_status,
			        s.created_at, s.updated_at, s.deleted_at, s.report_path,
			        q.name AS questionnaire_name, q.ref AS questionnaire_ref,
			        gt.grade_label
			   FROM {$wpdb->prefix}wpq_submissions s
			   LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			   LEFT JOIN {$wpdb->prefix}wpq_grade_thresholds gt
			          ON gt.questionnaire_id = s.questionnaire_id AND gt.grade_id = s.grade_id
			  WHERE s.contact_email = %s
			  ORDER BY s.created_at DESC",
			$email
		) ) ?: [];
	}

	/** @return array<int, object> */
	public static function get_contact_payments( string $email ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT ps.session_id, ps.payment_status, ps.amount_total, ps.currency,
			        ps.created_at, ps.updated_at,
			        s.ref AS submission_ref, s.id AS submission_id,
			        p.name AS product_name
			   FROM {$wpdb->prefix}wpq_payment_sessions ps
			   JOIN {$wpdb->prefix}wpq_submissions s ON s.id = ps.submission_id
			   LEFT JOIN {$wpdb->prefix}wpq_products p ON p.id = ps.product_id
			  WHERE s.contact_email = %s
			  ORDER BY ps.created_at DESC",
			$email
		) ) ?: [];
	}

	/**
	 * Returns all submission data for a contact for GDPR export.
	 *
	 * @return array<string, mixed>
	 */
	public static function export_contact_data( string $email ): array {
		global $wpdb;
		$submissions = $wpdb->get_results( $wpdb->prepare(
			"SELECT s.*, q.ref AS questionnaire_ref, q.name AS questionnaire_name
			   FROM {$wpdb->prefix}wpq_submissions s
			   LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
			  WHERE s.contact_email = %s
			  ORDER BY s.created_at ASC",
			$email
		) ) ?: [];

		$payments = self::get_contact_payments( $email );
		$opt_out  = self::get_contact_opt_out( $email );

		$clean_submissions = array_map( static function ( object $s ): array {
			$row = (array) $s;
			// Strip internal fields not relevant to a data-subject export.
			unset( $row['session_token'], $row['answers_json'], $row['domain_scores_json'], $row['findings_json'] );
			return $row;
		}, $submissions );

		$enquiries = $wpdb->get_results( $wpdb->prepare(
			"SELECT e.ref, e.contact_name, e.contact_email, e.contact_company, e.contact_phone,
			        e.consent, e.fields_json, e.created_at, f.name AS form_name
			   FROM {$wpdb->prefix}wpq_enquiries e
			   LEFT JOIN {$wpdb->prefix}wpq_enquiry_forms f ON f.id = e.form_id
			  WHERE e.contact_email = %s
			  ORDER BY e.created_at ASC",
			$email
		) ) ?: [];

		$export = [
			'contact_email'  => $email,
			'opted_out'      => $opt_out ? (bool) $opt_out->opted_out : false,
			'opted_out_at'   => $opt_out?->opted_out_at,
			'submissions'    => $clean_submissions,
			'payments'       => array_map( fn( $p ) => (array) $p, $payments ),
			'enquiries'      => array_map( fn( $e ) => (array) $e, $enquiries ),
		];

		// Canonical record, where one exists for this email identity. Only this
		// contact's own data is disclosed - a shared mailbox exports per email
		// but canonical details only for contacts actually holding the identity.
		if ( class_exists( 'WPQ_Contact_Normaliser' ) ) {
			$normalised = WPQ_Contact_Normaliser::normalise_email( $email );
			if ( '' !== $normalised ) {
				$hash        = WPQ_Contact_Normaliser::identity_hash( 'email', $normalised );
				$contact_ids = $wpdb->get_col( $wpdb->prepare(
					"SELECT DISTINCT contact_id FROM {$wpdb->prefix}wpq_contact_identities WHERE type = 'email' AND value_hash = %s",
					$hash
				) ) ?: [];

				$canonical = [];
				foreach ( $contact_ids as $contact_id ) {
					$contact_id = (int) $contact_id;
					$contact    = $wpdb->get_row( $wpdb->prepare(
						"SELECT uuid, given_name, family_name, display_name, organisation, job_title, status,
						        created_source, first_observed_at, last_observed_at, created_at
						 FROM {$wpdb->prefix}wpq_contacts WHERE id = %d",
						$contact_id
					) );
					if ( ! $contact ) {
						continue;
					}
					$canonical[] = [
						'profile'        => (array) $contact,
						'identities'     => array_map( 'get_object_vars', $wpdb->get_results( $wpdb->prepare(
							"SELECT type, value_original, verification, is_primary, first_observed_at, last_observed_at
							 FROM {$wpdb->prefix}wpq_contact_identities WHERE contact_id = %d",
							$contact_id
						) ) ?: [] ),
						'organisations'  => array_map( 'get_object_vars', $wpdb->get_results( $wpdb->prepare(
							"SELECT organisation_name, relationship, is_primary, valid_from, valid_until
							 FROM {$wpdb->prefix}wpq_contact_organisations WHERE contact_id = %d",
							$contact_id
						) ) ?: [] ),
						'consent_events' => array_map( 'get_object_vars', $wpdb->get_results( $wpdb->prepare(
							"SELECT purpose, event, source, occurred_at
							 FROM {$wpdb->prefix}wpq_contact_consent_events WHERE contact_id = %d ORDER BY occurred_at ASC",
							$contact_id
						) ) ?: [] ),
						'interactions'   => array_map( 'get_object_vars', $wpdb->get_results( $wpdb->prepare(
							"SELECT product, interaction_type, source_ref, occurred_at
							 FROM {$wpdb->prefix}wpq_contact_interactions WHERE contact_id = %d ORDER BY occurred_at ASC",
							$contact_id
						) ) ?: [] ),
					];
				}
				if ( ! empty( $canonical ) ) {
					$export['canonical_contacts'] = $canonical;
				}
			}
		}

		return $export;
	}

	/** Anonymises all submissions for a contact. Returns count of rows updated. */
	public static function anonymise_contact( string $email ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );

		// File artefacts are removed before (outside) the transaction: file
		// deletions cannot roll back, and losing a report file for a contact
		// whose anonymisation then failed is the privacy-safe direction.
		self::purge_questionnaire_report_artefacts_where(
			"contact_email = %s AND contact_email != 'anonymous@deleted.invalid'",
			[ $email ]
		);

		// One transaction across submissions, enquiries, and canonical contacts:
		// a partial anonymisation (source rows cleared but the canonical contact
		// still carrying PII, or vice versa) is a GDPR failure state.
		$result = self::transaction( static function () use ( $wpdb, $now, $email ) {
			$updated = $wpdb->query( $wpdb->prepare(
				"UPDATE {$wpdb->prefix}wpq_submissions
				    SET contact_name    = 'Anonymous',
				        contact_email   = 'anonymous@deleted.invalid',
				        contact_company = NULL,
				        contact_phone   = NULL,
				        ip_address      = NULL,
				        session_token   = '',
				        updated_at      = %s
				  WHERE contact_email = %s
				    AND contact_email != 'anonymous@deleted.invalid'",
				$now,
				$email
			) );
			if ( false === $updated ) {
				return false;
			}

			// Enquiries carry the same contact PII and their free-text answers may
			// too - anonymising a contact must reach them as well.
			if ( false === $wpdb->query( $wpdb->prepare(
				"UPDATE {$wpdb->prefix}wpq_enquiries
				    SET contact_name    = 'Anonymous',
				        contact_email   = 'anonymous@deleted.invalid',
				        contact_company = NULL,
				        contact_phone   = NULL,
				        fields_json     = NULL
				  WHERE contact_email = %s
				    AND contact_email != 'anonymous@deleted.invalid'",
				$email
			) ) ) {
				return false;
			}

			self::anonymise_canonical_contacts_for_email( $email );

			return (int) $updated;
		} );

		return is_int( $result ) ? $result : 0;
	}

	/**
	 * Anonymise every canonical contact holding this email identity: profile
	 * PII cleared, identities revoked and blanked, organisations removed,
	 * interaction organisation snapshots cleared. Consent/suppression events
	 * and their projections are deliberately retained (hashed identity only)
	 * so a direct-marketing objection survives anonymisation.
	 */
	public static function anonymise_canonical_contacts_for_email( string $email ): void {
		global $wpdb;
		if ( ! class_exists( 'WPQ_Contact_Normaliser' ) ) {
			return;
		}
		$normalised = WPQ_Contact_Normaliser::normalise_email( $email );
		if ( '' === $normalised ) {
			return;
		}
		$hash = WPQ_Contact_Normaliser::identity_hash( 'email', $normalised );
		$now  = current_time( 'mysql', true );

		$contact_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT contact_id FROM {$wpdb->prefix}wpq_contact_identities WHERE type = 'email' AND value_hash = %s",
			$hash
		) ) ?: [];

		foreach ( $contact_ids as $contact_id ) {
			$contact_id = (int) $contact_id;
			$wpdb->update( "{$wpdb->prefix}wpq_contacts", [
				'given_name'    => '',
				'family_name'   => '',
				'display_name'  => 'Anonymous',
				'organisation'  => '',
				'job_title'     => null,
				'status'        => 'anonymised',
				'wp_user_id'    => null,
				'anonymised_at' => $now,
				'updated_at'    => $now,
			], [ 'id' => $contact_id ] );

			// Identities: value cleared, hash kept so suppression scoping survives.
			$wpdb->update( "{$wpdb->prefix}wpq_contact_identities", [
				'value_original'   => '',
				'value_normalised' => '',
				'verification'     => 'revoked',
				'updated_at'       => $now,
			], [ 'contact_id' => $contact_id ] );

			$wpdb->delete( "{$wpdb->prefix}wpq_contact_organisations", [ 'contact_id' => $contact_id ] );
			$wpdb->query( $wpdb->prepare(
				"UPDATE {$wpdb->prefix}wpq_contact_interactions SET organisation = '' WHERE contact_id = %d",
				$contact_id
			) );

			if ( class_exists( 'WPQ_Contact_Admin' ) ) {
				WPQ_Contact_Admin::record_audit( $contact_id, 'anonymised', 'privacy_workflow', [], [], 'Email-keyed anonymisation request' );
			}
		}
	}

	/**
	 * Permanently hard-deletes all submissions for a contact and removes their
	 * contact preferences record. Returns count of submissions deleted.
	 */
	public static function delete_contact( string $email ): int {
		global $wpdb;
		$count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions WHERE contact_email = %s",
			$email
		) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- GDPR hard delete lookup
		$artefact_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, qr_docx_path, qr_pdf_path FROM {$wpdb->prefix}wpq_submissions WHERE contact_email = %s",
			$email
		) );
		foreach ( (array) $artefact_rows as $artefact_row ) {
			if ( class_exists( 'WPQ_Questionnaire_Report_Storage' ) ) {
				WPQ_Questionnaire_Report_Storage::delete_stored_files( $artefact_row->qr_docx_path ?? null, $artefact_row->qr_pdf_path ?? null );
			}
			// The submission rows are about to be removed outright, so their download
			// tokens must go with them rather than linger pointing at nothing.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- GDPR hard delete
			$wpdb->delete( "{$wpdb->prefix}wpq_report_tokens", [ 'submission_id' => (int) $artefact_row->id ], [ '%d' ] );
		}

		// One transaction across the hard deletes and the canonical-contact
		// anonymisation, mirroring anonymise_contact(): a half-applied GDPR
		// erasure is worse than a clean failure the admin can retry.
		self::transaction( static function () use ( $wpdb, $email ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- GDPR hard delete
			if ( false === $wpdb->delete( "{$wpdb->prefix}wpq_submissions", [ 'contact_email' => $email ], [ '%s' ] ) ) {
				return false;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- GDPR hard delete
			if ( false === $wpdb->delete( "{$wpdb->prefix}wpq_enquiries", [ 'contact_email' => $email ], [ '%s' ] ) ) {
				return false;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->delete( "{$wpdb->prefix}wpq_contact_preferences", [ 'email' => $email ], [ '%s' ] );

			// Canonical record: anonymised (identifiers cleared, hashed suppression
			// evidence retained per policy) and marked deleted - relational
			// integrity for merge/audit history is preserved without PII.
			self::anonymise_canonical_contacts_for_email( $email );
			if ( class_exists( 'WPQ_Contact_Normaliser' ) ) {
				$normalised = WPQ_Contact_Normaliser::normalise_email( $email );
				if ( '' !== $normalised ) {
					$hash = WPQ_Contact_Normaliser::identity_hash( 'email', $normalised );
					$ids  = $wpdb->get_col( $wpdb->prepare(
						"SELECT DISTINCT contact_id FROM {$wpdb->prefix}wpq_contact_identities WHERE type = 'email' AND value_hash = %s",
						$hash
					) ) ?: [];
					foreach ( $ids as $cid ) {
						$wpdb->update( "{$wpdb->prefix}wpq_contacts", [
							'status'     => 'deleted',
							'deleted_at' => current_time( 'mysql', true ),
							'updated_at' => current_time( 'mysql', true ),
						], [ 'id' => (int) $cid ] );
					}
				}
			}

			return true;
		} );

		return $count;
	}

	public static function get_contact_opt_out( string $email ): ?object {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_contact_preferences WHERE email = %s",
			$email
		) ) ?: null;
	}

	public static function set_contact_opt_out( string $email, bool $opted_out, int $user_id ): bool {
		global $wpdb;
		$now      = current_time( 'mysql', true );
		$existing = self::get_contact_opt_out( $email );
		if ( $existing ) {
			$result = $wpdb->update(
				"{$wpdb->prefix}wpq_contact_preferences",
				[ 'opted_out' => $opted_out ? 1 : 0, 'opted_out_at' => $now, 'opted_out_by_user_id' => $user_id ],
				[ 'email' => $email ],
				[ '%d', '%s', '%d' ],
				[ '%s' ]
			);
			return $result !== false;
		}

		$result = $wpdb->insert(
			"{$wpdb->prefix}wpq_contact_preferences",
			[ 'email' => $email, 'opted_out' => $opted_out ? 1 : 0, 'opted_out_at' => $now, 'opted_out_by_user_id' => $user_id ],
			[ '%s', '%d', '%s', '%d' ]
		);

		return $result !== false;
	}
}
