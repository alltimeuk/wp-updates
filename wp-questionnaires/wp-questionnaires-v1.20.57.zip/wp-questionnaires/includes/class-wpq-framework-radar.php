<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Framework readiness horizontal bar chart, drawn deterministically from
 * already-stored framework assessment rows (fr_results_json from the
 * automatic submission-time job, falling back to a Questionnaire Report
 * run's own qr_analysis_json copy) - never from a live Claude call. One bar
 * per assessed framework; length is the readiness position; colour is the
 * readiness level.
 *
 * Bars, not a radar: each framework is an independent standard with its own
 * headline score - a radar's connecting polygon implies a geometric
 * relationship between adjacent frameworks that doesn't actually exist (was
 * WPQ_Framework_Radar::svg_radar()/png_radar() before this class became
 * bars-only; that drawing code now lives in WPQ_Domain_Radar instead, where
 * the domains genuinely are facets of one coherent whole).
 *
 * Percent precedence per framework:
 *   1. readiness_percent - only present when the standard's own methodology
 *      yields a defensible figure (the analysis schema forbids estimating).
 *   2. Cited-control ratio - strengths / (strengths + gaps), both lists carry
 *      validated control references, so this is a data-backed coverage signal.
 *   3. Level band - aligned 85, partially_aligned 50, not_aligned 15,
 *      insufficient_evidence 5 - a last-resort indicative position.
 *
 * Two renderers from one row model:
 *   - render_svg(): inline SVG for the admin submission detail and the public
 *     results screen. Presentation attributes only (fill/stroke/font-*), no
 *     style attributes and no scripts, so it renders under the strictest CSP
 *     the frontend has to satisfy (style-src-attr 'none').
 *   - render_png(): GD-drawn PNG for the DOCX template (via image macro) and
 *     the Dompdf HTML report (as a data URI). Uses the DejaVu font bundled
 *     with Dompdf when present, falling back to GD's built-in font.
 */
class WPQ_Framework_Radar {

	public const LEVEL_COLOURS = [
		'aligned'               => '#2eb872',
		'partially_aligned'     => '#f5a623',
		'not_aligned'           => '#e84855',
		'insufficient_evidence' => '#9aa3ad',
	];

	private const LEVEL_BANDS = [
		'aligned'               => 85,
		'partially_aligned'     => 50,
		'not_aligned'           => 15,
		'insufficient_evidence' => 5,
	];

	/**
	 * Decode a submission's stored framework assessment rows, preferring the
	 * automatic submission-time job (fr_results_json, WPQ_Framework_Readiness_Job)
	 * over a Questionnaire Report run's own nested copy (qr_analysis_json) - the
	 * latter is kept only as a fallback for submissions assessed before this
	 * became a submission-time job, or whose questionnaire had no frameworks
	 * enabled until after report generation already ran once.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function stored_frameworks( object $submission ): array {
		$direct = self::decode_framework_rows( (string) ( $submission->fr_results_json ?? '' ) );
		if ( ! empty( $direct ) ) {
			return $direct;
		}

		$raw = (string) ( $submission->qr_analysis_json ?? '' );
		if ( '' === $raw ) {
			return [];
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) || ! is_array( $decoded['frameworks'] ?? null ) ) {
			return [];
		}
		return array_values( array_filter( $decoded['frameworks'], 'is_array' ) );
	}

	/** @return array<int, array<string, mixed>> */
	private static function decode_framework_rows( string $raw ): array {
		if ( '' === $raw ) {
			return [];
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return [];
		}
		return array_values( array_filter( $decoded, 'is_array' ) );
	}

	/**
	 * Normalise stored assessment rows into the chart row model.
	 *
	 * @param array<int, array<string, mixed>> $frameworks Stored assessment rows.
	 * @return array<int, array{name: string, level: string, label: string, percent: int, derived: bool}>
	 */
	public static function rows_from_analysis( array $frameworks ): array {
		$rows = [];
		foreach ( $frameworks as $framework ) {
			if ( ! is_array( $framework ) ) {
				continue;
			}
			$name = trim( (string) ( $framework['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}

			$level = strtolower( trim( (string) ( $framework['readiness_level'] ?? $framework['level'] ?? '' ) ) );
			if ( ! isset( self::LEVEL_COLOURS[ $level ] ) ) {
				$level = 'insufficient_evidence';
			}

			$percent = null;
			$derived = false;
			if ( isset( $framework['readiness_percent'] ) && is_numeric( $framework['readiness_percent'] ) ) {
				$percent = max( 0, min( 100, (int) $framework['readiness_percent'] ) );
			}

			if ( null === $percent ) {
				$strengths = is_array( $framework['strengths'] ?? null ) ? count( $framework['strengths'] ) : 0;
				$gaps      = is_array( $framework['gaps'] ?? null ) ? count( $framework['gaps'] ) : 0;
				$derived   = true;
				if ( ( $strengths + $gaps ) > 0 ) {
					$percent = (int) round( 100 * $strengths / ( $strengths + $gaps ) );
				} else {
					$percent = self::LEVEL_BANDS[ $level ];
				}
			}

			$rows[] = [
				'name'    => $name,
				'level'   => $level,
				'label'   => trim( (string) ( $framework['readiness_label'] ?? '' ) ) ?: ucwords( str_replace( '_', ' ', $level ) ),
				'percent' => $percent,
				'derived' => $derived,
			];
		}

		return $rows;
	}

	/**
	 * Inline SVG horizontal bar chart. Returns '' when there is nothing to
	 * draw.
	 *
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	public static function render_svg( array $rows ): string {
		if ( empty( $rows ) ) {
			return '';
		}
		return self::svg_bars( $rows );
	}

	/**
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	private static function svg_bars( array $rows ): string {
		$width    = 560;
		$row_h    = 54;
		$height   = 16 + $row_h * count( $rows );
		$bar_x    = 12;
		$bar_full = $width - 130;

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Framework readiness" class="wpq-radar-svg">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';

		foreach ( $rows as $i => $row ) {
			// Word-wrapped, not truncated with an ellipsis - a long framework
			// name (e.g. "NIST SP 800-161 Rev 1 - Cybersecurity Supply Chain
			// Risk Management Practices") must stay fully readable.
			$name_lines = self::wrap_text( $row['name'], 60 );
			$top        = 16 + $i * $row_h;
			foreach ( $name_lines as $li => $line ) {
				$svg .= '<text x="' . $bar_x . '" y="' . ( $top + 12 + $li * 13 ) . '" font-size="12" font-weight="600" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
					. self::escape( $line ) . '</text>';
			}
			$bar_top = $top + 12 + count( $name_lines ) * 13;
			$svg    .= '<rect x="' . $bar_x . '" y="' . $bar_top . '" width="' . $bar_full . '" height="14" rx="7" fill="#eef1f4"/>';
			$svg    .= '<rect x="' . $bar_x . '" y="' . $bar_top . '" width="' . self::coord( max( 7, $bar_full * $row['percent'] / 100 ) ) . '" height="14" rx="7" fill="' . self::LEVEL_COLOURS[ $row['level'] ] . '"/>';
			$svg    .= '<text x="' . ( $bar_x + $bar_full + 10 ) . '" y="' . ( $bar_top + 12 ) . '" font-size="11" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( (string) $row['percent'] . ( $row['derived'] ? '≈' : '' ) . '%' ) . '</text>';
			$svg .= '<text x="' . $bar_x . '" y="' . ( $bar_top + 30 ) . '" font-size="11" fill="' . self::LEVEL_COLOURS[ $row['level'] ] . '" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( $row['label'] ) . '</text>';
		}

		$svg .= '</svg>';
		return $svg;
	}

	/**
	 * GD-drawn PNG horizontal bar chart (mirrors the SVG). Returns null when
	 * GD is unavailable or drawing fails - callers must treat the image as
	 * optional.
	 *
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	public static function render_png( array $rows, int $width = 1120 ): ?string {
		if ( empty( $rows ) || ! function_exists( 'imagecreatetruecolor' ) ) {
			return null;
		}

		try {
			return self::png_bars( $rows, $width );
		} catch ( Throwable $e ) {
			return null;
		}
	}

	/** @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows */
	private static function png_bars( array $rows, int $width ): ?string {
		// Word-wrapped name lines determine each row's own height, since a
		// long framework name must stay fully readable rather than being
		// truncated with an ellipsis.
		$name_lines_per_row = array_map( static fn( array $row ): array => self::wrap_text( $row['name'], 55 ), $rows );
		$row_heights        = array_map( static fn( array $lines ): int => 60 + count( $lines ) * 24, $name_lines_per_row );
		$height             = 32 + array_sum( $row_heights );

		$img   = imagecreatetruecolor( $width, $height );
		$white = imagecolorallocate( $img, 255, 255, 255 );
		$track = imagecolorallocate( $img, 238, 241, 244 );
		$text  = imagecolorallocate( $img, 51, 65, 79 );
		imagefill( $img, 0, 0, $white );

		$bar_x    = 24;
		$bar_full = $width - 260;
		$top      = 32;
		foreach ( $rows as $i => $row ) {
			$colour     = self::png_level_colour( $img, $row['level'] );
			$name_lines = $name_lines_per_row[ $i ];
			foreach ( $name_lines as $li => $line ) {
				self::png_text( $img, 18, $bar_x, $top + 18 + $li * 24, $line, $text, true );
			}
			$bar_top = $top + 12 + count( $name_lines ) * 24;
			imagefilledrectangle( $img, $bar_x, $bar_top, $bar_x + $bar_full, $bar_top + 26, $track );
			imagefilledrectangle( $img, $bar_x, $bar_top, $bar_x + max( 14, (int) round( $bar_full * $row['percent'] / 100 ) ), $bar_top + 26, $colour );
			self::png_text( $img, 16, $bar_x + $bar_full + 16, $bar_top + 20, $row['label'] . ' (' . $row['percent'] . ( $row['derived'] ? '~' : '' ) . '%)', $text );
			$top += $row_heights[ $i ];
		}

		return self::png_output( $img );
	}

	private static function coord( float $value ): string {
		return rtrim( rtrim( sprintf( '%.1F', $value ), '0' ), '.' );
	}

	private static function escape( string $value ): string {
		return htmlspecialchars( $value, ENT_QUOTES | ENT_XML1, 'UTF-8' );
	}

	/**
	 * Greedy word-wrap for SVG text (which has no native wrapping) - splits
	 * on word boundaries only, so a long framework name wraps onto more
	 * lines rather than ever being cut with an ellipsis.
	 *
	 * @return array<int, string>
	 */
	private static function wrap_text( string $value, int $width ): array {
		$words = preg_split( '/\s+/', trim( $value ) ) ?: [ $value ];
		$lines = [];
		$line  = '';
		foreach ( $words as $word ) {
			$candidate = '' === $line ? $word : $line . ' ' . $word;
			if ( mb_strlen( $candidate ) > $width && '' !== $line ) {
				$lines[] = $line;
				$line    = $word;
			} else {
				$line = $candidate;
			}
		}
		if ( '' !== $line ) {
			$lines[] = $line;
		}
		return $lines ?: [ '' ];
	}

	/** @param resource|\GdImage $img */
	private static function png_level_colour( $img, string $level ): int {
		$hex = self::LEVEL_COLOURS[ $level ] ?? self::LEVEL_COLOURS['insufficient_evidence'];
		return imagecolorallocate(
			$img,
			(int) hexdec( substr( $hex, 1, 2 ) ),
			(int) hexdec( substr( $hex, 3, 2 ) ),
			(int) hexdec( substr( $hex, 5, 2 ) )
		);
	}

	private static function ttf_path(): string {
		$candidates = [
			WPQ_PLUGIN_DIR . 'vendor/dompdf/dompdf/lib/fonts/DejaVuSans.ttf',
			WPQ_PLUGIN_DIR . 'vendor/dompdf/dompdf/lib/fonts/DejaVuSans-Bold.ttf',
		];
		foreach ( $candidates as $candidate ) {
			if ( is_readable( $candidate ) ) {
				return $candidate;
			}
		}
		return '';
	}

	/** @param resource|\GdImage $img */
	private static function png_text( $img, int $size, int $x, int $y, string $text, int $colour, bool $bold = false ): void {
		$font = self::ttf_path();
		if ( '' !== $font && function_exists( 'imagettftext' ) ) {
			imagettftext( $img, $size, 0, $x, $y, $colour, $font, $text );
			if ( $bold ) {
				imagettftext( $img, $size, 0, $x + 1, $y, $colour, $font, $text );
			}
			return;
		}
		imagestring( $img, $bold ? 5 : 4, $x, $y - 12, $text, $colour );
	}

	/** @param resource|\GdImage $img */
	private static function png_output( $img ): ?string {
		ob_start();
		$ok     = imagepng( $img );
		$binary = ob_get_clean();
		imagedestroy( $img );
		return ( $ok && is_string( $binary ) && '' !== $binary ) ? $binary : null;
	}
}
