<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Domain Breakdown radar ("spider") chart, drawn deterministically from the
 * submission's own scored domain data (WPQ_Scoring::build_micro_report()'s
 * 'domains' array) - never from a live Claude call, so it renders
 * immediately alongside the rest of the results screen. One spoke per
 * questionnaire domain (whatever domains that questionnaire is actually
 * configured with - nothing here is hard-coded); radius is the percentage
 * score; colour is the domain's own resolved grade colour.
 *
 * A radar reads as a coherent whole here - unlike Framework Readiness
 * (WPQ_Framework_Radar, bars-only), a questionnaire's domains genuinely are
 * facets of one overall posture, so the connecting polygon is meaningful
 * rather than implying a false relationship between independent things.
 *
 * No full domain names on the radar itself - each vertex only carries a
 * short A/B/C... letter (its position in the rows array) so points stay
 * identifiable without crowding the diagram; the caller is expected to
 * render the exact percentages and full names as visible text alongside
 * this SVG (the results screen keeps its existing domain score cards for
 * that) - every value is also available programmatically from the same
 * `domains` array the caller already has, for a screen reader or any other
 * semantic representation. The bar fallback carries the same letter as a
 * prefix on its name label, so the two presentations use one consistent
 * identification scheme.
 */
class WPQ_Domain_Radar {

	public const MODE_BARS  = 'bars';
	public const MODE_RADAR = 'radar';

	private const MIN_RADAR_ROWS = 3;
	private const POLYGON_FILL   = '31,58,95'; // Navy, used at low alpha behind the vertices.

	/**
	 * Normalise WPQ_Scoring::build_micro_report()'s 'domains' array into the
	 * chart row model.
	 *
	 * @param array<int, array<string, mixed>> $domains
	 * @return array<int, array{name: string, percent: int, colour: string}>
	 */
	public static function rows_from_domains( array $domains ): array {
		$rows = [];
		foreach ( $domains as $domain ) {
			if ( ! is_array( $domain ) ) {
				continue;
			}
			$name = trim( (string) ( $domain['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}
			$rows[] = [
				'name'    => $name,
				'percent' => max( 0, min( 100, (int) ( $domain['pct'] ?? 0 ) ) ),
				'colour'  => trim( (string) ( $domain['grade_color'] ?? '' ) ) ?: '#9aa3ad',
			];
		}
		return $rows;
	}

	/**
	 * Inline SVG chart. $mode selects the questionnaire's configured
	 * presentation ('bars' or 'radar' - see WPQ_Feature_Flags::
	 * domain_breakdown_visualisation_mode_for_questionnaire()); a radar
	 * request still falls back to bars below MIN_RADAR_ROWS, since a radar
	 * needs at least that many points to read as a shape. Omitting $mode
	 * preserves the original threshold-only behaviour (radar for 3+ domains,
	 * bars otherwise). Returns '' when there is nothing to draw.
	 *
	 * @param array<int, array{name: string, percent: int, colour: string}> $rows
	 */
	public static function render_svg( array $rows, ?string $mode = null ): string {
		if ( empty( $rows ) ) {
			return '';
		}

		if ( self::MODE_BARS === $mode ) {
			return self::svg_bars( $rows );
		}

		return count( $rows ) >= self::MIN_RADAR_ROWS ? self::svg_radar( $rows ) : self::svg_bars( $rows );
	}

	/** @param array<int, array{name: string, percent: int, colour: string}> $rows */
	private static function svg_radar( array $rows ): string {
		$count         = count( $rows );
		$width         = 560;
		$radius        = 182.0;
		$top_margin    = 30;
		$bottom_margin = 40;
		$cx            = $width / 2;
		$cy            = $top_margin + $radius;
		$height        = $cy + $radius + $bottom_margin;

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Domain breakdown radar" class="wpq-radar-svg">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';

		// Concentric guide rings at 25/50/75/100.
		foreach ( [ 25, 50, 75, 100 ] as $ring ) {
			$points = [];
			for ( $i = 0; $i < $count; $i++ ) {
				[ $x, $y ] = self::point( $cx, $cy, $radius * $ring / 100, $i, $count );
				$points[]  = self::coord( $x ) . ',' . self::coord( $y );
			}
			$svg .= '<polygon points="' . implode( ' ', $points ) . '" fill="none" stroke="#e3e6ea" stroke-width="1"/>';
			[ $lx, $ly ] = self::point( $cx, $cy, $radius * $ring / 100, 0, $count );
			$svg        .= '<text x="' . self::coord( $lx + 6 ) . '" y="' . self::coord( $ly + 4 ) . '" font-size="9" fill="#9aa3ad" font-family="Helvetica, Arial, sans-serif">' . $ring . '</text>';
		}

		// Spokes - domain names are not drawn on the chart itself; the
		// caller's own score cards/list state every exact value as text.
		for ( $i = 0; $i < $count; $i++ ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius, $i, $count );
			$svg      .= '<line x1="' . self::coord( $cx ) . '" y1="' . self::coord( $cy ) . '" x2="' . self::coord( $x ) . '" y2="' . self::coord( $y ) . '" stroke="#e3e6ea" stroke-width="1"/>';
		}

		// Data polygon.
		$points = [];
		foreach ( $rows as $i => $row ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$points[]  = self::coord( $x ) . ',' . self::coord( $y );
		}
		$svg .= '<polygon points="' . implode( ' ', $points ) . '" fill="rgba(' . self::POLYGON_FILL . ',0.16)" stroke="rgba(' . self::POLYGON_FILL . ',0.55)" stroke-width="2"/>';

		// Colour-coded vertices with value titles (native SVG tooltip), each
		// carrying an A/B/C... letter so a point can be matched back to its
		// domain without reading full names off the diagram itself.
		foreach ( $rows as $i => $row ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$letter    = self::letter_for_index( $i );
			$svg      .= '<circle cx="' . self::coord( $x ) . '" cy="' . self::coord( $y ) . '" r="6" fill="' . self::escape( $row['colour'] ) . '" stroke="#ffffff" stroke-width="2">'
				. '<title>' . self::escape( $letter . ': ' . $row['name'] . ' - ' . $row['percent'] . '%' ) . '</title></circle>';
			$svg      .= '<text x="' . self::coord( $x + 9 ) . '" y="' . self::coord( $y - 9 ) . '" font-size="11" font-weight="700" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( $letter ) . '</text>';
		}

		$svg .= '</svg>';

		return $svg;
	}

	/** @param array<int, array{name: string, percent: int, colour: string}> $rows */
	private static function svg_bars( array $rows ): string {
		$width    = 560;
		$row_h    = 44;
		$height   = 16 + $row_h * count( $rows );
		$bar_x    = 12;
		$bar_full = $width - 90;

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Domain breakdown" class="wpq-radar-svg">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';

		foreach ( $rows as $i => $row ) {
			$top  = 16 + $i * $row_h;
			$svg .= '<text x="' . $bar_x . '" y="' . ( $top + 12 ) . '" font-size="12" font-weight="600" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( self::letter_for_index( $i ) . ': ' . $row['name'] ) . '</text>';
			$svg .= '<rect x="' . $bar_x . '" y="' . ( $top + 20 ) . '" width="' . $bar_full . '" height="14" rx="7" fill="#eef1f4"/>';
			$svg .= '<rect x="' . $bar_x . '" y="' . ( $top + 20 ) . '" width="' . self::coord( max( 7, $bar_full * $row['percent'] / 100 ) ) . '" height="14" rx="7" fill="' . self::escape( $row['colour'] ) . '"/>';
			$svg .= '<text x="' . ( $bar_x + $bar_full + 10 ) . '" y="' . ( $top + 32 ) . '" font-size="11" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( (string) $row['percent'] . '%' ) . '</text>';
		}

		$svg .= '</svg>';
		return $svg;
	}

	/**
	 * Spreadsheet-style column letters for a 0-based row index (0 => 'A',
	 * 25 => 'Z', 26 => 'AA', ...) so labelling never runs out regardless of
	 * how many domains a questionnaire is configured with.
	 */
	private static function letter_for_index( int $index ): string {
		$index++;
		$letters = '';
		while ( $index > 0 ) {
			$remainder = ( $index - 1 ) % 26;
			$letters   = chr( 65 + $remainder ) . $letters;
			$index     = intdiv( $index - 1, 26 );
		}
		return $letters;
	}

	/** @return array{0: float, 1: float} */
	private static function point( float $cx, float $cy, float $r, int $index, int $count ): array {
		$angle = -M_PI / 2 + 2 * M_PI * $index / $count;
		return [ $cx + $r * cos( $angle ), $cy + $r * sin( $angle ) ];
	}

	private static function coord( float $value ): string {
		return rtrim( rtrim( sprintf( '%.1F', $value ), '0' ), '.' );
	}

	private static function escape( string $value ): string {
		return htmlspecialchars( $value, ENT_QUOTES | ENT_XML1, 'UTF-8' );
	}
}
