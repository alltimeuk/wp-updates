<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var string      $view          '' (lists) | 'form' (composer) | 'enquiry' (detail)
 * @var object|null $enquiry_form  Editing form row, when $view === 'form' and id > 0.
 * @var object|null $enquiry       Enquiry row, when $view === 'enquiry'.
 * @var array       $forms         Forms with enquiry counts.
 * @var array       $enquiries     Recent enquiries.
 */

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Feedback query args are display-only.
$wpq_saved      = isset( $_GET['wpq_saved'] );
$wpq_deleted    = isset( $_GET['wpq_deleted'] );
$wpq_save_error = isset( $_GET['wpq_save_error'] );
// phpcs:enable WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap">

<?php if ( $wpq_saved ) : ?>
	<div class="notice notice-success is-dismissible"><p>Enquiry form saved.</p></div>
<?php endif; ?>
<?php if ( $wpq_deleted ) : ?>
	<div class="notice notice-success is-dismissible"><p>Deleted.</p></div>
<?php endif; ?>
<?php if ( $wpq_save_error ) : ?>
	<div class="notice notice-error is-dismissible"><p>The form could not be saved — a name is required.</p></div>
<?php endif; ?>

<?php if ( 'enquiry' === $view && $enquiry ) :
	$wpq_values = json_decode( (string) ( $enquiry->fields_json ?? '' ), true );
	$wpq_values = is_array( $wpq_values ) ? $wpq_values : [];
	?>
	<h1>Enquiry <?php echo esc_html( (string) $enquiry->ref ); ?></h1>
	<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-enquiries' ) ); ?>">&larr; Back to enquiries</a></p>
	<table class="widefat striped" style="max-width:760px">
		<tbody>
			<tr><th style="width:180px">Form</th><td><?php echo esc_html( (string) ( $enquiry->form_name ?? '' ) ); ?></td></tr>
			<tr><th>Received</th><td><?php echo esc_html( (string) $enquiry->created_at ); ?> UTC</td></tr>
			<tr><th>Name</th><td><?php echo esc_html( (string) $enquiry->contact_name ); ?></td></tr>
			<tr><th>Email</th><td><a href="mailto:<?php echo esc_attr( (string) $enquiry->contact_email ); ?>"><?php echo esc_html( (string) $enquiry->contact_email ); ?></a></td></tr>
			<?php if ( '' !== (string) ( $enquiry->contact_company ?? '' ) ) : ?>
				<tr><th>Company</th><td><?php echo esc_html( (string) $enquiry->contact_company ); ?></td></tr>
			<?php endif; ?>
			<?php if ( '' !== (string) ( $enquiry->contact_phone ?? '' ) ) : ?>
				<tr><th>Phone</th><td><?php echo esc_html( (string) $enquiry->contact_phone ); ?></td></tr>
			<?php endif; ?>
			<tr><th>Consent</th><td><?php echo $enquiry->consent ? 'Given' : 'Not given'; ?></td></tr>
			<?php foreach ( $wpq_values as $wpq_key => $wpq_value ) : ?>
				<tr>
					<th><?php echo esc_html( (string) $wpq_key ); ?></th>
					<td><?php echo esc_html( is_array( $wpq_value ) ? implode( ', ', array_map( 'strval', $wpq_value ) ) : (string) $wpq_value ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px"
		onsubmit="return confirm('Delete this enquiry permanently?');">
		<?php wp_nonce_field( 'wpq_delete_enquiry' ); ?>
		<input type="hidden" name="action" value="wpq_delete_enquiry">
		<input type="hidden" name="enquiry_id" value="<?php echo (int) $enquiry->id; ?>">
		<button type="submit" class="button button-link-delete">Delete enquiry</button>
	</form>

<?php elseif ( 'form' === $view ) :
	$wpq_editing = is_object( $enquiry_form );
	$wpq_fields  = $wpq_editing ? WPQ_Enquiry::decode_field_definitions( $enquiry_form->fields_json ?? null ) : [];
	?>
	<h1><?php echo $wpq_editing ? 'Edit enquiry form' : 'New enquiry form'; ?></h1>
	<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-enquiries' ) ); ?>">&larr; Back to enquiries</a></p>

	<?php if ( $wpq_editing ) : ?>
		<p>Shortcode: <code>[wpq_enquiry ref="<?php echo esc_attr( (string) $enquiry_form->ref ); ?>"]</code></p>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wpq-enquiry-form-editor">
		<?php wp_nonce_field( 'wpq_save_enquiry_form' ); ?>
		<input type="hidden" name="action" value="wpq_save_enquiry_form">
		<input type="hidden" name="form_id" value="<?php echo $wpq_editing ? (int) $enquiry_form->id : 0; ?>">
		<input type="hidden" name="fields_json" id="wpq-fields-json" value="">

		<table class="form-table">
			<tr>
				<th><label for="wpq-form-name">Name</label></th>
				<td><input type="text" id="wpq-form-name" name="form_name" class="regular-text" required
					value="<?php echo esc_attr( $wpq_editing ? (string) $enquiry_form->name : '' ); ?>"></td>
			</tr>
			<tr>
				<th><label for="wpq-form-description">Description</label></th>
				<td><textarea id="wpq-form-description" name="form_description" class="large-text" rows="2"><?php echo esc_textarea( $wpq_editing ? (string) $enquiry_form->description : '' ); ?></textarea>
				<p class="description">Shown above the form on the public page.</p></td>
			</tr>
			<tr>
				<th><label for="wpq-form-status">Status</label></th>
				<td>
					<select id="wpq-form-status" name="form_status">
						<option value="draft" <?php selected( $wpq_editing ? (string) $enquiry_form->status : 'draft', 'draft' ); ?>>Draft — not publicly available</option>
						<option value="published" <?php selected( $wpq_editing ? (string) $enquiry_form->status : '', 'published' ); ?>>Published</option>
					</select>
				</td>
			</tr>
			<tr>
				<th><label for="wpq-form-mail-enabled">Email delivery</label></th>
				<td>
					<select id="wpq-form-mail-enabled" name="form_mail_enabled">
						<option value="inherit" <?php selected( $wpq_editing ? (string) $enquiry_form->mail_enabled : 'inherit', 'inherit' ); ?>>Inherit global setting</option>
						<option value="enabled" <?php selected( $wpq_editing ? (string) $enquiry_form->mail_enabled : '', 'enabled' ); ?>>Enabled</option>
						<option value="disabled" <?php selected( $wpq_editing ? (string) $enquiry_form->mail_enabled : '', 'disabled' ); ?>>Disabled — store enquiries, send no email</option>
					</select>
				</td>
			</tr>
			<tr>
				<th><label for="wpq-form-notify-email">Notify email</label></th>
				<td><input type="email" id="wpq-form-notify-email" name="form_notify_email" class="regular-text"
					value="<?php echo esc_attr( $wpq_editing ? (string) ( $enquiry_form->notify_email ?? '' ) : '' ); ?>"
					placeholder="<?php echo esc_attr( (string) get_option( 'admin_email', '' ) ); ?>">
				<p class="description">Where new-enquiry notifications go. Leave blank for the site admin address.</p></td>
			</tr>
			<tr>
				<th><label for="wpq-form-send-ack">Acknowledge the sender</label></th>
				<td>
					<select id="wpq-form-send-ack" name="form_send_ack">
						<option value="no" <?php selected( $wpq_editing ? (string) $enquiry_form->send_ack : 'no', 'no' ); ?>>No</option>
						<option value="yes" <?php selected( $wpq_editing ? (string) $enquiry_form->send_ack : '', 'yes' ); ?>>Yes — email the contact a receipt</option>
					</select>
				</td>
			</tr>
		</table>

		<h2>Fields</h2>
		<p class="description" style="max-width:56em">
			Name, email, company, phone and consent are always collected. Compose any additional fields below;
			options apply to Select and Checkboxes fields (one per line).
		</p>
		<table class="widefat" id="wpq-fields-table" style="max-width:900px">
			<thead>
				<tr><th style="width:30%">Label</th><th style="width:15%">Type</th><th style="width:10%">Required</th><th>Options (one per line)</th><th style="width:60px"></th></tr>
			</thead>
			<tbody id="wpq-fields-body"></tbody>
		</table>
		<p><button type="button" class="button" id="wpq-add-field">Add field</button></p>

		<p class="submit">
			<button type="submit" class="button button-primary">Save enquiry form</button>
		</p>
	</form>

	<?php if ( $wpq_editing ) : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			onsubmit="return confirm('Delete this form AND all enquiries received through it?');">
			<?php wp_nonce_field( 'wpq_delete_enquiry_form' ); ?>
			<input type="hidden" name="action" value="wpq_delete_enquiry_form">
			<input type="hidden" name="form_id" value="<?php echo (int) $enquiry_form->id; ?>">
			<button type="submit" class="button button-link-delete">Delete form and its enquiries</button>
		</form>
	<?php endif; ?>

	<script>
	(function () {
		'use strict';
		var initial = <?php echo wp_json_encode( $wpq_fields ); ?>;
		var body    = document.getElementById('wpq-fields-body');
		var editor  = document.getElementById('wpq-enquiry-form-editor');

		function addRow(field) {
			field = field || { key: '', label: '', type: 'text', required: false, options: [] };
			var tr = document.createElement('tr');
			tr.innerHTML =
				'<td><input type="text" class="wpq-f-label regular-text" style="width:100%" value=""></td>' +
				'<td><select class="wpq-f-type">' +
					'<option value="text">Text</option><option value="textarea">Text area</option>' +
					'<option value="select">Select</option><option value="checkbox">Checkboxes</option>' +
				'</select></td>' +
				'<td style="text-align:center"><input type="checkbox" class="wpq-f-required"></td>' +
				'<td><textarea class="wpq-f-options" rows="2" style="width:100%"></textarea></td>' +
				'<td><button type="button" class="button-link-delete wpq-f-remove">Remove</button></td>';
			tr.querySelector('.wpq-f-label').value      = field.label;
			tr.querySelector('.wpq-f-type').value       = field.type;
			tr.querySelector('.wpq-f-required').checked = !!field.required;
			tr.querySelector('.wpq-f-options').value    = (field.options || []).join('\n');
			tr.dataset.key = field.key || '';
			tr.querySelector('.wpq-f-remove').addEventListener('click', function () { tr.remove(); });
			body.appendChild(tr);
		}

		initial.forEach(addRow);
		document.getElementById('wpq-add-field').addEventListener('click', function () { addRow(); });

		editor.addEventListener('submit', function () {
			var fields = [];
			body.querySelectorAll('tr').forEach(function (tr) {
				fields.push({
					key:      tr.dataset.key || '',
					label:    tr.querySelector('.wpq-f-label').value,
					type:     tr.querySelector('.wpq-f-type').value,
					required: tr.querySelector('.wpq-f-required').checked,
					options:  tr.querySelector('.wpq-f-options').value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean)
				});
			});
			document.getElementById('wpq-fields-json').value = JSON.stringify(fields);
		});
	})();
	</script>

<?php else : ?>
	<h1>Enquiries
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-enquiries&view=form' ) ); ?>" class="page-title-action">New enquiry form</a>
	</h1>

	<h2>Forms (<?php echo count( $forms ); ?>)</h2>
	<?php if ( empty( $forms ) ) : ?>
		<p>No enquiry forms yet — create one, publish it, and embed it with its shortcode.</p>
	<?php else : ?>
	<table class="widefat striped" style="max-width:980px">
		<thead><tr><th>Name</th><th>Shortcode</th><th>Status</th><th>Email delivery</th><th>Enquiries</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $forms as $wpq_form_row ) : ?>
			<tr>
				<td><strong><?php echo esc_html( (string) $wpq_form_row->name ); ?></strong></td>
				<td><code>[wpq_enquiry ref="<?php echo esc_attr( (string) $wpq_form_row->ref ); ?>"]</code></td>
				<td><?php echo esc_html( (string) $wpq_form_row->status ); ?></td>
				<td><?php echo esc_html( (string) $wpq_form_row->mail_enabled ); ?></td>
				<td><?php echo (int) ( $wpq_form_row->enquiry_count ?? 0 ); ?></td>
				<td><a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-enquiries&view=form&id=' . (int) $wpq_form_row->id ) ); ?>">Edit</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>

	<h2 style="margin-top:24px">Received enquiries (<?php echo count( $enquiries ); ?>)</h2>
	<?php if ( empty( $enquiries ) ) : ?>
		<p>No enquiries received yet.</p>
	<?php else : ?>
	<table class="widefat striped" style="max-width:980px">
		<thead><tr><th>Ref</th><th>Form</th><th>Name</th><th>Email</th><th>Received (UTC)</th><th>Status</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $enquiries as $wpq_enquiry_row ) : ?>
			<tr>
				<td><code><?php echo esc_html( (string) $wpq_enquiry_row->ref ); ?></code></td>
				<td><?php echo esc_html( (string) ( $wpq_enquiry_row->form_name ?? '' ) ); ?></td>
				<td><?php echo esc_html( (string) $wpq_enquiry_row->contact_name ); ?></td>
				<td><?php echo esc_html( (string) $wpq_enquiry_row->contact_email ); ?></td>
				<td><?php echo esc_html( (string) $wpq_enquiry_row->created_at ); ?></td>
				<td><?php echo 'new' === (string) $wpq_enquiry_row->status ? '<strong>New</strong>' : 'Seen'; ?></td>
				<td><a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-enquiries&view=enquiry&id=' . (int) $wpq_enquiry_row->id ) ); ?>">View</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
<?php endif; ?>
</div>
