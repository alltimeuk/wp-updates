<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Shortcode {

	public static function register(): void {
		add_shortcode( 'wpq_questionnaire', [ self::class, 'render' ] );
		add_shortcode( 'wpq_assessment',    [ self::class, 'render' ] );
		add_shortcode( 'wpq_assessments',   [ self::class, 'render' ] );
		add_shortcode( 'wpq_product',       [ self::class, 'render' ] );
		add_shortcode( 'wpq_title',       [ self::class, 'render_title' ] );
		add_shortcode( 'wpq_description', [ self::class, 'render_description' ] );
		add_shortcode( 'wpq_questions',   [ self::class, 'render_questions' ] );
		add_shortcode( 'wpq_domains',     [ self::class, 'render_domains' ] );
		add_shortcode( 'wpq_time',        [ self::class, 'render_minutes' ] );
		add_shortcode( 'wpq_estimate',    [ self::class, 'render_estimate' ] );
		add_shortcode( 'wpq_minutes',     [ self::class, 'render_minutes' ] );
		add_shortcode( 'wpq_submissions', [ self::class, 'render_submissions' ] );
		add_shortcode( 'wpq_status',      [ self::class, 'render_status' ] );
		add_shortcode( 'wpq_enquiry',     [ self::class, 'render_enquiry' ] );
	}

	public static function enqueue_assets(): void {
		wp_enqueue_style(
			'wpq-assessment',
			WPQ_PLUGIN_URL . 'public/assets/assessment.css',
			[],
			WPQ_VERSION
		);
		wp_enqueue_script(
			'wpq-assessment',
			WPQ_PLUGIN_URL . 'public/assets/assessment.js',
			[],
			WPQ_VERSION,
			true
		);
	}

	public static function render( array $atts ): string {
		$atts = shortcode_atts( [
			'ref'          => '',
			'show_pricing' => 'true',
			'layout'       => 'wide',
		], $atts, 'wpq_questionnaire' );

		$ref = strtoupper( sanitize_text_field( $atts['ref'] ) );
		if ( ! $ref ) {
			return '<p class="wpq-error">Questionnaire reference is required. Usage: [wpq_questionnaire ref="CS-01"]</p>';
		}

		$questionnaire = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $questionnaire ) {
			return '<p class="wpq-error">Questionnaire not found.</p>';
		}

		self::enqueue_assets();
		$asset_fallback = self::render_asset_fallback_tags();

		// A category or domain Call to Action can embed [wpq_enquiry] and its
		// form only exists in the DOM once the results screen inserts the CTA
		// HTML after the assessment completes - long after this shortcode's
		// own output (and any wp_footer script tags) has already been sent.
		// Load the enquiry form's behaviour unconditionally so it's ready
		// whenever that happens, since a CTA's content isn't known here.
		wp_enqueue_script( 'wpq-enquiry', WPQ_PLUGIN_URL . 'public/assets/enquiry.js', [], WPQ_VERSION, true );

		$grade_stylesheet_url = class_exists( 'WPQ_Questionnaire_Style_Generator' )
			? WPQ_Questionnaire_Style_Generator::ensure_stylesheet_url( (int) $questionnaire->id )
			: null;
		if ( $grade_stylesheet_url ) {
			wp_enqueue_style( 'wpq-grades-' . (int) $questionnaire->id, $grade_stylesheet_url, [ 'wpq-assessment' ], null );
		}

		$layout = sanitize_key( (string) $atts['layout'] );
		if ( ! in_array( $layout, [ 'wide', 'contained' ], true ) ) {
			$layout = 'wide';
		}

		$wpq_turnstile_required = class_exists( 'WPQ_Turnstile' ) && WPQ_Turnstile::required_for_questionnaire( $questionnaire );
		if ( $wpq_turnstile_required ) {
			wp_enqueue_script( 'wpq-turnstile-api', WPQ_Turnstile::SCRIPT_URL, [], null, [ 'strategy' => 'async', 'in_footer' => true ] );
		}

		$wpq_instance_config = [
			'restUrl'                => esc_url( rest_url( WPQ_REST_NAMESPACE . '/' ) ),
			'ref'                    => esc_js( $ref ),
			'showPricing'            => filter_var( $atts['show_pricing'], FILTER_VALIDATE_BOOLEAN ),
			'turnstileEnabled'       => $wpq_turnstile_required,
			'turnstileSiteKey'       => $wpq_turnstile_required ? WPQ_Turnstile::site_key() : '',
			'remediationPlanEnabled' => class_exists( 'WPQ_Remediation_Plan' )
				&& WPQ_Remediation_Plan::is_configured()
				&& ( ! class_exists( 'WPQ_Feature_Flags' ) || WPQ_Feature_Flags::remediation_plan_download_enabled_for_questionnaire( $questionnaire ) )
				&& ( ! class_exists( 'WPQ_Remediation_Delivery' ) || [] !== WPQ_Remediation_Delivery::channels_for_questionnaire( $questionnaire ) ),
			'remediationDeliveryEmailOnly' => class_exists( 'WPQ_Remediation_Delivery' )
				&& ! WPQ_Remediation_Delivery::channel_enabled( $questionnaire, WPQ_Remediation_Delivery::CHANNEL_RESULTS_DOWNLOAD )
				&& WPQ_Remediation_Delivery::channel_enabled( $questionnaire, WPQ_Remediation_Delivery::CHANNEL_EMAIL ),
		];

		ob_start();
		include WPQ_PLUGIN_DIR . 'public/views/assessment-shortcode.php';
		return $asset_fallback . ob_get_clean();
	}

	/**
	 * [wpq_enquiry ref="EF-XXXXXX"] - renders a composed enquiry form.
	 *
	 * collapsed="true" starts the form collapsed behind a reveal button
	 * (collapsed_text) instead of showing it in full - meant for embedding
	 * inside Call to Action body copy, where the full form up front would be
	 * too heavy. layout mirrors [wpq_questionnaire]'s wide/contained toggle.
	 */
	public static function render_enquiry( array $atts ): string {
		$atts = shortcode_atts( [
			'ref'            => '',
			'collapsed'      => 'false',
			'collapsed_text' => 'Enquire now',
			'layout'         => 'wide',
		], $atts, 'wpq_enquiry' );

		$ref = sanitize_text_field( (string) $atts['ref'] );
		if ( '' === $ref ) {
			return '<p class="wpq-error">Enquiry form reference is required. Usage: [wpq_enquiry ref="EF-XXXXXX"]</p>';
		}

		$form = WPQ_Database::get_enquiry_form_by_ref( $ref );
		if ( ! $form || 'published' !== (string) $form->status ) {
			return '<p class="wpq-error">Enquiry form not found.</p>';
		}

		wp_enqueue_style( 'wpq-assessment', WPQ_PLUGIN_URL . 'public/assets/assessment.css', [], WPQ_VERSION );
		wp_enqueue_script( 'wpq-enquiry', WPQ_PLUGIN_URL . 'public/assets/enquiry.js', [], WPQ_VERSION, true );

		$wpq_turnstile_enabled  = class_exists( 'WPQ_Turnstile' ) && WPQ_Turnstile::required_for_form( $form );
		$wpq_turnstile_site_key = $wpq_turnstile_enabled ? WPQ_Turnstile::site_key() : '';
		if ( $wpq_turnstile_enabled ) {
			wp_enqueue_script( 'wpq-turnstile-api', WPQ_Turnstile::SCRIPT_URL, [], null, [ 'strategy' => 'async', 'in_footer' => true ] );
		}

		$wpq_enquiry_rest_url = esc_url( rest_url( WPQ_REST_NAMESPACE . '/' ) );
		$wpq_enquiry_fields   = WPQ_Enquiry::decode_field_definitions( $form->fields_json ?? null );
		$wpq_enquiry_collapsed = filter_var( $atts['collapsed'], FILTER_VALIDATE_BOOLEAN );
		$wpq_enquiry_collapsed_text = sanitize_text_field( (string) $atts['collapsed_text'] );
		if ( '' === $wpq_enquiry_collapsed_text ) {
			$wpq_enquiry_collapsed_text = 'Enquire now';
		}

		$wpq_enquiry_layout = sanitize_key( (string) $atts['layout'] );
		if ( ! in_array( $wpq_enquiry_layout, [ 'wide', 'contained' ], true ) ) {
			$wpq_enquiry_layout = 'wide';
		}

		ob_start();
		include WPQ_PLUGIN_DIR . 'public/views/enquiry-shortcode.php';
		return (string) ob_get_clean();
	}

	private static function render_asset_fallback_tags(): string {
		if ( function_exists( 'did_action' ) && did_action( 'wp_head' ) < 1 ) {
			return '';
		}
		if ( function_exists( 'wp_style_is' ) && wp_style_is( 'wpq-assessment', 'done' ) ) {
			return '';
		}

		$href = esc_url( WPQ_PLUGIN_URL . 'public/assets/assessment.css?ver=' . rawurlencode( WPQ_VERSION ) );

		// No inline <style> fallback here (CSP: style-src-elem) - .wpq-hidden is
		// defined in assessment.css itself, so the only cost of relying on the
		// <link> alone is a brief flash on the rare late/AJAX-rendered shortcode
		// path, until the stylesheet finishes loading.
		// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Fallback for shortcode renders that happen after wp_head.
		return '<link rel="stylesheet" id="wpq-assessment-late-css" href="' . $href . '" media="all" />' . "\n";
	}

	public static function render_title( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_title' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		return $q ? esc_html( $q->name ) : '';
	}

	public static function render_description( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_description' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		return $q ? esc_html( $q->description ) : '';
	}

	public static function render_questions( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_questions' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		return (string) WPQ_Database::count_questions_for_questionnaire( (int) $q->id );
	}

	public static function render_domains( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_domains' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		return (string) count( WPQ_Database::get_domains( (int) $q->id ) );
	}

	public static function render_estimate( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_estimate' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		$count   = WPQ_Database::count_questions_for_questionnaire( (int) $q->id );
		$minutes = (int) ceil( $count * 42 / 60 );
		return $minutes . ' ' . ( $minutes === 1 ? 'minute' : 'minutes' );
	}

	public static function render_minutes( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_minutes' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		$count = WPQ_Database::count_questions_for_questionnaire( (int) $q->id );
		return (string) (int) ceil( $count * 42 / 60 );
	}

	public static function render_submissions( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_submissions' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		return (string) WPQ_Database::count_submissions_for_questionnaire( (int) $q->id );
	}

	public static function render_status( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_status' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_any_status_by_ref( $ref );
		return $q ? esc_html( (string) $q->status ) : '';
	}

	private static function resolve_ref( array $raw_atts, string $tag ): string {
		$atts = shortcode_atts( [ 'ref' => '' ], $raw_atts, $tag );
		return strtoupper( sanitize_text_field( $atts['ref'] ) );
	}
}
