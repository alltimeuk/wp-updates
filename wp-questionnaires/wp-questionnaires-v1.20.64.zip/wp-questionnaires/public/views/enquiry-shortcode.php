<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var object $form                        The enquiry form row (published).
 * @var array  $wpq_enquiry_fields           Sanitised field definitions.
 * @var bool   $wpq_turnstile_enabled        Whether Turnstile is required for this form.
 * @var string $wpq_turnstile_site_key       Cloudflare Turnstile site key, when enabled.
 * @var string $wpq_enquiry_rest_url         Base REST URL, read by enquiry.js instead of a
 *                                           localized inline <script> (CSP: script-src-elem).
 * @var bool   $wpq_enquiry_collapsed        Start collapsed behind a reveal button.
 * @var string $wpq_enquiry_collapsed_text   Reveal button label, when collapsed.
 * @var string $wpq_enquiry_layout           'wide' or 'contained' - mirrors [wpq_questionnaire].
 */
$wpq_enquiry_rest_url = $wpq_enquiry_rest_url ?? '';
?>
<div class="wpq-root wpq-enquiry-root wpq-wrap wpq-layout-<?php echo esc_attr( $wpq_enquiry_layout ); ?>" data-wpq-enquiry-ref="<?php echo esc_attr( (string) $form->ref ); ?>" data-wpq-rest-url="<?php echo esc_attr( $wpq_enquiry_rest_url ); ?>">
  <?php if ( $wpq_enquiry_collapsed ) : ?>
    <button type="button" class="wpq-btn wpq-btn-primary wpq-enquiry-reveal" aria-expanded="false"><?php echo esc_html( $wpq_enquiry_collapsed_text ); ?></button>
  <?php endif; ?>
  <div class="wpq-step<?php echo $wpq_enquiry_collapsed ? ' wpq-hidden' : ''; ?>">
    <div class="wpq-step-header">
      <h2><?php echo esc_html( (string) $form->name ); ?></h2>
      <?php if ( '' !== (string) $form->description ) : ?>
        <p class="wpq-desc"><?php echo esc_html( (string) $form->description ); ?></p>
      <?php endif; ?>
    </div>

    <form class="wpq-enquiry-form" novalidate>
      <div class="wpq-form-grid">
        <label>
          Name <span aria-hidden="true">*</span>
          <input type="text" name="contact_name" required maxlength="200" autocomplete="name">
        </label>
        <label>
          Email <span aria-hidden="true">*</span>
          <input type="email" name="contact_email" required maxlength="190" autocomplete="email">
        </label>
        <label>
          Company
          <input type="text" name="contact_company" maxlength="200" autocomplete="organization">
        </label>
        <label>
          Phone
          <input type="tel" name="contact_phone" maxlength="50" autocomplete="tel">
        </label>
      </div>

      <?php foreach ( $wpq_enquiry_fields as $wpq_field ) : ?>
        <div class="wpq-enquiry-field" data-field-key="<?php echo esc_attr( $wpq_field['key'] ); ?>" data-field-type="<?php echo esc_attr( $wpq_field['type'] ); ?>">
          <?php if ( 'checkbox' === $wpq_field['type'] ) : ?>
            <fieldset>
              <legend><?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?></legend>
              <?php foreach ( $wpq_field['options'] as $wpq_option ) : ?>
                <label class="wpq-checkbox-label">
                  <input type="checkbox" value="<?php echo esc_attr( $wpq_option ); ?>">
                  <?php echo esc_html( $wpq_option ); ?>
                </label>
              <?php endforeach; ?>
            </fieldset>
          <?php elseif ( 'select' === $wpq_field['type'] ) : ?>
            <label>
              <?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?>
              <select <?php echo $wpq_field['required'] ? 'required' : ''; ?>>
                <option value="">- Please choose -</option>
                <?php foreach ( $wpq_field['options'] as $wpq_option ) : ?>
                  <option value="<?php echo esc_attr( $wpq_option ); ?>"><?php echo esc_html( $wpq_option ); ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          <?php elseif ( 'textarea' === $wpq_field['type'] ) : ?>
            <label>
              <?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?>
              <textarea rows="4" maxlength="5000" <?php echo $wpq_field['required'] ? 'required' : ''; ?>></textarea>
            </label>
          <?php else : ?>
            <label>
              <?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?>
              <input type="text" maxlength="500" <?php echo $wpq_field['required'] ? 'required' : ''; ?>>
            </label>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>

      <!-- Honeypot - hidden from humans; a bot that fills it is silently discarded -->
      <div class="wpq-hp" aria-hidden="true">
        <label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
      </div>

      <div class="wpq-consent-row">
        <label class="wpq-consent-label">
          <input type="checkbox" name="consent" required>
          <span><?php
            $wpq_privacy_url = get_privacy_policy_url();
            if ( $wpq_privacy_url ) {
              printf(
                'I have read and accept the <a href="%s" target="_blank" rel="noopener noreferrer">privacy notice</a>.',
                esc_url( $wpq_privacy_url )
              );
            } else {
              echo 'I accept that my details will be used to follow up on this enquiry and manage the service.';
            }
          ?></span>
        </label>
      </div>

      <?php if ( ! empty( $wpq_turnstile_enabled ) ) : ?>
        <div class="cf-turnstile" data-sitekey="<?php echo esc_attr( $wpq_turnstile_site_key ); ?>"></div>
      <?php endif; ?>

      <div class="wpq-form-footer">
        <p class="wpq-privacy-note">We use your details to follow up on your enquiry, and manage our service.</p>
        <button type="submit" class="wpq-btn wpq-btn-primary">Send enquiry</button>
      </div>
      <p class="wpq-enquiry-status" role="status" aria-live="polite"></p>
    </form>

    <div class="wpq-enquiry-done wpq-hidden">
      <h3>Thank you</h3>
      <p>Your enquiry has been received<span class="wpq-enquiry-done-ref"></span>. We will be in touch.</p>
    </div>
  </div>
</div>
