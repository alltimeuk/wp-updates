<?php if ( ! defined( 'ABSPATH' ) ) exit;
$checkout_readiness = $checkout_readiness ?? [
	'checkout_enabled'        => false,
	'publishable_key_present' => false,
	'secret_key_present'      => false,
	'webhook_secret_present'  => false,
	'publishable_key_valid'   => false,
	'publishable_key_source'  => 'none',
	'secret_key_valid'        => false,
	'secret_key_source'       => 'none',
	'webhook_secret_valid'    => false,
	'webhook_secret_source'   => 'none',
	'active_product_count'    => 0,
	'priced_product_count'    => 0,
	'checkout_route_registered' => false,
	'webhook_route_registered' => false,
	'report_delivery_route_registered' => false,
	'checkout_route_status' => 'feature_gated',
	'webhook_route_status' => 'feature_gated',
	'report_delivery_route_status' => 'feature_gated',
	'report_template_available' => false,
	'report_renderer_available' => false,
	'report_storage_delivery_configured' => false,
	'report_storage_path' => '',
	'report_storage_path_available' => false,
	'report_storage_writable' => false,
	'report_storage_creatable' => false,
	'report_storage_index_guard_present' => false,
	'report_storage_htaccess_guard_present' => false,
	'atomic_report_token_support' => false,
	'stripe_api_initialised' => false,
	'stripe_library_available' => false,
	'dompdf_library_available' => false,
	'readiness_status'      => 'configuration_missing',
	'production_ready'        => false,
];
/** @var array{checkout_enabled:bool, publishable_key_present:bool, publishable_key_valid:bool, publishable_key_source:string, secret_key_present:bool, secret_key_valid:bool, secret_key_source:string, webhook_secret_present:bool, webhook_secret_valid:bool, webhook_secret_source:string, active_product_count:int, priced_product_count:int, checkout_route_registered:bool, webhook_route_registered:bool, report_delivery_route_registered:bool, checkout_route_status:string, webhook_route_status:string, report_delivery_route_status:string, report_template_available:bool, report_renderer_available:bool, report_storage_delivery_configured:bool, report_storage_path:string, report_storage_path_available:bool, report_storage_writable:bool, report_storage_creatable:bool, report_storage_index_guard_present:bool, report_storage_htaccess_guard_present:bool, atomic_report_token_support:bool, stripe_api_initialised:bool, stripe_library_available:bool, dompdf_library_available:bool, readiness_status:string, production_ready:bool} $checkout_readiness */
$migration_diagnostics = isset( $migration_diagnostics ) && is_array( $migration_diagnostics ) ? $migration_diagnostics : [
	'installed_db_version'    => get_option( 'wpq_db_version', '0' ),
	'target_db_version'       => WPQ_DB_VERSION,
	'last_migration_run'      => '',
	'last_migration_error'    => '',
	'last_migration_errors'   => [],
	'expired_session_count'   => 0,
	'table_health'            => [],
	'strict_schema_health'     => [],
];
/** @var array{installed_db_version:string, target_db_version:string, last_migration_run:string, last_migration_error:string, last_migration_errors:array<int, string>, expired_session_count:int, table_health:array<string, array{exists:bool, missing_columns:array<int, string>}>, strict_schema_health:array<string, array<string, array{ok:bool, message:string}>>} $migration_diagnostics */
/** @var array<string, string> $stripe_save_feedback */
$stripe_save_feedback = $stripe_save_feedback ?? [];
/** @var array<int, object> $categories */
$categories = $categories ?? [];
$stripe_key_status = static function ( bool $present, bool $valid ): string {
	if ( ! $present ) {
		return 'Missing';
	}
	return $valid ? 'Valid' : 'Invalid format';
};
$stripe_key_source = static fn( string $source ): string => $source === 'none' ? 'No source configured.' : 'Source: ' . $source . '.';
$route_status = static fn( bool $implemented ): string => $implemented ? 'Implemented' : 'Feature Gated';
?>
<div class="wrap wpq-admin-wrap">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <h1 style="margin:0;">WP Questionnaires - Settings</h1>
    <div style="display:flex;align-items:center;gap:6px;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="button" title="Import settings">&#8593; Import</a>
      <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=settings' ), 'wpq_export_settings' ) ); ?>" class="button" title="Export settings">&#8595; Export</a>
    </div>
  </div>

  <?php settings_errors( 'wpq_settings' ); ?>

  <h2 class="nav-tab-wrapper wpq-nav-tabs">
    <a href="#" class="nav-tab nav-tab-active" data-tab="stripe">Stripe</a>
    <a href="#" class="nav-tab" data-tab="halopsa">HaloPSA API</a>
    <a href="#" class="nav-tab" data-tab="categories">Categories</a>
    <a href="#" class="nav-tab" data-tab="shortcodes">Shortcodes</a>
    <a href="#" class="nav-tab" data-tab="results">Results Screen</a>
    <a href="#" class="nav-tab" data-tab="ai">AI</a>
    <a href="#" class="nav-tab" data-tab="mail">Mail</a>
    <a href="#" class="nav-tab" data-tab="turnstile">Turnstile</a>
    <a href="#" class="nav-tab" data-tab="diagnostics">Diagnostics</a>
    <a href="#" class="nav-tab" data-tab="advanced">Advanced</a>
    <a href="#" class="nav-tab" data-tab="readiness">Readiness</a>
  </h2>

  <form method="post">
    <?php wp_nonce_field( 'wpq_settings', 'wpq_settings_nonce' ); ?>
    <?php
    // Seed the section tracker with the tab that was just saved (if any) so
    // the page reopens on the same tab after a POST round-trip.
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Display-only tab restore; the nonce was verified before any option writes.
    $wpq_active_section = sanitize_key( (string) ( $_POST['wpq_settings_section'] ?? 'stripe' ) );
    ?>
    <input type="hidden" id="wpq-settings-section" name="wpq_settings_section" value="<?php echo esc_attr( '' !== $wpq_active_section ? $wpq_active_section : 'stripe' ); ?>">

    <!-- ================================================================ -->
    <!-- Tab: Stripe                                                       -->
    <!-- ================================================================ -->
    <div id="tab-stripe" class="wpq-tab-panel">
      <h3>Stripe Configuration</h3>
      <?php if ( $checkout_readiness['production_ready'] ) : ?>
        <div class="notice notice-success inline" style="margin:0 0 16px;padding:8px 12px;">
          <p><strong>Checkout production readiness: READY.</strong> Configuration, routes, and libraries are present.</p>
        </div>
      <?php elseif ( $checkout_readiness['readiness_status'] === 'feature_disabled' ) : ?>
        <div class="notice notice-warning inline" style="margin:0 0 16px;padding:8px 12px;">
          <p><strong>Checkout production readiness: INTENTIONALLY DISABLED.</strong> Checkout is Feature Gated while <code>WPQ_CHECKOUT_ENABLED</code> is false.</p>
        </div>
      <?php elseif ( $checkout_readiness['readiness_status'] === 'implementation_incomplete' ) : ?>
        <div class="notice notice-error inline" style="margin:0 0 16px;padding:8px 12px;">
          <p><strong>Checkout production readiness: IMPLEMENTATION INCOMPLETE.</strong> Checkout, webhook, and report-delivery handlers are not all implemented yet.</p>
        </div>
      <?php else : ?>
        <div class="notice notice-error inline" style="margin:0 0 16px;padding:8px 12px;">
          <p><strong>Checkout production readiness: CONFIGURATION INCOMPLETE.</strong> Do not enable paid checkout until every readiness check below passes.</p>
        </div>
      <?php endif; ?>
      <?php if ( ! empty( $checkout_readiness['checkout_enabled'] ) ) : ?>
        <div class="notice notice-success inline" style="margin:0 0 16px;padding:8px 12px;">
          <p><strong>Checkout feature gate: ON.</strong> Active products and checkout CTAs may be visible once every readiness check passes.</p>
        </div>
      <?php else : ?>
        <div class="notice notice-warning inline" style="margin:0 0 16px;padding:8px 12px;">
          <p><strong>Checkout feature gate: OFF.</strong> Keys saved here will be used when checkout is enabled. No checkout CTAs are shown to users right now.</p>
        </div>
      <?php endif; ?>
      <?php if ( ! empty( $checkout_readiness['checkout_constant_controlled'] ) ) : ?>
        <p class="description">Checkout is controlled by <code>WPQ_CHECKOUT_ENABLED</code> in PHP configuration. The database setting below is ignored while that constant is defined.</p>
      <?php else : ?>
        <p class="description">Checkout is controlled by the database setting below because <code>WPQ_CHECKOUT_ENABLED</code> is not defined in PHP configuration.</p>
      <?php endif; ?>

      <table class="widefat wpq-readiness-table" style="max-width:760px;margin:16px 0;">
        <tbody>
          <tr>
            <td style="width:140px;"><?php echo $checkout_readiness['checkout_enabled'] ? esc_html( 'Enabled' ) : esc_html( 'Disabled' ); ?></td>
            <td><strong>Checkout feature flag</strong></td>
            <td class="description">Controls whether public paid product CTAs can appear.</td>
          </tr>
          <tr>
            <td><?php echo esc_html( $stripe_key_status( $checkout_readiness['publishable_key_present'], $checkout_readiness['publishable_key_valid'] ) ); ?></td>
            <td><strong>Stripe publishable key</strong></td>
            <td class="description">Required by the browser checkout flow. <?php echo esc_html( $stripe_key_source( $checkout_readiness['publishable_key_source'] ) ); ?></td>
          </tr>
          <tr>
            <td><?php echo esc_html( $stripe_key_status( $checkout_readiness['secret_key_present'], $checkout_readiness['secret_key_valid'] ) ); ?></td>
            <td><strong>Stripe secret key</strong></td>
            <td class="description">Required by server-side Stripe calls. <?php echo esc_html( $stripe_key_source( $checkout_readiness['secret_key_source'] ) ); ?></td>
          </tr>
          <tr>
            <td><?php echo esc_html( $stripe_key_status( $checkout_readiness['webhook_secret_present'], $checkout_readiness['webhook_secret_valid'] ) ); ?></td>
            <td><strong>Stripe webhook secret</strong></td>
            <td class="description">Required before webhook events can be trusted. <?php echo esc_html( $stripe_key_source( $checkout_readiness['webhook_secret_source'] ) ); ?></td>
          </tr>
          <tr>
            <td><?php echo esc_html( (string) $checkout_readiness['active_product_count'] ); ?></td>
            <td><strong>Active products</strong></td>
            <td class="description"><?php echo esc_html( (string) $checkout_readiness['priced_product_count'] ); ?> active product(s) have a Stripe Price ID.</td>
          </tr>
          <tr>
            <td><?php echo esc_html( $route_status( $checkout_readiness['checkout_route_registered'] ) ); ?></td>
            <td><strong>Checkout route</strong></td>
            <td class="description">Required endpoint: <code>/<?php echo esc_html( WPQ_REST_NAMESPACE ); ?>/checkout</code>.</td>
          </tr>
          <tr>
            <td><?php echo esc_html( $route_status( $checkout_readiness['webhook_route_registered'] ) ); ?></td>
            <td><strong>Stripe webhook route</strong></td>
            <td class="description">Required endpoint: <code>/<?php echo esc_html( WPQ_REST_NAMESPACE ); ?>/stripe/webhook</code>.</td>
          </tr>
          <tr>
            <td><?php echo esc_html( $route_status( $checkout_readiness['report_delivery_route_registered'] ) ); ?></td>
            <td><strong>Report delivery route</strong></td>
            <td class="description">Required endpoint: <code>/<?php echo esc_html( WPQ_REST_NAMESPACE ); ?>/reports/{id}</code>.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['stripe_library_available'] ? esc_html( 'Available' ) : esc_html( 'Missing' ); ?></td>
            <td><strong>Stripe PHP library</strong></td>
            <td class="description">Checks for <code>Stripe\StripeClient</code>.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['dompdf_library_available'] ? esc_html( 'Available' ) : esc_html( 'Missing' ); ?></td>
            <td><strong>PDF renderer</strong></td>
            <td class="description">Checks for <code>Dompdf\Dompdf</code>.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['report_template_available'] ? esc_html( 'Available' ) : esc_html( 'Feature Gated' ); ?></td>
            <td><strong>Report template</strong></td>
            <td class="description">Paid report templates must exist before report delivery can go live.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['report_renderer_available'] ? esc_html( 'Available' ) : esc_html( 'Feature Gated' ); ?></td>
            <td><strong>Report renderer</strong></td>
            <td class="description">Checks that plugin report-generation code exists, beyond the Dompdf dependency.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['report_storage_delivery_configured'] ? esc_html( 'Configured' ) : esc_html( 'Feature Gated' ); ?></td>
            <td><strong>Report storage/delivery</strong></td>
            <td class="description">Paid report delivery needs a configured storage or delivery path.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['report_storage_path_available'] ? esc_html( 'Available' ) : ( $checkout_readiness['report_storage_creatable'] ? esc_html( 'Creatable' ) : esc_html( 'Missing' ) ); ?></td>
            <td><strong>Report storage directory</strong></td>
            <td class="description"><code><?php echo esc_html( $checkout_readiness['report_storage_path'] ?: 'not configured' ); ?></code></td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['report_storage_writable'] ? esc_html( 'Writable' ) : esc_html( 'Not writable' ); ?></td>
            <td><strong>Report storage writability</strong></td>
            <td class="description">Generated paid reports must be writable before download tokens can be issued.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['report_storage_index_guard_present'] && $checkout_readiness['report_storage_htaccess_guard_present'] ? esc_html( 'Present' ) : esc_html( 'Review' ); ?></td>
            <td><strong>Report storage guard files</strong></td>
            <td class="description"><code>index.html</code> and <code>.htaccess</code> are written as best-effort direct-access guards.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['atomic_report_token_support'] ? esc_html( 'Available' ) : esc_html( 'Missing' ); ?></td>
            <td><strong>Atomic report-token consumption</strong></td>
            <td class="description">Report delivery must consume tokens with a single checked database update.</td>
          </tr>
          <tr>
            <td><?php echo $checkout_readiness['stripe_api_initialised'] ? esc_html( 'Ready' ) : esc_html( 'Feature Gated' ); ?></td>
            <td><strong>Stripe API initialisation</strong></td>
            <td class="description">A real Stripe API client check should replace format-only key validation before checkout goes live.</td>
          </tr>
        </tbody>
      </table>

      <table class="form-table">
        <tr>
          <th><label for="wpq_checkout_enabled">Checkout feature gate</label></th>
          <td>
            <select id="wpq_checkout_enabled" name="wpq_checkout_enabled" <?php disabled( ! empty( $checkout_readiness['checkout_constant_controlled'] ) ); ?>>
              <option value="disabled" <?php selected( $checkout_readiness['checkout_flag_option'] ?? 'disabled', 'disabled' ); ?>>Disabled</option>
              <option value="enabled" <?php selected( $checkout_readiness['checkout_flag_option'] ?? 'disabled', 'enabled' ); ?>>Enabled</option>
            </select>
            <p class="description">Source: <?php echo esc_html( (string) ( $checkout_readiness['checkout_flag_source'] ?? 'database' ) ); ?>. PHP configuration wins when <code>WPQ_CHECKOUT_ENABLED</code> is defined.</p>
          </td>
        </tr>
        <tr>
          <th><label for="stripe_publishable_key">Publishable Key</label></th>
          <td>
            <input type="text" id="stripe_publishable_key" name="stripe_publishable_key" class="regular-text"
                   value="<?php echo esc_attr( WPQ_Secrets::get_stripe_publishable_key() ); ?>"
                   placeholder="pk_live_...">
            <p class="description">Resolution order: <code>WPQ_STRIPE_PUBLISHABLE_KEY</code>, <code>STRIPE_PUBLISHABLE_KEY</code>, then the stored WordPress option.</p>
            <?php if ( ! empty( $stripe_save_feedback['publishable_key'] ) ) : ?>
              <p class="description" style="color:#2eb872;font-weight:600;"><?php echo esc_html( $stripe_save_feedback['publishable_key'] ); ?></p>
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <th><label for="stripe_secret_key">Secret Key</label></th>
          <td>
            <input type="password" id="stripe_secret_key" name="stripe_secret_key" class="regular-text"
                   value=""
                   placeholder="<?php echo esc_attr( WPQ_Secrets::get_stripe_secret_key() !== '' ? 'stored or external secret configured' : 'sk_live_...' ); ?>"
                   autocomplete="new-password">
            <p class="description">Leave blank to keep the existing value. Resolution order: <code>WPQ_STRIPE_SECRET_KEY</code>, <code>STRIPE_SECRET_KEY</code>, then the stored WordPress option.</p>
            <?php if ( ! empty( $stripe_save_feedback['secret_key'] ) ) : ?>
              <p class="description" style="color:<?php echo str_contains( $stripe_save_feedback['secret_key'], 'kept' ) ? '#888' : '#2eb872'; ?>;font-weight:600;"><?php echo esc_html( $stripe_save_feedback['secret_key'] ); ?></p>
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <th><label for="stripe_webhook_secret">Webhook Secret</label></th>
          <td>
            <input type="password" id="stripe_webhook_secret" name="stripe_webhook_secret" class="regular-text"
                   value=""
                   placeholder="<?php echo esc_attr( WPQ_Secrets::get_stripe_webhook_secret() !== '' ? 'stored or external webhook secret configured' : 'whsec_...' ); ?>"
                   autocomplete="new-password">
            <p class="description">Leave blank to keep the existing value. Resolution order: <code>WPQ_STRIPE_WEBHOOK_SECRET</code>, <code>STRIPE_WEBHOOK_SECRET</code>, then the stored WordPress option.</p>
            <?php if ( ! empty( $stripe_save_feedback['webhook_secret'] ) ) : ?>
              <p class="description" style="color:<?php echo str_contains( $stripe_save_feedback['webhook_secret'], 'kept' ) ? '#888' : '#2eb872'; ?>;font-weight:600;"><?php echo esc_html( $stripe_save_feedback['webhook_secret'] ); ?></p>
            <?php endif; ?>
          </td>
        </tr>
      </table>

      <?php submit_button( 'Save settings' ); ?>
    </div>

    <!-- ================================================================ -->
    <!-- Tab: Diagnostics                                                  -->
    <!-- ================================================================ -->
    <div id="tab-diagnostics" class="wpq-tab-panel wpq-hidden">
      <h3 style="margin-top:32px;">Migration diagnostics</h3>
      <p>
        <a class="button button-secondary"
           href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export_diagnostics' ), 'wpq_export_diagnostics' ) ); ?>">
          Download diagnostics JSON
        </a>
        <span class="description" style="margin-left:8px;">Exports plugin version, DB version, migration log, schema health, and readiness checks as a JSON file (no secret key values included).</span>
      </p>
      <table class="widefat striped" style="max-width:900px;margin-top:12px;">
        <tbody>
          <tr>
            <td style="width:220px;"><strong>Installed DB version</strong></td>
            <td><code><?php echo esc_html( (string) $migration_diagnostics['installed_db_version'] ); ?></code></td>
          </tr>
          <tr>
            <td><strong>Target DB version</strong></td>
            <td><code><?php echo esc_html( (string) $migration_diagnostics['target_db_version'] ); ?></code></td>
          </tr>
          <tr>
            <td><strong>Last migration run</strong></td>
            <td><?php echo $migration_diagnostics['last_migration_run'] ? esc_html( (string) $migration_diagnostics['last_migration_run'] ) : esc_html( 'Not recorded yet.' ); ?></td>
          </tr>
          <tr>
            <td><strong>Last migration error</strong></td>
            <td><?php echo $migration_diagnostics['last_migration_error'] ? esc_html( (string) $migration_diagnostics['last_migration_error'] ) : esc_html( 'None recorded.' ); ?></td>
          </tr>
          <tr>
            <td><strong>Structured migration errors</strong></td>
            <td>
              <?php if ( empty( $migration_diagnostics['last_migration_errors'] ) ) : ?>
                <?php echo esc_html( 'None recorded.' ); ?>
              <?php else : ?>
                <ul style="margin:0 0 0 18px;">
                  <?php foreach ( $migration_diagnostics['last_migration_errors'] as $migration_error ) : ?>
                    <li><?php echo esc_html( $migration_error ); ?></li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </td>
          </tr>
          <tr>
            <td><strong>Expired session count</strong></td>
            <td><?php echo esc_html( (string) $migration_diagnostics['expired_session_count'] ); ?></td>
          </tr>
        </tbody>
      </table>

      <h4>Table and column health</h4>
      <table class="widefat striped" style="max-width:900px;margin-top:12px;">
        <thead>
          <tr>
            <th>Table</th>
            <th>Status</th>
            <th>Missing columns</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ( $migration_diagnostics['table_health'] as $table_name => $health ) : ?>
            <tr>
              <td><code><?php echo esc_html( $table_name ); ?></code></td>
              <td><?php echo $health['exists'] ? esc_html( 'Present' ) : esc_html( 'Missing' ); ?></td>
              <td><?php echo empty( $health['missing_columns'] ) ? esc_html( 'None' ) : esc_html( implode( ', ', $health['missing_columns'] ) ); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <h4>Strict schema checks</h4>
      <p class="description">Diagnostics-only checks for critical indexes, column types, enum values, and nullability. These checks do not block activation.</p>
      <table class="widefat striped" style="max-width:900px;margin-top:12px;">
        <thead>
          <tr>
            <th>Table</th>
            <th>Check</th>
            <th>Status</th>
            <th>Detail</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ( $migration_diagnostics['strict_schema_health'] as $table_name => $checks ) : ?>
            <?php foreach ( $checks as $check_name => $check ) : ?>
              <tr>
                <td><code><?php echo esc_html( $table_name ); ?></code></td>
                <td><code><?php echo esc_html( $check_name ); ?></code></td>
                <td><?php echo ! empty( $check['ok'] ) ? esc_html( 'OK' ) : esc_html( 'Review' ); ?></td>
                <td><?php echo esc_html( (string) ( $check['message'] ?? '' ) ); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- ================================================================ -->
    <!-- Tab: HaloPSA API                                                 -->
    <!-- ================================================================ -->
    <div id="tab-halopsa" class="wpq-tab-panel wpq-hidden">
      <h3>HaloPSA Pull API</h3>
      <p>
        WP Questionnaires exposes authenticated REST endpoints so that the HaloPSA integration tool can
        <strong>pull</strong> submission data from WordPress. No HaloPSA credentials are stored here -
        the HaloPSA tool handles all writes into HaloPSA directly.
      </p>

      <h4>Step 1 - Create a dedicated WordPress user</h4>
      <ol>
        <li>Go to <strong>WP Admin → Users → Add New</strong>.</li>
        <li>Set username to <code>wpq_halopsa</code> and role to <strong>WPQ HaloPSA API</strong>.</li>
        <li>Set a strong password (it will not be used directly - an Application Password is used instead).</li>
      </ol>

      <h4>Step 2 - Generate an Application Password</h4>
      <ol>
        <li>Go to <strong>WP Admin → Users → wpq_halopsa → Edit</strong>.</li>
        <li>Scroll to <strong>Application Passwords</strong>.</li>
        <li>Enter label <em>HaloPSA Tool</em> and click <strong>Add New Application Password</strong>.</li>
        <li>Copy the generated password immediately - it is shown only once.</li>
      </ol>

      <h4>Step 3 - Configure the HaloPSA tool</h4>
      <p>Supply the following to the HaloPSA tool operator:</p>
      <table class="widefat" style="max-width:640px;">
        <tbody>
          <tr>
            <td style="width:180px;font-weight:600;">WordPress site URL</td>
            <td><code><?php echo esc_html( get_home_url() ); ?></code></td>
          </tr>
          <tr>
            <td style="font-weight:600;">Username</td>
            <td><code>wpq_halopsa</code></td>
          </tr>
          <tr>
            <td style="font-weight:600;">Application Password</td>
            <td><em>The password generated in Step 2</em></td>
          </tr>
        </tbody>
      </table>

      <h4 style="margin-top:24px;">API Endpoint Reference</h4>
      <p>All endpoints require <strong>HTTP Basic Auth</strong>: <code>Authorization: Basic base64(username:app-password)</code></p>

      <?php
      $base_url = esc_html( get_home_url() ) . '/wp-json/wpq/v1/api';
      $endpoints = [
          [ 'GET',  '/submissions',               'Paginated list. Params: page, per_page, questionnaire, sync_status, abandoned' ],
          [ 'GET',  '/submissions/pending',        'All pending or retry_pending submissions - safe to poll repeatedly' ],
          [ 'GET',  '/submissions/{id}',           'Full submission detail: answers, domain scores, UTM, behaviour, sync fields' ],
          [ 'POST', '/submissions/{id}/start',     'Claim for processing → status = processing, records attempt timestamp. Rejects synced/ignored/skipped (409).' ],
          [ 'POST', '/submissions/{id}/fail',      'Record failed attempt. Body: {"error_message":"…","retry":true|false}. retry=true → retry_pending, retry=false → failed.' ],
          [ 'POST', '/submissions/{id}/acknowledge','Mark synced. Body: {"halopsa_lead_id":"HALO-1234"}. Sets status = synced.' ],
      ];
      ?>
      <table class="widefat" style="max-width:960px;">
        <thead>
          <tr>
            <th style="width:60px;">Method</th>
            <th style="width:340px;">Path</th>
            <th>Purpose</th>
            <th style="width:80px;"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ( $endpoints as [ $method, $path, $desc ] ) : ?>
            <tr>
              <td><code><?php echo esc_html( $method ); ?></code></td>
              <td>
                <code id="ep-<?php echo esc_attr( md5( $path ) ); ?>"><?php echo esc_html( $base_url . $path ); ?></code>
              </td>
              <td class="description"><?php echo esc_html( $desc ); ?></td>
              <td>
                <button type="button" class="button button-small wpq-copy-btn"
                        data-target="ep-<?php echo esc_attr( md5( $path ) ); ?>">Copy</button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <h4 style="margin-top:24px;">Test Application Password access</h4>
      <p class="description">Run this before configuring the HaloPSA tool to confirm authentication and route access are working:</p>
      <pre style="background:#f5f5f5;padding:12px;border-radius:4px;overflow-x:auto;">curl -sv \
  -u "wpq_halopsa:xxxx xxxx xxxx xxxx xxxx xxxx" \
  "<?php echo esc_html( get_home_url() ); ?>/wp-json/wpq/v1/api/submissions/pending"</pre>
      <p class="description">Expected: HTTP 200 with <code>{"status":"ok","total":…}</code>. An HTTP 401 means the Application Password is wrong or the user does not exist. An HTTP 403 means the user exists but lacks the <code>wpq_halopsa_api</code> capability - check the role assignment.</p>

      <h4 style="margin-top:24px;">Pull-worker lifecycle example</h4>
      <pre style="background:#f5f5f5;padding:12px;border-radius:4px;overflow-x:auto;"># 1. Poll for work
curl -s -u "wpq_halopsa:APPPASS" "<?php echo esc_html( get_home_url() ); ?>/wp-json/wpq/v1/api/submissions/pending"

# 2. Claim a submission
curl -s -X POST -u "wpq_halopsa:APPPASS" "<?php echo esc_html( get_home_url() ); ?>/wp-json/wpq/v1/api/submissions/42/start"

# 3a. Acknowledge success
curl -s -X POST -u "wpq_halopsa:APPPASS" \
  -H "Content-Type: application/json" \
  -d '{"halopsa_lead_id":"HALO-1234"}' \
  "<?php echo esc_html( get_home_url() ); ?>/wp-json/wpq/v1/api/submissions/42/acknowledge"

# 3b. Or report failure (retry=true queues for retry)
curl -s -X POST -u "wpq_halopsa:APPPASS" \
  -H "Content-Type: application/json" \
  -d '{"error_message":"API timeout","retry":true}' \
  "<?php echo esc_html( get_home_url() ); ?>/wp-json/wpq/v1/api/submissions/42/fail"</pre>

      <script>
      (function() {
        document.querySelectorAll('.wpq-copy-btn').forEach(function(btn) {
          btn.addEventListener('click', function() {
            var el = document.getElementById(btn.dataset.target);
            if (!el) return;
            navigator.clipboard.writeText(el.textContent.trim()).then(function() {
              var orig = btn.textContent;
              btn.textContent = 'Copied!';
              setTimeout(function() { btn.textContent = orig; }, 1500);
            });
          });
        });
      })();
      </script>
    </div>

    <!-- ================================================================ -->
    <!-- Tab: Shortcodes                                                   -->
    <!-- ================================================================ -->
    <div id="tab-shortcodes" class="wpq-tab-panel wpq-hidden">
      <h3>Shortcode reference</h3>
      <p>
        Use these shortcodes in posts, pages, landing pages, Call to Action body copy, and other supporting content.
        Replace <code>CS01</code> with the questionnaire reference, or <code>EF-XXXXXX</code> with the enquiry form reference, you want to display.
      </p>

      <table class="widefat striped" style="max-width:980px;margin:12px 0 22px;">
        <thead>
          <tr>
            <th style="width:260px;">Shortcode</th>
            <th>Returns</th>
            <th>Writing use</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><code>[wpq_questionnaire ref="CS01"]</code></td>
            <td>The full interactive questionnaire.</td>
            <td>Embed the assessment itself. Accepts <code>layout</code> and <code>show_pricing</code> (see Shortcode attributes below). Old aliases <code>[wpq_assessment]</code>, <code>[wpq_assessments]</code>, and <code>[wpq_product]</code> still work.</td>
          </tr>
          <tr>
            <td><code>[wpq_enquiry ref="EF-XXXXXX"]</code></td>
            <td>A composed enquiry/contact form.</td>
            <td>Embed a published enquiry form. Accepts <code>collapsed</code>, <code>collapsed_text</code>, and <code>layout</code> (see Shortcode attributes below) - <code>collapsed="true"</code> is meant for embedding inside Call to Action body copy, where showing the full form up front would be too heavy.</td>
          </tr>
          <tr>
            <td><code>[wpq_title ref="CS01"]</code></td>
            <td>The questionnaire title.</td>
            <td>Use in headings and intro copy.</td>
          </tr>
          <tr>
            <td><code>[wpq_description ref="CS01"]</code></td>
            <td>The questionnaire description.</td>
            <td>Use for summary paragraphs.</td>
          </tr>
          <tr>
            <td><code>[wpq_questions ref="CS01"]</code></td>
            <td>Total question count.</td>
            <td>Example: "Answer [wpq_questions ref="CS01"] questions."</td>
          </tr>
          <tr>
            <td><code>[wpq_domains ref="CS01"]</code></td>
            <td>Total domain count.</td>
            <td>Example: "Across [wpq_domains ref="CS-01"] control areas."</td>
          </tr>
          <tr>
            <td><code>[wpq_time ref="CS01"]</code></td>
            <td>Estimated completion time as a number only.</td>
            <td>Example: "Takes around [wpq_time ref="CS-01"] minutes."</td>
          </tr>
          <tr>
            <td><code>[wpq_minutes ref="CS01"]</code></td>
            <td>Alias for <code>[wpq_time]</code>.</td>
            <td>Useful when composing your own wording.</td>
          </tr>
          <tr>
            <td><code>[wpq_submissions ref="CS01"]</code></td>
            <td>Completed and in-progress submission count for this questionnaire.</td>
            <td>Use sparingly for social-proof or internal pages.</td>
          </tr>
          <tr>
            <td><code>[wpq_status ref="CS01"]</code></td>
            <td>Current questionnaire status.</td>
            <td>Useful for internal documentation and staging pages.</td>
          </tr>
        </tbody>
      </table>

      <h3>Shortcode attributes</h3>
      <p class="description">In addition to <code>ref</code> (required on both), the two full-embed shortcodes accept:</p>
      <table class="widefat striped" style="max-width:980px;margin:12px 0 22px;">
        <thead>
          <tr>
            <th style="width:150px;">Attribute</th>
            <th style="width:130px;">Applies to</th>
            <th>Values</th>
            <th>Default</th>
            <th>Effect</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><code>layout</code></td>
            <td><code>wpq_questionnaire</code>, <code>wpq_enquiry</code></td>
            <td><code>wide</code> / <code>contained</code></td>
            <td><code>wide</code></td>
            <td><code>wide</code> lets the embed break out of a narrow theme content column (viewport-relative width). <code>contained</code> respects the theme's normal column width instead. An unrecognised value falls back to <code>wide</code>.</td>
          </tr>
          <tr>
            <td><code>show_pricing</code></td>
            <td><code>wpq_questionnaire</code></td>
            <td><code>true</code> / <code>false</code></td>
            <td><code>true</code></td>
            <td>Whether the pricing card is shown for questionnaires linked to a paid product.</td>
          </tr>
          <tr>
            <td><code>collapsed</code></td>
            <td><code>wpq_enquiry</code></td>
            <td><code>true</code> / <code>false</code></td>
            <td><code>false</code></td>
            <td>When <code>true</code>, the form starts hidden behind a reveal button instead of showing in full. Clicking the button reveals the form (a one-way reveal, not a collapsible accordion).</td>
          </tr>
          <tr>
            <td><code>collapsed_text</code></td>
            <td><code>wpq_enquiry</code></td>
            <td>Any text</td>
            <td><code>Enquire now</code></td>
            <td>The reveal button's label, only shown when <code>collapsed="true"</code>. Example: <code>collapsed_text="Express your interest here"</code>.</td>
          </tr>
        </tbody>
      </table>
      <p class="description" style="max-width:70em;">
        Example: <code>[wpq_enquiry ref="EF-C47BF9" collapsed="true" collapsed_text="Express your interest here"]</code>
      </p>

      <h3>Available enquiry form references</h3>
      <p class="description">Only <strong>Published</strong> forms can render publicly. Draft references are shown here so editors can prepare copy safely.</p>
      <table class="widefat striped" style="max-width:900px;margin-bottom:22px;">
        <thead><tr><th>Ref</th><th>Name</th><th>Status</th><th>Enquiries received</th><th>Primary embed</th></tr></thead>
        <tbody>
          <?php $wpq_sc_enquiry_forms = class_exists( 'WPQ_Database' ) ? WPQ_Database::get_enquiry_forms_with_counts() : []; ?>
          <?php if ( empty( $wpq_sc_enquiry_forms ) ) : ?>
            <tr><td colspan="5">No enquiry forms yet - create one under <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-enquiries' ) ); ?>">Questionnaires -&gt; Enquiries</a>.</td></tr>
          <?php else : ?>
            <?php foreach ( $wpq_sc_enquiry_forms as $wpq_sc_form ) : ?>
              <tr>
                <td><code><?php echo esc_html( (string) $wpq_sc_form->ref ); ?></code></td>
                <td><?php echo esc_html( (string) $wpq_sc_form->name ); ?></td>
                <td><?php echo esc_html( (string) $wpq_sc_form->status ); ?></td>
                <td><?php echo (int) ( $wpq_sc_form->enquiry_count ?? 0 ); ?></td>
                <td><code>[wpq_enquiry ref="<?php echo esc_attr( (string) $wpq_sc_form->ref ); ?>"]</code></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>

      <h3>Available questionnaire references</h3>
      <p class="description">Only <strong>Preview</strong> and <strong>Live</strong> questionnaires can render publicly. Draft and Retired references are shown here so editors can prepare copy safely.</p>
      <table class="widefat striped" style="max-width:1100px;">
        <thead><tr><th>Ref</th><th>Name</th><th>Status</th><th>Questions</th><th>Domains</th><th>Time</th><th>Submissions</th><th>Primary embed</th></tr></thead>
        <tbody>
          <?php foreach ( WPQ_Database::get_questionnaire_list() as $q ) : ?>
            <?php
            $question_count  = (int) ( $q->question_count ?? 0 );
            $domain_count    = (int) ( $q->domain_count ?? 0 );
            $submission_count = (int) ( $q->submission_count ?? 0 );
            $minutes         = (int) ceil( $question_count * 42 / 60 );
            $display_ref     = class_exists( 'WPQ_Claude' ) ? WPQ_Claude::display_ref( (string) $q->ref ) : str_replace( '-', '', strtoupper( (string) $q->ref ) );
            $embed_shortcode = '[wpq_questionnaire ref="' . $display_ref . '"]';
            ?>
            <tr>
              <td><code><?php echo esc_html( $q->ref ); ?></code></td>
              <td><?php echo esc_html( $q->name ); ?></td>
              <td><?php echo esc_html( $q->status ); ?></td>
              <td><code>[wpq_questions ref="<?php echo esc_attr( $display_ref ); ?>"]</code><br><span class="description"><?php echo esc_html( (string) $question_count ); ?></span></td>
              <td><code>[wpq_domains ref="<?php echo esc_attr( $display_ref ); ?>"]</code><br><span class="description"><?php echo esc_html( (string) $domain_count ); ?></span></td>
              <td><code>[wpq_time ref="<?php echo esc_attr( $display_ref ); ?>"]</code><br><span class="description"><?php echo esc_html( (string) $minutes ); ?></span></td>
              <td><code>[wpq_submissions ref="<?php echo esc_attr( $display_ref ); ?>"]</code><br><span class="description"><?php echo esc_html( (string) $submission_count ); ?></span></td>
              <td><code><?php echo esc_html( $embed_shortcode ); ?></code></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- ================================================================ -->
    <!-- Tab: Results Screen                                               -->
    <!-- ================================================================ -->
    <div id="tab-results" class="wpq-tab-panel wpq-hidden">
      <h3>Domain Breakdown</h3>
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_domain_breakdown_visualisation">Default Domain Breakdown visualisation</label></th>
          <td>
            <?php $db_global_mode = class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::domain_breakdown_global_visualisation_mode() : 'bars'; ?>
            <select id="wpq_domain_breakdown_visualisation" name="wpq_domain_breakdown_visualisation">
              <option value="bars" <?php selected( $db_global_mode, 'bars' ); ?>>Bar charts</option>
              <option value="radar" <?php selected( $db_global_mode, 'radar' ); ?>>Radar / spider chart</option>
            </select>
            <p class="description">Global default for the results screen's Domain Breakdown section, inherited by questionnaires set to "Inherit global setting". A radar chart falls back to bars automatically when a questionnaire has fewer than 3 domains. Each questionnaire can override this from its editor page.</p>
          </td>
        </tr>
      </table>

      <?php submit_button( 'Save settings' ); ?>
    </div>

    <!-- ================================================================ -->
    <!-- Tab: AI                                                           -->
    <!-- ================================================================ -->
    <div id="tab-ai" class="wpq-tab-panel wpq-hidden">
      <h2 class="nav-tab-wrapper wpq-ai-subnav" style="margin-bottom:20px;">
        <a href="#" class="nav-tab wpq-ai-subtab" data-subtab="llm">LLM Providers</a>
        <a href="#" class="nav-tab nav-tab-active wpq-ai-subtab" data-subtab="framework">Skills</a>
        <a href="#" class="nav-tab wpq-ai-subtab" data-subtab="report">Report</a>
        <a href="#" class="nav-tab wpq-ai-subtab" data-subtab="plan">Plan</a>
        <a href="#" class="nav-tab wpq-ai-subtab" data-subtab="logs">Logs</a>
      </h2>

      <?php
      $claude_details = class_exists( 'WPQ_Remediation_Plan' ) ? WPQ_Remediation_Plan::get_api_key_details() : [ 'present' => false, 'source' => 'none' ];
      $model_details  = class_exists( 'WPQ_Remediation_Plan' ) ? WPQ_Remediation_Plan::get_model_diagnostics() : [ 'preference' => 'auto', 'selected_model' => '', 'available_count' => 0, 'auto_available' => false ];
      $claude_debug_enabled = class_exists( 'WPQ_Remediation_Plan' ) && WPQ_Remediation_Plan::debug_logging_enabled();
      $claude_debug_log     = class_exists( 'WPQ_Remediation_Plan' ) ? WPQ_Remediation_Plan::get_debug_log() : [];
      $llm_diag             = class_exists( 'WPQ_LLM_Provider' ) ? WPQ_LLM_Provider::diagnostics() : [ 'provider' => 'anthropic', 'provider_ready' => false, 'missing' => [], 'wired_up' => true ];
      ?>

      <!-- ============================================================ -->
      <!-- AI sub-tab: Skills (internal id/slug stays "framework")       -->
      <!-- ============================================================ -->
      <div id="ai-subtab-framework" class="wpq-ai-subpanel">
      <h3>Framework Readiness</h3>
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_framework_readiness_enabled">Global Framework Readiness</label></th>
          <td>
            <?php
            $fr_constant_controlled = class_exists( 'WPQ_Feature_Flags' ) && WPQ_Feature_Flags::framework_readiness_constant_controls();
            $fr_global_state        = class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::framework_readiness_global_option_state() : 'enabled';
            $fr_max_frameworks      = class_exists( 'WPQ_Framework_Readiness' ) ? WPQ_Framework_Readiness::MAX_FRAMEWORKS : 8;
            ?>
            <select id="wpq_framework_readiness_enabled" name="wpq_framework_readiness_enabled" <?php disabled( $fr_constant_controlled ); ?>>
              <option value="enabled" <?php selected( $fr_global_state, 'enabled' ); ?>>Enabled</option>
              <option value="disabled" <?php selected( $fr_global_state, 'disabled' ); ?>>Disabled</option>
            </select>
            <p class="description">Global default inherited by questionnaires set to "Inherit global setting". PHP configuration via <code>WPQ_FRAMEWORK_READINESS_ENABLED</code> wins when defined. When disabled - globally or for a specific questionnaire - a completed submission never schedules a Claude call for this feature and the results screen never shows or polls for it.</p>
            <p class="description">Each questionnaire selects its own frameworks (maximum <?php echo (int) $fr_max_frameworks; ?>) and its own enable/inherit/disable override from its editor page.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_framework_analysis_visualisation">Default Frameworks Analysis visualisation</label></th>
          <td>
            <?php $fa_global_mode = class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::framework_analysis_global_visualisation_mode() : 'bars'; ?>
            <select id="wpq_framework_analysis_visualisation" name="wpq_framework_analysis_visualisation">
              <option value="bars" <?php selected( $fa_global_mode, 'bars' ); ?>>Bar charts</option>
              <option value="radar" <?php selected( $fa_global_mode, 'radar' ); ?>>Radar / spider chart</option>
            </select>
            <p class="description">Global default for the results screen's Framework Readiness section, inherited by questionnaires set to "Inherit global setting". A radar chart falls back to bars automatically when fewer than 3 frameworks are selected. Unlike Domain Breakdown's domains, each framework is an independent standard - a radar's connecting polygon doesn't imply a real relationship between them, which is why bars remains the default even though radar is offered. Each questionnaire can override this from its editor page.</p>
          </td>
        </tr>
      </table>

      <h3>Skill bundles (ATLAS imports)</h3>
      <p class="description" style="max-width:780px;">
        Each framework below is imported from an ATLAS <code>.skill</code> bundle: the bundle registers the
        framework, its control catalogue is parsed into the database, and the same bundle can then be
        installed into the Anthropic Skills API for use in Report readiness analysis above -
        so the catalogue shown here and the skill Claude analyses with always come from one artefact.
      </p>
      <p class="description" style="max-width:780px;">
        Importing and browsing skill bundles here works no matter which LLM provider is chosen on the
        <a href="#" class="wpq-ai-subtab" data-subtab="llm">LLM Providers</a> tab.
        <?php if ( ! $llm_diag['wired_up'] ) : ?>
          <span style="color:#996800">The active provider is currently <strong><?php echo esc_html( class_exists( 'WPQ_LLM_Provider' ) ? WPQ_LLM_Provider::provider_label( $llm_diag['provider'] ) : $llm_diag['provider'] ); ?></strong>, which has no skill-installation integration yet - the Install action below is unavailable until you switch back to Anthropic Claude. Framework Readiness analysis for frameworks already installed still runs on the results screen regardless of this setting, since it always calls Anthropic Claude directly using the Claude credentials on the LLM Providers tab - only the *installation* step is gated by the provider choice.</span>
        <?php else : ?>
          Installing a bundle below, and Framework Readiness analysis above, call Anthropic Claude directly using the Claude credentials on the LLM Providers tab.
        <?php endif; ?>
      </p>

      <?php
      $skills_frameworks = class_exists( 'WPQ_Database' ) ? WPQ_Database::get_frameworks_with_counts() : [];
      $skills_claude_ready = class_exists( 'WPQ_Remediation_Plan' ) && ! empty( WPQ_Remediation_Plan::get_api_key_details()['present'] );
      if ( ! $skills_claude_ready ) : ?>
        <p class="description" style="color:#b32d2e">No Claude API key configured yet on the LLM Providers tab - importing bundles still works, but installing them into the Anthropic Skills API and running Framework Readiness analysis will fail until one is saved.</p>
      <?php endif; ?>

      <?php
      // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Feedback query args are display-only; every mutating action below carries its own nonce.
      $skills_imported       = isset( $_GET['wpq_imported'] ) ? (int) $_GET['wpq_imported'] : null;
      $skills_import_failed  = isset( $_GET['wpq_import_failed'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_import_failed'] ) ) : '';
      $skills_registered     = isset( $_GET['wpq_registered'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_registered'] ) ) : '';
      $skills_register_error = isset( $_GET['wpq_register_error'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_register_error'] ) ) : '';
      $skills_deleted        = isset( $_GET['wpq_deleted'] ) ? sanitize_key( wp_unslash( (string) $_GET['wpq_deleted'] ) ) : '';
      $skills_renamed        = isset( $_GET['wpq_renamed'] ) ? sanitize_key( wp_unslash( (string) $_GET['wpq_renamed'] ) ) : '';
      $skills_rename_error   = isset( $_GET['wpq_rename_error'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_rename_error'] ) ) : '';
      $skills_import_error   = isset( $_GET['wpq_import_error'] ) ? sanitize_key( (string) $_GET['wpq_import_error'] ) : '';
      // phpcs:enable WordPress.Security.NonceVerification.Recommended
      ?>
      <?php if ( null !== $skills_imported ) : ?>
        <div class="notice notice-<?php echo '' === $skills_import_failed ? 'success' : 'warning'; ?> is-dismissible">
          <p>
            Imported <?php echo (int) $skills_imported; ?> skill bundle(s).
            <?php if ( '' !== $skills_import_failed ) : ?>
              Failed: <?php echo esc_html( $skills_import_failed ); ?>
            <?php endif; ?>
          </p>
        </div>
      <?php endif; ?>
      <?php if ( 'no_files' === $skills_import_error ) : ?>
        <div class="notice notice-error is-dismissible"><p>No .skill files were selected.</p></div>
      <?php endif; ?>
      <?php if ( '' !== $skills_registered ) : ?>
        <div class="notice notice-success is-dismissible"><p>Installed into the Anthropic Skills API as <code><?php echo esc_html( $skills_registered ); ?></code>.</p></div>
      <?php endif; ?>
      <?php if ( '' !== $skills_register_error ) : ?>
        <div class="notice notice-error is-dismissible"><p>Skills API installation failed: <?php echo esc_html( $skills_register_error ); ?></p></div>
      <?php endif; ?>
      <?php if ( '1' === $skills_deleted ) : ?>
        <div class="notice notice-success is-dismissible"><p>Framework deleted.</p></div>
      <?php endif; ?>
      <?php if ( '1' === $skills_renamed ) : ?>
        <div class="notice notice-success is-dismissible"><p>Framework renamed. Push a new version to update the installed Anthropic skill's title.</p></div>
      <?php endif; ?>
      <?php if ( '' !== $skills_rename_error ) : ?>
        <div class="notice notice-error is-dismissible"><p><?php echo esc_html( $skills_rename_error ); ?></p></div>
      <?php endif; ?>

      <h4>Import ATLAS skill bundles</h4>
      <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="margin-bottom:24px">
        <?php wp_nonce_field( 'wpq_import_atlas_skills' ); ?>
        <input type="hidden" name="action" value="wpq_import_atlas_skills">
        <input type="file" name="wpq_skill_files[]" multiple accept=".skill,.zip" required>
        <button type="submit" class="button button-primary">Import bundles</button>
        <p class="description" style="max-width:60em">
          Select one or more <code>.skill</code> files (multiple files can be imported in one go).
          Re-importing a bundle refreshes the framework and replaces its control catalogue. Some
          frameworks (process frameworks such as ITIL and COBIT, and guides such as FedRAMP) carry no
          control tables in their bundle - they import with zero controls and remain fully usable for
          readiness analysis.
        </p>
      </form>

      <h4>Imported frameworks (<?php echo count( $skills_frameworks ); ?>)</h4>
      <?php if ( empty( $skills_frameworks ) ) : ?>
        <p>No frameworks imported yet.</p>
      <?php else : ?>
      <table class="widefat striped">
        <thead>
          <tr>
            <th>Framework</th>
            <th>Slug</th>
            <th>Version</th>
            <th>Controls</th>
            <th>Provider Installation</th>
            <th>Imported</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ( $skills_frameworks as $skills_framework ) : ?>
          <tr>
            <td>
              <strong><?php echo esc_html( (string) $skills_framework->name ); ?></strong>
              <?php if ( '' !== (string) ( $skills_framework->description ?? '' ) ) : ?>
                <br><span style="color:#666"><?php echo esc_html( mb_substr( (string) $skills_framework->description, 0, 140 ) ); ?></span>
              <?php endif; ?>
              <details style="margin-top:4px;">
                <summary style="cursor:pointer;color:#2271b1;font-size:12px;">Edit name</summary>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:6px;">
                  <?php wp_nonce_field( 'wpq_rename_framework' ); ?>
                  <input type="hidden" name="action" value="wpq_rename_framework">
                  <input type="hidden" name="framework_id" value="<?php echo (int) $skills_framework->id; ?>">
                  <input type="text" name="framework_name" maxlength="191" style="width:100%;max-width:420px;"
                    value="<?php echo esc_attr( (string) $skills_framework->name ); ?>">
                  <button type="submit" class="button button-small">Save name</button>
                  <?php if ( class_exists( 'WPQ_Framework_Importer' ) && mb_strlen( (string) $skills_framework->name ) > WPQ_Framework_Importer::MAX_DISPLAY_TITLE_CHARS ) : ?>
                    <p class="description" style="margin:4px 0 0;">Longer than the Skills API's
                      <?php echo (int) WPQ_Framework_Importer::MAX_DISPLAY_TITLE_CHARS; ?>-character title limit -
                      installs as &ldquo;<?php echo esc_html( WPQ_Framework_Importer::skill_display_title( (string) $skills_framework->name ) ); ?>&rdquo;.</p>
                  <?php endif; ?>
                </form>
              </details>
            </td>
            <td><code><?php echo esc_html( (string) $skills_framework->slug ); ?></code></td>
            <td><?php echo esc_html( (string) ( $skills_framework->version ?: '-' ) ); ?></td>
            <td><?php echo (int) ( $skills_framework->control_count ?? 0 ); ?></td>
            <td>
              <?php
              $skills_has_id = '' !== (string) ( $skills_framework->skill_id ?? '' );
              ?>
              <?php if ( empty( $llm_diag['wired_up'] ) ) : ?>
                <span style="color:#996800" title="The active LLM provider has no skill-installation integration yet, so this can't be checked against it.">Unknown</span>
              <?php elseif ( $skills_has_id ) : ?>
                <span style="color:#2eb872;font-weight:600;" title="<?php echo esc_attr( (string) $skills_framework->skill_id ); ?>">Installed</span>
                <?php if ( '' !== (string) ( $skills_framework->skill_version ?? '' ) ) : ?>
                  <br><span style="color:#666">v<?php echo esc_html( (string) $skills_framework->skill_version ); ?></span>
                <?php endif; ?>
              <?php else : ?>
                <span style="color:#666">Not Installed</span>
              <?php endif; ?>
            </td>
            <td><?php echo esc_html( (string) ( $skills_framework->skill_imported_at ?: '-' ) ); ?></td>
            <td>
              <?php if ( ! empty( $llm_diag['wired_up'] ) ) : ?>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
                  <?php wp_nonce_field( 'wpq_register_framework_skill' ); ?>
                  <input type="hidden" name="action" value="wpq_register_framework_skill">
                  <input type="hidden" name="framework_id" value="<?php echo (int) $skills_framework->id; ?>">
                  <button type="submit" class="button button-small">
                    <?php echo $skills_has_id ? 'Push new version' : 'Install into Anthropic Skills API'; ?>
                  </button>
                </form>
              <?php else : ?>
                <p class="description" style="margin:0 0 6px;">Install not available for
                  <?php echo esc_html( class_exists( 'WPQ_LLM_Provider' ) ? WPQ_LLM_Provider::provider_label( $llm_diag['provider'] ) : $llm_diag['provider'] ); ?>.</p>
              <?php endif; ?>
              <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"
                onsubmit="return confirm('Delete this framework and its control catalogue?');">
                <?php wp_nonce_field( 'wpq_delete_framework' ); ?>
                <input type="hidden" name="action" value="wpq_delete_framework">
                <input type="hidden" name="framework_id" value="<?php echo (int) $skills_framework->id; ?>">
                <button type="submit" class="button button-small button-link-delete">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
      </div>

      <!-- ============================================================ -->
      <!-- AI sub-tab: Plan                                              -->
      <!-- ============================================================ -->
      <div id="ai-subtab-plan" class="wpq-ai-subpanel wpq-hidden">
      <h3>Remediation Plans</h3>
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_remediation_plan_enabled">Global remediation plan downloads</label></th>
          <td>
            <?php
            $remediation_constant_controlled = class_exists( 'WPQ_Feature_Flags' ) && WPQ_Feature_Flags::remediation_constant_controls();
            $remediation_global_state        = class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::remediation_global_option_state() : 'enabled';
            ?>
            <select id="wpq_remediation_plan_enabled" name="wpq_remediation_plan_enabled" <?php disabled( $remediation_constant_controlled ); ?>>
              <option value="enabled" <?php selected( $remediation_global_state, 'enabled' ); ?>>Enabled</option>
              <option value="disabled" <?php selected( $remediation_global_state, 'disabled' ); ?>>Disabled</option>
            </select>
            <p class="description">Global default inherited by questionnaires set to "Inherit global setting". PHP configuration via <code>WPQ_REMEDIATION_PLAN_ENABLED</code> wins when defined.</p>
          </td>
        </tr>
        <?php if ( class_exists( 'WPQ_Remediation_Delivery' ) ) :
          $rp_global_channels = WPQ_Remediation_Delivery::global_channels(); ?>
        <tr>
          <th>Remediation plan delivery</th>
          <td>
            <fieldset>
              <legend class="screen-reader-text">Remediation plan delivery channels</legend>
              <?php foreach ( WPQ_Remediation_Delivery::channels() as $channel_key => $channel ) : ?>
                <label for="wpq_rp_delivery_<?php echo esc_attr( $channel_key ); ?>" style="display:block;margin-bottom:6px;">
                  <input type="checkbox" id="wpq_rp_delivery_<?php echo esc_attr( $channel_key ); ?>"
                         name="wpq_remediation_delivery_channels[]"
                         value="<?php echo esc_attr( $channel_key ); ?>"
                         <?php checked( in_array( $channel_key, $rp_global_channels, true ) ); ?>>
                  <strong><?php echo esc_html( $channel['label'] ); ?></strong><br>
                  <span class="description" style="margin-left:24px;"><?php echo esc_html( $channel['description'] ); ?></span>
                </label>
              <?php endforeach; ?>
              <p class="description">
                Each questionnaire can override this list. The emailed link expires after
                <?php echo esc_html( (string) (int) round( WPQ_Remediation_Delivery::TOKEN_TTL_SECONDS / DAY_IN_SECONDS ) ); ?>
                days or <?php echo esc_html( (string) WPQ_Remediation_Delivery::TOKEN_MAX_USES ); ?> downloads.
                With no channel selected, customers cannot obtain the workbook at all.
              </p>
            </fieldset>
          </td>
        </tr>
        <tr class="wpq-rp-email-row">
          <th><label for="wpq_remediation_delivery_email_subject">Email Subject</label></th>
          <td>
            <input type="text" id="wpq_remediation_delivery_email_subject" name="wpq_remediation_delivery_email_subject" class="regular-text"
                   value="<?php echo esc_attr( (string) get_option( 'wpq_remediation_delivery_email_subject', '' ) ); ?>"
                   placeholder="<?php echo esc_attr( WPQ_Remediation_Delivery::email_subject() ); ?>">
            <p class="description">Leave blank to use the default subject.</p>
          </td>
        </tr>
        <tr class="wpq-rp-email-row">
          <th><label for="wpq_remediation_delivery_email_intro">Email Body</label></th>
          <td>
            <textarea id="wpq_remediation_delivery_email_intro" name="wpq_remediation_delivery_email_intro" class="large-text" rows="3"
                      placeholder="<?php echo esc_attr( WPQ_Remediation_Delivery::email_intro() ); ?>"><?php echo esc_textarea( (string) get_option( 'wpq_remediation_delivery_email_intro', '' ) ); ?></textarea>
            <p class="description">Shown above the secure download link. Leave blank to use the default wording.</p>
          </td>
        </tr>
        <?php endif; ?>
      </table>
      </div>

      <!-- ============================================================ -->
      <!-- AI sub-tab: Report                                            -->
      <!-- ============================================================ -->
      <div id="ai-subtab-report" class="wpq-ai-subpanel wpq-hidden">
      <h3>Reports (DOCX &rarr; PDF)</h3>
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_questionnaire_report_enabled">Global Report generation</label></th>
          <td>
            <?php
            $qr_constant_controlled = class_exists( 'WPQ_Feature_Flags' ) && WPQ_Feature_Flags::questionnaire_report_constant_controls();
            $qr_global_state        = class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::questionnaire_report_global_option_state() : 'enabled';
            $qr_renderer_mode       = class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::questionnaire_report_global_renderer_mode() : 'docx_template';
            $qr_html_fallback       = class_exists( 'WPQ_Feature_Flags' ) && WPQ_Feature_Flags::questionnaire_report_html_fallback_allowed();
            ?>
            <select id="wpq_questionnaire_report_enabled" name="wpq_questionnaire_report_enabled" <?php disabled( $qr_constant_controlled ); ?>>
              <option value="enabled" <?php selected( $qr_global_state, 'enabled' ); ?>>Enabled</option>
              <option value="disabled" <?php selected( $qr_global_state, 'disabled' ); ?>>Disabled</option>
            </select>
            <p class="description">Global default inherited by questionnaires set to "Inherit global setting". PHP configuration via <code>WPQ_QUESTIONNAIRE_REPORT_ENABLED</code> wins when defined.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_questionnaire_report_renderer_mode">Renderer mode</label></th>
          <td>
            <select id="wpq_questionnaire_report_renderer_mode" name="wpq_questionnaire_report_renderer_mode">
              <option value="docx_template" <?php selected( $qr_renderer_mode, 'docx_template' ); ?>>DOCX template -&gt; PDF (default)</option>
              <option value="html_dompdf" <?php selected( $qr_renderer_mode, 'html_dompdf' ); ?>>Existing HTML/Dompdf renderer</option>
            </select>
            <p class="description">Questionnaires can override this per questionnaire from the questionnaire editor.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_questionnaire_report_html_fallback">Allow HTML/Dompdf fallback</label></th>
          <td>
            <select id="wpq_questionnaire_report_html_fallback" name="wpq_questionnaire_report_html_fallback">
              <option value="disabled" <?php selected( $qr_html_fallback, false ); ?>>Disabled - fail clearly if the DOCX template is not ready</option>
              <option value="enabled" <?php selected( $qr_html_fallback, true ); ?>>Enabled - fall back to the existing HTML/Dompdf renderer</option>
            </select>
            <p class="description">The fallback only applies to submissions linked to a priced product and reuses the existing purchased-report renderer without Claude analysis.</p>
          </td>
        </tr>
        <?php if ( class_exists( 'WPQ_Questionnaire_Report_Delivery' ) ) :
          $qr_delivery_channels = WPQ_Questionnaire_Report_Delivery::global_channels(); ?>
        <tr>
          <th>Customer delivery</th>
          <td>
            <fieldset>
              <legend class="screen-reader-text">Report delivery channels</legend>
              <?php foreach ( WPQ_Questionnaire_Report_Delivery::channels() as $channel_key => $channel ) : ?>
                <label for="wpq_qr_delivery_<?php echo esc_attr( $channel_key ); ?>" style="display:block;margin-bottom:6px;">
                  <input type="checkbox" id="wpq_qr_delivery_<?php echo esc_attr( $channel_key ); ?>"
                         name="wpq_questionnaire_report_delivery_channels[]"
                         value="<?php echo esc_attr( $channel_key ); ?>"
                         <?php checked( in_array( $channel_key, $qr_delivery_channels, true ) ); ?>>
                  <strong><?php echo esc_html( $channel['label'] ); ?></strong><br>
                  <span class="description" style="margin-left:24px;"><?php echo esc_html( $channel['description'] ); ?></span>
                </label>
              <?php endforeach; ?>
              <p class="description">
                Any combination can be enabled, and each questionnaire can override this list. With none selected,
                reports are generated but only ever downloaded by an administrator. Every channel hands out the same
                tokenised link, which expires after
                <?php echo esc_html( (string) (int) round( WPQ_Questionnaire_Report_Delivery::TOKEN_TTL_SECONDS / DAY_IN_SECONDS ) ); ?>
                days or <?php echo esc_html( (string) WPQ_Questionnaire_Report_Delivery::TOKEN_MAX_USES ); ?> downloads,
                and stops working immediately if the report is deleted or the contact anonymised.
              </p>
            </fieldset>
          </td>
        </tr>
        <tr class="wpq-qr-email-row">
          <th><label for="wpq_questionnaire_report_email_subject">Email Subject</label></th>
          <td>
            <input type="text" id="wpq_questionnaire_report_email_subject" name="wpq_questionnaire_report_email_subject" class="regular-text"
                   value="<?php echo esc_attr( (string) get_option( 'wpq_questionnaire_report_email_subject', '' ) ); ?>"
                   placeholder="<?php echo esc_attr( WPQ_Questionnaire_Report_Delivery::email_subject() ); ?>">
            <p class="description">Leave blank to use the default subject.</p>
          </td>
        </tr>
        <tr class="wpq-qr-email-row">
          <th><label for="wpq_questionnaire_report_email_intro">Email Body</label></th>
          <td>
            <textarea id="wpq_questionnaire_report_email_intro" name="wpq_questionnaire_report_email_intro" class="large-text" rows="3"
                      placeholder="<?php echo esc_attr( WPQ_Questionnaire_Report_Delivery::email_intro() ); ?>"><?php echo esc_textarea( (string) get_option( 'wpq_questionnaire_report_email_intro', '' ) ); ?></textarea>
            <p class="description">Shown above the secure download link. Leave blank to use the default wording.</p>
          </td>
        </tr>
        <?php endif; ?>
      </table>
      </div>

      <!-- ============================================================ -->
      <!-- AI sub-tab: LLM Providers                                     -->
      <!-- ============================================================ -->
      <div id="ai-subtab-llm" class="wpq-ai-subpanel wpq-hidden">
      <h3>LLM Providers</h3>
      <p class="description" style="max-width:780px;">Choose which large language model provider generates remediation plans, questionnaire reports and framework readiness assessments.</p>
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_llm_provider">Chosen provider</label></th>
          <td>
            <select id="wpq_llm_provider" name="wpq_llm_provider">
              <option value="anthropic" <?php selected( $llm_diag['provider'], 'anthropic' ); ?>>Anthropic Claude</option>
              <option value="copilot" <?php selected( $llm_diag['provider'], 'copilot' ); ?>>Microsoft Copilot</option>
              <option value="openai" <?php selected( $llm_diag['provider'], 'openai' ); ?>>OpenAI ChatGPT</option>
              <option value="mcp" <?php selected( $llm_diag['provider'], 'mcp' ); ?>>Our own MCP server</option>
            </select>
            <?php if ( ! $llm_diag['provider_ready'] ) : ?>
              <p class="description" style="color:#b32d2e">The chosen provider is missing configuration: <?php echo esc_html( implode( ', ', $llm_diag['missing'] ) ); ?>.</p>
            <?php endif; ?>
            <?php if ( ! $llm_diag['wired_up'] ) : ?>
              <p class="description" style="color:#996800">Not yet wired up: remediation plans, reports and framework readiness still call Anthropic Claude directly regardless of this setting, until this provider's integration is built. Credentials can be saved in advance.</p>
            <?php endif; ?>
          </td>
        </tr>
        <tr id="wpq-llm-provider-row-anthropic">
          <th>Anthropic Claude</th>
          <td>
            <p><label for="claude_api_key">Claude API Key</label><br>
              <input type="password" id="claude_api_key" name="claude_api_key" class="regular-text"
                     placeholder="<?php echo esc_attr( ! empty( $claude_details['present'] ) ? 'stored or external key configured' : 'sk-ant-...' ); ?>"
                     autocomplete="new-password"></p>
            <p class="description">Leave blank to keep the current value. Source: <?php echo esc_html( (string) ( $claude_details['source'] ?? 'none' ) ); ?>. Resolved in order: <code>WPQ_CLAUDE_API_KEY</code> constant, <code>CLAUDE_API_KEY</code> or <code>ANTHROPIC_API_KEY</code> environment variable, then this stored option.</p>
            <p><label for="claude_model">Claude Model</label><br>
              <input type="text" id="claude_model" name="claude_model" class="regular-text"
                     value="<?php echo esc_attr( (string) get_option( 'wpq_claude_model', 'auto' ) ); ?>"></p>
            <p class="description">Use <code>auto</code> to choose the newest available Haiku model from Anthropic's Models API for lower-cost generation, falling back to Sonnet and only using Opus if no balanced model is available. Current selection: <code><?php echo esc_html( (string) ( $model_details['selected_model'] ?? '' ) ); ?></code>.
            <?php if ( ! empty( $model_details['checked'] ) ) : ?>
              Available models cached: <?php echo esc_html( (string) ( $model_details['available_count'] ?? 0 ) ); ?>.
            <?php else : ?>
              A specific model is pinned, so the Models API is never queried - no cost, no call.
            <?php endif; ?>
            </p>
            <p><label for="wpq_claude_max_tokens">Max output tokens</label><br>
              <input type="number" id="wpq_claude_max_tokens" name="wpq_claude_max_tokens" class="small-text" style="width:100px;"
                     min="1024" max="128000" step="1"
                     value="<?php echo esc_attr( (string) ( class_exists( 'WPQ_Remediation_Plan' ) ? WPQ_Remediation_Plan::get_max_tokens_preference() : 40000 ) ); ?>"></p>
            <p class="description">The hard ceiling on a single Claude response, shared by the remediation plan, questionnaire report and framework readiness. Too low truncates a response mid-JSON, which always fails to parse - the Logs tab records a <code>_truncated</code> event when this happens. Default 40,000. The request's own timeout is derived from this value automatically, so raising it also gives Claude enough wall-clock time to actually finish, not just more room to write into.</p>
          </td>
        </tr>
        <tr id="wpq-llm-provider-row-copilot" class="wpq-hidden">
          <th>Microsoft Copilot</th>
          <td>
            <p><label for="wpq_copilot_endpoint">Azure OpenAI endpoint</label><br>
              <input type="text" id="wpq_copilot_endpoint" name="wpq_copilot_endpoint" class="regular-text" placeholder="https://your-resource.openai.azure.com/"
                     value="<?php echo esc_attr( (string) get_option( 'wpq_copilot_endpoint', '' ) ); ?>"></p>
            <p><label for="wpq_copilot_deployment">Deployment name</label><br>
              <input type="text" id="wpq_copilot_deployment" name="wpq_copilot_deployment" class="regular-text"
                     value="<?php echo esc_attr( (string) get_option( 'wpq_copilot_deployment', '' ) ); ?>"></p>
            <p><label for="wpq_copilot_api_key">API key</label><br>
              <input type="password" id="wpq_copilot_api_key" name="wpq_copilot_api_key" class="regular-text" autocomplete="new-password"
                     placeholder="<?php echo '' !== (string) get_option( 'wpq_copilot_api_key', '' ) ? '•••••••• (saved - leave blank to keep)' : ''; ?>"></p>
            <p class="description">Targets Azure OpenAI Service - the standard way to call Microsoft-hosted models programmatically. If "Microsoft Copilot" means Copilot Studio or another Microsoft 365 surface instead, that's a different API shape and this section will need revisiting before it's wired up. Constants/environment variables (<code>WPQ_COPILOT_*</code>) override these values.</p>
          </td>
        </tr>
        <tr id="wpq-llm-provider-row-openai" class="wpq-hidden">
          <th>OpenAI ChatGPT</th>
          <td>
            <p><label for="wpq_openai_api_key">API key</label><br>
              <input type="password" id="wpq_openai_api_key" name="wpq_openai_api_key" class="regular-text" autocomplete="new-password"
                     placeholder="<?php echo '' !== (string) get_option( 'wpq_openai_api_key', '' ) ? '•••••••• (saved - leave blank to keep)' : 'sk-...'; ?>"></p>
            <p><label for="wpq_openai_model">Model</label><br>
              <input type="text" id="wpq_openai_model" name="wpq_openai_model" class="regular-text" placeholder="e.g. the current flagship or a cost-optimised variant"
                     value="<?php echo esc_attr( (string) get_option( 'wpq_openai_model', '' ) ); ?>"></p>
            <p class="description">Model name exactly as OpenAI's API expects. Constants/environment variables (<code>WPQ_OPENAI_*</code>) override these values.</p>
          </td>
        </tr>
        <tr id="wpq-llm-provider-row-mcp" class="wpq-hidden">
          <th>Our own MCP server</th>
          <td>
            <p><label for="wpq_mcp_endpoint">MCP server URL</label><br>
              <input type="text" id="wpq_mcp_endpoint" name="wpq_mcp_endpoint" class="regular-text" placeholder="https://mcp.yourdomain.com/"
                     value="<?php echo esc_attr( (string) get_option( 'wpq_mcp_endpoint', '' ) ); ?>"></p>
            <p><label for="wpq_mcp_api_key">Auth token</label><br>
              <input type="password" id="wpq_mcp_api_key" name="wpq_mcp_api_key" class="regular-text" autocomplete="new-password"
                     placeholder="<?php echo '' !== (string) get_option( 'wpq_mcp_api_key', '' ) ? '•••••••• (saved - leave blank to keep)' : ''; ?>"></p>
            <p class="description">Routes generation work to your own MCP-compliant server instead of a third-party LLM API, so assessment data never leaves your own infrastructure boundary. We'll need your server's exact endpoint/tool contract before this can be wired up for real. Constants/environment variables (<code>WPQ_MCP_*</code>) override these values.</p>
          </td>
        </tr>
      </table>
      </div>

      <!-- ============================================================ -->
      <!-- AI sub-tab: Logs                                              -->
      <!-- ============================================================ -->
      <div id="ai-subtab-logs" class="wpq-ai-subpanel wpq-hidden">
      <h3>Logs</h3>
      <p class="description" style="max-width:780px;">Activity log for the chosen LLM provider. Only Anthropic Claude is wired up today (see LLM Providers), so this always reflects Claude API activity regardless of the provider selected there.</p>
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_claude_debug_enabled">Claude API debug log</label></th>
          <td>
            <select id="wpq_claude_debug_enabled" name="wpq_claude_debug_enabled">
              <option value="no" <?php selected( $claude_debug_enabled, false ); ?>>Disabled</option>
              <option value="yes" <?php selected( $claude_debug_enabled, true ); ?>>Enabled</option>
            </select>
            <p class="description">Temporarily records Anthropic request/response metadata for remediation plans and reports. API keys and full prompts are not stored, but response excerpts may contain generated customer-specific remediation text.</p>
            <?php if ( ! empty( $claude_debug_log ) ) : ?>
              <label style="display:block;margin-top:8px;">
                <input type="checkbox" name="wpq_clear_claude_debug_log" value="yes">
                Clear existing Claude debug log when saving
              </label>
            <?php endif; ?>
          </td>
        </tr>
      </table>

      <h4 style="margin-top:18px;">Recent activity log</h4>
      <?php if ( empty( $claude_debug_log ) ) : ?>
        <p class="description">No debug events recorded.</p>
      <?php else : ?>
        <table class="widefat striped" style="max-width:980px;">
          <thead>
            <tr>
              <th style="width:150px;">Time (UTC)</th>
              <th style="width:220px;">Event</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ( array_slice( $claude_debug_log, 0, 20 ) as $row ) : ?>
              <?php
              $event = is_array( $row ) ? (string) ( $row['event'] ?? '' ) : '';
              $time  = is_array( $row ) ? (string) ( $row['time'] ?? '' ) : '';
              $data  = is_array( $row ) && isset( $row['data'] ) ? $row['data'] : [];
              $json  = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
              ?>
              <tr>
                <td><?php echo esc_html( $time ); ?></td>
                <td><code><?php echo esc_html( $event ); ?></code></td>
                <td><pre style="white-space:pre-wrap;margin:0;max-height:160px;overflow:auto;"><?php echo esc_html( is_string( $json ) ? $json : '' ); ?></pre></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
      </div>

      <p>
        <button type="submit" class="button button-primary" onclick="document.getElementById('wpq-settings-section').value='ai';">Save AI settings</button>
      </p>
    </div>

    <!-- ================================================================ -->
    <!-- Tab: Advanced                                                      -->
    <!-- ================================================================ -->
    <div id="tab-advanced" class="wpq-tab-panel wpq-hidden">
      <h3>Advanced / Data</h3>

      <!-- ------------------------------------------------------------ -->
      <!-- PDF conversion (server environment, configured once)          -->
      <!-- ------------------------------------------------------------ -->
      <h3 style="margin-top:0;">PDF Conversion</h3>
      <p class="description">Used to convert generated Questionnaire Report DOCX files to PDF. A server-level path, not a per-report setting - see <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-settings#tab-readiness' ) ); ?>">Settings -&gt; Readiness</a> for live detection status.</p>
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_docx_pdf_converter_path">LibreOffice/soffice executable</label></th>
          <td>
            <input type="text" id="wpq_docx_pdf_converter_path" name="wpq_docx_pdf_converter_path" class="regular-text"
                   value="<?php echo esc_attr( (string) get_option( 'wpq_docx_pdf_converter_path', '' ) ); ?>"
                   placeholder="Leave blank to auto-detect common install locations">
            <p class="description">Absolute path to the <code>soffice</code>/<code>libreoffice</code> binary used to convert generated DOCX reports to PDF.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_docx_pdf_converter_timeout">PDF conversion timeout (seconds)</label></th>
          <td>
            <input type="number" id="wpq_docx_pdf_converter_timeout" name="wpq_docx_pdf_converter_timeout" class="small-text" min="10" max="600"
                   value="<?php echo esc_attr( (string) get_option( 'wpq_docx_pdf_converter_timeout', 60 ) ); ?>">
          </td>
        </tr>
      </table>

      <?php
      // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only GET params for feedback display.
      $purged    = isset( $_GET['purged'] )    ? (int) $_GET['purged']    : null;
      // phpcs:ignore WordPress.Security.NonceVerification.Recommended
      $anonymised = isset( $_GET['anonymised'] ) ? (int) $_GET['anonymised'] : null;
      if ( $purged !== null ) :
      ?>
        <div class="notice notice-success inline" style="margin:0 0 12px;padding:8px 12px;">
          <p>Purged <?php echo esc_html( (string) $purged ); ?> abandoned submission(s).</p>
        </div>
      <?php endif; ?>
      <?php if ( $anonymised !== null ) : ?>
        <div class="notice notice-success inline" style="margin:0 0 12px;padding:8px 12px;">
          <p>Anonymised <?php echo esc_html( (string) $anonymised ); ?> completed submission(s).</p>
        </div>
      <?php endif; ?>

      <?php
      /** @var array{purge_days:int, anonymise_days:int, purgeable_abandoned_count:int, anonymisable_count:int} $retention_diagnostics */
      $retention_diagnostics = $retention_diagnostics ?? [ 'purge_days' => 0, 'anonymise_days' => 0, 'purgeable_abandoned_count' => 0, 'anonymisable_count' => 0 ];
      ?>

      <!-- ------------------------------------------------------------ -->
      <!-- Retention policy                                               -->
      <!-- ------------------------------------------------------------ -->
      <h3 style="margin-top:24px;">Data Retention Policy</h3>
      <p class="description">Set a retention period for each category. A value of <strong>0</strong> disables automatic processing for that category. Changes take effect when you click <strong>Save settings</strong>; processing runs from the manual controls below, or daily when automation is enabled.</p>

      <table class="form-table">
        <tr>
          <th><label for="wpq_purge_abandoned_days">Purge abandoned sessions after (days)</label></th>
          <td>
            <input type="number" id="wpq_purge_abandoned_days" name="wpq_purge_abandoned_days"
                   value="<?php echo esc_attr( (string) $retention_diagnostics['purge_days'] ); ?>"
                   min="0" max="3650" step="1" class="small-text">
            <p class="description">Soft-deletes incomplete (abandoned) submissions older than this many days. 0 = disabled.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_anonymise_completed_days">Anonymise completed assessments after (days)</label></th>
          <td>
            <input type="number" id="wpq_anonymise_completed_days" name="wpq_anonymise_completed_days"
                   value="<?php echo esc_attr( (string) $retention_diagnostics['anonymise_days'] ); ?>"
                   min="0" max="3650" step="1" class="small-text">
            <p class="description">Replaces name, email, company, phone, and IP address in completed assessments older than this many days with anonymous placeholders. Assessment scores and domain data are preserved for analytics. 0 = disabled.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_retention_automation_enabled">Run retention automatically</label></th>
          <td>
            <label>
              <input type="checkbox" id="wpq_retention_automation_enabled" name="wpq_retention_automation_enabled" value="yes"
                     <?php checked( get_option( 'wpq_retention_automation_enabled', 'no' ), 'yes' ); ?>>
              Apply the thresholds above on a daily schedule, without requiring the manual buttons below.
            </label>
            <p class="description">Explicit opt-in. Runs via WP-Cron (hook <code>wpq_retention_daily</code>) and only processes categories whose threshold is above 0. Every run that touches rows is recorded in the audit log. <strong>Back up your database before enabling.</strong></p>
          </td>
        </tr>
      </table>

      <?php submit_button( 'Save settings' ); ?>

      <!-- ------------------------------------------------------------ -->
      <!-- Retention diagnostics                                          -->
      <!-- ------------------------------------------------------------ -->
      <h3 style="margin-top:28px;">Retention Diagnostics</h3>

      <table class="widefat striped" style="max-width:860px;margin-bottom:16px;">
        <tbody>
          <tr>
            <td style="width:280px;"><strong>Abandoned submissions eligible for purge</strong></td>
            <td>
              <?php if ( $retention_diagnostics['purge_days'] > 0 ) : ?>
                <strong><?php echo esc_html( (string) $retention_diagnostics['purgeable_abandoned_count'] ); ?></strong>
                older than <?php echo esc_html( (string) $retention_diagnostics['purge_days'] ); ?> day(s)
              <?php else : ?>
                <em>Purge not configured (threshold = 0).</em>
              <?php endif; ?>
            </td>
          </tr>
          <tr>
            <td><strong>Completed submissions eligible for anonymisation</strong></td>
            <td>
              <?php if ( $retention_diagnostics['anonymise_days'] > 0 ) : ?>
                <strong><?php echo esc_html( (string) $retention_diagnostics['anonymisable_count'] ); ?></strong>
                older than <?php echo esc_html( (string) $retention_diagnostics['anonymise_days'] ); ?> day(s)
              <?php else : ?>
                <em>Anonymisation not configured (threshold = 0).</em>
              <?php endif; ?>
            </td>
          </tr>
        </tbody>
      </table>

      <?php if ( $retention_diagnostics['purge_days'] > 0 && $retention_diagnostics['purgeable_abandoned_count'] > 0 ) : ?>
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:16px;flex-wrap:wrap;">
          <a class="button button-secondary"
             href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export_purgeable' ), 'wpq_export_purgeable' ) ); ?>">
            Export <?php echo esc_html( (string) $retention_diagnostics['purgeable_abandoned_count'] ); ?> purgeable submission(s) as CSV
          </a>
          <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
            <?php wp_nonce_field( 'wpq_purge_abandoned' ); ?>
            <input type="hidden" name="action" value="wpq_purge_abandoned">
            <button type="submit" class="button button-secondary" style="color:#d63638;border-color:#d63638;"
                    onclick="return confirm('This will soft-delete <?php echo esc_js( (string) $retention_diagnostics['purgeable_abandoned_count'] ); ?> abandoned submission(s). This action can be partially reversed by restoring deleted_at to NULL in the database.\n\nExport a CSV first if you need a permanent record.\n\nProceed?');">
              Purge <?php echo esc_html( (string) $retention_diagnostics['purgeable_abandoned_count'] ); ?> abandoned submission(s)
            </button>
          </form>
        </div>
      <?php elseif ( $retention_diagnostics['purge_days'] > 0 ) : ?>
        <p class="description">No abandoned submissions are older than <?php echo esc_html( (string) $retention_diagnostics['purge_days'] ); ?> day(s).</p>
      <?php endif; ?>

      <?php if ( $retention_diagnostics['anonymise_days'] > 0 && $retention_diagnostics['anonymisable_count'] > 0 ) : ?>
        <div style="margin-bottom:16px;">
          <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
            <?php wp_nonce_field( 'wpq_anonymise_old' ); ?>
            <input type="hidden" name="action" value="wpq_anonymise_old">
            <button type="submit" class="button button-secondary" style="color:#d63638;border-color:#d63638;"
                    onclick="return confirm('This will anonymise contact details (name, email, company, phone, IP) for <?php echo esc_js( (string) $retention_diagnostics['anonymisable_count'] ); ?> completed submission(s). Scores and domain data are preserved.\n\nThis cannot be undone.\n\nProceed?');">
              Anonymise <?php echo esc_html( (string) $retention_diagnostics['anonymisable_count'] ); ?> completed submission(s)
            </button>
          </form>
        </div>
      <?php elseif ( $retention_diagnostics['anonymise_days'] > 0 ) : ?>
        <p class="description">No completed submissions are older than <?php echo esc_html( (string) $retention_diagnostics['anonymise_days'] ); ?> day(s).</p>
      <?php endif; ?>

      <!-- ------------------------------------------------------------ -->
      <!-- Uninstall                                                      -->
      <!-- ------------------------------------------------------------ -->
      <h3 style="margin-top:28px;">Uninstall</h3>

      <div class="notice notice-warning inline" style="margin:0 0 16px;padding:8px 12px;">
        <p><strong>Caution:</strong> The setting below controls whether WP Questionnaires deletes its database tables when the plugin is uninstalled. Leaving it disabled (the default) means that lead records, assessment submissions, and questionnaire data survive an accidental uninstall.</p>
      </div>

      <table class="form-table">
        <tr>
          <th><label for="wpq_delete_data_on_uninstall">Delete all data on uninstall</label></th>
          <td>
            <label>
              <input type="checkbox" id="wpq_delete_data_on_uninstall" name="wpq_delete_data_on_uninstall" value="yes"
                     <?php checked( get_option( 'wpq_delete_data_on_uninstall' ), 'yes' ); ?>>
              When the plugin is deleted from WP Admin, permanently drop all plugin tables (questionnaires, submissions, payments, products) and remove all plugin settings.
            </label>
            <p class="description" style="color:#b32d2e;">Default: off. Enable only when you intend a full data erasure. This cannot be undone.</p>
          </td>
        </tr>
      </table>

      <?php submit_button( 'Save settings' ); ?>
    </div>

  </form>

  <!-- ================================================================ -->
  <!-- Tab: Mail (own forms - outside the main POST form)                 -->
  <!-- ================================================================ -->
  <?php if ( class_exists( 'WPQ_Mailer' ) ) :
    $wpq_mail_diag = WPQ_Mailer::diagnostics();
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Feedback query arg is display-only.
    $wpq_mail_test_result = isset( $_GET['wpq_mail_test'] ) ? sanitize_key( (string) $_GET['wpq_mail_test'] ) : '';
  ?>
  <div id="tab-mail" class="wpq-tab-panel wpq-hidden">
    <h3>Email Delivery</h3>
    <p class="description" style="max-width:780px;">
      Every email this plugin sends - report delivery links, resume links, enquiry notifications and
      acknowledgements - is routed through the provider configured here.
    </p>

    <?php if ( 'sent' === $wpq_mail_test_result ) : ?>
      <div class="notice notice-success inline"><p>Test email sent.</p></div>
    <?php elseif ( 'failed' === $wpq_mail_test_result ) : ?>
      <div class="notice notice-error inline"><p>Test email failed<?php echo '' !== $wpq_mail_diag['last_error'] ? ': ' . esc_html( $wpq_mail_diag['last_error'] ) : '.'; ?></p></div>
    <?php endif; ?>

    <form method="post">
      <?php wp_nonce_field( 'wpq_settings', 'wpq_settings_nonce' ); ?>
      <input type="hidden" name="wpq_settings_section" value="mail">
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_mail_enabled">Mail delivery</label></th>
          <td>
            <select id="wpq_mail_enabled" name="wpq_mail_enabled">
              <option value="enabled" <?php selected( $wpq_mail_diag['enabled'], true ); ?>>Enabled</option>
              <option value="disabled" <?php selected( $wpq_mail_diag['enabled'], false ); ?>>Disabled - this plugin sends no email at all</option>
            </select>
            <p class="description">The global switch for every email this plugin sends. Questionnaires and enquiry forms each have their own override.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_mail_provider">Active provider</label></th>
          <td>
            <select id="wpq_mail_provider" name="wpq_mail_provider">
              <option value="wp_mail" <?php selected( $wpq_mail_diag['provider'], 'wp_mail' ); ?>>WordPress wp_mail() (default)</option>
              <option value="gmail" <?php selected( $wpq_mail_diag['provider'], 'gmail' ); ?>>Gmail API (Google Cloud)</option>
              <option value="ses" <?php selected( $wpq_mail_diag['provider'], 'ses' ); ?>>AWS SES API</option>
              <option value="m365" <?php selected( $wpq_mail_diag['provider'], 'm365' ); ?>>Microsoft 365 (Microsoft Graph)</option>
            </select>
            <?php if ( ! $wpq_mail_diag['provider_ready'] ) : ?>
              <p class="description" style="color:#b32d2e">The active provider is missing configuration: <?php echo esc_html( implode( ', ', $wpq_mail_diag['missing'] ) ); ?>.</p>
            <?php endif; ?>
            <?php if ( '' !== $wpq_mail_diag['last_error'] ) : ?>
              <p class="description" style="color:#b32d2e">Last delivery error: <?php echo esc_html( $wpq_mail_diag['last_error'] ); ?></p>
            <?php endif; ?>
          </td>
        </tr>
        <tr id="wpq-mail-provider-row-gmail">
          <th>Gmail API</th>
          <td>
            <p><label for="wpq_gmail_client_id">Client ID</label><br>
              <input type="text" id="wpq_gmail_client_id" name="wpq_gmail_client_id" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_gmail_client_id', '' ) ); ?>"></p>
            <p><label for="wpq_gmail_client_secret">Client secret</label><br>
              <input type="password" id="wpq_gmail_client_secret" name="wpq_gmail_client_secret" class="regular-text" autocomplete="new-password"
                placeholder="<?php echo '' !== (string) get_option( 'wpq_gmail_client_secret', '' ) ? '•••••••• (saved - leave blank to keep)' : ''; ?>"></p>
            <p><label for="wpq_gmail_refresh_token">OAuth refresh token</label><br>
              <input type="password" id="wpq_gmail_refresh_token" name="wpq_gmail_refresh_token" class="regular-text" autocomplete="new-password"
                placeholder="<?php echo '' !== (string) get_option( 'wpq_gmail_refresh_token', '' ) ? '•••••••• (saved - leave blank to keep)' : ''; ?>"></p>
            <p><label for="wpq_gmail_sender">Sender address</label><br>
              <input type="email" id="wpq_gmail_sender" name="wpq_gmail_sender" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_gmail_sender', '' ) ); ?>"></p>
            <p class="description">A Google Cloud OAuth client with the <code>gmail.send</code> scope; the refresh token authorises sending as the sender address. Constants/environment variables (<code>WPQ_GMAIL_*</code>) override these values.</p>
          </td>
        </tr>
        <tr id="wpq-mail-provider-row-ses">
          <th>AWS SES API</th>
          <td>
            <p><label for="wpq_ses_access_key">Access key ID</label><br>
              <input type="text" id="wpq_ses_access_key" name="wpq_ses_access_key" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_ses_access_key', '' ) ); ?>"></p>
            <p><label for="wpq_ses_secret_key">Secret access key</label><br>
              <input type="password" id="wpq_ses_secret_key" name="wpq_ses_secret_key" class="regular-text" autocomplete="new-password"
                placeholder="<?php echo '' !== (string) get_option( 'wpq_ses_secret_key', '' ) ? '•••••••• (saved - leave blank to keep)' : ''; ?>"></p>
            <p><label for="wpq_ses_region">Region</label><br>
              <input type="text" id="wpq_ses_region" name="wpq_ses_region" class="regular-text" placeholder="eu-west-2" value="<?php echo esc_attr( (string) get_option( 'wpq_ses_region', '' ) ); ?>"></p>
            <p><label for="wpq_ses_from">From address</label><br>
              <input type="email" id="wpq_ses_from" name="wpq_ses_from" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_ses_from', '' ) ); ?>"></p>
            <p class="description">SES v2, signed with SigV4 - no AWS SDK required. The from address must be SES-verified. Constants/environment variables (<code>WPQ_SES_*</code>) override these values.</p>
          </td>
        </tr>
        <tr id="wpq-mail-provider-row-m365">
          <th>Microsoft 365 (Graph)</th>
          <td>
            <p><label for="wpq_m365_tenant_id">Directory (tenant) ID</label><br>
              <input type="text" id="wpq_m365_tenant_id" name="wpq_m365_tenant_id" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_m365_tenant_id', '' ) ); ?>"></p>
            <p><label for="wpq_m365_client_id">Application (client) ID</label><br>
              <input type="text" id="wpq_m365_client_id" name="wpq_m365_client_id" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_m365_client_id', '' ) ); ?>"></p>
            <p><label for="wpq_m365_client_secret">Client secret</label><br>
              <input type="password" id="wpq_m365_client_secret" name="wpq_m365_client_secret" class="regular-text" autocomplete="new-password"
                placeholder="<?php echo '' !== (string) get_option( 'wpq_m365_client_secret', '' ) ? '•••••••• (saved - leave blank to keep)' : ''; ?>"></p>
            <p><label for="wpq_m365_sender">Sender mailbox</label><br>
              <input type="email" id="wpq_m365_sender" name="wpq_m365_sender" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_m365_sender', '' ) ); ?>"></p>
            <p class="description">The real, mailbox-enabled UPN that Graph authenticates the send against. Must be an actual mailbox (a licensed user or a shared mailbox) - a distribution list is not a mailbox and cannot be used here, and Graph will reject it with "the requested user is invalid".</p>
            <p><label for="wpq_m365_from">From address (optional)</label><br>
              <input type="email" id="wpq_m365_from" name="wpq_m365_from" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_m365_from', '' ) ); ?>" placeholder="Leave blank to send as the sender mailbox above"></p>
            <p class="description">Only needed to send as a shared mailbox or distribution list address different from the sender mailbox above - for example a distribution list like <code>enquiries@yourdomain.com</code> that has no mailbox of its own. Requires the sender mailbox to be granted <strong>Send As</strong> permission on this address in Exchange Online (<code>Add-RecipientPermission -Identity "&lt;this address&gt;" -Trustee "&lt;sender mailbox&gt;" -AccessRights SendAs</code>); without that grant, Graph rejects the send even though the sender mailbox itself is valid.</p>
            <p class="description">An Entra ID (Azure AD) app registration authenticating app-only (client-credentials, no signed-in user) with the Microsoft Graph <strong>application</strong> permission <code>Mail.Send</code>, admin-consented. See "Setting up Microsoft 365 delivery" in the README for the full app-registration walkthrough. Constants/environment variables (<code>WPQ_M365_*</code>) override these values.</p>
          </td>
        </tr>
      </table>
      <p><button type="submit" class="button button-primary">Save Mail settings</button></p>
    </form>

    <h4 style="margin-top:24px;">Send a test email</h4>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
      <?php wp_nonce_field( 'wpq_mail_test' ); ?>
      <input type="hidden" name="action" value="wpq_mail_test">
      <label for="wpq_mail_test_recipient">Recipient:</label>
      <input type="email" id="wpq_mail_test_recipient" name="test_recipient" placeholder="<?php echo esc_attr( wp_get_current_user()->user_email ?? '' ); ?>">
      <button type="submit" class="button">Send test email</button>
      <span class="description">Save settings first - the test uses the saved configuration.</span>
    </form>
  </div>
  <?php endif; ?>

  <!-- ================================================================ -->
  <!-- Tab: Turnstile (own form - outside the main POST form)             -->
  <!-- ================================================================ -->
  <?php if ( class_exists( 'WPQ_Turnstile' ) ) :
    $wpq_ts_diag = WPQ_Turnstile::diagnostics();
  ?>
  <div id="tab-turnstile" class="wpq-tab-panel wpq-hidden">
    <h3>Cloudflare Turnstile</h3>
    <p class="description" style="max-width:780px;">
      Bot protection for the public lead-capture and enquiry forms - the two places an anonymous
      request writes a new contact into the system, which is what scrapers submitting false data
      actually target. A missing or rejected token blocks the submission. If Turnstile is enabled but
      not fully configured, or Cloudflare's API is unreachable, submissions are allowed through rather
      than blocked - a misconfiguration here should never lock out real customers. What visitors
      actually see (nothing, a quiet checkbox, or an interactive challenge) is controlled by the
      Widget Mode you choose for the sitekey in the Cloudflare Turnstile dashboard, not by this
      plugin. Get free site/secret keys from the
      <a href="https://dash.cloudflare.com/?to=/:account/turnstile" target="_blank" rel="noopener noreferrer">Cloudflare Turnstile dashboard</a>.
    </p>

    <form method="post">
      <?php wp_nonce_field( 'wpq_settings', 'wpq_settings_nonce' ); ?>
      <input type="hidden" name="wpq_settings_section" value="turnstile">
      <table class="form-table" role="presentation">
        <tr>
          <th><label for="wpq_turnstile_enabled">Bot protection</label></th>
          <td>
            <select id="wpq_turnstile_enabled" name="wpq_turnstile_enabled">
              <option value="disabled" <?php selected( $wpq_ts_diag['enabled'], false ); ?>>Disabled</option>
              <option value="enabled" <?php selected( $wpq_ts_diag['enabled'], true ); ?>>Enabled</option>
            </select>
            <p class="description">The global switch. Questionnaires and enquiry forms each have their own inherit/enabled/disabled override once this is on.</p>
            <?php if ( ! empty( $wpq_ts_diag['enabled'] ) && ! $wpq_ts_diag['configured'] ) : ?>
              <p class="description" style="color:#b32d2e">Enabled but not fully configured - missing: <?php echo esc_html( implode( ', ', $wpq_ts_diag['missing'] ) ); ?>. No forms will actually be protected until both keys are set.</p>
            <?php endif; ?>
            <?php if ( '' !== $wpq_ts_diag['last_error'] ) : ?>
              <p class="description" style="color:#b32d2e">Last error: <?php echo esc_html( $wpq_ts_diag['last_error'] ); ?></p>
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <th><label for="wpq_turnstile_site_key">Site key</label></th>
          <td><input type="text" id="wpq_turnstile_site_key" name="wpq_turnstile_site_key" class="regular-text" value="<?php echo esc_attr( (string) get_option( 'wpq_turnstile_site_key', '' ) ); ?>"></td>
        </tr>
        <tr>
          <th><label for="wpq_turnstile_secret_key">Secret key</label></th>
          <td>
            <input type="password" id="wpq_turnstile_secret_key" name="wpq_turnstile_secret_key" class="regular-text" autocomplete="new-password"
              placeholder="<?php echo '' !== (string) get_option( 'wpq_turnstile_secret_key', '' ) ? '•••••••• (saved - leave blank to keep)' : ''; ?>">
            <p class="description">Leave blank to keep the current value. Constants/environment variables (<code>WPQ_TURNSTILE_SITE_KEY</code> / <code>WPQ_TURNSTILE_SECRET_KEY</code>) override these values.</p>
          </td>
        </tr>
      </table>
      <p><button type="submit" class="button button-primary">Save Turnstile settings</button></p>
    </form>
  </div>
  <?php endif; ?>

  <!-- ================================================================ -->
  <!-- Tab: Categories (AJAX - outside the POST form)                    -->
  <!-- ================================================================ -->
  <div id="tab-categories" class="wpq-tab-panel wpq-hidden">
    <h3>Questionnaire Categories</h3>
    <p class="description">Categories are used to organise questionnaires in the library. Every questionnaire must belong to one category.</p>

    <table id="wpq-cat-table" class="wp-list-table widefat fixed striped" style="max-width:720px;margin:16px 0;" data-wpq-sortable="true">
      <thead>
        <tr>
          <th style="width:48px;">Order</th>
          <th style="width:180px;">Slug</th>
          <th>Name</th>
          <th style="width:140px;" data-no-sort></th>
        </tr>
      </thead>
      <tbody id="wpq-cat-tbody">
        <?php if ( empty( $categories ) ) : ?>
          <tr id="wpq-cat-empty"><td colspan="4">No categories found. Click <strong>Add Category</strong> to create one.</td></tr>
        <?php else : ?>
          <?php foreach ( $categories as $cat ) : ?>
            <tr data-cat-id="<?php echo (int) $cat->id; ?>">
              <td><?php echo (int) $cat->sort_order; ?></td>
              <td><code><?php echo esc_html( $cat->slug ); ?></code></td>
              <td class="wpq-cat-name-cell">
                <span class="wpq-cat-name-display"><?php echo esc_html( $cat->name ); ?></span>
                <span class="wpq-cat-edit-wrap wpq-hidden">
                  <input type="text" class="wpq-cat-name-input regular-text" value="<?php echo esc_attr( $cat->name ); ?>">
                  <input type="number" class="wpq-cat-order-input small-text" value="<?php echo (int) $cat->sort_order; ?>" min="0" style="width:56px;margin-left:8px;" title="Sort order">
                </span>
              </td>
              <td>
                <span class="wpq-cat-view-actions">
                  <button type="button" class="button button-small wpq-cat-edit-btn">Edit</button>
                  <button type="button" class="button button-small wpq-cat-delete-btn" style="margin-left:4px;" data-name="<?php echo esc_attr( $cat->name ); ?>">Delete</button>
                </span>
                <span class="wpq-cat-edit-actions wpq-hidden">
                  <button type="button" class="button button-primary button-small wpq-cat-save-btn">Save</button>
                  <button type="button" class="button button-small wpq-cat-cancel-btn" style="margin-left:4px;">Cancel</button>
                  <span class="wpq-cat-row-status" style="margin-left:6px;font-size:.85em;"></span>
                </span>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>

    <button type="button" id="wpq-cat-add-btn" class="button">+ Add Category</button>

    <div id="wpq-cat-add-form" class="wpq-hidden" style="margin-top:16px;max-width:500px;">
      <table class="form-table" style="margin:0;">
        <tr>
          <th style="width:120px;"><label for="wpq-cat-new-name">Name <span style="color:#d63638;">*</span></label></th>
          <td><input type="text" id="wpq-cat-new-name" class="regular-text" placeholder="e.g. Cloud Security"></td>
        </tr>
        <tr>
          <th><label for="wpq-cat-new-slug">Slug <span style="color:#d63638;">*</span></label></th>
          <td>
            <input type="text" id="wpq-cat-new-slug" class="regular-text" placeholder="e.g. cloud_security">
            <p class="description">Lowercase letters, numbers and underscores. Auto-generated from the name.</p>
          </td>
        </tr>
        <tr>
          <th><label for="wpq-cat-new-order">Sort order</label></th>
          <td><input type="number" id="wpq-cat-new-order" class="small-text" value="0" min="0"></td>
        </tr>
      </table>
      <p style="margin-top:12px;">
        <button type="button" id="wpq-cat-create-btn" class="button button-primary">Create</button>
        <button type="button" id="wpq-cat-create-cancel-btn" class="button" style="margin-left:8px;">Cancel</button>
        <span id="wpq-cat-create-status" class="wpq-hidden" style="margin-left:10px;font-size:.85em;"></span>
      </p>
    </div>
  </div>

  <!-- ================================================================ -->
  <!-- Tab: Readiness (own admin-post forms - outside the POST form)     -->
  <!-- ================================================================ -->
  <div id="tab-readiness" class="wpq-tab-panel wpq-hidden">
    <?php include WPQ_PLUGIN_DIR . 'admin/views/page-readiness.php'; ?>
  </div>

</div>
