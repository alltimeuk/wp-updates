<?xml version="1.0" encoding="UTF-8"?>
<!--
  WP Questionnaires - default email layout.

  Transforms the small <email> XML document built by WPQ_Email_Template into
  the HTML email body every WPQ_Mailer::send() call now delivers. The look
  and structure mirror templates/test_email.html; the shared signature lives
  in signature.xsl so future layouts can reuse it without duplicating the
  brand assets.

  Recognised <email> child elements (all optional except title):
    subject         - used as the <title> of the HTML document
    badge           - small pill shown top-right of the header
    department      - sub-line under the company name, and the signature's job title
    title           - large coloured heading
    recipient_line  - small italic line under the title
    intro/p         - one or more body paragraphs
    cta_url/cta_label - a button-style call to action link
    details/item[@label] - a two-column key/value table
    footnote        - small print under the details table
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method="html" encoding="UTF-8" indent="no" doctype-system="about:legacy-compat"/>
<xsl:include href="signature.xsl"/>

<xsl:template match="/email">
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<title><xsl:value-of select="subject"/></title>
</head>
<body style="margin:0;padding:0;background:#f5f5f5;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;">

<div style="background:#f5f5f5;padding:20px 0;">
<div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:4px;overflow:hidden;border:1px solid #e0e0e0;">

  <!-- HEADER -->
  <div style="background:#ffffff;padding:0px;">
    <table style="border-bottom:3px solid #E20979;width:100%;">
      <tr>
        <td style="border-right:0px solid #E20979;padding-top:1px;padding-bottom:1px;padding-left:0px;padding-right:0px;">
          <img src="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmlld0JveD0iMCAtMC4xMDQ1NjEyOTE4NDI4NTYwMSAyNDczLjY4NTQwMDI4Mjg4MyAyMzc0LjEwNDU2MTI5MTg0MyIgd2lkdGg9IjI0NzQiIGhlaWdodD0iMjM3NSI+Cgk8c3R5bGU+CgkJLnMwIHsgZmlsbDogI2UyMDk3OSB9IAoJCS5zMSB7IGZpbGw6ICNmZmZmZmYgfSAKCQkuczIgeyBmaWxsOiAjMmQyYzk0IH0gCgk8L3N0eWxlPgoJPGcgaWQ9IkxheWVyIDEiPgoJCTxnIGlkPSImbHQ7R3JvdXAmZ3Q7Ij4KCQkJPGcgaWQ9IiZsdDtHcm91cCZndDsiPgoJCQkJPHBhdGggaWQ9IiZsdDtQYXRoJmd0OyIgY2xhc3M9InMwIiBkPSJtMTc2NC43NCA3MjguNzRjLTMxLjA5IDIzMS45NC0zMDIuNjIgNDcyLjM3LTYwNS4yNSAzMzAuOTIgMCAwIDEwMS43OS05OS40NSAyNjguNDEtMTk0LjE0IDYuMTYgMzUuMTUgMTIuNTUgOTIuODItMC4xNSAxMzkuNTggMCAwIDQ4LjQtNjkuOTEgNjcuNDktMTc1LjY3IDc5LjUtMzkuOSAxNzAuMzctNzYuMyAyNjkuNS0xMDAuNjl6Ii8+CgkJCTwvZz4KCQkJPGcgaWQ9IiZsdDtHcm91cCZndDsiPgoJCQkJPHBhdGggaWQ9IiZsdDtQYXRoJmd0OyIgY2xhc3M9InMwIiBkPSJtNzU0LjA2IDE1MzEuOTVjLTE3Ni4xMy0yNDcuMjEtMjc5LjcxLTU0OS44NC0yNzkuNzEtODc2LjU1di0wLjM5YzAtMjEuOSAxMi4xNi00Mi4wMSAzMS4zMy01Mi42MSAyMTYuNjctMTIwLjAyIDQ2Ni4wNi0xODguMzcgNzMxLjQzLTE4OC4zNyAyNzggMCA1MzguNDcgNzQuOTggNzYyLjIyIDIwNS45MS05ODYuNTkgODEuOTktMTI0Mi4zIDkwMi4xOS0xMjQ1LjI3IDkxMi4wMXoiLz4KCQkJPC9nPgoJCQk8ZyBpZD0iJmx0O0dyb3VwJmd0OyI+CgkJCQk8cGF0aCBpZD0iJmx0O1BhdGgmZ3Q7IiBjbGFzcz0iczAiIGQ9Im0xODY4LjAxIDEyNzQuMDZjLTEyNi40OSAyODIuMTMtMzM2LjkyIDUxOC4zNi01OTkuNDEgNjc3LjAzLTE5LjQgMTEuNy00My42NCAxMS43LTYyLjk3IDAtMTUxLjk4LTkxLjg4LTI4Ni41LTIwOS44LTM5Ny40LTM0Ny41MSAwIDAgMCAwIDAtMC4wOCA0My4zMy0xMjMuNTMgMjUyLjI4LTUzOS43OSAxMDU5Ljc4LTMyOS40NHoiLz4KCQkJPC9nPgoJCQk8cGF0aCBpZD0iJmx0O1BhdGgmZ3Q7IiBjbGFzcz0iczEiIGQ9Im0xNzY0Ljc0IDcyOC43NGMtMzEuMDkgMjMxLjk0LTMwMi42MiA0NzIuMzctNjA1LjI1IDMzMC45MiAwIDAgMTAxLjc5LTk5LjQ1IDI2OC40MS0xOTQuMTQgNi4xNiAzNS4xNSAxMi41NSA5Mi44Mi0wLjE1IDEzOS41OCAwIDAgNDguNC02OS45MSA2Ny40OS0xNzUuNjcgNzkuNS0zOS45IDE3MC4zNy03Ni4zIDI2OS41LTEwMC42OXoiLz4KCQkJPGcgaWQ9IiZsdDtHcm91cCZndDsiPgoJCQkJPHBhdGggaWQ9IiZsdDtQYXRoJmd0OyIgY2xhc3M9InMyIiBkPSJtMTc2NC43NCA3MjguNzRjLTMxLjA5IDIzMS45NC0zMDIuNjIgNDcyLjM3LTYwNS4yNSAzMzAuOTIgMCAwIDEwMS43OS05OS40NSAyNjguNDEtMTk0LjE0IDYuMTYgMzUuMTUgMTIuNTUgOTIuODItMC4xNSAxMzkuNTggMCAwIDQ4LjQtNjkuOTEgNjcuNDktMTc1LjY3IDc5LjUtMzkuOSAxNzAuMzctNzYuMyAyNjkuNS0xMDAuNjl6Ii8+CgkJCTwvZz4KCQk8L2c+Cgk8L2c+Cjwvc3ZnPg==" alt="Alltime Technologies Ltd" height="80" style="height:80px;width:121px;float:left;"/>
        </td>
        <td style="vertical-align:middle;">
          <div style="font-family:Poppins,Arial,sans-serif;font-size:16px;font-weight:700;color:#2D2C94;line-height:1.2;">
            Alltime Technologies Ltd
          </div>
          <xsl:if test="department">
            <div style="font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#888888;margin-top:2px;"><xsl:value-of select="department"/></div>
          </xsl:if>
        </td>
        <td style="text-align:right;vertical-align:middle;padding-left:16px;">
          <xsl:if test="badge">
            <span style="display:inline-block;background:#2D2C94;color:#ffffff;font-family:Poppins,Arial,sans-serif;font-size:10px;font-weight:700;padding:3px 10px;border-radius:2px;letter-spacing:1px;vertical-align:middle;"><xsl:value-of select="badge"/></span>
          </xsl:if>
        </td>
      </tr>
    </table>
  </div>

  <!-- BODY -->
  <div style="padding:28px 28px 20px;">

    <div style="font-family:Poppins,Arial,sans-serif;font-size:18px;font-weight:700;color:#E20979;margin-bottom:4px;line-height:1.3;"><xsl:value-of select="title"/></div>

    <xsl:if test="recipient_line">
      <div style="margin-bottom:16px;"><span style="font-size:11px;color:#888;font-style:italic;"><xsl:value-of select="recipient_line"/></span></div>
    </xsl:if>

    <xsl:for-each select="intro/p">
      <div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;line-height:1.7;margin-bottom:16px;"><xsl:value-of select="."/></div>
    </xsl:for-each>

    <xsl:if test="cta_url">
      <div style="text-align:center;margin:8px 0 24px;">
        <a style="display:inline-block;background:#E20979;color:#ffffff;font-family:Poppins,Arial,sans-serif;font-size:14px;font-weight:700;padding:12px 28px;border-radius:4px;text-decoration:none;">
          <xsl:attribute name="href"><xsl:value-of select="cta_url"/></xsl:attribute>
          <xsl:value-of select="cta_label"/>
        </a>
      </div>
    </xsl:if>

    <xsl:if test="details/item">
      <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
        <xsl:for-each select="details/item">
          <tr>
            <td style="font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#888;padding:4px 12px 4px 0;white-space:nowrap;vertical-align:top;"><xsl:value-of select="@label"/>:</td>
            <td style="font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#333;padding:4px 0;"><xsl:value-of select="."/></td>
          </tr>
        </xsl:for-each>
      </table>
    </xsl:if>

    <xsl:if test="footnote">
      <div style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#888;line-height:1.6;">
        <xsl:value-of select="footnote"/>
      </div>
    </xsl:if>

  </div><!-- /body -->

  <!-- REGARDS + SIGNATURE -->
  <div style="padding:0 28px 24px;">
    <p style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;margin:0 0 4px;">Thank you,</p>
    <p style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;margin:0 0 20px;"></p>
    <xsl:call-template name="signature">
      <xsl:with-param name="department">
        <xsl:choose>
          <xsl:when test="department"><xsl:value-of select="department"/></xsl:when>
          <xsl:otherwise>Service Desk Team</xsl:otherwise>
        </xsl:choose>
      </xsl:with-param>
    </xsl:call-template>
  </div>

</div><!-- /card -->
</div><!-- /wrapper -->

</body>
</html>
</xsl:template>

</xsl:stylesheet>
