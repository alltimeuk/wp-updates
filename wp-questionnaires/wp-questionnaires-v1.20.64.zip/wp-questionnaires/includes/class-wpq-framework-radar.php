<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Framework readiness chart, drawn deterministically from already-stored
 * framework assessment rows (fr_results_json from the automatic
 * submission-time job, falling back to a Questionnaire Report run's own
 * qr_analysis_json copy) - never from a live Claude call. One entry per
 * assessed framework; length/radius is the readiness position; colour is
 * the readiness level.
 *
 * Bars is the default presentation: each framework is an independent
 * standard with its own headline score, so a radar's connecting polygon
 * implies a geometric relationship between adjacent frameworks that doesn't
 * actually exist the way it does for WPQ_Domain_Radar's domains (genuinely
 * facets of one coherent whole). Radar is still offered as an explicit,
 * admin-chosen alternative (WPQ_Feature_Flags::
 * framework_analysis_visualisation_mode_for_questionnaire()) for anyone who
 * wants the pattern-recognition read anyway and accepts that caveat - it is
 * never the default. Because a radar vertex can't fit a full framework name,
 * radar mode adds a lettered legend beneath the chart (name/percent/level
 * per row) directly inside the SVG, unlike Domain Breakdown which relies on
 * a separate on-page grid the caller renders alongside the chart - this
 * class has no such grid at any of its call sites, so the legend has to
 * travel with the chart itself.
 *
 * Percent precedence per framework:
 *   1. readiness_percent - only present when the standard's own methodology
 *      yields a defensible figure (the analysis schema forbids estimating).
 *   2. Cited-control ratio - strengths / (strengths + gaps), both lists carry
 *      validated control references, so this is a data-backed coverage signal.
 *   3. Level band - aligned 85, partially_aligned 50, not_aligned 15,
 *      insufficient_evidence 5 - a last-resort indicative position.
 *
 * Two renderers from one row model:
 *   - render_svg(): inline SVG for the admin submission detail and the public
 *     results screen, mode-aware (bars or radar). Presentation attributes
 *     only (fill/stroke/font-*), no style attributes and no scripts, so it
 *     renders under the strictest CSP the frontend has to satisfy
 *     (style-src-attr 'none').
 *   - render_png(): GD-drawn PNG for the DOCX template (via image macro) and
 *     the Dompdf HTML report (as a data URI). Bars only for now - these are
 *     generated documents rather than the live results screen, and adding a
 *     GD-drawn radar+legend is separate follow-up work. Uses the DejaVu font
 *     bundled with Dompdf when present, falling back to GD's built-in font.
 */
class WPQ_Framework_Radar {

	public const MODE_BARS  = 'bars';
	public const MODE_RADAR = 'radar';

	private const MIN_RADAR_ROWS = 3;
	private const POLYGON_FILL   = '31,58,95'; // Navy, matching WPQ_Domain_Radar.

	public const LEVEL_COLOURS = [
		'aligned'               => '#2eb872',
		'partially_aligned'     => '#f5a623',
		'not_aligned'           => '#e84855',
		'insufficient_evidence' => '#9aa3ad',
	];

	private const LEVEL_BANDS = [
		'aligned'               => 85,
		'partially_aligned'     => 50,
		'not_aligned'           => 15,
		'insufficient_evidence' => 5,
	];

	/**
	 * Decode a submission's stored framework assessment rows, preferring the
	 * automatic submission-time job (fr_results_json, WPQ_Framework_Readiness_Job)
	 * over a Questionnaire Report run's own nested copy (qr_analysis_json) - the
	 * latter is kept only as a fallback for submissions assessed before this
	 * became a submission-time job, or whose questionnaire had no frameworks
	 * enabled until after report generation already ran once.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function stored_frameworks( object $submission ): array {
		$direct = self::decode_framework_rows( (string) ( $submission->fr_results_json ?? '' ) );
		if ( ! empty( $direct ) ) {
			return $direct;
		}

		$raw = (string) ( $submission->qr_analysis_json ?? '' );
		if ( '' === $raw ) {
			return [];
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) || ! is_array( $decoded['frameworks'] ?? null ) ) {
			return [];
		}
		return array_values( array_filter( $decoded['frameworks'], 'is_array' ) );
	}

	/** @return array<int, array<string, mixed>> */
	private static function decode_framework_rows( string $raw ): array {
		if ( '' === $raw ) {
			return [];
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return [];
		}
		return array_values( array_filter( $decoded, 'is_array' ) );
	}

	/**
	 * Normalise stored assessment rows into the chart row model.
	 *
	 * @param array<int, array<string, mixed>> $frameworks Stored assessment rows.
	 * @return array<int, array{name: string, level: string, label: string, percent: int, derived: bool}>
	 */
	public static function rows_from_analysis( array $frameworks ): array {
		$rows = [];
		foreach ( $frameworks as $framework ) {
			if ( ! is_array( $framework ) ) {
				continue;
			}
			$name = trim( (string) ( $framework['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}

			$level = strtolower( trim( (string) ( $framework['readiness_level'] ?? $framework['level'] ?? '' ) ) );
			if ( ! isset( self::LEVEL_COLOURS[ $level ] ) ) {
				$level = 'insufficient_evidence';
			}

			$percent = null;
			$derived = false;
			if ( isset( $framework['readiness_percent'] ) && is_numeric( $framework['readiness_percent'] ) ) {
				$percent = max( 0, min( 100, (int) $framework['readiness_percent'] ) );
			}

			if ( null === $percent ) {
				$strengths = is_array( $framework['strengths'] ?? null ) ? count( $framework['strengths'] ) : 0;
				$gaps      = is_array( $framework['gaps'] ?? null ) ? count( $framework['gaps'] ) : 0;
				$derived   = true;
				if ( ( $strengths + $gaps ) > 0 ) {
					$percent = (int) round( 100 * $strengths / ( $strengths + $gaps ) );
				} else {
					$percent = self::LEVEL_BANDS[ $level ];
				}
			}

			$rows[] = [
				'name'    => $name,
				'level'   => $level,
				'label'   => trim( (string) ( $framework['readiness_label'] ?? '' ) ) ?: ucwords( str_replace( '_', ' ', $level ) ),
				'percent' => $percent,
				'derived' => $derived,
			];
		}

		return $rows;
	}

	/**
	 * Inline SVG chart. $mode selects the questionnaire's configured
	 * presentation (self::MODE_BARS or self::MODE_RADAR - see
	 * WPQ_Feature_Flags::framework_analysis_visualisation_mode_for_questionnaire()).
	 * A radar request still falls back to bars below MIN_RADAR_ROWS, since a
	 * radar needs at least that many points to read as a shape. Omitting
	 * $mode (or passing anything else) draws bars, matching this class's
	 * original bars-only behaviour for any caller that hasn't been updated to
	 * pass a resolved mode. Returns '' when there is nothing to draw.
	 *
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	public static function render_svg( array $rows, ?string $mode = null ): string {
		if ( empty( $rows ) ) {
			return '';
		}
		if ( self::MODE_RADAR === $mode && count( $rows ) >= self::MIN_RADAR_ROWS ) {
			return self::svg_radar( $rows );
		}
		return self::svg_bars( $rows );
	}

	/**
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	private static function svg_bars( array $rows ): string {
		$width    = 560;
		$row_h    = 54;
		$height   = 16 + $row_h * count( $rows );
		$bar_x    = 12;
		$bar_full = $width - 130;

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Framework readiness" class="wpq-radar-svg">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';

		foreach ( $rows as $i => $row ) {
			// Word-wrapped, not truncated with an ellipsis - a long framework
			// name (e.g. "NIST SP 800-161 Rev 1 - Cybersecurity Supply Chain
			// Risk Management Practices") must stay fully readable.
			$name_lines = self::wrap_text( $row['name'], 60 );
			$top        = 16 + $i * $row_h;
			foreach ( $name_lines as $li => $line ) {
				$svg .= '<text x="' . $bar_x . '" y="' . ( $top + 12 + $li * 13 ) . '" font-size="12" font-weight="600" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
					. self::escape( $line ) . '</text>';
			}
			$bar_top = $top + 12 + count( $name_lines ) * 13;
			$svg    .= '<rect x="' . $bar_x . '" y="' . $bar_top . '" width="' . $bar_full . '" height="14" rx="7" fill="#eef1f4"/>';
			$svg    .= '<rect x="' . $bar_x . '" y="' . $bar_top . '" width="' . self::coord( max( 7, $bar_full * $row['percent'] / 100 ) ) . '" height="14" rx="7" fill="' . self::LEVEL_COLOURS[ $row['level'] ] . '"/>';
			$svg    .= '<text x="' . ( $bar_x + $bar_full + 10 ) . '" y="' . ( $bar_top + 12 ) . '" font-size="11" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( (string) $row['percent'] . ( $row['derived'] ? '≈' : '' ) . '%' ) . '</text>';
			$svg .= '<text x="' . $bar_x . '" y="' . ( $bar_top + 30 ) . '" font-size="11" fill="' . self::LEVEL_COLOURS[ $row['level'] ] . '" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( $row['label'] ) . '</text>';
		}

		$svg .= '</svg>';
		return $svg;
	}

	/**
	 * Radar ("spider") chart with a lettered legend beneath it. One spoke per
	 * assessed framework; radius is the readiness percent; colour is the
	 * readiness level. Vertices carry only a letter (a full framework name
	 * cannot fit at a vertex without crowding the diagram) - the legend below
	 * spells out "letter: name - level - percent" per row, word-wrapped like
	 * svg_bars() so a long standard name stays fully readable.
	 *
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	private static function svg_radar( array $rows ): string {
		$count        = count( $rows );
		$width        = 560;
		$radius       = 160.0;
		$top_margin   = 30;
		$cx           = $width / 2;
		$cy           = $top_margin + $radius;
		$chart_height = $cy + $radius + 30;

		// Legend geometry: each row needs one line per wrapped name segment
		// plus one summary line (level label + percent).
		$legend_lines_per_row = array_map( static fn( array $row ): array => self::wrap_text( $row['name'], 70 ), $rows );
		$legend_line_h        = 15;
		$legend_row_gap       = 8;
		$y                    = $chart_height + 16;
		$legend_rows_y        = [];
		foreach ( $legend_lines_per_row as $lines ) {
			$legend_rows_y[] = $y;
			$y              += ( count( $lines ) + 1 ) * $legend_line_h + $legend_row_gap;
		}
		$height = $y + 6;

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $width . ' ' . self::coord( $height ) . '" role="img" aria-label="Framework readiness radar" class="wpq-radar-svg">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . self::coord( $height ) . '" fill="#ffffff"/>';

		// Concentric guide rings at 25/50/75/100.
		foreach ( [ 25, 50, 75, 100 ] as $ring ) {
			$points = [];
			for ( $i = 0; $i < $count; $i++ ) {
				[ $x, $ry ] = self::point( $cx, $cy, $radius * $ring / 100, $i, $count );
				$points[]   = self::coord( $x ) . ',' . self::coord( $ry );
			}
			$svg .= '<polygon points="' . implode( ' ', $points ) . '" fill="none" stroke="#e3e6ea" stroke-width="1"/>';
			[ $lx, $ly ] = self::point( $cx, $cy, $radius * $ring / 100, 0, $count );
			$svg        .= '<text x="' . self::coord( $lx + 6 ) . '" y="' . self::coord( $ly + 4 ) . '" font-size="9" fill="#9aa3ad" font-family="Helvetica, Arial, sans-serif">' . $ring . '</text>';
		}

		// Spokes.
		for ( $i = 0; $i < $count; $i++ ) {
			[ $x, $ry ] = self::point( $cx, $cy, $radius, $i, $count );
			$svg       .= '<line x1="' . self::coord( $cx ) . '" y1="' . self::coord( $cy ) . '" x2="' . self::coord( $x ) . '" y2="' . self::coord( $ry ) . '" stroke="#e3e6ea" stroke-width="1"/>';
		}

		// Data polygon.
		$points = [];
		foreach ( $rows as $i => $row ) {
			[ $x, $ry ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$points[]   = self::coord( $x ) . ',' . self::coord( $ry );
		}
		$svg .= '<polygon points="' . implode( ' ', $points ) . '" fill="rgba(' . self::POLYGON_FILL . ',0.16)" stroke="rgba(' . self::POLYGON_FILL . ',0.55)" stroke-width="2"/>';

		// Colour-coded vertices, letter-labelled (matching WPQ_Domain_Radar's
		// scheme) with the full name/percent in a native SVG tooltip.
		foreach ( $rows as $i => $row ) {
			[ $x, $ry ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$letter     = self::letter_for_index( $i );
			$colour     = self::LEVEL_COLOURS[ $row['level'] ];
			$svg       .= '<circle cx="' . self::coord( $x ) . '" cy="' . self::coord( $ry ) . '" r="6" fill="' . $colour . '" stroke="#ffffff" stroke-width="2">'
				. '<title>' . self::escape( $letter . ': ' . $row['name'] . ' - ' . $row['percent'] . '%' ) . '</title></circle>';
			$svg       .= '<text x="' . self::coord( $x + 9 ) . '" y="' . self::coord( $ry - 9 ) . '" font-size="11" font-weight="700" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( $letter ) . '</text>';
		}

		// Legend: letter + wrapped name, then a level/percent summary line.
		foreach ( $rows as $i => $row ) {
			$lines  = $legend_lines_per_row[ $i ];
			$base_y = $legend_rows_y[ $i ];
			$colour = self::LEVEL_COLOURS[ $row['level'] ];
			foreach ( $lines as $li => $line ) {
				$prefix = 0 === $li ? self::letter_for_index( $i ) . ': ' : '';
				$svg   .= '<text x="12" y="' . self::coord( $base_y + $li * $legend_line_h + 11 ) . '" font-size="12" font-weight="600" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
					. self::escape( $prefix . $line ) . '</text>';
			}
			$summary_y = $base_y + count( $lines ) * $legend_line_h + 11;
			$svg      .= '<text x="12" y="' . self::coord( $summary_y ) . '" font-size="11" fill="' . $colour . '" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( $row['label'] . ' - ' . (string) $row['percent'] . ( $row['derived'] ? '≈' : '' ) . '%' ) . '</text>';
		}

		$svg .= '</svg>';
		return $svg;
	}

	/**
	 * GD-drawn PNG horizontal bar chart (mirrors the SVG). Returns null when
	 * GD is unavailable or drawing fails - callers must treat the image as
	 * optional.
	 *
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	public static function render_png( array $rows, int $width = 1120 ): ?string {
		if ( empty( $rows ) || ! function_exists( 'imagecreatetruecolor' ) ) {
			return null;
		}

		try {
			return self::png_bars( $rows, $width );
		} catch ( Throwable $e ) {
			return null;
		}
	}

	/** @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows */
	private static function png_bars( array $rows, int $width ): ?string {
		// Word-wrapped name lines determine each row's own height, since a
		// long framework name must stay fully readable rather than being
		// truncated with an ellipsis.
		$name_lines_per_row = array_map( static fn( array $row ): array => self::wrap_text( $row['name'], 55 ), $rows );
		$row_heights        = array_map( static fn( array $lines ): int => 60 + count( $lines ) * 24, $name_lines_per_row );
		$height             = 32 + array_sum( $row_heights );

		$img   = imagecreatetruecolor( $width, $height );
		$white = imagecolorallocate( $img, 255, 255, 255 );
		$track = imagecolorallocate( $img, 238, 241, 244 );
		$text  = imagecolorallocate( $img, 51, 65, 79 );
		imagefill( $img, 0, 0, $white );

		$bar_x    = 24;
		$bar_full = $width - 260;
		$top      = 32;
		foreach ( $rows as $i => $row ) {
			$colour     = self::png_level_colour( $img, $row['level'] );
			$name_lines = $name_lines_per_row[ $i ];
			foreach ( $name_lines as $li => $line ) {
				self::png_text( $img, 18, $bar_x, $top + 18 + $li * 24, $line, $text, true );
			}
			$bar_top = $top + 12 + count( $name_lines ) * 24;
			imagefilledrectangle( $img, $bar_x, $bar_top, $bar_x + $bar_full, $bar_top + 26, $track );
			imagefilledrectangle( $img, $bar_x, $bar_top, $bar_x + max( 14, (int) round( $bar_full * $row['percent'] / 100 ) ), $bar_top + 26, $colour );
			self::png_text( $img, 16, $bar_x + $bar_full + 16, $bar_top + 20, $row['label'] . ' (' . $row['percent'] . ( $row['derived'] ? '~' : '' ) . '%)', $text );
			$top += $row_heights[ $i ];
		}

		return self::png_output( $img );
	}

	/**
	 * Spreadsheet-style column letters for a 0-based row index (0 => 'A',
	 * 25 => 'Z', 26 => 'AA', ...), matching WPQ_Domain_Radar's scheme so a
	 * radar vertex can be identified without crowding the diagram with full
	 * names.
	 */
	private static function letter_for_index( int $index ): string {
		$index++;
		$letters = '';
		while ( $index > 0 ) {
			$remainder = ( $index - 1 ) % 26;
			$letters   = chr( 65 + $remainder ) . $letters;
			$index     = intdiv( $index - 1, 26 );
		}
		return $letters;
	}

	/** @return array{0: float, 1: float} */
	private static function point( float $cx, float $cy, float $r, int $index, int $count ): array {
		$angle = -M_PI / 2 + 2 * M_PI * $index / $count;
		return [ $cx + $r * cos( $angle ), $cy + $r * sin( $angle ) ];
	}

	private static function coord( float $value ): string {
		return rtrim( rtrim( sprintf( '%.1F', $value ), '0' ), '.' );
	}

	private static function escape( string $value ): string {
		return htmlspecialchars( $value, ENT_QUOTES | ENT_XML1, 'UTF-8' );
	}

	/**
	 * Greedy word-wrap for SVG text (which has no native wrapping) - splits
	 * on word boundaries only, so a long framework name wraps onto more
	 * lines rather than ever being cut with an ellipsis.
	 *
	 * @return array<int, string>
	 */
	private static function wrap_text( string $value, int $width ): array {
		$words = preg_split( '/\s+/', trim( $value ) ) ?: [ $value ];
		$lines = [];
		$line  = '';
		foreach ( $words as $word ) {
			$candidate = '' === $line ? $word : $line . ' ' . $word;
			if ( mb_strlen( $candidate ) > $width && '' !== $line ) {
				$lines[] = $line;
				$line    = $word;
			} else {
				$line = $candidate;
			}
		}
		if ( '' !== $line ) {
			$lines[] = $line;
		}
		return $lines ?: [ '' ];
	}

	/** @param resource|\GdImage $img */
	private static function png_level_colour( $img, string $level ): int {
		$hex = self::LEVEL_COLOURS[ $level ] ?? self::LEVEL_COLOURS['insufficient_evidence'];
		return imagecolorallocate(
			$img,
			(int) hexdec( substr( $hex, 1, 2 ) ),
			(int) hexdec( substr( $hex, 3, 2 ) ),
			(int) hexdec( substr( $hex, 5, 2 ) )
		);
	}

	private static function ttf_path(): string {
		$candidates = [
			WPQ_PLUGIN_DIR . 'vendor/dompdf/dompdf/lib/fonts/DejaVuSans.ttf',
			WPQ_PLUGIN_DIR . 'vendor/dompdf/dompdf/lib/fonts/DejaVuSans-Bold.ttf',
		];
		foreach ( $candidates as $candidate ) {
			if ( is_readable( $candidate ) ) {
				return $candidate;
			}
		}
		return '';
	}

	/** @param resource|\GdImage $img */
	private static function png_text( $img, int $size, int $x, int $y, string $text, int $colour, bool $bold = false ): void {
		$font = self::ttf_path();
		if ( '' !== $font && function_exists( 'imagettftext' ) ) {
			imagettftext( $img, $size, 0, $x, $y, $colour, $font, $text );
			if ( $bold ) {
				imagettftext( $img, $size, 0, $x + 1, $y, $colour, $font, $text );
			}
			return;
		}
		imagestring( $img, $bold ? 5 : 4, $x, $y - 12, $text, $colour );
	}

	/** @param resource|\GdImage $img */
	private static function png_output( $img ): ?string {
		ob_start();
		$ok     = imagepng( $img );
		$binary = ob_get_clean();
		imagedestroy( $img );
		return ( $ok && is_string( $binary ) && '' !== $binary ) ? $binary : null;
	}
}
