<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Assesses a completed submission's readiness against the frameworks selected
 * for its questionnaire, using the ATLAS skill registered for each framework.
 *
 * Each framework is assessed in its own beta Messages call with the framework's
 * Anthropic skill attached via `container.skills` (which requires the
 * code-execution tool - skills execute inside the container). The response is
 * a strict JSON posture assessment; every control reference it cites is
 * validated against the framework's imported catalogue, the same
 * anti-hallucination pattern used for `related_finding_ids`.
 *
 * Readiness is an enhancement to the Questionnaire Report: a framework whose
 * assessment fails is skipped (logged, never fatal), and a questionnaire with
 * no selected or registered frameworks simply produces no frameworks section.
 */
class WPQ_Framework_Readiness {

	public const PROMPT_VERSION = 'framework-readiness-v1';

	private const API_URL     = 'https://api.anthropic.com/v1/messages';
	private const API_VERSION = '2023-06-01';
	private const BETA_HEADER = 'code-execution-2025-08-25,skills-2025-10-02';

	/** Cost/latency guard: a report assesses at most this many frameworks. */
	public const MAX_FRAMEWORKS = 8;

	public const READINESS_LEVELS = [ 'aligned', 'partially_aligned', 'not_aligned', 'insufficient_evidence' ];

	private const LEVEL_LABELS = [
		'aligned'               => 'Aligned',
		'partially_aligned'     => 'Partially aligned',
		'not_aligned'           => 'Not aligned',
		'insufficient_evidence' => 'Insufficient evidence',
	];

	/**
	 * Assess the submission context against every selected, Anthropic-registered
	 * framework. Returns one row per successful assessment, in selection order.
	 *
	 * @param array<string, mixed> $context The questionnaire report context.
	 * @return array<int, array<string, mixed>>
	 */
	public static function assess_for_questionnaire( object $questionnaire, array $context ): array {
		$frameworks = self::resolve_attempted_frameworks( $questionnaire );

		$results = [];
		foreach ( $frameworks as $framework ) {
			try {
				$results[] = self::assess_framework( $framework, $context );
			} catch ( Throwable $e ) {
				self::log_debug_event( 'framework_readiness_failed', [
					'framework_id' => (int) $framework->id,
					'slug'         => (string) $framework->slug,
					'error_type'   => get_class( $e ),
					'error'        => $e->getMessage(),
				] );
			}
		}

		return $results;
	}

	/**
	 * Same assessment as assess_for_questionnaire(), but fires every framework's
	 * Claude call concurrently via curl_multi rather than one after another -
	 * worst case is bounded by the single slowest call rather than the sum of
	 * all of them. Falls back to the sequential path entirely when curl_multi
	 * isn't usable on this host (hardened hosts sometimes disable it, same as
	 * proc_open - see WPQ_LibreOffice_Pdf_Converter::proc_open_available()).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function assess_for_questionnaire_concurrent( object $questionnaire, array $context ): array {
		if ( ! self::curl_multi_available() ) {
			return self::assess_for_questionnaire( $questionnaire, $context );
		}

		$frameworks = self::resolve_attempted_frameworks( $questionnaire );
		if ( empty( $frameworks ) ) {
			return [];
		}

		$details = WPQ_Remediation_Plan::get_api_key_details();
		$api_key = (string) ( $details['value'] ?? '' );
		if ( '' === $api_key ) {
			self::log_debug_event( 'framework_readiness_failed', [ 'error_type' => 'RuntimeException', 'error' => 'Claude API key missing.' ] );
			return [];
		}
		$model      = WPQ_Remediation_Plan::select_model( $api_key );
		$max_tokens = WPQ_Remediation_Plan::get_max_tokens_preference();
		$timeout    = WPQ_Remediation_Plan::timeout_for_max_tokens( $max_tokens );

		$multi   = curl_multi_init();
		$handles = [];

		foreach ( $frameworks as $framework ) {
			try {
				$request = self::build_request( $framework, $context, $api_key, $model );
			} catch ( Throwable $e ) {
				self::log_debug_event( 'framework_readiness_failed', [
					'framework_id' => (int) $framework->id,
					'slug'         => (string) $framework->slug,
					'error_type'   => get_class( $e ),
					'error'        => $e->getMessage(),
				] );
				continue;
			}

			self::log_debug_event( 'framework_readiness_request', [
				'framework_id' => (int) $framework->id,
				'slug'         => (string) $framework->slug,
				'skill_id'     => (string) $framework->skill_id,
				'model'        => $model,
				'concurrent'   => true,
			] );

			$ch = curl_init( $request['url'] );
			curl_setopt_array( $ch, [
				CURLOPT_POST           => true,
				CURLOPT_POSTFIELDS     => $request['body'],
				CURLOPT_HTTPHEADER     => self::flatten_headers( $request['headers'] ),
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_TIMEOUT        => $timeout,
				CURLOPT_SSL_VERIFYPEER => true,
				CURLOPT_SSL_VERIFYHOST => 2,
			] );
			self::apply_ca_bundle( $ch );
			curl_multi_add_handle( $multi, $ch );
			$handles[] = [ 'ch' => $ch, 'framework' => $framework ];
		}

		$started = microtime( true );
		$running = null;
		do {
			$status = curl_multi_exec( $multi, $running );
			if ( $running ) {
				curl_multi_select( $multi, 1.0 );
			}
		} while ( $running > 0 && CURLM_OK === $status );
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		$results = [];
		foreach ( $handles as $entry ) {
			$ch        = $entry['ch'];
			$framework = $entry['framework'];
			$body_text = (string) curl_multi_getcontent( $ch );
			$errno     = curl_errno( $ch );
			$code      = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
			// No curl_close() - a no-op since PHP 8 (curl handles are objects,
			// garbage-collected once curl_multi_remove_handle() drops the ref).
			curl_multi_remove_handle( $multi, $ch );

			self::log_debug_event( 'framework_readiness_response', [
				'framework_id' => (int) $framework->id,
				'slug'         => (string) $framework->slug,
				'status_code'  => $code,
				// Concurrent calls share a wall-clock window rather than each
				// having its own elapsed time - labelled as such, not per-call.
				'batch_elapsed_ms' => $elapsed_ms,
				'body_chars'   => strlen( $body_text ),
			] );

			if ( 0 !== $errno ) {
				self::log_debug_event( 'framework_readiness_failed', [
					'framework_id' => (int) $framework->id,
					'slug'         => (string) $framework->slug,
					'error_type'   => 'CurlError',
					'error'        => 'curl error ' . $errno . ( function_exists( 'curl_strerror' ) ? ': ' . curl_strerror( $errno ) : '' ),
				] );
				continue;
			}

			try {
				$results[] = self::handle_response( $framework, $code, $body_text, $max_tokens );
			} catch ( Throwable $e ) {
				self::log_debug_event( 'framework_readiness_failed', [
					'framework_id' => (int) $framework->id,
					'slug'         => (string) $framework->slug,
					'error_type'   => get_class( $e ),
					'error'        => $e->getMessage(),
				] );
			}
		}

		curl_multi_close( $multi );

		return $results;
	}

	/**
	 * Whether this host's PHP configuration allows firing concurrent cURL
	 * requests. Hardened shared hosting sometimes disables curl_multi_* via
	 * disable_functions - the same category of restriction as proc_open (see
	 * WPQ_LibreOffice_Pdf_Converter::proc_open_available()).
	 */
	public static function curl_multi_available(): bool {
		$required = [ 'curl_init', 'curl_multi_init', 'curl_multi_add_handle', 'curl_multi_exec', 'curl_multi_select', 'curl_setopt_array' ];
		foreach ( $required as $fn ) {
			if ( ! function_exists( $fn ) ) {
				return false;
			}
		}

		$disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
		foreach ( $required as $fn ) {
			if ( in_array( $fn, $disabled, true ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Resolve the questionnaire's selected framework IDs down to the
	 * Anthropic-registered rows actually worth attempting, logging (never
	 * throwing) every reason a selection didn't make it into the result:
	 * the MAX_FRAMEWORKS cost/latency cap, and a framework whose skill_id
	 * isn't registered (deleted, or never finished import).
	 *
	 * @return array<int, object>
	 */
	private static function resolve_attempted_frameworks( object $questionnaire ): array {
		$framework_ids = self::selected_framework_ids( $questionnaire );
		if ( empty( $framework_ids ) ) {
			return [];
		}

		$attempted_ids = array_slice( $framework_ids, 0, self::MAX_FRAMEWORKS );
		$dropped_ids   = array_slice( $framework_ids, self::MAX_FRAMEWORKS );
		if ( ! empty( $dropped_ids ) ) {
			// No per-framework identity here (a truncated ID may not even exist)
			// - this only needs to explain a "fewer results than selected" count.
			self::log_debug_event( 'framework_readiness_capped', [
				'questionnaire_id' => (int) ( $questionnaire->id ?? 0 ),
				'selected_count'   => count( $framework_ids ),
				'max_frameworks'   => self::MAX_FRAMEWORKS,
				'dropped_ids'      => $dropped_ids,
			] );
		}

		$frameworks = [];
		foreach ( $attempted_ids as $framework_id ) {
			$framework = WPQ_Database::get_framework( $framework_id );
			if ( ! $framework || '' === trim( (string) ( $framework->skill_id ?? '' ) ) ) {
				self::log_debug_event( 'framework_readiness_skipped', [
					'framework_id' => $framework_id,
					'slug'         => $framework ? (string) $framework->slug : null,
					'reason'       => $framework ? 'not_registered_with_skills_api' : 'framework_not_found',
				] );
				continue; // Not imported, or not registered with the Skills API yet.
			}
			$frameworks[] = $framework;
		}

		return $frameworks;
	}

	/** @return array<int, string> */
	private static function flatten_headers( array $headers ): array {
		$out = [];
		foreach ( $headers as $key => $value ) {
			$out[] = $key . ': ' . $value;
		}
		return $out;
	}

	/** @param \CurlHandle|resource $ch */
	private static function apply_ca_bundle( $ch ): void {
		// Mirrors WP_Http_Curl's own CA bundle so verification doesn't depend
		// on this host's system bundle being present/current - never disables
		// verification, only points it at a known-good bundle when one exists.
		$bundle = defined( 'ABSPATH' ) && defined( 'WPINC' ) ? ABSPATH . WPINC . '/certificates/ca-bundle.crt' : '';
		if ( '' !== $bundle && is_readable( $bundle ) ) {
			curl_setopt( $ch, CURLOPT_CAINFO, $bundle );
		}
	}

	/** @return array<int, int> */
	public static function selected_framework_ids( object $questionnaire ): array {
		$raw = trim( (string) ( $questionnaire->framework_ids ?? '' ) );
		if ( '' === $raw ) {
			return [];
		}
		$ids = [];
		foreach ( explode( ',', $raw ) as $part ) {
			$id = (int) trim( $part );
			if ( $id > 0 && ! in_array( $id, $ids, true ) ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	/**
	 * One framework, one call, one validated assessment row.
	 *
	 * @param array<string, mixed> $context
	 * @return array<string, mixed>
	 */
	public static function assess_framework( object $framework, array $context ): array {
		$details = WPQ_Remediation_Plan::get_api_key_details();
		$api_key = (string) ( $details['value'] ?? '' );
		if ( '' === $api_key ) {
			throw new RuntimeException( 'Claude API key missing.' );
		}

		$model      = WPQ_Remediation_Plan::select_model( $api_key );
		$max_tokens = WPQ_Remediation_Plan::get_max_tokens_preference();
		$request    = self::build_request( $framework, $context, $api_key, $model );

		self::log_debug_event( 'framework_readiness_request', [
			'framework_id' => (int) $framework->id,
			'slug'         => (string) $framework->slug,
			'skill_id'     => (string) $framework->skill_id,
			'model'        => $model,
		] );

		$started  = microtime( true );
		$response = wp_remote_post( $request['url'], [
			'timeout' => WPQ_Remediation_Plan::timeout_for_max_tokens( $max_tokens ),
			'headers' => $request['headers'],
			'body'    => $request['body'],
		] );
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'Readiness request failed: ' . esc_html( $response->get_error_message() ) );
		}

		$code      = (int) wp_remote_retrieve_response_code( $response );
		$body_text = wp_remote_retrieve_body( $response );

		self::log_debug_event( 'framework_readiness_response', [
			'framework_id' => (int) $framework->id,
			'slug'         => (string) $framework->slug,
			'status_code'  => $code,
			'elapsed_ms'   => $elapsed_ms,
			'body_chars'   => strlen( $body_text ),
		] );

		return self::handle_response( $framework, $code, $body_text, $max_tokens );
	}

	/**
	 * Builds the Messages API request for one framework, shared by both the
	 * sequential (wp_remote_post) and concurrent (curl_multi) call paths.
	 *
	 * @param array<string, mixed> $context
	 * @return array{url: string, headers: array<string,string>, body: string}
	 */
	private static function build_request( object $framework, array $context, string $api_key, string $model ): array {
		$payload = self::build_payload( $framework, $context, $model );
		$encoded = wp_json_encode( $payload );
		if ( ! is_string( $encoded ) || '' === $encoded ) {
			throw new RuntimeException( 'Readiness request payload could not be encoded.' );
		}

		return [
			'url'     => self::API_URL,
			'headers' => [
				'content-type'      => 'application/json',
				'x-api-key'         => $api_key,
				'anthropic-version' => self::API_VERSION,
				'anthropic-beta'    => self::BETA_HEADER,
			],
			'body'    => $encoded,
		];
	}

	/**
	 * Turns a raw HTTP status + body into a validated assessment row, shared by
	 * both call paths. Throws on any failure - never returns a partial row.
	 */
	private static function handle_response( object $framework, int $code, string $body_text, int $max_tokens ): array {
		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( 'Readiness request returned HTTP ' . (int) $code . '.' );
		}

		$body = json_decode( $body_text, true );
		if ( ! is_array( $body ) ) {
			throw new RuntimeException( 'Readiness response was not JSON.' );
		}

		if ( ( $body['stop_reason'] ?? '' ) === 'max_tokens' ) {
			// The direct signal that generation was cut off mid-response, not
			// left to be inferred from "JSON failed to parse" after the fact -
			// the response then always fails JSON parsing anyway, since the
			// output stops wherever the token ceiling landed. The skill's own
			// code-execution steps share this same budget with the final
			// answer, so which framework hits this varies run to run.
			self::log_debug_event( 'framework_readiness_truncated', [
				'framework_id' => (int) $framework->id,
				'slug'         => (string) $framework->slug,
				'max_tokens'   => $max_tokens,
				'note'         => 'Response hit the output-token ceiling before the assessment finished; raise the Max output tokens setting in Settings -> AI.',
			] );
		}

		$text = '';
		foreach ( $body['content'] ?? [] as $part ) {
			if ( is_array( $part ) && ( $part['type'] ?? '' ) === 'text' ) {
				$text .= (string) ( $part['text'] ?? '' );
			}
		}

		$known_refs = self::known_control_refs( (int) $framework->id );
		$assessment = self::parse_and_validate( $text, $known_refs );

		$assessment['framework_id'] = (int) $framework->id;
		$assessment['slug']         = (string) $framework->slug;
		$assessment['name']         = (string) $framework->name;

		return $assessment;
	}

	/**
	 * The Messages API request. The framework's skill rides in
	 * `container.skills` and executes through the code-execution tool; both
	 * beta flags are required.
	 *
	 * @param array<string, mixed> $context
	 * @return array<string, mixed>
	 */
	public static function build_payload( object $framework, array $context, string $model ): array {
		return [
			'model'      => $model,
			// Shared with the Questionnaire Report/Remediation Plan (Settings ->
			// AI): the code-execution skill's own intermediate tool/code steps
			// consume the same output-token budget as the final JSON answer, so
			// a framework-specific ceiling here previously truncated whichever
			// framework's skill happened to need more of that budget on a given
			// run - not a fixed set of "problem" frameworks (fixed after 4000
			// caused intermittent "Readiness response was not valid JSON").
			'max_tokens' => WPQ_Remediation_Plan::get_max_tokens_preference(),
			'container'  => [
				'skills' => [
					[
						'type'     => 'custom',
						'skill_id' => (string) $framework->skill_id,
						'version'  => '' !== trim( (string) ( $framework->skill_version ?? '' ) ) ? (string) $framework->skill_version : 'latest',
					],
				],
			],
			'tools'      => [
				[ 'type' => 'code_execution_20260521', 'name' => 'code_execution' ],
			],
			'system'     => 'You are a senior compliance assessor. Use the attached ' . (string) $framework->name
				. ' skill to assess the organisation\'s formal posture against that standard, based only on the '
				. 'questionnaire evidence provided. Cite the standard\'s own control/clause references. Do not '
				. 'invent evidence; where the questionnaire does not cover a control, treat it as unassessed '
				. 'rather than failed. Return only valid JSON matching the requested schema.',
			'messages'   => [
				[ 'role' => 'user', 'content' => self::build_prompt( $framework, $context ) ],
			],
		];
	}

	/** @param array<string, mixed> $context */
	public static function build_prompt( object $framework, array $context ): string {
		$schema = wp_json_encode( [
			'readiness_level'   => 'aligned|partially_aligned|not_aligned|insufficient_evidence',
			'readiness_percent' => 'integer 0-100, or null unless the standard\'s own methodology yields a defensible figure',
			'summary'           => 'string - 2-4 sentences on formal posture against the standard',
			'strengths'         => [ [ 'control_ref' => 'string - the standard\'s own reference', 'note' => 'string' ] ],
			'gaps'              => [ [ 'control_ref' => 'string', 'gap' => 'string', 'recommendation' => 'string' ] ],
		] );

		$payload = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		return 'Assess this organisation\'s posture against ' . (string) $framework->name . ".\n"
			. "Return strict JSON only, matching exactly this shape (arrays may be empty but must be present):\n{$schema}\n"
			. "Set readiness_percent to null unless the standard's methodology produces a defensible percentage - never estimate one.\n"
			. "Do not include markdown or text outside the JSON object.\n"
			. "Questionnaire evidence JSON:\n{$payload}";
	}

	/**
	 * @param array<int, string> $known_refs Lower-cased control refs from the imported catalogue.
	 * @return array<string, mixed>
	 */
	public static function parse_and_validate( string $text, array $known_refs ): array {
		$text = trim( $text );
		if ( '' === $text ) {
			throw new RuntimeException( 'Readiness response was empty.' );
		}

		$decoded = json_decode( $text, true );
		if ( ! is_array( $decoded ) && preg_match( '/\{.*\}/s', $text, $matches ) ) {
			$decoded = json_decode( $matches[0], true );
		}
		if ( ! is_array( $decoded ) ) {
			throw new RuntimeException( 'Readiness response was not valid JSON.' );
		}

		$level = strtolower( trim( (string) ( $decoded['readiness_level'] ?? '' ) ) );
		if ( ! in_array( $level, self::READINESS_LEVELS, true ) ) {
			$level = 'insufficient_evidence';
		}

		$percent = null;
		if ( isset( $decoded['readiness_percent'] ) && is_numeric( $decoded['readiness_percent'] ) ) {
			$percent = max( 0, min( 100, (int) $decoded['readiness_percent'] ) );
		}

		$summary = sanitize_textarea_field( (string) ( $decoded['summary'] ?? '' ) );
		if ( '' === $summary ) {
			throw new RuntimeException( 'Readiness response is missing a summary.' );
		}

		return [
			'readiness_level' => $level,
			'readiness_label' => self::LEVEL_LABELS[ $level ],
			'readiness_percent' => $percent,
			'summary'         => $summary,
			'strengths'       => self::sanitise_ref_rows( $decoded['strengths'] ?? [], $known_refs, [ 'note' ] ),
			'gaps'            => self::sanitise_ref_rows( $decoded['gaps'] ?? [], $known_refs, [ 'gap', 'recommendation' ] ),
		];
	}

	/**
	 * Sanitise rows carrying a control_ref plus text fields. A cited ref that
	 * does not exist in the imported catalogue is cleared (never shown to a
	 * client as if it were real) while the row's substance is kept. When the
	 * catalogue is empty (metadata-only frameworks such as ITIL), refs pass
	 * through untouched - there is nothing to validate against.
	 *
	 * @param array<int, string> $known_refs
	 * @param array<int, string> $text_fields
	 * @return array<int, array<string, string>>
	 */
	private static function sanitise_ref_rows( mixed $rows, array $known_refs, array $text_fields ): array {
		if ( ! is_array( $rows ) ) {
			return [];
		}

		$out = [];
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$clean = [];
			$has_text = false;
			foreach ( $text_fields as $field ) {
				$value = sanitize_textarea_field( (string) ( $row[ $field ] ?? '' ) );
				$clean[ $field ] = $value;
				if ( '' !== $value ) {
					$has_text = true;
				}
			}
			if ( ! $has_text ) {
				continue;
			}

			$ref = sanitize_text_field( (string) ( $row['control_ref'] ?? '' ) );
			if ( ! empty( $known_refs ) && '' !== $ref && ! in_array( strtolower( $ref ), $known_refs, true ) ) {
				$ref = '';
			}
			$clean['control_ref'] = mb_substr( $ref, 0, 50 );

			$out[] = $clean;
		}

		return $out;
	}

	/** @return array<int, string> */
	public static function known_control_refs( int $framework_id ): array {
		$refs = [];
		foreach ( WPQ_Database::get_framework_controls( $framework_id ) as $control ) {
			$ref = strtolower( trim( (string) ( $control->control_ref ?? '' ) ) );
			if ( '' !== $ref ) {
				$refs[] = $ref;
			}
		}
		return $refs;
	}

	private static function log_debug_event( string $event, array $data = [] ): void {
		if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' )
			&& WPQ_Questionnaire_Report_Analysis::debug_logging_enabled()
			&& method_exists( 'WPQ_Remediation_Plan', 'get_api_key_details' ) ) {
			// Reuse the shared Claude debug log via the analysis class's channel.
			$log   = get_option( 'wpq_claude_debug_log', [] );
			$log   = is_array( $log ) ? $log : [];
			array_unshift( $log, [
				'time'  => current_time( 'mysql', true ),
				'event' => sanitize_key( $event ),
				'data'  => $data,
			] );
			update_option( 'wpq_claude_debug_log', array_slice( $log, 0, 50 ), false );
		}
	}
}
