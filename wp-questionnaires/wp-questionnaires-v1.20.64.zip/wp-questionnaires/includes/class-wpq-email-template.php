<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Renders every outbound email through an XML Transform stylesheet.
 *
 * Callers build a small associative array describing the email's content
 * (title, intro paragraphs, an optional call-to-action link, a details
 * table, a footnote); render() turns that into a small <email> XML document
 * and runs it through templates/email/email.xsl, which applies the
 * Alltime Technologies Ltd branding and the shared signature
 * (templates/email/signature.xsl) - the same look as templates/test_email.html.
 *
 * Every text value is written via DOMDocument::createTextNode(), so any
 * markup a caller passes through (an enquiry form's free-text fields, a
 * contact's name) is escaped rather than interpreted - the resulting HTML
 * cannot be used to inject scripts or extra markup into the email body.
 *
 * Recognised $fields keys (all optional except 'title'):
 *   subject         string   <title> of the HTML document (defaults to the mail subject)
 *   badge           string   small pill shown top-right of the header
 *   department      string   sub-line under the company name, and the signature's job title
 *   title           string   large coloured heading
 *   recipient_line  string   small italic line under the title
 *   intro           string|array  one or more body paragraphs
 *   cta_url         string   call-to-action link URL
 *   cta_label       string   call-to-action link text (required when cta_url is set)
 *   details         array    label => value rows rendered as a two-column table
 *   footnote        string   small print under the details table
 */
class WPQ_Email_Template {

	private const LAYOUT_DIR = WPQ_PLUGIN_DIR . 'templates/email/';
	private const DEFAULT_LAYOUT = 'email.xsl';

	/** Whether the PHP xsl extension needed to render templates is loaded. */
	public static function available(): bool {
		return class_exists( 'XSLTProcessor' ) && class_exists( 'DOMDocument' );
	}

	/**
	 * @param array<string, mixed> $fields
	 * @throws RuntimeException When the xsl extension is missing or the transform fails.
	 */
	public static function render( array $fields, string $layout = self::DEFAULT_LAYOUT ): string {
		if ( ! self::available() ) {
			throw new RuntimeException( 'The PHP xsl extension is required to render email templates - ask your host to enable it (see Settings -> Readiness).' );
		}

		$stylesheet_path = self::LAYOUT_DIR . basename( $layout );
		if ( ! is_file( $stylesheet_path ) ) {
			throw new RuntimeException( 'Email template not found: ' . esc_html( $layout ) );
		}

		$xsl_doc = new DOMDocument();
		libxml_use_internal_errors( true );
		$loaded = $xsl_doc->load( $stylesheet_path );
		libxml_use_internal_errors( false );
		if ( ! $loaded ) {
			throw new RuntimeException( 'Email template could not be parsed: ' . esc_html( $layout ) );
		}

		$processor = new XSLTProcessor();
		$processor->importStylesheet( $xsl_doc );

		$html = $processor->transformToXml( self::build_xml( $fields ) );
		if ( false === $html ) {
			throw new RuntimeException( 'Email template transform failed: ' . esc_html( $layout ) );
		}

		return $html;
	}

	/** @param array<string, mixed> $fields */
	private static function build_xml( array $fields ): DOMDocument {
		$doc  = new DOMDocument( '1.0', 'UTF-8' );
		$root = $doc->createElement( 'email' );
		$doc->appendChild( $root );

		$text = static function ( string $name, string $value ) use ( $doc, $root ): void {
			if ( '' === $value ) {
				return;
			}
			$el = $doc->createElement( $name );
			$el->appendChild( $doc->createTextNode( $value ) );
			$root->appendChild( $el );
		};

		foreach ( [ 'subject', 'badge', 'department', 'title', 'recipient_line', 'cta_url', 'cta_label', 'footnote' ] as $key ) {
			if ( isset( $fields[ $key ] ) ) {
				$text( $key, (string) $fields[ $key ] );
			}
		}

		if ( ! empty( $fields['intro'] ) ) {
			$paragraphs = is_array( $fields['intro'] ) ? $fields['intro'] : [ $fields['intro'] ];
			$intro_el   = $doc->createElement( 'intro' );
			foreach ( $paragraphs as $paragraph ) {
				$paragraph = trim( (string) $paragraph );
				if ( '' === $paragraph ) {
					continue;
				}
				$p_el = $doc->createElement( 'p' );
				$p_el->appendChild( $doc->createTextNode( $paragraph ) );
				$intro_el->appendChild( $p_el );
			}
			$root->appendChild( $intro_el );
		}

		if ( ! empty( $fields['details'] ) && is_array( $fields['details'] ) ) {
			$details_el = $doc->createElement( 'details' );
			foreach ( $fields['details'] as $label => $value ) {
				if ( is_array( $value ) ) {
					$value = implode( ', ', $value );
				}
				$value = trim( (string) $value );
				if ( '' === $value ) {
					continue;
				}
				$item_el = $doc->createElement( 'item' );
				$item_el->setAttribute( 'label', (string) $label );
				$item_el->appendChild( $doc->createTextNode( $value ) );
				$details_el->appendChild( $item_el );
			}
			$root->appendChild( $details_el );
		}

		return $doc;
	}
}
