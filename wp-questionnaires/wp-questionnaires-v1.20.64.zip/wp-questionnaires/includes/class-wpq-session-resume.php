<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Save-and-resume for in-progress assessments.
 *
 * A customer part-way through a questionnaire can request a resume link
 * (shown on screen and optionally emailed). The link carries a hashed,
 * expiring, purpose-scoped token - the same token infrastructure as report
 * delivery - never the session token itself, so the session credential is
 * never exposed in a URL, mailbox, or server log.
 *
 * Redeeming the link **rotates** the submission's session token: the client
 * gets a fresh credential and continues where it left off. Rotation is what
 * makes resume survive plugin updates too - migrations deliberately blank
 * in-progress session tokens, and a rotated token repairs exactly that.
 *
 * Server-side progress comes from the heartbeat, which (as of this class)
 * carries the partial answers, not just a position marker.
 */
class WPQ_Session_Resume {

	public const TOKEN_PURPOSE = 'resume';

	/** A resume link outlives a busy fortnight; abandoned-data purges still apply. */
	public const TOKEN_TTL_SECONDS = 30 * DAY_IN_SECONDS;

	/** Clicking the link many times is normal (email clients prefetch, retries). */
	public const TOKEN_MAX_USES = 25;

	private const MAX_ANSWER_ENTRIES      = 400;
	private const MAX_ANSWER_VALUE_CHARS  = 2000;
	private const MAX_ANSWER_LIST_ITEMS   = 50;

	// ------------------------------------------------------------------ //
	// Link creation
	// ------------------------------------------------------------------ //

	/**
	 * Mint a resume URL for an in-progress submission, anchored to the page
	 * the assessment lives on.
	 *
	 * @return array{url: string, expires_days: int}
	 */
	public static function mint_link( object $submission, string $page_url ): array {
		if ( ! empty( $submission->completed_at ) ) {
			throw new RuntimeException( 'This assessment has already been completed.' );
		}

		$base = self::validate_page_url( $page_url );
		if ( null === $base ) {
			throw new RuntimeException( 'The resume link must point at a page on this site.' );
		}

		$token = WPQ_Database::create_report_token(
			(int) $submission->id,
			self::TOKEN_TTL_SECONDS,
			self::TOKEN_MAX_USES,
			self::TOKEN_PURPOSE
		);
		if ( empty( $token['token'] ) ) {
			throw new RuntimeException( 'Could not create a resume link.' );
		}

		return [
			'url'          => add_query_arg( [ 'wpq_resume' => (string) $token['token'] ], $base ),
			'expires_days' => (int) round( self::TOKEN_TTL_SECONDS / DAY_IN_SECONDS ),
		];
	}

	/**
	 * The resume link is only ever anchored to a same-site page: scheme and
	 * host must match the site's own, and stale resume/utm parameters are
	 * stripped so redeeming doesn't re-trigger attribution or old tokens.
	 * Returns null when the URL cannot be trusted.
	 */
	public static function validate_page_url( string $page_url ): ?string {
		$page_url = trim( $page_url );
		if ( '' === $page_url ) {
			return null;
		}

		$parts = wp_parse_url( $page_url );
		$home  = wp_parse_url( home_url() );
		if ( ! is_array( $parts ) || ! is_array( $home ) ) {
			return null;
		}
		if ( ! in_array( strtolower( (string) ( $parts['scheme'] ?? '' ) ), [ 'http', 'https' ], true ) ) {
			return null;
		}
		if ( strtolower( (string) ( $parts['host'] ?? '' ) ) !== strtolower( (string) ( $home['host'] ?? '' ) ) ) {
			return null;
		}

		$clean = ( (string) $parts['scheme'] ) . '://' . ( (string) $parts['host'] )
			. ( isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '' )
			. ( (string) ( $parts['path'] ?? '/' ) );

		if ( ! empty( $parts['query'] ) ) {
			parse_str( (string) $parts['query'], $query );
			unset( $query['wpq_resume'] );
			foreach ( array_keys( $query ) as $key ) {
				if ( str_starts_with( (string) $key, 'utm_' ) ) {
					unset( $query[ $key ] );
				}
			}
			if ( ! empty( $query ) ) {
				$clean = add_query_arg( array_map( 'sanitize_text_field', $query ), $clean );
			}
		}

		return $clean;
	}

	/** Email the resume link to the submission's contact, respecting the questionnaire's mail gate. */
	public static function email_link( object $submission, string $url, int $expires_days ): bool {
		$email = sanitize_email( (string) ( $submission->contact_email ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return false;
		}

		if ( class_exists( 'WPQ_Mailer' ) ) {
			$questionnaire_id = (int) ( $submission->questionnaire_id ?? 0 );
			$questionnaire    = $questionnaire_id > 0 ? WPQ_Database::get_questionnaire( $questionnaire_id ) : null;
			if ( ! WPQ_Mailer::allowed_for_questionnaire( $questionnaire ) ) {
				return false;
			}
		}

		$name    = trim( (string) ( $submission->contact_name ?? '' ) );
		$subject = 'Continue your assessment';

		if ( class_exists( 'WPQ_Mailer' ) && class_exists( 'WPQ_Email_Template' ) ) {
			try {
				$html = WPQ_Email_Template::render( [
					'subject'        => $subject,
					'title'          => 'Continue Your Assessment',
					'recipient_line' => '' !== $name ? 'Hello ' . $name : '',
					'intro'          => 'Your assessment has been saved. Pick up exactly where you left off using the link below.',
					'cta_url'        => $url,
					'cta_label'      => 'Resume your assessment',
					'footnote'       => sprintf( 'The link is personal to you and expires in %d days.', $expires_days ),
				] );
			} catch ( Throwable $e ) {
				update_option( 'wpq_mail_last_error', sanitize_text_field( gmdate( 'Y-m-d H:i:s' ) . ' UTC ' . $e->getMessage() ), false );
				return false;
			}
			return WPQ_Mailer::send( $email, $subject, $html );
		}

		$body = ( '' !== $name ? 'Hello ' . $name . ',' : 'Hello,' ) . "\n\n"
			. "Your assessment has been saved. Pick up exactly where you left off using this link:\n\n"
			. $url . "\n\n"
			. sprintf( 'The link is personal to you and expires in %d days.', $expires_days ) . "\n";

		return (bool) wp_mail(
			$email,
			$subject,
			$body,
			[ 'Content-Type: text/plain; charset=UTF-8' ]
		);
	}

	// ------------------------------------------------------------------ //
	// Redemption
	// ------------------------------------------------------------------ //

	/**
	 * Redeem a resume token: rotate the session credential and return
	 * everything the front end needs to hydrate.
	 *
	 * @return array{status: string, submission_id?: int, session_token?: string, questionnaire_ref?: string, answers?: array<string, mixed>, last_question_answered?: string}
	 */
	public static function redeem( string $raw_token ): array {
		$raw_token = trim( $raw_token );
		if ( '' === $raw_token ) {
			throw new RuntimeException( 'A resume token is required.' );
		}

		$token = WPQ_Database::get_report_token( $raw_token );
		if ( ! $token || self::TOKEN_PURPOSE !== (string) ( $token->purpose ?? '' ) ) {
			throw new RuntimeException( 'This resume link is not valid.' );
		}

		$submission = WPQ_Database::get_submission( (int) $token->submission_id );
		if ( ! $submission ) {
			throw new RuntimeException( 'This assessment is no longer available.' );
		}

		if ( ! empty( $submission->completed_at ) ) {
			return [ 'status' => 'completed' ];
		}

		$consumed = WPQ_Database::consume_report_token( (int) $submission->id, $raw_token, self::TOKEN_PURPOSE );
		if ( ! $consumed ) {
			throw new RuntimeException( 'This resume link has expired.' );
		}

		// Rotate the session credential: the resume token proves possession of
		// the emailed link; the fresh session token is what authorises the
		// continued session. This also revives sessions whose tokens were
		// blanked by a plugin-update migration.
		$new_token = bin2hex( random_bytes( 32 ) );
		$updated   = WPQ_Database::update_submission( (int) $submission->id, [
			'session_token' => hash_hmac( 'sha256', $new_token, wp_salt( 'auth' ) ),
			'abandoned'     => 0,
		] );
		if ( ! $updated ) {
			throw new RuntimeException( 'Could not resume this assessment.' );
		}

		return self::progress_payload( $submission, $new_token );
	}

	/**
	 * Progress for a client that already holds a valid session token (the
	 * same-device "continue where you left off" path). No rotation.
	 *
	 * @return array{status: string, submission_id: int, session_token: string, questionnaire_ref: string, answers: array<string, mixed>, last_question_answered: string}
	 */
	public static function progress_payload( object $submission, string $session_token ): array {
		$questionnaire_id = (int) ( $submission->questionnaire_id ?? 0 );
		$questionnaire    = $questionnaire_id > 0 ? WPQ_Database::get_questionnaire( $questionnaire_id ) : null;

		$answers = json_decode( (string) ( $submission->answers_json ?? '' ), true );

		return [
			'status'                 => 'in_progress',
			'submission_id'          => (int) $submission->id,
			'session_token'          => $session_token,
			'questionnaire_ref'      => (string) ( $questionnaire->ref ?? '' ),
			'answers'                => is_array( $answers ) ? $answers : [],
			'last_question_answered' => (string) ( $submission->last_question_answered ?? '' ),
		];
	}

	// ------------------------------------------------------------------ //
	// Partial-answer persistence (used by the heartbeat)
	// ------------------------------------------------------------------ //

	/**
	 * Sanitise a partial answer set from the heartbeat. Keys must be the
	 * "{domain}_{question}" convention; values are scalars or small lists of
	 * scalars (multi-select questions send a JSON-encoded list, which is kept
	 * verbatim as a string, matching what final submission sends).
	 *
	 * Returns null when the payload is not a plausible answer set - the
	 * heartbeat then simply skips persisting, it never fails.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function sanitise_partial_answers( mixed $answers ): ?array {
		if ( ! is_array( $answers ) || count( $answers ) > self::MAX_ANSWER_ENTRIES ) {
			return null;
		}

		$clean = [];
		foreach ( $answers as $key => $value ) {
			if ( ! is_string( $key ) || ! preg_match( '/^\d{1,4}_\d{1,4}$/', $key ) ) {
				return null;
			}
			if ( is_array( $value ) ) {
				if ( count( $value ) > self::MAX_ANSWER_LIST_ITEMS ) {
					return null;
				}
				$list = [];
				foreach ( $value as $item ) {
					if ( ! is_scalar( $item ) ) {
						return null;
					}
					$list[] = mb_substr( sanitize_text_field( (string) $item ), 0, self::MAX_ANSWER_VALUE_CHARS );
				}
				$clean[ $key ] = $list;
				continue;
			}
			if ( ! is_scalar( $value ) ) {
				return null;
			}
			$clean[ $key ] = mb_substr( sanitize_textarea_field( (string) $value ), 0, self::MAX_ANSWER_VALUE_CHARS );
		}

		return $clean;
	}
}
