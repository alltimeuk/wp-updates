<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Feature_Flags {

	public const ENABLED  = 'enabled';
	public const DISABLED = 'disabled';
	public const INHERIT  = 'inherit';

	/** @var array<string,string> */
	private static array $cache = [];

	public static function checkout_constant_controls(): bool {
		return defined( 'WPQ_CHECKOUT_ENABLED_CONFIGURED' ) && WPQ_CHECKOUT_ENABLED_CONFIGURED;
	}

	public static function checkout_source(): string {
		return self::checkout_constant_controls() ? 'constant' : 'database';
	}

	public static function checkout_option_state(): string {
		return self::normalise_enabled_state( self::option( 'wpq_checkout_enabled', self::DISABLED ), self::DISABLED );
	}

	public static function checkout_enabled(): bool {
		if ( self::checkout_constant_controls() ) {
			return defined( 'WPQ_CHECKOUT_ENABLED' ) && WPQ_CHECKOUT_ENABLED;
		}

		return self::checkout_option_state() === self::ENABLED;
	}

	public static function remediation_constant_controls(): bool {
		return defined( 'WPQ_REMEDIATION_PLAN_ENABLED_CONFIGURED' ) && WPQ_REMEDIATION_PLAN_ENABLED_CONFIGURED;
	}

	public static function remediation_global_source(): string {
		return self::remediation_constant_controls() ? 'constant' : 'database';
	}

	public static function remediation_global_option_state(): string {
		return self::normalise_enabled_state( self::option( 'wpq_remediation_plan_enabled', self::ENABLED ), self::ENABLED );
	}

	public static function remediation_global_enabled(): bool {
		if ( self::remediation_constant_controls() ) {
			return defined( 'WPQ_REMEDIATION_PLAN_ENABLED' ) && WPQ_REMEDIATION_PLAN_ENABLED;
		}

		return self::remediation_global_option_state() === self::ENABLED;
	}

	public static function remediation_questionnaire_state( object $questionnaire ): string {
		return self::normalise_inherit_state( (string) ( $questionnaire->remediation_plan_enabled ?? self::INHERIT ) );
	}

	public static function remediation_plan_download_enabled_for_questionnaire( object $questionnaire ): bool {
		if ( ! self::remediation_global_enabled() ) {
			return false;
		}

		return self::remediation_questionnaire_state( $questionnaire ) !== self::DISABLED;
	}

	public const RENDERER_DOCX_TEMPLATE = 'docx_template';
	public const RENDERER_HTML_DOMPDF  = 'html_dompdf';

	public static function questionnaire_report_constant_controls(): bool {
		return defined( 'WPQ_QUESTIONNAIRE_REPORT_ENABLED_CONFIGURED' ) && WPQ_QUESTIONNAIRE_REPORT_ENABLED_CONFIGURED;
	}

	public static function questionnaire_report_global_source(): string {
		return self::questionnaire_report_constant_controls() ? 'constant' : 'database';
	}

	public static function questionnaire_report_global_option_state(): string {
		return self::normalise_enabled_state( self::option( 'wpq_questionnaire_report_enabled', self::ENABLED ), self::ENABLED );
	}

	public static function questionnaire_report_global_enabled(): bool {
		if ( self::questionnaire_report_constant_controls() ) {
			return defined( 'WPQ_QUESTIONNAIRE_REPORT_ENABLED' ) && WPQ_QUESTIONNAIRE_REPORT_ENABLED;
		}

		return self::questionnaire_report_global_option_state() === self::ENABLED;
	}

	public static function questionnaire_report_questionnaire_state( object $questionnaire ): string {
		return self::normalise_inherit_state( (string) ( $questionnaire->questionnaire_report_enabled ?? self::INHERIT ) );
	}

	public static function questionnaire_report_enabled_for_questionnaire( object $questionnaire ): bool {
		if ( ! self::questionnaire_report_global_enabled() ) {
			return false;
		}

		return self::questionnaire_report_questionnaire_state( $questionnaire ) !== self::DISABLED;
	}

	public static function questionnaire_report_global_renderer_mode(): string {
		$mode = sanitize_key( self::option( 'wpq_questionnaire_report_renderer_mode', self::RENDERER_DOCX_TEMPLATE ) );
		return in_array( $mode, [ self::RENDERER_DOCX_TEMPLATE, self::RENDERER_HTML_DOMPDF ], true ) ? $mode : self::RENDERER_DOCX_TEMPLATE;
	}

	public static function questionnaire_report_renderer_mode_for_questionnaire( object $questionnaire ): string {
		$override = sanitize_key( (string) ( $questionnaire->questionnaire_report_renderer_mode ?? self::INHERIT ) );
		if ( in_array( $override, [ self::RENDERER_DOCX_TEMPLATE, self::RENDERER_HTML_DOMPDF ], true ) ) {
			return $override;
		}

		return self::questionnaire_report_global_renderer_mode();
	}

	public static function questionnaire_report_html_fallback_allowed(): bool {
		return self::option( 'wpq_questionnaire_report_html_fallback', self::DISABLED ) === self::ENABLED;
	}

	public static function framework_readiness_constant_controls(): bool {
		return defined( 'WPQ_FRAMEWORK_READINESS_ENABLED_CONFIGURED' ) && WPQ_FRAMEWORK_READINESS_ENABLED_CONFIGURED;
	}

	public static function framework_readiness_global_source(): string {
		return self::framework_readiness_constant_controls() ? 'constant' : 'database';
	}

	public static function framework_readiness_global_option_state(): string {
		return self::normalise_enabled_state( self::option( 'wpq_framework_readiness_enabled', self::ENABLED ), self::ENABLED );
	}

	public static function framework_readiness_global_enabled(): bool {
		if ( self::framework_readiness_constant_controls() ) {
			return defined( 'WPQ_FRAMEWORK_READINESS_ENABLED' ) && WPQ_FRAMEWORK_READINESS_ENABLED;
		}

		return self::framework_readiness_global_option_state() === self::ENABLED;
	}

	public static function framework_readiness_questionnaire_state( object $questionnaire ): string {
		return self::normalise_inherit_state( (string) ( $questionnaire->framework_readiness_enabled ?? self::INHERIT ) );
	}

	public static function framework_readiness_enabled_for_questionnaire( object $questionnaire ): bool {
		if ( ! self::framework_readiness_global_enabled() ) {
			return false;
		}

		return self::framework_readiness_questionnaire_state( $questionnaire ) !== self::DISABLED;
	}

	// Shared by every bars/radar visualisation toggle (Domain Breakdown,
	// Framework Analysis) - not tied to either feature specifically.
	public const VISUALISATION_BARS  = 'bars';
	public const VISUALISATION_RADAR = 'radar';

	public static function domain_breakdown_global_visualisation_mode(): string {
		$mode = sanitize_key( self::option( 'wpq_domain_breakdown_visualisation', self::VISUALISATION_BARS ) );
		return in_array( $mode, [ self::VISUALISATION_BARS, self::VISUALISATION_RADAR ], true ) ? $mode : self::VISUALISATION_BARS;
	}

	public static function domain_breakdown_questionnaire_state( object $questionnaire ): string {
		return self::normalise_visualisation_state( (string) ( $questionnaire->domain_breakdown_visualisation ?? self::INHERIT ) );
	}

	/**
	 * Bars is the backward-compatible default: an un-migrated or never-
	 * configured questionnaire resolves to the global mode, which itself
	 * defaults to bars, so no existing questionnaire's results screen
	 * changes presentation unless someone explicitly opts it into radar.
	 */
	public static function domain_breakdown_visualisation_mode_for_questionnaire( object $questionnaire ): string {
		$override = self::domain_breakdown_questionnaire_state( $questionnaire );
		if ( self::INHERIT !== $override ) {
			return $override;
		}

		return self::domain_breakdown_global_visualisation_mode();
	}

	public static function framework_analysis_global_visualisation_mode(): string {
		$mode = sanitize_key( self::option( 'wpq_framework_analysis_visualisation', self::VISUALISATION_BARS ) );
		return in_array( $mode, [ self::VISUALISATION_BARS, self::VISUALISATION_RADAR ], true ) ? $mode : self::VISUALISATION_BARS;
	}

	public static function framework_analysis_questionnaire_state( object $questionnaire ): string {
		return self::normalise_visualisation_state( (string) ( $questionnaire->framework_analysis_visualisation ?? self::INHERIT ) );
	}

	/**
	 * Bars is the backward-compatible default, exactly mirroring
	 * domain_breakdown_visualisation_mode_for_questionnaire(): an un-migrated
	 * or never-configured questionnaire resolves to the global mode, which
	 * itself defaults to bars, so no existing questionnaire's results screen
	 * changes presentation unless someone explicitly opts it into radar.
	 */
	public static function framework_analysis_visualisation_mode_for_questionnaire( object $questionnaire ): string {
		$override = self::framework_analysis_questionnaire_state( $questionnaire );
		if ( self::INHERIT !== $override ) {
			return $override;
		}

		return self::framework_analysis_global_visualisation_mode();
	}

	public static function clear_cache(): void {
		self::$cache = [];
	}

	public static function normalise_enabled_state( string $value, string $default = self::DISABLED ): string {
		$value = sanitize_key( $value );
		return in_array( $value, [ self::ENABLED, self::DISABLED ], true ) ? $value : $default;
	}

	public static function normalise_inherit_state( string $value ): string {
		$value = sanitize_key( $value );
		return in_array( $value, [ self::INHERIT, self::ENABLED, self::DISABLED ], true ) ? $value : self::INHERIT;
	}

	/** Shared validator for any bars/radar/inherit override column. */
	public static function normalise_visualisation_state( string $value ): string {
		$value = sanitize_key( $value );
		return in_array( $value, [ self::INHERIT, self::VISUALISATION_BARS, self::VISUALISATION_RADAR ], true ) ? $value : self::INHERIT;
	}

	private static function option( string $name, string $default ): string {
		if ( ! array_key_exists( $name, self::$cache ) ) {
			self::$cache[ $name ] = (string) get_option( $name, $default );
		}

		return self::$cache[ $name ];
	}
}
