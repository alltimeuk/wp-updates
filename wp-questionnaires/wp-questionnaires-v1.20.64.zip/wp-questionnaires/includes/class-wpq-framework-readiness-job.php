<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Orchestrates Framework Readiness as its own background job, independent of
 * Questionnaire Report generation: claim -> WP-Cron -> concurrent Claude
 * calls (WPQ_Framework_Readiness::assess_for_questionnaire_concurrent()) ->
 * stored result. Triggered automatically once a submission completes
 * (public/class-wpq-rest-api.php's submit_assessment()), not gated behind
 * the customer clicking "Generate your assessment report" - the two features
 * share the same underlying Claude call but have entirely separate lifecycle
 * columns (fr_* vs qr_*), since qr_analysis_json is fully overwritten on
 * every Questionnaire Report run and isn't safe for this job to share.
 *
 * Every failure mode here is a silent no-op by design: this is an
 * enhancement layered onto a submission that has already succeeded, so it
 * must never surface an error to the customer or block the submit response.
 */
class WPQ_Framework_Readiness_Job {

	public const CRON_HOOK = 'wpq_process_framework_readiness';

	public const ACTIVE_STATES      = [ 'queued', 'processing' ];
	public const RESTARTABLE_STATES = [ 'not_requested', 'completed', 'partial', 'failed' ];

	/**
	 * Claim and schedule a readiness run for a just-completed submission.
	 * A no-op when: the submission isn't complete yet, a run is already
	 * active, the feature is disabled for this questionnaire, the
	 * questionnaire has no frameworks selected, or the claim loses a race to
	 * a concurrent caller (all silently skip the same way a duplicate click
	 * on "Generate" already does for reports).
	 */
	public static function request_generation( int $submission_id ): void {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || empty( $submission->completed_at ) ) {
			return;
		}
		if ( in_array( (string) ( $submission->fr_status ?? '' ), self::ACTIVE_STATES, true ) ) {
			return;
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire || ! WPQ_Feature_Flags::framework_readiness_enabled_for_questionnaire( $questionnaire ) ) {
			return;
		}
		if ( empty( WPQ_Framework_Readiness::selected_framework_ids( $questionnaire ) ) ) {
			return;
		}

		$token   = wp_generate_password( 20, false, false );
		$claimed = WPQ_Database::claim_framework_readiness_job( $submission_id, $token, self::RESTARTABLE_STATES, 'queued' );
		if ( ! $claimed ) {
			return;
		}

		wp_schedule_single_event( time(), self::CRON_HOOK, [ $submission_id, $token ] );
		self::kick_cron();
	}

	/**
	 * WP-Cron single-event handler. Builds the submission's context via the
	 * same generation-flow-independent builder the Questionnaire Report
	 * itself uses, then runs every selected framework's Claude call
	 * concurrently.
	 */
	public static function process( int $submission_id, string $token ): void {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || (string) $submission->fr_generation_token !== $token ) {
			return; // Superseded or stale duplicate cron firing.
		}
		if ( 'queued' !== (string) $submission->fr_status ) {
			return;
		}

		WPQ_Database::update_submission_framework_readiness( $submission_id, [ 'fr_status' => 'processing' ] );

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			self::fail( $submission_id, $token, 'questionnaire_missing', 'The parent questionnaire could not be found.' );
			return;
		}

		try {
			$context = WPQ_Questionnaire_Report_Context::build_for_submission( $submission );
		} catch ( Throwable $e ) {
			self::fail( $submission_id, $token, 'context_build_failed', 'Could not build the assessment context.' );
			return;
		}

		if ( ! self::still_claimed( $submission_id, $token ) ) {
			return;
		}

		$selected_count = count( WPQ_Framework_Readiness::selected_framework_ids( $questionnaire ) );
		$results        = WPQ_Framework_Readiness::assess_for_questionnaire_concurrent( $questionnaire, $context );

		if ( empty( $results ) ) {
			self::fail( $submission_id, $token, 'no_frameworks_assessed', 'None of the selected frameworks could be assessed. Enable Claude debug logging in Settings -> AI for details.' );
			return;
		}

		if ( ! self::still_claimed( $submission_id, $token ) ) {
			return;
		}

		$encoded = wp_json_encode( $results );

		WPQ_Database::update_submission_framework_readiness( $submission_id, [
			'fr_status'       => count( $results ) < $selected_count ? 'partial' : 'completed',
			'fr_completed_at' => current_time( 'mysql', true ),
			'fr_results_json' => is_string( $encoded ) ? $encoded : '[]',
		] );
	}

	/**
	 * @return array{status: string, completed_at: string}
	 */
	public static function state_snapshot( ?object $submission ): array {
		if ( ! $submission ) {
			return [ 'status' => 'not_requested', 'completed_at' => '' ];
		}

		return [
			'status'       => (string) ( $submission->fr_status ?? 'not_requested' ),
			'completed_at' => (string) ( $submission->fr_completed_at ?? '' ),
		];
	}

	private static function fail( int $submission_id, string $token, string $code, string $message ): void {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || (string) $submission->fr_generation_token !== $token ) {
			return; // Superseded by a newer claim.
		}

		WPQ_Database::update_submission_framework_readiness( $submission_id, [
			'fr_status'          => 'failed',
			'fr_completed_at'    => current_time( 'mysql', true ),
			'fr_failure_code'    => $code,
			'fr_failure_message' => $message,
		] );
	}

	private static function still_claimed( int $submission_id, string $token ): bool {
		$submission = WPQ_Database::get_submission( $submission_id );
		return (bool) $submission && (string) $submission->fr_generation_token === $token;
	}

	private static function kick_cron(): void {
		if ( class_exists( 'WPQ_Cron_Kicker' ) ) {
			WPQ_Cron_Kicker::kick();
		}
	}
}
