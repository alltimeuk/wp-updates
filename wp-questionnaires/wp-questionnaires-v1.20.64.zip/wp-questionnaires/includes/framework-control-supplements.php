<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Supplemental control catalogues for ATLAS skill bundles whose reference
 * material does not carry a (complete) tabular catalogue.
 *
 * Each entry is `slug => [ 'mode' => 'fallback'|'replace', 'controls' => [...] ]`:
 * 'fallback' applies only when parsing the bundle yields no controls, so an
 * ATLAS bundle that later ships its own catalogue automatically takes
 * precedence; 'replace' is for standards whose canonical catalogue is fixed
 * and complete (COBIT's 40 objectives), where the curated set beats a partial
 * scrape.
 *
 * Content is authored from the named standards' own published structure -
 * section/regulation references are the standards', not invented. Standards
 * not listed here (ITIL v3/v4 and other process frameworks) are deliberately
 * metadata-only.
 *
 * @return array<string, array{mode: string, controls: array<int, array{control_ref: string, control_name: string, domain: string, description: string}>}>
 */
return [

	// NIST SP 800-207, Zero Trust Architecture. The seven tenets (§2.1) are the
	// document's normative core; the three logical components (§3) are the
	// architecture every deployment model composes.
	'nist-sp-800-207' => [ 'mode' => 'fallback', 'controls' => [
		[ 'control_ref' => 'Tenet 1', 'control_name' => 'All data sources and computing services are considered resources', 'domain' => 'Tenets of Zero Trust (§2.1)', 'description' => 'Networks may be composed of multiple classes of devices and services; anything that provides data or computation is treated as a resource subject to access decisions.' ],
		[ 'control_ref' => 'Tenet 2', 'control_name' => 'All communication is secured regardless of network location', 'domain' => 'Tenets of Zero Trust (§2.1)', 'description' => 'Network location alone does not imply trust; access requests from enterprise-owned infrastructure must meet the same security requirements as those from any other network.' ],
		[ 'control_ref' => 'Tenet 3', 'control_name' => 'Access to individual enterprise resources is granted on a per-session basis', 'domain' => 'Tenets of Zero Trust (§2.1)', 'description' => 'Trust is evaluated before access is granted, with least privilege applied; authentication to one resource does not automatically grant access to another.' ],
		[ 'control_ref' => 'Tenet 4', 'control_name' => 'Access to resources is determined by dynamic policy', 'domain' => 'Tenets of Zero Trust (§2.1)', 'description' => 'Policy decisions weigh the observable state of client identity, the application or service, and the requesting asset, and may include behavioural and environmental attributes.' ],
		[ 'control_ref' => 'Tenet 5', 'control_name' => 'The enterprise monitors and measures the integrity and security posture of all owned and associated assets', 'domain' => 'Tenets of Zero Trust (§2.1)', 'description' => 'No asset is inherently trusted; posture is evaluated when requests are processed, with continuous diagnostics and mitigation informing decisions.' ],
		[ 'control_ref' => 'Tenet 6', 'control_name' => 'All resource authentication and authorization are dynamic and strictly enforced before access is allowed', 'domain' => 'Tenets of Zero Trust (§2.1)', 'description' => 'A constant cycle of obtaining access, scanning and assessing threats, adapting, and continually re-evaluating trust in ongoing communication.' ],
		[ 'control_ref' => 'Tenet 7', 'control_name' => 'The enterprise collects as much information as possible about the current state of assets, network infrastructure and communications, and uses it to improve its security posture', 'domain' => 'Tenets of Zero Trust (§2.1)', 'description' => 'Data about asset security posture, traffic and access requests is collected and used to improve policy creation and enforcement.' ],
		[ 'control_ref' => 'PE', 'control_name' => 'Policy Engine', 'domain' => 'Core Logical Components (§3)', 'description' => 'Decides whether to grant access to a resource for a given subject, using enterprise policy and input from external sources as a trust algorithm.' ],
		[ 'control_ref' => 'PA', 'control_name' => 'Policy Administrator', 'domain' => 'Core Logical Components (§3)', 'description' => 'Establishes and shuts down the communication path between subject and resource, generating session-specific credentials or tokens on the Policy Engine\'s decision.' ],
		[ 'control_ref' => 'PEP', 'control_name' => 'Policy Enforcement Point', 'domain' => 'Core Logical Components (§3)', 'description' => 'Enables, monitors, and terminates connections between a subject and an enterprise resource, acting on instructions from the Policy Administrator.' ],
	], ],

	// NIST SP 800-39, Managing Information Security Risk. The three-tier model
	// (§2.1) and the four-component risk management process (Chapter 3).
	'nist-sp-800-39' => [ 'mode' => 'fallback', 'controls' => [
		[ 'control_ref' => 'Tier 1', 'control_name' => 'Organization', 'domain' => 'Multitiered Risk Management (§2.1)', 'description' => 'Risk framed and governed at organisational level: risk executive function, risk management strategy, and investment decisions.' ],
		[ 'control_ref' => 'Tier 2', 'control_name' => 'Mission/Business Processes', 'domain' => 'Multitiered Risk Management (§2.1)', 'description' => 'Risk managed for mission and business processes: enterprise architecture, information flows, and process-level resilience informed by Tier 1 strategy.' ],
		[ 'control_ref' => 'Tier 3', 'control_name' => 'Information Systems', 'domain' => 'Multitiered Risk Management (§2.1)', 'description' => 'Risk managed at the system level through the Risk Management Framework: categorisation, control selection, implementation, assessment, authorisation, monitoring.' ],
		[ 'control_ref' => '3.1', 'control_name' => 'Framing Risk', 'domain' => 'Risk Management Process (Chapter 3)', 'description' => 'Establish the context for risk-based decisions: assumptions, constraints, risk tolerance, and priorities that produce the risk management strategy.' ],
		[ 'control_ref' => '3.2', 'control_name' => 'Assessing Risk', 'domain' => 'Risk Management Process (Chapter 3)', 'description' => 'Identify threats, vulnerabilities, harm, and likelihood to determine risk to organisational operations, assets, and individuals.' ],
		[ 'control_ref' => '3.3', 'control_name' => 'Responding to Risk', 'domain' => 'Risk Management Process (Chapter 3)', 'description' => 'Develop, evaluate, and implement courses of action - accept, avoid, mitigate, share, or transfer - consistent with the organisation\'s risk tolerance.' ],
		[ 'control_ref' => '3.4', 'control_name' => 'Monitoring Risk', 'domain' => 'Risk Management Process (Chapter 3)', 'description' => 'Verify implementation, measure ongoing effectiveness, and track changes to systems and environments that affect risk over time.' ],
	], ],

	// NIST SP 800-115, Technical Guide to Information Security Testing and
	// Assessment. The technique classes (§3–§5) and assessment lifecycle (§6–§8)
	// that structure the document.
	'nist-sp-800-115' => [ 'mode' => 'fallback', 'controls' => [
		[ 'control_ref' => '§3', 'control_name' => 'Review Techniques', 'domain' => 'Assessment Techniques', 'description' => 'Passive examination of systems, policies, and procedures: documentation, log, ruleset and configuration review, network sniffing, and file integrity checking.' ],
		[ 'control_ref' => '§4', 'control_name' => 'Target Identification and Analysis Techniques', 'domain' => 'Assessment Techniques', 'description' => 'Identifying active devices and associated services and analysing them for potential vulnerabilities: network discovery, port and service identification, vulnerability scanning, wireless scanning.' ],
		[ 'control_ref' => '§5', 'control_name' => 'Target Vulnerability Validation Techniques', 'domain' => 'Assessment Techniques', 'description' => 'Corroborating the existence of vulnerabilities: password cracking, penetration testing, social engineering.' ],
		[ 'control_ref' => '§6', 'control_name' => 'Security Assessment Planning', 'domain' => 'Assessment Lifecycle', 'description' => 'Developing the assessment policy, prioritising and scheduling assessments, selecting the approach, and addressing logistical and legal considerations.' ],
		[ 'control_ref' => '§7', 'control_name' => 'Security Assessment Execution', 'domain' => 'Assessment Lifecycle', 'description' => 'Coordinating and conducting the assessment, analysing findings, and handling the data generated - including protection of assessment data.' ],
		[ 'control_ref' => '§8', 'control_name' => 'Post-Testing Activities', 'domain' => 'Assessment Lifecycle', 'description' => 'Reporting, remediation recommendations, and mitigation tracking that convert assessment findings into security improvement.' ],
	], ],

	// UK Cyber Security and Resilience (Network and Information Systems) Bill.
	// In the House of Lords as of mid-2026; Royal Assent expected late 2026.
	// Clause numbers are not stable pre-assent, so measures carry plugin-scoped
	// refs and an explicit provisional marker.
	'uk-nis-csrb' => [ 'mode' => 'fallback', 'controls' => [
		[ 'control_ref' => 'CSRB-1', 'control_name' => 'Managed service providers brought into scope', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Extends the NIS Regulations 2018 regime to managed service providers, making MSPs directly subject to registration, security duties, and incident reporting.' ],
		[ 'control_ref' => 'CSRB-2', 'control_name' => 'Data centres regulated as essential infrastructure', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Brings data centres above a capacity threshold into the regulated regime as essential services.' ],
		[ 'control_ref' => 'CSRB-3', 'control_name' => 'Enhanced incident reporting: 24-hour initial notification', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Requires an initial notification of significant incidents within 24 hours, with a full report within 72 hours, to the relevant regulator and the NCSC.' ],
		[ 'control_ref' => 'CSRB-4', 'control_name' => 'Expanded incident definition including near-misses and customer impact', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Broadens what must be reported beyond service disruption, capturing incidents affecting confidentiality or integrity and significant near-miss events.' ],
		[ 'control_ref' => 'CSRB-5', 'control_name' => 'NCSC Cyber Assessment Framework on a statutory footing', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Embeds the Cyber Assessment Framework (CAF) as the reference framework regulators use to assess in-scope entities\' security duties.' ],
		[ 'control_ref' => 'CSRB-6', 'control_name' => 'Strengthened regulator powers and cost recovery', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Gives competent authorities stronger information-gathering and enforcement powers and the ability to recover regulatory costs from regulated entities.' ],
		[ 'control_ref' => 'CSRB-7', 'control_name' => 'Turnover-linked penalties', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Introduces penalty ceilings up to £17 million or 4% of global turnover for the most serious failures of security or reporting duties.' ],
		[ 'control_ref' => 'CSRB-8', 'control_name' => 'Delegated powers to update scope and requirements', 'domain' => 'Provisions (pre-Royal Assent, subject to change)', 'description' => 'Allows the Secretary of State to update the regime by secondary legislation as threats and technology evolve, including adding new sectors.' ],
	], ],

	// COBIT 2019. The canonical catalogue is exactly the 40 governance and
	// management objectives; the bundle's own tables only reference a subset in
	// passing, so the curated set replaces the partial scrape.
	'cobit' => [ 'mode' => 'replace', 'controls' => [
		[ 'control_ref' => 'EDM01', 'control_name' => 'Ensured Governance Framework Setting and Maintenance', 'domain' => 'Evaluate, Direct and Monitor (EDM)', 'description' => 'Analyse and articulate the requirements for the governance of enterprise I&T, and put in place and maintain governance components.' ],
		[ 'control_ref' => 'EDM02', 'control_name' => 'Ensured Benefits Delivery', 'domain' => 'Evaluate, Direct and Monitor (EDM)', 'description' => 'Secure optimal value from I&T-enabled initiatives, services and assets, and cost-efficient delivery.' ],
		[ 'control_ref' => 'EDM03', 'control_name' => 'Ensured Risk Optimization', 'domain' => 'Evaluate, Direct and Monitor (EDM)', 'description' => 'Ensure the enterprise\'s risk appetite and tolerance are understood, articulated and communicated, and that I&T risk is identified and managed.' ],
		[ 'control_ref' => 'EDM04', 'control_name' => 'Ensured Resource Optimization', 'domain' => 'Evaluate, Direct and Monitor (EDM)', 'description' => 'Ensure adequate and sufficient I&T-related capabilities (people, process and technology) to support enterprise objectives effectively at optimal cost.' ],
		[ 'control_ref' => 'EDM05', 'control_name' => 'Ensured Stakeholder Engagement', 'domain' => 'Evaluate, Direct and Monitor (EDM)', 'description' => 'Ensure stakeholders are identified and engaged, and that enterprise I&T performance and conformance reporting is transparent and timely.' ],
		[ 'control_ref' => 'APO01', 'control_name' => 'Managed I&T Management Framework', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Design the management system for enterprise I&T: organisational structures, roles, policies, and processes.' ],
		[ 'control_ref' => 'APO02', 'control_name' => 'Managed Strategy', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Provide a holistic view of the current business and I&T environment and direction, and formulate the digital transformation strategy.' ],
		[ 'control_ref' => 'APO03', 'control_name' => 'Managed Enterprise Architecture', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Establish a common architecture for business processes, information, data, applications and technology.' ],
		[ 'control_ref' => 'APO04', 'control_name' => 'Managed Innovation', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Maintain awareness of technology trends, identify innovation opportunities, and plan how to benefit from innovation.' ],
		[ 'control_ref' => 'APO05', 'control_name' => 'Managed Portfolio', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Execute the strategic direction for investments: programme selection, portfolio management, and benefit monitoring.' ],
		[ 'control_ref' => 'APO06', 'control_name' => 'Managed Budget and Costs', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Manage I&T-related financial activities: budgeting, cost and benefit management, and prioritisation of spending.' ],
		[ 'control_ref' => 'APO07', 'control_name' => 'Managed Human Resources', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Provide a structured approach to optimal structuring, placement, decision rights and skills of human resources.' ],
		[ 'control_ref' => 'APO08', 'control_name' => 'Managed Relationships', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Manage relationships between the business and IT in a formalised and transparent way.' ],
		[ 'control_ref' => 'APO09', 'control_name' => 'Managed Service Agreements', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Align I&T-enabled products and services and service levels with enterprise needs and expectations.' ],
		[ 'control_ref' => 'APO10', 'control_name' => 'Managed Vendors', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Manage I&T-related products and services provided by all types of vendors, including selection, contracts, and performance monitoring.' ],
		[ 'control_ref' => 'APO11', 'control_name' => 'Managed Quality', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Define and communicate quality requirements in all processes, procedures and enterprise outcomes.' ],
		[ 'control_ref' => 'APO12', 'control_name' => 'Managed Risk', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Continually identify, assess and reduce I&T-related risk within tolerance levels set by executive management.' ],
		[ 'control_ref' => 'APO13', 'control_name' => 'Managed Security', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Define, operate and monitor an information security management system.' ],
		[ 'control_ref' => 'APO14', 'control_name' => 'Managed Data', 'domain' => 'Align, Plan and Organize (APO)', 'description' => 'Achieve and sustain effective management of the enterprise data assets across the data life cycle.' ],
		[ 'control_ref' => 'BAI01', 'control_name' => 'Managed Programs', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Manage all programmes from the investment portfolio in alignment with enterprise strategy and in a coordinated way.' ],
		[ 'control_ref' => 'BAI02', 'control_name' => 'Managed Requirements Definition', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Identify solutions and analyse requirements before acquisition or creation to ensure alignment with strategic requirements.' ],
		[ 'control_ref' => 'BAI03', 'control_name' => 'Managed Solutions Identification and Build', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Establish and maintain identified products and services in line with requirements, covering design, development, procurement and partnering.' ],
		[ 'control_ref' => 'BAI04', 'control_name' => 'Managed Availability and Capacity', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Balance current and future needs for availability, performance and capacity with cost-efficient service provision.' ],
		[ 'control_ref' => 'BAI05', 'control_name' => 'Managed Organizational Change', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Maximise the likelihood of successfully implementing sustainable enterprise-wide organisational change.' ],
		[ 'control_ref' => 'BAI06', 'control_name' => 'Managed IT Changes', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Manage all changes in a controlled manner, including standard changes and emergency maintenance.' ],
		[ 'control_ref' => 'BAI07', 'control_name' => 'Managed IT Change Acceptance and Transitioning', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Formally accept and make operational new solutions: implementation planning, conversion, testing, and post-implementation review.' ],
		[ 'control_ref' => 'BAI08', 'control_name' => 'Managed Knowledge', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Maintain the availability of relevant, current, validated and reliable knowledge and management information.' ],
		[ 'control_ref' => 'BAI09', 'control_name' => 'Managed Assets', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Manage I&T assets through their life cycle: value delivery, cost accounting, and licence compliance.' ],
		[ 'control_ref' => 'BAI10', 'control_name' => 'Managed Configuration', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Define and maintain descriptions and relationships among key resources and capabilities required to deliver I&T-enabled services.' ],
		[ 'control_ref' => 'BAI11', 'control_name' => 'Managed Projects', 'domain' => 'Build, Acquire and Implement (BAI)', 'description' => 'Manage all projects with a defined project management approach in alignment with programme direction.' ],
		[ 'control_ref' => 'DSS01', 'control_name' => 'Managed Operations', 'domain' => 'Deliver, Service and Support (DSS)', 'description' => 'Coordinate and execute the operational procedures required to deliver internal and outsourced I&T services.' ],
		[ 'control_ref' => 'DSS02', 'control_name' => 'Managed Service Requests and Incidents', 'domain' => 'Deliver, Service and Support (DSS)', 'description' => 'Provide timely and effective response to user requests and resolution of all types of incidents.' ],
		[ 'control_ref' => 'DSS03', 'control_name' => 'Managed Problems', 'domain' => 'Deliver, Service and Support (DSS)', 'description' => 'Identify and classify problems and their root causes, and provide timely resolution and proactive prevention.' ],
		[ 'control_ref' => 'DSS04', 'control_name' => 'Managed Continuity', 'domain' => 'Deliver, Service and Support (DSS)', 'description' => 'Establish and maintain a plan enabling the business and I&T to respond to incidents and quickly recover critical operations.' ],
		[ 'control_ref' => 'DSS05', 'control_name' => 'Managed Security Services', 'domain' => 'Deliver, Service and Support (DSS)', 'description' => 'Protect enterprise information: network and endpoint security, identity and access management, and security monitoring.' ],
		[ 'control_ref' => 'DSS06', 'control_name' => 'Managed Business Process Controls', 'domain' => 'Deliver, Service and Support (DSS)', 'description' => 'Define and maintain appropriate business process controls to ensure information satisfies control requirements.' ],
		[ 'control_ref' => 'MEA01', 'control_name' => 'Managed Performance and Conformance Monitoring', 'domain' => 'Monitor, Evaluate and Assess (MEA)', 'description' => 'Collect, validate and evaluate enterprise and alignment goals and metrics, and monitor that performance is on track.' ],
		[ 'control_ref' => 'MEA02', 'control_name' => 'Managed System of Internal Control', 'domain' => 'Monitor, Evaluate and Assess (MEA)', 'description' => 'Continuously monitor and evaluate the control environment, including self-assessments and independent assurance reviews.' ],
		[ 'control_ref' => 'MEA03', 'control_name' => 'Managed Compliance With External Requirements', 'domain' => 'Monitor, Evaluate and Assess (MEA)', 'description' => 'Evaluate that I&T processes and business processes comply with laws, regulations and contractual requirements.' ],
		[ 'control_ref' => 'MEA04', 'control_name' => 'Managed Assurance', 'domain' => 'Monitor, Evaluate and Assess (MEA)', 'description' => 'Plan, scope and execute assurance initiatives to enable management to deliver adequate and sustainable assurance.' ],
	], ],

	// HIPAA. The Security Rule's standards (45 CFR §164.308–§164.316) plus the
	// Breach Notification Rule's notification duties (Subpart D).
	'hipaa-compliance' => [ 'mode' => 'fallback', 'controls' => [
		[ 'control_ref' => '§164.308(a)(1)', 'control_name' => 'Security Management Process', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Implement policies and procedures to prevent, detect, contain and correct security violations: risk analysis, risk management, sanction policy, information system activity review.' ],
		[ 'control_ref' => '§164.308(a)(2)', 'control_name' => 'Assigned Security Responsibility', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Identify the security official responsible for developing and implementing the entity\'s security policies and procedures.' ],
		[ 'control_ref' => '§164.308(a)(3)', 'control_name' => 'Workforce Security', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Ensure workforce members have appropriate access to ePHI and prevent access by those who should not have it: authorisation/supervision, clearance, termination procedures.' ],
		[ 'control_ref' => '§164.308(a)(4)', 'control_name' => 'Information Access Management', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Implement policies and procedures for authorising access to ePHI consistent with the Privacy Rule: access authorisation, establishment and modification.' ],
		[ 'control_ref' => '§164.308(a)(5)', 'control_name' => 'Security Awareness and Training', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Security awareness and training programme for all workforce members: security reminders, malware protection, log-in monitoring, password management.' ],
		[ 'control_ref' => '§164.308(a)(6)', 'control_name' => 'Security Incident Procedures', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Identify and respond to suspected or known security incidents; mitigate harmful effects and document incidents and outcomes.' ],
		[ 'control_ref' => '§164.308(a)(7)', 'control_name' => 'Contingency Plan', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Respond to emergencies that damage systems containing ePHI: data backup plan, disaster recovery plan, emergency mode operation, testing, applications and data criticality analysis.' ],
		[ 'control_ref' => '§164.308(a)(8)', 'control_name' => 'Evaluation', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Periodic technical and non-technical evaluation of security safeguards in response to environmental and operational changes.' ],
		[ 'control_ref' => '§164.308(b)(1)', 'control_name' => 'Business Associate Contracts and Other Arrangements', 'domain' => 'Administrative Safeguards (§164.308)', 'description' => 'Permit business associates to create, receive, maintain or transmit ePHI only with satisfactory assurances the information will be appropriately safeguarded.' ],
		[ 'control_ref' => '§164.310(a)(1)', 'control_name' => 'Facility Access Controls', 'domain' => 'Physical Safeguards (§164.310)', 'description' => 'Limit physical access to electronic information systems and the facilities housing them: contingency operations, facility security plan, access control and validation, maintenance records.' ],
		[ 'control_ref' => '§164.310(b)', 'control_name' => 'Workstation Use', 'domain' => 'Physical Safeguards (§164.310)', 'description' => 'Specify the proper functions to be performed and the manner in which they are performed at workstations that access ePHI.' ],
		[ 'control_ref' => '§164.310(c)', 'control_name' => 'Workstation Security', 'domain' => 'Physical Safeguards (§164.310)', 'description' => 'Implement physical safeguards for all workstations that access ePHI to restrict access to authorised users.' ],
		[ 'control_ref' => '§164.310(d)(1)', 'control_name' => 'Device and Media Controls', 'domain' => 'Physical Safeguards (§164.310)', 'description' => 'Govern receipt and removal of hardware and electronic media containing ePHI: disposal, media re-use, accountability, data backup and storage.' ],
		[ 'control_ref' => '§164.312(a)(1)', 'control_name' => 'Access Control', 'domain' => 'Technical Safeguards (§164.312)', 'description' => 'Allow access to ePHI only to authorised persons or programs: unique user identification, emergency access procedure, automatic logoff, encryption and decryption.' ],
		[ 'control_ref' => '§164.312(b)', 'control_name' => 'Audit Controls', 'domain' => 'Technical Safeguards (§164.312)', 'description' => 'Implement hardware, software and procedural mechanisms that record and examine activity in systems containing or using ePHI.' ],
		[ 'control_ref' => '§164.312(c)(1)', 'control_name' => 'Integrity', 'domain' => 'Technical Safeguards (§164.312)', 'description' => 'Protect ePHI from improper alteration or destruction, including mechanisms to authenticate ePHI.' ],
		[ 'control_ref' => '§164.312(d)', 'control_name' => 'Person or Entity Authentication', 'domain' => 'Technical Safeguards (§164.312)', 'description' => 'Verify that a person or entity seeking access to ePHI is the one claimed.' ],
		[ 'control_ref' => '§164.312(e)(1)', 'control_name' => 'Transmission Security', 'domain' => 'Technical Safeguards (§164.312)', 'description' => 'Guard against unauthorised access to ePHI transmitted over electronic communications networks: integrity controls and encryption.' ],
		[ 'control_ref' => '§164.314(a)', 'control_name' => 'Business Associate Contracts or Other Arrangements', 'domain' => 'Organizational Requirements (§164.314)', 'description' => 'Contract requirements ensuring business associates comply with the Security Rule and report security incidents, including for subcontractors.' ],
		[ 'control_ref' => '§164.314(b)', 'control_name' => 'Requirements for Group Health Plans', 'domain' => 'Organizational Requirements (§164.314)', 'description' => 'Plan documents must require the plan sponsor to reasonably and appropriately safeguard ePHI created, received, maintained or transmitted on the plan\'s behalf.' ],
		[ 'control_ref' => '§164.316(a)', 'control_name' => 'Policies and Procedures', 'domain' => 'Policies, Procedures and Documentation (§164.316)', 'description' => 'Implement reasonable and appropriate policies and procedures to comply with the Security Rule\'s standards and implementation specifications.' ],
		[ 'control_ref' => '§164.316(b)(1)', 'control_name' => 'Documentation', 'domain' => 'Policies, Procedures and Documentation (§164.316)', 'description' => 'Maintain written documentation of policies, procedures, actions, activities and assessments; retain six years, make available, and update as needed.' ],
		[ 'control_ref' => '§164.404', 'control_name' => 'Notification to Individuals', 'domain' => 'Breach Notification (Subpart D)', 'description' => 'Notify each individual whose unsecured PHI has been, or is reasonably believed to have been, breached - without unreasonable delay and within 60 days of discovery.' ],
		[ 'control_ref' => '§164.406', 'control_name' => 'Notification to the Media', 'domain' => 'Breach Notification (Subpart D)', 'description' => 'For breaches involving more than 500 residents of a state or jurisdiction, notify prominent media outlets serving that area.' ],
		[ 'control_ref' => '§164.408', 'control_name' => 'Notification to the Secretary', 'domain' => 'Breach Notification (Subpart D)', 'description' => 'Notify the Secretary of HHS: contemporaneously with individual notice for 500+ breaches, annually for smaller breaches.' ],
		[ 'control_ref' => '§164.410', 'control_name' => 'Notification by a Business Associate', 'domain' => 'Breach Notification (Subpart D)', 'description' => 'A business associate must notify the covered entity of a breach of unsecured PHI without unreasonable delay and within 60 days of discovery.' ],
	], ],

	// ISO/IEC 27018. Annex A's additional controls for PII protection in public
	// clouds are organised by the eleven ISO/IEC 29100 privacy principles
	// (Annex sections A.2–A.12); the sections are the stable reference points.
	'iso27018' => [ 'mode' => 'fallback', 'controls' => [
		[ 'control_ref' => 'A.2', 'control_name' => 'Consent and choice', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Provide the cloud customer with the means to enable PII principals\' rights, and process PII only on documented customer instructions.' ],
		[ 'control_ref' => 'A.3', 'control_name' => 'Purpose legitimacy and specification', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Process PII only for the purposes expressed in the customer agreement; do not use PII for marketing or advertising without explicit consent.' ],
		[ 'control_ref' => 'A.4', 'control_name' => 'Collection limitation', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Limit collection of PII to what is relevant, proportional and necessary for the specified purposes.' ],
		[ 'control_ref' => 'A.5', 'control_name' => 'Data minimization', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Minimise the PII processed, including secure erasure of temporary files and restriction of PII in printed or displayed material.' ],
		[ 'control_ref' => 'A.6', 'control_name' => 'Use, retention and disclosure limitation', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Restrict use, retention and disclosure of PII to the specified purposes; notify the customer of legally binding disclosure requests and record disclosures.' ],
		[ 'control_ref' => 'A.7', 'control_name' => 'Accuracy and quality', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Support the cloud customer in ensuring PII is accurate, complete and up to date for its intended purposes.' ],
		[ 'control_ref' => 'A.8', 'control_name' => 'Openness, transparency and notice', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Disclose the use of sub-contractors to process PII and the countries where PII may be processed, before or as agreed with the customer.' ],
		[ 'control_ref' => 'A.9', 'control_name' => 'Individual participation and access', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Assist the cloud customer in fulfilling PII principals\' requests for access, correction and erasure of their PII.' ],
		[ 'control_ref' => 'A.10', 'control_name' => 'Accountability', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Notify the cloud customer promptly of any unauthorised access to PII or processing equipment resulting in loss, disclosure or alteration.' ],
		[ 'control_ref' => 'A.11', 'control_name' => 'Information security', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Cloud-specific security measures for PII: confidentiality agreements, restriction of portable media, secure transmission over public networks, secure disposal, and user-id management.' ],
		[ 'control_ref' => 'A.12', 'control_name' => 'Privacy compliance', 'domain' => 'Annex A - Extended Control Set for PII Protection', 'description' => 'Specify and document the countries where PII may be stored, and ensure intended destinations are known to the cloud customer.' ],
	], ],

	// EU NIS2 Directive (2022/2555). The governance and reporting duties
	// (Articles 20, 23) and the ten minimum cybersecurity risk-management
	// measures every in-scope entity must take (Article 21(2)(a)–(j)).
	'nis2' => [ 'mode' => 'fallback', 'controls' => [
		[ 'control_ref' => 'Art. 20', 'control_name' => 'Governance', 'domain' => 'Governance and Reporting', 'description' => 'Management bodies must approve cybersecurity risk-management measures, oversee their implementation, be liable for infringements, and follow (and offer staff) cybersecurity training.' ],
		[ 'control_ref' => 'Art. 21(2)(a)', 'control_name' => 'Risk analysis and information system security policies', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Policies on risk analysis and information system security as the foundation of the entity\'s cybersecurity risk-management measures.' ],
		[ 'control_ref' => 'Art. 21(2)(b)', 'control_name' => 'Incident handling', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Processes and capabilities for preventing, detecting, analysing, containing and responding to incidents.' ],
		[ 'control_ref' => 'Art. 21(2)(c)', 'control_name' => 'Business continuity and crisis management', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Business continuity measures such as backup management and disaster recovery, and crisis management.' ],
		[ 'control_ref' => 'Art. 21(2)(d)', 'control_name' => 'Supply chain security', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Security-related aspects of relationships with direct suppliers and service providers, considering their vulnerabilities and secure development practices.' ],
		[ 'control_ref' => 'Art. 21(2)(e)', 'control_name' => 'Security in acquisition, development and maintenance', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Security in network and information systems acquisition, development and maintenance, including vulnerability handling and disclosure.' ],
		[ 'control_ref' => 'Art. 21(2)(f)', 'control_name' => 'Effectiveness assessment', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Policies and procedures to assess the effectiveness of cybersecurity risk-management measures.' ],
		[ 'control_ref' => 'Art. 21(2)(g)', 'control_name' => 'Cyber hygiene and training', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Basic cyber hygiene practices and cybersecurity training across the organisation.' ],
		[ 'control_ref' => 'Art. 21(2)(h)', 'control_name' => 'Cryptography and encryption', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Policies and procedures regarding the use of cryptography and, where appropriate, encryption.' ],
		[ 'control_ref' => 'Art. 21(2)(i)', 'control_name' => 'Human resources security, access control and asset management', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Human resources security, access control policies and asset management.' ],
		[ 'control_ref' => 'Art. 21(2)(j)', 'control_name' => 'Multi-factor authentication and secured communications', 'domain' => 'Minimum Risk-Management Measures (Art. 21(2))', 'description' => 'Use of multi-factor or continuous authentication, secured voice, video and text communications, and secured emergency communication systems, where appropriate.' ],
		[ 'control_ref' => 'Art. 23', 'control_name' => 'Incident reporting', 'domain' => 'Governance and Reporting', 'description' => 'Report significant incidents to the CSIRT or competent authority: early warning within 24 hours, incident notification within 72 hours, final report within one month.' ],
	], ],
];
