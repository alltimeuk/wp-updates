<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * The chosen LLM provider for AI-driven generation (remediation plans,
 * questionnaire reports, framework readiness), and its credentials.
 *
 * This class currently only resolves *which* provider is selected and
 * whether its credentials are present - it does not yet route any actual
 * generation call. WPQ_Remediation_Plan, WPQ_Questionnaire_Report_Analysis
 * and WPQ_Claude/WPQ_Claude_Client still call Anthropic directly. Wiring a
 * second provider into those call sites is separate follow-up work; Anthropic
 * Claude is the only provider actually used regardless of this setting until
 * that work lands. Framework Readiness specifically depends on Anthropic's
 * hosted Skills/code-execution container to run ATLAS skill bundles, which
 * has no equivalent on the other providers - that capability would need a
 * redesign, not just a swapped API endpoint.
 *
 * Credentials resolve constant -> environment -> option, matching
 * WPQ_Mailer's and WPQ_Secrets' convention.
 */
class WPQ_LLM_Provider {

	public const PROVIDER_ANTHROPIC = 'anthropic';
	public const PROVIDER_COPILOT   = 'copilot';
	public const PROVIDER_OPENAI    = 'openai';
	public const PROVIDER_MCP       = 'mcp';

	public const PROVIDERS = [ self::PROVIDER_ANTHROPIC, self::PROVIDER_COPILOT, self::PROVIDER_OPENAI, self::PROVIDER_MCP ];

	private const OPTION_PROVIDER = 'wpq_llm_provider';

	public static function active_provider(): string {
		$provider = (string) get_option( self::OPTION_PROVIDER, self::PROVIDER_ANTHROPIC );
		return in_array( $provider, self::PROVIDERS, true ) ? $provider : self::PROVIDER_ANTHROPIC;
	}

	/** Human-readable label for a provider key, for admin screens. */
	public static function provider_label( string $provider ): string {
		return [
			self::PROVIDER_ANTHROPIC => 'Anthropic Claude',
			self::PROVIDER_COPILOT   => 'Microsoft Copilot',
			self::PROVIDER_OPENAI    => 'OpenAI ChatGPT',
			self::PROVIDER_MCP       => 'our own MCP server',
		][ $provider ] ?? ucfirst( $provider );
	}

	/**
	 * @return array{value: string, source: string}
	 */
	private static function get_setting_details( string $option, string $constant, string $environment_key ): array {
		if ( defined( $constant ) && constant( $constant ) ) {
			return [ 'value' => (string) constant( $constant ), 'source' => 'constant' ];
		}
		$environment_value = getenv( $environment_key );
		if ( is_string( $environment_value ) && '' !== $environment_value ) {
			return [ 'value' => $environment_value, 'source' => 'environment' ];
		}
		$option_value = (string) get_option( $option, '' );
		return [ 'value' => $option_value, 'source' => '' !== $option_value ? 'option' : 'none' ];
	}

	/** Delegates to the existing Claude API key/model resolution already used for remediation plans and reports. */
	public static function anthropic_settings(): array {
		return [
			'api_key' => class_exists( 'WPQ_Remediation_Plan' ) ? WPQ_Remediation_Plan::get_api_key_details() : [ 'value' => '', 'source' => 'none' ],
		];
	}

	/** @return array<string, array{value: string, source: string}> */
	public static function copilot_settings(): array {
		return [
			'endpoint'   => self::get_setting_details( 'wpq_copilot_endpoint', 'WPQ_COPILOT_ENDPOINT', 'WPQ_COPILOT_ENDPOINT' ),
			'deployment' => self::get_setting_details( 'wpq_copilot_deployment', 'WPQ_COPILOT_DEPLOYMENT', 'WPQ_COPILOT_DEPLOYMENT' ),
			'api_key'    => self::get_setting_details( 'wpq_copilot_api_key', 'WPQ_COPILOT_API_KEY', 'WPQ_COPILOT_API_KEY' ),
		];
	}

	/** @return array<string, array{value: string, source: string}> */
	public static function openai_settings(): array {
		return [
			'api_key' => self::get_setting_details( 'wpq_openai_api_key', 'WPQ_OPENAI_API_KEY', 'WPQ_OPENAI_API_KEY' ),
			'model'   => self::get_setting_details( 'wpq_openai_model', 'WPQ_OPENAI_MODEL', 'WPQ_OPENAI_MODEL' ),
		];
	}

	/** @return array<string, array{value: string, source: string}> */
	public static function mcp_settings(): array {
		return [
			'endpoint' => self::get_setting_details( 'wpq_mcp_endpoint', 'WPQ_MCP_ENDPOINT', 'WPQ_MCP_ENDPOINT' ),
			'api_key'  => self::get_setting_details( 'wpq_mcp_api_key', 'WPQ_MCP_API_KEY', 'WPQ_MCP_API_KEY' ),
		];
	}

	/**
	 * Configuration state per provider, for the settings UI.
	 *
	 * @return array{provider: string, provider_ready: bool, missing: array<int, string>, wired_up: bool}
	 */
	public static function diagnostics(): array {
		$provider = self::active_provider();
		$missing  = [];

		$settings = match ( $provider ) {
			self::PROVIDER_COPILOT => self::copilot_settings(),
			self::PROVIDER_OPENAI  => self::openai_settings(),
			self::PROVIDER_MCP     => self::mcp_settings(),
			default                => self::anthropic_settings(),
		};

		foreach ( $settings as $key => $details ) {
			if ( '' === $details['value'] ) {
				$missing[] = $key;
			}
		}

		return [
			'provider'       => $provider,
			'provider_ready' => empty( $missing ),
			'missing'        => $missing,
			// Only Anthropic Claude is actually called by any generation
			// path today - see the class docblock.
			'wired_up'       => self::PROVIDER_ANTHROPIC === $provider,
		];
	}
}
