<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var string             $email
 * @var array<int, object> $submissions
 * @var array<int, object> $payments
 * @var object|null        $opt_out
 */
$email       = $email       ?? '';
/** @phpstan-ignore-next-line */
$submissions = $submissions ?? [];
/** @phpstan-ignore-next-line */
$payments    = $payments    ?? [];
$opt_out     = $opt_out     ?? null;

$contact_name        = '';
$contact_company     = '';
$contact_phone       = '';
$consent_accepted_at = null;
foreach ( $submissions as $s ) {
	if ( ! $contact_name    && ! empty( $s->contact_name ) )    $contact_name    = $s->contact_name;
	if ( ! $contact_company && ! empty( $s->contact_company ) ) $contact_company = $s->contact_company;
	if ( ! $contact_phone   && ! empty( $s->contact_phone ) )   $contact_phone   = $s->contact_phone;
	if ( ! empty( $s->consent_accepted_at ) ) {
		if ( ! $consent_accepted_at || $s->consent_accepted_at < $consent_accepted_at ) {
			$consent_accepted_at = $s->consent_accepted_at;
		}
	}
}

$is_opted_out  = $opt_out && $opt_out->opted_out;
$back_url      = admin_url( 'admin.php?page=wpq-contacts' );
$nonce_export  = wp_create_nonce( 'wpq_export_contact' );
$nonce_anon    = wp_create_nonce( 'wpq_anonymise_contact' );
$nonce_delete  = wp_create_nonce( 'wpq_delete_contact' );
$has_real_data = ! empty( $submissions ) && ( $submissions[0]->contact_email ?? '' ) !== 'anonymous@deleted.invalid';
?>
<div class="wrap wpq-admin-wrap">
  <h1 style="display:flex;align-items:center;gap:16px;">
    <a href="<?php echo esc_url( $back_url ); ?>" style="font-size:14px;font-weight:400;text-decoration:none;">&larr; Contacts</a>
    Contact: <?php echo esc_html( $email ); ?>
    <?php if ( $is_opted_out ) : ?>
      <span style="font-size:13px;background:#d63638;color:#fff;padding:2px 10px;border-radius:12px;font-weight:600;">Opted out</span>
    <?php endif; ?>
  </h1>

  <div class="wpq-detail-grid" style="grid-template-columns:2fr 1fr;">

    <!-- ============================================================= -->
    <!-- Left column: contact info + submissions                        -->
    <!-- ============================================================= -->
    <div>

      <!-- Contact info -->
      <div class="wpq-card" style="margin-top:0;">
        <h3 style="margin-top:0;">Contact information</h3>
        <table class="widefat" style="max-width:600px;">
          <tbody>
            <tr><td style="width:140px;font-weight:600;">Email</td><td><?php echo esc_html( $email ); ?></td></tr>
            <tr><td style="font-weight:600;">Name</td><td><?php echo esc_html( $contact_name ?: '—' ); ?></td></tr>
            <tr><td style="font-weight:600;">Company</td><td><?php echo esc_html( $contact_company ?: '—' ); ?></td></tr>
            <tr><td style="font-weight:600;">Phone</td><td><?php echo esc_html( $contact_phone ?: '—' ); ?></td></tr>
            <tr>
              <td style="font-weight:600;">Privacy consent</td>
              <td>
                <?php if ( $consent_accepted_at ) : ?>
                  <span style="color:#00a32a;">&#10003; Accepted</span>
                  <span class="description" style="margin-left:6px;"><?php echo esc_html( wp_date( 'd M Y H:i', strtotime( $consent_accepted_at ) ) ); ?></span>
                <?php else : ?>
                  <span class="description">Not recorded</span>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td style="font-weight:600;">Opt-out</td>
              <td>
                <?php if ( $is_opted_out ) : ?>
                  Opted out <?php echo esc_html( $opt_out->opted_out_at ? wp_date( 'd M Y', strtotime( $opt_out->opted_out_at ) ) : '' ); ?>
                  <button type="button" class="button button-small wpq-opt-out-btn" style="margin-left:8px;"
                    data-email="<?php echo esc_attr( $email ); ?>" data-opted-out="0">Remove opt-out</button>
                <?php else : ?>
                  <span class="description">Not opted out.</span>
                  <button type="button" class="button button-small wpq-opt-out-btn" style="margin-left:8px;"
                    data-email="<?php echo esc_attr( $email ); ?>" data-opted-out="1">Mark opted out</button>
                <?php endif; ?>
                <span class="wpq-opt-out-status" style="margin-left:6px;font-size:.85em;"></span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Submissions -->
      <div class="wpq-card">
        <h3 style="margin-top:0;">Submissions (<?php echo count( $submissions ); ?>)</h3>
        <?php if ( empty( $submissions ) ) : ?>
          <p class="description">No submissions found.</p>
        <?php else : ?>
          <table class="wp-list-table widefat striped">
            <thead>
              <tr>
                <th style="width:90px;">Ref</th>
                <th>Questionnaire</th>
                <th style="width:60px;">Score</th>
                <th style="width:80px;">Grade</th>
                <th style="width:90px;">Status</th>
                <th style="width:90px;">Payment</th>
                <th style="width:70px;">Consent</th>
                <th style="width:100px;">Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ( $submissions as $s ) : ?>
                <?php
                $status_text = $s->deleted_at ? 'Deleted' : ( $s->abandoned ? 'Abandoned' : 'Completed' );
                $status_cls  = $s->deleted_at ? 'wpq-status-deleted' : ( $s->abandoned ? '' : 'wpq-status-completed' );
                $sub_url = add_query_arg( [
                    'page'       => 'wpq-submissions',
                    'wpq_action' => 'view',
                    'id'         => $s->id,
                ], admin_url( 'admin.php' ) );
                ?>
                <tr>
                  <td><a href="<?php echo esc_url( $sub_url ); ?>"><?php echo esc_html( $s->ref ); ?></a></td>
                  <td><?php echo esc_html( isset( $s->questionnaire_name ) ? '[' . $s->questionnaire_ref . '] ' . $s->questionnaire_name : '—' ); ?></td>
                  <td style="text-align:center;"><?php echo $s->overall_score !== null ? esc_html( (string) $s->overall_score ) . '%' : '—'; ?></td>
                  <td><?php echo esc_html( $s->grade_label ?? $s->grade_id ?? '—' ); ?></td>
                  <td><span class="<?php echo esc_attr( $status_cls ); ?>"><?php echo esc_html( $status_text ); ?></span></td>
                  <td>
                    <?php if ( $s->payment_status === 'paid' ) : ?>
                      <span class="wpq-status-completed">Paid</span>
                    <?php elseif ( $s->payment_status === 'none' ) : ?>
                      <span class="description">Free</span>
                    <?php else : ?>
                      <?php echo esc_html( ucfirst( $s->payment_status ) ); ?>
                    <?php endif; ?>
                  </td>
                  <td style="text-align:center;">
                    <?php if ( ! empty( $s->consent_accepted_at ) ) : ?>
                      <span style="color:#00a32a;" title="<?php echo esc_attr( wp_date( 'd M Y H:i', strtotime( $s->consent_accepted_at ) ) ); ?>">&#10003;</span>
                    <?php else : ?>
                      <span class="description">—</span>
                    <?php endif; ?>
                  </td>
                  <td><?php echo esc_html( wp_date( 'd M Y', strtotime( $s->created_at ) ) ); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>

      <!-- Payments -->
      <?php if ( ! empty( $payments ) ) : ?>
        <div class="wpq-card">
          <h3 style="margin-top:0;">Payments (<?php echo count( $payments ); ?>)</h3>
          <table class="wp-list-table widefat striped">
            <thead>
              <tr>
                <th>Stripe Session</th>
                <th style="width:90px;">Submission</th>
                <th>Product</th>
                <th style="width:70px;">Amount</th>
                <th style="width:90px;">Status</th>
                <th style="width:100px;">Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ( $payments as $p ) : ?>
                <tr>
                  <td><code style="font-size:.8em;"><?php echo esc_html( $p->session_id ); ?></code></td>
                  <td><?php echo esc_html( $p->submission_ref ); ?></td>
                  <td><?php echo esc_html( $p->product_name ?? '—' ); ?></td>
                  <td>
                    <?php if ( $p->amount_total && $p->currency ) :
                      $sym = match ( strtoupper( $p->currency ) ) { 'USD' => '$', 'EUR' => '€', default => '£' };
                      echo esc_html( $sym . number_format( (int) $p->amount_total / 100, 2 ) );
                    else : ?>
                      <span class="description">—</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if ( $p->payment_status === 'paid' ) : ?>
                      <span class="wpq-status-completed">Paid</span>
                    <?php else : ?>
                      <?php echo esc_html( ucfirst( $p->payment_status ) ); ?>
                    <?php endif; ?>
                  </td>
                  <td><?php echo esc_html( wp_date( 'd M Y', strtotime( $p->created_at ) ) ); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

    </div>

    <!-- ============================================================= -->
    <!-- Right column: GDPR operations                                  -->
    <!-- ============================================================= -->
    <div>
      <div class="wpq-card" style="margin-top:0;">
        <h3 style="margin-top:0;">GDPR Data Subject Rights</h3>
        <p class="description">These operations are irreversible. Export a copy of the data before anonymising or deleting.</p>

        <!-- Export -->
        <h4 style="margin-bottom:4px;">Export data</h4>
        <p class="description">Downloads all submission and payment data for this contact as a JSON file.</p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
          <?php wp_nonce_field( 'wpq_export_contact' ); ?>
          <input type="hidden" name="action" value="wpq_export_contact">
          <input type="hidden" name="email" value="<?php echo esc_attr( $email ); ?>">
          <button type="submit" class="button">Download JSON</button>
        </form>

        <hr style="margin:20px 0;">

        <!-- Anonymise -->
        <h4 style="margin-bottom:4px;">Anonymise</h4>
        <p class="description">Replaces name, email, company, phone, and IP address with anonymous placeholders. Scores and domain data are preserved. Cannot be undone.</p>
        <?php if ( $has_real_data ) : ?>
          <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                onsubmit="return confirm('Anonymise all submissions for <?php echo esc_js( $email ); ?>?\n\nThis replaces personal data with anonymous placeholders and cannot be undone.');">
            <?php wp_nonce_field( 'wpq_anonymise_contact' ); ?>
            <input type="hidden" name="action" value="wpq_anonymise_contact">
            <input type="hidden" name="email" value="<?php echo esc_attr( $email ); ?>">
            <button type="submit" class="button" style="color:#d63638;border-color:#d63638;">Anonymise contact</button>
          </form>
        <?php else : ?>
          <p class="description" style="color:#888;">Contact data already anonymised.</p>
        <?php endif; ?>

        <hr style="margin:20px 0;">

        <!-- Delete -->
        <h4 style="margin-bottom:4px;">Delete</h4>
        <p class="description">Permanently hard-deletes all submissions for this contact. This is irreversible — export first.</p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
              onsubmit="return confirm('PERMANENTLY DELETE all submissions and data for <?php echo esc_js( $email ); ?>?\n\nThis cannot be undone. Export first if you need a record.');">
          <?php wp_nonce_field( 'wpq_delete_contact' ); ?>
          <input type="hidden" name="action" value="wpq_delete_contact">
          <input type="hidden" name="email" value="<?php echo esc_attr( $email ); ?>">
          <button type="submit" class="button" style="color:#d63638;border-color:#d63638;">Delete contact &amp; submissions</button>
        </form>

        <hr style="margin:20px 0;">

        <!-- Opt-out -->
        <h4 style="margin-bottom:4px;">Marketing opt-out</h4>
        <p class="description">Suppresses future contact by recording a preference. Does not delete any data — use Delete or Anonymise for erasure requests.</p>
        <?php if ( $is_opted_out ) : ?>
          <p><span style="color:#d63638;font-weight:600;">Opted out</span>
            <?php if ( $opt_out->opted_out_at ) : ?>
              on <?php echo esc_html( wp_date( 'd M Y', strtotime( $opt_out->opted_out_at ) ) ); ?>
            <?php endif; ?>
          </p>
          <button type="button" class="button wpq-opt-out-btn"
            data-email="<?php echo esc_attr( $email ); ?>" data-opted-out="0">Remove opt-out</button>
        <?php else : ?>
          <button type="button" class="button wpq-opt-out-btn"
            data-email="<?php echo esc_attr( $email ); ?>" data-opted-out="1">Mark as opted out</button>
        <?php endif; ?>
        <span class="wpq-opt-out-status" style="display:block;margin-top:6px;font-size:.85em;"></span>
      </div>
    </div>

  </div><!-- .wpq-detail-grid -->
</div>
