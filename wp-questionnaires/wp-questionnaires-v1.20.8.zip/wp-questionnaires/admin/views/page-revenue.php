<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Pricing, Coupons, and Orders combined onto one screen as collapsible
 * sections — they are all facets of the same paid report checkout flow, so
 * reviewing one usually means checking the others.
 *
 * @var array<int, object{id:int, questionnaire_ref?: string|null, questionnaire_id?: int|null, name:string, description:string, price_gbp:numeric-string|float|int, billing_type:string, report_type:string, stripe_price_id:string|null, status:string}> $products
 * @var array<int, object>                                                                                                                                                                    $coupons
 * @var array<int, object>                                                                                                                                                                    $questionnaires
 * @var array<int, object>                                                                                                                                                                    $orders
 * @var array<int, object{currency:string, paid_count:int, total_amount:int}>                                                                                                                 $revenue_summary
 * @var int                                                                                                                                                                                    $orders_total
 * @var int                                                                                                                                                                                    $orders_per_page
 * @var int                                                                                                                                                                                    $orders_page
 * @var string                                                                                                                                                                                 $orders_search
 */
$products        = $products        ?? [];
/** @phpstan-ignore-next-line */
$coupons         = $coupons         ?? [];
/** @phpstan-ignore-next-line */
$questionnaires  = $questionnaires  ?? [];
/** @phpstan-ignore-next-line */
$orders          = $orders          ?? [];
/** @phpstan-ignore-next-line */
$revenue_summary = $revenue_summary ?? [];
/** @phpstan-ignore-next-line */
$orders_total    = $orders_total    ?? 0;
/** @phpstan-ignore-next-line */
$orders_per_page = $orders_per_page ?? 50;
/** @phpstan-ignore-next-line */
$orders_page     = $orders_page     ?? 1;
/** @phpstan-ignore-next-line */
$orders_search   = $orders_search   ?? '';

$checkout_readiness = isset( $checkout_readiness ) && is_array( $checkout_readiness ) ? $checkout_readiness : [
	'checkout_enabled'        => false,
	'publishable_key_present' => false,
	'secret_key_present'      => false,
	'webhook_secret_present'  => false,
	'publishable_key_valid'   => false,
	'publishable_key_source'  => 'none',
	'secret_key_valid'        => false,
	'secret_key_source'       => 'none',
	'webhook_secret_valid'    => false,
	'webhook_secret_source'   => 'none',
	'active_product_count'    => 0,
	'priced_product_count'    => 0,
];

$sorted_questionnaires = $questionnaires;
usort( $sorted_questionnaires, fn( $a, $b ) => strcmp( $a->name, $b->name ) );
$qs_with_product = array_filter( $questionnaires, fn( $q ) => ! empty( $q->stripe_product_id ) );

if ( ! function_exists( 'wpq_format_discount' ) ) {
	function wpq_format_discount( object $c ): string {
		if ( $c->discount_type === 'percent' ) {
			return (int) $c->percent_off . '%';
		}
		$symbol = match ( strtoupper( (string) $c->currency ) ) {
			'USD' => '$', 'EUR' => '€', 'AUD' => 'A$', 'CAD' => 'C$', default => '£',
		};
		return $symbol . number_format( (int) $c->amount_off / 100, 2 );
	}
}

if ( ! function_exists( 'wpq_format_duration' ) ) {
	function wpq_format_duration( object $c ): string {
		return match ( $c->duration ) {
			'once'       => 'Once',
			'forever'    => 'Forever',
			'repeating'  => (int) $c->duration_in_months . ' months',
			default      => ucfirst( $c->duration ),
		};
	}
}

if ( ! function_exists( 'wpq_format_scope' ) ) {
	function wpq_format_scope( object $c ): string {
		if ( $c->scope === 'questionnaire' ) {
			$label = $c->questionnaire_ref ? '[' . $c->questionnaire_ref . '] ' . $c->questionnaire_name : $c->questionnaire_name ?? '—';
			return 'Questionnaire: ' . $label;
		}
		if ( $c->scope === 'catalogue_item' ) {
			return 'Catalogue: ' . ( $c->product_name ?? '—' );
		}
		return 'All products';
	}
}

$currency_symbol = static fn( string $currency ): string => match ( strtoupper( $currency ) ) {
	'USD' => '$', 'EUR' => '€', 'AUD' => 'A$', 'CAD' => 'C$', default => '£',
};

$active_products_count = count( array_filter( $products, static fn( $p ) => $p->status === 'active' ) );
$active_coupons_count  = count( array_filter( $coupons, static fn( $c ) => $c->status === 'active' ) );

$orders_total_pages = $orders_per_page > 0 ? (int) ceil( $orders_total / $orders_per_page ) : 1;
$orders_base_url    = admin_url( 'admin.php?page=wpq-revenue' );

$status_styles = [
	'none'    => 'background:#6c757d;color:#fff;',
	'pending' => 'background:#fd7e14;color:#fff;',
	'paid'    => 'background:#198754;color:#fff;',
	'failed'  => 'background:#dc3545;color:#fff;',
	'expired' => 'background:#6c757d;color:#fff;',
];
$status_labels = [
	'none'    => 'None',
	'pending' => 'Pending',
	'paid'    => 'Paid',
	'failed'  => 'Failed',
	'expired' => 'Expired',
];
?>
<style>
.wpq-revenue-metrics { display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:12px; max-width:1100px; margin:16px 0 24px; }
.wpq-revenue-metric { background:#fff; border:1px solid #c3c4c7; border-radius:2px; padding:14px 18px; }
.wpq-revenue-metric .num { font-size:22px; font-weight:600; line-height:1.2; }
.wpq-revenue-metric .label { font-size:12px; color:#666; margin-top:2px; }
.wpq-revenue-section { max-width:1200px; margin-bottom:16px; border:1px solid #c3c4c7; border-radius:2px; background:#fff; }
.wpq-revenue-section > summary { cursor:pointer; padding:14px 18px; font-size:16px; font-weight:600; list-style:none; display:flex; align-items:center; gap:8px; }
.wpq-revenue-section > summary::-webkit-details-marker { display:none; }
.wpq-revenue-section > summary::before { content:"\25B8"; display:inline-block; transition:transform .15s; font-size:12px; color:#666; }
.wpq-revenue-section[open] > summary::before { transform:rotate(90deg); }
.wpq-revenue-section > summary .description { font-weight:400; font-size:12px; }
.wpq-revenue-body { padding:0 18px 18px; }
</style>

<div class="wrap wpq-admin-wrap">
<h1>Revenue</h1>
<p class="description">Pricing, coupons, and paid-report orders in one place.</p>

<div class="wpq-revenue-metrics">
	<div class="wpq-revenue-metric">
		<div class="num"><?php echo esc_html( (string) $active_products_count ); ?></div>
		<div class="label">Active pricing options (<?php echo esc_html( (string) count( $products ) ); ?> total)</div>
	</div>
	<div class="wpq-revenue-metric">
		<div class="num"><?php echo esc_html( (string) $active_coupons_count ); ?></div>
		<div class="label">Active coupons</div>
	</div>
	<div class="wpq-revenue-metric">
		<div class="num"><?php echo esc_html( number_format( $orders_total ) ); ?></div>
		<div class="label">Total orders</div>
	</div>
	<div class="wpq-revenue-metric">
		<?php if ( empty( $revenue_summary ) ) : ?>
			<div class="num">£0.00</div>
			<div class="label">Revenue (paid)</div>
		<?php else : ?>
			<?php foreach ( $revenue_summary as $row ) : ?>
				<div class="num"><?php echo esc_html( $currency_symbol( (string) $row->currency ) . number_format( (int) $row->total_amount / 100, 2 ) ); ?></div>
				<div class="label">Revenue — <?php echo esc_html( strtoupper( (string) $row->currency ) ); ?> (<?php echo esc_html( (string) $row->paid_count ); ?> paid)</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
</div>

<!-- ==================================================================== -->
<!-- Pricing                                                               -->
<!-- ==================================================================== -->
<details class="wpq-revenue-section" id="wpq-revenue-pricing" open>
<summary><h2 style="display:inline;margin:0;font-size:inherit;">Pricing</h2> <span class="description">Paid report pricing options</span></summary>
<div class="wpq-revenue-body">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <button type="button" id="wpq-add-product" class="page-title-action">Add Pricing Option</button>
    <div style="display:flex;align-items:center;gap:6px;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="button" title="Import pricing">&#8593; Import</a>
      <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=pricing' ), 'wpq_export_pricing' ) ); ?>" class="button" title="Export all pricing">&#8595; Export all</a>
    </div>
  </div>
  <p class="description">Set a Stripe Price ID and mark an option <strong>Active</strong> to enable the upgrade CTA on the results screen.</p>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;"
       data-export-type="pricing"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_pricing' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">— Bulk action —</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
    <span style="flex:1;"></span>
    <input type="search" class="wpq-table-filter" style="height:30px;width:220px;" placeholder="Filter pricing…" aria-label="Filter pricing options">
    <span class="wpq-table-filter-count description"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" style="margin-top:8px;" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th class="wpq-col-ref">Ref</th>
        <th>Name</th>
        <th class="wpq-col-price">Price</th>
        <th class="wpq-col-billing">Billing</th>
        <th class="wpq-col-stripe">Stripe Price ID</th>
        <th class="wpq-col-status">Status</th>
        <th class="wpq-col-action" data-no-sort></th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $products ) ) : ?>
        <tr><td colspan="8">No pricing options found. Click <strong>Add Pricing Option</strong> to create one.</td></tr>
      <?php else : ?>
        <?php foreach ( $products as $p ) : ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo (int) $p->id; ?>"></td>
            <td><?php echo esc_html( $p->questionnaire_ref ?? '—' ); ?></td>
            <td>
              <strong><?php echo esc_html( $p->name ); ?></strong>
              <br><span class="description"><?php echo esc_html( $p->description ); ?></span>
            </td>
            <td>£<?php echo number_format( (float) $p->price_gbp, 2 ); ?></td>
            <td><?php echo esc_html( str_replace( '_', ' ', $p->billing_type ) ); ?></td>
            <td>
              <?php if ( $p->stripe_price_id ) : ?>
                <code><?php echo esc_html( $p->stripe_price_id ); ?></code>
              <?php else : ?>
                <span class="description">Not set</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ( $p->status === 'active' ) : ?>
                <span class="wpq-status-active">&#9679; Active</span>
              <?php else : ?>
                <span class="wpq-status-inactive">&#9679; Inactive</span>
              <?php endif; ?>
            </td>
            <td style="white-space:nowrap;">
              <button type="button" class="button button-small wpq-edit-product"
                data-id="<?php echo (int) $p->id; ?>"
                data-name="<?php echo esc_attr( $p->name ); ?>"
                data-description="<?php echo esc_attr( $p->description ); ?>"
                data-price="<?php echo esc_attr( $p->price_gbp ); ?>"
                data-stripe="<?php echo esc_attr( $p->stripe_price_id ); ?>"
                data-billing="<?php echo esc_attr( $p->billing_type ); ?>"
                data-report="<?php echo esc_attr( $p->report_type ); ?>"
                data-status="<?php echo esc_attr( $p->status ); ?>"
                data-questionnaire="<?php echo esc_attr( $p->questionnaire_id ?? '' ); ?>"
              >Edit</button>
              <button type="button" class="button button-small wpq-delete-product"
                data-id="<?php echo (int) $p->id; ?>"
                data-name="<?php echo esc_attr( $p->name ); ?>"
                style="color:#a00;"
              >Delete</button>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- Inline product editor -->
  <div id="wpq-product-editor" class="wpq-card wpq-hidden" style="margin-top:24px;max-width:800px;">
    <h2 id="wpq-pe-title" style="margin-top:0;">Add Pricing Option</h2>
    <input type="hidden" id="wpq-pe-id" value="">

    <table class="form-table" style="margin-top:0;">
      <tr>
        <th style="width:180px;"><label for="wpq-pe-name">Name <span style="color:#d63638;">*</span></label></th>
        <td><input type="text" id="wpq-pe-name" class="regular-text" placeholder="e.g. CyberCheck Professional Report"></td>
      </tr>
      <tr>
        <th><label for="wpq-pe-description">Description</label></th>
        <td><textarea id="wpq-pe-description" class="large-text" rows="3" placeholder="Shown on the upgrade CTA"></textarea></td>
      </tr>
      <tr>
        <th><label for="wpq-pe-questionnaire">Questionnaire</label></th>
        <td>
          <select id="wpq-pe-questionnaire">
            <option value="">— All / cross-questionnaire —</option>
            <?php foreach ( $sorted_questionnaires as $q ) : ?>
              <option value="<?php echo (int) $q->id; ?>"><?php echo esc_html( '[' . $q->ref . '] ' . $q->name ); ?></option>
            <?php endforeach; ?>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-price">Price (GBP)</label></th>
        <td><input type="number" id="wpq-pe-price" class="small-text" step="0.01" min="0" value="0.00"></td>
      </tr>
      <tr>
        <th><label for="wpq-pe-billing">Billing type</label></th>
        <td>
          <select id="wpq-pe-billing">
            <option value="one_off">One-off payment</option>
            <option value="subscription_annual">Annual subscription</option>
            <option value="subscription_monthly">Monthly subscription</option>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-report">Report type</label></th>
        <td>
          <select id="wpq-pe-report">
            <option value="professional">Professional</option>
            <option value="annual">Annual</option>
            <option value="bundle">Bundle</option>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-stripe">Stripe Price ID</label></th>
        <td>
          <input type="text" id="wpq-pe-stripe" class="regular-text" placeholder="price_…">
          <p class="description">Auto-created in Stripe on save when the linked questionnaire has a Stripe product. Or enter an existing <code>price_…</code> ID manually.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-status">Status</label></th>
        <td>
          <select id="wpq-pe-status">
            <option value="inactive">Inactive</option>
            <option value="active">Active</option>
          </select>
          <p class="description">Stripe Price ID is auto-created on save when a questionnaire with a Stripe product is linked.</p>
        </td>
      </tr>
    </table>

    <p>
      <button type="button" id="wpq-save-product" class="button button-primary">Save</button>
      <button type="button" id="wpq-cancel-product" class="button" style="margin-left:8px;">Cancel</button>
      <span id="wpq-pe-status-msg" style="margin-left:12px;" class="wpq-hidden"></span>
    </p>
  </div>
</div>
</details>

<!-- ==================================================================== -->
<!-- Coupons                                                               -->
<!-- ==================================================================== -->
<details class="wpq-revenue-section" id="wpq-revenue-coupons">
<summary><h2 style="display:inline;margin:0;font-size:inherit;">Coupons &amp; Promo Codes</h2> <span class="description">Stripe discount codes</span></summary>
<div class="wpq-revenue-body">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <button type="button" id="wpq-add-coupon" class="page-title-action">Create Coupon</button>
    <div style="display:flex;align-items:center;gap:6px;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="button" title="Import coupons">&#8593; Import</a>
      <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=coupons' ), 'wpq_export_coupons' ) ); ?>" class="button" title="Export all coupons">&#8595; Export all</a>
    </div>
  </div>
  <p class="description">Coupons are created in your Stripe account and can optionally be restricted to a specific questionnaire or pricing catalogue item.</p>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;"
       data-export-type="coupons"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_coupons' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">— Bulk action —</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
    <span style="flex:1;"></span>
    <input type="search" class="wpq-table-filter" style="height:30px;width:220px;" placeholder="Filter coupons…" aria-label="Filter coupons">
    <span class="wpq-table-filter-count description"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" style="margin-top:8px;" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th style="width:130px;">Promo Code</th>
        <th>Name</th>
        <th style="width:80px;">Discount</th>
        <th style="width:100px;">Duration</th>
        <th>Applies To</th>
        <th style="width:120px;">Expires</th>
        <th style="width:80px;">Status</th>
        <th style="width:70px;" data-no-sort></th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $coupons ) ) : ?>
        <tr><td colspan="9">No coupons yet. Click <strong>Create Coupon</strong> to add one.</td></tr>
      <?php else : ?>
        <?php foreach ( $coupons as $c ) : ?>
          <?php if ( $c->status === 'deleted' ) continue; ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo (int) $c->id; ?>"></td>
            <td>
              <?php if ( $c->promo_code ) : ?>
                <code style="font-size:12px;"><?php echo esc_html( $c->promo_code ); ?></code>
              <?php else : ?>
                <span class="description">No code</span>
              <?php endif; ?>
            </td>
            <td>
              <?php echo esc_html( $c->name ); ?>
              <br><code style="font-size:11px;color:#666;"><?php echo esc_html( $c->stripe_coupon_id ); ?></code>
            </td>
            <td><?php echo esc_html( wpq_format_discount( $c ) ); ?></td>
            <td><?php echo esc_html( wpq_format_duration( $c ) ); ?></td>
            <td><?php echo esc_html( wpq_format_scope( $c ) ); ?></td>
            <td>
              <?php if ( $c->redeem_by ) : ?>
                <?php echo esc_html( wp_date( 'd M Y', strtotime( $c->redeem_by ) ) ); ?>
              <?php else : ?>
                <span class="description">No expiry</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ( $c->status === 'active' ) : ?>
                <span class="wpq-status-active">&#9679; Active</span>
              <?php else : ?>
                <span class="wpq-status-inactive">&#9679; Deleted</span>
              <?php endif; ?>
            </td>
            <td>
              <button type="button" class="button button-small wpq-delete-coupon"
                data-id="<?php echo (int) $c->id; ?>"
                data-name="<?php echo esc_attr( $c->name ); ?>">Delete</button>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- Inline create form -->
  <div id="wpq-coupon-form" class="wpq-card wpq-hidden" style="margin-top:24px;max-width:800px;">
    <h2 style="margin-top:0;">Create Coupon</h2>

    <table class="form-table" style="margin-top:0;">
      <tr>
        <th style="width:200px;"><label for="wpq-cf-name">Name <span style="color:#d63638;">*</span></label></th>
        <td>
          <input type="text" id="wpq-cf-name" class="regular-text" placeholder="e.g. Summer 2026 Discount">
          <p class="description">Internal label — shown in your Stripe dashboard.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-code">Promo Code</label></th>
        <td>
          <input type="text" id="wpq-cf-code" class="regular-text" placeholder="e.g. SUMMER25" style="text-transform:uppercase;" maxlength="50">
          <p class="description">Customer-facing code they type at checkout. Leave blank for a coupon without a public code (applied programmatically). Letters, numbers, hyphens and underscores only.</p>
        </td>
      </tr>
      <tr>
        <th>Discount type</th>
        <td>
          <label><input type="radio" name="wpq_cf_discount_type" value="percent" checked> Percent off</label>
          &nbsp;&nbsp;
          <label><input type="radio" name="wpq_cf_discount_type" value="fixed"> Fixed amount off</label>
        </td>
      </tr>
      <tr id="wpq-cf-row-percent">
        <th><label for="wpq-cf-percent">Percent off <span style="color:#d63638;">*</span></label></th>
        <td>
          <input type="number" id="wpq-cf-percent" class="small-text" min="1" max="100" value="10"> %
        </td>
      </tr>
      <tr id="wpq-cf-row-fixed" class="wpq-hidden">
        <th><label for="wpq-cf-amount">Amount off <span style="color:#d63638;">*</span></label></th>
        <td>
          <input type="number" id="wpq-cf-amount" class="small-text" min="0.01" step="0.01" value="0.00">
          <select id="wpq-cf-currency" style="margin-left:8px;">
            <option value="GBP">GBP (£)</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="AUD">AUD</option>
            <option value="CAD">CAD</option>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-duration">Duration</label></th>
        <td>
          <select id="wpq-cf-duration">
            <option value="once">Once — applied once per customer</option>
            <option value="repeating">Repeating — applied for N months (subscriptions)</option>
            <option value="forever">Forever — applies every payment</option>
          </select>
        </td>
      </tr>
      <tr id="wpq-cf-row-months" class="wpq-hidden">
        <th><label for="wpq-cf-months">Duration (months)</label></th>
        <td><input type="number" id="wpq-cf-months" class="small-text" min="1" value="3"></td>
      </tr>
      <tr>
        <th><label for="wpq-cf-max">Max redemptions</label></th>
        <td>
          <input type="number" id="wpq-cf-max" class="small-text" min="1" placeholder="Unlimited">
          <p class="description">Leave blank for unlimited uses.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-expiry">Expiry date</label></th>
        <td>
          <input type="date" id="wpq-cf-expiry">
          <p class="description">Leave blank for no expiry.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-scope">Applies to</label></th>
        <td>
          <select id="wpq-cf-scope">
            <option value="all">All products</option>
            <option value="questionnaire">Specific questionnaire (one Stripe product)</option>
            <option value="catalogue_item">Specific pricing (one Stripe price)</option>
          </select>
        </td>
      </tr>
      <tr id="wpq-cf-row-questionnaire" class="wpq-hidden">
        <th><label for="wpq-cf-questionnaire">Questionnaire</label></th>
        <td>
          <select id="wpq-cf-questionnaire">
            <option value="">— Select questionnaire —</option>
            <?php foreach ( $qs_with_product as $q ) : ?>
              <option value="<?php echo (int) $q->id; ?>">[<?php echo esc_html( $q->ref ); ?>] <?php echo esc_html( $q->name ); ?> <small>(<?php echo esc_html( $q->stripe_product_id ); ?>)</small></option>
            <?php endforeach; ?>
          </select>
          <?php if ( empty( $qs_with_product ) ) : ?>
            <p class="description" style="color:#a00;">No questionnaires have a Stripe Product ID set. Edit a questionnaire in the Library to add one.</p>
          <?php else : ?>
            <p class="description">Stripe will restrict this coupon to the selected questionnaire's product. Only questionnaires with a Stripe Product ID are shown.</p>
          <?php endif; ?>
        </td>
      </tr>
      <tr id="wpq-cf-row-product" class="wpq-hidden">
        <th><label for="wpq-cf-product">Catalogue item</label></th>
        <td>
          <select id="wpq-cf-product">
            <option value="">— Select pricing option —</option>
            <?php foreach ( $products as $p ) : ?>
              <option value="<?php echo (int) $p->id; ?>"><?php echo esc_html( $p->name ); ?><?php if ( $p->stripe_price_id ) echo ' (' . esc_html( $p->stripe_price_id ) . ')'; ?></option>
            <?php endforeach; ?>
          </select>
          <p class="description">The coupon association is stored locally. Stripe does not support restricting coupons by price — apply this coupon at checkout for the selected item.</p>
        </td>
      </tr>
    </table>

    <p>
      <button type="button" id="wpq-save-coupon" class="button button-primary">Create in Stripe</button>
      <button type="button" id="wpq-cancel-coupon" class="button" style="margin-left:8px;">Cancel</button>
      <span id="wpq-cf-status" style="margin-left:12px;" class="wpq-hidden"></span>
    </p>
  </div>
</div>
</details>

<!-- ==================================================================== -->
<!-- Orders                                                                -->
<!-- ==================================================================== -->
<details class="wpq-revenue-section" id="wpq-revenue-orders">
<summary><h2 style="display:inline;margin:0;font-size:inherit;">Orders</h2> <span class="description">All Stripe payment sessions</span></summary>
<div class="wpq-revenue-body">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <p class="description" style="margin:0;">Read-only — manage individual payments in the Stripe dashboard.</p>
    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=orders' ), 'wpq_export_orders' ) ); ?>" class="button" title="Export all orders">&#8595; Export all</a>
  </div>

  <form method="get" style="margin:16px 0 8px;display:flex;gap:8px;align-items:center;">
    <input type="hidden" name="page" value="wpq-revenue">
    <input type="search" name="s" value="<?php echo esc_attr( $orders_search ); ?>" placeholder="Search email, name or session ID&hellip;" class="regular-text">
    <button type="submit" class="button">Search</button>
    <?php if ( $orders_search ) : ?>
      <a href="<?php echo esc_url( $orders_base_url ); ?>#wpq-revenue-orders" class="button">Clear</a>
    <?php endif; ?>
    <span class="description" style="margin-left:8px;"><?php echo esc_html( number_format( $orders_total ) ); ?> order<?php echo $orders_total !== 1 ? 's' : ''; ?></span>
  </form>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;"
       data-export-type="orders"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_orders' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">— Bulk action —</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th style="width:140px;">Date</th>
        <th>Contact</th>
        <th>Questionnaire</th>
        <th style="width:160px;">Product</th>
        <th style="width:80px;">Status</th>
        <th style="width:100px;text-align:right;">Amount</th>
        <th style="width:120px;" data-no-sort>Session</th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $orders ) ) : ?>
        <tr><td colspan="8">No orders found<?php echo $orders_search ? ' matching "' . esc_html( $orders_search ) . '"' : ''; ?>.</td></tr>
      <?php else : ?>
        <?php foreach ( $orders as $o ) : ?>
          <?php
          $order_date    = $o->created_at ? wp_date( 'd M Y H:i', strtotime( $o->created_at ) ) : '—';
          $order_amount  = $o->amount_total !== null
                     ? number_format( (int) $o->amount_total / 100, 2 ) . ' ' . strtoupper( (string) $o->currency )
                     : '—';
          $order_status_style = $status_styles[ $o->payment_status ] ?? $status_styles['none'];
          $order_status_label = $status_labels[ $o->payment_status ] ?? ucfirst( $o->payment_status );
          $order_contact_url  = add_query_arg( [
              'page'       => 'wpq-contacts',
              'wpq_action' => 'view',
              'email'      => rawurlencode( $o->contact_email ),
          ], admin_url( 'admin.php' ) );
          ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo esc_attr( $o->session_id ); ?>"></td>
            <td><?php echo esc_html( $order_date ); ?></td>
            <td>
              <a href="<?php echo esc_url( $order_contact_url ); ?>"><?php echo esc_html( $o->contact_email ); ?></a>
              <?php if ( $o->contact_name ) : ?>
                <br><span class="description"><?php echo esc_html( $o->contact_name ); ?></span>
              <?php endif; ?>
            </td>
            <td><?php echo esc_html( $o->questionnaire_name ?: '—' ); ?></td>
            <td><?php echo esc_html( $o->product_name ?: '—' ); ?></td>
            <td>
              <span style="display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;<?php echo esc_attr( $order_status_style ); ?>">
                <?php echo esc_html( $order_status_label ); ?>
              </span>
            </td>
            <td style="text-align:right;font-variant-numeric:tabular-nums;"><?php echo esc_html( $order_amount ); ?></td>
            <td>
              <span title="<?php echo esc_attr( $o->session_id ); ?>" style="font-family:monospace;font-size:11px;">
                <?php echo esc_html( substr( (string) $o->session_id, 0, 18 ) . ( strlen( (string) $o->session_id ) > 18 ? '...' : '' ) ); ?>
              </span>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <?php if ( $orders_total_pages > 1 ) : ?>
    <div style="margin-top:16px;">
      <?php
      // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- paginate_links returns safe HTML
      echo paginate_links( [
          'base'      => add_query_arg( 'paged', '%#%', esc_url( $orders_base_url . ( $orders_search ? '&s=' . rawurlencode( $orders_search ) : '' ) ) ),
          'format'    => '',
          'current'   => $orders_page,
          'total'     => $orders_total_pages,
          'prev_text' => '&laquo;',
          'next_text' => '&raquo;',
      ] );
      // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
      ?>
    </div>
  <?php endif; ?>
</div>
</details>

</div>
<script>
(function () {
	// Remembers which sections are open across reloads (e.g. after saving a
	// product or coupon, or paging through orders) so the admin doesn't lose
	// their place. Native <details> toggling works fine without this.
	var STORAGE_KEY = 'wpqRevenueOpenSections';
	var sections = document.querySelectorAll('.wpq-revenue-section');
	var stored;
	try {
		stored = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '{}');
	} catch (e) {
		stored = {};
	}

	if (window.location.hash && document.getElementById(window.location.hash.slice(1))) {
		document.getElementById(window.location.hash.slice(1)).open = true;
	} else {
		sections.forEach(function (el) {
			if (Object.prototype.hasOwnProperty.call(stored, el.id)) {
				el.open = !!stored[el.id];
			}
		});
	}

	sections.forEach(function (el) {
		el.addEventListener('toggle', function () {
			var state;
			try {
				state = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '{}');
			} catch (e) {
				state = {};
			}
			state[el.id] = el.open;
			window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
		});
	});
})();
</script>
