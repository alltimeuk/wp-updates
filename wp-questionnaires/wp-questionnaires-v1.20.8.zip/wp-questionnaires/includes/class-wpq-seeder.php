<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Seeder {

	public static function seed_all(): void {
		if ( WPQ_Database::get_questionnaire_any_status_by_ref( 'CS01' ) ) {
			return;
		}
		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );
		$seeded = self::seed_cs01_cybercheck_2026();
		if ( ! $seeded ) {
			$wpdb->query( 'ROLLBACK' );
			return;
		}
		$wpdb->query( 'COMMIT' );
	}

	/**
	 * Import the committed questionnaire library data file.
	 * Safe to call on every activation — skips already-seeded questionnaires.
	 */
	public static function seed_library(): void {
		$importer = new WPQ_Questionnaire_Library_Importer();
		$importer->import();

		// Promote any draft library questionnaires left over from earlier seeds
		// that used status = 'draft'. Safe to run on every activation.
		// Status 'live' is the equivalent of the former 'published'.
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $wpdb->prefix is a table-name prefix, not user input.
		$wpdb->query( "UPDATE {$wpdb->prefix}wpq_questionnaires SET status = 'live' WHERE created_by_seed = 1 AND status = 'draft'" );
	}

	/**
	 * Idempotent: adds a default domain to questionnaires that have none,
	 * and adds a standard 5-grade threshold set to questionnaires that have none.
	 * Safe to call on every activation — only acts where data is missing.
	 */
	public static function enrich_library_questionnaires(): void {
		$questionnaires = WPQ_Database::get_questionnaire_list();
		foreach ( $questionnaires as $q ) {
			$q_id = (int) $q->id;

			// Add a fallback domain if none exists.
			if ( empty( WPQ_Database::get_domains( $q_id ) ) ) {
				WPQ_Database::insert_domain( [
					'questionnaire_id' => $q_id,
					'sort_order'       => 1,
					'slug'             => 'questions',
					'name'             => 'Questions',
					'icon'             => '',
					'domain_weight'    => 100,
				] );
			}

			// Add standard grade thresholds if none exist.
			if ( empty( WPQ_Database::get_grade_thresholds( $q_id ) ) ) {
				self::insert_default_grades( $q_id );
			}
		}
	}

	private static function insert_default_grades( int $questionnaire_id ): void {
		WPQ_Database::insert_default_grade_thresholds( $questionnaire_id );
	}

	public static function seed_cs01_update(): void {
		$q = WPQ_Database::get_questionnaire_any_status_by_ref( 'CS01' );
		if ( ! $q ) {
			self::seed_all();
			return;
		}
		$current = isset( $q->source_version ) ? (string) $q->source_version : '0';
		if ( version_compare( $current, '16', '>=' ) ) {
			return;
		}
		global $wpdb;
		$wpdb->update(
			"{$wpdb->prefix}wpq_questionnaires",
			[
				'source_name'           => 'Cyber Essentials Self Assessment Questionnaire',
				'source_question_set'   => 'DANZELL',
				'source_effective_date' => '2026-04-27',
				'source_version'        => '16',
				'source_file'           => 'AT-CE-2026-Self-Assessment-QuestionSet.xlsx',
			],
			[ 'ref' => 'CS01' ]
		);
	}

	// ------------------------------------------------------------------ //
	// Helpers
	// ------------------------------------------------------------------ //

	private static function insert_q( int $domain_id, int $sort_order, array $q ): int {
		return WPQ_Database::insert_question( [
			'domain_id'        => $domain_id,
			'sort_order'       => $sort_order,
			'question_ref'     => $q['ref'],
			'question_text'    => $q['text'],
			'guidance_yes'     => $q['guidance_yes'] ?? '',
			'guidance_no'      => $q['guidance_no'] ?? '',
			'recommendation'   => $q['recommendation'] ?? $q['guidance_no'] ?? '',
			'score_yes'        => $q['score_yes'] ?? 0,
			'score_no'         => $q['score_no'] ?? 0,
			'score_partial'    => 0,
			'max_score'        => $q['max_score'] ?? null,
			'question_type'    => $q['type'] ?? 'boolean',
			'scoring_mode'     => $q['mode'] ?? 'non_scoring',
			'is_required'      => $q['required'] ?? 1,
			'help_text'        => $q['help'] ?? '',
			'min_selections'   => $q['min_sel'] ?? null,
			'max_selections'   => $q['max_sel'] ?? null,
			'condition_on_ref' => $q['cond_ref'] ?? null,
			'condition_value'  => $q['cond_val'] ?? null,
			'condition_op'     => $q['cond_op'] ?? 'eq',
		] );
	}

	private static function insert_opts( int $question_id, array $opts ): void {
		foreach ( $opts as $i => $opt ) {
			WPQ_Database::insert_question_option( [
				'question_id'      => $question_id,
				'option_key'       => $opt['key'],
				'option_label'     => $opt['label'],
				'score'            => $opt['score'] ?? 0,
				'risk_level'       => $opt['risk'] ?? null,
				'finding_priority' => $opt['priority'] ?? null,
				'finding_action'   => $opt['action'] ?? null,
				'sort_order'       => $i,
				'is_default'       => $opt['default'] ?? 0,
				'is_active'        => 1,
				'requires_notes'   => $opt['notes'] ?? 0,
				'exclusive'        => $opt['exclusive'] ?? 0,
			] );
		}
	}

	/**
	 * Idempotent: for every radio/checkbox/select/combobox question whose scoring mode
	 * is single_option, sum_selected, or max_selected, and where ALL options currently
	 * have score = 0, assign sensible default scores:
	 *   - sum_selected  → each option gets score = 1 (each selection adds one point).
	 *   - single_option / max_selected → descending by sort_order: first = N-1, last = 0.
	 * Questions with at least one non-zero option score are left untouched.
	 */
	public static function backfill_option_scores(): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table-name prefix is not user input.
		$questions = $wpdb->get_results(
			"SELECT id, scoring_mode
			 FROM {$wpdb->prefix}wpq_questions
			 WHERE scoring_mode IN ('single_option','sum_selected','max_selected')"
		);

		if ( empty( $questions ) ) {
			return;
		}

		foreach ( $questions as $question ) {
			$q_id = (int) $question->id;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$options = $wpdb->get_results(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table-name prefix is not user input.
					"SELECT id, score
					 FROM {$wpdb->prefix}wpq_question_options
					 WHERE question_id = %d
					 ORDER BY sort_order ASC, id ASC",
					$q_id
				)
			);

			if ( empty( $options ) ) {
				continue;
			}

			// Only backfill when every option has score = 0.
			$all_zero = true;
			foreach ( $options as $opt ) {
				if ( (int) $opt->score !== 0 ) {
					$all_zero = false;
					break;
				}
			}

			if ( ! $all_zero ) {
				continue;
			}

			$n = count( $options );

			foreach ( $options as $i => $opt ) {
				$score = ( $question->scoring_mode === 'sum_selected' )
					? 1
					: max( 0, $n - 1 - $i );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update(
					"{$wpdb->prefix}wpq_question_options",
					[ 'score' => $score ],
					[ 'id'    => (int) $opt->id ],
					[ '%d' ],
					[ '%d' ]
				);
			}
		}
	}

	/**
	 * Idempotent: copy guidance_no → recommendation for every question that has
	 * guidance_no set but recommendation still empty.  Runs after install/upgrade
	 * so that existing tri_state/boolean questions gain report recommendations
	 * automatically without requiring manual re-entry.
	 */
	public static function backfill_recommendation(): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table-name prefix is not user input.
		$wpdb->query(
			"UPDATE {$wpdb->prefix}wpq_questions
			 SET recommendation = guidance_no
			 WHERE recommendation = '' AND guidance_no != ''"
		);
	}

	/**
	 * Idempotent: applies scoring modes and option scores to all library questionnaire
	 * questions using the 15-question template (Q04/Q09 boolean, Q05/Q06 sum_selected,
	 * Q07/Q08/Q13 single_option). Only updates questions still marked non_scoring.
	 */
	public static function backfill_library_scoring(): void {
		global $wpdb;
		$tq  = $wpdb->prefix . 'wpq_questions';
		$tqo = $wpdb->prefix . 'wpq_question_options';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table-name prefix is not user input; all values are internal constants.

		// Q04 (documented baseline), Q09 (exceptions recorded) — boolean, yes=2 no=0.
		$wpdb->query(
			"UPDATE {$tq}
			 SET scoring_mode = 'boolean', score_yes = 2, score_no = 0
			 WHERE question_ref IN ('Q04','Q09')
			   AND library_version IS NOT NULL
			   AND created_by_seed = 1
			   AND scoring_mode = 'non_scoring'"
		);

		// Q05 (control areas documented), Q06 (evidence available) — sum_selected, max 2.
		$wpdb->query(
			"UPDATE {$tq}
			 SET scoring_mode = 'sum_selected', max_score = 2
			 WHERE question_ref IN ('Q05','Q06')
			   AND library_version IS NOT NULL
			   AND created_by_seed = 1
			   AND scoring_mode = 'non_scoring'"
		);

		// Q07 (review frequency), Q08 (maturity), Q13 (budget) — single_option, max 2.
		$wpdb->query(
			"UPDATE {$tq}
			 SET scoring_mode = 'single_option', max_score = 2
			 WHERE question_ref IN ('Q07','Q08','Q13')
			   AND library_version IS NOT NULL
			   AND created_by_seed = 1
			   AND scoring_mode = 'non_scoring'"
		);

		// Q05 options: all score 1 except option_9 ("None of these") = 0.
		$wpdb->query(
			"UPDATE {$tqo} o
			 JOIN {$tq} q ON q.id = o.question_id
			 SET o.score = CASE WHEN o.option_key = 'option_9' THEN 0 ELSE 1 END
			 WHERE q.question_ref = 'Q05'
			   AND q.library_version IS NOT NULL
			   AND q.created_by_seed = 1"
		);

		// Q06 options: all score 1 except option_10 ("No evidence available") = 0.
		$wpdb->query(
			"UPDATE {$tqo} o
			 JOIN {$tq} q ON q.id = o.question_id
			 SET o.score = CASE WHEN o.option_key = 'option_10' THEN 0 ELSE 1 END
			 WHERE q.question_ref = 'Q06'
			   AND q.library_version IS NOT NULL
			   AND q.created_by_seed = 1"
		);

		// Q07 options: Never=0, Ad hoc=0, Monthly=2, Quarterly=2, Annually=1, Event-driven=2.
		$wpdb->query(
			"UPDATE {$tqo} o
			 JOIN {$tq} q ON q.id = o.question_id
			 SET o.score = CASE o.option_key
			     WHEN 'option_1' THEN 0
			     WHEN 'option_2' THEN 0
			     WHEN 'option_3' THEN 2
			     WHEN 'option_4' THEN 2
			     WHEN 'option_5' THEN 1
			     WHEN 'option_6' THEN 2
			     ELSE 0 END
			 WHERE q.question_ref = 'Q07'
			   AND q.library_version IS NOT NULL
			   AND q.created_by_seed = 1"
		);

		// Q08 options: Not started=0, Informal=0, Partially=1, Implemented=2, Managed=2.
		$wpdb->query(
			"UPDATE {$tqo} o
			 JOIN {$tq} q ON q.id = o.question_id
			 SET o.score = CASE o.option_key
			     WHEN 'option_1' THEN 0
			     WHEN 'option_2' THEN 0
			     WHEN 'option_3' THEN 1
			     WHEN 'option_4' THEN 2
			     WHEN 'option_5' THEN 2
			     ELSE 0 END
			 WHERE q.question_ref = 'Q08'
			   AND q.library_version IS NOT NULL
			   AND q.created_by_seed = 1"
		);

		// Q13 options: No budget=0, Under consideration=1, Budget allocated=2, In progress=2, Unknown=0.
		$wpdb->query(
			"UPDATE {$tqo} o
			 JOIN {$tq} q ON q.id = o.question_id
			 SET o.score = CASE o.option_key
			     WHEN 'option_1' THEN 0
			     WHEN 'option_2' THEN 1
			     WHEN 'option_3' THEN 2
			     WHEN 'option_4' THEN 2
			     WHEN 'option_5' THEN 0
			     ELSE 0 END
			 WHERE q.question_ref = 'Q13'
			   AND q.library_version IS NOT NULL
			   AND q.created_by_seed = 1"
		);

		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	// ------------------------------------------------------------------ //
	// CE 2026 DANZELL v16 — main seed method
	// ------------------------------------------------------------------ //

	private static function seed_cs01_cybercheck_2026(): bool {
		$q_id = WPQ_Database::insert_questionnaire( [
			'ref'                   => 'CS01',
			'category'              => 'cyber_security',
			'name'                  => 'CyberCheck - Security Assessment',
			'description'           => 'Cyber Essentials aligned self-assessment based on the DANZELL question set (effective 27 April 2026, Version 16). Complete to understand your organisation\'s compliance with the five Cyber Essentials technical controls.',
			'status'                => 'live',
			'source_name'           => 'Cyber Essentials Self Assessment Questionnaire',
			'source_question_set'   => 'DANZELL',
			'source_effective_date' => '2026-04-27',
			'source_version'        => '16',
			'source_file'           => 'AT-CE-2026-Self-Assessment-QuestionSet.xlsx',
		] );

		if ( ! $q_id ) return false;

		// ------------------------------------------------------------------ //
		// Domain 1 — Your Organisation
		// ------------------------------------------------------------------ //

		$d1 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 0,
			'slug'             => 'your_organisation',
			'name'             => 'Your Organisation',
			'icon'             => '',
		] );

		$q = self::insert_q( $d1, 0, [
			'ref'  => 'A1.1',
			'text' => 'What is the full legal name of your organisation?',
			'type' => 'short_text', 'mode' => 'non_scoring',
		] );

		$q = self::insert_q( $d1, 1, [
			'ref'  => 'A1.2',
			'text' => 'What type of organisation are you?',
			'type' => 'select', 'mode' => 'non_scoring',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'sole_trader',        'label' => 'Sole Trader' ],
			[ 'key' => 'partnership',        'label' => 'Partnership' ],
			[ 'key' => 'llp',                'label' => 'Limited Liability Partnership (LLP)' ],
			[ 'key' => 'limited_company',    'label' => 'Private Limited Company (Ltd)' ],
			[ 'key' => 'plc',                'label' => 'Public Limited Company (PLC)' ],
			[ 'key' => 'charity',            'label' => 'Registered Charity' ],
			[ 'key' => 'cio',                'label' => 'Charitable Incorporated Organisation (CIO)' ],
			[ 'key' => 'community_interest', 'label' => 'Community Interest Company (CIC)' ],
			[ 'key' => 'government',         'label' => 'Government / Public Sector Body' ],
			[ 'key' => 'education',          'label' => 'Educational Institution' ],
			[ 'key' => 'other',              'label' => 'Other' ],
		] );

		self::insert_q( $d1, 2, [
			'ref'      => 'A1.3',
			'text'     => 'What is your company or charity registration number?',
			'type'     => 'short_text', 'mode' => 'non_scoring', 'required' => 0,
			'guidance_no' => 'Leave blank if not applicable.',
		] );

		self::insert_q( $d1, 3, [
			'ref'      => 'A1.4',
			'text'     => 'What is your organisation\'s trading name, if different from the legal name?',
			'type'     => 'short_text', 'mode' => 'non_scoring', 'required' => 0,
		] );

		$q = self::insert_q( $d1, 4, [
			'ref'  => 'A1.5',
			'text' => 'How many employees does your organisation have?',
			'type' => 'select', 'mode' => 'non_scoring',
		] );
		self::insert_opts( $q, [
			[ 'key' => '1',         'label' => 'Just me (1 employee)' ],
			[ 'key' => '2_9',       'label' => '2 to 9' ],
			[ 'key' => '10_49',     'label' => '10 to 49' ],
			[ 'key' => '50_249',    'label' => '50 to 249' ],
			[ 'key' => '250_999',   'label' => '250 to 999' ],
			[ 'key' => '1000_4999', 'label' => '1,000 to 4,999' ],
			[ 'key' => '5000_plus', 'label' => '5,000 or more' ],
		] );

		self::insert_q( $d1, 5, [
			'ref'          => 'A1.6',
			'text'         => 'Does your organisation use cloud services?',
			'type'         => 'boolean', 'mode' => 'non_scoring',
			'guidance_yes' => 'Cloud services include hosted email, cloud storage, SaaS applications, IaaS, and PaaS platforms.',
			'guidance_no'  => '',
		] );

		self::insert_q( $d1, 6, [
			'ref'      => 'A1.6.1',
			'text'     => 'Which cloud services does your organisation use?',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A1.6', 'cond_val' => 'yes', 'cond_op' => 'eq',
			'help'     => 'List the cloud service providers and applications used, e.g. Microsoft 365, Google Workspace, AWS, Azure.',
		] );

		$q = self::insert_q( $d1, 7, [
			'ref'  => 'A1.7',
			'text' => 'What is your main business?',
			'type' => 'select', 'mode' => 'non_scoring',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'accommodation',           'label' => 'Accommodation and food service activities' ],
			[ 'key' => 'admin_support',            'label' => 'Administrative and support service activities' ],
			[ 'key' => 'agriculture',              'label' => 'Agriculture, forestry and fishing' ],
			[ 'key' => 'arts',                     'label' => 'Arts, entertainment and recreation' ],
			[ 'key' => 'banking',                  'label' => 'Banking and financial services' ],
			[ 'key' => 'charity',                  'label' => 'Charities and voluntary sector' ],
			[ 'key' => 'chemical',                 'label' => 'Chemical and pharmaceutical manufacturing' ],
			[ 'key' => 'civil_eng',                'label' => 'Civil engineering and construction' ],
			[ 'key' => 'computing',                'label' => 'Computing and software development' ],
			[ 'key' => 'creative',                 'label' => 'Creative and digital media' ],
			[ 'key' => 'defence',                  'label' => 'Defence and military (private sector)' ],
			[ 'key' => 'education_fe_he',          'label' => 'Education — further and higher education' ],
			[ 'key' => 'education_school',         'label' => 'Education — primary and secondary schools' ],
			[ 'key' => 'electricity',              'label' => 'Electricity generation and distribution' ],
			[ 'key' => 'emergency',                'label' => 'Emergency services' ],
			[ 'key' => 'engineering',              'label' => 'Engineering consultancy and services' ],
			[ 'key' => 'environment',              'label' => 'Environmental and waste management' ],
			[ 'key' => 'finance_insurance',        'label' => 'Finance and insurance (general)' ],
			[ 'key' => 'food_drink',               'label' => 'Food and drink manufacturing' ],
			[ 'key' => 'gas',                      'label' => 'Gas distribution and services' ],
			[ 'key' => 'government_central',       'label' => 'Government and public administration — central' ],
			[ 'key' => 'government_local',         'label' => 'Government and public administration — local' ],
			[ 'key' => 'healthcare_nhs',           'label' => 'Healthcare — NHS' ],
			[ 'key' => 'healthcare_private',       'label' => 'Healthcare — private' ],
			[ 'key' => 'housing',                  'label' => 'Housing and property management' ],
			[ 'key' => 'hr_recruitment',           'label' => 'Human resources and recruitment' ],
			[ 'key' => 'info_comms',               'label' => 'Information and communications' ],
			[ 'key' => 'insurance',                'label' => 'Insurance' ],
			[ 'key' => 'it_services',              'label' => 'IT services and managed services' ],
			[ 'key' => 'legal',                    'label' => 'Legal services' ],
			[ 'key' => 'logistics',                'label' => 'Logistics and supply chain' ],
			[ 'key' => 'manufacturing_general',    'label' => 'Manufacturing — general' ],
			[ 'key' => 'manufacturing_auto',       'label' => 'Manufacturing — automotive' ],
			[ 'key' => 'manufacturing_electronic', 'label' => 'Manufacturing — electronics' ],
			[ 'key' => 'manufacturing_industrial', 'label' => 'Manufacturing — industrial machinery' ],
			[ 'key' => 'media',                    'label' => 'Media and publishing' ],
			[ 'key' => 'mining',                   'label' => 'Mining and quarrying' ],
			[ 'key' => 'motor_trade',              'label' => 'Motor trade' ],
			[ 'key' => 'pharmaceutical',           'label' => 'Pharmaceutical and biotech' ],
			[ 'key' => 'professional',             'label' => 'Professional services' ],
			[ 'key' => 'property',                 'label' => 'Property and real estate' ],
			[ 'key' => 'public_health',            'label' => 'Public health' ],
			[ 'key' => 'rail_transport',           'label' => 'Rail and public transport' ],
			[ 'key' => 'research',                 'label' => 'Research and development' ],
			[ 'key' => 'retail_general',           'label' => 'Retail — general' ],
			[ 'key' => 'retail_online',            'label' => 'Retail — online' ],
			[ 'key' => 'science_tech',             'label' => 'Science and technology' ],
			[ 'key' => 'security_services',        'label' => 'Security services (physical and cyber)' ],
			[ 'key' => 'social_care',              'label' => 'Social care' ],
			[ 'key' => 'telecommunications',       'label' => 'Telecommunications' ],
			[ 'key' => 'transport_aviation',       'label' => 'Transport and aviation' ],
			[ 'key' => 'utilities_water',          'label' => 'Utilities — water' ],
			[ 'key' => 'wholesale',                'label' => 'Wholesale and distribution' ],
			[ 'key' => 'other',                    'label' => 'Other (please specify)' ],
		] );

		self::insert_q( $d1, 8, [
			'ref'  => 'A1.8',
			'text' => 'What is the full name of the primary contact for this application?',
			'type' => 'short_text', 'mode' => 'non_scoring',
		] );

		$q = self::insert_q( $d1, 9, [
			'ref'  => 'A1.9',
			'text' => 'What is the primary contact\'s role?',
			'type' => 'select', 'mode' => 'non_scoring',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'director_senior_manager', 'label' => 'Director, Owner or Senior Manager' ],
			[ 'key' => 'it_security_professional', 'label' => 'IT or Security Professional' ],
		] );

		$q = self::insert_q( $d1, 10, [
			'ref'     => 'A1.10',
			'text'    => 'What are the two main reasons for applying for Cyber Essentials certification?',
			'type'    => 'checkbox', 'mode' => 'non_scoring',
			'max_sel' => 2,
			'help'    => 'Select up to two reasons.',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'customer_requirement', 'label' => 'Customer or client requirement' ],
			[ 'key' => 'insurance_requirement', 'label' => 'Insurance requirement' ],
			[ 'key' => 'supply_chain',          'label' => 'Supply chain or tender requirement' ],
			[ 'key' => 'public_sector',         'label' => 'Public sector procurement requirement' ],
			[ 'key' => 'business_dev',          'label' => 'Business development or marketing' ],
			[ 'key' => 'board_commitment',      'label' => 'Board or management commitment' ],
			[ 'key' => 'regulatory',            'label' => 'Regulatory or legal requirement' ],
			[ 'key' => 'good_practice',         'label' => 'General good practice' ],
		] );

		self::insert_q( $d1, 11, [
			'ref'  => 'A1.11',
			'text' => 'What is the primary contact\'s email address?',
			'type' => 'short_text', 'mode' => 'non_scoring',
		] );

		$q = self::insert_q( $d1, 12, [
			'ref'  => 'A1.13',
			'text' => 'How many devices are included in the scope of this assessment?',
			'type' => 'select', 'mode' => 'non_scoring',
			'help' => 'Include desktops, laptops, servers, mobile phones, tablets, and other internet-connected devices managed by your organisation.',
		] );
		self::insert_opts( $q, [
			[ 'key' => '1_9',      'label' => '1 to 9 devices' ],
			[ 'key' => '10_49',    'label' => '10 to 49 devices' ],
			[ 'key' => '50_99',    'label' => '50 to 99 devices' ],
			[ 'key' => '100_499',  'label' => '100 to 499 devices' ],
			[ 'key' => '500_999',  'label' => '500 to 999 devices' ],
			[ 'key' => '1000_plus','label' => '1,000 or more devices' ],
		] );

		$q = self::insert_q( $d1, 13, [
			'ref'      => 'A1.14',
			'text'     => 'Where did you hear about Cyber Essentials?',
			'type'     => 'select', 'mode' => 'non_scoring', 'required' => 0,
		] );
		self::insert_opts( $q, [
			[ 'key' => 'internet_search', 'label' => 'Internet search engine' ],
			[ 'key' => 'social_media',    'label' => 'Social media' ],
			[ 'key' => 'ncsc',            'label' => 'NCSC website or guidance' ],
			[ 'key' => 'gov_website',     'label' => 'Government or DSIT website' ],
			[ 'key' => 'colleague',       'label' => 'Colleague or peer' ],
			[ 'key' => 'industry_body',   'label' => 'Industry body or trade association' ],
			[ 'key' => 'insurance',       'label' => 'Insurance provider' ],
			[ 'key' => 'it_provider',     'label' => 'IT support provider or MSP' ],
			[ 'key' => 'partner',         'label' => 'Partner or reseller' ],
			[ 'key' => 'event',           'label' => 'Event or conference' ],
			[ 'key' => 'other',           'label' => 'Other' ],
		] );

		// ------------------------------------------------------------------ //
		// Domain 2 — Certificates
		// ------------------------------------------------------------------ //

		$d2 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 1,
			'slug'             => 'certificates',
			'name'             => 'Certificates',
			'icon'             => '',
		] );

		$q = self::insert_q( $d2, 0, [
			'ref'  => 'A2.1',
			'text' => 'Does your organisation currently hold a valid Cyber Essentials certificate?',
			'type' => 'radio', 'mode' => 'non_scoring',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'yes', 'label' => 'Yes' ],
			[ 'key' => 'no',  'label' => 'No' ],
		] );

		self::insert_q( $d2, 1, [
			'ref'      => 'A2.2',
			'text'     => 'What is your current certificate reference number?',
			'type'     => 'short_text', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A2.1', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		self::insert_q( $d2, 2, [
			'ref'      => 'A2.2.1',
			'text'     => 'What date was your current certificate awarded?',
			'type'     => 'short_text', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A2.1', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		self::insert_q( $d2, 3, [
			'ref'      => 'A2.2.2',
			'text'     => 'What is the scope of your current certificate?',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A2.1', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		self::insert_q( $d2, 4, [
			'ref'      => 'A2.3.1',
			'text'     => 'Is your current certificate still within its valid period?',
			'type'     => 'boolean', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A2.1', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		self::insert_q( $d2, 5, [
			'ref'      => 'A2.3.2',
			'text'     => 'Why is your Cyber Essentials certificate no longer valid?',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A2.3.1', 'cond_val' => 'no', 'cond_op' => 'eq',
		] );

		// ------------------------------------------------------------------ //
		// Domain 3 — Application
		// ------------------------------------------------------------------ //

		$d3 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 2,
			'slug'             => 'application',
			'name'             => 'Application',
			'icon'             => '',
		] );

		$q = self::insert_q( $d3, 0, [
			'ref'  => 'A3.1',
			'text' => 'What are you applying for?',
			'type' => 'radio', 'mode' => 'non_scoring',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'ce',      'label' => 'Cyber Essentials' ],
			[ 'key' => 'ce_plus', 'label' => 'Cyber Essentials Plus' ],
		] );

		$q = self::insert_q( $d3, 1, [
			'ref'  => 'A3.2',
			'text' => 'Does this application cover your entire organisation or a defined subset?',
			'type' => 'radio', 'mode' => 'non_scoring',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'entire', 'label' => 'Entire organisation' ],
			[ 'key' => 'subset', 'label' => 'A defined subset of the organisation' ],
		] );

		self::insert_q( $d3, 2, [
			'ref'      => 'A3.3',
			'text'     => 'Please describe the subset scope for this assessment.',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A3.2', 'cond_val' => 'subset', 'cond_op' => 'eq',
			'help'     => 'Describe the systems, services, locations, or business units included in scope.',
		] );

		// ------------------------------------------------------------------ //
		// Domain 4 — Scope of Assessment
		// ------------------------------------------------------------------ //

		$d4 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 3,
			'slug'             => 'scope_of_assessment',
			'name'             => 'Scope of Assessment',
			'icon'             => '',
		] );

		self::insert_q( $d4, 0, [
			'ref'          => 'A4.1.1',
			'text'         => 'Is automatic updating enabled for all operating systems and firmware within the scope?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Automatic updates ensure patches are applied promptly without manual intervention.',
			'guidance_no'  => 'Enable automatic updates for all operating systems and firmware in scope to reduce exposure from known vulnerabilities.',
		] );

		self::insert_q( $d4, 1, [
			'ref'          => 'A4.1.2',
			'text'         => 'How do you ensure operating systems and firmware are kept up to date?',
			'type'         => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref'     => 'A4.1.1', 'cond_val' => 'no', 'cond_op' => 'eq',
			'help'         => 'Describe your manual or managed update process.',
		] );

		self::insert_q( $d4, 2, [
			'ref'          => 'A4.2',
			'text'         => 'Are all devices in scope running supported versions of their operating systems?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Using supported OS versions ensures you receive security updates from the vendor.',
			'guidance_no'  => 'Replace or upgrade all devices running end-of-life or unsupported operating systems. Unsupported systems do not receive security patches and present a significant risk.',
		] );

		$q = self::insert_q( $d4, 3, [
			'ref'          => 'A4.3',
			'text'         => 'What authentication method is used to protect administrator accounts on devices and systems in scope?',
			'type'         => 'radio', 'mode' => 'single_option',
			'max_score'    => 2,
			'guidance_yes' => 'Your authentication method meets Cyber Essentials requirements.',
			'guidance_no'  => 'Administrator accounts must be protected using an approved authentication method. Select the method in use and ensure it meets the Cyber Essentials requirements.',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'a', 'label' => 'Multi-factor authentication, with a minimum password length 8 characters and no maximum length',                                                         'score' => 2 ],
			[ 'key' => 'b', 'label' => 'Automatic blocking of common passwords, with a minimum password length 8 characters and no maximum length',                                             'score' => 2 ],
			[ 'key' => 'c', 'label' => 'A password minimum length of 12 characters and no maximum length',                                                                                     'score' => 2 ],
			[ 'key' => 'd', 'label' => 'Passwordless system is being used as an alternative to user name and password, please describe',                                                        'score' => 2, 'notes' => 1 ],
			[ 'key' => 'e', 'label' => 'None of the above, please describe',                                                                                                                   'score' => 0, 'notes' => 1, 'priority' => 'critical', 'action' => 'Implement an approved authentication method for all administrator accounts. At minimum, enforce a password length of 12 characters or use MFA.' ],
		] );

		self::insert_q( $d4, 4, [
			'ref'          => 'A4.4',
			'text'         => 'Are administrator accounts used only for administrative tasks and not for general day-to-day work?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Limiting admin accounts to administrative tasks reduces the risk of credential compromise during normal use.',
			'guidance_no'  => 'Create separate standard user accounts for day-to-day activity. Administrator credentials should only be used when administrative access is required.',
		] );

		self::insert_q( $d4, 5, [
			'ref'          => 'A4.5',
			'text'         => 'Does remote access to in-scope systems require multi-factor authentication?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'MFA for remote access significantly reduces the risk of unauthorised access via stolen credentials.',
			'guidance_no'  => 'Enable multi-factor authentication for all remote access to in-scope systems. This is a requirement for Cyber Essentials.',
		] );

		self::insert_q( $d4, 6, [
			'ref'      => 'A4.7',
			'text'     => 'Please list the IP address ranges included within the scope of this assessment.',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'help'     => 'Include both internal IP ranges and any external/public IP addresses associated with systems in scope.',
		] );

		self::insert_q( $d4, 7, [
			'ref'          => 'A4.8',
			'text'         => 'Does the scope include any web-facing services accessible from the internet?',
			'type'         => 'boolean', 'mode' => 'non_scoring',
		] );

		self::insert_q( $d4, 8, [
			'ref'          => 'A4.9',
			'text'         => 'Do any devices in scope act as internet-facing servers?',
			'type'         => 'boolean', 'mode' => 'non_scoring',
		] );

		self::insert_q( $d4, 9, [
			'ref'      => 'A4.10',
			'text'     => 'What services do the internet-facing servers provide?',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A4.9', 'cond_val' => 'yes', 'cond_op' => 'eq',
			'help'     => 'For example: web hosting, email, VPN, remote desktop, FTP.',
		] );

		self::insert_q( $d4, 10, [
			'ref'      => 'A4.11',
			'text'     => 'Which ports and protocols are exposed on the internet-facing servers?',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A4.9', 'cond_val' => 'yes', 'cond_op' => 'eq',
			'help'     => 'For example: TCP 443 (HTTPS), TCP 80 (HTTP), UDP 1194 (OpenVPN).',
		] );

		// ------------------------------------------------------------------ //
		// Domain 5 — Insurance
		// ------------------------------------------------------------------ //

		$d5 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 4,
			'slug'             => 'insurance',
			'name'             => 'Insurance',
			'icon'             => '',
		] );

		self::insert_q( $d5, 0, [
			'ref'  => 'A5.1',
			'text' => 'Does your organisation hold cyber liability insurance?',
			'type' => 'boolean', 'mode' => 'non_scoring',
		] );

		self::insert_q( $d5, 1, [
			'ref'      => 'A5.2',
			'text'     => 'Who is your cyber insurance provider?',
			'type'     => 'short_text', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A5.1', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		self::insert_q( $d5, 2, [
			'ref'      => 'A5.3',
			'text'     => 'When does your cyber insurance policy expire?',
			'type'     => 'short_text', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A5.1', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		self::insert_q( $d5, 3, [
			'ref'          => 'A5.4',
			'text'         => 'Does your insurer require specific authentication controls for access to administration interfaces?',
			'type'         => 'boolean', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref'     => 'A5.1', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		$q = self::insert_q( $d5, 4, [
			'ref'          => 'A5.5',
			'text'         => 'What authentication method does your policy require for access to administration interfaces?',
			'type'         => 'radio', 'mode' => 'single_option',
			'max_score'    => 2,
			'cond_ref'     => 'A5.4', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'a', 'label' => 'Multi-factor authentication, with a minimum password length of 8 characters and no maximum length',                                                      'score' => 2 ],
			[ 'key' => 'b', 'label' => 'Automatic blocking of common passwords, with a minimum password length of 8 characters and no maximum length',                                          'score' => 2 ],
			[ 'key' => 'c', 'label' => 'A minimum password length of 12 characters and no maximum length',                                                                                     'score' => 2 ],
			[ 'key' => 'd', 'label' => 'Passwordless, please describe',                                                                                                                        'score' => 2, 'notes' => 1 ],
			[ 'key' => 'e', 'label' => 'None of the above, please describe',                                                                                                                   'score' => 0, 'notes' => 1, 'priority' => 'critical', 'action' => 'Implement an authentication method that meets your insurer\'s requirements for administration access.' ],
		] );

		self::insert_q( $d5, 5, [
			'ref'      => 'A5.6',
			'text'     => 'Please confirm the authentication requirement is met and describe how.',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A5.4', 'cond_val' => 'yes', 'cond_op' => 'eq',
		] );

		$q = self::insert_q( $d5, 6, [
			'ref'          => 'A5.7',
			'text'         => 'What protection is in place against brute force attacks on administration interfaces?',
			'type'         => 'radio', 'mode' => 'single_option',
			'max_score'    => 2,
			'guidance_yes' => 'Brute force protection is in place for administration interfaces.',
			'guidance_no'  => 'Implement throttling or account lockout to protect against brute force attacks on all administration interfaces.',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'a', 'label' => 'Throttling the rate of attempts',                                  'score' => 2 ],
			[ 'key' => 'b', 'label' => 'Locking accounts after no more than 10 unsuccessful attempts',     'score' => 2 ],
			[ 'key' => 'c', 'label' => 'None of the above, please describe',                               'score' => 0, 'notes' => 1, 'exclusive' => 1, 'priority' => 'critical', 'action' => 'Implement throttling or account lockout to protect administration interfaces against brute force attacks.' ],
		] );

		// ------------------------------------------------------------------ //
		// Domain 6 — Firewalls
		// ------------------------------------------------------------------ //

		$d6 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 5,
			'slug'             => 'firewalls',
			'name'             => 'Firewalls',
			'icon'             => '',
		] );

		self::insert_q( $d6, 0, [
			'ref'          => 'A6.1',
			'text'         => 'Do you use a firewall or equivalent network device to protect every network boundary and internet connection?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'A boundary firewall is in place to protect your network.',
			'guidance_no'  => 'Install and configure a firewall on every connection between your network and the internet. All traffic must pass through the firewall.',
		] );

		self::insert_q( $d6, 1, [
			'ref'          => 'A6.2',
			'text'         => 'Is the firewall configured to block inbound connections by default, with only approved services permitted?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Your firewall enforces a default-deny policy for inbound traffic.',
			'guidance_no'  => 'Configure the firewall with a default-deny rule for all inbound connections. Only create rules for services that are explicitly required and approved.',
		] );

		self::insert_q( $d6, 2, [
			'ref'          => 'A6.3',
			'text'         => 'Are firewall rules documented, reviewed, and approved by an authorised person?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Firewall rules are maintained with appropriate governance.',
			'guidance_no'  => 'Document all firewall rules and establish a review process. Rules should be authorised by a named individual and reviewed at least annually.',
		] );

		self::insert_q( $d6, 3, [
			'ref'          => 'A6.4',
			'text'         => 'Has the default administrative password on the firewall been changed to a strong unique password?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Default credentials have been replaced with a strong unique password.',
			'guidance_no'  => 'Change the default administrative password on the firewall immediately. Use a strong, unique password that is stored securely.',
		] );

		self::insert_q( $d6, 4, [
			'ref'          => 'A6.5',
			'text'         => 'Is the firewall management interface restricted so it is not accessible from the internet?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'The firewall management interface is only accessible from trusted internal networks.',
			'guidance_no'  => 'Restrict the firewall management interface to a trusted internal network or management VLAN. It must not be accessible directly from the internet.',
		] );

		self::insert_q( $d6, 5, [
			'ref'          => 'A6.6',
			'text'         => 'Are unused open ports and services on the firewall disabled or blocked?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Unused ports and services are disabled, reducing the attack surface.',
			'guidance_no'  => 'Audit all firewall rules and disable any ports or services that are not actively required. Each open port represents a potential entry point.',
		] );

		self::insert_q( $d6, 6, [
			'ref'          => 'A6.7',
			'text'         => 'Is there a process to review and update firewall rules when network changes occur?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'A change management process ensures firewall rules remain accurate and current.',
			'guidance_no'  => 'Establish a change management process for firewall rules. Any network change should trigger a review to ensure the rules remain appropriate.',
		] );

		// ------------------------------------------------------------------ //
		// Domain 7 — Secure Configuration
		// ------------------------------------------------------------------ //

		$d7 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 6,
			'slug'             => 'secure_configuration',
			'name'             => 'Secure Configuration',
			'icon'             => '',
		] );

		self::insert_q( $d7, 0, [
			'ref'          => 'A7.1',
			'text'         => 'Have all default passwords on devices and software been changed before deployment?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Default passwords are changed as part of your deployment process.',
			'guidance_no'  => 'Change all default passwords on every device and software application before putting them into use. Default credentials are publicly known and trivially exploited.',
		] );

		self::insert_q( $d7, 1, [
			'ref'          => 'A7.2',
			'text'         => 'Is unnecessary software, services, and functionality removed or disabled from in-scope devices?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Unnecessary software and services are removed, reducing the attack surface.',
			'guidance_no'  => 'Audit all devices and remove or disable software, services, and features that are not required. Each unnecessary component is a potential vulnerability.',
		] );

		self::insert_q( $d7, 2, [
			'ref'          => 'A7.3',
			'text'         => 'Is the auto-run feature disabled for removable media such as USB drives on all in-scope devices?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Auto-run is disabled, preventing malware on removable media from executing automatically.',
			'guidance_no'  => 'Disable auto-run for removable media via Group Policy (Windows) or equivalent settings on all in-scope devices.',
		] );

		self::insert_q( $d7, 3, [
			'ref'          => 'A7.4',
			'text'         => 'Is a host-based firewall or equivalent enabled on all in-scope end-user devices?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'A host-based firewall is active on end-user devices, providing an additional layer of protection.',
			'guidance_no'  => 'Enable the built-in firewall (Windows Defender Firewall, macOS application firewall) on all end-user devices. This protects devices when they are used outside the corporate network.',
		] );

		self::insert_q( $d7, 4, [
			'ref'          => 'A7.5',
			'text'         => 'Are screen locks with automatic timeout configured on all in-scope devices?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Screen locks are configured to protect unattended devices.',
			'guidance_no'  => 'Configure automatic screen lock with a short inactivity timeout (5 to 10 minutes) on all devices. This prevents unauthorised access when devices are left unattended.',
		] );

		self::insert_q( $d7, 5, [
			'ref'          => 'A7.6',
			'text'         => 'Are standard user and administrator accounts kept separate, with staff using standard accounts for normal work?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'User and admin accounts are separated, reducing the impact of compromised credentials.',
			'guidance_no'  => 'Create separate standard user accounts for day-to-day activities. Administrative accounts should only be used when explicitly required for administrative tasks.',
		] );

		self::insert_q( $d7, 6, [
			'ref'          => 'A7.7',
			'text'         => 'Are account privileges for all user accounts limited to the minimum required for their role?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'The principle of least privilege is applied, limiting the damage from any single compromised account.',
			'guidance_no'  => 'Review all user account privileges and reduce them to the minimum required. Remove any access rights that are not actively needed.',
		] );

		self::insert_q( $d7, 7, [
			'ref'          => 'A7.8',
			'text'         => 'Are cloud services and cloud-hosted applications configured with security hardening applied?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Cloud services have been configured securely, following vendor hardening guidance.',
			'guidance_no'  => 'Review the configuration of all cloud services against the vendor\'s security hardening guidance. Disable unnecessary features, restrict access, and apply recommended settings.',
		] );

		self::insert_q( $d7, 8, [
			'ref'          => 'A7.9',
			'text'         => 'Is there a standard secure baseline configuration used for new devices before they are deployed?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'A standard hardened baseline ensures all devices meet the same security standard.',
			'guidance_no'  => 'Define and document a standard baseline configuration for each device type. Apply this before deployment and use it to detect configuration drift.',
		] );

		self::insert_q( $d7, 9, [
			'ref'          => 'A7.10',
			'text'         => 'Are configuration changes controlled, documented, and authorised before being applied?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Configuration changes are managed through an authorised change process.',
			'guidance_no'  => 'Implement a change management process for configuration changes. All changes should be documented, tested, and authorised before deployment.',
		] );

		self::insert_q( $d7, 10, [
			'ref'          => 'A7.11',
			'text'         => 'Is multi-factor authentication required for all accounts that access cloud services?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'MFA is enforced for cloud service access, protecting against credential-based attacks.',
			'guidance_no'  => 'Enable and enforce multi-factor authentication for all accounts that access cloud services. This is a specific requirement of Cyber Essentials.',
		] );

		self::insert_q( $d7, 11, [
			'ref'          => 'A7.14',
			'text'         => 'Is multi-factor authentication enabled on all accounts that have access to sensitive or privileged data?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'MFA is applied to protect access to sensitive and privileged accounts.',
			'guidance_no'  => 'Enable multi-factor authentication for all accounts with access to sensitive or privileged data. Prioritise administrator, finance, and executive accounts.',
		] );

		self::insert_q( $d7, 12, [
			'ref'      => 'A7.15',
			'text'     => 'Please explain why multi-factor authentication is not in use and what compensating controls are in place.',
			'type'     => 'memo', 'mode' => 'non_scoring', 'required' => 0,
			'cond_ref' => 'A7.14', 'cond_val' => 'no', 'cond_op' => 'eq',
		] );

		// ------------------------------------------------------------------ //
		// Domain 8 — Security Update Management
		// ------------------------------------------------------------------ //

		$d8 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 7,
			'slug'             => 'security_update_management',
			'name'             => 'Security Update Management',
			'icon'             => '',
		] );

		self::insert_q( $d8, 0, [
			'ref'          => 'A8.6',
			'text'         => 'Are all software applications and operating systems in scope kept up to date with security patches?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Software is kept up to date, reducing exposure to known vulnerabilities.',
			'guidance_no'  => 'Establish a process to apply security updates for all software within 14 days of release. Enable automatic updates where possible.',
		] );

		self::insert_q( $d8, 1, [
			'ref'          => 'A8.7',
			'text'         => 'Are high or critical severity security updates applied within 14 days of release?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Critical patches are applied within the 14-day window required by Cyber Essentials.',
			'guidance_no'  => 'You must apply high and critical severity patches within 14 days of release. Consider enabling automatic updates or establishing a regular patching cycle.',
		] );

		self::insert_q( $d8, 2, [
			'ref'          => 'A8.8',
			'text'         => 'Is all software within scope licensed and actively supported by the vendor?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'All software is licensed and supported, ensuring security updates are available.',
			'guidance_no'  => 'Replace or upgrade any end-of-life software that no longer receives security updates. Unsupported software cannot be patched and must be removed from scope.',
		] );

		self::insert_q( $d8, 3, [
			'ref'          => 'A8.9',
			'text'         => 'Is there a documented process for monitoring vendor security advisories and applying updates?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'You have a process to track and act on vendor security advisories.',
			'guidance_no'  => 'Subscribe to security advisories from your key software vendors and establish a documented process for reviewing and acting on them.',
		] );

		self::insert_q( $d8, 4, [
			'ref'          => 'A8.10',
			'text'         => 'Are mobile devices and tablets in scope kept up to date with the latest operating system and app updates?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Mobile devices are kept up to date as part of your patch management process.',
			'guidance_no'  => 'Include mobile devices in your update management process. Enable automatic updates on iOS and Android devices and regularly verify that devices are running current versions.',
		] );

		// ------------------------------------------------------------------ //
		// Domain 9 — User Access Control
		// ------------------------------------------------------------------ //

		$d9 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 8,
			'slug'             => 'user_access_control',
			'name'             => 'User Access Control',
			'icon'             => '',
		] );

		self::insert_q( $d9, 0, [
			'ref'          => 'A9.1',
			'text'         => 'Are user accounts only created for named, authorised individuals?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'User accounts are tied to named individuals, making accountability clear.',
			'guidance_no'  => 'Ensure every active account is associated with a named, authorised individual. Remove shared or generic accounts.',
		] );

		self::insert_q( $d9, 1, [
			'ref'          => 'A9.2',
			'text'         => 'Are user accounts and access rights reviewed regularly and removed when no longer needed?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Access rights are reviewed regularly, reducing the risk from dormant or over-privileged accounts.',
			'guidance_no'  => 'Conduct a periodic review of all user accounts. Disable or delete accounts for former employees and contractors immediately on departure.',
		] );

		self::insert_q( $d9, 2, [
			'ref'          => 'A9.3',
			'text'         => 'Is there a formal process for granting, changing, and revoking access rights?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'A formal access management process is in place.',
			'guidance_no'  => 'Implement a formal process for requesting, approving, and revoking access rights. Document all access grants and changes.',
		] );

		self::insert_q( $d9, 3, [
			'ref'          => 'A9.4',
			'text'         => 'Is a password policy enforced across all user accounts?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'A password policy is enforced, helping to ensure accounts use strong credentials.',
			'guidance_no'  => 'Implement and enforce a password policy requiring minimum length, complexity, and change-on-compromise. Use a password manager or MFA to support compliance.',
		] );

		self::insert_q( $d9, 4, [
			'ref'          => 'A9.5',
			'text'         => 'Is multi-factor authentication used for all remote access to in-scope systems and services?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'MFA is required for remote access, significantly reducing the risk of unauthorised access.',
			'guidance_no'  => 'Enable multi-factor authentication for all remote access, including VPN, remote desktop, and cloud portals. This is a specific Cyber Essentials requirement.',
		] );

		self::insert_q( $d9, 5, [
			'ref'          => 'A9.6',
			'text'         => 'Are privileged and administrative accounts subject to additional access controls beyond standard user accounts?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Privileged accounts have enhanced controls, limiting the damage from a compromised admin credential.',
			'guidance_no'  => 'Apply additional controls to privileged accounts such as MFA, dedicated admin workstations, and session logging.',
		] );

		self::insert_q( $d9, 6, [
			'ref'          => 'A9.7',
			'text'         => 'Are there controls to prevent users from installing unauthorised software on in-scope devices?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'Controls prevent unauthorised software installation, reducing the risk of malware and shadow IT.',
			'guidance_no'  => 'Restrict software installation to authorised users or an approved application catalogue. Remove local administrator rights from standard user accounts.',
		] );

		self::insert_q( $d9, 7, [
			'ref'          => 'A9.8',
			'text'         => 'Is there a documented leaver process that includes prompt removal of all access rights?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'guidance_yes' => 'A leaver process ensures access is revoked promptly when staff leave.',
			'guidance_no'  => 'Create and follow a leaver checklist that includes disabling or deleting all accounts on the last working day. Former employee accounts are a common breach vector.',
		] );

		// ------------------------------------------------------------------ //
		// Domain 10 — Malware Protection
		// ------------------------------------------------------------------ //

		$d10 = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 9,
			'slug'             => 'malware_protection',
			'name'             => 'Malware Protection',
			'icon'             => '',
		] );

		$q = self::insert_q( $d10, 0, [
			'ref'          => 'A8.1',
			'text'         => 'Which of the following malware protection methods does your organisation use on in-scope devices?',
			'type'         => 'checkbox', 'mode' => 'sum_selected',
			'max_score'    => 2,
			'guidance_yes' => 'At least one approved malware protection method is in use.',
			'guidance_no'  => 'You must implement at least one approved malware protection method. Anti-malware software or application allow listing are the accepted approaches.',
		] );
		self::insert_opts( $q, [
			[ 'key' => 'a', 'label' => 'Having anti-malware software installed',                                                                                                                              'score' => 2 ],
			[ 'key' => 'b', 'label' => 'Limiting installation of applications by application allow listing, for example using an app store and a list of approved applications, or using a Mobile Device Management solution', 'score' => 2 ],
			[ 'key' => 'c', 'label' => 'None of the above, please describe',                                                                                                                                 'score' => 0, 'exclusive' => 1, 'notes' => 1, 'priority' => 'critical', 'action' => 'Implement anti-malware software or application allow listing on all in-scope devices. This is a mandatory Cyber Essentials control.' ],
		] );

		self::insert_q( $d10, 1, [
			'ref'          => 'A8.2',
			'text'         => 'Is anti-malware software configured to scan automatically in real time or on access?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'cond_ref'     => 'A8.1', 'cond_val' => 'a', 'cond_op' => 'contains',
			'guidance_yes' => 'Anti-malware is configured for real-time or on-access scanning.',
			'guidance_no'  => 'Configure your anti-malware software to scan files automatically when they are accessed or downloaded. Scheduled-only scanning leaves devices exposed between scans.',
		] );

		self::insert_q( $d10, 2, [
			'ref'          => 'A8.3',
			'text'         => 'Is anti-malware software kept up to date with the latest malware signatures automatically?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'cond_ref'     => 'A8.1', 'cond_val' => 'a', 'cond_op' => 'contains',
			'guidance_yes' => 'Anti-malware signatures are updated automatically, ensuring protection against the latest threats.',
			'guidance_no'  => 'Enable automatic signature updates for your anti-malware software. Out-of-date signatures significantly reduce detection effectiveness.',
		] );

		self::insert_q( $d10, 3, [
			'ref'          => 'A8.4',
			'text'         => 'Is the application allow list reviewed and updated regularly to ensure only approved applications are permitted?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'cond_ref'     => 'A8.1', 'cond_val' => 'b', 'cond_op' => 'contains',
			'guidance_yes' => 'The allow list is reviewed regularly, maintaining an accurate inventory of approved applications.',
			'guidance_no'  => 'Schedule regular reviews of your application allow list to remove applications that are no longer used or authorised.',
		] );

		self::insert_q( $d10, 4, [
			'ref'          => 'A8.5',
			'text'         => 'Does the application allow listing policy cover mobile devices as well as desktop and laptop computers?',
			'type'         => 'boolean', 'mode' => 'boolean',
			'score_yes'    => 2, 'score_no' => 0,
			'cond_ref'     => 'A8.1', 'cond_val' => 'b', 'cond_op' => 'contains',
			'guidance_yes' => 'Mobile devices are included in your application control policy.',
			'guidance_no'  => 'Extend your application allow listing policy to cover mobile devices. Use an MDM solution or enforce app store restrictions on iOS and Android.',
		] );

		// ------------------------------------------------------------------ //
		// Grade thresholds
		// ------------------------------------------------------------------ //

		$thresholds = [
			[
				'min_score'    => 90,
				'grade_id'     => 'compliant',
				'grade_label'  => 'Compliant',
				'verdict_text' => 'Your organisation meets the Cyber Essentials requirements assessed in this questionnaire. Maintain these controls and keep your certificate up to date.',
				'color_hex'    => '#1a5e35',
				'bg_hex'       => '#d4f5e5',
			],
			[
				'min_score'    => 70,
				'grade_id'     => 'nearly_compliant',
				'grade_label'  => 'Nearly Compliant',
				'verdict_text' => 'Your organisation is close to meeting the Cyber Essentials requirements. Address the findings below to reach full compliance.',
				'color_hex'    => '#5a6e00',
				'bg_hex'       => '#f0f5d8',
			],
			[
				'min_score'    => 50,
				'grade_id'     => 'work_required',
				'grade_label'  => 'Work Required',
				'verdict_text' => 'Several Cyber Essentials controls are not in place. Work through the findings below before applying for certification.',
				'color_hex'    => '#7a4e00',
				'bg_hex'       => '#fef3d8',
			],
			[
				'min_score'    => 0,
				'grade_id'     => 'high_risk',
				'grade_label'  => 'High Risk',
				'verdict_text' => 'Significant Cyber Essentials controls are missing. Address the critical findings below as a priority before considering certification.',
				'color_hex'    => '#8a1c22',
				'bg_hex'       => '#fff5f5',
			],
		];

		foreach ( $thresholds as $threshold ) {
			WPQ_Database::insert_grade_threshold( array_merge(
				$threshold,
				[ 'questionnaire_id' => $q_id ]
			) );
		}

		// ------------------------------------------------------------------ //
		// Products
		// ------------------------------------------------------------------ //

		WPQ_Database::insert_product( [
			'questionnaire_id' => $q_id,
			'name'             => 'CyberCheck Professional Report',
			'slug'             => 'cybercheck-professional',
			'description'      => 'Detailed Cyber Essentials readiness report: domain breakdown, all findings with priority, recommended remediation actions, and an overall compliance score.',
			'price_gbp'        => 49.00,
			'stripe_price_id'  => '',
			'billing_type'     => 'one_off',
			'report_type'      => 'professional',
			'status'           => 'inactive',
		] );

		WPQ_Database::insert_product( [
			'questionnaire_id' => $q_id,
			'name'             => 'CyberCheck Annual Plan',
			'slug'             => 'cybercheck-annual',
			'description'      => 'Professional report plus quarterly reassessment access. Track your Cyber Essentials compliance progress throughout the year.',
			'price_gbp'        => 99.00,
			'stripe_price_id'  => '',
			'billing_type'     => 'subscription_annual',
			'report_type'      => 'annual',
			'status'           => 'inactive',
		] );

		return true;
	}
}
