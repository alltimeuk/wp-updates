<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Builds the versioned, structured assessment context sent to Claude and used
 * to populate the Questionnaire Report DOCX template. Contains only data
 * needed for the report — no IP address, browser metadata, session tokens,
 * Stripe identifiers, API credentials, marketing attribution, or internal
 * diagnostics.
 */
class WPQ_Questionnaire_Report_Context {

	public const CONTEXT_VERSION = 'questionnaire-report-context-v1';

	public static function build_for_submission( object $submission ): array {
		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			throw new RuntimeException( 'Questionnaire not found.' );
		}

		$structure     = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		$answers       = self::decode_array( $submission->answers_json ?? '' );
		$findings      = self::decode_array( $submission->findings_json ?? '' );
		$domain_scores = self::decode_array( $submission->domain_scores_json ?? '' );

		$template_checksum = (string) ( $questionnaire->claude_template_checksum ?? '' );

		return [
			'schema_version' => self::CONTEXT_VERSION,
			'traceability'   => [
				'context_version'   => self::CONTEXT_VERSION,
				'prompt_version'    => null,
				'questionnaire_id'  => (int) $questionnaire->id,
				'submission_id'     => (int) $submission->id,
				'questionnaire_ref' => (string) ( $questionnaire->ref ?? '' ),
				'template_checksum' => $template_checksum,
			],
			'customer'       => [
				'name'            => (string) ( $submission->contact_name ?? '' ),
				'company'         => (string) ( $submission->contact_company ?? '' ),
				'email'           => (string) ( $submission->contact_email ?? '' ),
				'submission_ref'  => (string) ( $submission->ref ?? '' ),
			],
			'questionnaire'  => [
				'id'                => (int) $questionnaire->id,
				'ref'               => (string) ( $questionnaire->ref ?? '' ),
				'name'              => (string) ( $questionnaire->name ?? '' ),
				'description'       => (string) ( $questionnaire->description ?? '' ),
				'category'          => (string) ( $questionnaire->category ?? '' ),
				'completion_date'   => (string) ( $submission->completed_at ?? '' ),
				'template_checksum' => $template_checksum,
			],
			'assessment'     => [
				'overall_score'    => $submission->overall_score !== null ? (int) $submission->overall_score : null,
				'grade_id'         => (string) ( $submission->grade_id ?? '' ),
				'grade_label'      => (string) ( $submission->grade_label ?? '' ),
				'verdict'          => self::grade_verdict( $structure, (string) ( $submission->grade_id ?? '' ) ),
				'duration_seconds' => $submission->duration_seconds !== null ? (int) $submission->duration_seconds : null,
				'domain_scores'    => self::normalise_domain_scores( $domain_scores ),
			],
			'questions'      => self::build_question_rows( $structure, $answers ),
			'findings'       => self::build_finding_rows( $findings ),
		];
	}

	private static function decode_array( mixed $json ): array {
		if ( ! is_string( $json ) || '' === $json ) {
			return [];
		}
		$decoded = json_decode( $json, true );
		return is_array( $decoded ) ? $decoded : [];
	}

	private static function grade_verdict( array $structure, string $grade_id ): string {
		if ( '' === $grade_id ) {
			return '';
		}
		foreach ( $structure['thresholds'] ?? [] as $threshold ) {
			if ( ( $threshold['grade_id'] ?? '' ) === $grade_id ) {
				return (string) ( $threshold['verdict_text'] ?? $threshold['verdict'] ?? '' );
			}
		}
		return '';
	}

	private static function normalise_domain_scores( array $domain_scores ): array {
		$rows = [];
		foreach ( array_values( $domain_scores ) as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$rows[] = [
				'name'  => (string) ( $entry['name'] ?? $entry['slug'] ?? '' ),
				'slug'  => (string) ( $entry['slug'] ?? '' ),
				'score' => $entry['score'] ?? null,
				'max'   => $entry['max'] ?? null,
				'pct'   => $entry['pct'] ?? null,
			];
		}
		return $rows;
	}

	private static function build_question_rows( array $structure, array $answers ): array {
		$rows = [];

		foreach ( $structure['domains'] ?? [] as $di => $domain ) {
			foreach ( $domain['questions'] ?? [] as $qi => $question ) {
				$key           = "{$di}_{$qi}";
				$scoring_mode  = (string) ( $question['scoring_mode'] ?? 'legacy_tri_state' );
				if ( ! array_key_exists( $key, $answers ) ) {
					continue;
				}

				$answer = $answers[ $key ];
				$rows[] = [
					'domain'             => (string) ( $domain['name'] ?? '' ),
					'domain_ref'         => (string) ( $domain['slug'] ?? '' ),
					'question_ref'       => (string) ( $question['question_ref'] ?? "{$di}.{$qi}" ),
					'question'           => (string) ( $question['question'] ?? '' ),
					'answer'             => self::answer_label( $question, $answer ),
					'scoring_mode'       => $scoring_mode,
					'score_contribution' => 'non_scoring' === $scoring_mode ? null : self::score_contribution( $question, $answer ),
					'recommendation'     => (string) ( $question['recommendation'] ?? '' ),
					'help_text'          => (string) ( $question['help_text'] ?? '' ),
				];
			}
		}

		return $rows;
	}

	private static function answer_label( array $question, mixed $answer ): string {
		if ( is_array( $answer ) ) {
			return implode( ', ', array_map( static fn( $item ) => self::answer_label( $question, $item ), $answer ) );
		}

		if ( is_string( $answer ) ) {
			$decoded = json_decode( $answer, true );
			if ( is_array( $decoded ) ) {
				return implode( ', ', array_map( static fn( $item ) => self::answer_label( $question, $item ), $decoded ) );
			}
		}

		$type = (string) ( $question['question_type'] ?? 'tri_state' );
		if ( 'tri_state' === $type ) {
			$map = [ 'yes' => 'Yes', 'partial' => 'Partial', 'no' => 'No' ];
			if ( isset( $map[ (string) $answer ] ) ) {
				return $map[ (string) $answer ];
			}
		}
		if ( 'boolean' === $type ) {
			return 'yes' === $answer ? 'Yes' : 'No';
		}

		foreach ( $question['options'] ?? [] as $option ) {
			if ( (string) ( $option['key'] ?? '' ) === (string) $answer ) {
				return (string) ( $option['label'] ?? $answer );
			}
		}

		return is_scalar( $answer ) ? (string) $answer : '';
	}

	private static function score_contribution( array $question, mixed $answer ): ?int {
		$mode = (string) ( $question['scoring_mode'] ?? 'legacy_tri_state' );

		if ( in_array( $mode, [ 'legacy_tri_state' ], true ) ) {
			return match ( (string) $answer ) {
				'yes'     => (int) ( $question['score_yes'] ?? 0 ),
				'partial' => (int) ( $question['score_partial'] ?? 0 ),
				'no'      => (int) ( $question['score_no'] ?? 0 ),
				default   => null,
			};
		}

		if ( in_array( $mode, [ 'boolean', 'reverse_boolean' ], true ) ) {
			$is_yes = 'yes' === $answer;
			if ( 'reverse_boolean' === $mode ) {
				$is_yes = ! $is_yes;
			}
			return $is_yes ? (int) ( $question['score_yes'] ?? 0 ) : (int) ( $question['score_no'] ?? 0 );
		}

		if ( 'single_option' === $mode ) {
			foreach ( $question['options'] ?? [] as $option ) {
				if ( (string) ( $option['key'] ?? '' ) === (string) $answer ) {
					return (int) ( $option['score'] ?? 0 );
				}
			}
			return null;
		}

		if ( in_array( $mode, [ 'sum_selected', 'max_selected' ], true ) ) {
			$selected = is_array( $answer ) ? $answer : ( is_string( $answer ) && is_array( json_decode( $answer, true ) ) ? json_decode( $answer, true ) : [] );
			$scores   = [];
			foreach ( $question['options'] ?? [] as $option ) {
				if ( in_array( (string) ( $option['key'] ?? '' ), array_map( 'strval', (array) $selected ), true ) ) {
					$scores[] = (int) ( $option['score'] ?? 0 );
				}
			}
			if ( empty( $scores ) ) {
				return 0;
			}
			return 'max_selected' === $mode ? max( $scores ) : array_sum( $scores );
		}

		return null;
	}

	private static function build_finding_rows( array $findings ): array {
		$rows = [];
		foreach ( array_values( $findings ) as $finding ) {
			if ( ! is_array( $finding ) ) {
				continue;
			}
			$rows[] = [
				'priority'       => (string) ( $finding['priority'] ?? $finding['finding_priority'] ?? '' ),
				'domain'         => (string) ( $finding['domain'] ?? $finding['domain_name'] ?? '' ),
				'finding'        => (string) ( $finding['finding'] ?? $finding['issue'] ?? '' ),
				'action'         => (string) ( $finding['action'] ?? $finding['finding_action'] ?? '' ),
				'rationale'      => (string) ( $finding['rationale'] ?? $finding['guidance'] ?? '' ),
				'question_ref'   => (string) ( $finding['question_ref'] ?? $finding['ref'] ?? '' ),
			];
		}
		return $rows;
	}

	public static function summary( array $context ): array {
		return [
			'questionnaire_ref' => (string) ( $context['traceability']['questionnaire_ref'] ?? '' ),
			'question_count'    => is_array( $context['questions'] ?? null ) ? count( $context['questions'] ) : 0,
			'finding_count'     => is_array( $context['findings'] ?? null ) ? count( $context['findings'] ) : 0,
			'domain_count'      => is_array( $context['assessment']['domain_scores'] ?? null ) ? count( $context['assessment']['domain_scores'] ) : 0,
		];
	}
}
