<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Framework readiness radar ("spider") chart, drawn deterministically from the
 * framework assessments stored in qr_analysis_json — never from a live Claude
 * call. One spoke per assessed framework; radius is the readiness position;
 * colour is the readiness level.
 *
 * Radius precedence per framework:
 *   1. readiness_percent — only present when the standard's own methodology
 *      yields a defensible figure (the analysis schema forbids estimating).
 *   2. Cited-control ratio — strengths / (strengths + gaps), both lists carry
 *      validated control references, so this is a data-backed coverage signal.
 *   3. Level band — aligned 85, partially_aligned 50, not_aligned 15,
 *      insufficient_evidence 5 — a last-resort indicative position.
 *
 * Two renderers from one row model:
 *   - render_svg(): inline SVG for the admin submission detail and the public
 *     results screen. Presentation attributes only (fill/stroke/font-*), no
 *     style attributes and no scripts, so it renders under the strictest CSP
 *     the frontend has to satisfy (style-src-attr 'none').
 *   - render_png(): GD-drawn PNG for the DOCX template (via image macro) and
 *     the Dompdf HTML report (as a data URI). Uses the DejaVu font bundled
 *     with Dompdf when present, falling back to GD's built-in font.
 *
 * A radar needs at least three spokes to read as a shape; with one or two
 * frameworks both renderers fall back to colour-coded horizontal bars.
 */
class WPQ_Framework_Radar {

	public const LEVEL_COLOURS = [
		'aligned'               => '#2eb872',
		'partially_aligned'     => '#f5a623',
		'not_aligned'           => '#e84855',
		'insufficient_evidence' => '#9aa3ad',
	];

	private const LEVEL_BANDS = [
		'aligned'               => 85,
		'partially_aligned'     => 50,
		'not_aligned'           => 15,
		'insufficient_evidence' => 5,
	];

	private const POLYGON_FILL   = '31,58,95'; // Navy, used at low alpha behind the vertices.
	private const MIN_RADAR_ROWS = 3;

	/**
	 * Decode a submission's stored analysis and return its framework rows,
	 * or [] when no analysis or no frameworks section exists.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function stored_frameworks( object $submission ): array {
		$raw = (string) ( $submission->qr_analysis_json ?? '' );
		if ( '' === $raw ) {
			return [];
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) || ! is_array( $decoded['frameworks'] ?? null ) ) {
			return [];
		}
		return array_values( array_filter( $decoded['frameworks'], 'is_array' ) );
	}

	/**
	 * Normalise stored assessment rows into the chart row model.
	 *
	 * @param array<int, array<string, mixed>> $frameworks Stored assessment rows.
	 * @return array<int, array{name: string, level: string, label: string, percent: int, derived: bool}>
	 */
	public static function rows_from_analysis( array $frameworks ): array {
		$rows = [];
		foreach ( $frameworks as $framework ) {
			if ( ! is_array( $framework ) ) {
				continue;
			}
			$name = trim( (string) ( $framework['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}

			$level = strtolower( trim( (string) ( $framework['readiness_level'] ?? $framework['level'] ?? '' ) ) );
			if ( ! isset( self::LEVEL_COLOURS[ $level ] ) ) {
				$level = 'insufficient_evidence';
			}

			$percent = null;
			$derived = false;
			if ( isset( $framework['readiness_percent'] ) && is_numeric( $framework['readiness_percent'] ) ) {
				$percent = max( 0, min( 100, (int) $framework['readiness_percent'] ) );
			}

			if ( null === $percent ) {
				$strengths = is_array( $framework['strengths'] ?? null ) ? count( $framework['strengths'] ) : 0;
				$gaps      = is_array( $framework['gaps'] ?? null ) ? count( $framework['gaps'] ) : 0;
				$derived   = true;
				if ( ( $strengths + $gaps ) > 0 ) {
					$percent = (int) round( 100 * $strengths / ( $strengths + $gaps ) );
				} else {
					$percent = self::LEVEL_BANDS[ $level ];
				}
			}

			$rows[] = [
				'name'    => $name,
				'level'   => $level,
				'label'   => trim( (string) ( $framework['readiness_label'] ?? '' ) ) ?: ucwords( str_replace( '_', ' ', $level ) ),
				'percent' => $percent,
				'derived' => $derived,
			];
		}

		return $rows;
	}

	/**
	 * Inline SVG chart (radar for 3+ rows, bars otherwise). Returns '' when
	 * there is nothing to draw.
	 *
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	public static function render_svg( array $rows ): string {
		if ( empty( $rows ) ) {
			return '';
		}
		return count( $rows ) >= self::MIN_RADAR_ROWS ? self::svg_radar( $rows ) : self::svg_bars( $rows );
	}

	/** @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows */
	private static function svg_radar( array $rows ): string {
		$count  = count( $rows );
		$width  = 560;
		$legend = 26 * $count + 16;
		$height = 430 + $legend;
		$cx     = $width / 2;
		$cy     = 215;
		$radius = 140.0;

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Framework readiness radar" class="wpq-radar-svg">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';

		// Concentric guide rings at 25/50/75/100.
		foreach ( [ 25, 50, 75, 100 ] as $ring ) {
			$points = [];
			for ( $i = 0; $i < $count; $i++ ) {
				[ $x, $y ] = self::point( $cx, $cy, $radius * $ring / 100, $i, $count );
				$points[]  = self::coord( $x ) . ',' . self::coord( $y );
			}
			$svg .= '<polygon points="' . implode( ' ', $points ) . '" fill="none" stroke="#e3e6ea" stroke-width="1"/>';
			[ $lx, $ly ] = self::point( $cx, $cy, $radius * $ring / 100, 0, $count );
			$svg        .= '<text x="' . self::coord( $lx + 6 ) . '" y="' . self::coord( $ly + 4 ) . '" font-size="9" fill="#9aa3ad" font-family="Helvetica, Arial, sans-serif">' . $ring . '</text>';
		}

		// Spokes and axis labels.
		for ( $i = 0; $i < $count; $i++ ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius, $i, $count );
			$svg      .= '<line x1="' . self::coord( $cx ) . '" y1="' . self::coord( $cy ) . '" x2="' . self::coord( $x ) . '" y2="' . self::coord( $y ) . '" stroke="#e3e6ea" stroke-width="1"/>';

			[ $lx, $ly ] = self::point( $cx, $cy, $radius + 18, $i, $count );
			$anchor      = 'middle';
			if ( $lx > $cx + 8 ) {
				$anchor = 'start';
			} elseif ( $lx < $cx - 8 ) {
				$anchor = 'end';
			}
			$svg .= '<text x="' . self::coord( $lx ) . '" y="' . self::coord( $ly + 4 ) . '" font-size="11" font-weight="600" fill="#33414f" text-anchor="' . $anchor . '" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( self::truncate( $rows[ $i ]['name'], 26 ) ) . '</text>';
		}

		// Data polygon.
		$points = [];
		foreach ( $rows as $i => $row ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$points[]  = self::coord( $x ) . ',' . self::coord( $y );
		}
		$svg .= '<polygon points="' . implode( ' ', $points ) . '" fill="rgba(' . self::POLYGON_FILL . ',0.16)" stroke="rgba(' . self::POLYGON_FILL . ',0.55)" stroke-width="2"/>';

		// Colour-coded vertices with value titles (native SVG tooltip).
		foreach ( $rows as $i => $row ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$svg      .= '<circle cx="' . self::coord( $x ) . '" cy="' . self::coord( $y ) . '" r="6" fill="' . self::LEVEL_COLOURS[ $row['level'] ] . '" stroke="#ffffff" stroke-width="2">'
				. '<title>' . self::escape( $row['name'] . ' — ' . $row['label'] . ' (' . $row['percent'] . ( $row['derived'] ? '≈' : '' ) . '%)' ) . '</title></circle>';
		}

		$svg .= self::svg_legend( $rows, 24, 430, $width - 48 );
		$svg .= '</svg>';

		return $svg;
	}

	/** @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows */
	private static function svg_bars( array $rows ): string {
		$width    = 560;
		$row_h    = 54;
		$height   = 16 + $row_h * count( $rows );
		$bar_x    = 12;
		$bar_full = $width - 130;

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Framework readiness" class="wpq-radar-svg">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';

		foreach ( $rows as $i => $row ) {
			$top  = 16 + $i * $row_h;
			$svg .= '<text x="' . $bar_x . '" y="' . ( $top + 12 ) . '" font-size="12" font-weight="600" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( self::truncate( $row['name'], 52 ) ) . '</text>';
			$svg .= '<rect x="' . $bar_x . '" y="' . ( $top + 20 ) . '" width="' . $bar_full . '" height="14" rx="7" fill="#eef1f4"/>';
			$svg .= '<rect x="' . $bar_x . '" y="' . ( $top + 20 ) . '" width="' . self::coord( max( 7, $bar_full * $row['percent'] / 100 ) ) . '" height="14" rx="7" fill="' . self::LEVEL_COLOURS[ $row['level'] ] . '"/>';
			$svg .= '<text x="' . ( $bar_x + $bar_full + 10 ) . '" y="' . ( $top + 32 ) . '" font-size="11" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( $row['label'] . ' (' . $row['percent'] . ( $row['derived'] ? '≈' : '' ) . '%)' ) . '</text>';
		}

		$svg .= '</svg>';
		return $svg;
	}

	/** @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows */
	private static function svg_legend( array $rows, int $x, int $y, int $max_width ): string {
		$svg = '';
		foreach ( $rows as $i => $row ) {
			$line_y = $y + 26 * $i + 14;
			$svg   .= '<circle cx="' . ( $x + 6 ) . '" cy="' . ( $line_y - 4 ) . '" r="6" fill="' . self::LEVEL_COLOURS[ $row['level'] ] . '"/>';
			$svg   .= '<text x="' . ( $x + 20 ) . '" y="' . $line_y . '" font-size="12" fill="#33414f" font-family="Helvetica, Arial, sans-serif">'
				. self::escape( self::truncate( $row['name'], 48 ) . ' — ' . $row['label'] . ' (' . $row['percent'] . ( $row['derived'] ? '≈' : '' ) . '%)' ) . '</text>';
		}
		return $svg;
	}

	/**
	 * GD-drawn PNG (radar or bars, mirroring the SVG). Returns null when GD is
	 * unavailable or drawing fails — callers must treat the image as optional.
	 *
	 * @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows
	 */
	public static function render_png( array $rows, int $width = 1120 ): ?string {
		if ( empty( $rows ) || ! function_exists( 'imagecreatetruecolor' ) ) {
			return null;
		}

		try {
			return count( $rows ) >= self::MIN_RADAR_ROWS
				? self::png_radar( $rows, $width )
				: self::png_bars( $rows, $width );
		} catch ( Throwable $e ) {
			return null;
		}
	}

	/** @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows */
	private static function png_radar( array $rows, int $width ): ?string {
		$count  = count( $rows );
		$legend = 52 * $count + 32;
		$height = 860 + $legend;
		$cx     = (int) ( $width / 2 );
		$cy     = 430;
		$radius = 280.0;

		$img = imagecreatetruecolor( $width, $height );
		if ( function_exists( 'imageantialias' ) ) {
			imageantialias( $img, true );
		}
		$white  = imagecolorallocate( $img, 255, 255, 255 );
		$grid   = imagecolorallocate( $img, 227, 230, 234 );
		$text   = imagecolorallocate( $img, 51, 65, 79 );
		$muted  = imagecolorallocate( $img, 154, 163, 173 );
		$fill   = imagecolorallocatealpha( $img, 31, 58, 95, 105 );
		$stroke = imagecolorallocatealpha( $img, 31, 58, 95, 55 );
		imagefill( $img, 0, 0, $white );

		// Guide rings.
		foreach ( [ 25, 50, 75, 100 ] as $ring ) {
			$points = [];
			for ( $i = 0; $i < $count; $i++ ) {
				[ $x, $y ] = self::point( $cx, $cy, $radius * $ring / 100, $i, $count );
				$points[]  = (int) round( $x );
				$points[]  = (int) round( $y );
			}
			imagepolygon( $img, $points, $grid );
			[ $lx, $ly ] = self::point( $cx, $cy, $radius * $ring / 100, 0, $count );
			self::png_text( $img, 13, (int) round( $lx + 8 ), (int) round( $ly + 5 ), (string) $ring, $muted );
		}

		// Spokes + axis labels.
		for ( $i = 0; $i < $count; $i++ ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius, $i, $count );
			imageline( $img, $cx, $cy, (int) round( $x ), (int) round( $y ), $grid );
			[ $lx, $ly ] = self::point( $cx, $cy, $radius + 34, $i, $count );
			$label       = self::truncate( $rows[ $i ]['name'], 28 );
			$approx_w    = self::png_text_width( 17, $label );
			$tx          = (int) round( $lx );
			if ( $lx > $cx + 10 ) {
				// keep as-is (anchor start)
				$tx = (int) round( $lx );
			} elseif ( $lx < $cx - 10 ) {
				$tx = (int) round( $lx - $approx_w );
			} else {
				$tx = (int) round( $lx - $approx_w / 2 );
			}
			self::png_text( $img, 17, $tx, (int) round( $ly + 6 ), $label, $text, true );
		}

		// Data polygon.
		$points = [];
		foreach ( $rows as $i => $row ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$points[]  = (int) round( $x );
			$points[]  = (int) round( $y );
		}
		imagefilledpolygon( $img, $points, $fill );
		if ( function_exists( 'imagesetthickness' ) ) {
			imagesetthickness( $img, 3 );
		}
		imagepolygon( $img, $points, $stroke );
		if ( function_exists( 'imagesetthickness' ) ) {
			imagesetthickness( $img, 1 );
		}

		// Vertices.
		foreach ( $rows as $i => $row ) {
			[ $x, $y ] = self::point( $cx, $cy, $radius * $row['percent'] / 100, $i, $count );
			$colour    = self::png_level_colour( $img, $row['level'] );
			imagefilledellipse( $img, (int) round( $x ), (int) round( $y ), 22, 22, $white );
			imagefilledellipse( $img, (int) round( $x ), (int) round( $y ), 16, 16, $colour );
		}

		// Legend.
		$ly = 860 + 16;
		foreach ( $rows as $row ) {
			$colour = self::png_level_colour( $img, $row['level'] );
			imagefilledellipse( $img, 40, $ly + 14, 18, 18, $colour );
			self::png_text( $img, 17, 62, $ly + 21, self::truncate( $row['name'], 52 ) . ' — ' . $row['label'] . ' (' . $row['percent'] . ( $row['derived'] ? '~' : '' ) . '%)', $text );
			$ly += 52;
		}

		return self::png_output( $img );
	}

	/** @param array<int, array{name: string, level: string, label: string, percent: int, derived: bool}> $rows */
	private static function png_bars( array $rows, int $width ): ?string {
		$row_h  = 104;
		$height = 32 + $row_h * count( $rows );
		$img    = imagecreatetruecolor( $width, $height );
		$white  = imagecolorallocate( $img, 255, 255, 255 );
		$track  = imagecolorallocate( $img, 238, 241, 244 );
		$text   = imagecolorallocate( $img, 51, 65, 79 );
		imagefill( $img, 0, 0, $white );

		$bar_x    = 24;
		$bar_full = $width - 260;
		foreach ( $rows as $i => $row ) {
			$top    = 32 + $i * $row_h;
			$colour = self::png_level_colour( $img, $row['level'] );
			self::png_text( $img, 18, $bar_x, $top + 18, self::truncate( $row['name'], 60 ), $text, true );
			imagefilledrectangle( $img, $bar_x, $top + 34, $bar_x + $bar_full, $top + 60, $track );
			imagefilledrectangle( $img, $bar_x, $top + 34, $bar_x + max( 14, (int) round( $bar_full * $row['percent'] / 100 ) ), $top + 60, $colour );
			self::png_text( $img, 16, $bar_x + $bar_full + 16, $top + 54, $row['label'] . ' (' . $row['percent'] . ( $row['derived'] ? '~' : '' ) . '%)', $text );
		}

		return self::png_output( $img );
	}

	/** @return array{0: float, 1: float} */
	private static function point( float $cx, float $cy, float $r, int $index, int $count ): array {
		$angle = -M_PI / 2 + 2 * M_PI * $index / $count;
		return [ $cx + $r * cos( $angle ), $cy + $r * sin( $angle ) ];
	}

	private static function coord( float $value ): string {
		return rtrim( rtrim( sprintf( '%.1F', $value ), '0' ), '.' );
	}

	private static function escape( string $value ): string {
		return htmlspecialchars( $value, ENT_QUOTES | ENT_XML1, 'UTF-8' );
	}

	private static function truncate( string $value, int $length ): string {
		if ( function_exists( 'mb_strlen' ) && function_exists( 'mb_substr' ) ) {
			return mb_strlen( $value ) > $length ? rtrim( mb_substr( $value, 0, $length - 1 ) ) . '…' : $value;
		}
		return strlen( $value ) > $length ? rtrim( substr( $value, 0, $length - 1 ) ) . '...' : $value;
	}

	/** @param resource|\GdImage $img */
	private static function png_level_colour( $img, string $level ): int {
		$hex = self::LEVEL_COLOURS[ $level ] ?? self::LEVEL_COLOURS['insufficient_evidence'];
		return imagecolorallocate(
			$img,
			(int) hexdec( substr( $hex, 1, 2 ) ),
			(int) hexdec( substr( $hex, 3, 2 ) ),
			(int) hexdec( substr( $hex, 5, 2 ) )
		);
	}

	private static function ttf_path(): string {
		$candidates = [
			WPQ_PLUGIN_DIR . 'vendor/dompdf/dompdf/lib/fonts/DejaVuSans.ttf',
			WPQ_PLUGIN_DIR . 'vendor/dompdf/dompdf/lib/fonts/DejaVuSans-Bold.ttf',
		];
		foreach ( $candidates as $candidate ) {
			if ( is_readable( $candidate ) ) {
				return $candidate;
			}
		}
		return '';
	}

	/** Approximate rendered text width for right/centre alignment. */
	private static function png_text_width( int $size, string $text ): int {
		$font = self::ttf_path();
		if ( '' !== $font && function_exists( 'imagettfbbox' ) ) {
			$box = imagettfbbox( $size, 0, $font, $text );
			if ( is_array( $box ) ) {
				return (int) abs( $box[2] - $box[0] );
			}
		}
		return (int) ( strlen( $text ) * $size * 0.6 );
	}

	/** @param resource|\GdImage $img */
	private static function png_text( $img, int $size, int $x, int $y, string $text, int $colour, bool $bold = false ): void {
		$font = self::ttf_path();
		if ( '' !== $font && function_exists( 'imagettftext' ) ) {
			imagettftext( $img, $size, 0, $x, $y, $colour, $font, $text );
			if ( $bold ) {
				imagettftext( $img, $size, 0, $x + 1, $y, $colour, $font, $text );
			}
			return;
		}
		imagestring( $img, $bold ? 5 : 4, $x, $y - 12, $text, $colour );
	}

	/** @param resource|\GdImage $img */
	private static function png_output( $img ): ?string {
		ob_start();
		$ok     = imagepng( $img );
		$binary = ob_get_clean();
		imagedestroy( $img );
		return ( $ok && is_string( $binary ) && '' !== $binary ) ? $binary : null;
	}
}
