<?php
/**
 * Admin-side operations for the canonical contact master: list/detail
 * queries for the Contacts screens, the ambiguous-match review actions,
 * the deliberate merge workflow, and the audit trail. All mutations here
 * are called from capability-checked, nonce-verified admin handlers only.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) && ! defined( 'WPQ_TESTING' ) ) {
	exit;
}

class WPQ_Contact_Admin {

	// ------------------------------------------------------------------ //
	// List and detail
	// ------------------------------------------------------------------ //

	/**
	 * Paginated canonical contact list with primary email, verification,
	 * interaction counts, last interaction and marketing state.
	 *
	 * @param array{search?: string, status?: string, per_page?: int, page?: int} $args
	 * @return array<int, object>
	 */
	public static function list_contacts( array $args = [] ): array {
		global $wpdb;
		$per_page = max( 1, min( 200, (int) ( $args['per_page'] ?? 50 ) ) );
		$offset   = ( max( 1, (int) ( $args['page'] ?? 1 ) ) - 1 ) * $per_page;
		$search   = trim( (string) ( $args['search'] ?? '' ) );
		$status   = sanitize_key( (string) ( $args['status'] ?? '' ) );

		$where  = "c.status NOT IN ('merged','deleted')";
		$params = [];
		if ( '' !== $status ) {
			$where   .= ' AND c.status = %s';
			$params[] = $status;
		}
		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (c.display_name LIKE %s OR c.organisation LIKE %s OR EXISTS (
				SELECT 1 FROM ' . $wpdb->prefix . 'wpq_contact_identities si
				WHERE si.contact_id = c.id AND si.value_normalised LIKE %s))';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = "SELECT c.*,
			(SELECT i.value_original FROM {$wpdb->prefix}wpq_contact_identities i
			 WHERE i.contact_id = c.id AND i.type = 'email' AND i.is_primary = 1 LIMIT 1) AS primary_email,
			(SELECT i.verification FROM {$wpdb->prefix}wpq_contact_identities i
			 WHERE i.contact_id = c.id AND i.type = 'email' AND i.is_primary = 1 LIMIT 1) AS primary_email_verification,
			(SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions s WHERE s.contact_id = c.id) AS submission_count,
			(SELECT COUNT(*) FROM {$wpdb->prefix}wpq_enquiries e WHERE e.contact_id = c.id) AS enquiry_count,
			(SELECT MAX(x.occurred_at) FROM {$wpdb->prefix}wpq_contact_interactions x WHERE x.contact_id = c.id) AS last_interaction_at,
			(SELECT p.state FROM {$wpdb->prefix}wpq_contact_preferences_current p
			 WHERE p.contact_id = c.id AND p.purpose = 'direct_marketing_email' ORDER BY p.identity_id ASC LIMIT 1) AS marketing_state,
			(SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contact_match_review r
			 WHERE r.status = 'pending' AND FIND_IN_SET(c.id, r.candidate_contact_ids) > 0) AS pending_review_count
			FROM {$wpdb->prefix}wpq_contacts c
			WHERE {$where}
			ORDER BY COALESCE((SELECT MAX(x2.occurred_at) FROM {$wpdb->prefix}wpq_contact_interactions x2 WHERE x2.contact_id = c.id), c.created_at) DESC
			LIMIT %d OFFSET %d";

		$params[] = $per_page;
		$params[] = $offset;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql is built above from internal fragments; all user input travels via $params placeholders.
		return $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) ?: [];
	}

	/**
	 * @param array{search?: string, status?: string} $args
	 */
	public static function count_contacts( array $args = [] ): int {
		global $wpdb;
		$search = trim( (string) ( $args['search'] ?? '' ) );
		$status = sanitize_key( (string) ( $args['status'] ?? '' ) );

		$where  = "c.status NOT IN ('merged','deleted')";
		$params = [];
		if ( '' !== $status ) {
			$where   .= ' AND c.status = %s';
			$params[] = $status;
		}
		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (c.display_name LIKE %s OR c.organisation LIKE %s OR EXISTS (
				SELECT 1 FROM ' . $wpdb->prefix . 'wpq_contact_identities si
				WHERE si.contact_id = c.id AND si.value_normalised LIKE %s))';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = "SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contacts c WHERE {$where}";
		if ( empty( $params ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Static internal SQL with no user input.
			return (int) $wpdb->get_var( $sql );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql is built above from internal fragments; all user input travels via $params placeholders.
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
	}

	/**
	 * Everything the contact detail screen shows.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function get_profile( int $contact_id ): ?array {
		global $wpdb;
		$contact = WPQ_Contact_Repository::get_contact( $contact_id );
		if ( ! $contact ) {
			return null;
		}

		return [
			'contact'       => $contact,
			'identities'    => $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpq_contact_identities WHERE contact_id = %d ORDER BY is_primary DESC, id ASC",
				$contact_id
			) ) ?: [],
			'organisations' => $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpq_contact_organisations WHERE contact_id = %d ORDER BY is_primary DESC, id ASC",
				$contact_id
			) ) ?: [],
			'preferences'   => $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpq_contact_preferences_current WHERE contact_id = %d ORDER BY purpose ASC",
				$contact_id
			) ) ?: [],
			'interactions'  => $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpq_contact_interactions WHERE contact_id = %d ORDER BY occurred_at DESC LIMIT 100",
				$contact_id
			) ) ?: [],
			'submissions'   => $wpdb->get_results( $wpdb->prepare(
				"SELECT id, ref, contact_name, contact_email, contact_company, overall_score, grade_id,
				        payment_status, halopsa_lead_id, halopsa_sync_status, started_at, completed_at
				 FROM {$wpdb->prefix}wpq_submissions WHERE contact_id = %d ORDER BY id DESC LIMIT 100",
				$contact_id
			) ) ?: [],
			'enquiries'     => $wpdb->get_results( $wpdb->prepare(
				"SELECT id, ref, contact_name, contact_email, contact_company, status, created_at
				 FROM {$wpdb->prefix}wpq_enquiries WHERE contact_id = %d ORDER BY id DESC LIMIT 100",
				$contact_id
			) ) ?: [],
			'merges'        => $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpq_contact_merge_log
				 WHERE survivor_id = %d OR absorbed_id = %d ORDER BY id DESC LIMIT 20",
				$contact_id,
				$contact_id
			) ) ?: [],
			'audit'         => $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpq_contact_audit WHERE contact_id = %d ORDER BY id DESC LIMIT 50",
				$contact_id
			) ) ?: [],
		];
	}

	// ------------------------------------------------------------------ //
	// Audit
	// ------------------------------------------------------------------ //

	/**
	 * @param array<string, mixed> $before
	 * @param array<string, mixed> $after
	 */
	public static function record_audit( int $contact_id, string $action, string $actor, array $before = [], array $after = [], string $reason = '' ): void {
		global $wpdb;
		$wpdb->insert( "{$wpdb->prefix}wpq_contact_audit", [
			'contact_id'     => $contact_id,
			'action'         => sanitize_key( $action ),
			'actor'          => mb_substr( sanitize_text_field( $actor ), 0, 100 ),
			'before_summary' => wp_json_encode( $before ),
			'after_summary'  => wp_json_encode( $after ),
			'reason'         => '' !== $reason ? sanitize_textarea_field( $reason ) : null,
			'created_at'     => current_time( 'mysql', true ),
		] );
	}

	/**
	 * Edit canonical scalar fields with an audit record. Historic snapshots
	 * are untouched by design — this only changes the canonical profile.
	 *
	 * @param array{display_name?: string, organisation?: string, job_title?: string} $fields
	 */
	public static function edit_contact( int $contact_id, array $fields, string $actor, string $reason = '' ): bool {
		$contact = WPQ_Contact_Repository::get_contact( $contact_id );
		if ( ! $contact ) {
			return false;
		}

		$updates = [];
		$before  = [];
		$after   = [];
		foreach ( [ 'display_name', 'organisation', 'job_title' ] as $field ) {
			if ( ! array_key_exists( $field, $fields ) ) {
				continue;
			}
			$incoming = sanitize_text_field( (string) $fields[ $field ] );
			$current  = (string) ( $contact->{$field} ?? '' );
			// Blank input never erases a populated canonical value.
			if ( '' === trim( $incoming ) || $incoming === $current ) {
				continue;
			}
			$updates[ $field ] = $incoming;
			$before[ $field ]  = $current;
			$after[ $field ]   = $incoming;
		}
		if ( isset( $updates['display_name'] ) ) {
			$split                  = WPQ_Contact_Normaliser::split_name( $updates['display_name'] );
			$updates['given_name']  = $split['given'];
			$updates['family_name'] = $split['family'];
		}
		if ( empty( $updates ) ) {
			return false;
		}

		$ok = WPQ_Contact_Repository::update_contact( $contact_id, $updates );
		if ( $ok ) {
			self::record_audit( $contact_id, 'edit', $actor, $before, $after, $reason );
			do_action( 'alltime_contact_updated', $contact_id, array_keys( $after ), [ 'actor' => $actor ] );
		}

		return $ok;
	}

	// ------------------------------------------------------------------ //
	// Review queue
	// ------------------------------------------------------------------ //

	/** @return array<int, object> */
	public static function get_pending_reviews( int $limit = 100 ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_contact_match_review WHERE status = 'pending' ORDER BY id ASC LIMIT %d",
			max( 1, min( 500, $limit ) )
		) ) ?: [];
	}

	public static function get_review( int $review_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_contact_match_review WHERE id = %d",
			$review_id
		) ) ?: null;
	}

	/**
	 * Resolve a review candidate. Valid resolutions: link_to_existing (moves
	 * the source record's provisional contact into the chosen contact via
	 * merge), create_separate_contact / mark_shared_identity (keep as-is),
	 * defer, ignore_with_reason.
	 */
	public static function resolve_review( int $review_id, string $resolution, string $actor, string $reason = '', int $target_contact_id = 0 ): bool {
		global $wpdb;
		$review = self::get_review( $review_id );
		if ( ! $review || 'pending' !== (string) $review->status ) {
			return false;
		}

		$valid = [ 'link_to_existing', 'create_separate_contact', 'merge_contacts', 'mark_shared_identity', 'defer', 'ignore_with_reason' ];
		if ( ! in_array( $resolution, $valid, true ) ) {
			return false;
		}

		if ( in_array( $resolution, [ 'link_to_existing', 'merge_contacts' ], true ) ) {
			// The review's first candidate is the provisional contact created for
			// the ambiguous record; merging it into the chosen survivor performs
			// the link with full audit and snapshot preservation.
			$candidates  = array_map( 'intval', array_filter( explode( ',', (string) $review->candidate_contact_ids ) ) );
			$provisional = (int) ( $candidates[0] ?? 0 );
			if ( $target_contact_id <= 0 || $provisional <= 0 || $target_contact_id === $provisional ) {
				return false;
			}
			$merged = self::merge_contacts( $target_contact_id, $provisional, $actor, 'review:' . $resolution . ( '' !== $reason ? ' — ' . $reason : '' ) );
			if ( ! $merged ) {
				return false;
			}
		}

		$status = 'defer' === $resolution ? 'deferred' : ( 'ignore_with_reason' === $resolution ? 'ignored' : 'resolved' );

		return false !== $wpdb->update(
			"{$wpdb->prefix}wpq_contact_match_review",
			[
				'status'      => $status,
				'resolution'  => sanitize_key( $resolution ),
				'resolved_by' => mb_substr( sanitize_text_field( $actor ), 0, 100 ),
				'resolved_at' => 'defer' === $resolution ? null : current_time( 'mysql', true ),
			],
			[ 'id' => $review_id ]
		);
	}

	// ------------------------------------------------------------------ //
	// Merge
	// ------------------------------------------------------------------ //

	/**
	 * Deliberate merge: repoints source records, identities, organisations,
	 * interactions and consent events to the survivor, reprojects preferences
	 * (most restrictive state wins by construction), marks the absorbed
	 * contact merged (never deleted), and records merge log + audit.
	 */
	public static function merge_contacts( int $survivor_id, int $absorbed_id, string $actor, string $reason = '' ): bool {
		global $wpdb;
		if ( $survivor_id <= 0 || $absorbed_id <= 0 || $survivor_id === $absorbed_id ) {
			return false;
		}
		$survivor = WPQ_Contact_Repository::get_contact( $survivor_id );
		$absorbed = WPQ_Contact_Repository::get_contact( $absorbed_id );
		if ( ! $survivor || ! $absorbed || 'merged' === (string) $absorbed->status || 'merged' === (string) $survivor->status ) {
			return false;
		}

		$before = [
			'survivor' => [ 'id' => $survivor_id, 'display_name' => (string) $survivor->display_name, 'status' => (string) $survivor->status ],
			'absorbed' => [ 'id' => $absorbed_id, 'display_name' => (string) $absorbed->display_name, 'status' => (string) $absorbed->status ],
		];

		// The whole merge is one transaction: a partially applied merge (children
		// repointed but the absorbed contact never marked merged, or vice versa)
		// leaves the canonical model ambiguous and is worse than a clean failure.
		$merged = WPQ_Database::transaction( static function () use ( $wpdb, $survivor, $absorbed, $survivor_id, $absorbed_id, $actor, $reason, $before ) {

		// Repoint source records and canonical children. Snapshots are columns
		// on the source rows and are untouched by design.
		$wpdb->update( "{$wpdb->prefix}wpq_submissions", [ 'contact_id' => $survivor_id ], [ 'contact_id' => $absorbed_id ] );
		$wpdb->update( "{$wpdb->prefix}wpq_enquiries", [ 'contact_id' => $survivor_id ], [ 'contact_id' => $absorbed_id ] );
		$wpdb->update( "{$wpdb->prefix}wpq_contact_organisations", [ 'contact_id' => $survivor_id ], [ 'contact_id' => $absorbed_id ] );
		$wpdb->update( "{$wpdb->prefix}wpq_contact_consent_events", [ 'contact_id' => $survivor_id ], [ 'contact_id' => $absorbed_id ] );

		// Identities move; the survivor's existing primaries stay primary.
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}wpq_contact_identities i
			 SET i.contact_id = %d,
			     i.is_primary = IF( EXISTS (
			         SELECT 1 FROM (SELECT id FROM {$wpdb->prefix}wpq_contact_identities WHERE contact_id = %d AND is_primary = 1) sp
			     ) AND i.is_primary = 1, 0, i.is_primary )
			 WHERE i.contact_id = %d",
			$survivor_id,
			$survivor_id,
			$absorbed_id
		) );

		// Interactions: the dedupe key spans product/source/type only, so a
		// straight repoint cannot collide.
		$wpdb->update( "{$wpdb->prefix}wpq_contact_interactions", [ 'contact_id' => $survivor_id ], [ 'contact_id' => $absorbed_id ] );

		// Reproject every purpose the combined event history covers — the
		// projection applies the most restrictive event, which implements the
		// "most restrictive marketing state" merge rule.
		$purposes = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT purpose FROM {$wpdb->prefix}wpq_contact_consent_events WHERE contact_id = %d",
			$survivor_id
		) ) ?: [];
		foreach ( $purposes as $purpose ) {
			WPQ_Contact_Repository::reproject_preference( $survivor_id, (string) $purpose, 0 );
		}
		// The absorbed contact's stale projections are removed; the survivor's
		// rebuilt ones are now authoritative.
		$wpdb->delete( "{$wpdb->prefix}wpq_contact_preferences_current", [ 'contact_id' => $absorbed_id ] );

		// Fold in profile fields the survivor lacks; never overwrite.
		$updates = [ 'last_observed_at' => current_time( 'mysql', true ) ];
		foreach ( [ 'display_name', 'organisation', 'job_title', 'given_name', 'family_name' ] as $field ) {
			if ( '' === trim( (string) ( $survivor->{$field} ?? '' ) ) && '' !== trim( (string) ( $absorbed->{$field} ?? '' ) ) ) {
				$updates[ $field ] = (string) $absorbed->{$field};
			}
		}
		WPQ_Contact_Repository::update_contact( $survivor_id, $updates );

		WPQ_Contact_Repository::update_contact( $absorbed_id, [
			'status'                 => 'merged',
			'merged_into_contact_id' => $survivor_id,
		] );

		$wpdb->insert( "{$wpdb->prefix}wpq_contact_merge_log", [
			'survivor_id'    => $survivor_id,
			'absorbed_id'    => $absorbed_id,
			'reason'         => sanitize_textarea_field( $reason ),
			'actor'          => mb_substr( sanitize_text_field( $actor ), 0, 100 ),
			'before_summary' => wp_json_encode( $before ),
			'resolutions'    => wp_json_encode( [ 'profile_fields_folded' => array_keys( $updates ) ] ),
			'recovery'       => wp_json_encode( [
				'note'                => 'Absorbed contact retained with status=merged; repoint child rows back to absorbed_id and clear merged_into_contact_id to recover.',
				'absorbed_uuid'       => (string) $absorbed->uuid,
				'absorbed_display'    => (string) $absorbed->display_name,
			] ),
			'created_at'     => current_time( 'mysql', true ),
		] );

		self::record_audit( $survivor_id, 'merge_in', $actor, $before['absorbed'], [], $reason );
		self::record_audit( $absorbed_id, 'merged_away', $actor, [], [ 'into' => $survivor_id ], $reason );

		return true;
		} );

		if ( true !== $merged ) {
			return false;
		}

		// Fired only after the transaction has committed, so external listeners
		// never observe a merge that subsequently rolled back.
		do_action( 'alltime_contact_merged', $survivor_id, $absorbed_id, [ 'actor' => $actor ] );

		return true;
	}
}
