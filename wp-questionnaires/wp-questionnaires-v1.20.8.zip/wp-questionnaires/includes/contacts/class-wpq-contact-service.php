<?php
/**
 * Canonical contact resolution service — the single entry point for creating,
 * finding and updating canonical contacts. REST controllers call this; other
 * Alltime plugins will reach it through the versioned `alltime_contact_service`
 * filter (Phase 4). Nothing writes the canonical tables except the repository
 * this service drives.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) && ! defined( 'WPQ_TESTING' ) ) {
	exit;
}

class WPQ_Contact_Service implements WPQ_Contact_Service_Interface {

	private const OPTION_ENABLED = 'wpq_contact_master_enabled';

	/** Feature flag for the new-record linking layer. Default on; additive only. */
	public static function enabled(): bool {
		return get_option( self::OPTION_ENABLED, 'enabled' ) !== 'disabled';
	}

	public static function instance(): self {
		static $instance = null;
		if ( null === $instance ) {
			$instance = new self();
		}
		return $instance;
	}

	/**
	 * The contract version this implementation satisfies. Other Alltime
	 * plugins discover the service with:
	 *
	 *     $contacts = apply_filters( 'alltime_contact_service', null, '1.0' );
	 *
	 * A null return means no compatible provider is active.
	 */
	public const CONTRACT_VERSION = '1.0';

	/** Registers the versioned service accessor. Called once at plugin load. */
	public static function register_service_filter(): void {
		add_filter( 'alltime_contact_service', static function ( $service, string $version = '1.0' ) {
			if ( null !== $service ) {
				return $service; // Another provider already answered.
			}
			if ( ! self::enabled() ) {
				return null;
			}
			// Same major version and not newer than this implementation.
			$requested_major = (int) explode( '.', $version )[0];
			$our_major       = (int) explode( '.', self::CONTRACT_VERSION )[0];
			if ( $requested_major !== $our_major || version_compare( $version, self::CONTRACT_VERSION, '>' ) ) {
				return null;
			}
			return self::instance();
		}, 10, 2 );
	}

	/**
	 * Resolve the canonical contact for submitted details, creating a
	 * provisional contact when no safe match exists. Precedence: linked WP
	 * user → trusted UUID → verified identity → single unambiguous unverified
	 * email match → new provisional (ambiguity also queues a review row).
	 *
	 * @param array{name?: string, email?: string, telephone?: string, organisation?: string} $input
	 * @param array{source: string, source_type?: string, source_id?: int, wp_user_id?: int, trusted_uuid?: string, observed_at?: string} $context
	 * @return array{contact_id: int, created: bool, decision: string, reason: string}
	 */
	public function resolve_or_create( array $input, array $context ): array {
		$name         = sanitize_text_field( (string) ( $input['name'] ?? '' ) );
		$email        = sanitize_email( (string) ( $input['email'] ?? '' ) );
		$telephone    = sanitize_text_field( (string) ( $input['telephone'] ?? '' ) );
		$organisation = sanitize_text_field( (string) ( $input['organisation'] ?? '' ) );
		$observed_at  = (string) ( $context['observed_at'] ?? current_time( 'mysql', true ) );
		$source       = sanitize_key( (string) ( $context['source'] ?? 'unknown' ) );
		$source_type  = sanitize_key( (string) ( $context['source_type'] ?? '' ) );
		$source_id    = (int) ( $context['source_id'] ?? 0 );

		// 1. Authenticated WordPress user already linked to a contact. The
		//    caller supplies this from a server-side auth context only — never
		//    from request payload.
		$wp_user_id = (int) ( $context['wp_user_id'] ?? 0 );
		if ( $wp_user_id > 0 ) {
			$existing = WPQ_Contact_Repository::get_contact_by_wp_user( $wp_user_id );
			if ( $existing ) {
				$this->absorb_details( $existing, $name, $email, $telephone, $organisation, $source_type, $source_id, $observed_at );
				return [ 'contact_id' => (int) $existing->id, 'created' => false, 'decision' => 'link', 'reason' => 'wordpress_user' ];
			}
		}

		// 2. Trusted internal UUID — server-side integrations only; public
		//    request payloads must never reach this parameter.
		$trusted_uuid = (string) ( $context['trusted_uuid'] ?? '' );
		if ( '' !== $trusted_uuid ) {
			$existing = WPQ_Contact_Repository::get_contact_by_uuid( $trusted_uuid );
			if ( $existing ) {
				$existing = WPQ_Contact_Repository::resolve_merged( $existing );
				$this->absorb_details( $existing, $name, $email, $telephone, $organisation, $source_type, $source_id, $observed_at );
				return [ 'contact_id' => (int) $existing->id, 'created' => false, 'decision' => 'link', 'reason' => 'trusted_uuid' ];
			}
		}

		// 3/4. Identity match on the normalised email.
		$normalised_email = WPQ_Contact_Normaliser::normalise_email( $email );
		$candidates       = [];
		if ( '' !== $normalised_email ) {
			$candidates = WPQ_Contact_Repository::find_contacts_by_identity(
				'email',
				WPQ_Contact_Normaliser::identity_hash( 'email', $normalised_email )
			);
		}

		$verdict = WPQ_Contact_Matcher::decide_email_match( $email, $name, $candidates );

		if ( WPQ_Contact_Matcher::DECISION_LINK === $verdict['decision'] ) {
			$existing = WPQ_Contact_Repository::get_contact( $verdict['contact_id'] );
			if ( $existing ) {
				$this->absorb_details( $existing, $name, $email, $telephone, $organisation, $source_type, $source_id, $observed_at );
				return [ 'contact_id' => (int) $existing->id, 'created' => false, 'decision' => 'link', 'reason' => $verdict['reason'] ];
			}
		}

		// 5. New provisional contact (also the landing place for ambiguity).
		$split      = WPQ_Contact_Normaliser::split_name( $name );
		$contact_id = WPQ_Contact_Repository::insert_contact( [
			'given_name'     => $split['given'],
			'family_name'    => $split['family'],
			'display_name'   => $name,
			'organisation'   => $organisation,
			'status'         => 'provisional',
			'created_source' => $source,
			'observed_at'    => $observed_at,
		] );
		if ( $contact_id <= 0 ) {
			return [ 'contact_id' => 0, 'created' => false, 'decision' => 'error', 'reason' => 'insert_failed' ];
		}

		$this->attach_identities( $contact_id, $email, $telephone, $source_type, $source_id, $observed_at );
		if ( '' !== $organisation ) {
			WPQ_Contact_Repository::record_organisation( $contact_id, $organisation, $source );
		}

		if ( WPQ_Contact_Matcher::DECISION_REVIEW === $verdict['decision'] && '' !== $source_type && $source_id > 0 ) {
			WPQ_Contact_Repository::queue_review(
				$source_type,
				$source_id,
				array_merge( [ $contact_id ], array_map( static fn( object $c ): int => (int) $c->id, $candidates ) ),
				$verdict['reason'],
				[ 'email' => $normalised_email, 'submitted_name' => $name ]
			);
		}

		do_action( 'alltime_contact_created', $contact_id, [ 'source' => $source, 'decision' => $verdict['decision'] ] );

		return [ 'contact_id' => $contact_id, 'created' => true, 'decision' => $verdict['decision'], 'reason' => $verdict['reason'] ];
	}

	public function get_by_id( int $contact_id ): ?object {
		$contact = WPQ_Contact_Repository::get_contact( $contact_id );
		return $contact ? WPQ_Contact_Repository::resolve_merged( $contact ) : null;
	}

	public function get_by_uuid( string $uuid ): ?object {
		$contact = WPQ_Contact_Repository::get_contact_by_uuid( $uuid );
		return $contact ? WPQ_Contact_Repository::resolve_merged( $contact ) : null;
	}

	public function get_for_wordpress_user( int $user_id ): ?object {
		return WPQ_Contact_Repository::get_contact_by_wp_user( $user_id );
	}

	public function link_wordpress_user( int $contact_id, int $user_id ): bool {
		if ( $contact_id <= 0 || $user_id <= 0 ) {
			return false;
		}
		// One active canonical contact per WP user.
		$existing = WPQ_Contact_Repository::get_contact_by_wp_user( $user_id );
		if ( $existing && (int) $existing->id !== $contact_id ) {
			return false;
		}

		return WPQ_Contact_Repository::update_contact( $contact_id, [ 'wp_user_id' => $user_id ] );
	}

	/** @param array<string, mixed> $input */
	public function record_interaction( int $contact_id, array $input ): int {
		$input['contact_id'] = $contact_id;
		$interaction_id      = WPQ_Contact_Repository::record_interaction( $input );
		if ( $interaction_id > 0 ) {
			do_action(
				'alltime_contact_interaction_recorded',
				$interaction_id,
				$contact_id,
				sanitize_key( (string) ( $input['product'] ?? 'wp-questionnaires' ) )
			);
		}
		return $interaction_id;
	}

	/** @param array<string, mixed> $input */
	public function record_consent_event( int $contact_id, array $input ): int {
		$input['contact_id'] = $contact_id;
		$event_id            = WPQ_Contact_Repository::record_consent_event( $input );
		if ( $event_id > 0 ) {
			do_action(
				'alltime_contact_preference_changed',
				$contact_id,
				sanitize_key( (string) ( $input['purpose'] ?? '' ) ),
				(string) ( $input['event'] ?? '' )
			);
		}
		return $event_id;
	}

	// ------------------------------------------------------------------ //
	// Internals
	// ------------------------------------------------------------------ //

	/**
	 * Fold newly observed details into a linked contact under the update
	 * rules: blanks never erase, unverified input never overwrites a verified
	 * contact's conflicting values, and every observation moves last_observed_at.
	 */
	private function absorb_details( object $contact, string $name, string $email, string $telephone, string $organisation, string $source_type, int $source_id, string $observed_at ): void {
		$contact_id = (int) $contact->id;
		$verified   = ! empty( $contact->verified_at );
		$updates    = [ 'last_observed_at' => $observed_at ];

		if ( WPQ_Contact_Matcher::may_update_field( (string) ( $contact->display_name ?? '' ), $name, $verified ) ) {
			$split                  = WPQ_Contact_Normaliser::split_name( $name );
			$updates['display_name'] = $name;
			$updates['given_name']   = $split['given'];
			$updates['family_name']  = $split['family'];
		}
		if ( '' !== trim( $organisation ) && '' === trim( (string) ( $contact->organisation ?? '' ) ) ) {
			$updates['organisation'] = $organisation;
		}

		WPQ_Contact_Repository::update_contact( $contact_id, $updates );
		$this->attach_identities( $contact_id, $email, $telephone, $source_type, $source_id, $observed_at );
		if ( '' !== trim( $organisation ) ) {
			WPQ_Contact_Repository::record_organisation( $contact_id, $organisation, $source_type ?: 'observation' );
		}
	}

	/**
	 * Attach email/telephone identities. An identity the contact already holds
	 * is touched; a new one is added unverified (and made primary only when the
	 * contact has no primary of that type — a new address never displaces an
	 * existing primary).
	 */
	private function attach_identities( int $contact_id, string $email, string $telephone, string $source_type, int $source_id, string $observed_at ): void {
		foreach ( [ 'email' => $email, 'telephone' => $telephone ] as $type => $raw ) {
			$raw = trim( $raw );
			if ( '' === $raw ) {
				continue;
			}
			$normalised = 'email' === $type
				? WPQ_Contact_Normaliser::normalise_email( $raw )
				: WPQ_Contact_Normaliser::normalise_telephone( $raw );
			if ( '' === $normalised ) {
				continue;
			}
			$hash     = WPQ_Contact_Normaliser::identity_hash( $type, $normalised );
			$existing = WPQ_Contact_Repository::get_contact_identity( $contact_id, $type, $hash );
			if ( $existing ) {
				WPQ_Contact_Repository::touch_identity( (int) $existing->id, $observed_at );
				continue;
			}
			WPQ_Contact_Repository::insert_identity( [
				'contact_id'       => $contact_id,
				'type'             => $type,
				'value_original'   => $raw,
				'value_normalised' => $normalised,
				'value_hash'       => $hash,
				'is_primary'       => ! WPQ_Contact_Repository::contact_has_primary_identity( $contact_id, $type ),
				'source_type'      => $source_type,
				'source_id'        => $source_id,
				'observed_at'      => $observed_at,
			] );
		}
	}
}
