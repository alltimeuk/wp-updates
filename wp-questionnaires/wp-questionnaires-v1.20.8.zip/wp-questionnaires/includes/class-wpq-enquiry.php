<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Enquiry forms: admin-composed contact forms (a lighter sibling of the
 * questionnaire composer) that register contacts through the public site.
 *
 * A form is a name, description, status, mail settings, and an ordered list
 * of custom fields (text / textarea / select / checkbox), stored as JSON.
 * Every enquiry always captures the standard contact block (name, email,
 * company, phone, consent) plus the form's custom fields.
 *
 * This class holds the pure logic — field-definition sanitisation and
 * response validation — so both the admin composer and the public endpoint
 * share one contract. Persistence lives in WPQ_Database; transport in
 * WPQ_REST_API; presentation in the shortcode and admin views.
 */
class WPQ_Enquiry {

	public const FIELD_TYPES = [ 'text', 'textarea', 'select', 'checkbox' ];

	public const MAX_FIELDS        = 30;
	public const MAX_OPTIONS       = 30;
	public const MAX_LABEL_CHARS   = 200;
	public const MAX_TEXT_CHARS    = 500;
	public const MAX_TEXTAREA_CHARS = 5000;

	// ------------------------------------------------------------------ //
	// Field definitions (admin composer)
	// ------------------------------------------------------------------ //

	/**
	 * Sanitise a submitted field-definition list into the canonical stored
	 * shape. Unknown types, duplicate keys, and empty labels are dropped;
	 * option lists apply to select/checkbox only.
	 *
	 * @return array<int, array{key: string, label: string, type: string, required: bool, options: array<int, string>}>
	 */
	public static function sanitise_field_definitions( mixed $fields ): array {
		if ( ! is_array( $fields ) ) {
			return [];
		}

		$clean = [];
		$seen  = [];
		foreach ( array_slice( array_values( $fields ), 0, self::MAX_FIELDS ) as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$label = sanitize_text_field( (string) ( $field['label'] ?? '' ) );
			$label = mb_substr( $label, 0, self::MAX_LABEL_CHARS );
			if ( '' === $label ) {
				continue;
			}

			$type = (string) ( $field['type'] ?? 'text' );
			if ( ! in_array( $type, self::FIELD_TYPES, true ) ) {
				$type = 'text';
			}

			$key = sanitize_key( (string) ( $field['key'] ?? '' ) );
			if ( '' === $key ) {
				$key = sanitize_key( str_replace( ' ', '_', strtolower( $label ) ) );
			}
			$key = substr( $key, 0, 50 );
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;

			$options = [];
			if ( in_array( $type, [ 'select', 'checkbox' ], true ) ) {
				foreach ( array_slice( (array) ( $field['options'] ?? [] ), 0, self::MAX_OPTIONS ) as $option ) {
					if ( ! is_scalar( $option ) ) {
						continue;
					}
					$option = mb_substr( sanitize_text_field( (string) $option ), 0, self::MAX_LABEL_CHARS );
					if ( '' !== $option && ! in_array( $option, $options, true ) ) {
						$options[] = $option;
					}
				}
				if ( empty( $options ) ) {
					continue; // A choice field without choices cannot be answered.
				}
			}

			$clean[] = [
				'key'      => $key,
				'label'    => $label,
				'type'     => $type,
				'required' => ! empty( $field['required'] ),
				'options'  => $options,
			];
		}

		return $clean;
	}

	/** @return array<int, array{key: string, label: string, type: string, required: bool, options: array<int, string>}> */
	public static function decode_field_definitions( ?string $fields_json ): array {
		$decoded = json_decode( (string) $fields_json, true );
		return self::sanitise_field_definitions( is_array( $decoded ) ? $decoded : [] );
	}

	// ------------------------------------------------------------------ //
	// Response validation (public endpoint)
	// ------------------------------------------------------------------ //

	/**
	 * Validate a public submission's custom-field responses against the form
	 * definition. Select answers must be one of the defined options; checkbox
	 * answers a subset of them. Unknown keys are discarded, never stored.
	 *
	 * @param array<int, array{key: string, label: string, type: string, required: bool, options: array<int, string>}> $definitions
	 * @return array{valid: true, values: array<string, mixed>}|array{valid: false, message: string}
	 */
	public static function validate_responses( array $definitions, mixed $responses ): array {
		$responses = is_array( $responses ) ? $responses : [];
		$values    = [];

		foreach ( $definitions as $field ) {
			$key   = $field['key'];
			$value = $responses[ $key ] ?? null;

			switch ( $field['type'] ) {
				case 'checkbox':
					$selected = [];
					foreach ( (array) ( is_array( $value ) ? $value : [] ) as $item ) {
						if ( is_scalar( $item ) && in_array( (string) $item, $field['options'], true ) ) {
							$selected[] = (string) $item;
						}
					}
					if ( $field['required'] && empty( $selected ) ) {
						return [ 'valid' => false, 'message' => '"' . $field['label'] . '" is required.' ];
					}
					if ( ! empty( $selected ) ) {
						$values[ $key ] = array_values( array_unique( $selected ) );
					}
					break;

				case 'select':
					$value = is_scalar( $value ) ? (string) $value : '';
					if ( '' !== $value && ! in_array( $value, $field['options'], true ) ) {
						return [ 'valid' => false, 'message' => '"' . $field['label'] . '" has an invalid selection.' ];
					}
					if ( $field['required'] && '' === $value ) {
						return [ 'valid' => false, 'message' => '"' . $field['label'] . '" is required.' ];
					}
					if ( '' !== $value ) {
						$values[ $key ] = $value;
					}
					break;

				case 'textarea':
					$value = is_scalar( $value ) ? sanitize_textarea_field( (string) $value ) : '';
					$value = mb_substr( $value, 0, self::MAX_TEXTAREA_CHARS );
					if ( $field['required'] && '' === trim( $value ) ) {
						return [ 'valid' => false, 'message' => '"' . $field['label'] . '" is required.' ];
					}
					if ( '' !== trim( $value ) ) {
						$values[ $key ] = $value;
					}
					break;

				default: // text
					$value = is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '';
					$value = mb_substr( $value, 0, self::MAX_TEXT_CHARS );
					if ( $field['required'] && '' === trim( $value ) ) {
						return [ 'valid' => false, 'message' => '"' . $field['label'] . '" is required.' ];
					}
					if ( '' !== trim( $value ) ) {
						$values[ $key ] = $value;
					}
			}
		}

		return [ 'valid' => true, 'values' => $values ];
	}

	// ------------------------------------------------------------------ //
	// Mail gating
	// ------------------------------------------------------------------ //

	/** Global mail switch combined with the form's own inherit/enabled/disabled setting. */
	public static function mail_allowed_for_form( ?object $form ): bool {
		if ( class_exists( 'WPQ_Mailer' ) && ! WPQ_Mailer::globally_enabled() ) {
			return false;
		}
		return 'disabled' !== (string) ( $form->mail_enabled ?? 'inherit' );
	}

	/** The admin recipient for enquiry notifications: the form's own, else the site admin. */
	public static function notify_recipient( ?object $form ): string {
		$email = sanitize_email( (string) ( $form->notify_email ?? '' ) );
		if ( '' !== $email && is_email( $email ) ) {
			return $email;
		}
		return sanitize_email( (string) get_option( 'admin_email', '' ) );
	}

	/** A short reference like ENQ-20260810-A1B2, unique enough for humans and support threads. */
	public static function generate_ref(): string {
		return 'ENQ-' . gmdate( 'Ymd' ) . '-' . strtoupper( substr( bin2hex( random_bytes( 3 ) ), 0, 4 ) );
	}

	// ------------------------------------------------------------------ //
	// Emails
	// ------------------------------------------------------------------ //

	/**
	 * @param array<int, array{key: string, label: string, type: string, required: bool, options: array<int, string>}> $definitions
	 * @param array<string, mixed> $values
	 */
	public static function build_notification_body( object $form, object $enquiry, array $definitions, array $values ): string {
		$lines   = [];
		$lines[] = 'New enquiry via "' . (string) $form->name . '" (' . (string) $enquiry->ref . ')';
		$lines[] = '';
		$lines[] = 'Name:    ' . (string) $enquiry->contact_name;
		$lines[] = 'Email:   ' . (string) $enquiry->contact_email;
		if ( '' !== (string) ( $enquiry->contact_company ?? '' ) ) {
			$lines[] = 'Company: ' . (string) $enquiry->contact_company;
		}
		if ( '' !== (string) ( $enquiry->contact_phone ?? '' ) ) {
			$lines[] = 'Phone:   ' . (string) $enquiry->contact_phone;
		}

		foreach ( $definitions as $field ) {
			if ( ! array_key_exists( $field['key'], $values ) ) {
				continue;
			}
			$value   = $values[ $field['key'] ];
			$lines[] = '';
			$lines[] = $field['label'] . ':';
			$lines[] = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
		}

		return implode( "\n", $lines ) . "\n";
	}

	public static function build_acknowledgement_body( object $form, object $enquiry ): string {
		$name = trim( (string) ( $enquiry->contact_name ?? '' ) );
		return ( '' !== $name ? 'Hello ' . $name . ',' : 'Hello,' ) . "\n\n"
			. 'Thank you for your enquiry (' . (string) $enquiry->ref . "). We have received it and will be in touch.\n";
	}
}
