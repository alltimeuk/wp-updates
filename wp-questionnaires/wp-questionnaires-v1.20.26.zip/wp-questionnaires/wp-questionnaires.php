<?php
/**
 * Plugin Name: WP Questionnaires
 * Plugin URI:  https://alltimetech.co.uk
 * Description: Assessment and lead-generation platform with a canonical contact master. Publishes scored questionnaires with save & resume, captures leads and enquiries, generates AI-driven questionnaire reports and remediation plans, delivers email via wp_mail/Gmail/SES, and sells branded PDF reports via Stripe - with HaloPSA sync throughout.
 * Version:     1.20.26
 * Author:      Simon Jackson @ Alltime Technologies Ltd
 * Author URI:  https://alltimetech.co.uk
 * License:     Proprietary
 * Text Domain: wp-questionnaires
 * Requires PHP: 8.1
 * Requires at least: 6.4
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPQ_VERSION',          '1.20.26' );
define( 'WPQ_DB_VERSION',       '1.43.0' );
define( 'WPQ_PLUGIN_FILE',      __FILE__ );
define( 'WPQ_PLUGIN_DIR',       plugin_dir_path( __FILE__ ) );
define( 'WPQ_PLUGIN_URL',       plugin_dir_url( __FILE__ ) );
define( 'WPQ_PLUGIN_BASENAME',  plugin_basename( __FILE__ ) );
define( 'WPQ_REST_NAMESPACE',   'wpq/v1' );

// Feature gate - set true once Stripe checkout endpoints are deployed.
define( 'WPQ_CHECKOUT_ENABLED_CONFIGURED', defined( 'WPQ_CHECKOUT_ENABLED' ) );

if ( ! defined( 'WPQ_CHECKOUT_ENABLED' ) ) {
	define( 'WPQ_CHECKOUT_ENABLED', false );
}

define( 'WPQ_REMEDIATION_PLAN_ENABLED_CONFIGURED', defined( 'WPQ_REMEDIATION_PLAN_ENABLED' ) );
if ( ! defined( 'WPQ_REMEDIATION_PLAN_ENABLED' ) ) {
	define( 'WPQ_REMEDIATION_PLAN_ENABLED', true );
}

define( 'WPQ_QUESTIONNAIRE_REPORT_ENABLED_CONFIGURED', defined( 'WPQ_QUESTIONNAIRE_REPORT_ENABLED' ) );
if ( ! defined( 'WPQ_QUESTIONNAIRE_REPORT_ENABLED' ) ) {
	define( 'WPQ_QUESTIONNAIRE_REPORT_ENABLED', true );
}

// Set true only when REMOTE_ADDR is always a trusted reverse proxy that
// sanitises inbound X-Forwarded-For before forwarding to PHP.
if ( ! defined( 'WPQ_TRUST_PROXY_IP' ) ) {
	define( 'WPQ_TRUST_PROXY_IP', false );
}

$autoload = WPQ_PLUGIN_DIR . 'vendor/autoload.php';
if ( is_readable( $autoload ) ) {
	require_once $autoload;
}

require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-activator.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-deactivator.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-database.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-secrets.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-feature-flags.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-claude.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-stripe.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-report-renderer.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-remediation-plan.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-claude-client.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-questionnaire-report-context.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-questionnaire-report-analysis.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-docx-template-renderer.php';
require_once WPQ_PLUGIN_DIR . 'includes/interface-wpq-docx-pdf-converter.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-libreoffice-pdf-converter.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-questionnaire-report-storage.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-questionnaire-report-delivery.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-framework-importer.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-framework-readiness.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-framework-radar.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-session-resume.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-mailer.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-turnstile.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-remediation-delivery.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-enquiry.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/interface-wpq-contact-service.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/class-wpq-contact-normaliser.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/class-wpq-contact-matcher.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/class-wpq-contact-repository.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/class-wpq-contact-service.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/class-wpq-contact-migration.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/class-wpq-contact-admin.php';
require_once WPQ_PLUGIN_DIR . 'includes/contacts/class-wpq-customer-platform-bridge.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-cron-kicker.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-questionnaire-report.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-scoring.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-questionnaire-style-generator.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-library-importer.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-seeder.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-import-export.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-plugin.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-updater.php';

register_activation_hook( WPQ_PLUGIN_FILE,   [ 'WPQ_Activator',   'activate'   ] );
register_deactivation_hook( WPQ_PLUGIN_FILE, [ 'WPQ_Deactivator', 'deactivate' ] );
add_action( 'admin_init', [ 'WPQ_Activator', 'ensure_schema_current' ] );
add_action( WPQ_Questionnaire_Report::CRON_HOOK, [ 'WPQ_Questionnaire_Report', 'process' ], 10, 2 );
add_action( WPQ_Questionnaire_Report::RETRY_CRON_HOOK, [ 'WPQ_Questionnaire_Report', 'process_pdf_retry' ], 10, 2 );
add_action( WPQ_Questionnaire_Report::RERENDER_CRON_HOOK, [ 'WPQ_Questionnaire_Report', 'process_rerender' ], 10, 2 );
add_action( WPQ_Contact_Migration::CRON_HOOK, [ 'WPQ_Contact_Migration', 'run_batch' ] );
add_action( 'wpq_retention_daily', [ 'WPQ_Database', 'run_retention_automation' ] );

// Keep the daily retention event scheduled in lockstep with the opt-in
// toggle: scheduled while enabled, cleanly unscheduled when switched off so
// no orphaned cron entry lingers.
add_action( 'init', static function (): void {
	$enabled   = 'yes' === get_option( 'wpq_retention_automation_enabled', 'no' );
	$scheduled = (bool) wp_next_scheduled( 'wpq_retention_daily' );
	if ( $enabled && ! $scheduled ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wpq_retention_daily' );
	} elseif ( ! $enabled && $scheduled ) {
		wp_clear_scheduled_hook( 'wpq_retention_daily' );
	}
} );
WPQ_Contact_Service::register_service_filter();
// Overdue-event sweep for hosts with DISABLE_WP_CRON and no system cron.
WPQ_Cron_Kicker::register();

// Shared-component bridge: when wp-reconnaissance is active, publish this
// plugin's canonical contact service on its Alltime\CustomerPlatform
// discovery hook too, so both products resolve one canonical contact.
// Deferred to plugins_loaded so recon's autoloader (and therefore the
// contract interfaces) exist before the interface_exists() probe runs.
add_action( 'plugins_loaded', [ 'WPQ_Customer_Platform_Bridge', 'register' ], 0 );

// Plugin updater - runs in admin and WP-Cron contexts (where update checks fire).
if ( is_admin() || wp_doing_cron() ) {
	add_action( 'plugins_loaded', static function (): void {
		new WPQ_Updater();
	} );
}

function wpq(): WPQ_Plugin {
	return WPQ_Plugin::instance();
}

wpq();
