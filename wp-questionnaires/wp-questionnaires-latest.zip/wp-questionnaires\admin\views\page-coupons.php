<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var array<int, object> $coupons
 * @var array<int, object> $questionnaires
 * @var array<int, object> $products
 */
$coupons = $coupons ?? [];
/** @phpstan-ignore-next-line */
$questionnaires = $questionnaires ?? [];
/** @phpstan-ignore-next-line */
$products = $products ?? [];

$qs_with_product = array_filter( $questionnaires, fn( $q ) => ! empty( $q->stripe_product_id ) );

function wpq_format_discount( object $c ): string {
	if ( $c->discount_type === 'percent' ) {
		return (int) $c->percent_off . '%';
	}
	$symbol = match ( strtoupper( (string) $c->currency ) ) {
		'USD' => '$', 'EUR' => '€', 'AUD' => 'A$', 'CAD' => 'C$', default => '£',
	};
	return $symbol . number_format( (int) $c->amount_off / 100, 2 );
}

function wpq_format_duration( object $c ): string {
	return match ( $c->duration ) {
		'once'       => 'Once',
		'forever'    => 'Forever',
		'repeating'  => (int) $c->duration_in_months . ' months',
		default      => ucfirst( $c->duration ),
	};
}

function wpq_format_scope( object $c ): string {
	if ( $c->scope === 'questionnaire' ) {
		$label = $c->questionnaire_ref ? '[' . $c->questionnaire_ref . '] ' . $c->questionnaire_name : $c->questionnaire_name ?? '—';
		return 'Questionnaire: ' . $label;
	}
	if ( $c->scope === 'catalogue_item' ) {
		return 'Catalogue: ' . ( $c->product_name ?? '—' );
	}
	return 'All products';
}
?>
<div class="wrap wpq-admin-wrap">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <h1 style="margin:0;display:flex;align-items:center;gap:16px;">
      Coupons &amp; Promo Codes
      <button type="button" id="wpq-add-coupon" class="page-title-action">Create Coupon</button>
    </h1>
    <div style="display:flex;align-items:center;gap:6px;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="button" title="Import coupons">&#8593; Import</a>
      <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=coupons' ), 'wpq_export_coupons' ) ); ?>" class="button" title="Export all coupons">&#8595; Export all</a>
    </div>
  </div>
  <p class="description">Stripe coupons and promotion codes. Coupons are created in your Stripe account and can optionally be restricted to a specific questionnaire or pricing catalogue item.</p>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;"
       data-export-type="coupons"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_coupons' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">— Bulk action —</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
    <span style="flex:1;"></span>
    <input type="search" class="wpq-table-filter" style="height:30px;width:220px;" placeholder="Filter coupons…" aria-label="Filter coupons">
    <span class="wpq-table-filter-count description"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" style="margin-top:8px;" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th style="width:130px;">Promo Code</th>
        <th>Name</th>
        <th style="width:80px;">Discount</th>
        <th style="width:100px;">Duration</th>
        <th>Applies To</th>
        <th style="width:120px;">Expires</th>
        <th style="width:80px;">Status</th>
        <th style="width:70px;" data-no-sort></th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $coupons ) ) : ?>
        <tr><td colspan="9">No coupons yet. Click <strong>Create Coupon</strong> to add one.</td></tr>
      <?php else : ?>
        <?php foreach ( $coupons as $c ) : ?>
          <?php if ( $c->status === 'deleted' ) continue; ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo (int) $c->id; ?>"></td>
            <td>
              <?php if ( $c->promo_code ) : ?>
                <code style="font-size:12px;"><?php echo esc_html( $c->promo_code ); ?></code>
              <?php else : ?>
                <span class="description">No code</span>
              <?php endif; ?>
            </td>
            <td>
              <?php echo esc_html( $c->name ); ?>
              <br><code style="font-size:11px;color:#666;"><?php echo esc_html( $c->stripe_coupon_id ); ?></code>
            </td>
            <td><?php echo esc_html( wpq_format_discount( $c ) ); ?></td>
            <td><?php echo esc_html( wpq_format_duration( $c ) ); ?></td>
            <td><?php echo esc_html( wpq_format_scope( $c ) ); ?></td>
            <td>
              <?php if ( $c->redeem_by ) : ?>
                <?php echo esc_html( wp_date( 'd M Y', strtotime( $c->redeem_by ) ) ); ?>
              <?php else : ?>
                <span class="description">No expiry</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ( $c->status === 'active' ) : ?>
                <span class="wpq-status-active">&#9679; Active</span>
              <?php else : ?>
                <span class="wpq-status-inactive">&#9679; Deleted</span>
              <?php endif; ?>
            </td>
            <td>
              <button type="button" class="button button-small wpq-delete-coupon"
                data-id="<?php echo (int) $c->id; ?>"
                data-name="<?php echo esc_attr( $c->name ); ?>">Delete</button>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- ================================================================ -->
  <!-- Inline create form                                                -->
  <!-- ================================================================ -->
  <div id="wpq-coupon-form" class="wpq-card wpq-hidden" style="margin-top:24px;max-width:800px;">
    <h2 style="margin-top:0;">Create Coupon</h2>

    <table class="form-table" style="margin-top:0;">
      <tr>
        <th style="width:200px;"><label for="wpq-cf-name">Name <span style="color:#d63638;">*</span></label></th>
        <td>
          <input type="text" id="wpq-cf-name" class="regular-text" placeholder="e.g. Summer 2026 Discount">
          <p class="description">Internal label — shown in your Stripe dashboard.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-code">Promo Code</label></th>
        <td>
          <input type="text" id="wpq-cf-code" class="regular-text" placeholder="e.g. SUMMER25" style="text-transform:uppercase;" maxlength="50">
          <p class="description">Customer-facing code they type at checkout. Leave blank for a coupon without a public code (applied programmatically). Letters, numbers, hyphens and underscores only.</p>
        </td>
      </tr>
      <tr>
        <th>Discount type</th>
        <td>
          <label><input type="radio" name="wpq_cf_discount_type" value="percent" checked> Percent off</label>
          &nbsp;&nbsp;
          <label><input type="radio" name="wpq_cf_discount_type" value="fixed"> Fixed amount off</label>
        </td>
      </tr>
      <tr id="wpq-cf-row-percent">
        <th><label for="wpq-cf-percent">Percent off <span style="color:#d63638;">*</span></label></th>
        <td>
          <input type="number" id="wpq-cf-percent" class="small-text" min="1" max="100" value="10"> %
        </td>
      </tr>
      <tr id="wpq-cf-row-fixed" class="wpq-hidden">
        <th><label for="wpq-cf-amount">Amount off <span style="color:#d63638;">*</span></label></th>
        <td>
          <input type="number" id="wpq-cf-amount" class="small-text" min="0.01" step="0.01" value="0.00">
          <select id="wpq-cf-currency" style="margin-left:8px;">
            <option value="GBP">GBP (£)</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="AUD">AUD</option>
            <option value="CAD">CAD</option>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-duration">Duration</label></th>
        <td>
          <select id="wpq-cf-duration">
            <option value="once">Once — applied once per customer</option>
            <option value="repeating">Repeating — applied for N months (subscriptions)</option>
            <option value="forever">Forever — applies every payment</option>
          </select>
        </td>
      </tr>
      <tr id="wpq-cf-row-months" class="wpq-hidden">
        <th><label for="wpq-cf-months">Duration (months)</label></th>
        <td><input type="number" id="wpq-cf-months" class="small-text" min="1" value="3"></td>
      </tr>
      <tr>
        <th><label for="wpq-cf-max">Max redemptions</label></th>
        <td>
          <input type="number" id="wpq-cf-max" class="small-text" min="1" placeholder="Unlimited">
          <p class="description">Leave blank for unlimited uses.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-expiry">Expiry date</label></th>
        <td>
          <input type="date" id="wpq-cf-expiry">
          <p class="description">Leave blank for no expiry.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-cf-scope">Applies to</label></th>
        <td>
          <select id="wpq-cf-scope">
            <option value="all">All products</option>
            <option value="questionnaire">Specific questionnaire (one Stripe product)</option>
            <option value="catalogue_item">Specific pricing (one Stripe price)</option>
          </select>
        </td>
      </tr>
      <tr id="wpq-cf-row-questionnaire" class="wpq-hidden">
        <th><label for="wpq-cf-questionnaire">Questionnaire</label></th>
        <td>
          <select id="wpq-cf-questionnaire">
            <option value="">— Select questionnaire —</option>
            <?php foreach ( $qs_with_product as $q ) : ?>
              <option value="<?php echo (int) $q->id; ?>">[<?php echo esc_html( $q->ref ); ?>] <?php echo esc_html( $q->name ); ?> <small>(<?php echo esc_html( $q->stripe_product_id ); ?>)</small></option>
            <?php endforeach; ?>
          </select>
          <?php if ( empty( $qs_with_product ) ) : ?>
            <p class="description" style="color:#a00;">No questionnaires have a Stripe Product ID set. Edit a questionnaire in the Library to add one.</p>
          <?php else : ?>
            <p class="description">Stripe will restrict this coupon to the selected questionnaire's product. Only questionnaires with a Stripe Product ID are shown.</p>
          <?php endif; ?>
        </td>
      </tr>
      <tr id="wpq-cf-row-product" class="wpq-hidden">
        <th><label for="wpq-cf-product">Catalogue item</label></th>
        <td>
          <select id="wpq-cf-product">
            <option value="">— Select pricing option —</option>
            <?php foreach ( $products as $p ) : ?>
              <option value="<?php echo (int) $p->id; ?>"><?php echo esc_html( $p->name ); ?><?php if ( $p->stripe_price_id ) echo ' (' . esc_html( $p->stripe_price_id ) . ')'; ?></option>
            <?php endforeach; ?>
          </select>
          <p class="description">The coupon association is stored locally. Stripe does not support restricting coupons by price — apply this coupon at checkout for the selected item.</p>
        </td>
      </tr>
    </table>

    <p>
      <button type="button" id="wpq-save-coupon" class="button button-primary">Create in Stripe</button>
      <button type="button" id="wpq-cancel-coupon" class="button" style="margin-left:8px;">Cancel</button>
      <span id="wpq-cf-status" style="margin-left:12px;" class="wpq-hidden"></span>
    </p>
  </div>
</div>
