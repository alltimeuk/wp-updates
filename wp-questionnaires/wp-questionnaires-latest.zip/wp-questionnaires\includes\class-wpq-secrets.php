<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Secrets {

	public static function get_stripe_publishable_key(): string {
		return self::get_stripe_publishable_key_details()['value'];
	}

	public static function get_stripe_secret_key(): string {
		return self::get_stripe_secret_key_details()['value'];
	}

	public static function get_stripe_webhook_secret(): string {
		return self::get_stripe_webhook_secret_details()['value'];
	}

	public static function get_stripe_publishable_key_details(): array {
		return self::resolve_secret(
			'WPQ_STRIPE_PUBLISHABLE_KEY',
			'STRIPE_PUBLISHABLE_KEY',
			'wpq_stripe_publishable_key',
			'/^pk_(test|live)_[A-Za-z0-9_]+$/'
		);
	}

	public static function get_stripe_secret_key_details(): array {
		return self::resolve_secret(
			'WPQ_STRIPE_SECRET_KEY',
			'STRIPE_SECRET_KEY',
			'wpq_stripe_secret_key',
			'/^sk_(test|live)_[A-Za-z0-9_]+$/'
		);
	}

	public static function get_stripe_webhook_secret_details(): array {
		return self::resolve_secret(
			'WPQ_STRIPE_WEBHOOK_SECRET',
			'STRIPE_WEBHOOK_SECRET',
			'wpq_stripe_webhook_secret',
			'/^whsec_[A-Za-z0-9_]+$/'
		);
	}

	private static function resolve_secret( string $constant, string $environment_key, string $option_key, string $pattern ): array {
		$value  = '';
		$source = 'none';

		if ( defined( $constant ) && constant( $constant ) ) {
			$value  = (string) constant( $constant );
			$source = 'constant';
		} else {
			$environment_value = getenv( $environment_key );
			if ( is_string( $environment_value ) && $environment_value !== '' ) {
				$value  = $environment_value;
				$source = 'environment';
			} else {
				$option_value = (string) get_option( $option_key, '' );
				if ( $option_value !== '' ) {
					$value  = $option_value;
					$source = 'option';
				}
			}
		}

		return [
			'value'   => $value,
			'source'  => $source,
			'present' => $value !== '',
			'valid'   => $value !== '' && preg_match( $pattern, $value ) === 1,
		];
	}
}
