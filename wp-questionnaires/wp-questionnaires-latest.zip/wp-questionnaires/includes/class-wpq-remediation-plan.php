<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Remediation_Plan {

	private const API_URL = 'https://api.anthropic.com/v1/messages';
	private const API_VERSION = '2023-06-01';

	public static function is_configured(): bool {
		$details = self::get_api_key_details();
		return ! empty( $details['present'] );
	}

	public static function get_api_key_details(): array {
		$value  = '';
		$source = 'none';

		if ( defined( 'WPQ_CLAUDE_API_KEY' ) && constant( 'WPQ_CLAUDE_API_KEY' ) ) {
			$value  = (string) constant( 'WPQ_CLAUDE_API_KEY' );
			$source = 'constant';
		} else {
			$environment_value = getenv( 'CLAUDE_API_KEY' );
			if ( ! is_string( $environment_value ) || $environment_value === '' ) {
				$environment_value = getenv( 'ANTHROPIC_API_KEY' );
			}
			if ( is_string( $environment_value ) && $environment_value !== '' ) {
				$value  = $environment_value;
				$source = 'environment';
			} else {
				$option_value = (string) get_option( 'wpq_claude_api_key', '' );
				if ( $option_value !== '' ) {
					$value  = $option_value;
					$source = 'option';
				}
			}
		}

		return [
			'value'   => $value,
			'source'  => $source,
			'present' => $value !== '',
			'valid'   => $value !== '' && preg_match( '/^sk-ant-/', $value ) === 1,
		];
	}

	public static function generate_for_submission( object $submission, int $days ): array {
		if ( ! in_array( $days, [ 30, 60, 90 ], true ) ) {
			$days = 30;
		}

		$context = self::build_context( $submission, $days );
		$tasks   = self::request_tasks( $context, $days );
		$binary  = self::build_workbook( $context, $tasks, $days );
		$ref     = preg_replace( '/[^A-Za-z0-9_-]+/', '-', (string) ( $submission->ref ?? 'submission-' . (int) $submission->id ) );

		return [
			'filename' => 'wpq-remediation-plan-' . trim( (string) $ref, '-' ) . '.xlsx',
			'binary'   => $binary,
		];
	}

	private static function build_context( object $submission, int $days ): array {
		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			throw new RuntimeException( 'Questionnaire not found.' );
		}

		$structure = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		$answers   = json_decode( (string) ( $submission->answers_json ?? '{}' ), true );
		$findings  = json_decode( (string) ( $submission->findings_json ?? '[]' ), true );
		$domains   = json_decode( (string) ( $submission->domain_scores_json ?? '[]' ), true );

		if ( ! is_array( $answers ) ) {
			$answers = [];
		}
		if ( ! is_array( $findings ) ) {
			$findings = [];
		}
		if ( ! is_array( $domains ) ) {
			$domains = [];
		}

		return [
			'customer' => [
				'name'    => (string) ( $submission->contact_name ?? '' ),
				'company' => (string) ( $submission->contact_company ?? '' ),
				'email'   => (string) ( $submission->contact_email ?? '' ),
			],
			'assessment' => [
				'ref'            => (string) ( $questionnaire->ref ?? '' ),
				'name'           => (string) ( $questionnaire->name ?? '' ),
				'plan_days'      => $days,
				'overall_score'  => (int) ( $submission->overall_score ?? 0 ),
				'grade_label'    => (string) ( $submission->grade_label ?? '' ),
				'completed_at'   => (string) ( $submission->completed_at ?? '' ),
			],
			'answers'  => self::build_answer_summary( $structure, $answers ),
			'domains'  => $domains,
			'findings' => array_values( $findings ),
		];
	}

	private static function build_answer_summary( array $structure, array $answers ): array {
		$rows = [];

		foreach ( $structure['domains'] ?? [] as $di => $domain ) {
			foreach ( $domain['questions'] ?? [] as $qi => $question ) {
				$key    = "{$di}_{$qi}";
				$answer = $answers[ $key ] ?? null;
				$label  = self::answer_label( $question, $answer );
				$rows[] = [
					'domain'         => (string) ( $domain['name'] ?? '' ),
					'domain_slug'    => (string) ( $domain['slug'] ?? '' ),
					'question_ref'   => (string) ( $question['question_ref'] ?? '' ),
					'question'       => (string) ( $question['question'] ?? '' ),
					'answer'         => $label,
					'recommendation' => (string) ( $question['recommendation'] ?? '' ),
				];
			}
		}

		return $rows;
	}

	private static function answer_label( array $question, mixed $answer ): string {
		if ( is_array( $answer ) ) {
			return implode( ', ', array_map( static fn( $item ) => self::answer_label( $question, $item ), $answer ) );
		}

		if ( is_string( $answer ) ) {
			$decoded = json_decode( $answer, true );
			if ( is_array( $decoded ) ) {
				return implode( ', ', array_map( static fn( $item ) => self::answer_label( $question, $item ), $decoded ) );
			}
		}

		foreach ( $question['options'] ?? [] as $option ) {
			if ( (string) ( $option['key'] ?? '' ) === (string) $answer ) {
				return (string) ( $option['label'] ?? $answer );
			}
		}

		return is_scalar( $answer ) ? (string) $answer : '';
	}

	private static function request_tasks( array $context, int $days ): array {
		$key_details = self::get_api_key_details();
		$api_key     = (string) ( $key_details['value'] ?? '' );
		if ( $api_key === '' ) {
			throw new RuntimeException( 'Claude API key missing.' );
		}

		$model  = (string) get_option( 'wpq_claude_model', 'claude-sonnet-4-20250514' );
		$prompt = self::build_prompt( $context, $days );

		$response = wp_remote_post(
			self::API_URL,
			[
				'timeout' => 45,
				'headers' => [
					'content-type'      => 'application/json',
					'x-api-key'         => $api_key,
					'anthropic-version' => self::API_VERSION,
				],
				'body'    => wp_json_encode( [
					'model'      => $model,
					'max_tokens' => 5000,
					'system'     => 'You create practical cyber remediation plans. Return only valid JSON.',
					'messages'   => [
						[
							'role'    => 'user',
							'content' => $prompt,
						],
					],
				] ),
			]
		);

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'Claude request failed.' );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( 'Claude returned an error response.' );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) ) {
			throw new RuntimeException( 'Claude response was not JSON.' );
		}

		$text = '';
		foreach ( $body['content'] ?? [] as $part ) {
			if ( is_array( $part ) && ( $part['type'] ?? '' ) === 'text' ) {
				$text .= (string) ( $part['text'] ?? '' );
			}
		}

		return self::parse_tasks( $text );
	}

	private static function build_prompt( array $context, int $days ): string {
		$payload = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return "Create a {$days}-day remediation tasklist for this completed questionnaire.\n"
			. "Return strict JSON only with this shape: {\"tasks\":[{\"phase\":\"30|60|90\",\"due_day\":7,\"priority\":\"High|Medium|Low\",\"domain\":\"...\",\"task\":\"...\",\"details\":\"...\",\"success_criteria\":\"...\",\"owner\":\"...\"}]}.\n"
			. "Make tasks specific to the answers and recommendations. Use UK business-friendly wording. Do not include markdown.\n"
			. "Assessment context JSON:\n{$payload}";
	}

	private static function parse_tasks( string $text ): array {
		$text = trim( $text );
		if ( $text === '' ) {
			throw new RuntimeException( 'Claude response was empty.' );
		}

		$decoded = json_decode( $text, true );
		if ( ! is_array( $decoded ) ) {
			if ( preg_match( '/\{.*\}/s', $text, $matches ) ) {
				$decoded = json_decode( $matches[0], true );
			}
		}

		if ( ! is_array( $decoded ) || ! isset( $decoded['tasks'] ) || ! is_array( $decoded['tasks'] ) ) {
			throw new RuntimeException( 'Claude response did not contain tasks.' );
		}

		$tasks = [];
		foreach ( $decoded['tasks'] as $task ) {
			if ( ! is_array( $task ) ) {
				continue;
			}
			$tasks[] = [
				'phase'            => sanitize_text_field( (string) ( $task['phase'] ?? '' ) ),
				'due_day'          => max( 1, (int) ( $task['due_day'] ?? 1 ) ),
				'priority'         => sanitize_text_field( (string) ( $task['priority'] ?? 'Medium' ) ),
				'domain'           => sanitize_text_field( (string) ( $task['domain'] ?? '' ) ),
				'task'             => sanitize_text_field( (string) ( $task['task'] ?? '' ) ),
				'details'          => sanitize_textarea_field( (string) ( $task['details'] ?? '' ) ),
				'success_criteria' => sanitize_textarea_field( (string) ( $task['success_criteria'] ?? '' ) ),
				'owner'            => sanitize_text_field( (string) ( $task['owner'] ?? 'Customer' ) ),
				'status'           => 'Not started',
			];
		}

		if ( empty( $tasks ) ) {
			throw new RuntimeException( 'Claude response did not contain usable tasks.' );
		}

		return $tasks;
	}

	private static function build_workbook( array $context, array $tasks, int $days ): string {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( 'ZipArchive is not available.' );
		}

		$tmp = tempnam( sys_get_temp_dir(), 'wpq-remediation-' );
		if ( ! is_string( $tmp ) || $tmp === '' ) {
			throw new RuntimeException( 'Could not create workbook.' );
		}

		$zip = new ZipArchive();
		if ( $zip->open( $tmp, ZipArchive::OVERWRITE ) !== true ) {
			throw new RuntimeException( 'Could not open workbook archive.' );
		}

		$planner_rows = [
			[ 'Field', 'Value' ],
			[ 'Customer', (string) ( $context['customer']['name'] ?? '' ) ],
			[ 'Company', (string) ( $context['customer']['company'] ?? '' ) ],
			[ 'Questionnaire', (string) ( $context['assessment']['name'] ?? '' ) ],
			[ 'Questionnaire Ref', (string) ( $context['assessment']['ref'] ?? '' ) ],
			[ 'Overall Score', (string) ( $context['assessment']['overall_score'] ?? '' ) ],
			[ 'Grade', (string) ( $context['assessment']['grade_label'] ?? '' ) ],
			[ 'Plan Length', $days . ' days' ],
			[ 'Generated At', gmdate( 'c' ) ],
		];

		$task_rows = [
			[ 'Phase', 'Due Day', 'Priority', 'Domain', 'Task', 'Details', 'Success Criteria', 'Owner', 'Status' ],
		];
		foreach ( $tasks as $task ) {
			$task_rows[] = [
				(string) $task['phase'],
				(string) $task['due_day'],
				(string) $task['priority'],
				(string) $task['domain'],
				(string) $task['task'],
				(string) $task['details'],
				(string) $task['success_criteria'],
				(string) $task['owner'],
				(string) $task['status'],
			];
		}

		$zip->addFromString( '[Content_Types].xml', self::content_types_xml() );
		$zip->addFromString( '_rels/.rels', self::root_rels_xml() );
		$zip->addFromString( 'docProps/app.xml', self::app_xml() );
		$zip->addFromString( 'docProps/core.xml', self::core_xml() );
		$zip->addFromString( 'xl/workbook.xml', self::workbook_xml() );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', self::workbook_rels_xml() );
		$zip->addFromString( 'xl/styles.xml', self::styles_xml() );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', self::worksheet_xml( $planner_rows ) );
		$zip->addFromString( 'xl/worksheets/sheet2.xml', self::worksheet_xml( $task_rows ) );
		$zip->close();

		$binary = file_get_contents( $tmp );
		@unlink( $tmp );
		if ( ! is_string( $binary ) ) {
			throw new RuntimeException( 'Could not read workbook.' );
		}

		return $binary;
	}

	private static function worksheet_xml( array $rows ): string {
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
		foreach ( array_values( $rows ) as $r => $row ) {
			$row_num = $r + 1;
			$xml .= '<row r="' . $row_num . '">';
			foreach ( array_values( $row ) as $c => $value ) {
				$cell = self::cell_name( $c, $row_num );
				$xml .= '<c r="' . $cell . '" t="inlineStr"><is><t>' . self::xml( (string) $value ) . '</t></is></c>';
			}
			$xml .= '</row>';
		}
		return $xml . '</sheetData></worksheet>';
	}

	private static function cell_name( int $column, int $row ): string {
		$name = '';
		$column++;
		while ( $column > 0 ) {
			$mod  = ( $column - 1 ) % 26;
			$name = chr( 65 + $mod ) . $name;
			$column = (int) floor( ( $column - $mod ) / 26 );
		}
		return $name . $row;
	}

	private static function xml( string $value ): string {
		return htmlspecialchars( $value, ENT_XML1 | ENT_COMPAT, 'UTF-8' );
	}

	private static function content_types_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';
	}

	private static function root_rels_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>';
	}

	private static function workbook_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Planner" sheetId="1" r:id="rId1"/><sheet name="Tasklist" sheetId="2" r:id="rId2"/></sheets></workbook>';
	}

	private static function workbook_rels_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
	}

	private static function styles_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellXfs></styleSheet>';
	}

	private static function app_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>WP Questionnaires</Application></Properties>';
	}

	private static function core_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>WP Questionnaires</dc:creator><dc:title>Remediation Plan</dc:title><dcterms:created xsi:type="dcterms:W3CDTF">' . self::xml( gmdate( 'c' ) ) . '</dcterms:created></cp:coreProperties>';
	}
}
