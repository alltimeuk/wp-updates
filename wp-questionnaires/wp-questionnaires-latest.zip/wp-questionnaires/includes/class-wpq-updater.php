<?php
/**
 * Self-hosted plugin updater.
 *
 * Polls update.json on GitHub Pages, injects version info into WordPress's
 * built-in update mechanism, and exposes a kill-switch constant for staging.
 *
 * Define WPQ_DISABLE_AUTO_UPDATE = true in wp-config.php to prevent automatic
 * background updates on a given environment (staging, local, etc.).
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Updater {

	private const UPDATE_URL = 'https://alltimeuk.github.io/wp-updates/wp-questionnaires/update.json';
	private const CACHE_KEY  = 'wpq_remote_update_info';
	private const CACHE_TTL  = 1800; // 30 minutes.

	public function __construct() {
		add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'inject_update' ] );
		add_filter( 'plugins_api',                           [ $this, 'plugin_info' ], 10, 3 );
		add_action( 'upgrader_process_complete',             [ $this, 'after_update' ], 10, 2 );
		add_filter( 'auto_update_plugin',                    [ $this, 'auto_update_gate' ], 10, 2 );
		add_action( 'delete_site_transient_update_plugins',   [ $this, 'clear_remote_cache' ] );
		add_action( 'load-update-core.php',                   [ $this, 'clear_remote_cache' ] );
	}

	// -----------------------------------------------------------------------
	// Update injection
	// -----------------------------------------------------------------------

	/**
	 * Injects our plugin into the update_plugins transient when a newer
	 * version is available on the GitHub Pages endpoint.
	 *
	 * @param mixed $transient Value of the update_plugins transient.
	 * @return mixed Unchanged or augmented transient.
	 */
	public function inject_update( mixed $transient ): mixed {
		if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
			return $transient;
		}

		$remote = $this->get_remote_info();
		if ( null === $remote ) {
			return $transient;
		}

		$obj               = new stdClass();
		$obj->id           = 'alltimeuk/wp-questionnaires';
		$obj->slug         = 'wp-questionnaires';
		$obj->plugin       = WPQ_PLUGIN_BASENAME;
		$obj->new_version  = $remote->version;
		$obj->url          = $remote->homepage ?? '';
		$obj->package      = $remote->download_url ?? '';
		$obj->icons        = [];
		$obj->banners      = [];
		$obj->tested       = $remote->tested ?? '';
		$obj->requires_php = $remote->requires_php ?? '';

		if ( version_compare( WPQ_VERSION, $remote->version, '<' ) ) {
			$transient->response[ WPQ_PLUGIN_BASENAME ] = $obj;
		} else {
			$obj->package                                 = '';
			$transient->no_update[ WPQ_PLUGIN_BASENAME ] = $obj;
		}

		return $transient;
	}

	// -----------------------------------------------------------------------
	// Plugin info popup
	// -----------------------------------------------------------------------

	/**
	 * Supplies plugin details for the "View version x.x.x details" popup.
	 *
	 * @param mixed  $result Result object or false.
	 * @param string $action plugins_api action name.
	 * @param object $args   Query arguments (slug, etc.).
	 * @return mixed Original $result or a populated stdClass for our plugin.
	 */
	public function plugin_info( mixed $result, string $action, object $args ): mixed {
		if ( 'plugin_information' !== $action || 'wp-questionnaires' !== ( $args->slug ?? '' ) ) {
			return $result;
		}

		$remote = $this->get_remote_info();
		if ( null === $remote ) {
			return $result;
		}

		$info                = new stdClass();
		$info->name          = $remote->name ?? 'WP Questionnaires';
		$info->slug          = 'wp-questionnaires';
		$info->version       = $remote->version;
		$info->author        = '<a href="' . esc_url( $remote->author_homepage ?? '' ) . '">'
		                     . esc_html( $remote->author ?? 'Alltime Technologies Ltd' ) . '</a>';
		$info->requires      = $remote->requires ?? '6.4';
		$info->tested        = $remote->tested ?? '';
		$info->requires_php  = $remote->requires_php ?? '8.1';
		$info->last_updated  = $remote->last_updated ?? '';
		$info->download_link = $remote->download_url ?? '';
		$info->sections      = (array) ( $remote->sections ?? new stdClass() );
		$info->icons         = [];
		$info->banners       = [];

		return $info;
	}

	// -----------------------------------------------------------------------
	// Post-update cache bust
	// -----------------------------------------------------------------------

	/**
	 * Clears the cached update info after any plugin update completes, so the
	 * next admin page load fetches fresh data.
	 *
	 * @param object $upgrader WP_Upgrader instance.
	 * @param array  $hook_extra Array describing what was upgraded.
	 */
	public function after_update( object $upgrader, array $hook_extra ): void {
		if (
			isset( $hook_extra['type'], $hook_extra['action'] ) &&
			'plugin' === $hook_extra['type'] &&
			'update' === $hook_extra['action']
		) {
			$this->clear_remote_cache();
		}
	}

	public function clear_remote_cache(): void {
		delete_transient( self::CACHE_KEY );
	}

	// -----------------------------------------------------------------------
	// Auto-update gate
	// -----------------------------------------------------------------------

	/**
	 * Prevents automatic background updates when WPQ_DISABLE_AUTO_UPDATE is
	 * true (set this in wp-config.php on staging/local environments). Otherwise
	 * defers to WordPress's own per-plugin auto-update toggle in the plugin list.
	 *
	 * @param ?bool  $update Current decision (true/false/null).
	 * @param object $item   Plugin data object.
	 * @return ?bool Filtered decision.
	 */
	public function auto_update_gate( ?bool $update, object $item ): ?bool {
		if ( ! isset( $item->plugin ) || WPQ_PLUGIN_BASENAME !== $item->plugin ) {
			return $update;
		}
		if ( defined( 'WPQ_DISABLE_AUTO_UPDATE' ) && WPQ_DISABLE_AUTO_UPDATE ) {
			return false;
		}
		return $update; // WordPress's built-in per-plugin toggle takes effect.
	}

	// -----------------------------------------------------------------------
	// Remote fetch with caching
	// -----------------------------------------------------------------------

	/**
	 * Fetches update.json from the GitHub Pages endpoint, caching the result
	 * (30 m on success, 1 h on failure) to avoid hammering the remote.
	 *
	 * @return ?object Parsed JSON object, or null on failure / cached failure.
	 */
	private function get_remote_info(): ?object {
		$cached = get_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return $cached['data'] instanceof stdClass ? $cached['data'] : null;
		}

		$response = wp_remote_get(
			self::UPDATE_URL,
			[
				'timeout'    => 10,
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; WP-Questionnaires/' . WPQ_VERSION . '; ' . get_bloginfo( 'url' ),
			]
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			set_transient( self::CACHE_KEY, [ 'data' => null ], HOUR_IN_SECONDS );
			return null;
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ) );
		if ( ! $data || ! isset( $data->version ) ) {
			set_transient( self::CACHE_KEY, [ 'data' => null ], HOUR_IN_SECONDS );
			return null;
		}

		set_transient( self::CACHE_KEY, [ 'data' => $data ], self::CACHE_TTL );
		return $data;
	}
}
