# Changelog

## 1.11.53 - 2026-07-09

### Fixed

- Reissued the demo-data exclusion release with release packaging that removes
  the empty `includes/data` directory as well as its generated contents.

## 1.11.52 - 2026-07-09

### Changed

- Stopped automatic seeding of the generated questionnaire library during
  activation and schema upgrades.
- Excluded generated/demo questionnaire library payloads from release ZIPs;
  `.sample_data` remains source-only optional import material.
- Updated package smoke tests to fail if demo questionnaire data is bundled.

## 1.11.51 - 2026-07-09

### Added

- Added Composer PSR-4 autoloading for new `Alltime\WPQ\` classes and a
  minimal internal service registry.
- Added immutable completion-time submission snapshots for questionnaire,
  scoring, grade threshold, option, and CTA context.
- Added a named WPQ administrator capability set as the first step toward
  delegated access controls.

### Changed

- Bumped the database schema to `1.26.0` for the new submission snapshot
  columns.
- Updated release packaging to include the new `src/` namespace tree.

## 1.11.50 - 2026-07-09

### Fixed

- Reissued the stabilisation groundwork release with PHPCS-compatible SQL
  string formatting for the database-backed rate limiter.

## 1.11.49 - 2026-07-09

### Added

- Added stabilisation groundwork for durable admin audit logging and atomic
  public rate limiting with new `wpq_audit_log` and `wpq_rate_limits` tables.
- Added central database transaction helpers for upcoming high-risk write-path
  hardening.
- Added readiness and schema diagnostics for rate-limit storage.

### Changed

- Public REST rate limiting now prefers the database-backed limiter when the
  new storage table is available, with the previous transient limiter retained
  as an upgrade-safe fallback.
- Bumped the database schema to `1.25.0` for the audit and rate-limit tables.

## 1.11.48 - 2026-07-08

### Changed

- Reduced the default key findings display to actionable critical, high, medium,
  and low entries, sorted by domain and then severity.
- Updated result CTA placement and styling so domain CTAs are capped at three,
  randomly distributed across eligible domains, and visually slot into the
  findings list with a right-edge accent.
- Removed the circular severity marker from public key findings.

## 1.11.47 - 2026-07-08

### Fixed

- Aligned public result gauge and domain-breakdown colours with the
  questionnaire's configured grade thresholds and grade colours.

## 1.11.46 - 2026-07-08

### Changed

- Renamed Call to Action "Scope" admin labels to "Domain" and removed the
  repeated domain slug from domain dropdown labels.
- Replaced per-row domain saves in the questionnaire editor with one master
  Save domains action.

## 1.11.45 - 2026-07-08

### Changed

- Replaced per-row grade saves with one master Save grades action in the
  questionnaire editor.
- Renamed answer-option and grade row actions from Delete to Remove to clarify
  that the row is being removed, not the parent question or questionnaire.

## 1.11.44 - 2026-07-07

### Fixed

- Cleared the plugin's private update metadata cache when WordPress clears its
  plugin update transient or when the Update Core screen is loaded, so the
  self-hosted updater detects freshly published releases promptly.
- Reduced the self-hosted update metadata cache from 12 hours to 30 minutes.

## 1.11.43 - 2026-07-07

### Added

- Added admin-managed category and domain call-to-action sections for public
  questionnaire results.
- Added Claude-powered remediation plan generation with downloadable workbook
  output for completed assessments.

### Fixed

- Preserved domain `brief` content during questionnaire import/export and
  questionnaire duplication.

### Changed

- Bumped the database schema to `1.24.0` for the new CTA storage table.

## 1.11.42 - 2026-07-07

### Changed

- Reissued the grade-colour release so the tag includes the wp-updates release
  workflow cleanup.
- Fixed the wp-updates deploy commit message to avoid a doubled `v` prefix and
  added a clearer preflight error when `WP_UPDATES_TOKEN` is missing.

## 1.11.41 - 2026-07-07

### Changed

- New questionnaires now start with the standard four grade thresholds:
  Strong, Moderate, Needs Attention, and High Risk, using the requested
  green, amber, red, and blue text/background palette.
- Public assessment results now colour the overall score gauge, grade pill,
  and domain breakdown bars from the questionnaire's configured grade
  thresholds instead of fixed percentage colour bands.

## 1.11.40 - 2026-07-07

### Changed

- Changed `[wpq_time ref="..."]` to return only the numeric minute estimate so
  page templates can supply their own surrounding copy.
- Documented `[wpq_minutes]` as a backwards-compatible alias for the numeric
  time shortcode and kept `[wpq_estimate]` for formatted "X minutes" output.

## 1.11.39 - 2026-07-07

### Added

- Added canonical `[wpq_questionnaire ref="..."]` shortcode for embedding a
  questionnaire, while keeping `[wpq_assessment]`, `[wpq_assessments]`, and
  `[wpq_product]` as backwards-compatible aliases.
- Added helper shortcodes for post/page copy: `[wpq_domains]`, `[wpq_time]`,
  `[wpq_submissions]`, and `[wpq_status]`.
- Expanded the Settings -> Shortcodes screen with copy/paste examples,
  editorial guidance, and per-questionnaire shortcode snippets.

### Changed

- Updated shortcode documentation to prefer `[wpq_questionnaire]` and list all
  available metadata helper shortcodes.

## 1.11.38 - 2026-07-07

### Fixed

- Fixed `single_option` radio questionnaire scoring when imported questions have
  `max_score` stored as `0`; those questions now derive their maximum score from
  answer options so overall and domain percentages calculate correctly.
- Updated the public results gauge and domain bars to display clamped percentage
  values with an explicit `%` suffix.
- Preserved blank/null max-score values during questionnaire import/export so
  option-scored questionnaires do not reintroduce zero denominators.

## 1.11.37 - 2026-07-06

### Changed

- Advanced the release version for a fresh GitHub release tag after the
  v1.11.36 release object already existed.

## 1.11.36 - 2026-07-06

### Fixed

- Question editor Save now persists answer options alongside the question fields,
  including newly pasted option rows.
- Public assessment answer layouts now use the wider panel space more effectively by
  capping option-grid columns to the actual option count and stretching answer cells.

### Changed

- Results copy now labels the findings section as "Key Findings".

## 1.11.35 - 2026-07-03

### Added

- **Consent persistence** — privacy consent acceptance is now stored server-side. A new
  `consent_accepted_at` column (DATETIME, nullable) is added to `wpq_submissions` via DB
  migration 1.23.0. When the lead form is submitted with the consent checkbox ticked, the
  server records the UTC timestamp against the submission row. The admin Contacts → record
  view displays "Privacy consent: ✓ Accepted dd Mon YYYY HH:mm" in the contact info card
  (earliest consent across all submissions), and a per-submission Consent column (✓ / —) in
  the submissions table.

## 1.11.34 - 2026-07-03

### Added

- **Privacy consent checkbox** — lead capture form now requires an explicit opt-in tick before
  submission. Label links to the WordPress privacy policy page (via `get_privacy_policy_url()`),
  falling back to a plain-text statement if no URL is configured. Satisfies EU GDPR informed
  consent requirements for processing personal data collected via the assessment form.

## 1.11.33 - 2026-07-02

### Added

- **`wpq_product` shortcode** — alias for `[wpq_assessment ref="…"]`; both names are now
  registered and fully interchangeable.
- **`wpq_minutes` shortcode** — returns the estimated completion time as a plain integer
  (minutes), e.g. `5`. Use when you need just the number without the "minutes" suffix (which
  `wpq_estimate` already provides as "5 minutes").

### Changed

- **Questionnaire status lifecycle** — the four lifecycle stages are now `draft → preview →
  live → retired` (replacing `draft / published / archived`):
  - **Draft** — questionnaire is being built; not accessible via shortcode; no Stripe product
    required or auto-created.
  - **Preview** — accessible via shortcode for internal testing; does not require Stripe.
  - **Live** — accessible via shortcode; saving with Live status auto-creates a Stripe Product
    if one does not yet exist.
  - **Retired** — shortcode returns nothing; Stripe Product is kept (not archived).
- **Stripe Product auto-create** — moved from "on every save" to "first save in Live status
  only". Creating or saving a Draft/Preview questionnaire no longer touches Stripe.
- **DB schema migration** (`WPQ_DB_VERSION 1.22.0`) — `wpq_questionnaires.status` ENUM updated
  from `(draft, published, archived)` to `(draft, preview, live, retired)`. Existing rows are
  migrated: `published → live`, `archived → retired`.
- Bulk action labels updated: "Publish" → "Go Live", "Archive" → "Retire",
  "Unarchive" → "Revert to Draft (Retired only)", "Remove" → "Remove (Retired only)".

## 1.11.32 - 2026-07-02

### Added

- **Stripe full lifecycle sync — questionnaires** — creating a questionnaire now auto-creates a
  Stripe Product (`prod_…`) and saves its ID back to the questionnaire. Saving a questionnaire
  (name or description change) updates the Stripe Product name/description. Bulk-removing an
  archived questionnaire archives the Stripe Product (`active: false`). If Stripe is not
  initialised the save proceeds unchanged.
- **Stripe full lifecycle sync — pricing options** — saving a pricing option (create or update)
  now auto-creates a Stripe Price (`price_…`) if the linked questionnaire has a Stripe Product
  and the Stripe Price field is empty. The amount and billing type (one-off, monthly, annual) are
  mapped automatically. Deleting a pricing option archives its Stripe Price first.
- **Delete pricing option** — a Delete button is now shown alongside Edit in the Pricing table.
  Clicking it confirms, archives the Stripe Price (if set), and removes the row from the DB.
  The Stripe Price ID field hint is updated to reflect auto-creation.

## 1.11.31 - 2026-07-02

### Fixed

- **Add Pricing Option — questionnaire dropdown** — questionnaires are now sorted alphabetically
  by name. The underlying `get_questionnaire_list()` query order (category, ref) is unchanged
  for other views; the sort is applied at the call site in `page-products.php`.

## 1.11.30 - 2026-07-02

### Changed

- **Questions editor — tip icon removed** — the floating ⓘ icon overlaid on the question textarea
  is removed from the admin UI; it served no purpose there. The Tip label and input field in the
  behaviour row are unchanged.
- **Questions editor — Tip input width** — Tip input now fills the remaining width of the behaviour
  row (flex: 1) rather than being a fixed 25em `regular-text` box, giving it roughly half the row.

## 1.11.29 - 2026-07-02

### Changed

- **Question number colour** — question number now renders in Alltime Dark Pink (`--wpq-pink`, `#E20979`)
  to match the Next button, replacing the previous muted grey.
- **Domains table — Brief column** — removed `regular-text` class from the Name input (it was forcing
  25em width and overflowing into the Brief column); Name input now fills its cell at `width:100%`.
  Name `<th>` widened to 200px; Brief `<th>` and `<td>` gain 12px left padding to create clear visual
  separation between columns.

## 1.11.28 - 2026-07-02

### Changed

- **Plugin update endpoint** — migrated from `gh-pages` branch in `wp-questionnaires` to a dedicated
  public `alltimeuk/wp-updates` repository. Each plugin deploys into its own subdirectory
  (`wp-questionnaires/`), enabling the same repo to serve multiple plugins without cross-plugin
  interference. `WPQ_Updater::UPDATE_URL` updated to
  `https://alltimeuk.github.io/wp-updates/wp-questionnaires/update.json`.
- **GitHub Actions deploy step** — switched from `github_token` + `force_orphan: true` to
  `personal_token: ${{ secrets.WP_UPDATES_TOKEN }}` + `external_repository: alltimeuk/wp-updates` +
  `destination_dir: wp-questionnaires` + `keep_files: true`. This preserves other plugins' directories
  on every push rather than wiping the entire repo.

## 1.11.27 - 2026-07-02

### Changed

- **Question font size** — both question number and question text reduced from 1.1rem to 1.05em,
  improving readability on mobile without sacrificing legibility on desktop.
- **Questions editor — recommendation field** — recommendation textarea is now placed adjacent to the
  question textarea in a 50/50 flex layout rather than below it; collapses to hidden automatically for
  question types that don't support recommendations.
- **Domains table alignment** — Brief textarea column cells are now top-aligned (`vertical-align: top`)
  so all inputs within a domain row sit at the top of the row rather than floating to the vertical centre.

### Fixed

- **PHPStan stubs** — added missing WordPress function stubs (`delete_transient`, `get_bloginfo`,
  `is_wp_error`, `wp_doing_cron`, `wp_remote_get`, `wp_remote_retrieve_response_code`,
  `wp_remote_retrieve_body`) and constants (`WPQ_PLUGIN_BASENAME`, `HOUR_IN_SECONDS`); fixed
  `add_action` stub to accept optional `$priority` and `$accepted_args` parameters.

## 1.11.26 - 2026-07-02

### Added

- **Plugin self-update** — `WPQ_Updater` hooks into WordPress's built-in update mechanism. The plugin
  polls `update.json` from the GitHub Pages endpoint (12 h cache on success, 1 h on failure) and
  injects available-update data into the `update_plugins` transient so site admins see standard WP
  update notifications and can use the native one-click update flow.
- **GitHub Pages update endpoint** — `release.yml` now deploys a `gh-pages` branch on every tagged
  release, publishing `update.json` (machine-readable version metadata), `wp-questionnaires-latest.zip`
  (the plugin ZIP, overwritten each release), and `index.html` (human-readable landing page).
- **Kill-switch constant** — define `WPQ_DISABLE_AUTO_UPDATE = true` in `wp-config.php` on staging or
  local environments to suppress automatic background updates; WordPress's per-plugin toggle is still
  respected when the constant is absent or false.

## 1.11.25 - 2026-07-02

### Changed

- **Question text colours** — both question number and question text set to `--wpq-text-mid` (#666666);
  removes the harsh near-black on question text and lifts the muted grey on the number so they match.

## 1.11.24 - 2026-07-02

### Changed

- **Question divider line** — colour changed from light grey to `--wpq-navy` (#2D2C94); 5 px extra
  padding/margin added above and below the line to improve readability between questions.
- **Form width** — max-width increased from 860 px to 1000 px; fully responsive on mobile.
- **Question number** — no space between "Q" and the digit (e.g. `Q1:` not `Q 1:`); font size
  raised to 1.1 rem to match the question text.
- **Tri-state / Boolean button gap** — column gap between answer buttons widened from 10 px to 30 px.

## 1.11.23 - 2026-07-02

### Added

- **Domain Brief** — new `brief` TEXT column on `wpq_domains`. Visible as a resizable textarea in the
  Domains tab (admin), right of the Name column. Supports up to ~5 paragraphs separated by blank lines.
- **Brief page in customer journey** — if a domain has a brief, a full-screen "brief page" is shown
  before the domain's questions each time the user enters that domain. User journey becomes:
  Lead form → Domain 1 Brief → Domain 1 Questions → Domain 2 Brief → Domain 2 Questions → … → Report.
  Domains with no brief skip straight to questions.
- **Back button** — fully wired. From a brief page: Back returns to the previous domain's questions
  (hidden on the first brief/question screen). From a questions page: Back goes to that domain's brief
  if one exists, otherwise to the previous domain's questions.
- DB migration block for `1.21.0` adds `brief TEXT NULL AFTER domain_weight` to `wpq_domains`.

## 1.11.22 - 2026-07-02

### Fixed

- **Import oversized file** — size check now fires instantly from `File.size`
  before the browser reads or parses the file. Previously the check ran after
  `JSON.parse` + `JSON.stringify` of the whole file, which caused the browser
  tab to freeze on very large files (e.g. 43 MB combined export) and surface a
  misleading "server unreachable" error instead of a clear size message.

## 1.11.21 - 2026-07-02

### Added

- **Collapsible domain sections** — clicking a domain heading (blue) collapses or expands all
  questions beneath it; question count shown in heading.
- **Reset Questions** button above the question list — two-step confirmation before deleting all
  questions for the questionnaire (new `wpq_reset_questions` AJAX endpoint).
- **Create Questions** form — specify domain + count, creates N empty questions sequentially via
  existing `wpq_add_question`, with live progress indicator.
- **Save/Delete buttons** moved to a right-aligned column adjacent to the question label, top-aligned.

### Changed

- Answer options column renamed "Finding action" → "Recommendation".

## 1.11.20 - 2026-07-02

### Changed

- **Question editor layout** — removed per-question domain dropdown (now a
  hidden field; domain assignment is shown in the section heading). Removed the
  "Type & behaviour" sub-heading. Type, Scoring mode, Required, and Tip controls
  are now a single bottom-aligned flex row with Tip moved inline as a 4th cell,
  eliminating the separate Tip row below.

### Fixed

- **Import oversized payload** — added pre-send 8 MB size check and an
  `httpError()` helper that surfaces HTTP status codes (including HTTP 413
  guidance to use smaller files) instead of a generic "Request failed" message.
  PHP-side: detects empty `$_POST` with non-zero `Content-Length` and returns an
  actionable error message rather than silently failing.

## 1.11.19 - 2026-07-01

### Added

- **Multi-file import** — the import drop-zone now accepts multiple JSON files
  at once. All files are read and analysed in sequence, then presented together
  so conflicts can be resolved in one pass before a single "Import N files"
  click processes them all.
- **Set all conflicts to** bar — a single "Set all conflicts to: [Skip |
  Overwrite] Apply to all" control above the conflict tables sets every
  per-row dropdown simultaneously, with individual rows still overridable.
- **Detailed import error reporting** — question-level failures now surface the
  exact MySQL error string (e.g. "Column 'condition_op' cannot be null"), the
  question ref/row number, and the count of failed rows per questionnaire.
  Errors are shown per-file in a collapsible `<details>` block, and a final
  collapsible summary lists every error across all files.

### Changed

- Import conflict table collapses (hides) after a file has been successfully
  imported; only the per-file badge (✓ N imported) and any errors remain
  visible, keeping the page readable when processing many files at once.

## 1.11.18 - 2026-07-01

### Fixed

- Import: questions failing to insert when `condition_op` is absent from the
  JSON — the column is `ENUM NOT NULL DEFAULT 'eq'` and MySQL 8 strict mode
  rejects a SQL NULL on a NOT NULL column, silently dropping every question row.
  Now defaults to `'eq'` when no value is supplied, matching the DB default.
  This was the root cause of CE-2026-V16 importing with domains but zero
  questions.

### Changed

- Results screen: verdict text (e.g. "Significant cyber security gaps
  identified. Immediate action required.") is now displayed in Alltime navy
  (`#2D2C94`) at 1.05 rem / medium weight so it stands out next to the score
  ring, rather than being muted grey at 0.95 rem.

## 1.11.17 - 2026-07-01

### Changed

- Submission detail page — **Result** section removed as a standalone card;
  score and grade are now shown as a single row inside the **Details** panel,
  colour-coded using the questionnaire's own grade threshold colours and
  displaying the configured grade label (e.g. "E") with the verdict text.
- **Domain Scores** — each domain row now has a collapsible `▶ N questions`
  toggle underneath it. Expanding it reveals a per-question sub-table showing
  the question ref, question text, and the answer the respondent gave.
  Answers to scored yes/no/partial questions are colour-coded (green / red /
  amber). Non-scoring questions are shown in muted text.

## 1.11.16 - 2026-07-01

### Changed

- Renamed "Key findings" section on the results screen to **Recommendations**.
- Recommendations cards redesigned: priority badge (Critical/Medium) and domain
  name are now separate elements; each card shows the question, the answer the
  respondent gave ("You answered: …"), and the recommendation text as distinct
  rows, making it clear what was asked, how it was answered, and what action
  is required.
- Removed the previous 5-item cap on recommendations so all findings from the
  assessment are surfaced, not just the top five.

### Added

- Filter controls above the Recommendations list. A **Severity** group filters
  by Critical / Medium; a **Domain** group (shown when findings span more than
  one domain) filters by domain name. The two groups are mutually exclusive —
  selecting a severity filter resets the domain filter to "All", and vice
  versa, so the respondent can browse one dimension at a time.

## 1.11.15 - 2026-07-01

### Added

- Client-side filter input on the Questionnaires, Coupons, and Pricing admin
  list tables. Typing in the "Filter…" box instantly narrows visible rows by
  matching against all text in each row (ref, name, status, Stripe ID, etc.).
  A live count shows "N of M shown" while a query is active.
  Contacts, Orders, and Submissions already had server-side search and are
  unchanged.

## 1.11.14 - 2026-07-01

### Fixed

- REST route regex for the questionnaire endpoint broadened from
  `[A-Z]{2,6}-?\d{1,6}` to `[A-Z][A-Z0-9_-]{1,29}`, allowing refs that
  contain letters after digits, longer prefixes, or underscores/hyphens in
  any position. Previously any non-standard ref silently produced a 404 from
  WordPress route matching even though the questionnaire existed in the DB.
- Assessment load error now shows the actual error code (e.g. `NOT_FOUND`,
  `[HTTP 404]`) instead of the generic connection message, making it easier
  to diagnose why a questionnaire failed to load.

## 1.11.13 - 2026-07-01

### Changed

- Question text font-size increased to `1.1rem` (was `11pt`).
- Answer option font-size increased to `1rem` across all input types: tri-state
  buttons, radio labels, checkbox labels, select, textarea, and short-text.
- Added `text-rendering: optimizeLegibility` and
  `-webkit-font-smoothing: subpixel-antialiased` to the questionnaire wrapper.
- Radio/checkbox grid columns changed from `repeat(N, max-content)` to
  `repeat(N, minmax(0, 1fr))` — options now fill the container width instead
  of overflowing when there are 4–5 long labels per row.

### Added

- "Next domain" now validates that all required visible questions in the current
  domain are answered before advancing. Unanswered questions are highlighted
  in red; the viewport scrolls to the first unanswered question automatically.
- Advancing to a new domain (or pressing "← Back") now smoothly scrolls the
  viewport back to the top of the questionnaire widget.
- Validation highlights clear automatically when the question is answered.

## 1.11.12 - 2026-07-01

### Added

- `WPQ_Stripe::has_test_checkout_session()` and `has_test_webhook_event()` — test-mode
  introspection helpers used by integration tests without exposing internal state.
- `CheckoutEndpointIntegrationTest` — 15 integration tests covering the full checkout
  validation chain: gate disabled, all server-side validation failures (submission, token,
  payment state, product), retry from failed/expired, and the happy-path with a mocked
  Stripe session.
- `WebhookEndpointIntegrationTest` — 12 integration tests covering webhook processing:
  missing/invalid signature, unsupported event types, completed/expired transitions,
  idempotency replay guard, currency/amount/metadata mismatch guards, and report
  generation on payment.
- `ReportDownloadIntegrationTest` — 7 integration tests covering the report download
  endpoint: no token, unpaid submission, valid token (triggers download header), token
  consumed after use, exhausted token, expired token, and cross-submission rejection.

### Fixed

- `is_checkout_feature_enabled()` and `implementation_ready_for_checkout()` now short-
  circuit to `true` when a test Stripe session is injected via
  `WPQ_Stripe::set_test_checkout_session()`, allowing integration tests to exercise the
  full checkout validation chain without real Stripe credentials.

## 1.11.11 - 2026-07-01

### Fixed

- `get_products_for_questionnaire` now filters out active products without a `stripe_price_id`,
  preventing a product card and checkout button appearing in the assessment UI for products that
  are not yet fully configured in Stripe. The server already rejected such requests with
  `PRODUCT_NOT_CONFIGURED`; this closes the frontend gap so the CTA is never shown.

## 1.11.10 - 2026-07-01

### Fixed

- REST route regex now accepts hyphenated refs (e.g. `QL-001`, `CS-01`); previously the pattern
  `[A-Z]{2,4}\d{2,4}` rejected any ref containing a hyphen, causing "We could not load the
  assessment" for all questionnaires imported from the batch files.
- Questionnaire bulk actions now include **Publish**, allowing imported questionnaires to be
  published in bulk without opening each one individually.

### Changed

- `wpq-import-batch-01.json` through `wpq-import-batch-06.json`: all 150 questionnaires changed
  from `"status": "draft"` to `"status": "published"` so they import as published by default.

## 1.11.9 - 2026-07-01

### Changed

- `ce-2026-danzell.json`: scoring and recommendations updated to align with the IASME Assessor
  Marking Scheme Danzell v9.0 (April 2026 edition).
  - **Auto-fail** (`finding_priority: critical`): A6.1 (unsupported OS), A6.4 (14-day OS/firmware patching),
    A6.5 (14-day application patching), A7.16 (admin MFA), A7.17 (user MFA).
  - **Non-compliance** (`finding_priority: medium`): A4.1–A4.7, A4.10, A5.1–A5.3, A5.5, A5.7–A5.9,
    A6.2, A6.3, A6.6, A7.2, A7.8, A7.9, A7.13, A8.1–A8.5. These allow up to 2 non-compliances
    across the whole assessment before certification is denied.
  - **Information-only** (`non_scoring`): A4.1.1, A4.9, A5.4, A7.14 corrected from scored to
    information-only — always marked compliant if answered, fail if blank.
  - All `recommendation` and `finding_action` fields updated with wording drawn directly from the
    IASME marking guide (requirement references, CE-compliant control descriptions).
  - Grade thresholds revised to reflect CE pass/fail structure: ≥95% = Compliant (≤2
    non-compliances), ≥85% = Minor Gaps, ≥70% = Significant Gaps, <70% = Non-Compliant.

## 1.11.8 - 2026-06-30

### Added

- `.sample_data/` directory containing questionnaire source data and pre-built WPQ JSON import files:
  - `ce-2026-danzell.json` — Cyber Essentials 2026 self-assessment (DANZELL v16, 106 questions across 8 domains, 38 scored) with extrapolated answer options, CE-compliant scoring, grade thresholds, and finding actions.
  - `wpq-import-batch-01.json` through `wpq-import-batch-06.json` — bulk import batches for the 150-questionnaire library (QL-001 to QL-150), 25 questionnaires per file.
  - Source xlsx files: `cyber_security_questionnaire_library.xlsx`, `_expanded.xlsx`, `_expanded_v2.xlsx`, `_expanded_v3.xlsx`.
  - `CE Marking Scheme and Assessor Guidance Danzell v9.0_GREEN 1.pdf` — IASME/NCSC assessor reference document.

## 1.11.7 - 2026-06-30

### Fixed

- Submission error banner is now dismissed (`hideError()`) on a successful submit, so a previous failed-validation warning no longer persists on the results screen.
- `single_option` (radio) questions now auto-generate a medium finding when the selected answer scores below the question maximum and no explicit `finding_priority`/`finding_action` is set on the option. Falls back to the question's `recommendation` field, or a derived sentence if that is also empty.

## 1.11.6 - 2026-06-30

### Fixed

- Radio/checkbox grid columns now use `max-content` so each column is exactly as wide as its longest label — no equal-width stretching, no wrapping. Grid is left-aligned within the question body with a 15 px column gap.

## 1.11.5 - 2026-06-30

### Fixed

- Radio and checkbox grid columns now use `minmax(max-content, 1fr)` so each column is at least as wide as its longest label, preventing text wrapping. Column gap reduced to 15 px.

## 1.11.4 - 2026-06-30

### Changed

- Select (combobox) now spans full width with rounded corners and consistent padding matching other input types.
- Short-text input no longer capped at 440 px — spans full width.
- Boolean and tri-state answer buttons are now centre-aligned within the question body.

## 1.11.3 - 2026-06-30

### Changed

- Radio and checkbox answer grids now use a dynamic column count based on the average option label length: 5 columns (≤ 50 chars), 4 (≤ 80), 3 (≤ 100), 2 (≤ 150), 1 (> 150). Column count is computed at render time in JS and applied as a `wpq-cols-N` class. Mobile (≤ 600 px) always collapses to a single column.

## 1.11.2 - 2026-06-30

### Fixed

- Radio and checkbox answer options now always render in a 2-column grid on desktop — changed from `repeat(auto-fill, minmax(180px, 1fr))` to `repeat(2, 1fr)` so the grid is stable regardless of the theme or page-builder column width.

## 1.11.1 - 2026-06-30

### Added

- **Import/Export on every list view** — Import and Export All buttons now appear in the top-right header of every admin list page (Questionnaires, Contacts, Orders, Pricing, Coupons, Settings).
- **Export Selected bulk action** — every table now has a checkbox column and an "Export selected" bulk action; selecting records and clicking GO POSTs the IDs to the export handler and triggers a browser file download.

### Fixed

- `$_POST['ids']` in `handle_export()` now correctly applies both `wp_unslash` and `sanitize_text_field` in a single pass, resolving the remaining PHPCS strict-security `InputNotSanitized` error.

## 1.11.0 - 2026-06-30

### Added

- **Import / Export** — new admin page (Settings → Import / Export) supporting full round-trip data transfer for all six entity types:
  - **Questionnaires** — full structure including domains, questions, answer options, and grade thresholds.
  - **Contacts & Submissions** — all submission data keyed by contact email.
  - **Orders** — payment session records linked to submissions and products.
  - **Pricing** — all product tiers, cross-referenced by questionnaire ref and slug.
  - **Coupons** — Stripe coupon/promo definitions with questionnaire and product linkage.
  - **Settings** — all 14 plugin option keys (Stripe + HaloPSA).
- Export: each entity type downloads as a dated JSON file via a dedicated admin-post handler (`wpq_export`).
- Import: drag-and-drop or file-browse upload; automatic conflict detection with per-record Skip / Overwrite resolution before applying; result summary shows imported and skipped counts plus any per-record errors.

## 1.10.4 - 2026-06-30

### Changed

- Answer options table: removed the "Active" column. All options are now always visible to respondents; `is_active` is hardcoded to 1 on save. Any options previously hidden (`is_active = 0`) are re-activated on upgrade (DB migration v1.20.0).

## 1.10.3 - 2026-06-30

### Changed

- Questionnaire Details tab: replaced the raw Price / Currency inputs with a read-only "Pricing" table that cross-references `wpq_products` for all price tiers linked to this questionnaire (name, billing type, GBP price, Stripe Price ID, status). A direct link to the Pricing admin page is included.

## 1.10.2 - 2026-06-29

### Changed

- Scoring tab: score inputs (Yes / Partial / No) are now displayed inline with their corresponding recommendation textarea rather than in separate columns. Each answer row shows its label, recommendation field, and score number in a single horizontal group. The separate Yes / Partial / No column headers have been removed.

## 1.10.1 - 2026-06-29

### Changed

- Scoring tab: "Guidance" column heading renamed to "Recommendations".
- Recommendation field placeholder updated to remove the word "Guidance".

## 1.10.0 - 2026-06-29

### Added

- **Guidance fields in Scoring tab**: Per-question guidance is now edited inside the scoring matrix rather than on the Questions editor page.
  - Boolean questions: separate True / False guidance fields.
  - Tri-state questions: separate Yes / Partial / No guidance fields.
  - Option-based questions (radio, select, checkbox): one guidance field per answer option.
  - Memo / non-scoring questions: no guidance fields (shown as "—").
- Database: `guidance_partial` column added to `wpq_questions`; `guidance` column added to `wpq_question_options` (migration v1.19.0).

### Changed

- Guidance fields removed from the Questions editor tab (they are now exclusively in the Scoring tab).
- Duplicate-questionnaire and export helpers carry the new `guidance_partial` and per-option `guidance` values through.

## 1.9.6 - 2026-06-29

### Changed

- Question numbering label changed from "QUESTION X OF Y" to "Q X:" and now appears inline with the question text (10 px gap, baseline-aligned) rather than on a separate line above it.
- Radio and checkbox option grids: strengthened CSS selector specificity (`.wpq-answers.wpq-answers-radio`) to guarantee the grid display overrides the parent flex rule on all browsers and WordPress caching configurations.

## 1.9.5 - 2026-06-29

### Fixed

- Key findings: label no longer shows the generic domain name "Questions" when no meaningful action text exists. The label now shows just the priority word ("Critical" / "Medium"); the finding body falls back to the question text when no recommendation or guidance is set. Questionnaires with proper recommendation text continue to show "Priority — Domain" as before.
- Scoring: `top_actions` now includes `question` so the JS can use the question text as a fallback body for library questionnaire findings.

## 1.9.4 - 2026-06-29

### Changed

- Radio and checkbox option lists now render in a responsive CSS grid (`auto-fill`, min 180 px per column) instead of a centred vertical stack. At typical desktop widths this produces 3–4 columns; narrows to 2 at tablet widths and 1 on mobile.
- Exclusive checkbox options (e.g. "None of these") span the full grid row and are separated by a hairline rule.
- Hint text ("Select up to N options") spans the full grid row via `grid-column: 1 / -1`.

## 1.9.3 - 2026-06-29

### Changed

- Admin menu: "All Submissions" → "Submissions", "Questionnaire Library" → "Questionnaires", "Pricing Catalogue" → "Pricing".
- Page headings updated to match: Questionnaires library page, questionnaire editor breadcrumb, and Pricing page.

## 1.9.2 - 2026-06-29

### Added

- **Library questionnaire scoring** (DB 1.18.0). All 18+ CSQ library questionnaires now ship with full scoring logic built in by default. Seven of the 15 template questions are scored per questionnaire:
  - Q04 / Q09 (`boolean`): Yes = 2, No = 0 — "Documented baseline" and "Exceptions recorded".
  - Q05 / Q06 (`sum_selected`, max 2): Each positive option scores 1 — "Control areas documented" and "Evidence available". Negative options ("None of these", "No evidence available") score 0.
  - Q07 (`single_option`, max 2): Review frequency — Never/Ad hoc = 0, Annually = 1, Monthly/Quarterly/Event-driven = 2.
  - Q08 (`single_option`, max 2): Maturity level — Not started/Informal = 0, Partially implemented = 1, Implemented/Managed = 2.
  - Q13 (`single_option`, max 2): Budget/project route — No budget/Unknown = 0, Under consideration = 1, Allocated/In progress = 2.
- `WPQ_Seeder::backfill_library_scoring()` — idempotent DB backfill that applies scoring modes and option scores to all existing library questions (`created_by_seed = 1, library_version IS NOT NULL`) that are still `non_scoring`. Runs automatically on plugin activation/upgrade.
- `WPQ_Questionnaire_Library_Importer::SCORING_DEFAULTS` and `OPTION_SCORE_DEFAULTS` constants — new imports get correct scoring applied at seed time without requiring the backfill.

## 1.9.1 - 2026-06-29

### Added

- **Orders admin page** (`wpq-orders` submenu). Read-only paginated sortable table of all Stripe payment sessions with contact email, contact name, questionnaire name, product name, payment status (colour-coded badge), amount, and truncated session ID.
- `WPQ_Database::get_orders()` and `WPQ_Database::count_orders()` — paginated/searchable query across `wpq_payment_sessions` joined to submissions, questionnaires, and products. Sortable by date, amount, status, or contact email.

### Fixed

- PHPStan `Variable on left side of ?? always exists and is not nullable` errors in `page-contacts.php` and `page-contact-detail.php`.
- PHPStan `Function paginate_links not found` and `Function add_query_arg invoked with 3 parameters` in Contacts list view.

## 1.9.0 - 2026-06-29

### Added

- **Contacts admin page** (`wpq-contacts` submenu). Aggregate view of all unique submitters grouped by email: submission count, completed count, paid count, last seen date, opt-out status. Searchable and sortable.
- **Contact detail page** (`?wpq_action=view&email=…`): contact info, full submission history, payment history, and a GDPR operations panel.
- **GDPR data-subject rights operations** on the contact detail page:
  - **Export data** — downloads all submission and payment data as a JSON file.
  - **Anonymise** — replaces name, email, company, phone, and IP address with anonymous placeholders. Scores preserved.
  - **Delete** — permanently hard-deletes all submissions for the contact and removes the contact preferences record.
  - **Mark opted-out / Remove opt-out** — records a marketing suppression preference without deleting data.
- `wpq_contact_preferences` DB table (DB 1.17.0): stores per-email opt-out preference with timestamp and acting user ID.
- `WPQ_Database` contact methods: `get_contacts()`, `count_contacts()`, `get_contact_submissions()`, `get_contact_payments()`, `export_contact_data()`, `anonymise_contact()`, `delete_contact()`, `get_contact_opt_out()`, `set_contact_opt_out()`.
- AJAX action `wpq_toggle_contact_opt_out`; POST handlers `wpq_export_contact`, `wpq_anonymise_contact`, `wpq_delete_contact`.

## 1.8.9 - 2026-06-29

### Added

- **Questionnaire Categories** managed from Settings → Categories tab (DB 1.16.0). New `wpq_categories` table with slug, name, and sort order. Ten pre-populated categories: Cyber Security, Data Privacy, Business Continuity, Risk & Compliance, Operational Resilience, IT Governance, Supplier Risk, Cloud Security, Physical Security, HR & People Security.
- Full AJAX CRUD in the Categories tab: add category (name auto-generates slug), inline edit (name and sort order), delete with confirmation.
- Questionnaire Library and New Questionnaire modal now populate the category dropdown from the DB instead of a hardcoded array.
- `WPQ_Database::seed_categories()`, `get_categories()`, `insert_category()`, `update_category()`, `delete_category()`, `category_slug_exists()`.
- AJAX actions: `wpq_create_category`, `wpq_update_category`, `wpq_delete_category`.

### Changed

- Existing `wpq_questionnaires.category` slugs are remapped on upgrade: `it_managed_services` → `it_governance`, `isms` / `business_management` / `risk_management` → `risk_compliance`.

## 1.8.8 - 2026-06-29

### Added

- Sortable columns on all admin tables: Questionnaire Library, Pricing Catalogue, and Coupons tables now support client-side column sorting (click any header to sort ascending/descending; action and checkbox columns excluded). Submissions table already had server-side sorting via `WP_List_Table`; extended to cover Contact, Questionnaire, Grade, Abandoned, HaloPSA Status, and UTM Source columns in addition to the existing Ref, Score, and Date columns.
- Renamed "Assessment Submissions" page heading to "Submissions".

## 1.8.7 - 2026-06-29

### Added

- **Coupons & Promo Codes** admin page (`wpq-coupons` submenu). Create Stripe coupons (percent off or fixed amount off) with optional customer-facing promotion codes, duration control, max redemptions, and expiry. Coupons can be scoped to all products, a specific questionnaire (Stripe Product), or a specific pricing catalogue item.
- `WPQ_Stripe::create_coupon()`, `create_promotion_code()`, `delete_coupon()` — Stripe SDK wrappers for coupon lifecycle management.
- `wpq_coupons` DB table (DB 1.15.0): stores coupon metadata locally alongside Stripe IDs for display and association tracking.
- `WPQ_Database::insert_coupon()`, `get_all_coupons()`, `get_coupon()`, `update_coupon()` — CRUD methods for the coupons table.
- AJAX actions `wpq_create_coupon` and `wpq_delete_coupon`: create/archive in Stripe with rollback on DB failure; delete gracefully handles already-archived Stripe coupons.

## 1.8.6 - 2026-06-29

### Added

- New `recommendation` field on `wpq_questions` (DB 1.14.0): stores the actionable text shown in the results report when a respondent answers No. Separate from `guidance_no`, which is the inline contextual help displayed to respondents during the questionnaire.
- `WPQ_Seeder::backfill_recommendation()`: idempotent migration that copies `guidance_no` → `recommendation` for every existing question where `recommendation` is empty and `guidance_no` is set, preserving current report output on upgrade.
- Recommendation textarea in the question editor (visible for `boolean`/`tri_state` types only, same row-visibility rule as Guidance). Placeholder text indicates it falls back to Guidance — No when left blank.

### Changed

- Scoring engine (`WPQ_Scoring`) now uses `recommendation` as the finding `action` text for `legacy_tri_state` and `boolean` questions; falls back to `guidance_no` when `recommendation` is empty (backward-compatible).
- `WPQ_Seeder::insert_q()` now seeds `recommendation` from the question's `recommendation` key, defaulting to `guidance_no` if not explicitly set.

## 1.8.5 - 2026-06-29

### Added

- `WPQ_Seeder::backfill_option_scores()`: idempotent enrichment pass that assigns default scores to every radio/checkbox/select/combobox question whose scoring mode is `single_option`, `sum_selected`, or `max_selected` and where ALL options currently have `score = 0`. `sum_selected` (checkbox) options each receive `score = 1`; `single_option`/`max_selected` (radio/select) options receive descending scores by sort order (first option = N-1, last = 0). Questions with any non-zero option score are left untouched.
- DB version bumped to 1.13.0 to trigger the backfill pass on existing installs.

### Fixed

- Question editor: new options added via `+ Add option` now default to `score = 1` instead of `0`, ensuring every option-based question contributes to the domain score from the moment options are added.

## 1.8.4 - 2026-06-29

### Fixed

- `.wpq-hidden` now uses `display: none !important` so utility-class visibility is never overridden by element-specific `display` rules (e.g. `.wpq-q-scores { display: flex }` was winning over `.wpq-hidden`).
- Question editor: Guidance Yes/No fields are now hidden for non-boolean/tri-state question types (radio, checkbox, select, memo), matching the same condition as the Scores row. Both PHP initial render and the JS type-change handler updated.
- Question editor: "Help text" label renamed to "Tip". An ⓘ icon appears to the right of the question textarea when a tip is set; it is hidden when no tip exists. Clicking the icon focuses the Tip input. The icon updates live as you type.

## 1.8.3 - 2026-06-26

### Fixed

- Question editor: options manager (`+ Add option` / edit / delete rows) is now always rendered in the DOM and toggled visible by the type dropdown. Previously it was conditionally omitted for non-option types (`tri_state`, `boolean`, `memo`), so switching a question to `radio`, `checkbox`, or `select` showed no options panel because the element did not exist.
- Question editor: "New Questionnaire" modal auto-opening on page load resolved by removing `display:flex` from the modal's static inline style — the CSS class `wpq-hidden` (`display:none`) was being overridden by the higher-specificity inline style.

## 1.8.2 - 2026-06-26

### Fixed

- `get_questionnaire_list()`: rewrote query to use non-correlated derived tables so each physical table is referenced exactly once, fixing MySQL "Can't reopen table" errors caused by the WordPress test suite's use of `TEMPORARY TABLE`.
- Library table Status column: replaced HTML-string `$status_labels` with CSS-class-based rendering to prevent WordPress escaping functions from outputting raw HTML.
- Library table Domains/Questions columns: use `(int)` cast instead of `absint()` (PHPStan lacked WordPress stubs for the view file).
- Library table Scoring/Grading tick/cross: use `esc_attr()` on class attribute and HTML entities for the symbol characters.
- `ajax_bulk_questionnaire_action()`: split compound one-liner statements onto separate lines to satisfy PHPCS `DisallowMultipleStatements`.

### Changed

- Admin menu: "Site Health" renamed to "Readiness".
- Admin menu: "Products" renamed to "Pricing Catalogue".
- Readiness page: title updated to "Readiness"; Payment Readiness section added (checkout flag, pricing configured, Stripe API, libraries, routes, report generation, token delivery).
- Pricing Catalogue page: Payment Readiness checklist moved to the Readiness page; page now shows only the pricing options table.
- All "Product/Products" labels in the Pricing Catalogue page and JS updated to "Pricing option/Pricing options".

## 1.8.1 - 2026-06-24

### Added

- Questionnaire Library table: Domains column (count), Questions column (count), Scoring column (✓ if any scored questions exist), Grading column (✓ if grade thresholds exist).
- `WPQ_Seeder::enrich_library_questionnaires()`: idempotently adds a default "Questions" domain and A–E grade thresholds to any questionnaire missing them.
- `WPQ_Database::get_questionnaire_list()` now returns `domain_count`, `question_count`, `grade_count`, and `scored_question_count` via subqueries.

### Changed

- DB schema version bumped to `1.12.0` to trigger `enrich_library_questionnaires()` on existing installs.

## 1.8.0 - 2026-06-24

### Added

- `stripe_price` (INT pence) and `stripe_currency` (VARCHAR 3, default GBP) columns on `wpq_questionnaires`.
- `domain_weight` (SMALLINT, default 100) column on `wpq_domains`.
- `question_weight` (SMALLINT, default 100) column on `wpq_questions`.
- Questionnaire Library: NEW button with modal to create a blank questionnaire.
- Questionnaire Library: per-row SELECT checkboxes with ACTIONS dropdown + GO button (Archive, Unarchive, Remove, Duplicate).
- Questionnaire Library: price rendered as currency symbol + value (e.g. `£ 49.99`).
- Questionnaire editor: split into 5 tabs — Details, Domains, Questions, Scoring, Grades.
- Details tab: Stripe Price and Currency fields.
- Domains tab: ADD / EDIT / REMOVE domains; auto-labelled A, B, C… by sort order.
- Questions tab: domain selector per question; question label shows domain + position (e.g. C2); Add Question and Delete Question per domain.
- Scoring tab: Domain Weights table; Question Scoring Matrix (per-question weight + answer scores inline).
- Grades tab: grade thresholds table (unchanged content, now its own tab).
- `WPQ_Database::delete_domain()`, `delete_question()`, `delete_questionnaire()`, `duplicate_questionnaire()`.
- AJAX actions: `wpq_create_questionnaire`, `wpq_bulk_questionnaire_action`, `wpq_add_domain`, `wpq_update_domain`, `wpq_delete_domain`, `wpq_save_domain_weight`, `wpq_add_question`, `wpq_delete_question`, `wpq_save_question_scoring`.

### Changed

- `wpq_save_questionnaire` AJAX now accepts `stripe_price` and `stripe_currency`.
- `wpq_save_question` AJAX now accepts optional `domain_id` (moves question to a different domain).
- DB schema version bumped to `1.11.0`.

## 1.7.4 - 2026-06-24

### Added

- `[wpq_title ref="CSQ001"]` shortcode: returns the questionnaire name (published only).
- `[wpq_description ref="CSQ001"]` shortcode: returns the questionnaire description (published only).
- `[wpq_questions ref="CSQ001"]` shortcode: returns the total question count.
- `[wpq_estimate ref="CSQ001"]` shortcode: returns estimated completion time — 42 s per question, rounded up, formatted as "X minutes".
- `stripe_product_id` column on `wpq_questionnaires`: stores the Stripe Product ID for each questionnaire.
- Stripe Product ID is visible in the Questionnaire Library table and editable from the questionnaire Details tab.

### Changed

- DB schema version bumped to `1.10.0`.

## 1.7.3 - 2026-06-24

### Changed

- Questionnaire title (`.wpq-step-header h2`): Poppins, weight 600, 1.6 em.

## 1.7.2 - 2026-06-24

### Fixed

- `white-space: normal` added to `.wpq-wrap` — prevents the ~500 px blank-space bug that occurs when the shortcode is placed inside a Gutenberg "Preformatted" (`<pre>`) block, which sets `white-space: preserve` and renders every blank line in the plugin template as visible space.
- Removed `min-height: 200px` from `.wpq-wrap` (unnecessary now that all hidden steps use `display: none`).

## 1.7.1 - 2026-06-24

### Fixed

- Reduced excess whitespace in the lead capture step: `step-header` margin-bottom 32 → 16 px, lead form padding 32 → 20/24 px, loading spinner padding 60 → 32 px.

## 1.7.0 - 2026-06-24

### Changed

- Assessment frontend completely restyled.
- Questions rendered in Poppins 11 pt; all answer controls, buttons, and inputs in Aptos 10 pt.
- Help text replaced by an inline `ⓘ` icon adjacent to the question; tooltip reveals on hover or keyboard focus — no longer always visible.
- Yes/No and tri-state answer buttons vertically centred within their row.
- Memo textarea expands to full panel width; character counter sits right-aligned below it.
- Select, radio, checkbox, and short-text inputs styled consistently (Aptos, matching border/focus-ring treatment).
- Single-domain questionnaires hide the domain tab bar and redundant domain heading automatically.
- Question panel padding reduced (28 → 20 px), question spacing reduced (28 → 20 px), domain-heading margin tightened (24 → 16 px), minimum panel height removed.
- Grade threshold editor: `+ Add Grade` and `Delete` buttons added to Scoring & Grades tab in the questionnaire editor.

## 1.6.2 - 2026-06-24

### Added

- Grade threshold management in the questionnaire editor: new `+ Add Grade` button creates a default grade row inline without a page reload; new `Delete` button on each row removes it with a confirmation prompt.

## 1.6.1 - 2026-06-24

### Fixed

- `condition_op NOT NULL` constraint violation: CS01 seeder was passing explicit `NULL` for `condition_op` on questions without conditional visibility; MySQL strict mode rejected this even though the column has `DEFAULT 'eq'`. Fixed by defaulting to `'eq'` in `insert_q()`.
- `[wpq_assessment ref="CSQxxx"]` shortcodes showed "Assessment not found": library questionnaires were seeded as `draft` but `get_questionnaire_by_ref()` requires `status = 'published'`. Fixed by seeding library questionnaires as `published` and promoting any existing `draft` library records on activation.
- REST questionnaire route regex (`[A-Z]{2}-\d{2}`) rejected `CS01` and all `CSQ001`–`CSQ150` refs. Widened to `[A-Z]{2,4}\d{2,4}`.
- Integration tests used old `CS-01` ref throughout; updated to `CS01`.

## 1.6.0 - 2026-06-24

### Added

- Cyber Security Questionnaire Library (`1.0.0`): 150 questionnaires, 2,250 questions, 10,750 options imported from `cyber_security_questionnaire_library.xlsx` and committed as `includes/data/questionnaire-library-1.0.0.php`.
- New `WPQ_Questionnaire_Library_Importer` class: reads the committed seed data file and inserts questionnaires idempotently on activation. Skips questionnaires already owned by the library (`created_by_seed = 1`) and never overwrites customised records (`is_customised = 1`).
- New question type `number`: free-form numeric input; always resolves to `non_scoring`; validated with `is_numeric()`.
- DB migration `1.9.0`: new columns on `wpq_questionnaires` (`source_type`, `source_sheet`, `library_version`, `library_id`, `library_family`, `created_by_seed`, `is_customised`); new columns on `wpq_questions` (`answer_type_raw`, `created_by_seed`, `library_version`); `number` added to the `question_type` ENUM; new column `created_by_seed` on `wpq_question_options`; new `wpq_library_log` table for diagnostics.
- `WPQ_Seeder::seed_library()`: called on activation after CS01 seeding; delegates to `WPQ_Questionnaire_Library_Importer::import()`.
- Library questionnaires seeded with `status = 'draft'` and default `scoring_mode = 'non_scoring'`; each gets a single auto-created domain with `slug = 'general'`.
- Column E guidance preserved as `help_text` on each question.
- 41 PHPUnit test cases in `tests/Unit/LibraryTest.php` covering seed file structure, data completeness, type mapping, option fidelity, idempotency, scoring engine compatibility, and legacy backwards compatibility.
- `includes/data/` excluded from PHPCS scanning (generated file; causes OOM in the duplicate-key sniff).

### Changed

- Plugin version bumped to `1.6.0`; DB version to `1.9.0`.
- `WPQ_Scoring::resolve_scoring_mode()`: `number` joins `memo` and `short_text` as always `non_scoring`.
- `WPQ_Scoring::validate()`: `number` case added — rejects non-numeric input.
- `WPQ_Admin::$valid_types`: `number` added to the admin question-type selector.
- `WPQ_Questionnaire_Library_Importer::import()` uses `WPQ_PLUGIN_DIR` constant instead of `plugin_dir_path()` for test compatibility.

### Backwards Compatibility

- Existing CS01 (DANZELL CE 2026) is not affected by the library import; library uses separate `CSQ001–CSQ150` refs.
- All prior submissions, scores, and questionnaire customisations are preserved.
- New columns are nullable or have zero defaults; existing records continue to function without change.

## 1.5.0 - 2026-06-24

### Added

- New question type `short_text` (free-text single-line input, always `non_scoring`).
- New scoring mode `reverse_boolean`: answering "no" is compliant and scores `score_no` points; answering "yes" triggers a finding using `guidance_yes` as the action text.
- New columns on `wpq_questions`: `question_ref` (display reference e.g. `A4.3`), `min_selections`, `max_selections` (checkbox cardinality enforcement), `condition_on_ref`, `condition_value`, `condition_op` (conditional visibility by ref string; resolved to `di_qi` key in `get_questionnaire_structure()`).
- New columns on `wpq_question_options`: `requires_notes` (free-text note required when option selected), `exclusive` (selecting this option invalidates all other selections).
- Source metadata columns on `wpq_questionnaires`: `source_name`, `source_question_set`, `source_effective_date`, `source_version`, `source_file` — supports questionnaire library versioning.
- Conditional visibility in the frontend assessment: questions with `condition` are shown or hidden based on the referenced question's current answer; hidden questions are excluded from scoring and validation.
- CyberCheck - Security Assessment (`CS01`) seeded with the full Cyber Essentials 2026 DANZELL self-assessment question set (Version 16, effective 27 April 2026): 10 domains, 76 questions, grade thresholds at 90 / 70 / 50 / 0 percent, and two products (CyberCheck Professional Report £49, CyberCheck Annual Plan £99).
- `WPQ_Seeder::seed_cs01_update()` public method to bump source metadata when a newer question-set version is available.

### Changed

- DB schema version bumped to `1.8.0`.
- `WPQ_Seeder::seed_all()` now checks for `CS01` (was `CS-01`).
- Existing `CS-01` questionnaire ref renamed to `CS01` via migration on first activation after upgrade.
- `WPQ_Scoring::validate()` enforces `min_selections` / `max_selections` for checkbox questions and the `exclusive` flag; hidden (condition-not-met) questions are skipped.
- `WPQ_Scoring::score()` skips hidden questions; `reverse_boolean` mode scores `score_no` on "no" and records a finding on "yes".
- Frontend assessment sends `question_ref` alongside `domain_slug` and `question_index` in answer payloads to support ref-based condition resolution.

### Backwards Compatibility

- All existing questionnaire data, submissions, and scoring results are unaffected.
- New columns are nullable or have zero defaults; existing questions without the new fields continue to function as before.

## 1.4.0 - 2026-06-23

### Added

- Introduced a multi-type question model extending the legacy `tri_state` (Yes / Partial / No) model with `boolean`, `select`, `radio`, `checkbox`, and `memo` question types.
- Added `wpq_question_options` table for option-based answer types; supports `option_key`, `option_label`, `score`, `risk_level`, `finding_priority`, `finding_action`, `sort_order`, `is_default`, and `is_active`.
- New columns on `wpq_questions`: `question_type`, `is_required`, `scoring_mode`, `max_score`, `help_text`.
- Six scoring modes: `legacy_tri_state`, `boolean`, `single_option`, `sum_selected`, `max_selected`, `non_scoring`.
- Type-aware validation in `WPQ_Scoring::validate()`: `boolean` rejects `partial`; `select`/`radio` validate against active option keys; `checkbox` accepts arrays; `memo` sanitises strings and enforces max length.
- Updated scoring engine to handle all six modes; `non_scoring` questions excluded from denominator.
- Public questionnaire REST response now includes `question_type`, `is_required`, `scoring_mode`, `max_score`, and active options per question.
- Frontend assessment renders question-type-specific controls: Yes/Partial/No buttons, Yes/No buttons, `<select>`, radio inputs, checkboxes, and textarea.
- Admin questionnaire editor now exposes question type selector, is-required toggle, scoring mode, max score, help text, and an inline options manager for option-based types.
- New admin AJAX handlers: `wpq_save_question_option`, `wpq_delete_question_option`.

### Changed

- DB schema version is now `1.7.0`.
- `WPQ_Scoring::validate()` and `::score()` are now type-aware; all existing `tri_state` questions remain fully backwards-compatible.
- `WPQ_Database::get_questionnaire_structure()` includes new question fields and active options.

### Backwards Compatibility

- Existing `tri_state` questions (without `question_type`) default to `legacy_tri_state` scoring; no data loss.
- Legacy `score_yes`, `score_partial`, `score_no` columns preserved; not removed in this phase.
- Existing `answers_json` remains readable.

## 1.3.1 - 2026-06-23

### Fixed

- Fatal error on activation: `WPQ_Submissions_Table::extra_tablenav` and `column_default` declared narrower parameter types than `WP_List_Table`, which PHP 8.0+ enforces as a fatal incompatibility.
- `table_exists()` now uses `SELECT 1 FROM table LIMIT 0` with `suppress_errors()` instead of `SHOW TABLES LIKE`, eliminating MySQL 8.0 LIKE-pattern escaping false negatives.
- Integration tests: replaced `INFORMATION_SCHEMA.COLUMNS` queries with `SHOW COLUMNS FROM … LIKE`, since the WordPress test framework creates temporary tables that `INFORMATION_SCHEMA` does not expose.

### Changed

- GitHub Actions bumped to Node.js 24-compatible versions: `actions/checkout@v7`, `actions/cache@v6`, `actions/upload-artifact@v7`.
- Release workflow now creates a GitHub Release with the ZIP attached when triggered by a `v*` tag; `workflow_dispatch` from a branch runs checks only.

## 1.3.0 - 2026-06-22

### Added

- Implemented Phase 3 one-off Stripe Checkout flow for completed assessments.
- Added `POST /wpq/v1/checkout`, `POST /wpq/v1/stripe/webhook`, and `GET /wpq/v1/reports/{id}`.
- Added Stripe SDK wrapper for Checkout Session creation and webhook signature verification.
- Added Dompdf report rendering, plugin-owned report storage, and signed report-token delivery.
- Added `wpq_report_tokens` for hashed, expiring report download tokens.
- Added expected `amount_total` and `currency` fields to `wpq_payment_sessions`.
- Added report reference fields to submissions: `report_product_id`, `report_path`, `report_generated_at`, and `report_error`.
- Added admin submission payment/report visibility.
- Added production readiness dashboard at Settings → Site Health, aggregating plugin version, DB version, schema health, Stripe configuration, report storage, REST routes, HaloPSA API role, submission sync counts, and recent migration errors.
- Expanded HaloPSA sync state machine from 4 to 8 states: `pending`, `processing`, `synced`, `failed`, `retry_pending`, `ignored`, `manual_review`, `skipped`.
- Added `halopsa_last_attempted_at`, `halopsa_retry_count`, and `halopsa_sync_error` columns to `wpq_submissions` to support external pull-worker operation.
- Added `POST /wpq/v1/api/submissions/{id}/start` — claims a submission for processing, transitions to `processing`, and records the attempt timestamp; rejects terminal states with HTTP 409.
- Added `POST /wpq/v1/api/submissions/{id}/fail` — records a failed sync attempt; `"retry": true` queues the submission as `retry_pending`, `"retry": false` marks it permanently `failed`.
- Pending submission export (`GET /wpq/v1/api/submissions/pending`) now includes `retry_pending` submissions alongside `pending` ones.
- Added bin/check-versions.sh version-alignment script; CI enforces plugin header == WPQ_VERSION constant == CHANGELOG heading on every push; release workflow additionally enforces tag match and no ## Unreleased section.
- Added WordPress integration test suite (`tests/integration/`) covering role/capability creation, REST authentication (401/403/200), public endpoint payload validation, schema migration verification, report-token lifecycle, and Stripe webhook idempotency. CI provisions a MySQL service and runs the suite automatically.
- Improved admin Settings UX: section-specific save confirmations, per-field Stripe key format feedback, diagnostics JSON export, copy-to-clipboard buttons for API endpoint URLs, test-access curl guide, and full pull-worker lifecycle example.
- Added data retention controls: configurable purge threshold for abandoned sessions, configurable anonymisation threshold for completed assessments (preserves scores), CSV export of purgeable submissions before purging, per-operation confirmation dialogs, and retention diagnostics in Settings → Advanced.

### Changed

- Database schema version is now `1.6.0`.
- Public product exposure remains gated by `WPQ_CHECKOUT_ENABLED` plus all Phase 3 capability checks.
- Payment remains webhook-confirmed only; checkout redirect success does not mark submissions as paid.

### Migration Notes

- Existing payment sessions gain nullable `amount_total` and `currency` columns.
- Existing submissions gain nullable report reference/error columns.
- New installs and upgrades create `wpq_report_tokens`.
- Existing `halopsa_sync_status` ENUM is widened to 8 values; `halopsa_last_attempted_at`, `halopsa_retry_count`, and `halopsa_sync_error` are added with safe defaults and no data loss.

### Upgrade Notes

- Configure Stripe keys and webhook secret via constants/environment variables where possible.
- Set `WPQ_CHECKOUT_ENABLED` only after confirming Settings → Site Health and checkout readiness are green.

### Rollback Notes

- Back up the database and generated reports before downgrading from DB version `1.6.0`.

## 1.2.0 - 2026-06-20

- Plugin version: 1.2.0.
- Database schema version: 1.4.0.

### Added

- Added security-focused CI checks, PHPStan, PHPUnit suites, and release ZIP automation.
- Added migration diagnostics for DB version, migration errors, expired sessions, and schema health.
- Added soft-delete support for submissions and centralized payment status transitions.
- Added checkout readiness checks for required routes, Stripe/Dompdf libraries, and Stripe secret resolution.
- Added a release manifest (`release.json`) to release ZIPs with commit, ref, build time, plugin version, and DB version.
- Added diagnostics-only strict schema checks for critical indexes, column types, enum values, and nullability.
- Added packaged-plugin smoke loading to the release workflow.
- Added `wpq_payment_events` for future Stripe webhook idempotency and audit trails.
- Added payment-event database helpers for webhook idempotency and processing audit records.
- Added `Phase3Spec.md` covering checkout, webhook, and report-delivery route contracts.

### Changed

- Stripe publishable key, secret key, and webhook secret now resolve from plugin constants first, server environment variables second, and WordPress options last.
- Product slugs remain immutable when products are renamed.
- Checkout readiness now labels Phase 3 endpoint handlers as intentionally not implemented instead of generic missing routes.
- Release ZIP builds now validate extracted version metadata, packaged PHP syntax, required packaged files, and `release.json`.
- Public product exposure now requires the full Phase 3 checkout capability contract, not only `WPQ_CHECKOUT_ENABLED`.
- Payment sessions now use the same payment status vocabulary as submissions: `none`, `pending`, `paid`, `failed`, and `expired`.

### Security Fixes

- Admin submission delete actions now report actual successful and failed soft-delete counts.
- Checkout readiness no longer treats stored option values alone as production readiness.

### Migration Notes

- Schema upgrades target DB version 1.4.0.
- Migration diagnostics report missing tables/columns and recorded migration errors.
- Older in-progress plaintext session tokens may be expired during the token-hash migration.
- Older payment-session rows using `unpaid` are migrated to `pending`.

### Breaking Changes

- None currently expected for public questionnaire embeds.

### Upgrade Notes

- Review Settings -> Diagnostics after deployment and confirm the installed DB version matches 1.4.0.
- Prefer `WPQ_STRIPE_SECRET_KEY` or `STRIPE_SECRET_KEY` for production Stripe secrets instead of storing secrets in WordPress options.

### Rollback Notes

- Back up the WordPress database before upgrading production sites.
- If rolling back after a schema migration, verify custom table compatibility manually before reactivating an older plugin build.

Compatibility notes:

- Requires PHP 8.1+ and WordPress 6.4+.
- Current database schema version: 1.4.0.
