<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_REST_API {
	private const REPORT_DOWNLOAD_HEADER = 'X-WPQ-Report-Download';

	/** @var array<string, string> */
	private static array $report_download_paths = [];

	public static function checkout_capabilities(): array {
		return [
			'checkout'                => method_exists( self::class, 'create_checkout' ) && class_exists( 'WPQ_Stripe' ),
			'webhook'                 => method_exists( self::class, 'stripe_webhook' ) && method_exists( 'WPQ_Database', 'insert_payment_event' ),
			'report_delivery'         => method_exists( self::class, 'download_report' ) && method_exists( 'WPQ_Database', 'consume_report_token' ),
			'report_template'         => class_exists( 'WPQ_Report_Renderer' ) && WPQ_Report_Renderer::template_available(),
			'report_renderer'         => class_exists( 'WPQ_Report_Renderer' ) && WPQ_Report_Renderer::can_render(),
			'report_storage_delivery' => class_exists( 'WPQ_Report_Renderer' ) && WPQ_Report_Renderer::storage_available(),
			'stripe_api_initialised'  => class_exists( 'WPQ_Stripe' ) && WPQ_Stripe::can_initialise(),
		];
	}

	public static function is_checkout_publicly_available(): bool {
		if ( ! ( defined( 'WPQ_CHECKOUT_ENABLED' ) && WPQ_CHECKOUT_ENABLED ) ) {
			return false;
		}

		$capabilities = self::checkout_capabilities();
		foreach ( [ 'checkout', 'webhook', 'report_delivery', 'report_template', 'report_renderer', 'report_storage_delivery', 'stripe_api_initialised' ] as $capability ) {
			if ( empty( $capabilities[ $capability ] ) ) {
				return false;
			}
		}

		return true;
	}

	public static function register_routes(): void {
		// Questionnaire structure (public — no auth needed).
		register_rest_route( WPQ_REST_NAMESPACE, '/questionnaire/(?P<ref>[A-Z][A-Z0-9_-]{1,29})', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'get_questionnaire' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'ref' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// Lead capture.
		register_rest_route( WPQ_REST_NAMESPACE, '/lead', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'submit_lead' ],
			'permission_callback' => '__return_true',
		] );

		// Heartbeat (update last answered question).
		register_rest_route( WPQ_REST_NAMESPACE, '/heartbeat', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'heartbeat' ],
			'permission_callback' => '__return_true',
		] );

		// Assessment submission.
		register_rest_route( WPQ_REST_NAMESPACE, '/submit', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'submit_assessment' ],
			'permission_callback' => '__return_true',
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/checkout', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'create_checkout' ],
			'permission_callback' => '__return_true',
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/stripe/webhook', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'stripe_webhook' ],
			'permission_callback' => '__return_true',
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/reports/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'download_report' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );
	}

	// ------------------------------------------------------------------ //
	// GET /wpq/v1/questionnaire/{ref}
	// ------------------------------------------------------------------ //

	public static function get_questionnaire( WP_REST_Request $request ): WP_REST_Response {
		$ref           = strtoupper( sanitize_text_field( $request->get_param( 'ref' ) ) );
		$questionnaire = WPQ_Database::get_questionnaire_by_ref( $ref );

		if ( ! $questionnaire ) {
			return self::error( 404, 'NOT_FOUND', 'Questionnaire not found.' );
		}

		$structure = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		// Products are only surfaced when the Stripe checkout is deployed (Phase 3).
		$checkout_available = self::is_checkout_publicly_available();
		$products  = $checkout_available
			? WPQ_Database::get_products_for_questionnaire( (int) $questionnaire->id )
			: [];

		return new WP_REST_Response( [
			'status'        => 'ok',
			'ref'           => $questionnaire->ref,
			'name'          => $questionnaire->name,
			'description'   => $questionnaire->description,
			'domains'       => $structure['domains'],
			'thresholds'    => $structure['thresholds'],
			'products'      => array_map( fn( $p ) => [
				'id'                     => (int) $p->id,
				'name'                   => $p->name,
				'slug'                   => $p->slug,
				'description'            => $p->description,
				'price_gbp'              => (float) $p->price_gbp,
				'billing_type'           => $p->billing_type,
				'report_type'            => $p->report_type,
				'available_for_checkout' => $checkout_available,
			], $products ),
		], 200 );
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/lead
	// ------------------------------------------------------------------ //

	public static function submit_lead( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'lead', 5, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$ref = strtoupper( sanitize_text_field( $body['ref'] ?? '' ) );
		if ( ! $ref ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Missing questionnaire ref.' );
		}

		$questionnaire = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $questionnaire ) {
			return self::error( 404, 'NOT_FOUND', 'Questionnaire not found.' );
		}

		$name    = substr( sanitize_text_field( $body['contact_name']    ?? '' ), 0, 255 );
		$email   = substr( sanitize_email(     $body['contact_email']   ?? '' ), 0, 254 );
		$company = substr( sanitize_text_field( $body['contact_company'] ?? '' ), 0, 255 );
		$phone   = substr( preg_replace( '/[^\d\s\+\(\)\-]/', '', $body['contact_phone'] ?? '' ), 0, 30 );

		if ( ! $name || ! $email || ! $company ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Name, email, and company are required.' );
		}

		if ( ! is_email( $email ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Email address is not valid.' );
		}

		$now        = current_time( 'mysql', true );
		$token      = bin2hex( random_bytes( 32 ) );
		// session_token column stores HMAC-SHA256 keyed with wp_salt('auth'); the raw token is never persisted.
		$token_hash = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
		$consented  = ! empty( $body['consent'] ) ? $now : null;
		$id         = WPQ_Database::create_submission( [
			'questionnaire_id'    => (int) $questionnaire->id,
			'contact_name'        => $name,
			'contact_email'       => $email,
			'contact_company'     => $company,
			'contact_phone'       => $phone,
			'consent_accepted_at' => $consented,
			'session_token'       => $token_hash,
			'abandoned'           => 1,
			'halopsa_sync_status' => 'pending',
			'started_at'          => $now,
			'utm_source'         => substr( sanitize_text_field( $body['utm_source']   ?? '' ), 0, 255 ) ?: null,
			'utm_medium'         => substr( sanitize_text_field( $body['utm_medium']   ?? '' ), 0, 255 ) ?: null,
			'utm_campaign'       => substr( sanitize_text_field( $body['utm_campaign'] ?? '' ), 0, 255 ) ?: null,
			'utm_term'           => substr( sanitize_text_field( $body['utm_term']     ?? '' ), 0, 255 ) ?: null,
			'utm_content'        => substr( sanitize_text_field( $body['utm_content']  ?? '' ), 0, 255 ) ?: null,
			'referrer_url'       => substr( esc_url_raw( $body['referrer_url']  ?? '' ), 0, 2048 ) ?: null,
			'landing_page'       => substr( esc_url_raw( $body['landing_page']  ?? '' ), 0, 2048 ) ?: null,
			'ip_address'         => self::get_client_ip(),
		] );

		if ( ! $id ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not create submission.' );
		}

		return new WP_REST_Response( [
			'status'        => 'ok',
			'submission_id' => $id,
			'session_token' => $token,
			'ref'           => sprintf( 'WPQ-%s-%04d', gmdate( 'Ymd' ), $id ),
		], 201 );
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/heartbeat
	// ------------------------------------------------------------------ //

	public static function heartbeat( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'heartbeat', 30, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body          = $request->get_json_params();
		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token         = sanitize_text_field( $body['session_token'] ?? '' );
		$last_key      = sanitize_text_field( $body['last_question'] ?? '' );

		if ( ! $submission_id || ! $token || ! $last_key ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id, session_token, and last_question are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}

		if ( ! WPQ_Database::update_submission( $submission_id, [
			'last_question_answered' => $last_key,
		] ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission.' );
		}

		return new WP_REST_Response( [ 'status' => 'ok' ], 200 );
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/submit
	// ------------------------------------------------------------------ //

	public static function submit_assessment( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'submit', 10, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token         = sanitize_text_field( $body['session_token'] ?? '' );
		$answers       = $body['answers'] ?? null;

		if ( ! $submission_id || ! $token || ! is_array( $answers ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id, session_token, and answers are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission record not found.' );
		}

		if ( ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}

		// Prevent replaying a session token to overwrite an already-completed submission.
		if ( $submission->completed_at ) {
			return self::error( 409, 'ALREADY_COMPLETED', 'This assessment has already been submitted.' );
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			return self::error( 404, 'NOT_FOUND', 'Questionnaire not found.' );
		}

		$structure  = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		$validation = WPQ_Scoring::validate( $answers, $structure );

		if ( $validation !== true ) {
			return self::error( 400, $validation['code'], $validation['message'] );
		}

		$result = WPQ_Scoring::score( $answers, $structure );
		$now    = current_time( 'mysql', true );
		$started = $submission->started_at ?? $now;
		$duration = max( 0, strtotime( $now ) - strtotime( $started ) );

		if ( ! WPQ_Database::update_submission( $submission_id, [
			'overall_score'         => $result['overall_score'],
			'grade_id'              => $result['grade']['grade_id'],
			'answers_json'          => wp_json_encode( $answers ),
			'domain_scores_json'    => wp_json_encode( $result['domain_scores'] ),
			'findings_json'         => wp_json_encode( $result['findings'] ),
			'abandoned'             => 0,
			'completed_at'          => $now,
			'duration_seconds'      => $duration,
			'last_question_answered'=> null,
		] ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission.' );
		}

		$micro_report = WPQ_Scoring::build_micro_report( $result );

		return new WP_REST_Response( $micro_report, 200 );
	}

	public static function create_checkout( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::is_checkout_feature_enabled() ) {
			return self::error( 403, 'CHECKOUT_DISABLED', 'Checkout is not enabled.' );
		}
		if ( ! self::implementation_ready_for_checkout() ) {
			return self::error( 409, 'CHECKOUT_NOT_READY', 'Checkout is not fully configured.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token = sanitize_text_field( $body['session_token'] ?? '' );
		$product_id = (int) ( $body['product_id'] ?? 0 );
		if ( ! $submission_id || ! $token || ! $product_id ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id, session_token, and product_id are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission record not found.' );
		}
		if ( ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}
		if ( empty( $submission->completed_at ) || (int) ( $submission->abandoned ?? 1 ) !== 0 ) {
			return self::error( 409, 'INCOMPLETE_SUBMISSION', 'Checkout requires a completed assessment.' );
		}
		$current_payment_status = (string) ( $submission->payment_status ?? 'none' );
		if ( ! in_array( $current_payment_status, [ 'none', 'failed', 'expired' ], true ) ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'This submission is not eligible for checkout.' );
		}
		if ( empty( $submission->answers_json ) ) {
			return self::error( 409, 'MISSING_ANSWERS', 'Completed assessment answers are missing.' );
		}

		$product = WPQ_Database::get_product_admin( $product_id );
		if ( ! $product ) {
			return self::error( 404, 'NOT_FOUND', 'Product not found.' );
		}
		if ( ( $product->status ?? '' ) !== 'active' ) {
			return self::error( 409, 'PRODUCT_INACTIVE', 'Product is not active.' );
		}
		if ( (int) ( $product->questionnaire_id ?? 0 ) !== (int) $submission->questionnaire_id ) {
			return self::error( 409, 'PRODUCT_MISMATCH', 'Product does not belong to this questionnaire.' );
		}
		if ( empty( $product->stripe_price_id ) ) {
			return self::error( 409, 'PRODUCT_NOT_CONFIGURED', 'Product does not have a Stripe Price ID.' );
		}
		if ( ( $product->billing_type ?? '' ) !== 'one_off' ) {
			return self::error( 409, 'UNSUPPORTED_BILLING_TYPE', 'Subscriptions are not supported in this phase.' );
		}

		$answers_hash = WPQ_Database::answers_hash( (string) $submission->answers_json );
		$amount_total = self::product_amount_total( $product );
		$currency = 'gbp';

		try {
			$stripe_session = WPQ_Stripe::create_checkout_session(
				$submission,
				$product,
				$answers_hash,
				self::checkout_return_url( 'success' ),
				self::checkout_return_url( 'cancel' )
			);
		} catch ( Throwable $e ) {
			return self::error( 500, 'STRIPE_ERROR', 'Could not create Stripe Checkout Session.' );
		}

		$stripe_session_id = sanitize_text_field( (string) ( $stripe_session->id ?? '' ) );
		$checkout_url = esc_url_raw( (string) ( $stripe_session->url ?? '' ) );
		if ( $stripe_session_id === '' || $checkout_url === '' ) {
			return self::error( 500, 'STRIPE_ERROR', 'Stripe did not return a usable Checkout Session.' );
		}

		if ( ! WPQ_Database::upsert_payment_session( $stripe_session_id, [
			'submission_id'   => $submission_id,
			'product_id'      => $product_id,
			'payment_status'  => 'pending',
			'answers_hash'    => $answers_hash,
			'amount_total'    => $amount_total,
			'currency'        => $currency,
		] ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not record payment session.' );
		}

		if ( ! WPQ_Database::transition_payment_status( $submission_id, $current_payment_status, 'pending' ) ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'Could not move submission into pending payment state.' );
		}

		if ( ! WPQ_Database::update_submission( $submission_id, [
			'product_id'         => $product_id,
			'stripe_session_id'  => $stripe_session_id,
		] ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission payment details.' );
		}

		return new WP_REST_Response( [
			'status'            => 'ok',
			'checkout_url'      => $checkout_url,
			'stripe_session_id' => $stripe_session_id,
		], 200 );
	}

	public static function stripe_webhook( WP_REST_Request $request ): WP_REST_Response {
		$payload = method_exists( $request, 'get_body' ) ? (string) $request->get_body() : '';
		$signature = method_exists( $request, 'get_header' ) ? (string) $request->get_header( 'stripe-signature' ) : '';
		if ( $signature === '' ) {
			return self::error( 400, 'MISSING_SIGNATURE', 'Missing Stripe signature.' );
		}

		try {
			$event = WPQ_Stripe::construct_webhook_event( $payload, $signature );
		} catch ( Throwable $e ) {
			return self::error( 400, 'INVALID_SIGNATURE', 'Invalid Stripe webhook signature.' );
		}

		$stripe_event_id = sanitize_text_field( (string) ( $event->id ?? '' ) );
		$event_type = sanitize_text_field( (string) ( $event->type ?? '' ) );
		if ( $stripe_event_id === '' ) {
			return self::error( 400, 'INVALID_EVENT', 'Stripe event ID is missing.' );
		}

		$existing_event = WPQ_Database::get_payment_event( $stripe_event_id );
		if ( $existing_event && ! empty( $existing_event->processed_at ) ) {
			return new WP_REST_Response( [ 'status' => 'ok', 'duplicate' => true ], 200 );
		}
		$allowed_events = [
			'checkout.session.completed'            => 'paid',
			'checkout.session.expired'              => 'expired',
			'checkout.session.async_payment_failed' => 'failed',
		];
		if ( ! isset( $allowed_events[ $event_type ] ) ) {
			return new WP_REST_Response( [ 'status' => 'ignored', 'event_type' => $event_type ], 200 );
		}

		$stripe_session = $event->data->object ?? null;
		if ( ! is_object( $stripe_session ) ) {
			return self::error( 400, 'INVALID_EVENT', 'Stripe Checkout Session is missing.' );
		}

		return self::process_checkout_event( $event, $stripe_session, $existing_event, $allowed_events[ $event_type ] );
	}

	public static function download_report( WP_REST_Request $request ): WP_REST_Response {
		$submission_id = (int) $request->get_param( 'id' );
		$token = sanitize_text_field( (string) $request->get_param( 'token' ) );
		if ( ! $submission_id || $token === '' ) {
			return self::error( 403, 'FORBIDDEN', 'A valid report token is required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || ( $submission->payment_status ?? '' ) !== 'paid' ) {
			return self::error( 403, 'FORBIDDEN', 'Report is not available.' );
		}
		$report_path = (string) ( $submission->report_path ?? '' );
		$resolved_path = class_exists( 'WPQ_Report_Renderer' ) ? WPQ_Report_Renderer::resolve_report_path( $report_path ) : null;
		if ( ! $resolved_path ) {
			return self::error( 404, 'NOT_FOUND', 'Report file not found.' );
		}
		if ( strtolower( pathinfo( $resolved_path, PATHINFO_EXTENSION ) ) !== 'pdf' ) {
			return self::error( 404, 'NOT_FOUND', 'Report file not found.' );
		}
		if ( ! is_readable( $resolved_path ) ) {
			return self::error( 404, 'NOT_FOUND', 'Report file not found.' );
		}

		$report_token = WPQ_Database::consume_report_token( $submission_id, $token );
		if ( ! $report_token ) {
			return self::error( 403, 'FORBIDDEN', 'Report token can no longer be used.' );
		}

		return self::report_download_response( $resolved_path );
	}

	public static function serve_report_download( bool $served, $result, WP_REST_Request $request, $server ): bool {
		if ( $served || ! ( $result instanceof WP_REST_Response ) ) {
			return $served;
		}

		$headers     = $result->get_headers();
		$download_id = sanitize_text_field( (string) ( $headers[ self::REPORT_DOWNLOAD_HEADER ] ?? '' ) );
		if ( $download_id === '' ) {
			return $served;
		}

		// Remove the internal routing header before serving.
		unset( $headers[ self::REPORT_DOWNLOAD_HEADER ] );
		$result->set_headers( $headers );

		$path = self::$report_download_paths[ $download_id ] ?? '';
		if ( $path === '' ) {
			return $served;
		}

		$resolved_path = self::validate_report_stream_path( $path );
		if ( ! $resolved_path ) {
			unset( self::$report_download_paths[ $download_id ] );
			return $served;
		}

		unset( self::$report_download_paths[ $download_id ] );
		return self::stream_report_file( $resolved_path );
	}

	// ------------------------------------------------------------------ //
	// Helpers
	// ------------------------------------------------------------------ //

	private static function process_checkout_event( object $event, object $stripe_session, ?object $existing_event, string $target_status ): WP_REST_Response {
		$stripe_session_id = sanitize_text_field( (string) ( $stripe_session->id ?? '' ) );
		$payment_session = $stripe_session_id !== '' ? WPQ_Database::get_payment_session( $stripe_session_id ) : null;
		if ( ! $payment_session ) {
			return self::error( 409, 'UNKNOWN_SESSION', 'Payment session is not recognised.' );
		}

		$submission = WPQ_Database::get_submission( (int) $payment_session->submission_id );
		$product = WPQ_Database::get_product_admin( (int) $payment_session->product_id );
		if ( ! $submission || ! $product ) {
			return self::error( 409, 'LOCAL_RECORD_MISSING', 'Submission or product record is missing.' );
		}

		$metadata = is_object( $stripe_session->metadata ?? null ) ? $stripe_session->metadata : (object) [];
		$expected = [
			'submission_id' => (string) $payment_session->submission_id,
			'product_id'    => (string) $payment_session->product_id,
			'answers_hash'  => (string) $payment_session->answers_hash,
		];
		foreach ( $expected as $key => $value ) {
			if ( (string) ( $metadata->{$key} ?? '' ) !== $value ) {
				return self::error( 409, 'METADATA_MISMATCH', 'Stripe session metadata does not match local records.' );
			}
		}

		$amount_total = (int) ( $stripe_session->amount_total ?? -1 );
		$currency = strtolower( sanitize_text_field( (string) ( $stripe_session->currency ?? '' ) ) );
		if ( $amount_total !== (int) $payment_session->amount_total ) {
			return self::error( 409, 'AMOUNT_MISMATCH', 'Stripe amount does not match expected amount.' );
		}
		if ( $currency !== (string) $payment_session->currency ) {
			return self::error( 409, 'CURRENCY_MISMATCH', 'Stripe currency does not match expected currency.' );
		}

		$stripe_event_id = sanitize_text_field( (string) $event->id );
		if ( ! $existing_event ) {
			$inserted_event = WPQ_Database::insert_payment_event( [
				'stripe_event_id' => $stripe_event_id,
				'stripe_session_id' => $stripe_session_id,
				'submission_id' => (int) $payment_session->submission_id,
				'product_id' => (int) $payment_session->product_id,
				'event_type' => sanitize_text_field( (string) $event->type ),
				'previous_status' => (string) $submission->payment_status,
				'new_status' => $target_status,
				'amount_total' => $amount_total,
				'currency' => $currency,
				'payload_json' => $event,
			] );
			if ( ! $inserted_event ) {
				return new WP_REST_Response( [ 'status' => 'ok', 'duplicate' => true ], 200 );
			}
		}

		$previous_status = (string) $submission->payment_status;
		if ( $previous_status === 'paid' && $target_status !== 'paid' ) {
			WPQ_Database::mark_payment_event_processed( $stripe_event_id, $previous_status, 'paid' );
			return new WP_REST_Response( [ 'status' => 'ok', 'ignored_terminal' => true ], 200 );
		}
		if ( $previous_status === 'pending' && ! WPQ_Database::transition_payment_status( (int) $submission->id, 'pending', $target_status ) ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'Could not update payment state.' );
		}
		if ( $previous_status !== 'pending' && $previous_status !== $target_status ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'Payment is not pending.' );
		}

		if ( ! WPQ_Database::update_payment_session_status( $stripe_session_id, $target_status ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update payment session.' );
		}

		if ( $target_status !== 'paid' ) {
			WPQ_Database::mark_payment_event_processed( $stripe_event_id, $previous_status, $target_status );
			return new WP_REST_Response( [ 'status' => 'ok', 'payment_status' => $target_status ], 200 );
		}

		try {
			$existing_report = empty( $submission->report_path ) || ! class_exists( 'WPQ_Report_Renderer' )
				? null
				: WPQ_Report_Renderer::resolve_report_path( (string) $submission->report_path );
			if ( ! $existing_report || ! is_readable( $existing_report ) ) {
				WPQ_Report_Renderer::generate_and_store( (int) $submission->id, (int) $product->id );
			}
			$token = WPQ_Database::create_report_token( (int) $submission->id );
			if ( empty( $token['token'] ) ) {
				throw new RuntimeException( 'Could not create report token.' );
			}
		} catch ( Throwable $e ) {
			if ( ! WPQ_Database::update_submission_report( (int) $submission->id, (int) $product->id, (string) ( $submission->report_path ?? '' ), $e->getMessage() ) ) {
				error_log( 'WPQ could not record report generation failure for submission ' . (int) $submission->id );
			}
			return self::error( 500, 'REPORT_GENERATION_FAILED', 'Payment was confirmed, but report generation failed.' );
		}

		WPQ_Database::mark_payment_event_processed( $stripe_event_id, $previous_status, 'paid' );

		return new WP_REST_Response( [
			'status' => 'ok',
			'report_url' => self::report_download_url( (int) $submission->id, (string) $token['token'] ),
		], 200 );
	}

	private static function is_checkout_feature_enabled(): bool {
		// When a test Stripe session is injected, bypass the feature flag entirely.
		if ( class_exists( 'WPQ_Stripe' ) && WPQ_Stripe::has_test_checkout_session() ) {
			return true;
		}
		if ( defined( 'WPQ_TESTING' ) && isset( $GLOBALS['wpq_test_checkout_enabled'] ) ) {
			return (bool) $GLOBALS['wpq_test_checkout_enabled'];
		}

		return defined( 'WPQ_CHECKOUT_ENABLED' ) && WPQ_CHECKOUT_ENABLED;
	}

	private static function implementation_ready_for_checkout(): bool {
		// When a test Stripe session is injected, skip capability checks.
		if ( class_exists( 'WPQ_Stripe' ) && WPQ_Stripe::has_test_checkout_session() ) {
			return true;
		}
		$capabilities = self::checkout_capabilities();
		foreach ( [ 'checkout', 'webhook', 'report_delivery', 'report_template', 'report_renderer', 'report_storage_delivery', 'stripe_api_initialised' ] as $capability ) {
			if ( empty( $capabilities[ $capability ] ) ) {
				return false;
			}
		}

		return true;
	}

	private static function product_amount_total( object $product ): int {
		return (int) round( (float) $product->price_gbp * 100 );
	}

	private static function checkout_return_url( string $status ): string {
		if ( function_exists( 'home_url' ) ) {
			return home_url( '/?wpq_checkout=' . rawurlencode( $status ) );
		}

		return 'https://example.test/?wpq_checkout=' . rawurlencode( $status );
	}

	private static function report_download_url( int $submission_id, string $token ): string {
		$path = WPQ_REST_NAMESPACE . '/reports/' . $submission_id . '?token=' . rawurlencode( $token );
		if ( function_exists( 'rest_url' ) ) {
			return rest_url( $path );
		}

		return 'https://example.test/wp-json/' . $path;
	}

	private static function report_download_response( string $path ): WP_REST_Response {
		$download_id = hash_hmac( 'sha256', $path . '|' . microtime( true ) . '|' . wp_generate_uuid4(), wp_salt( 'auth' ) );
		self::$report_download_paths[ $download_id ] = $path;

		return new WP_REST_Response( [], 200, [ self::REPORT_DOWNLOAD_HEADER => $download_id ] );
	}

	private static function validate_report_stream_path( string $path ): ?string {
		$resolved_path = class_exists( 'WPQ_Report_Renderer' ) ? WPQ_Report_Renderer::resolve_report_path( $path ) : null;
		if ( ! $resolved_path ) {
			return null;
		}
		if ( strtolower( pathinfo( $resolved_path, PATHINFO_EXTENSION ) ) !== 'pdf' ) {
			return null;
		}
		if ( ! is_readable( $resolved_path ) ) {
			return null;
		}

		return $resolved_path;
	}

	private static function report_stream_headers( string $path ): array {
		$file_name = preg_replace( '/[^A-Za-z0-9._-]/', '-', basename( $path ) );
		$file_name = $file_name ?: 'wpq-report.pdf';
		$headers   = [
			'Content-Type'           => 'application/pdf',
			'Content-Disposition'    => 'attachment; filename="' . $file_name . '"',
			'X-Content-Type-Options' => 'nosniff',
			'Cache-Control'          => 'no-store, no-cache, must-revalidate, max-age=0',
			'Pragma'                 => 'no-cache',
			'Expires'                => '0',
		];
		$size = filesize( $path );
		if ( $size !== false ) {
			$headers['Content-Length'] = (string) $size;
		}
		return $headers;
	}

	private static function stream_report_file( string $path ): bool {
		$headers = self::report_stream_headers( $path );

		if ( defined( 'WPQ_TESTING' ) && WPQ_TESTING ) {
			$GLOBALS['wpq_test_streamed_report'] = [
				'path'    => $path,
				'headers' => $headers,
			];
			return true;
		}

		if ( function_exists( 'status_header' ) ) {
			status_header( 200 );
		}
		foreach ( $headers as $name => $value ) {
			header( $name . ': ' . $value );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Controlled plugin-generated PDF path after token validation.
		readfile( $path );
		return true;
	}

	private static function check_rate_limit( string $endpoint, int $limit, int $window_seconds ): bool {
		$ip   = self::get_client_ip();
		$key  = 'wpq_rl_' . md5( $endpoint . $ip );
		$data = get_transient( $key );

		if ( $data === false ) {
			// First request — open a fixed window starting now.
			set_transient( $key, [ 'count' => 1, 'expires' => time() + $window_seconds ], $window_seconds );
			return true;
		}

		if ( $data['count'] >= $limit ) {
			return false;
		}

		// Increment but preserve the original window expiry (not a sliding window).
		$remaining = max( 1, (int) $data['expires'] - time() );
		set_transient( $key, [ 'count' => $data['count'] + 1, 'expires' => $data['expires'] ], $remaining );
		return true;
	}

	private static function get_client_ip(): string {
		// Only trust X-Forwarded-For when WPQ_TRUST_PROXY_IP is explicitly enabled,
		// i.e. when REMOTE_ADDR is always a trusted reverse proxy that strips inbound XFF.
		if ( WPQ_TRUST_PROXY_IP && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) )[0] );
			if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return $ip;
			}
		}
		$ip = trim( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ) );
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	private static function error( int $status, string $code, string $message ): WP_REST_Response {
		return new WP_REST_Response( [
			'status'  => 'error',
			'code'    => $code,
			'message' => $message,
		], $status );
	}
}
