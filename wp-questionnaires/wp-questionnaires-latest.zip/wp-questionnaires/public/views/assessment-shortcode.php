<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="wpq-wrap" id="wpq-app" data-wpq-config="<?php echo esc_attr( wp_json_encode( $wpq_instance_config ?? [] ) ); ?>" aria-live="polite">

  <!-- ---------------------------------------------------------------- -->
  <!-- LOADING STATE                                                     -->
  <!-- ---------------------------------------------------------------- -->
  <div class="wpq-loading" id="wpq-loading">
    <div class="wpq-spinner" aria-label="Loading assessment…"></div>
    <p>Loading assessment…</p>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- ERROR STATE                                                       -->
  <!-- ---------------------------------------------------------------- -->
  <div class="wpq-error-state wpq-hidden" id="wpq-error-state" role="alert">
    <p id="wpq-error-message">Something went wrong. Please refresh and try again.</p>
    <button class="wpq-btn wpq-btn-secondary" id="wpq-retry-btn">Try again</button>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- STEP 1: LEAD CAPTURE FORM                                        -->
  <!-- ---------------------------------------------------------------- -->
  <div class="wpq-step wpq-hidden" id="wpq-step-lead">
    <div class="wpq-step-header">
      <h2 id="wpq-questionnaire-name"></h2>
      <p id="wpq-questionnaire-desc" class="wpq-desc"></p>
    </div>

    <form class="wpq-lead-form" id="wpq-lead-form" novalidate>
      <div class="wpq-form-row">
        <label for="wpq-name">Full name <span aria-hidden="true">*</span></label>
        <input type="text" id="wpq-name" name="contact_name" autocomplete="name" required placeholder="Jane Smith" />
        <span class="wpq-field-error" id="wpq-name-error"></span>
      </div>
      <div class="wpq-form-row">
        <label for="wpq-email">Email address <span aria-hidden="true">*</span></label>
        <input type="email" id="wpq-email" name="contact_email" autocomplete="email" required placeholder="jane@example.com" />
        <span class="wpq-field-error" id="wpq-email-error"></span>
      </div>
      <div class="wpq-form-row">
        <label for="wpq-company">Company name <span aria-hidden="true">*</span></label>
        <input type="text" id="wpq-company" name="contact_company" autocomplete="organization" required placeholder="Acme Ltd" />
        <span class="wpq-field-error" id="wpq-company-error"></span>
      </div>
      <div class="wpq-form-row">
        <label for="wpq-phone">Phone number <span class="wpq-optional">(optional)</span></label>
        <input type="tel" id="wpq-phone" name="contact_phone" autocomplete="tel" placeholder="+44 20 7946 0000" />
      </div>

      <!-- Attribution fields — populated by JS, not shown to user -->
      <input type="hidden" name="utm_source"   id="wpq-utm-source" />
      <input type="hidden" name="utm_medium"   id="wpq-utm-medium" />
      <input type="hidden" name="utm_campaign" id="wpq-utm-campaign" />
      <input type="hidden" name="utm_term"     id="wpq-utm-term" />
      <input type="hidden" name="utm_content"  id="wpq-utm-content" />
      <input type="hidden" name="referrer_url" id="wpq-referrer" />
      <input type="hidden" name="landing_page" id="wpq-landing" />

      <div class="wpq-consent-row">
        <label class="wpq-consent-label">
          <input type="checkbox" id="wpq-consent" name="consent">
          <span><?php
            $privacy_url = get_privacy_policy_url();
            if ( $privacy_url ) {
              printf(
                'I have read and accept the <a href="%s" target="_blank" rel="noopener noreferrer">privacy notice</a>.',
                esc_url( $privacy_url )
              );
            } else {
              echo 'I accept that my details will be used to provide my results and manage the service.';
            }
          ?></span>
        </label>
        <span class="wpq-field-error" id="wpq-consent-error"></span>
      </div>

      <div class="wpq-form-footer">
        <p class="wpq-privacy-note">We use your details to provide your results, follow up on your enquiry, and manage the service.</p>
        <button type="submit" class="wpq-btn wpq-btn-primary" id="wpq-lead-submit">
          Start assessment →
        </button>
      </div>
    </form>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- STEP 2: QUESTIONNAIRE                                            -->
  <!-- ---------------------------------------------------------------- -->
  <div class="wpq-step wpq-hidden" id="wpq-step-assessment">

    <!-- Tool header -->
    <div class="wpq-tool-header">
      <div class="wpq-progress-meta">
        <span id="wpq-answered-label">0 of 0 answered</span>
        <span id="wpq-pct-label">0%</span>
      </div>
      <div class="wpq-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" id="wpq-progress-bar-wrap">
        <div class="wpq-progress-fill" id="wpq-progress-fill"></div>
      </div>
    </div>

    <!-- Domain tabs -->
    <div class="wpq-domain-tabs" id="wpq-domain-tabs" role="tablist" aria-label="Assessment domains"></div>

    <!-- Brief panels — injected by JS -->
    <div class="wpq-brief-panels wpq-hidden" id="wpq-brief-panels"></div>

    <!-- Question panels — injected by JS -->
    <div class="wpq-panels" id="wpq-panels"></div>

    <!-- Navigation -->
    <div class="wpq-nav">
      <button class="wpq-btn wpq-btn-secondary" id="wpq-back-btn" style="visibility:hidden;">← Back</button>
      <button class="wpq-btn wpq-btn-primary"   id="wpq-next-btn">Next domain →</button>
    </div>
  </div>

  <!-- ---------------------------------------------------------------- -->
  <!-- STEP 3: RESULTS                                                  -->
  <!-- ---------------------------------------------------------------- -->
  <div class="wpq-step wpq-hidden" id="wpq-step-results">

    <div class="wpq-results-header">
      <div class="wpq-score-ring-wrap">
        <svg class="wpq-score-ring" viewBox="0 0 120 120" aria-label="Score ring" role="img">
          <circle class="wpq-ring-bg"   cx="60" cy="60" r="52" />
          <circle class="wpq-ring-fill" cx="60" cy="60" r="52" id="wpq-ring-fill" />
        </svg>
        <div class="wpq-score-numeral" id="wpq-score-numeral">0</div>
      </div>

      <div class="wpq-grade-block">
        <span class="wpq-grade-pill" id="wpq-grade-pill"></span>
        <p class="wpq-verdict"       id="wpq-verdict"></p>
      </div>
    </div>

    <!-- Domain grid -->
    <div class="wpq-results-section">
      <h3 class="wpq-section-title">Domain breakdown</h3>
      <div class="wpq-domain-grid" id="wpq-domain-grid"></div>
    </div>

    <!-- Key Findings -->
    <div class="wpq-results-section">
      <h3 class="wpq-section-title">Key Findings</h3>
      <div class="wpq-findings-filters" id="wpq-findings-filters"></div>
      <ul class="wpq-findings-list" id="wpq-findings-list"></ul>
      <div class="wpq-category-cta wpq-hidden" id="wpq-category-cta"></div>
    </div>

    <!-- Upgrade CTA — shown only if products available -->
    <!-- Remediation plan -->
    <div class="wpq-remediation-plan wpq-hidden" id="wpq-remediation-plan">
      <div>
        <h3>Download your remediation plan</h3>
        <p>Generate a practical workbook with 30, 60, or 90 day remediation tasks based on your answers.</p>
      </div>
      <div class="wpq-remediation-actions">
        <label for="wpq-remediation-days">Plan length</label>
        <select id="wpq-remediation-days">
          <option value="30">30 days</option>
          <option value="60">60 days</option>
          <option value="90" selected>90 days</option>
        </select>
        <button type="button" class="wpq-btn wpq-btn-secondary" id="wpq-remediation-download">Download Remediation Plan</button>
      </div>
      <p class="wpq-remediation-status" id="wpq-remediation-status" role="status" aria-live="polite"></p>
    </div>

    <div class="wpq-upgrade-cta wpq-hidden" id="wpq-upgrade-cta">
      <h3>Get your full report</h3>
      <p>Receive a complete branded PDF report with your 90-day action plan and standards readiness indicator.</p>
      <div class="wpq-product-list" id="wpq-product-list"></div>
    </div>

    <!-- Restart -->
    <div class="wpq-restart">
      <button class="wpq-btn-link" id="wpq-restart-btn">Start assessment again</button>
    </div>
  </div>

</div><!-- /.wpq-wrap -->
