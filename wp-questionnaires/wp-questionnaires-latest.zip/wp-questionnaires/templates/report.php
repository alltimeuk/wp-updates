<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/** @var object $submission */
/** @var object|null $questionnaire */
/** @var object $product */
/** @var array<int, array<string, mixed>> $domain_scores */
/** @var array<int, array<string, mixed>> $findings */
/** @var string $generated_at */
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<style>
		body { color: #1f2933; font-family: DejaVu Sans, sans-serif; font-size: 12px; line-height: 1.45; }
		h1, h2 { color: #0f172a; margin: 0 0 12px; }
		h1 { font-size: 26px; }
		h2 { border-bottom: 1px solid #d8dee8; font-size: 16px; margin-top: 28px; padding-bottom: 6px; }
		table { border-collapse: collapse; margin: 10px 0 18px; width: 100%; }
		th, td { border: 1px solid #d8dee8; padding: 8px; text-align: left; vertical-align: top; }
		th { background: #f3f6fa; width: 28%; }
		.score { background: #eef7ff; border: 1px solid #b8ddff; margin: 16px 0; padding: 14px; }
		.small { color: #667085; font-size: 10px; }
	</style>
</head>
<body>
	<p class="small"><?php echo esc_html( (string) $generated_at ); ?></p>
	<h1><?php echo esc_html( (string) ( $questionnaire->name ?? 'Assessment Report' ) ); ?></h1>
	<p><?php echo esc_html( (string) $product->name ); ?> for <?php echo esc_html( (string) $submission->contact_company ); ?></p>

	<div class="score">
		<strong>Overall score:</strong> <?php echo esc_html( (string) ( $submission->overall_score ?? 'N/A' ) ); ?>/100<br>
		<strong>Grade:</strong> <?php echo esc_html( (string) ( $submission->grade_label ?? $submission->grade_id ?? 'N/A' ) ); ?>
	</div>

	<h2>Submission</h2>
	<table>
		<tr><th>Reference</th><td><?php echo esc_html( (string) $submission->ref ); ?></td></tr>
		<tr><th>Name</th><td><?php echo esc_html( (string) $submission->contact_name ); ?></td></tr>
		<tr><th>Email</th><td><?php echo esc_html( (string) $submission->contact_email ); ?></td></tr>
		<tr><th>Company</th><td><?php echo esc_html( (string) $submission->contact_company ); ?></td></tr>
		<tr><th>Completed</th><td><?php echo esc_html( (string) ( $submission->completed_at ?? '' ) ); ?></td></tr>
	</table>

	<?php if ( ! empty( $domain_scores ) ) : ?>
		<h2>Domain Scores</h2>
		<table>
			<tr><th>Domain</th><th>Score</th><th>Percent</th></tr>
			<?php foreach ( $domain_scores as $domain_score ) : ?>
				<tr>
					<td><?php echo esc_html( (string) ( $domain_score['name'] ?? $domain_score['slug'] ?? '' ) ); ?></td>
					<td><?php echo esc_html( (string) ( $domain_score['score'] ?? '' ) ); ?> / <?php echo esc_html( (string) ( $domain_score['max'] ?? '' ) ); ?></td>
					<td><?php echo esc_html( (string) ( $domain_score['pct'] ?? '' ) ); ?>%</td>
				</tr>
			<?php endforeach; ?>
		</table>
	<?php endif; ?>

	<?php if ( ! empty( $findings ) ) : ?>
		<h2>Priority Findings</h2>
		<table>
			<tr><th>Priority</th><th>Domain</th><th>Recommended action</th></tr>
			<?php foreach ( $findings as $finding ) : ?>
				<tr>
					<td><?php echo esc_html( (string) ( $finding['priority'] ?? '' ) ); ?></td>
					<td><?php echo esc_html( (string) ( $finding['domain'] ?? '' ) ); ?></td>
					<td><?php echo esc_html( (string) ( $finding['action'] ?? '' ) ); ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	<?php endif; ?>
</body>
</html>
