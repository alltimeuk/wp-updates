<?php if ( ! defined( 'ABSPATH' ) ) exit;
/** @var array $r — output of WPQ_Admin::get_operational_readiness() */
$r = $r ?? [];

// ── inline helpers ──────────────────────────────────────────────────────────

$ok  = static function ( string $label, string $detail = '' ): void {
	echo '<tr><td><span class="dashicons dashicons-yes-alt" style="color:#46b450"></span> ' . esc_html( $label ) . '</td>';
	echo '<td>' . esc_html( $detail ) . '</td></tr>';
};
$warn = static function ( string $label, string $detail = '' ): void {
	echo '<tr><td><span class="dashicons dashicons-warning" style="color:#dba617"></span> ' . esc_html( $label ) . '</td>';
	echo '<td>' . esc_html( $detail ) . '</td></tr>';
};
$err = static function ( string $label, string $detail = '' ): void {
	echo '<tr><td><span class="dashicons dashicons-dismiss" style="color:#dc3232"></span> ' . esc_html( $label ) . '</td>';
	echo '<td>' . esc_html( $detail ) . '</td></tr>';
};
$check = static function ( bool $pass, string $label, string $detail = '' ) use ( $ok, $err ): void {
	$pass ? $ok( $label, $detail ) : $err( $label, $detail );
};

// Key source badge (constants > env > options)
$source_label = static function ( string $source ): string {
	return match ( $source ) {
		'constant' => 'PHP constant',
		'env'      => 'Environment variable',
		'option'   => 'WP option (database)',
		default    => 'Not set',
	};
};

$status = $r['overall_status'] ?? 'ok';
$errors   = $r['overall_errors']   ?? [];
$warnings = $r['overall_warnings'] ?? [];
?>
<div class="wrap">
<h1>Readiness</h1>
<p style="color:#666">
	WP Questionnaires v<?php echo esc_html( $r['plugin_version'] ?? '' ); ?>
	&nbsp;&mdash;&nbsp;
	<a href="<?php echo esc_url( add_query_arg( [ 'page' => 'wpq-readiness' ], admin_url( 'admin.php' ) ) ); ?>">Refresh</a>
</p>

<?php
// ── Overall status banner ───────────────────────────────────────────────────
if ( $status === 'error' ) : ?>
<div class="notice notice-error" style="margin:0 0 16px">
	<p><strong>Action required</strong></p>
	<ul style="list-style:disc;margin-left:20px">
		<?php foreach ( $errors as $msg ) : ?><li><?php echo esc_html( $msg ); ?></li><?php endforeach; ?>
	</ul>
</div>
<?php elseif ( $status === 'warning' ) : ?>
<div class="notice notice-warning" style="margin:0 0 16px">
	<p><strong>Review recommended</strong></p>
	<ul style="list-style:disc;margin-left:20px">
		<?php foreach ( $warnings as $msg ) : ?><li><?php echo esc_html( $msg ); ?></li><?php endforeach; ?>
	</ul>
</div>
<?php else : ?>
<div class="notice notice-success" style="margin:0 0 16px">
	<p><strong>All checks passed</strong></p>
</div>
<?php endif; ?>

<?php /* ── shared card styles ── */ ?>
<style>
.wpq-health-card { max-width:900px; margin-bottom:24px; }
.wpq-health-card h2 { font-size:14px; font-weight:600; margin:0 0 8px; }
.wpq-health-card table.widefat td { vertical-align:middle; padding:6px 10px; }
.wpq-health-card table.widefat td:first-child { width:60%; white-space:nowrap; }
.wpq-count-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; max-width:900px; margin-bottom:24px; }
.wpq-count-card { background:#fff; border:1px solid #c3c4c7; border-radius:2px; padding:16px 20px; }
.wpq-count-card h3 { font-size:13px; margin:0 0 12px; }
.wpq-count-card table { border-collapse:collapse; width:100%; }
.wpq-count-card td { padding:3px 0; font-size:13px; }
.wpq-count-card td:last-child { text-align:right; font-weight:600; }
</style>

<?php
// ── 1. Plugin & Database ────────────────────────────────────────────────────
$db_match    = (bool) ( $r['db_version_match'] ?? false );
$installed   = $r['db_version_installed'] ?? '0';
$code_ver    = $r['db_version_code'] ?? WPQ_DB_VERSION;
?>
<div class="card wpq-health-card">
<h2>Plugin &amp; Database</h2>
<table class="widefat striped"><tbody>
<?php
$check( true, 'Plugin version', $r['plugin_version'] ?? '' );
$check( $db_match, 'DB schema version', $installed . ' installed / ' . $code_ver . ' required' );
$check( (bool) ( $r['checkout_enabled'] ?? false ), 'Checkout phase enabled', ( $r['checkout_enabled'] ?? false ) ? 'Yes (WPQ_CHECKOUT_ENABLED=true)' : 'No — phase 3 gated off' );
$check( (bool) ( $r['stripe_library'] ?? false ), 'Stripe PHP library', ( $r['stripe_library'] ?? false ) ? 'Present' : 'Missing (composer require stripe/stripe-php)' );
$check( (bool) ( $r['dompdf_library'] ?? false ), 'Dompdf PDF library', ( $r['dompdf_library'] ?? false ) ? 'Present' : 'Missing (composer require dompdf/dompdf)' );
?>
</tbody></table>
</div>

<?php
// ── 2. Schema Health ────────────────────────────────────────────────────────
$schema      = $r['schema'] ?? [];
$table_health = $schema['table_health'] ?? [];
$strict       = $schema['strict_schema_health'] ?? [];
?>
<div class="card wpq-health-card">
<h2>Schema Health</h2>
<table class="widefat striped"><tbody>
<?php
if ( $table_health ) :
	foreach ( $table_health as $table_name => $info ) :
		$exists  = (bool) $info['exists'];
		$missing = $info['missing_columns'] ?? [];
		if ( ! $exists ) :
			$err( $table_name, 'Table missing' );
		elseif ( $missing ) :
			$warn( $table_name, 'Missing columns: ' . implode( ', ', $missing ) );
		else :
			$ok( $table_name, 'OK' );
		endif;
	endforeach;
else :
	$warn( 'Table health', 'Diagnostic data unavailable' );
endif;

if ( $strict ) :
	foreach ( $strict as $table_name => $checks ) :
		foreach ( $checks as $check_name => $result ) :
			$pass = (bool) ( $result['ok'] ?? false );
			$msg  = (string) ( $result['message'] ?? '' );
			$pass ? $ok( $table_name . ': ' . $check_name, $msg ) : $warn( $table_name . ': ' . $check_name, $msg );
		endforeach;
	endforeach;
endif;
?>
</tbody></table>
</div>

<?php
// ── 3. Rate Limiting ────────────────────────────────────────────────────────
$rate_limit_storage = $r['rate_limit_storage'] ?? [ 'table' => '', 'available' => false, 'error' => '' ];
?>
<div class="card wpq-health-card">
<h2>Rate Limiting</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) ( $rate_limit_storage['available'] ?? false ), 'Atomic rate-limit storage', ( $rate_limit_storage['available'] ?? false ) ? 'Available' : 'Unavailable - transient fallback active' );
if ( ! empty( $rate_limit_storage['table'] ) ) :
	$ok( 'Rate-limit table', (string) $rate_limit_storage['table'] );
endif;
?>
</tbody></table>
</div>

<?php
// ── 4. Stripe Configuration ─────────────────────────────────────────────────
$pub_key = $r['pub_key'] ?? [ 'present' => false, 'valid' => false, 'source' => 'none' ];
$sec_key = $r['sec_key'] ?? [ 'present' => false, 'valid' => false, 'source' => 'none' ];
$whsec   = $r['whsec']   ?? [ 'present' => false, 'valid' => false, 'source' => 'none' ];
?>
<div class="card wpq-health-card">
<h2>Stripe Configuration</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) $pub_key['valid'], 'Publishable key', $pub_key['valid'] ? 'Valid — ' . $source_label( $pub_key['source'] ) : ( $pub_key['present'] ? 'Present but invalid format' : 'Not set' ) );
$check( (bool) $sec_key['valid'], 'Secret key', $sec_key['valid'] ? 'Valid — ' . $source_label( $sec_key['source'] ) : ( $sec_key['present'] ? 'Present but invalid format' : 'Not set' ) );
$check( (bool) $whsec['valid'], 'Webhook signing secret', $whsec['valid'] ? 'Valid — ' . $source_label( $whsec['source'] ) : ( $whsec['present'] ? 'Present but invalid format' : 'Not set' ) );
$check( (bool) ( $r['stripe_initialised'] ?? false ), 'Stripe API initialised', ( $r['stripe_initialised'] ?? false ) ? 'Yes' : 'No — keys or library unavailable' );
?>
</tbody></table>
</div>

<?php
// ── 5. Report Storage ───────────────────────────────────────────────────────
$storage = $r['storage'] ?? [];
$storage_path = (string) ( $storage['path'] ?? '' );
?>
<div class="card wpq-health-card">
<h2>Report Storage</h2>
<table class="widefat striped"><tbody>
<?php
if ( $storage_path !== '' ) :
	$ok( 'Storage path', $storage_path );
else :
	$warn( 'Storage path', 'Not configured' );
endif;
$check( (bool) ( $storage['available'] ?? false ), 'Directory exists', ( $storage['available'] ?? false ) ? 'Yes' : 'No' );
$check( (bool) ( $storage['writable'] ?? false ), 'Directory writable', ( $storage['writable'] ?? false ) ? 'Yes' : 'No' );
$check( (bool) ( $storage['index_guard_present'] ?? false ), 'index.php guard', ( $storage['index_guard_present'] ?? false ) ? 'Present' : 'Missing' );
$check( (bool) ( $storage['htaccess_guard_present'] ?? false ), '.htaccess deny guard', ( $storage['htaccess_guard_present'] ?? false ) ? 'Present' : 'Missing' );
$check( method_exists( 'WPQ_Database', 'consume_report_token' ), 'Signed one-time tokens', method_exists( 'WPQ_Database', 'consume_report_token' ) ? 'Supported' : 'Method missing' );
?>
</tbody></table>
</div>

<?php
// ── 6. REST Routes ──────────────────────────────────────────────────────────
$core_routes = $r['core_routes'] ?? [];
$api_routes  = $r['api_routes']  ?? [];
$capabilities = $r['capabilities'] ?? [];
?>
<div class="card wpq-health-card">
<h2>REST Routes</h2>
<table class="widefat striped"><tbody>
<?php
$phase3 = [ 'POST /checkout', 'POST /stripe/webhook', 'GET /reports/{id}' ];
foreach ( $core_routes as $route => $present ) :
	$is_phase3 = in_array( $route, $phase3, true );
	if ( $present ) :
		$ok( $route, 'Implemented' );
	elseif ( $is_phase3 ) :
		$warn( $route, 'Phase 3 — not yet implemented' );
	else :
		$err( $route, 'Missing' );
	endif;
endforeach;

foreach ( $api_routes as $route => $present ) :
	$check( $present, $route . ' (HaloPSA pull API)', $present ? 'Implemented' : 'Missing' );
endforeach;
?>
</tbody></table>
</div>

<?php
// ── 6. HaloPSA API Role ─────────────────────────────────────────────────────
$halopsa_role_ok = (bool) ( $r['halopsa_role_ok'] ?? false );
$halopsa_cap_ok  = (bool) ( $r['halopsa_cap_ok']  ?? false );
$halopsa_users   = (int) ( $r['halopsa_users'] ?? 0 );
?>
<div class="card wpq-health-card">
<h2>HaloPSA API Role</h2>
<table class="widefat striped"><tbody>
<?php
$check( $halopsa_role_ok, 'wpq_halopsa role registered', $halopsa_role_ok ? 'Present' : 'Not registered — run activation' );
$check( $halopsa_cap_ok,  'wpq_halopsa_api capability on role', $halopsa_cap_ok ? 'Granted' : 'Missing — role has no API capability' );
if ( $halopsa_users > 0 ) :
	$ok( 'Users with wpq_halopsa role', (string) $halopsa_users );
else :
	$warn( 'Users with wpq_halopsa role', 'None — create a user and assign the wpq_halopsa role for pull-API access' );
endif;
?>
</tbody></table>
</div>

<?php
// ── 7. Submission Counts ────────────────────────────────────────────────────
$sync_counts = $r['sync_counts'] ?? [ 'sync' => [], 'payment' => [], 'total' => 0 ];
$sync    = $sync_counts['sync']    ?? [];
$payment = $sync_counts['payment'] ?? [];
?>
<div class="wpq-count-grid">
	<div class="wpq-count-card">
		<h3>HaloPSA Sync Status</h3>
		<table><tbody>
			<tr><td>Pending</td><td><?php echo esc_html( (string) ( $sync['pending'] ?? 0 ) ); ?></td></tr>
			<tr><td>Processing</td><td><?php echo esc_html( (string) ( $sync['processing'] ?? 0 ) ); ?></td></tr>
			<tr><td>Synced</td><td><?php echo esc_html( (string) ( $sync['synced'] ?? 0 ) ); ?></td></tr>
			<tr style="color:<?php echo ( $sync['failed'] ?? 0 ) > 0 ? '#dc3232' : 'inherit'; ?>">
				<td>Failed</td><td><?php echo esc_html( (string) ( $sync['failed'] ?? 0 ) ); ?></td>
			</tr>
			<tr style="color:<?php echo ( $sync['retry_pending'] ?? 0 ) > 0 ? '#d63638' : 'inherit'; ?>">
				<td>Retry pending</td><td><?php echo esc_html( (string) ( $sync['retry_pending'] ?? 0 ) ); ?></td>
			</tr>
			<tr><td>Ignored</td><td><?php echo esc_html( (string) ( $sync['ignored'] ?? 0 ) ); ?></td></tr>
			<tr style="color:<?php echo ( $sync['manual_review'] ?? 0 ) > 0 ? '#dba617' : 'inherit'; ?>">
				<td>Manual review</td><td><?php echo esc_html( (string) ( $sync['manual_review'] ?? 0 ) ); ?></td>
			</tr>
			<tr><td>Skipped</td><td><?php echo esc_html( (string) ( $sync['skipped'] ?? 0 ) ); ?></td></tr>
			<tr style="border-top:1px solid #ddd;font-weight:bold"><td>Total</td><td><?php echo esc_html( (string) ( $sync_counts['total'] ?? 0 ) ); ?></td></tr>
		</tbody></table>
	</div>
	<div class="wpq-count-card">
		<h3>Payment Status</h3>
		<table><tbody>
			<tr><td>None / free</td><td><?php echo esc_html( (string) ( $payment['none'] ?? 0 ) ); ?></td></tr>
			<tr><td>Pending</td><td><?php echo esc_html( (string) ( $payment['pending'] ?? 0 ) ); ?></td></tr>
			<tr><td>Paid</td><td><?php echo esc_html( (string) ( $payment['paid'] ?? 0 ) ); ?></td></tr>
			<tr style="color:<?php echo ( $payment['failed'] ?? 0 ) > 0 ? '#dc3232' : 'inherit'; ?>">
				<td>Failed</td><td><?php echo esc_html( (string) ( $payment['failed'] ?? 0 ) ); ?></td>
			</tr>
			<tr><td>Expired</td><td><?php echo esc_html( (string) ( $payment['expired'] ?? 0 ) ); ?></td></tr>
		</tbody></table>
	</div>
</div>

<?php
// ── 8. Payment Readiness ─────────────────────────────────────────────────────
$cr = $checkout_readiness ?? [];
$stripe_key_status = static function ( bool $present, bool $valid ): string {
	if ( ! $present ) { return 'Not set'; }
	return $valid ? 'Valid' : 'Invalid format';
};
$route_status = static fn( bool $implemented ): string => $implemented ? 'Implemented' : 'Phase 3 — not yet implemented';
?>
<div class="card wpq-health-card">
<h2>Payment Readiness</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) ( $cr['production_ready'] ?? false ),      'Overall payment readiness',   ( $cr['production_ready'] ?? false ) ? 'Production ready' : ( $cr['readiness_status'] ?? 'Not ready' ) );
$check( (bool) ( $cr['checkout_enabled'] ?? false ),      'Checkout feature flag',        ( $cr['checkout_enabled'] ?? false ) ? 'WPQ_CHECKOUT_ENABLED = true' : 'Disabled (phase-gated)' );
$check( (int) ( $cr['priced_product_count'] ?? 0 ) > 0,  'Pricing options configured',   (int) ( $cr['priced_product_count'] ?? 0 ) . ' active option(s) with a Stripe Price ID' );
$check( (bool) ( $cr['stripe_api_initialised'] ?? false ),'Stripe API initialised',       ( $cr['stripe_api_initialised'] ?? false ) ? 'Yes' : 'No — keys or library unavailable' );
$check( (bool) ( $cr['stripe_library_available'] ?? false ), 'Stripe PHP library',        ( $cr['stripe_library_available'] ?? false ) ? 'Present' : 'Missing (composer require stripe/stripe-php)' );
$check( (bool) ( $cr['dompdf_library_available'] ?? false ), 'Dompdf PDF library',        ( $cr['dompdf_library_available'] ?? false ) ? 'Present' : 'Missing (composer require dompdf/dompdf)' );
$check( (bool) ( $cr['checkout_route_registered'] ?? false ), 'Checkout route',           $route_status( $cr['checkout_route_registered'] ?? false ) );
$check( (bool) ( $cr['webhook_route_registered'] ?? false ),  'Stripe webhook route',     $route_status( $cr['webhook_route_registered'] ?? false ) );
$check( (bool) ( $cr['report_delivery_route_registered'] ?? false ), 'Report delivery route', $route_status( $cr['report_delivery_route_registered'] ?? false ) );
$check( (bool) ( $cr['report_template_available'] ?? false ) && (bool) ( $cr['report_renderer_available'] ?? false ), 'Report generation', ( $cr['report_template_available'] ?? false ) && ( $cr['report_renderer_available'] ?? false ) ? 'Ready' : 'Phase 3 — not yet implemented' );
$check( (bool) ( $cr['atomic_report_token_support'] ?? false ), 'Report token delivery',  ( $cr['atomic_report_token_support'] ?? false ) ? 'Supported' : 'Method missing' );
?>
</tbody></table>
</div>

<?php
// ── 9. Migration Log ─────────────────────────────────────────────────────────
$last_run   = (string) ( $schema['last_migration_run'] ?? '' );
$last_error = (string) ( $schema['last_migration_error'] ?? '' );
$error_list = $schema['last_migration_errors'] ?? [];
if ( ! is_array( $error_list ) ) { $error_list = []; }
?>
<div class="card wpq-health-card">
<h2>Migration Log</h2>
<table class="widefat striped"><tbody>
<?php
if ( $last_run !== '' ) :
	$ok( 'Last migration run', $last_run );
else :
	$warn( 'Last migration run', 'Never recorded' );
endif;

if ( $last_error !== '' ) :
	$err( 'Last migration error', $last_error );
else :
	$ok( 'Last migration error', 'None' );
endif;
?>
</tbody></table>
<?php if ( $error_list ) : ?>
<details style="margin:8px 0 0"><summary style="cursor:pointer;font-size:13px">Recent migration errors (<?php echo count( $error_list ); ?>)</summary>
<ul style="margin:8px 0 0 20px;font-size:12px;font-family:monospace;color:#555">
	<?php foreach ( array_slice( $error_list, -20 ) as $entry ) : ?>
	<li><?php echo esc_html( is_array( $entry ) ? wp_json_encode( $entry ) : (string) $entry ); ?></li>
	<?php endforeach; ?>
</ul>
</details>
<?php endif; ?>
</div>

</div><!-- .wrap -->
