<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var array<int, object{id:int, questionnaire_ref?: string|null, questionnaire_id?: int|null, name:string, description:string, price_gbp:numeric-string|float|int, billing_type:string, report_type:string, stripe_price_id:string|null, status:string}> $products
 */
$products = $products ?? [];
$checkout_readiness = isset( $checkout_readiness ) && is_array( $checkout_readiness ) ? $checkout_readiness : [
	'checkout_enabled'        => false,
	'publishable_key_present' => false,
	'secret_key_present'      => false,
	'webhook_secret_present'  => false,
	'publishable_key_valid'   => false,
	'publishable_key_source'  => 'none',
	'secret_key_valid'        => false,
	'secret_key_source'       => 'none',
	'webhook_secret_valid'    => false,
	'webhook_secret_source'   => 'none',
	'active_product_count'    => 0,
	'priced_product_count'    => 0,
	'checkout_route_registered' => false,
	'webhook_route_registered' => false,
	'report_delivery_route_registered' => false,
	'checkout_route_status' => 'phase_3_not_implemented',
	'webhook_route_status' => 'phase_3_not_implemented',
	'report_delivery_route_status' => 'phase_3_not_implemented',
	'report_template_available' => false,
	'report_renderer_available' => false,
	'report_storage_delivery_configured' => false,
	'report_storage_path' => '',
	'report_storage_path_available' => false,
	'report_storage_writable' => false,
	'report_storage_index_guard_present' => false,
	'report_storage_htaccess_guard_present' => false,
	'atomic_report_token_support' => false,
	'stripe_api_initialised' => false,
	'stripe_library_available' => false,
	'dompdf_library_available' => false,
	'readiness_status'        => 'configuration_missing',
	'production_ready'        => false,
];
$questionnaires = WPQ_Database::get_questionnaire_list();
usort( $questionnaires, fn( $a, $b ) => strcmp( $a->name, $b->name ) );
?>
<div class="wrap wpq-admin-wrap">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <h1 style="margin:0;display:flex;align-items:center;gap:16px;">
      Pricing
      <button type="button" id="wpq-add-product" class="page-title-action">Add Pricing Option</button>
    </h1>
    <div style="display:flex;align-items:center;gap:6px;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="button" title="Import pricing">&#8593; Import</a>
      <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=pricing' ), 'wpq_export_pricing' ) ); ?>" class="button" title="Export all pricing">&#8595; Export all</a>
    </div>
  </div>
  <p class="description">Paid report pricing options. Set a Stripe Price ID and mark an option <strong>Active</strong> to enable the upgrade CTA on the results screen.</p>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;"
       data-export-type="pricing"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_pricing' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">— Bulk action —</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
    <span style="flex:1;"></span>
    <input type="search" class="wpq-table-filter" style="height:30px;width:220px;" placeholder="Filter pricing…" aria-label="Filter pricing options">
    <span class="wpq-table-filter-count description"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" style="margin-top:8px;" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th class="wpq-col-ref">Ref</th>
        <th>Name</th>
        <th class="wpq-col-price">Price</th>
        <th class="wpq-col-billing">Billing</th>
        <th class="wpq-col-stripe">Stripe Price ID</th>
        <th class="wpq-col-status">Status</th>
        <th class="wpq-col-action" data-no-sort></th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $products ) ) : ?>
        <tr><td colspan="8">No pricing options found. Click <strong>Add Pricing Option</strong> to create one.</td></tr>
      <?php else : ?>
        <?php foreach ( $products as $p ) : ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo (int) $p->id; ?>"></td>
            <td><?php echo esc_html( $p->questionnaire_ref ?? '—' ); ?></td>
            <td>
              <strong><?php echo esc_html( $p->name ); ?></strong>
              <br><span class="description"><?php echo esc_html( $p->description ); ?></span>
            </td>
            <td>£<?php echo number_format( (float) $p->price_gbp, 2 ); ?></td>
            <td><?php echo esc_html( str_replace( '_', ' ', $p->billing_type ) ); ?></td>
            <td>
              <?php if ( $p->stripe_price_id ) : ?>
                <code><?php echo esc_html( $p->stripe_price_id ); ?></code>
              <?php else : ?>
                <span class="description">Not set</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ( $p->status === 'active' ) : ?>
                <span class="wpq-status-active">&#9679; Active</span>
              <?php else : ?>
                <span class="wpq-status-inactive">&#9679; Inactive</span>
              <?php endif; ?>
            </td>
            <td style="white-space:nowrap;">
              <button type="button" class="button button-small wpq-edit-product"
                data-id="<?php echo (int) $p->id; ?>"
                data-name="<?php echo esc_attr( $p->name ); ?>"
                data-description="<?php echo esc_attr( $p->description ); ?>"
                data-price="<?php echo esc_attr( $p->price_gbp ); ?>"
                data-stripe="<?php echo esc_attr( $p->stripe_price_id ); ?>"
                data-billing="<?php echo esc_attr( $p->billing_type ); ?>"
                data-report="<?php echo esc_attr( $p->report_type ); ?>"
                data-status="<?php echo esc_attr( $p->status ); ?>"
                data-questionnaire="<?php echo esc_attr( $p->questionnaire_id ?? '' ); ?>"
              >Edit</button>
              <button type="button" class="button button-small wpq-delete-product"
                data-id="<?php echo (int) $p->id; ?>"
                data-name="<?php echo esc_attr( $p->name ); ?>"
                style="color:#a00;"
              >Delete</button>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- ================================================================ -->
  <!-- Inline product editor                                             -->
  <!-- ================================================================ -->
  <div id="wpq-product-editor" class="wpq-card wpq-hidden" style="margin-top:24px;max-width:800px;">
    <h2 id="wpq-pe-title" style="margin-top:0;">Add Pricing Option</h2>
    <input type="hidden" id="wpq-pe-id" value="">

    <table class="form-table" style="margin-top:0;">
      <tr>
        <th style="width:180px;"><label for="wpq-pe-name">Name <span style="color:#d63638;">*</span></label></th>
        <td><input type="text" id="wpq-pe-name" class="regular-text" placeholder="e.g. CyberCheck Professional Report"></td>
      </tr>
      <tr>
        <th><label for="wpq-pe-description">Description</label></th>
        <td><textarea id="wpq-pe-description" class="large-text" rows="3" placeholder="Shown on the upgrade CTA"></textarea></td>
      </tr>
      <tr>
        <th><label for="wpq-pe-questionnaire">Questionnaire</label></th>
        <td>
          <select id="wpq-pe-questionnaire">
            <option value="">— All / cross-questionnaire —</option>
            <?php foreach ( $questionnaires as $q ) : ?>
              <option value="<?php echo (int) $q->id; ?>"><?php echo esc_html( '[' . $q->ref . '] ' . $q->name ); ?></option>
            <?php endforeach; ?>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-price">Price (GBP)</label></th>
        <td><input type="number" id="wpq-pe-price" class="small-text" step="0.01" min="0" value="0.00"></td>
      </tr>
      <tr>
        <th><label for="wpq-pe-billing">Billing type</label></th>
        <td>
          <select id="wpq-pe-billing">
            <option value="one_off">One-off payment</option>
            <option value="subscription_annual">Annual subscription</option>
            <option value="subscription_monthly">Monthly subscription</option>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-report">Report type</label></th>
        <td>
          <select id="wpq-pe-report">
            <option value="professional">Professional</option>
            <option value="annual">Annual</option>
            <option value="bundle">Bundle</option>
          </select>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-stripe">Stripe Price ID</label></th>
        <td>
          <input type="text" id="wpq-pe-stripe" class="regular-text" placeholder="price_…">
          <p class="description">Auto-created in Stripe on save when the linked questionnaire has a Stripe product. Or enter an existing <code>price_…</code> ID manually.</p>
        </td>
      </tr>
      <tr>
        <th><label for="wpq-pe-status">Status</label></th>
        <td>
          <select id="wpq-pe-status">
            <option value="inactive">Inactive</option>
            <option value="active">Active</option>
          </select>
          <p class="description">Stripe Price ID is auto-created on save when a questionnaire with a Stripe product is linked.</p>
        </td>
      </tr>
    </table>

    <p>
      <button type="button" id="wpq-save-product" class="button button-primary">Save</button>
      <button type="button" id="wpq-cancel-product" class="button" style="margin-left:8px;">Cancel</button>
      <span id="wpq-pe-status-msg" style="margin-left:12px;" class="wpq-hidden"></span>
    </p>
  </div>
</div>
