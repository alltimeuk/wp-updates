<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var WPQ_Submissions_Table $table
 */
$deleted_count = isset( $_GET['deleted'] ) ? max( 0, (int) sanitize_text_field( wp_unslash( $_GET['deleted'] ) ) ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$failed_count  = isset( $_GET['failed'] ) ? max( 0, (int) sanitize_text_field( wp_unslash( $_GET['failed'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap wpq-admin-wrap">
  <h1 class="wp-heading-inline">Submissions</h1>
  <hr class="wp-header-end">

  <?php if ( $deleted_count !== null && $deleted_count > 0 ) : ?>
    <div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( '%d submission(s) removed.', $deleted_count ) ); ?></p></div>
  <?php endif; ?>

  <?php if ( $failed_count > 0 ) : ?>
    <div class="notice notice-error is-dismissible"><p><?php echo esc_html( sprintf( '%d submission(s) could not be removed.', $failed_count ) ); ?></p></div>
  <?php endif; ?>

  <form method="get">
    <input type="hidden" name="page" value="wpq-submissions">
    <?php
    $table->search_box( 'Search submissions', 'wpq-submissions' );
    $table->display();
    ?>
  </form>
</div>
