<?php
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Import_Export {

	private const EXPORT_VERSION = '1.0';

	private const SETTINGS_KEYS = [
		'wpq_stripe_publishable_key',
		'wpq_stripe_secret_key',
		'wpq_stripe_webhook_secret',
		'wpq_claude_model',
		'wpq_purge_abandoned_days',
		'wpq_anonymise_completed_days',
		'wpq_delete_data_on_uninstall',
		'wpq_halopsa_api_url',
		'wpq_halopsa_client_id',
		'wpq_halopsa_client_secret',
		'wpq_halopsa_prospect_type',
		'wpq_halopsa_field_score',
		'wpq_halopsa_field_grade',
		'wpq_halopsa_field_ref',
		'wpq_halopsa_field_status',
	];

	// ------------------------------------------------------------------ //
	// EXPORT                                                               //
	// ------------------------------------------------------------------ //

	public static function export( string $type, array $ids = [] ): array {
		$meta = [
			'version'        => self::EXPORT_VERSION,
			'type'           => $type,
			'plugin_version' => WPQ_VERSION,
			'exported_at'    => gmdate( 'c' ),
		];

		switch ( $type ) {
			case 'questionnaires':
                $data = self::export_questionnaires( $ids );
                break;
			case 'contacts':
                $data = self::export_contacts( $ids );
                break;
			case 'orders':
                $data = self::export_orders( $ids );
                break;
			case 'pricing':
                $data = self::export_pricing( $ids );
                break;
			case 'coupons':
                $data = self::export_coupons( $ids );
                break;
			case 'ctas':
                $data = self::export_ctas( $ids );
                break;
			case 'settings':
                $data = self::export_settings();
                break;
			default:
                $data = [];
		}

		return [ 'wpq_export' => $meta, 'data' => $data ];
	}

	private static function export_questionnaires( array $ids = [] ): array {
		global $wpdb;

		if ( ! empty( $ids ) ) {
			$ids_int = array_map( 'intval', $ids );
			$ph      = implode( ',', array_fill( 0, count( $ids_int ), '%d' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $ph is an internal placeholder string, not user input.
			$questionnaires = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpq_questionnaires WHERE id IN ({$ph}) ORDER BY id ASC", ...$ids_int ) );
		} else {
			$questionnaires = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wpq_questionnaires ORDER BY id ASC" );
		}

		$out = [];
		foreach ( $questionnaires as $q ) {
			$domains = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpq_domains WHERE questionnaire_id = %d ORDER BY sort_order ASC", (int) $q->id ) );

			$domains_out = [];
			foreach ( $domains as $d ) {
				$questions = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpq_questions WHERE domain_id = %d ORDER BY sort_order ASC", (int) $d->id ) );

				$questions_out = [];
				foreach ( $questions as $question ) {
					$options = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpq_question_options WHERE question_id = %d ORDER BY sort_order ASC", (int) $question->id ) );
					$max_score = null;
					if ( isset( $question->max_score ) && $question->max_score !== null && (int) $question->max_score > 0 ) {
						$max_score = (int) $question->max_score;
					}

					$options_out = [];
					foreach ( $options as $opt ) {
						$options_out[] = [
							'option_key'       => $opt->option_key,
							'option_label'     => $opt->option_label,
							'score'            => (int) $opt->score,
							'risk_level'       => $opt->risk_level,
							'finding_priority' => $opt->finding_priority,
							'finding_action'   => $opt->finding_action,
							'guidance'         => $opt->guidance,
							'sort_order'       => (int) $opt->sort_order,
							'is_default'       => (int) $opt->is_default,
							'requires_notes'   => (int) $opt->requires_notes,
							'exclusive'        => (int) $opt->exclusive,
						];
					}

					$questions_out[] = [
						'sort_order'       => (int) $question->sort_order,
						'question_text'    => $question->question_text,
						'question_ref'     => $question->question_ref,
						'question_type'    => $question->question_type,
						'is_required'      => (int) $question->is_required,
						'scoring_mode'     => $question->scoring_mode,
						'score_yes'        => (int) $question->score_yes,
						'score_partial'    => (int) $question->score_partial,
						'score_no'         => (int) $question->score_no,
						'question_weight'  => (int) $question->question_weight,
						'max_score'        => $max_score,
						'help_text'        => $question->help_text,
						'guidance_yes'     => $question->guidance_yes,
						'guidance_no'      => $question->guidance_no,
						'guidance_partial' => $question->guidance_partial,
						'recommendation'   => $question->recommendation,
						'min_selections'   => $question->min_selections !== null ? (int) $question->min_selections : null,
						'max_selections'   => $question->max_selections !== null ? (int) $question->max_selections : null,
						'condition_on_ref' => $question->condition_on_ref,
						'condition_value'  => $question->condition_value,
						'condition_op'     => $question->condition_op,
						'options'          => $options_out,
					];
				}

				$domains_out[] = [
					'sort_order'    => (int) $d->sort_order,
					'slug'          => $d->slug,
					'name'          => $d->name,
					'icon'          => $d->icon,
					'brief'         => $d->brief,
					'domain_weight' => (int) $d->domain_weight,
					'questions'     => $questions_out,
				];
			}

			$thresholds = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpq_grade_thresholds WHERE questionnaire_id = %d ORDER BY min_score DESC", (int) $q->id ) );
			$thresholds_out = [];
			foreach ( $thresholds as $t ) {
				$thresholds_out[] = [
					'min_score'    => (int) $t->min_score,
					'grade_id'     => $t->grade_id,
					'grade_label'  => $t->grade_label,
					'verdict_text' => $t->verdict_text,
					'color_hex'    => $t->color_hex,
					'bg_hex'       => $t->bg_hex,
				];
			}

			$out[] = [
				'ref'               => $q->ref,
				'name'              => $q->name,
				'description'       => $q->description,
				'status'            => $q->status,
				'category'          => $q->category,
				'stripe_product_id' => $q->stripe_product_id,
				'domains'           => $domains_out,
				'grade_thresholds'  => $thresholds_out,
			];
		}

		return $out;
	}

	private static function export_contacts( array $ids = [] ): array {
		global $wpdb;

		if ( ! empty( $ids ) ) {
			$emails = array_values( array_filter( array_map( 'sanitize_email', $ids ) ) );
		} else {
			$emails = $wpdb->get_col( "SELECT DISTINCT contact_email FROM {$wpdb->prefix}wpq_submissions WHERE contact_email != '' AND deleted_at IS NULL ORDER BY contact_email" );
		}

		$out = [];
		foreach ( $emails as $email ) {
			$pref = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpq_contact_preferences WHERE email = %s", $email ) );

			$submissions = $wpdb->get_results( $wpdb->prepare(
				"SELECT s.*, q.ref AS questionnaire_ref FROM {$wpdb->prefix}wpq_submissions s
				 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = s.questionnaire_id
				 WHERE s.contact_email = %s AND s.deleted_at IS NULL
				 ORDER BY s.created_at ASC",
				$email
			) );

			$submissions_out = [];
			foreach ( $submissions as $s ) {
				$submissions_out[] = [
					'ref'                => $s->ref,
					'questionnaire_ref'  => $s->questionnaire_ref,
					'contact_name'       => $s->contact_name,
					'contact_company'    => $s->contact_company,
					'contact_phone'      => $s->contact_phone,
					'overall_score'      => $s->overall_score !== null ? (int) $s->overall_score : null,
					'grade_id'           => $s->grade_id,
					'answers_json'       => $s->answers_json,
					'domain_scores_json' => $s->domain_scores_json,
					'findings_json'      => $s->findings_json,
					'payment_status'     => $s->payment_status,
					'abandoned'          => (int) $s->abandoned,
					'started_at'         => $s->started_at,
					'completed_at'       => $s->completed_at,
					'duration_seconds'   => $s->duration_seconds !== null ? (int) $s->duration_seconds : null,
				];
			}

			$out[] = [
				'email'        => $email,
				'opted_out'    => $pref ? (bool) $pref->opted_out : false,
				'opted_out_at' => $pref ? $pref->opted_out_at : null,
				'submissions'  => $submissions_out,
			];
		}

		return $out;
	}

	private static function export_orders( array $ids = [] ): array {
		global $wpdb;

		if ( ! empty( $ids ) ) {
			$ids_esc = array_map( 'sanitize_text_field', $ids );
			$ph      = implode( ',', array_fill( 0, count( $ids_esc ), '%s' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $ph is an internal placeholder string, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT ps.*, s.ref AS submission_ref, s.contact_email, s.contact_name, s.contact_company,
				        p.slug AS product_slug, p.name AS product_name
				 FROM {$wpdb->prefix}wpq_payment_sessions ps
				 LEFT JOIN {$wpdb->prefix}wpq_submissions s ON s.id = ps.submission_id
				 LEFT JOIN {$wpdb->prefix}wpq_products p ON p.id = ps.product_id
				 WHERE s.deleted_at IS NULL AND ps.session_id IN ({$ph})
				 ORDER BY ps.created_at DESC",
				...$ids_esc
			) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$rows = $wpdb->get_results(
				"SELECT ps.*, s.ref AS submission_ref, s.contact_email, s.contact_name, s.contact_company,
				        p.slug AS product_slug, p.name AS product_name
				 FROM {$wpdb->prefix}wpq_payment_sessions ps
				 LEFT JOIN {$wpdb->prefix}wpq_submissions s ON s.id = ps.submission_id
				 LEFT JOIN {$wpdb->prefix}wpq_products p ON p.id = ps.product_id
				 WHERE s.deleted_at IS NULL
				 ORDER BY ps.created_at DESC"
			);
		}

		$out = [];
		foreach ( $rows as $r ) {
			$out[] = [
				'submission_ref'   => $r->submission_ref,
				'contact_email'    => $r->contact_email,
				'contact_name'     => $r->contact_name,
				'contact_company'  => $r->contact_company,
				'product_slug'     => $r->product_slug,
				'product_name'     => $r->product_name,
				'payment_status'   => $r->payment_status,
				'stripe_session_id'=> $r->session_id,
				'amount_total'     => $r->amount_total,
				'currency'         => $r->currency,
				'created_at'       => $r->created_at,
				'updated_at'       => $r->updated_at,
			];
		}

		return $out;
	}

	private static function export_pricing( array $ids = [] ): array {
		global $wpdb;

		if ( ! empty( $ids ) ) {
			$ids_int = array_map( 'intval', $ids );
			$ph      = implode( ',', array_fill( 0, count( $ids_int ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $ph is an internal placeholder string, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT p.*, q.ref AS questionnaire_ref FROM {$wpdb->prefix}wpq_products p
				 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = p.questionnaire_id
				 WHERE p.id IN ({$ph})
				 ORDER BY p.questionnaire_id, p.price_gbp",
				...$ids_int
			) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$rows = $wpdb->get_results(
				"SELECT p.*, q.ref AS questionnaire_ref FROM {$wpdb->prefix}wpq_products p
				 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = p.questionnaire_id
				 ORDER BY p.questionnaire_id, p.price_gbp"
			);
		}

		$out = [];
		foreach ( $rows as $r ) {
			$out[] = [
				'questionnaire_ref' => $r->questionnaire_ref,
				'name'              => $r->name,
				'slug'              => $r->slug,
				'description'       => $r->description,
				'price_gbp'         => (float) $r->price_gbp,
				'stripe_price_id'   => $r->stripe_price_id,
				'billing_type'      => $r->billing_type,
				'report_type'       => $r->report_type,
				'status'            => $r->status,
			];
		}

		return $out;
	}

	private static function export_coupons( array $ids = [] ): array {
		global $wpdb;

		if ( ! empty( $ids ) ) {
			$ids_int = array_map( 'intval', $ids );
			$ph      = implode( ',', array_fill( 0, count( $ids_int ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $ph is an internal placeholder string, not user input.
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT c.*, q.ref AS questionnaire_ref, p.slug AS product_slug
				 FROM {$wpdb->prefix}wpq_coupons c
				 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = c.questionnaire_id
				 LEFT JOIN {$wpdb->prefix}wpq_products p ON p.id = c.product_id
				 WHERE c.id IN ({$ph})
				 ORDER BY c.created_at DESC",
				...$ids_int
			) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$rows = $wpdb->get_results(
				"SELECT c.*, q.ref AS questionnaire_ref, p.slug AS product_slug
				 FROM {$wpdb->prefix}wpq_coupons c
				 LEFT JOIN {$wpdb->prefix}wpq_questionnaires q ON q.id = c.questionnaire_id
				 LEFT JOIN {$wpdb->prefix}wpq_products p ON p.id = c.product_id
				 ORDER BY c.created_at DESC"
			);
		}

		$out = [];
		foreach ( $rows as $r ) {
			$out[] = [
				'stripe_coupon_id'   => $r->stripe_coupon_id,
				'stripe_promo_id'    => $r->stripe_promo_id,
				'promo_code'         => $r->promo_code,
				'name'               => $r->name,
				'discount_type'      => $r->discount_type,
				'percent_off'        => $r->percent_off !== null ? (float) $r->percent_off : null,
				'amount_off'         => $r->amount_off !== null ? (int) $r->amount_off : null,
				'currency'           => $r->currency,
				'duration'           => $r->duration,
				'duration_in_months' => $r->duration_in_months !== null ? (int) $r->duration_in_months : null,
				'max_redemptions'    => $r->max_redemptions !== null ? (int) $r->max_redemptions : null,
				'redeem_by'          => $r->redeem_by,
				'scope'              => $r->scope,
				'questionnaire_ref'  => $r->questionnaire_ref,
				'product_slug'       => $r->product_slug,
				'status'             => $r->status,
				'created_at'         => $r->created_at,
			];
		}

		return $out;
	}

	private static function export_settings(): array {
		$out = [];
		foreach ( self::SETTINGS_KEYS as $key ) {
			$out[ $key ] = get_option( $key, '' );
		}
		return $out;
	}

	private static function export_ctas( array $ids = [] ): array {
		$out = [];
		foreach ( WPQ_Database::get_ctas_for_export( $ids ) as $cta ) {
			$out[] = [
				'category_slug' => (string) $cta->category_slug,
				'domain_slug'   => (string) $cta->domain_slug,
				'body_html'     => (string) $cta->body_html,
				'status'        => (string) $cta->status,
				'created_at'    => (string) $cta->created_at,
				'updated_at'    => (string) $cta->updated_at,
			];
		}
		return $out;
	}

	// ------------------------------------------------------------------ //
	// IMPORT — ANALYSE                                                     //
	// ------------------------------------------------------------------ //

	/** @return array{type:string, conflicts:list<array<string,string>>, clean_count:int, total:int, errors:list<string>} */
	public static function analyse( array $payload ): array {
		$type   = $payload['wpq_export']['type'] ?? '';
		$data   = $payload['data'] ?? [];
		$conflicts = [];
		$errors    = [];

		switch ( $type ) {
			case 'questionnaires':
				foreach ( $data as $item ) {
					$ref = $item['ref'] ?? '';
					if ( ! $ref ) { $errors[] = 'A questionnaire record is missing its ref field.';
continue; }
					$existing = WPQ_Database::get_questionnaire_any_status_by_ref( $ref );
					if ( $existing ) {
						$conflicts[] = [
							'key'    => $ref,
							'label'  => $item['name'] ?? $ref,
							'detail' => 'Current status: ' . $existing->status,
						];
					}
				}
				break;

			case 'contacts':
				foreach ( $data as $item ) {
					$email = $item['email'] ?? '';
					if ( ! $email ) continue;
					global $wpdb;
					$existing = (int) $wpdb->get_var( $wpdb->prepare(
						"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions WHERE contact_email = %s AND deleted_at IS NULL",
						$email
					) );
					if ( $existing > 0 ) {
						$sub_count = count( $item['submissions'] ?? [] );
						$conflicts[] = [
							'key'    => $email,
							'label'  => $email,
							'detail' => $sub_count . ' submission(s) in import',
						];
					}
				}
				break;

			case 'pricing':
				foreach ( $data as $item ) {
					$slug = $item['slug'] ?? '';
					if ( ! $slug ) continue;
					if ( WPQ_Database::slug_exists( $slug ) ) {
						$conflicts[] = [
							'key'    => $slug,
							'label'  => $item['name'] ?? $slug,
							'detail' => '£' . number_format( (float) ( $item['price_gbp'] ?? 0 ), 2 ),
						];
					}
				}
				break;

			case 'coupons':
				foreach ( $data as $item ) {
					global $wpdb;
					$coupon_id = $item['stripe_coupon_id'] ?? '';
					if ( ! $coupon_id ) continue;
					$existing = $wpdb->get_var( $wpdb->prepare(
						"SELECT id FROM {$wpdb->prefix}wpq_coupons WHERE stripe_coupon_id = %s",
						$coupon_id
					) );
					if ( $existing ) {
						$conflicts[] = [
							'key'    => $coupon_id,
							'label'  => $item['name'] ?? $coupon_id,
							'detail' => $item['promo_code'] ?? '',
						];
					}
				}
				break;

			case 'ctas':
				foreach ( $data as $item ) {
					$key = self::cta_import_key( $item );
					if ( $key === '' ) {
						$errors[] = 'A call-to-action record is missing its category_slug field.';
						continue;
					}

					$existing = WPQ_Database::get_cta_by_scope(
						(string) ( $item['category_slug'] ?? '' ),
						(string) ( $item['domain_slug'] ?? '' )
					);
					if ( $existing ) {
						$category = sanitize_key( (string) ( $item['category_slug'] ?? '' ) );
						$domain = sanitize_key( (string) ( $item['domain_slug'] ?? '' ) );
						$conflicts[] = [
							'key'    => $key,
							'label'  => $domain !== '' ? "{$category} / {$domain}" : "{$category} / Category-wide",
							'detail' => 'Current status: ' . (string) $existing->status,
						];
					}
				}
				break;

			case 'orders':
			case 'settings':
				// Orders: imported individually (skip on dup). Settings: no per-item conflicts.
				break;
		}

		$total = is_array( $data ) ? count( $data ) : 0;

		return [
			'type'        => $type,
			'conflicts'   => $conflicts,
			'clean_count' => max( 0, $total - count( $conflicts ) ),
			'total'       => $total,
			'errors'      => $errors,
		];
	}

	// ------------------------------------------------------------------ //
	// IMPORT — APPLY                                                       //
	// ------------------------------------------------------------------ //

	/** @return array{imported:int, skipped:int, errors:list<string>} */
	public static function apply( array $payload, array $resolutions ): array {
		$type     = $payload['wpq_export']['type'] ?? '';
		$data     = $payload['data'] ?? [];
		$imported = 0;
		$skipped  = 0;
		$errors   = [];

		switch ( $type ) {
			case 'questionnaires':
				foreach ( $data as $item ) {
					$ref      = $item['ref'] ?? '';
					$existing = WPQ_Database::get_questionnaire_any_status_by_ref( $ref );
					if ( $existing && ( $resolutions[ $ref ] ?? 'skip' ) === 'skip' ) {
						$skipped++;
						continue;
					}
					$result = self::import_questionnaire( $item, $existing ? (int) $existing->id : null );
					if ( $result['created'] ) {
						$imported++;
					}
					if ( ! empty( $result['q_errors'] ) ) {
						$cnt     = count( $result['q_errors'] );
						$detail  = implode( '; ', array_slice( $result['q_errors'], 0, 10 ) );
						$detail .= $cnt > 10 ? ' … and ' . ( $cnt - 10 ) . ' more' : '';
						$errors[] = "Questionnaire {$ref} — {$cnt} row(s) failed: {$detail}";
					}
				}
				break;

			case 'contacts':
				foreach ( $data as $item ) {
					$email = $item['email'] ?? '';
					global $wpdb;
					$existing = (int) $wpdb->get_var( $wpdb->prepare(
						"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions WHERE contact_email = %s AND deleted_at IS NULL",
						$email
					) );
					if ( $existing > 0 && ( $resolutions[ $email ] ?? 'skip' ) === 'skip' ) {
						$skipped++;
						continue;
					}
					$r = self::import_contact( $item );
					$imported += $r['imported'];
					$skipped  += $r['skipped'];
					$errors    = array_merge( $errors, $r['errors'] );
				}
				break;

			case 'pricing':
				foreach ( $data as $item ) {
					$slug = $item['slug'] ?? '';
					if ( WPQ_Database::slug_exists( $slug ) && ( $resolutions[ $slug ] ?? 'skip' ) === 'skip' ) {
						$skipped++;
						continue;
					}
					self::import_product( $item ) ? $imported++ : $skipped++;
				}
				break;

			case 'coupons':
				foreach ( $data as $item ) {
					global $wpdb;
					$coupon_id  = $item['stripe_coupon_id'] ?? '';
					$existing   = (int) $wpdb->get_var( $wpdb->prepare(
						"SELECT id FROM {$wpdb->prefix}wpq_coupons WHERE stripe_coupon_id = %s",
						$coupon_id
					) );
					if ( $existing && ( $resolutions[ $coupon_id ] ?? 'skip' ) === 'skip' ) {
						$skipped++;
						continue;
					}
					self::import_coupon( $item, $existing ?: null ) ? $imported++ : $skipped++;
				}
				break;

			case 'ctas':
				foreach ( $data as $item ) {
					$key = self::cta_import_key( $item );
					if ( $key === '' ) {
						$errors[] = 'A call-to-action record is missing its category_slug field.';
						$skipped++;
						continue;
					}

					$existing = WPQ_Database::get_cta_by_scope(
						(string) ( $item['category_slug'] ?? '' ),
						(string) ( $item['domain_slug'] ?? '' )
					);
					if ( $existing && ( $resolutions[ $key ] ?? 'skip' ) === 'skip' ) {
						$skipped++;
						continue;
					}

					self::import_cta( $item, $existing ? (int) $existing->id : null ) ? $imported++ : $skipped++;
				}
				break;

			case 'orders':
				foreach ( $data as $item ) {
					$r = self::import_order( $item );
					if ( $r === true ) {
						$imported++;
					} elseif ( is_string( $r ) ) {
						$errors[] = $r;
						$skipped++;
					} else {
						$skipped++;
					}
				}
				break;

			case 'settings':
				if ( is_array( $data ) ) {
					foreach ( self::SETTINGS_KEYS as $key ) {
						if ( array_key_exists( $key, $data ) ) {
							update_option( $key, $data[ $key ] );
						}
					}
					$imported = count( self::SETTINGS_KEYS );
				}
				break;
		}

		return [ 'imported' => $imported, 'skipped' => $skipped, 'errors' => $errors ];
	}

	// ------------------------------------------------------------------ //
	// IMPORT HELPERS                                                       //
	// ------------------------------------------------------------------ //

	/** @return array{created:bool,q_errors:list<string>} */
	private static function import_questionnaire( array $item, ?int $existing_id ): array {
		global $wpdb;
		$q_data = [
			'name'              => sanitize_text_field( $item['name'] ?? '' ),
			'description'       => sanitize_textarea_field( $item['description'] ?? '' ),
			'status'            => in_array( $item['status'] ?? '', [ 'draft', 'preview', 'live', 'retired' ], true ) ? $item['status'] : 'draft',
			'category'          => sanitize_text_field( $item['category'] ?? '' ),
			'stripe_product_id' => sanitize_text_field( $item['stripe_product_id'] ?? '' ) ?: null,
		];

		if ( $existing_id ) {
			WPQ_Database::update_questionnaire( $existing_id, $q_data );
			foreach ( WPQ_Database::get_domains( $existing_id ) as $d ) {
				WPQ_Database::delete_domain( (int) $d->id );
			}
			foreach ( WPQ_Database::get_grade_thresholds( $existing_id ) as $t ) {
				WPQ_Database::delete_grade_threshold( (int) $t->id );
			}
			$q_id = $existing_id;
		} else {
			$q_data['ref'] = sanitize_text_field( $item['ref'] ?? '' );
			$q_id          = WPQ_Database::insert_questionnaire( $q_data );
			if ( ! $q_id ) {
				return [ 'created' => false, 'q_errors' => [ 'Questionnaire record insert failed: ' . $wpdb->last_error ] ];
			}
		}

		$q_errors = [];
		$q_seq    = 0;

		foreach ( $item['domains'] ?? [] as $d ) {
			$d_name = sanitize_text_field( $d['name'] ?? '' );
			$d_id   = WPQ_Database::insert_domain( [
				'questionnaire_id' => $q_id,
				'sort_order'       => (int) ( $d['sort_order'] ?? 0 ),
				'slug'             => sanitize_text_field( $d['slug'] ?? '' ),
				'name'             => $d_name,
				'icon'             => sanitize_text_field( $d['icon'] ?? '' ),
				'brief'            => sanitize_textarea_field( $d['brief'] ?? '' ),
				'domain_weight'    => (int) ( $d['domain_weight'] ?? 100 ),
			] );
			if ( ! $d_id ) {
				$q_errors[] = 'Domain "' . $d_name . '": ' . ( $wpdb->last_error ?: 'insert failed' );
				continue;
			}

			foreach ( $d['questions'] ?? [] as $qu ) {
				$q_seq++;
				$wpdb->last_error = '';
				$max_score = null;
				if ( isset( $qu['max_score'] ) && $qu['max_score'] !== null && $qu['max_score'] !== '' && (int) $qu['max_score'] > 0 ) {
					$max_score = (int) $qu['max_score'];
				}

				$qu_id = WPQ_Database::insert_question( [
					'domain_id'        => $d_id,
					'sort_order'       => (int) ( $qu['sort_order'] ?? 0 ),
					'question_text'    => sanitize_textarea_field( $qu['question_text'] ?? '' ),
					'question_ref'     => sanitize_text_field( $qu['question_ref'] ?? '' ),
					'question_type'    => sanitize_text_field( $qu['question_type'] ?? 'tri_state' ),
					'is_required'      => (int) ( $qu['is_required'] ?? 1 ),
					'scoring_mode'     => sanitize_text_field( $qu['scoring_mode'] ?? 'legacy_tri_state' ),
					'score_yes'        => (int) ( $qu['score_yes'] ?? 2 ),
					'score_partial'    => (int) ( $qu['score_partial'] ?? 1 ),
					'score_no'         => (int) ( $qu['score_no'] ?? 0 ),
					'question_weight'  => (int) ( $qu['question_weight'] ?? 100 ),
					'max_score'        => $max_score,
					'help_text'        => sanitize_textarea_field( $qu['help_text'] ?? '' ),
					'guidance_yes'     => sanitize_textarea_field( $qu['guidance_yes'] ?? '' ),
					'guidance_no'      => sanitize_textarea_field( $qu['guidance_no'] ?? '' ),
					'guidance_partial' => sanitize_textarea_field( $qu['guidance_partial'] ?? '' ),
					'recommendation'   => sanitize_textarea_field( $qu['recommendation'] ?? '' ),
					'min_selections'   => isset( $qu['min_selections'] ) ? (int) $qu['min_selections'] : null,
					'max_selections'   => isset( $qu['max_selections'] ) ? (int) $qu['max_selections'] : null,
					'condition_on_ref' => sanitize_text_field( $qu['condition_on_ref'] ?? '' ) ?: null,
					'condition_value'  => sanitize_text_field( $qu['condition_value'] ?? '' ) ?: null,
					'condition_op'     => sanitize_text_field( $qu['condition_op'] ?? '' ) ?: 'eq',
				] );
				if ( ! $qu_id ) {
					$label        = sanitize_text_field( $qu['question_ref'] ?? '' ) ?: "row {$q_seq}";
					$q_errors[]   = $label . ': ' . ( $wpdb->last_error ?: 'insert returned 0' );
					continue;
				}

				foreach ( $qu['options'] ?? [] as $opt ) {
					WPQ_Database::insert_question_option( [
						'question_id'      => $qu_id,
						'option_key'       => sanitize_text_field( $opt['option_key'] ?? '' ),
						'option_label'     => sanitize_text_field( $opt['option_label'] ?? '' ),
						'score'            => (int) ( $opt['score'] ?? 0 ),
						'risk_level'       => sanitize_text_field( $opt['risk_level'] ?? '' ) ?: null,
						'finding_priority' => sanitize_text_field( $opt['finding_priority'] ?? '' ) ?: null,
						'finding_action'   => sanitize_textarea_field( $opt['finding_action'] ?? '' ) ?: null,
						'guidance'         => sanitize_textarea_field( $opt['guidance'] ?? '' ) ?: null,
						'sort_order'       => (int) ( $opt['sort_order'] ?? 0 ),
						'is_default'       => (int) ( $opt['is_default'] ?? 0 ),
						'is_active'        => 1,
						'requires_notes'   => (int) ( $opt['requires_notes'] ?? 0 ),
						'exclusive'        => (int) ( $opt['exclusive'] ?? 0 ),
					] );
				}
			}
		}

		foreach ( $item['grade_thresholds'] ?? [] as $t ) {
			WPQ_Database::insert_grade_threshold( [
				'questionnaire_id' => $q_id,
				'min_score'        => (int) ( $t['min_score'] ?? 0 ),
				'grade_id'         => sanitize_text_field( $t['grade_id'] ?? '' ),
				'grade_label'      => sanitize_text_field( $t['grade_label'] ?? '' ),
				'verdict_text'     => sanitize_textarea_field( $t['verdict_text'] ?? '' ),
				'color_hex'        => sanitize_hex_color( $t['color_hex'] ?? '#000000' ) ?? '#000000',
				'bg_hex'           => sanitize_hex_color( $t['bg_hex'] ?? '#ffffff' ) ?? '#ffffff',
			] );
		}

		return [ 'created' => true, 'q_errors' => $q_errors ];
	}

	/** @return array{imported:int, skipped:int, errors:list<string>} */
	private static function import_contact( array $item ): array {
		global $wpdb;
		$imported = 0;
		$skipped  = 0;
		$errors   = [];
		$email    = $item['email'] ?? '';

		if ( ! empty( $item['opted_out'] ) ) {
			WPQ_Database::set_contact_opt_out( $email, true, get_current_user_id() );
		}

		foreach ( $item['submissions'] ?? [] as $sub ) {
			$ref = $sub['ref'] ?? '';
			$existing = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}wpq_submissions WHERE ref = %s",
				$ref
			) );
			if ( $existing ) { $skipped++;
continue; }

			$q_ref       = $sub['questionnaire_ref'] ?? '';
			$questionnaire = $q_ref ? WPQ_Database::get_questionnaire_any_status_by_ref( $q_ref ) : null;
			if ( ! $questionnaire ) {
				$errors[] = "Submission {$ref}: questionnaire '{$q_ref}' not found on this site — skipped.";
				$skipped++;
				continue;
			}

			$result = $wpdb->insert(
				$wpdb->prefix . 'wpq_submissions',
				[
					'ref'                => $ref,
					'questionnaire_id'   => (int) $questionnaire->id,
					'contact_name'       => sanitize_text_field( $sub['contact_name'] ?? '' ),
					'contact_email'      => sanitize_email( $email ),
					'contact_company'    => sanitize_text_field( $sub['contact_company'] ?? '' ),
					'contact_phone'      => sanitize_text_field( $sub['contact_phone'] ?? '' ),
					'overall_score'      => isset( $sub['overall_score'] ) ? (int) $sub['overall_score'] : null,
					'grade_id'           => sanitize_text_field( $sub['grade_id'] ?? '' ),
					'answers_json'       => $sub['answers_json'] ?? '',
					'domain_scores_json' => $sub['domain_scores_json'] ?? '',
					'findings_json'      => $sub['findings_json'] ?? '',
					'payment_status'     => in_array( $sub['payment_status'] ?? '', [ 'none', 'pending', 'paid', 'failed', 'expired' ], true ) ? $sub['payment_status'] : 'none',
					'abandoned'          => (int) ( $sub['abandoned'] ?? 0 ),
					'started_at'         => sanitize_text_field( $sub['started_at'] ?? current_time( 'mysql', true ) ),
					'completed_at'       => sanitize_text_field( $sub['completed_at'] ?? '' ) ?: null,
					'duration_seconds'   => isset( $sub['duration_seconds'] ) ? (int) $sub['duration_seconds'] : null,
					'created_at'         => current_time( 'mysql', true ),
					'updated_at'         => current_time( 'mysql', true ),
				]
			);
			$result ? $imported++ : $errors[] = "Failed to insert submission {$ref}.";
		}

		return [ 'imported' => $imported, 'skipped' => $skipped, 'errors' => $errors ];
	}

	private static function import_product( array $item ): bool {
		global $wpdb;
		$slug = $item['slug'] ?? '';
		$q_ref = $item['questionnaire_ref'] ?? '';
		$questionnaire = $q_ref ? WPQ_Database::get_questionnaire_any_status_by_ref( $q_ref ) : null;

		$data = [
			'questionnaire_id' => $questionnaire ? (int) $questionnaire->id : null,
			'name'             => sanitize_text_field( $item['name'] ?? '' ),
			'slug'             => sanitize_title( $slug ),
			'description'      => sanitize_textarea_field( $item['description'] ?? '' ),
			'price_gbp'        => (float) ( $item['price_gbp'] ?? 0 ),
			'stripe_price_id'  => sanitize_text_field( $item['stripe_price_id'] ?? '' ),
			'billing_type'     => in_array( $item['billing_type'] ?? '', [ 'one_off', 'subscription_annual', 'subscription_monthly' ], true ) ? $item['billing_type'] : 'one_off',
			'report_type'      => in_array( $item['report_type'] ?? '', [ 'professional', 'annual', 'bundle' ], true ) ? $item['report_type'] : 'professional',
			'status'           => in_array( $item['status'] ?? '', [ 'active', 'inactive' ], true ) ? $item['status'] : 'active',
		];

		$existing_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_products WHERE slug = %s",
			$slug
		) );

		return $existing_id
			? WPQ_Database::update_product( $existing_id, $data )
			: WPQ_Database::insert_product( $data ) > 0;
	}

	private static function import_coupon( array $item, ?int $existing_id ): bool {
		global $wpdb;
		$q_ref = $item['questionnaire_ref'] ?? '';
		$questionnaire = $q_ref ? WPQ_Database::get_questionnaire_any_status_by_ref( $q_ref ) : null;

		$p_slug = $item['product_slug'] ?? '';
		$product_id = $p_slug ? (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_products WHERE slug = %s", $p_slug
		) ) : null;

		$data = [
			'stripe_coupon_id'   => sanitize_text_field( $item['stripe_coupon_id'] ?? '' ),
			'stripe_promo_id'    => sanitize_text_field( $item['stripe_promo_id'] ?? '' ) ?: null,
			'promo_code'         => sanitize_text_field( $item['promo_code'] ?? '' ) ?: null,
			'name'               => sanitize_text_field( $item['name'] ?? '' ),
			'discount_type'      => in_array( $item['discount_type'] ?? '', [ 'percent', 'fixed' ], true ) ? $item['discount_type'] : 'percent',
			'percent_off'        => isset( $item['percent_off'] ) ? (float) $item['percent_off'] : null,
			'amount_off'         => isset( $item['amount_off'] ) ? (int) $item['amount_off'] : null,
			'currency'           => sanitize_text_field( $item['currency'] ?? 'GBP' ),
			'duration'           => in_array( $item['duration'] ?? '', [ 'once', 'repeating', 'forever' ], true ) ? $item['duration'] : 'once',
			'duration_in_months' => isset( $item['duration_in_months'] ) ? (int) $item['duration_in_months'] : null,
			'max_redemptions'    => isset( $item['max_redemptions'] ) ? (int) $item['max_redemptions'] : null,
			'redeem_by'          => sanitize_text_field( $item['redeem_by'] ?? '' ) ?: null,
			'scope'              => in_array( $item['scope'] ?? '', [ 'all', 'questionnaire', 'catalogue_item' ], true ) ? $item['scope'] : 'all',
			'questionnaire_id'   => $questionnaire ? (int) $questionnaire->id : null,
			'product_id'         => $product_id ?: null,
			'status'             => in_array( $item['status'] ?? '', [ 'active', 'deleted' ], true ) ? $item['status'] : 'active',
		];

		return $existing_id
			? WPQ_Database::update_coupon( $existing_id, $data )
			: WPQ_Database::insert_coupon( $data ) > 0;
	}

	/** @return true|false|string  true=imported, false=skipped, string=error message */
	private static function import_order( array $item ) {
		global $wpdb;
		$sub_ref = $item['submission_ref'] ?? '';
		if ( ! $sub_ref ) return false;

		$submission_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_submissions WHERE ref = %s", $sub_ref
		) );
		if ( ! $submission_id ) return "Order for {$sub_ref}: submission not found on this site — skipped.";

		$session_id = $item['stripe_session_id'] ?? '';
		if ( ! $session_id ) return false;

		$already = $wpdb->get_var( $wpdb->prepare(
			"SELECT session_id FROM {$wpdb->prefix}wpq_payment_sessions WHERE session_id = %s", $session_id
		) );
		if ( $already ) return false;

		$p_slug = $item['product_slug'] ?? '';
		$product_id = $p_slug ? (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_products WHERE slug = %s", $p_slug
		) ) : 0;

		return WPQ_Database::upsert_payment_session( $session_id, [
			'submission_id'  => $submission_id,
			'product_id'     => $product_id ?: null,
			'payment_status' => $item['payment_status'] ?? 'paid',
			'amount_total'   => isset( $item['amount_total'] ) ? (int) $item['amount_total'] : null,
			'currency'       => strtolower( $item['currency'] ?? 'gbp' ),
		] );
	}

	private static function import_cta( array $item, ?int $existing_id ): bool {
		$category_slug = sanitize_key( (string) ( $item['category_slug'] ?? '' ) );
		if ( $category_slug === '' ) {
			return false;
		}

		$data = [
			'id'            => $existing_id ?: 0,
			'category_slug' => $category_slug,
			'domain_slug'   => sanitize_key( (string) ( $item['domain_slug'] ?? '' ) ),
			'body_html'     => wp_kses_post( (string) ( $item['body_html'] ?? '' ) ),
			'status'        => in_array( (string) ( $item['status'] ?? 'active' ), [ 'active', 'inactive' ], true ) ? (string) $item['status'] : 'active',
		];

		return WPQ_Database::upsert_cta( $data ) > 0;
	}

	private static function cta_import_key( array $item ): string {
		$category_slug = sanitize_key( (string) ( $item['category_slug'] ?? '' ) );
		if ( $category_slug === '' ) {
			return '';
		}

		return $category_slug . '|' . sanitize_key( (string) ( $item['domain_slug'] ?? '' ) );
	}
}
