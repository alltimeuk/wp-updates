<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-library-importer.php';
require_once WPQ_PLUGIN_DIR . 'public/class-wpq-shortcode.php';
require_once WPQ_PLUGIN_DIR . 'public/class-wpq-rest-api.php';
require_once WPQ_PLUGIN_DIR . 'public/class-wpq-halopsa-api.php';

class WPQ_Plugin {

	private static ?WPQ_Plugin $instance = null;

	public static function instance(): WPQ_Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->init_hooks();
	}

	private function init_hooks(): void {
		add_action( 'rest_api_init', [ WPQ_REST_API::class,     'register_routes' ] );
		add_action( 'rest_api_init', [ WPQ_HaloPSA_API::class, 'register_routes' ] );
		add_filter( 'rest_pre_serve_request', [ WPQ_REST_API::class, 'serve_report_download' ], 1, 4 );
		add_action( 'init',          [ WPQ_Shortcode::class,   'register' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_public_assets' ] );

		if ( is_admin() ) {
			require_once WPQ_PLUGIN_DIR . 'admin/class-wpq-admin.php';
			new WPQ_Admin();
		}
	}

	public function enqueue_public_assets(): void {
		// Only enqueue early on pages that have the shortcode in content or post meta.
		if ( ! $this->current_page_has_shortcode() ) return;

		WPQ_Shortcode::enqueue_assets();
	}

	private function current_page_has_shortcode(): bool {
		global $post;
		if ( ! is_a( $post, 'WP_Post' ) ) {
			return false;
		}
		if ( self::content_has_assessment_shortcode( $post->post_content ) ) {
			return true;
		}

		foreach ( get_post_meta( (int) $post->ID ) as $values ) {
			foreach ( (array) $values as $value ) {
				if ( self::content_has_assessment_shortcode( $value ) ) {
					return true;
				}
			}
		}

		return false;
	}

	private static function content_has_assessment_shortcode( $content ): bool {
		if ( is_array( $content ) ) {
			foreach ( $content as $value ) {
				if ( self::content_has_assessment_shortcode( $value ) ) {
					return true;
				}
			}
			return false;
		}

		if ( is_object( $content ) ) {
			return self::content_has_assessment_shortcode( get_object_vars( $content ) );
		}

		if ( ! is_string( $content ) || $content === '' ) {
			return false;
		}

		$decoded = maybe_unserialize( $content );
		if ( $decoded !== $content ) {
			return self::content_has_assessment_shortcode( $decoded );
		}

		foreach ( [ 'wpq_questionnaire', 'wpq_assessment', 'wpq_assessments', 'wpq_product' ] as $tag ) {
			if ( has_shortcode( $content, $tag ) ) {
				return true;
			}
		}

		return false;
	}

}
