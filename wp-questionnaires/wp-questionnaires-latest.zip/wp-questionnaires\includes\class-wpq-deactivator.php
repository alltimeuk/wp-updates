<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Deactivator {
	public static function deactivate(): void {
		// Roles, options, and tables are intentionally preserved on deactivation so
		// that re-activating the plugin restores full functionality without data loss.
		// Destructive cleanup (tables, options, role) runs only on uninstall via uninstall.php.

		// Flush rate-limit transients so stale windows don't carry over if the plugin
		// is re-activated after a settings change or IP rotation.
		global $wpdb;
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE '_transient_wpq_rl_%'
			    OR option_name LIKE '_transient_timeout_wpq_rl_%'"
		);
	}
}
