<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Authenticated REST endpoints for the HaloPSA pull integration.
 *
 * All routes live under /wpq/v1/api/ and require a WordPress Application
 * Password issued to a user with the wpq_halopsa_api capability.
 *
 * Usage (HTTP Basic Auth):
 *   Authorization: Basic base64(username:application-password)
 */
class WPQ_HaloPSA_API {

	public static function register_routes(): void {
		// GET /wpq/v1/api/submissions — paginated list.
		register_rest_route( WPQ_REST_NAMESPACE, '/api/submissions', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'list_submissions' ],
			'permission_callback' => [ self::class, 'check_permission' ],
		] );

		// GET /wpq/v1/api/submissions/pending — pending sync only.
		register_rest_route( WPQ_REST_NAMESPACE, '/api/submissions/pending', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'list_pending' ],
			'permission_callback' => [ self::class, 'check_permission' ],
		] );

		// GET /wpq/v1/api/submissions/{id} — full detail.
		register_rest_route( WPQ_REST_NAMESPACE, '/api/submissions/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'get_submission' ],
			'permission_callback' => [ self::class, 'check_permission' ],
			'args'                => [
				'id' => [ 'required' => true, 'validate_callback' => fn( $v ) => is_numeric( $v ) ],
			],
		] );

		// POST /wpq/v1/api/submissions/{id}/acknowledge — mark synced.
		register_rest_route( WPQ_REST_NAMESPACE, '/api/submissions/(?P<id>\d+)/acknowledge', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'acknowledge' ],
			'permission_callback' => [ self::class, 'check_permission' ],
			'args'                => [
				'id' => [ 'required' => true, 'validate_callback' => fn( $v ) => is_numeric( $v ) ],
			],
		] );

		// POST /wpq/v1/api/submissions/{id}/start — mark as processing.
		register_rest_route( WPQ_REST_NAMESPACE, '/api/submissions/(?P<id>\d+)/start', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'start_processing' ],
			'permission_callback' => [ self::class, 'check_permission' ],
			'args'                => [
				'id' => [ 'required' => true, 'validate_callback' => fn( $v ) => is_numeric( $v ) ],
			],
		] );

		// POST /wpq/v1/api/submissions/{id}/fail — record a failed attempt.
		register_rest_route( WPQ_REST_NAMESPACE, '/api/submissions/(?P<id>\d+)/fail', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'report_failure' ],
			'permission_callback' => [ self::class, 'check_permission' ],
			'args'                => [
				'id' => [ 'required' => true, 'validate_callback' => fn( $v ) => is_numeric( $v ) ],
			],
		] );
	}

	// ------------------------------------------------------------------ //
	// Permission check
	// ------------------------------------------------------------------ //

	public static function check_permission(): bool {
		return is_user_logged_in() && current_user_can( 'wpq_halopsa_api' );
	}

	// ------------------------------------------------------------------ //
	// GET /wpq/v1/api/submissions
	// ------------------------------------------------------------------ //

	public static function list_submissions( WP_REST_Request $request ): WP_REST_Response {
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?: 20 ) ) );

		$args = [
			'per_page'           => $per_page,
			'page'               => $page,
			'halopsa_sync_status'=> sanitize_text_field( $request->get_param( 'sync_status' ) ?? '' ) ?: null,
		];

		$questionnaire_ref = sanitize_text_field( $request->get_param( 'questionnaire' ) ?? '' );
		if ( $questionnaire_ref ) {
			$q = WPQ_Database::get_questionnaire_by_ref( strtoupper( $questionnaire_ref ) );
			if ( $q ) {
				$args['questionnaire_id'] = (int) $q->id;
			}
		}

		$abandoned = $request->get_param( 'abandoned' );
		if ( $abandoned !== null ) {
			$args['abandoned'] = (int) $abandoned;
		}

		$result = WPQ_Database::get_submissions( $args );
		$rows   = $result['items'];
		$total  = $result['total'];

		return new WP_REST_Response( [
			'status'      => 'ok',
			'page'        => $page,
			'per_page'    => $per_page,
			'total'       => $total,
			'pages'       => (int) ceil( $total / $per_page ),
			'submissions' => array_map( [ self::class, 'format_submission_summary' ], $rows ),
		], 200 );
	}

	// ------------------------------------------------------------------ //
	// GET /wpq/v1/api/submissions/pending
	// ------------------------------------------------------------------ //

	public static function list_pending( WP_REST_Request $request ): WP_REST_Response {
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?: 50 ) ) );

		$result = WPQ_Database::get_submissions_pending_halopsa_sync( $page, $per_page );

		return new WP_REST_Response( [
			'status'      => 'ok',
			'page'        => $page,
			'per_page'    => $per_page,
			'total'       => $result['total'],
			'pages'       => (int) ceil( $result['total'] / $per_page ),
			'submissions' => array_map( [ self::class, 'format_submission_detail' ], $result['items'] ),
		], 200 );
	}

	// ------------------------------------------------------------------ //
	// GET /wpq/v1/api/submissions/{id}
	// ------------------------------------------------------------------ //

	public static function get_submission( WP_REST_Request $request ): WP_REST_Response {
		$id         = (int) $request->get_param( 'id' );
		$submission = WPQ_Database::get_submission( $id );

		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission not found.' );
		}

		return new WP_REST_Response( [
			'status'     => 'ok',
			'submission' => self::format_submission_detail( $submission ),
		], 200 );
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/api/submissions/{id}/acknowledge
	// ------------------------------------------------------------------ //

	public static function acknowledge( WP_REST_Request $request ): WP_REST_Response {
		$id   = (int) $request->get_param( 'id' );
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission = WPQ_Database::get_submission( $id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission not found.' );
		}

		$halopsa_lead_id = sanitize_text_field( $body['halopsa_lead_id'] ?? '' );
		if ( ! $halopsa_lead_id ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'halopsa_lead_id is required.' );
		}

		$updated = WPQ_Database::update_submission( $id, [
			'halopsa_lead_id'     => $halopsa_lead_id,
			'halopsa_sync_status' => 'synced',
			'halopsa_synced_at'   => current_time( 'mysql', true ),
		] );

		if ( ! $updated ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission record.' );
		}

		return new WP_REST_Response( [
			'status'          => 'ok',
			'submission_id'   => $id,
			'halopsa_lead_id' => $halopsa_lead_id,
			'sync_status'     => 'synced',
		], 200 );
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/api/submissions/{id}/start
	// ------------------------------------------------------------------ //

	public static function start_processing( WP_REST_Request $request ): WP_REST_Response {
		$id         = (int) $request->get_param( 'id' );
		$submission = WPQ_Database::get_submission( $id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission not found.' );
		}

		$current = $submission->halopsa_sync_status ?? '';
		if ( in_array( $current, [ 'synced', 'ignored', 'skipped' ], true ) ) {
			return self::error( 409, 'INVALID_TRANSITION', "Cannot start processing a submission with status '{$current}'." );
		}

		$updated = WPQ_Database::update_submission( $id, [
			'halopsa_sync_status'       => 'processing',
			'halopsa_last_attempted_at' => current_time( 'mysql', true ),
		] );

		if ( ! $updated ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission record.' );
		}

		return new WP_REST_Response( [
			'status'        => 'ok',
			'submission_id' => $id,
			'sync_status'   => 'processing',
		], 200 );
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/api/submissions/{id}/fail
	// ------------------------------------------------------------------ //

	public static function report_failure( WP_REST_Request $request ): WP_REST_Response {
		$id   = (int) $request->get_param( 'id' );
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission = WPQ_Database::get_submission( $id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission not found.' );
		}

		$error_message = sanitize_text_field( $body['error_message'] ?? '' );
		if ( $error_message === '' ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'error_message is required.' );
		}

		$retry      = ! empty( $body['retry'] );
		$new_status = $retry ? 'retry_pending' : 'failed';
		$retry_count = max( 0, (int) ( $submission->halopsa_retry_count ?? 0 ) ) + 1;

		$updated = WPQ_Database::update_submission( $id, [
			'halopsa_sync_status' => $new_status,
			'halopsa_sync_error'  => $error_message,
			'halopsa_retry_count' => $retry_count,
		] );

		if ( ! $updated ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission record.' );
		}

		return new WP_REST_Response( [
			'status'        => 'ok',
			'submission_id' => $id,
			'sync_status'   => $new_status,
			'retry_count'   => $retry_count,
		], 200 );
	}

	// ------------------------------------------------------------------ //
	// Formatters
	// ------------------------------------------------------------------ //

	private static function format_submission_summary( object $row ): array {
		return [
			'id'                  => (int) $row->id,
			'submission_ref'      => $row->ref,
			'questionnaire_ref'   => $row->questionnaire_ref ?? '',
			'contact_name'        => $row->contact_name,
			'contact_email'       => $row->contact_email,
			'contact_company'     => $row->contact_company,
			'overall_score'       => $row->overall_score !== null ? (int) $row->overall_score : null,
			'grade_label'         => $row->grade_label ?? $row->grade_id,
			'abandoned'           => (bool) $row->abandoned,
			'halopsa_sync_status' => $row->halopsa_sync_status,
			'halopsa_lead_id'     => $row->halopsa_lead_id,
			'created_at'          => $row->created_at,
		];
	}

	private static function format_submission_detail( object $row ): array {
		$domain_scores_raw = $row->domain_scores_json ? json_decode( $row->domain_scores_json, true ) : null;
		$domain_scores     = null;
		if ( is_array( $domain_scores_raw ) ) {
			// Return as slug → pct object per the API spec (not the raw scored array).
			$domain_scores = [];
			foreach ( $domain_scores_raw as $d ) {
				$domain_scores[ $d['slug'] ] = $d['pct'];
			}
		}
		$answers = $row->answers_json ? json_decode( $row->answers_json, true ) : null;

		return [
			'id'                  => (int) $row->id,
			'submission_ref'      => $row->ref,
			'questionnaire_ref'   => $row->questionnaire_ref ?? '',
			'questionnaire_name'  => $row->questionnaire_name ?? '',
			'contact_name'        => $row->contact_name,
			'contact_email'       => $row->contact_email,
			'contact_company'     => $row->contact_company,
			'contact_phone'       => $row->contact_phone,
			'overall_score'       => $row->overall_score !== null ? (int) $row->overall_score : null,
			'grade_label'         => $row->grade_label ?? $row->grade_id,
			'domain_scores'       => $domain_scores,
			'answers_json'        => $answers,
			'abandoned'           => (bool) $row->abandoned,
			'utm_source'          => $row->utm_source,
			'utm_medium'          => $row->utm_medium,
			'utm_campaign'        => $row->utm_campaign,
			'utm_term'            => $row->utm_term,
			'utm_content'         => $row->utm_content,
			'referrer_url'        => $row->referrer_url,
			'landing_page'        => $row->landing_page,
			'started_at'          => $row->started_at,
			'completed_at'        => $row->completed_at,
			'duration_seconds'    => $row->duration_seconds !== null ? (int) $row->duration_seconds : null,
			'halopsa_sync_status'       => $row->halopsa_sync_status,
			'halopsa_lead_id'           => $row->halopsa_lead_id,
			'halopsa_synced_at'         => $row->halopsa_synced_at,
			'halopsa_last_attempted_at' => $row->halopsa_last_attempted_at ?? null,
			'halopsa_retry_count'       => isset( $row->halopsa_retry_count ) ? (int) $row->halopsa_retry_count : 0,
			'halopsa_sync_error'        => $row->halopsa_sync_error ?? null,
			'created_at'                => $row->created_at,
		];
	}

	private static function error( int $status, string $code, string $message ): WP_REST_Response {
		return new WP_REST_Response( [
			'status'  => 'error',
			'code'    => $code,
			'message' => $message,
		], $status );
	}
}
