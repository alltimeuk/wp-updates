<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var array<int, object> $questionnaires
 * @var array<int, object> $categories
 */
$categories = $categories ?? [];
?>
<?php
$currency_symbols = [ 'GBP' => '£', 'USD' => '$', 'EUR' => '€', 'AUD' => 'A$', 'CAD' => 'C$' ];
$cat_labels = [];
foreach ( $categories as $cat ) {
	$cat_labels[ $cat->slug ] = $cat->name;
}
$status_labels = [
	'live'    => [ '● Live',    'wpq-status-live'    ],
	'preview' => [ '● Preview', 'wpq-status-preview' ],
	'draft'   => [ '● Draft',   'wpq-status-draft'   ],
	'retired' => [ '● Retired', 'wpq-status-retired' ],
];
?>
<div class="wrap wpq-admin-wrap">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
    <h1 style="margin:0;">Questionnaires</h1>
    <div style="display:flex;align-items:center;gap:6px;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="button" title="Import questionnaires">&#8593; Import</a>
      <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=questionnaires' ), 'wpq_export_questionnaires' ) ); ?>" class="button" title="Export all questionnaires">&#8595; Export all</a>
      <button class="button button-primary" id="wpq-new-q-btn">+ New Questionnaire</button>
    </div>
  </div>

  <!-- NEW Questionnaire modal -->
  <div id="wpq-new-q-modal" class="wpq-hidden" style="
    position:fixed;top:0;left:0;right:0;bottom:0;
    background:rgba(0,0,0,.5);z-index:99999;
    align-items:center;justify-content:center;">
    <div style="background:#fff;padding:28px 32px;border-radius:6px;min-width:380px;max-width:480px;box-shadow:0 4px 24px rgba(0,0,0,.18);">
      <h2 style="margin-top:0;">New Questionnaire</h2>
      <table class="form-table" style="margin:0 0 16px;">
        <tr>
          <th><label for="wpq-new-q-ref">Reference</label></th>
          <td><input type="text" id="wpq-new-q-ref" class="regular-text" placeholder="e.g. CS02" style="text-transform:uppercase;"></td>
        </tr>
        <tr>
          <th><label for="wpq-new-q-name">Name</label></th>
          <td><input type="text" id="wpq-new-q-name" class="regular-text" placeholder="Questionnaire name"></td>
        </tr>
        <tr>
          <th><label for="wpq-new-q-category">Category</label></th>
          <td>
            <select id="wpq-new-q-category">
              <?php foreach ( $categories as $cat ) : ?>
                <option value="<?php echo esc_attr( $cat->slug ); ?>"><?php echo esc_html( $cat->name ); ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
      </table>
      <p class="wpq-new-q-error wpq-hidden" style="color:#a00;margin:0 0 12px;"></p>
      <p style="margin:0;display:flex;gap:8px;">
        <button id="wpq-new-q-submit" class="button button-primary">Create</button>
        <button id="wpq-new-q-cancel" class="button">Cancel</button>
      </p>
    </div>
  </div>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;"
       data-export-type="questionnaires"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_questionnaires' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">— Bulk action —</option>
      <option value="publish">Go Live</option>
      <option value="archive">Retire</option>
      <option value="unarchive">Revert to Draft (Retired only)</option>
      <option value="remove">Remove (Retired only)</option>
      <option value="duplicate">Duplicate</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
    <span style="flex:1;"></span>
    <input type="search" class="wpq-table-filter" style="height:30px;width:220px;" placeholder="Filter questionnaires…" aria-label="Filter questionnaires">
    <span class="wpq-table-filter-count description"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th style="width:72px;">Ref</th>
        <th>Name</th>
        <th style="width:120px;">Category</th>
        <th style="width:90px;">Status</th>
        <th style="width:62px;" title="Number of domains">Domains</th>
        <th style="width:68px;" title="Total questions">Questions</th>
        <th style="width:64px;" title="Has scoreable questions">Scoring</th>
        <th style="width:62px;" title="Has grade thresholds">Grading</th>
        <th style="width:74px;">Submissions</th>
        <th style="width:76px;">Price</th>
        <th style="width:140px;">Stripe Product</th>
        <th style="width:56px;" data-no-sort>Edit</th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $questionnaires ) ) : ?>
        <tr><td colspan="13">No questionnaires found.</td></tr>
      <?php else : ?>
        <?php foreach ( $questionnaires as $q ) : ?>
          <?php
          $edit_url        = admin_url( 'admin.php?page=wpq-library&wpq_action=edit&id=' . $q->id );
          $sym             = $currency_symbols[ strtoupper( $q->stripe_currency ?? 'GBP' ) ] ?? 'GBP';
          $price_str       = ! empty( $q->stripe_price ) ? $sym . ' ' . number_format( (int) $q->stripe_price / 100, 2 ) : '—';
          $domain_count    = (int) ( $q->domain_count ?? 0 );
          $question_count  = (int) ( $q->question_count ?? 0 );
          $has_scoring     = (int) ( $q->scored_question_count ?? 0 ) > 0;
          $has_grading     = (int) ( $q->grade_count ?? 0 ) > 0;
          ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo (int) $q->id; ?>"></td>
            <td><strong><?php echo esc_html( $q->ref ); ?></strong></td>
            <td><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $q->name ); ?></a></td>
            <td style="font-size:.85em;"><?php echo esc_html( $cat_labels[ $q->category ] ?? $q->category ); ?></td>
            <td><?php
              $sl = $status_labels[ $q->status ] ?? null;
              if ( $sl ) {
                  printf( '<span class="%s">%s</span>', esc_attr( $sl[1] ), esc_html( $sl[0] ) );
              } else {
                  echo esc_html( $q->status );
              }
            ?></td>
            <td style="text-align:center;"><?php echo (int) $domain_count; ?></td>
            <td style="text-align:center;"><?php echo (int) $question_count; ?></td>
            <td style="text-align:center;"><span class="<?php echo esc_attr( $has_scoring ? 'wpq-check-yes' : 'wpq-check-no' ); ?>"><?php echo $has_scoring ? '&#10003;' : '&#10007;'; ?></span></td>
            <td style="text-align:center;"><span class="<?php echo esc_attr( $has_grading ? 'wpq-check-yes' : 'wpq-check-no' ); ?>"><?php echo $has_grading ? '&#10003;' : '&#10007;'; ?></span></td>
            <td style="text-align:center;"><?php echo (int) ( $q->submission_count ?? 0 ); ?></td>
            <td><?php echo esc_html( $price_str ); ?></td>
            <td><code style="font-size:.78em;word-break:break-all;"><?php echo esc_html( $q->stripe_product_id ?? '' ); ?></code></td>
            <td><a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small">Edit</a></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
