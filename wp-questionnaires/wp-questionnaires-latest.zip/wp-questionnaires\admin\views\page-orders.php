<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var array<int, object> $orders
 * @var int                $total
 * @var int                $per_page
 * @var int                $page
 * @var string             $search
 */
$orders   = $orders   ?? [];
/** @phpstan-ignore-next-line */
$total    = $total    ?? 0;
/** @phpstan-ignore-next-line */
$per_page = $per_page ?? 50;
/** @phpstan-ignore-next-line */
$page     = $page     ?? 1;
/** @phpstan-ignore-next-line */
$search   = $search   ?? '';

$total_pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 1;
$base_url    = admin_url( 'admin.php?page=wpq-orders' );

$status_styles = [
	'none'    => 'background:#6c757d;color:#fff;',
	'pending' => 'background:#fd7e14;color:#fff;',
	'paid'    => 'background:#198754;color:#fff;',
	'failed'  => 'background:#dc3545;color:#fff;',
	'expired' => 'background:#6c757d;color:#fff;',
];
$status_labels = [
	'none'    => 'None',
	'pending' => 'Pending',
	'paid'    => 'Paid',
	'failed'  => 'Failed',
	'expired' => 'Expired',
];
?>
<div class="wrap wpq-admin-wrap">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <h1 style="margin:0;">Orders</h1>
    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=orders' ), 'wpq_export_orders' ) ); ?>" class="button" title="Export all orders">&#8595; Export all</a>
  </div>
  <p class="description">All Stripe payment sessions. Read-only — manage individual payments in the Stripe dashboard.</p>

  <form method="get" style="margin:16px 0 8px;display:flex;gap:8px;align-items:center;">
    <input type="hidden" name="page" value="wpq-orders">
    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search email, name or session ID&hellip;" class="regular-text">
    <button type="submit" class="button">Search</button>
    <?php if ( $search ) : ?>
      <a href="<?php echo esc_url( $base_url ); ?>" class="button">Clear</a>
    <?php endif; ?>
    <span class="description" style="margin-left:8px;"><?php echo esc_html( number_format( $total ) ); ?> order<?php echo $total !== 1 ? 's' : ''; ?></span>
  </form>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;"
       data-export-type="orders"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_orders' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">— Bulk action —</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th style="width:140px;">Date</th>
        <th>Contact</th>
        <th>Questionnaire</th>
        <th style="width:160px;">Product</th>
        <th style="width:80px;">Status</th>
        <th style="width:100px;text-align:right;">Amount</th>
        <th style="width:120px;" data-no-sort>Session</th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $orders ) ) : ?>
        <tr><td colspan="8">No orders found<?php echo $search ? ' matching "' . esc_html( $search ) . '"' : ''; ?>.</td></tr>
      <?php else : ?>
        <?php foreach ( $orders as $o ) : ?>
          <?php
          $date    = $o->created_at ? wp_date( 'd M Y H:i', strtotime( $o->created_at ) ) : '—';
          $amount  = $o->amount_total !== null
                     ? number_format( (int) $o->amount_total / 100, 2 ) . ' ' . strtoupper( (string) $o->currency )
                     : '—';
          $status_style = $status_styles[ $o->payment_status ] ?? $status_styles['none'];
          $status_label = $status_labels[ $o->payment_status ] ?? ucfirst( $o->payment_status );
          $contact_url  = add_query_arg( [
              'page'       => 'wpq-contacts',
              'wpq_action' => 'view',
              'email'      => rawurlencode( $o->contact_email ),
          ], admin_url( 'admin.php' ) );
          ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo esc_attr( $o->session_id ); ?>"></td>
            <td><?php echo esc_html( $date ); ?></td>
            <td>
              <a href="<?php echo esc_url( $contact_url ); ?>"><?php echo esc_html( $o->contact_email ); ?></a>
              <?php if ( $o->contact_name ) : ?>
                <br><span class="description"><?php echo esc_html( $o->contact_name ); ?></span>
              <?php endif; ?>
            </td>
            <td><?php echo esc_html( $o->questionnaire_name ?: '—' ); ?></td>
            <td><?php echo esc_html( $o->product_name ?: '—' ); ?></td>
            <td>
              <span style="display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;<?php echo esc_attr( $status_style ); ?>">
                <?php echo esc_html( $status_label ); ?>
              </span>
            </td>
            <td style="text-align:right;font-variant-numeric:tabular-nums;"><?php echo esc_html( $amount ); ?></td>
            <td>
              <span title="<?php echo esc_attr( $o->session_id ); ?>" style="font-family:monospace;font-size:11px;">
                <?php echo esc_html( substr( (string) $o->session_id, 0, 18 ) . ( strlen( (string) $o->session_id ) > 18 ? '...' : '' ) ); ?>
              </span>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <?php if ( $total_pages > 1 ) : ?>
    <div style="margin-top:16px;">
      <?php
      // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- paginate_links returns safe HTML
      /** @phpstan-ignore-next-line */
      echo paginate_links( [
          /** @phpstan-ignore-next-line */
          'base'      => add_query_arg( 'paged', '%#%', esc_url( $base_url . ( $search ? '&s=' . rawurlencode( $search ) : '' ) ) ),
          'format'    => '',
          'current'   => $page,
          'total'     => $total_pages,
          'prev_text' => '&laquo;',
          'next_text' => '&raquo;',
      ] );
      // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
      ?>
    </div>
  <?php endif; ?>
</div>
