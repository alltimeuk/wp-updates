<?php if ( ! defined( 'ABSPATH' ) ) exit;
/** @var array $r - output of WPQ_Admin::get_operational_readiness() */
$r = $r ?? [];

// ── inline helpers ──────────────────────────────────────────────────────────

$ok  = static function ( string $label, string $detail = '' ): void {
	echo '<tr><td><span class="dashicons dashicons-yes-alt" style="color:#46b450"></span> ' . esc_html( $label ) . '</td>';
	echo '<td>' . esc_html( $detail ) . '</td></tr>';
};
$warn = static function ( string $label, string $detail = '' ): void {
	echo '<tr><td><span class="dashicons dashicons-warning" style="color:#dba617"></span> ' . esc_html( $label ) . '</td>';
	echo '<td>' . esc_html( $detail ) . '</td></tr>';
};
$err = static function ( string $label, string $detail = '' ): void {
	echo '<tr><td><span class="dashicons dashicons-dismiss" style="color:#dc3232"></span> ' . esc_html( $label ) . '</td>';
	echo '<td>' . esc_html( $detail ) . '</td></tr>';
};
$check = static function ( bool $pass, string $label, string $detail = '' ) use ( $ok, $err ): void {
	$pass ? $ok( $label, $detail ) : $err( $label, $detail );
};

// Key source badge (constants > env > options)
$source_label = static function ( string $source ): string {
	return match ( $source ) {
		'constant' => 'PHP constant',
		'env', 'environment' => 'Environment variable',
		'option'   => 'WP option (database)',
		default    => 'Not set',
	};
};

$status = $r['overall_status'] ?? 'ok';
$errors   = $r['overall_errors']   ?? [];
$warnings = $r['overall_warnings'] ?? [];
?>
<p style="color:#666">
	WP Questionnaires v<?php echo esc_html( $r['plugin_version'] ?? '' ); ?>
	&nbsp;&mdash;&nbsp;
	<a href="<?php echo esc_url( add_query_arg( [ 'page' => 'wpq-settings', 'tab' => 'readiness' ], admin_url( 'admin.php' ) ) ); ?>">Refresh</a>
</p>

<?php
// ── Overall status banner ───────────────────────────────────────────────────
if ( $status === 'error' ) : ?>
<div class="notice notice-error inline" style="margin:0 0 16px">
	<p><strong>Action required</strong></p>
	<ul style="list-style:disc;margin-left:20px">
		<?php foreach ( $errors as $msg ) : ?><li><?php echo esc_html( $msg ); ?></li><?php endforeach; ?>
	</ul>
</div>
<?php elseif ( $status === 'warning' ) : ?>
<div class="notice notice-warning inline" style="margin:0 0 16px">
	<p><strong>Review recommended</strong></p>
	<ul style="list-style:disc;margin-left:20px">
		<?php foreach ( $warnings as $msg ) : ?><li><?php echo esc_html( $msg ); ?></li><?php endforeach; ?>
	</ul>
</div>
<?php else : ?>
<div class="notice notice-success inline" style="margin:0 0 16px">
	<p><strong>All checks passed</strong></p>
</div>
<?php endif; ?>

<?php /* ── shared card styles ── */ ?>
<style>
.wpq-health-card { max-width:900px; margin-bottom:24px; }
.wpq-health-card h2 { font-size:14px; font-weight:600; margin:0 0 8px; }
.wpq-health-card table.widefat td { vertical-align:middle; padding:6px 10px; }
.wpq-health-card table.widefat td:first-child { width:60%; white-space:nowrap; }
.wpq-count-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; max-width:900px; margin-bottom:24px; }
.wpq-count-card { background:#fff; border:1px solid #c3c4c7; border-radius:2px; padding:16px 20px; }
.wpq-count-card h3 { font-size:13px; margin:0 0 12px; }
.wpq-count-card table { border-collapse:collapse; width:100%; }
.wpq-count-card td { padding:3px 0; font-size:13px; }
.wpq-count-card td:last-child { text-align:right; font-weight:600; }
</style>

<?php
// ── 1. Plugin & Database ────────────────────────────────────────────────────
$db_match    = (bool) ( $r['db_version_match'] ?? false );
$installed   = $r['db_version_installed'] ?? '0';
$code_ver    = $r['db_version_code'] ?? WPQ_DB_VERSION;
?>
<div class="card wpq-health-card">
<h2>Plugin &amp; Database</h2>
<table class="widefat striped"><tbody>
<?php
$check( true, 'Plugin version', $r['plugin_version'] ?? '' );
$check( $db_match, 'DB schema version', $installed . ' installed / ' . $code_ver . ' required' );
$check( (bool) ( $r['checkout_enabled'] ?? false ), 'Checkout enabled', ( $r['checkout_enabled'] ?? false ) ? 'Yes (' . ( $r['checkout_flag_source'] ?? 'unknown' ) . ')' : 'No - Feature Gated' );
$check( (bool) ( $r['remediation_plan_global_enabled'] ?? false ), 'Remediation Plan downloads', ( $r['remediation_plan_global_enabled'] ?? false ) ? 'Enabled (' . ( $r['remediation_plan_global_source'] ?? 'unknown' ) . ')' : 'Disabled' );
$check( (bool) ( $r['stripe_library'] ?? false ), 'Stripe PHP library', ( $r['stripe_library'] ?? false ) ? 'Present' : 'Missing (composer require stripe/stripe-php)' );
$check( (bool) ( $r['dompdf_library'] ?? false ), 'Dompdf PDF library', ( $r['dompdf_library'] ?? false ) ? 'Present' : 'Missing (composer require dompdf/dompdf)' );
?>
</tbody></table>
</div>

<?php
// ── 2. Schema Health ────────────────────────────────────────────────────────
$schema      = $r['schema'] ?? [];
$table_health = $schema['table_health'] ?? [];
$strict       = $schema['strict_schema_health'] ?? [];
?>
<div class="card wpq-health-card">
<h2>Schema Health</h2>
<table class="widefat striped"><tbody>
<?php
if ( $table_health ) :
	foreach ( $table_health as $table_name => $info ) :
		$exists  = (bool) $info['exists'];
		$missing = $info['missing_columns'] ?? [];
		if ( ! $exists ) :
			$err( $table_name, 'Table missing' );
		elseif ( $missing ) :
			$warn( $table_name, 'Missing columns: ' . implode( ', ', $missing ) );
		else :
			$ok( $table_name, 'OK' );
		endif;
	endforeach;
else :
	$warn( 'Table health', 'Diagnostic data unavailable' );
endif;

if ( $strict ) :
	foreach ( $strict as $table_name => $checks ) :
		foreach ( $checks as $check_name => $result ) :
			$pass = (bool) ( $result['ok'] ?? false );
			$msg  = (string) ( $result['message'] ?? '' );
			$pass ? $ok( $table_name . ': ' . $check_name, $msg ) : $warn( $table_name . ': ' . $check_name, $msg );
		endforeach;
	endforeach;
endif;
?>
</tbody></table>
</div>

<?php
// ── 3. Rate Limiting ────────────────────────────────────────────────────────
$rate_limit_storage = $r['rate_limit_storage'] ?? [ 'table' => '', 'available' => false, 'error' => '' ];
?>
<div class="card wpq-health-card">
<h2>Rate Limiting</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) ( $rate_limit_storage['available'] ?? false ), 'Atomic rate-limit storage', ( $rate_limit_storage['available'] ?? false ) ? 'Available' : 'Unavailable - transient fallback active' );
if ( ! empty( $rate_limit_storage['table'] ) ) :
	$ok( 'Rate-limit table', (string) $rate_limit_storage['table'] );
endif;
?>
</tbody></table>
</div>

<?php
// ── 4. Stripe Configuration ─────────────────────────────────────────────────
$pub_key = $r['pub_key'] ?? [ 'present' => false, 'valid' => false, 'source' => 'none' ];
$sec_key = $r['sec_key'] ?? [ 'present' => false, 'valid' => false, 'source' => 'none' ];
$whsec   = $r['whsec']   ?? [ 'present' => false, 'valid' => false, 'source' => 'none' ];
?>
<div class="card wpq-health-card">
<h2>Stripe Configuration</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) $pub_key['valid'], 'Publishable key', $pub_key['valid'] ? 'Valid - ' . $source_label( $pub_key['source'] ) : ( $pub_key['present'] ? 'Present but invalid format' : 'Not set' ) );
$check( (bool) $sec_key['valid'], 'Secret key', $sec_key['valid'] ? 'Valid - ' . $source_label( $sec_key['source'] ) : ( $sec_key['present'] ? 'Present but invalid format' : 'Not set' ) );
$check( (bool) $whsec['valid'], 'Webhook signing secret', $whsec['valid'] ? 'Valid - ' . $source_label( $whsec['source'] ) : ( $whsec['present'] ? 'Present but invalid format' : 'Not set' ) );
$check( (bool) ( $r['stripe_initialised'] ?? false ), 'Stripe API initialised', ( $r['stripe_initialised'] ?? false ) ? 'Yes' : 'No - keys or library unavailable' );
?>
</tbody></table>
</div>

<?php
// ── 5. Report Storage ───────────────────────────────────────────────────────
$claude_key          = $r['claude_key'] ?? [ 'present' => false, 'valid' => false, 'source' => 'none' ];
$claude_model        = $r['claude_model'] ?? [ 'preference' => 'auto', 'selected_model' => '', 'available_count' => 0 ];
$claude_capabilities = $r['claude_capabilities'] ?? [];
?>
<div class="card wpq-health-card">
<h2>Claude Configuration</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) ( $claude_key['valid'] ?? false ), 'Claude API key', ( $claude_key['valid'] ?? false ) ? 'Valid - ' . $source_label( (string) ( $claude_key['source'] ?? 'none' ) ) : ( ( $claude_key['present'] ?? false ) ? 'Present but invalid format' : 'Not set' ) );
$ok( 'Model preference', (string) ( $claude_model['preference'] ?? 'auto' ) );
$ok( 'Selected model', (string) ( $claude_model['selected_model'] ?? '' ) );
$ok( 'Max output tokens', class_exists( 'WPQ_Remediation_Plan' ) ? number_format( WPQ_Remediation_Plan::get_max_tokens_preference() ) . ' (change in Settings -> AI)' : '-' );
$check( (bool) ( $r['claude_client_initialised'] ?? false ), 'Claude API adapter', ( $r['claude_client_initialised'] ?? false ) ? 'Ready' : 'Not initialised' );
$check( ! empty( $claude_capabilities['messages'] ), 'Messages API', ! empty( $claude_capabilities['messages'] ) ? 'Supported' : 'Unavailable' );
$check( ! empty( $claude_capabilities['models'] ), 'Models API', ! empty( $claude_capabilities['models'] ) ? 'Supported' : 'Unavailable' );
$check( ! empty( $claude_capabilities['files_beta'] ), 'Files API', ! empty( $claude_capabilities['files_beta'] ) ? 'Supported beta API' : 'Unavailable' );
$warn( 'Claude.ai Project/chat lifecycle', 'Not supported by the public API; WordPress stores internal session IDs and optional externally supplied project links.' );
?>
</tbody></table>
</div>

<?php
$storage = $r['storage'] ?? [];
$storage_path = (string) ( $storage['path'] ?? '' );
?>
<div class="card wpq-health-card">
<h2>Report Storage</h2>
<table class="widefat striped"><tbody>
<?php
if ( $storage_path !== '' ) :
	$ok( 'Storage path', $storage_path );
else :
	$warn( 'Storage path', 'Not configured' );
endif;
$check( (bool) ( $storage['available'] ?? false ), 'Directory exists', ( $storage['available'] ?? false ) ? 'Yes' : 'No' );
$check( (bool) ( $storage['writable'] ?? false ), 'Directory writable', ( $storage['writable'] ?? false ) ? 'Yes' : 'No' );
$check( (bool) ( $storage['index_guard_present'] ?? false ), 'index.php guard', ( $storage['index_guard_present'] ?? false ) ? 'Present' : 'Missing' );
$check( (bool) ( $storage['htaccess_guard_present'] ?? false ), '.htaccess deny guard', ( $storage['htaccess_guard_present'] ?? false ) ? 'Present' : 'Missing' );
$check( method_exists( 'WPQ_Database', 'consume_report_token' ), 'Signed one-time tokens', method_exists( 'WPQ_Database', 'consume_report_token' ) ? 'Supported' : 'Method missing' );
?>
</tbody></table>
</div>

<?php
// ── 5b. Questionnaire Report (DOCX -> PDF) ─────────────────────────────────
$qr = $r['questionnaire_report'] ?? [];
$qr_converter = $qr['converter'] ?? [];
$qr_storage   = $qr['storage'] ?? [ 'docx' => [], 'pdf' => [] ];
?>
<div class="card wpq-health-card">
<h2>Report (DOCX &rarr; PDF)</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) ( $r['questionnaire_report_global_enabled'] ?? false ), 'Report generation', ( $r['questionnaire_report_global_enabled'] ?? false ) ? 'Enabled (' . ( $r['questionnaire_report_global_source'] ?? 'unknown' ) . ')' : 'Disabled' );
$check( (bool) ( $qr['claude_configured'] ?? false ), 'Claude configured', ( $qr['claude_configured'] ?? false ) ? 'Yes - shares the Claude API key above' : 'No' );
$check( (bool) ( $qr['phpword_available'] ?? false ), 'DOCX templating library (PHPWord)', ( $qr['phpword_available'] ?? false ) ? 'Present' : 'Missing (composer require phpoffice/phpword)' );
$check( (bool) ( $r['gd_extension'] ?? false ), 'PHP gd extension', ( $r['gd_extension'] ?? false ) ? 'Loaded' : 'Missing - required by PHPWord' );
$check( (bool) ( $r['zip_extension'] ?? false ), 'PHP zip extension', ( $r['zip_extension'] ?? false ) ? 'Loaded' : 'Missing - required by PHPWord' );
$ok( 'Renderer mode (global default)', (string) ( $qr['renderer_mode'] ?? 'docx_template' ) );
$check( (bool) ( $qr_converter['proc_open_available'] ?? false ), 'PHP proc_open (required to run any local converter)', ( $qr_converter['proc_open_available'] ?? false ) ? 'Available' : 'Disabled by this host (disable_functions) - a local LibreOffice/soffice binary cannot run here no matter how it is installed' );
$check( (bool) ( $qr_converter['available'] ?? false ), 'PDF converter (LibreOffice/soffice)', ( $qr_converter['available'] ?? false ) ? 'Detected: ' . ( $qr_converter['detected_executable'] ?? '' ) : 'Not detected - configure the executable path in Settings -> AI' );
$check( (bool) ( $qr_converter['temp_writable'] ?? false ), 'Conversion temp directory writable', ( $qr_converter['temp_writable'] ?? false ) ? 'Yes' : 'No' );
$ok( 'Conversion timeout', (string) ( $qr_converter['timeout_seconds'] ?? 60 ) . 's' );
$check( (bool) ( $qr_storage['docx']['available'] ?? false ) && (bool) ( $qr_storage['docx']['writable'] ?? false ), 'DOCX storage', ( $qr_storage['docx']['path'] ?? '' ) . ' - ' . ( ( $qr_storage['docx']['writable'] ?? false ) ? 'writable' : 'not writable' ) );
$check( (bool) ( $qr_storage['pdf']['available'] ?? false ) && (bool) ( $qr_storage['pdf']['writable'] ?? false ), 'PDF storage', ( $qr_storage['pdf']['path'] ?? '' ) . ' - ' . ( ( $qr_storage['pdf']['writable'] ?? false ) ? 'writable' : 'not writable' ) );
$warn( 'HTML/Dompdf fallback', ( $qr['html_fallback_allowed'] ?? false ) ? 'Explicitly enabled - will be used when the DOCX template is missing or invalid' : 'Disabled - the DOCX pipeline must be ready for generation to succeed' );
?>
</tbody></table>
</div>

<?php
// ── 5b2. Framework Readiness ────────────────────────────────────────────────
$fr = $r['framework_readiness'] ?? [];
?>
<div class="card wpq-health-card">
<h2>Framework Readiness</h2>
<table class="widefat striped"><tbody>
<?php
$ok( 'Assessed automatically', 'On submission completion, independent of Questionnaire Report generation (a submission-time background job)' );
$ok( 'Frameworks per submission (max)', (string) ( $fr['max_frameworks'] ?? 8 ) );
$check( (bool) ( $fr['curl_multi_available'] ?? false ), 'Concurrent requests (curl_multi)', ( $fr['curl_multi_available'] ?? false ) ? 'Available - all selected frameworks are assessed in parallel' : 'Disabled by this host (disable_functions) - falls back to assessing frameworks one at a time' );
?>
</tbody></table>
</div>

<?php
// ── 5c. Cron & Task Processing ─────────────────────────────────────────────
$cron = $r['cron'] ?? [ 'wp_cron_disabled' => false, 'mode' => 'wp_cron', 'scheduled_event_count' => 0, 'next_event_at' => null ];
?>
<div class="card wpq-health-card">
<h2>Cron &amp; Task Processing</h2>
<table class="widefat striped"><tbody>
<?php
if ( $cron['wp_cron_disabled'] ) :
	$ok( 'Processing mode', 'DISABLE_WP_CRON is set - core never auto-spawns wp-cron.php. The plugin compensates: queued report jobs fire an immediate loopback kick, and admin page views sweep for overdue scheduled events once a minute.' );
else :
	$ok( 'Processing mode', 'WordPress pseudo-cron - events run on the next page load after their scheduled time.' );
endif;
$ok( 'Scheduled report-generation events', (string) $cron['scheduled_event_count'] );
if ( $cron['next_event_at'] ) :
	$ok( 'Next scheduled run', wp_date( 'd M Y H:i:s', (int) $cron['next_event_at'] ) );
elseif ( (int) $cron['scheduled_event_count'] > 0 ) :
	$warn( 'Next scheduled run', 'Unable to determine - check the events below.' );
else :
	$ok( 'Next scheduled run', 'None scheduled' );
endif;
$wpq_loopback = $cron['loopback'] ?? [ 'checked' => false, 'reachable' => false, 'detail' => '' ];
if ( ! empty( $wpq_loopback['checked'] ) ) :
	$check(
		(bool) $wpq_loopback['reachable'],
		'wp-cron.php reachability',
		$wpq_loopback['reachable']
			? 'Reachable (' . (string) $wpq_loopback['detail'] . ') - probed over HTTP, cached for 10 minutes.'
			: 'UNREACHABLE (' . (string) $wpq_loopback['detail'] . ') - queued jobs will never run. Common causes: basic-auth on staging, firewall blocking loopback requests, or broken TLS on the local interface.'
	);
else :
	$warn( 'wp-cron.php reachability', 'Probe unavailable.' );
endif;
if ( $cron['wp_cron_disabled'] ) :
	$ok( 'Scheduler', 'The plugin\'s loopback kicker covers report jobs and (via the admin sweep) recurring events, so no system crontab is required. Belt-and-braces on hosts without one: point a free external pinger (e.g. cron-job.org or UptimeRobot) at wp-cron.php every 5 minutes so recurring jobs also run when no admin is logged in.' );
endif;
?>
</tbody></table>
</div>

<?php
// ── 5d. Cron Task Backlog ───────────────────────────────────────────────────
$cron_backlog = $r['cron_backlog'] ?? [];
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Feedback query arg is display-only.
$wpq_cron_notice = isset( $_GET['wpq_cron'] ) ? sanitize_key( (string) $_GET['wpq_cron'] ) : '';
?>
<div class="card wpq-health-card" style="max-width:1100px;">
<h2>Cron Task Backlog</h2>
<?php if ( 'retried' === $wpq_cron_notice ) : ?>
	<div class="notice notice-success inline"><p>Retry attempted - the job was run inline within this request. Check its status below.</p></div>
<?php elseif ( 'cancelled' === $wpq_cron_notice ) : ?>
	<div class="notice notice-success inline"><p>Generation cancelled. Use "Generate Report" on the submission to start a fresh run.</p></div>
<?php elseif ( 'error' === $wpq_cron_notice ) : ?>
	<div class="notice notice-error inline"><p>That action could not be completed - the job may have already moved on. Refresh and try again.</p></div>
<?php endif; ?>
<?php if ( empty( $cron_backlog ) ) : ?>
	<p class="description" style="padding:0 10px 10px;">No Questionnaire Report generation jobs are currently in flight.</p>
<?php else : ?>
<table class="widefat striped"><thead><tr>
	<th>Submission</th>
	<th>Customer</th>
	<th>Questionnaire</th>
	<th>Status</th>
	<th>Requested</th>
	<th>Last attempt</th>
	<th>Attempts</th>
	<th>Payload</th>
	<th>Actions</th>
</tr></thead><tbody>
<?php foreach ( $cron_backlog as $task ) :
	$requested_at    = (string) ( $task->qr_requested_at ?? '' );
	$last_attempt_at = (string) ( $task->qr_last_attempt_at ?? '' );
	$requested_ts    = $requested_at ? strtotime( $requested_at . ' UTC' ) : false;
	$elapsed         = $requested_ts ? human_time_diff( $requested_ts, time() ) : '';
	$never_attempted = '' === $last_attempt_at;
	$submission_url  = add_query_arg( [ 'page' => 'wpq-submissions', 'wpq_action' => 'view', 'id' => (int) $task->id ], admin_url( 'admin.php' ) );
?>
	<tr>
		<td><a href="<?php echo esc_url( $submission_url ); ?>"><?php echo esc_html( (string) ( $task->ref ?? ( '#' . $task->id ) ) ); ?></a></td>
		<td><?php echo esc_html( (string) ( $task->contact_name ?? '' ) ); ?><?php if ( ! empty( $task->contact_company ) ) : ?><br><span class="description"><?php echo esc_html( (string) $task->contact_company ); ?></span><?php endif; ?></td>
		<td><?php echo esc_html( (string) ( $task->questionnaire_name ?? '-' ) ); ?></td>
		<td>
			<?php echo esc_html( (string) ( $task->qr_status ?? '' ) ); ?>
			<?php if ( $never_attempted ) : ?><br><span class="description" style="color:#dba617;">never attempted<?php echo $elapsed ? ' - queued ' . esc_html( $elapsed ) . ' ago' : ''; ?></span><?php endif; ?>
		</td>
		<td><?php echo $requested_at ? esc_html( wp_date( 'd M Y H:i', $requested_ts ?: null ) ) : '-'; ?></td>
		<td><?php echo $last_attempt_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $last_attempt_at . ' UTC' ) ?: null ) ) : '-'; ?></td>
		<td><?php echo esc_html( (string) ( $task->qr_attempt_count ?? 0 ) ); ?></td>
		<td>
			<?php if ( ! empty( $task->qr_analysis_json ) ) : ?>
			<details><summary style="cursor:pointer;">View</summary>
				<pre style="max-width:320px;max-height:200px;overflow:auto;white-space:pre-wrap;font-size:11px;background:#f6f7f7;padding:6px;"><?php echo esc_html( wp_json_encode( json_decode( (string) $task->qr_analysis_json, true ), JSON_PRETTY_PRINT ) ?: (string) $task->qr_analysis_json ); ?></pre>
			</details>
			<?php else : ?>
			<span class="description">-</span>
			<?php endif; ?>
		</td>
		<td>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
				<?php wp_nonce_field( 'wpq_cron_task_action' ); ?>
				<input type="hidden" name="action" value="wpq_retry_cron_task">
				<input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) $task->id ); ?>">
				<button type="submit" class="button button-small">Retry</button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;"
				onsubmit="return confirm('Cancel this in-progress report generation? It can be started again from the submission afterwards.');">
				<?php wp_nonce_field( 'wpq_cron_task_action' ); ?>
				<input type="hidden" name="action" value="wpq_cancel_cron_task">
				<input type="hidden" name="submission_id" value="<?php echo esc_attr( (string) $task->id ); ?>">
				<button type="submit" class="button button-small">Cancel</button>
			</form>
		</td>
	</tr>
<?php endforeach; ?>
</tbody></table>
<?php endif; ?>
</div>

<?php
// ── 6. REST Routes ──────────────────────────────────────────────────────────
$core_routes = $r['core_routes'] ?? [];
$api_routes  = $r['api_routes']  ?? [];
$capabilities = $r['capabilities'] ?? [];
?>
<div class="card wpq-health-card">
<h2>REST Routes</h2>
<table class="widefat striped"><tbody>
<?php
$feature_gated_routes = [ 'POST /checkout', 'POST /stripe/webhook', 'GET /reports/{id}' ];
foreach ( $core_routes as $route => $present ) :
	$is_feature_gated = in_array( $route, $feature_gated_routes, true );
	if ( $present ) :
		$ok( $route, 'Implemented' );
	elseif ( $is_feature_gated ) :
		$warn( $route, 'Feature Gated' );
	else :
		$err( $route, 'Missing' );
	endif;
endforeach;

foreach ( $api_routes as $route => $present ) :
	$check( $present, $route . ' (HaloPSA pull API)', $present ? 'Implemented' : 'Missing' );
endforeach;
?>
</tbody></table>
</div>

<?php
// ── 6. HaloPSA API Role ─────────────────────────────────────────────────────
$halopsa_role_ok = (bool) ( $r['halopsa_role_ok'] ?? false );
$halopsa_cap_ok  = (bool) ( $r['halopsa_cap_ok']  ?? false );
$halopsa_users   = (int) ( $r['halopsa_users'] ?? 0 );
?>
<div class="card wpq-health-card">
<h2>HaloPSA API Role</h2>
<table class="widefat striped"><tbody>
<?php
$check( $halopsa_role_ok, 'wpq_halopsa role registered', $halopsa_role_ok ? 'Present' : 'Not registered - run activation' );
$check( $halopsa_cap_ok,  'wpq_halopsa_api capability on role', $halopsa_cap_ok ? 'Granted' : 'Missing - role has no API capability' );
if ( $halopsa_users > 0 ) :
	$ok( 'Users with wpq_halopsa role', (string) $halopsa_users );
else :
	$warn( 'Users with wpq_halopsa role', 'None - create a user and assign the wpq_halopsa role for pull-API access' );
endif;
?>
</tbody></table>
</div>

<?php
// ── 7. Submission Counts ────────────────────────────────────────────────────
$sync_counts = $r['sync_counts'] ?? [ 'sync' => [], 'payment' => [], 'total' => 0 ];
$sync    = $sync_counts['sync']    ?? [];
$payment = $sync_counts['payment'] ?? [];
?>
<div class="wpq-count-grid">
	<div class="wpq-count-card">
		<h3>HaloPSA Sync Status</h3>
		<table><tbody>
			<tr><td>Pending</td><td><?php echo esc_html( (string) ( $sync['pending'] ?? 0 ) ); ?></td></tr>
			<tr><td>Processing</td><td><?php echo esc_html( (string) ( $sync['processing'] ?? 0 ) ); ?></td></tr>
			<tr><td>Synced</td><td><?php echo esc_html( (string) ( $sync['synced'] ?? 0 ) ); ?></td></tr>
			<tr style="color:<?php echo ( $sync['failed'] ?? 0 ) > 0 ? '#dc3232' : 'inherit'; ?>">
				<td>Failed</td><td><?php echo esc_html( (string) ( $sync['failed'] ?? 0 ) ); ?></td>
			</tr>
			<tr style="color:<?php echo ( $sync['retry_pending'] ?? 0 ) > 0 ? '#d63638' : 'inherit'; ?>">
				<td>Retry pending</td><td><?php echo esc_html( (string) ( $sync['retry_pending'] ?? 0 ) ); ?></td>
			</tr>
			<tr><td>Ignored</td><td><?php echo esc_html( (string) ( $sync['ignored'] ?? 0 ) ); ?></td></tr>
			<tr style="color:<?php echo ( $sync['manual_review'] ?? 0 ) > 0 ? '#dba617' : 'inherit'; ?>">
				<td>Manual review</td><td><?php echo esc_html( (string) ( $sync['manual_review'] ?? 0 ) ); ?></td>
			</tr>
			<tr><td>Skipped</td><td><?php echo esc_html( (string) ( $sync['skipped'] ?? 0 ) ); ?></td></tr>
			<tr style="border-top:1px solid #ddd;font-weight:bold"><td>Total</td><td><?php echo esc_html( (string) ( $sync_counts['total'] ?? 0 ) ); ?></td></tr>
		</tbody></table>
	</div>
	<div class="wpq-count-card">
		<h3>Payment Status</h3>
		<table><tbody>
			<tr><td>None / free</td><td><?php echo esc_html( (string) ( $payment['none'] ?? 0 ) ); ?></td></tr>
			<tr><td>Pending</td><td><?php echo esc_html( (string) ( $payment['pending'] ?? 0 ) ); ?></td></tr>
			<tr><td>Paid</td><td><?php echo esc_html( (string) ( $payment['paid'] ?? 0 ) ); ?></td></tr>
			<tr style="color:<?php echo ( $payment['failed'] ?? 0 ) > 0 ? '#dc3232' : 'inherit'; ?>">
				<td>Failed</td><td><?php echo esc_html( (string) ( $payment['failed'] ?? 0 ) ); ?></td>
			</tr>
			<tr><td>Expired</td><td><?php echo esc_html( (string) ( $payment['expired'] ?? 0 ) ); ?></td></tr>
		</tbody></table>
	</div>
</div>

<?php
// ── 8. Payment Readiness ─────────────────────────────────────────────────────
$cr = $checkout_readiness ?? [];
$stripe_key_status = static function ( bool $present, bool $valid ): string {
	if ( ! $present ) { return 'Not set'; }
	return $valid ? 'Valid' : 'Invalid format';
};
$route_status = static fn( bool $implemented ): string => $implemented ? 'Implemented' : 'Feature Gated';
?>
<div class="card wpq-health-card">
<h2>Payment Readiness</h2>
<table class="widefat striped"><tbody>
<?php
$check( (bool) ( $cr['production_ready'] ?? false ),      'Overall payment readiness',   ( $cr['production_ready'] ?? false ) ? 'Production ready' : ( $cr['readiness_status'] ?? 'Not ready' ) );
$check( (bool) ( $cr['checkout_enabled'] ?? false ),      'Checkout feature flag',        ( $cr['checkout_enabled'] ?? false ) ? 'Enabled (' . ( $cr['checkout_flag_source'] ?? 'unknown' ) . ')' : 'Disabled (phase-gated)' );
$check( (int) ( $cr['priced_product_count'] ?? 0 ) > 0,  'Pricing options configured',   (int) ( $cr['priced_product_count'] ?? 0 ) . ' active option(s) with a Stripe Price ID' );
$check( (bool) ( $cr['stripe_api_initialised'] ?? false ),'Stripe API initialised',       ( $cr['stripe_api_initialised'] ?? false ) ? 'Yes' : 'No - keys or library unavailable' );
$check( (bool) ( $cr['stripe_library_available'] ?? false ), 'Stripe PHP library',        ( $cr['stripe_library_available'] ?? false ) ? 'Present' : 'Missing (composer require stripe/stripe-php)' );
$check( (bool) ( $cr['dompdf_library_available'] ?? false ), 'Dompdf PDF library',        ( $cr['dompdf_library_available'] ?? false ) ? 'Present' : 'Missing (composer require dompdf/dompdf)' );
$check( (bool) ( $cr['checkout_route_registered'] ?? false ), 'Checkout route',           $route_status( $cr['checkout_route_registered'] ?? false ) );
$check( (bool) ( $cr['webhook_route_registered'] ?? false ),  'Stripe webhook route',     $route_status( $cr['webhook_route_registered'] ?? false ) );
$check( (bool) ( $cr['report_delivery_route_registered'] ?? false ), 'Report delivery route', $route_status( $cr['report_delivery_route_registered'] ?? false ) );
$check( (bool) ( $cr['report_template_available'] ?? false ) && (bool) ( $cr['report_renderer_available'] ?? false ), 'Report generation', ( $cr['report_template_available'] ?? false ) && ( $cr['report_renderer_available'] ?? false ) ? 'Ready' : 'Feature Gated' );
$check( (bool) ( $cr['atomic_report_token_support'] ?? false ), 'Report token delivery',  ( $cr['atomic_report_token_support'] ?? false ) ? 'Supported' : 'Method missing' );
?>
</tbody></table>
</div>

<?php
// ── 9. Migration Log ─────────────────────────────────────────────────────────
$last_run   = (string) ( $schema['last_migration_run'] ?? '' );
$last_error = (string) ( $schema['last_migration_error'] ?? '' );
$error_list = $schema['last_migration_errors'] ?? [];
if ( ! is_array( $error_list ) ) { $error_list = []; }
?>
<div class="card wpq-health-card">
<h2>Migration Log</h2>
<table class="widefat striped"><tbody>
<?php
if ( $last_run !== '' ) :
	$ok( 'Last migration run', $last_run );
else :
	$warn( 'Last migration run', 'Never recorded' );
endif;

if ( $last_error !== '' ) :
	$err( 'Last migration error', $last_error );
else :
	$ok( 'Last migration error', 'None' );
endif;
?>
</tbody></table>
<?php if ( $error_list ) : ?>
<details style="margin:8px 0 0"><summary style="cursor:pointer;font-size:13px">Recent migration errors (<?php echo count( $error_list ); ?>)</summary>
<ul style="margin:8px 0 0 20px;font-size:12px;font-family:monospace;color:#555">
	<?php foreach ( array_slice( $error_list, -20 ) as $entry ) : ?>
	<li><?php echo esc_html( is_array( $entry ) ? wp_json_encode( $entry ) : (string) $entry ); ?></li>
	<?php endforeach; ?>
</ul>
</details>
<?php endif; ?>
</div>

<?php if ( class_exists( 'WPQ_Contact_Repository' ) && class_exists( 'WPQ_Contact_Migration' ) ) :
	$wpq_contact_diag  = WPQ_Contact_Repository::diagnostics();
	$wpq_contact_state = WPQ_Contact_Migration::get_state();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Feedback query arg is display-only.
	$wpq_contact_notice = isset( $_GET['wpq_contact_migration'] ) ? sanitize_key( (string) $_GET['wpq_contact_migration'] ) : '';
?>
<div class="wpq-health-card">
<h2>Canonical Contact Master</h2>
<?php if ( 'batch_done' === $wpq_contact_notice ) : ?>
	<div class="notice notice-success inline"><p>Migration batch processed. Remaining batches continue automatically via cron.</p></div>
<?php elseif ( 'reset_done' === $wpq_contact_notice ) : ?>
	<div class="notice notice-success inline"><p>Migration checkpoints reset. Already-linked records are untouched and will be skipped on re-run.</p></div>
<?php endif; ?>
<table class="widefat striped"><tbody>
<?php
$ok( 'Canonical contacts', (string) $wpq_contact_diag['contacts'] );
if ( $wpq_contact_diag['unlinked_submissions'] > 0 ) :
	$warn( 'Unlinked submissions', (string) $wpq_contact_diag['unlinked_submissions'] . ' - run the migration below' );
else :
	$ok( 'Unlinked submissions', '0' );
endif;
if ( $wpq_contact_diag['unlinked_enquiries'] > 0 ) :
	$warn( 'Unlinked enquiries', (string) $wpq_contact_diag['unlinked_enquiries'] . ' - run the migration below' );
else :
	$ok( 'Unlinked enquiries', '0' );
endif;
if ( $wpq_contact_diag['pending_reviews'] > 0 ) :
	$warn( 'Ambiguous match candidates', (string) $wpq_contact_diag['pending_reviews'] . ' awaiting review' );
else :
	$ok( 'Ambiguous match candidates', '0' );
endif;
$ok( 'Historic migration', (string) $wpq_contact_state['status'] );
if ( 'not_started' !== $wpq_contact_state['status'] ) :
	$ok( 'Migration progress', sprintf(
		'%d submissions and %d enquiries examined; %d contacts created; %d records linked; %d reviews queued; %d preferences migrated (%d ambiguous); %d errors',
		(int) $wpq_contact_state['submissions_examined'],
		(int) $wpq_contact_state['enquiries_examined'],
		(int) $wpq_contact_state['contacts_created'],
		(int) $wpq_contact_state['records_linked'],
		(int) $wpq_contact_state['reviews_queued'],
		(int) $wpq_contact_state['preferences_migrated'],
		(int) $wpq_contact_state['preferences_ambiguous'],
		(int) $wpq_contact_state['errors']
	) );
endif;
if ( '' !== (string) $wpq_contact_state['last_error'] ) :
	$err( 'Last migration error', (string) $wpq_contact_state['last_error'] );
endif;
?>
</tbody></table>
<div style="margin-top:10px;">
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
		<?php wp_nonce_field( 'wpq_contact_migration' ); ?>
		<input type="hidden" name="action" value="wpq_contact_migration_batch">
		<button type="submit" class="button button-primary">
			<?php echo 'completed' === $wpq_contact_state['status'] ? 'Re-check for unlinked records' : 'Run migration batch'; ?>
		</button>
	</form>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"
		onsubmit="return confirm('Reset migration checkpoints? Linked records are untouched and will be skipped when the migration re-runs.');">
		<?php wp_nonce_field( 'wpq_contact_migration' ); ?>
		<input type="hidden" name="action" value="wpq_contact_migration_reset">
		<button type="submit" class="button">Reset checkpoints</button>
	</form>
	<p class="description" style="margin-top:6px;">Batches are bounded (100 records / 20s) and continue automatically via cron until every historic record is linked or queued for review.</p>
</div>
</div>
<?php endif; ?>
