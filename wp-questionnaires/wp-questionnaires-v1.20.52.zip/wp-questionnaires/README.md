# WP Questionnaires

A generic WordPress assessment and lead-generation platform with a canonical contact master. Publishes scored questionnaires with save & resume, captures leads and enquiries, generates AI-driven (Claude) questionnaire reports and remediation plans, delivers email via wp_mail/Gmail/SES/Microsoft 365, and sells branded PDF reports via Stripe - with HaloPSA sync throughout.

**CyberCheck (CS-01)** is the first seeded assessment product that ships with the plugin. The platform is designed to host multiple assessment products over time - WP Questionnaires is the platform; CyberCheck is a dataset that runs inside it.

---

## Requirements

| Dependency | Version |
|---|---|
| PHP | 8.1+ |
| WordPress | 6.4+ |
| Composer | Required for `vendor/` |
| LibreOffice (`soffice`/`libreoffice`) | Optional - required only to convert generated Questionnaire Report DOCX files to PDF |

---

## Installation

1. Clone or unzip the plugin into `wp-content/plugins/wp-questionnaires/`.
2. Run `composer install` to install PHP dependencies (dompdf, stripe-php, phpoffice/phpword, etc.). PHPWord additionally requires the `gd` and `zip` PHP extensions, both of which are near-universal on WordPress hosting.
3. Activate the plugin from **WP Admin → Plugins**.
4. Activation creates all database tables and seeds the CS-01 CyberCheck questionnaire.

---

## Shortcodes

Place a questionnaire on any WordPress page or post:

```
[wpq_questionnaire ref="CS01"]
[wpq_questionnaire ref="CS01" show_pricing="false"]
```

Legacy aliases `[wpq_assessment]`, `[wpq_assessments]`, and `[wpq_product]` remain supported for existing content.

| Attribute | Default | Description |
|---|---|---|
| `ref` | (required) | Questionnaire reference code, e.g. `CS01` |
| `show_pricing` | `true` | Whether to allow the paid product CTA after results. Products are still hidden unless checkout is explicitly enabled. |
| `layout` | `wide` | `wide` or `contained` layout for the questionnaire container. |

Helper shortcodes for editorial copy:

| Shortcode | Returns |
|---|---|
| `[wpq_title ref="CS01"]` | Questionnaire title |
| `[wpq_description ref="CS01"]` | Questionnaire description |
| `[wpq_questions ref="CS01"]` | Total question count |
| `[wpq_domains ref="CS01"]` | Total domain count |
| `[wpq_time ref="CS01"]` | Estimated completion time as a plain number |
| `[wpq_estimate ref="CS01"]` | Estimated completion time as a phrase, e.g. "7 minutes" |
| `[wpq_minutes ref="CS01"]` | Alias for `[wpq_time]` |
| `[wpq_submissions ref="CS01"]` | Non-deleted submission count |
| `[wpq_status ref="CS01"]` | Questionnaire status |

Enquiry forms composed in the **Enquiries** admin area render with:

```
[wpq_enquiry ref="EF-XXXXXX"]
```

---

## Admin screens

| Screen | Menu label | Purpose |
|---|---|---|
| Submissions | Questionnaires → Submissions | View and manage all assessment submissions. Filter by status, questionnaire, date, and payment state. |
| Contacts | Questionnaires → Contacts | Deduplicated contact records built from submission lead data. |
| Revenue | Questionnaires → Revenue | Pricing, coupons, and orders for paid PDF reports, as collapsible sections on one screen: products and pricing, Stripe discount codes, and paid-report orders with payment status and report download links. |
| Questionnaires | Questionnaires → Questionnaires | Manage the questionnaire library: publish, archive, duplicate, bulk-publish, and delete assessments. |
| Call to Action | Questionnaires → Call to Action | Rich-text category and domain CTAs injected into questionnaire results. |
| Enquiries | Questionnaires → Enquiries | Compose enquiry/contact forms with custom fields, and browse received enquiries. |
| Frameworks | Questionnaires → Frameworks | Import ATLAS `.skill` bundles to register/refresh compliance frameworks and their control catalogues, and register them with the Anthropic Skills API. |
| Settings | Questionnaires → Settings | Plugin configuration: Stripe credentials, HaloPSA API, Mail, AI, Turnstile, general options, and advanced/destructive settings - including a **Readiness** tab with site health checks for plugin configuration (Stripe keys, HaloPSA, checkout gate, required PHP extensions/libraries), WP-Cron vs system-cron processing mode, and a Cron Task Backlog listing in-flight Questionnaire Report generation jobs with retry/cancel actions. |
| Import / Export | Questionnaires → Import / Export | Bulk import or export questionnaire definitions as JSON. Supports single questionnaires and batch files. |

---

## Calls to action and remediation plans

The **Call to Action** admin screen stores small rich-text CTA bodies. Category-wide CTAs appear below the key findings section after a customer completes a questionnaire. Domain CTAs are selected from the unique domains used by questionnaires in the selected category and are inserted after the matching domain recommendations. Result pages show at most three domain CTAs plus one category CTA.

AI remediation plans are configured in **Settings → AI**. Delivery to the customer is channel-based, mirroring Questionnaire Report delivery: a global channel list (direct download on the results screen, and/or an emailed secure link that expires after 30 days or 10 downloads) with a per-questionnaire override (inherit / none / custom) in the questionnaire editor. Claude API keys are resolved in this order:

1. `WPQ_CLAUDE_API_KEY` constant.
2. `CLAUDE_API_KEY` or `ANTHROPIC_API_KEY` server environment variable.
3. WordPress option saved from Settings → AI.

When configured and enabled, completed questionnaire results show a **Download Remediation Plan** button for 30, 60, or 90 day plans. The download feature can be toggled globally in **Settings -> AI** and per questionnaire from the questionnaire editor. The plugin sends the customer, answer, scoring, and recommendation context to Claude, asks for structured remediation tasks, and then creates the returned workbook locally with `Planner` and `Tasklist` worksheets.

The Claude model setting defaults to `auto`. In this mode the plugin calls Anthropic's Models API and selects the newest available Haiku model as the balanced cost/quality choice for remediation planning - this workload is structured JSON generation with a bounded workbook output, which Haiku handles well. If Haiku is unavailable it falls back to Sonnet, and Opus is only selected if no cheaper/balanced model family is available. A specific model ID can still be entered manually when needed.

Temporary Claude API diagnostics can be enabled from **Settings -> AI**. When enabled, the plugin stores a capped admin-only debug log of Anthropic request/response metadata, including status codes, request IDs where available, token usage reported by Claude, response excerpts, and parsing/workbook errors. API keys and full prompts are not stored. Disable this once remediation plan generation is confirmed in production.

Claude Project IDs are configured per questionnaire from the questionnaire editor. The current direct Messages API workflow does not create visible Claude.ai Project chats or attach generated conversations to Claude.ai Projects; remediation plan history remains in WordPress submission/report records and the downloaded workbook.

Questionnaires can also store per-questionnaire Claude project metadata and a `.docx` report template attachment from the questionnaire editor. Publishing a questionnaire updates the intended project name and marks the integration as configured only when an administrator has supplied that questionnaire's Project ID; otherwise it shows `manual_configuration_required`. New submissions initialise a single WordPress-managed Claude session snapshot named from the company and contact, for example `Acme Ltd - Jane Smith`.

The architecture note at `.roadmap/claude-integration.md` documents the supported Anthropic API surface, the unsupported Claude.ai Project/chat lifecycle behaviours, the staged report-generation boundary, and privacy considerations.

---

## Questionnaire Reports (DOCX → PDF)

The **Questionnaire Report** is a separate AI-generated customer-facing analytical assessment report, distinct from the Remediation Plan above:

| | Remediation Plan | Questionnaire Report |
|---|---|---|
| Purpose | Operational task list | Analytical narrative assessment |
| Template | Questionnaire-specific `.xlsx` | Questionnaire-specific `.docx` |
| Output | `.xlsx` workbook | `.docx`, converted to `.pdf` |
| Claude prompt | `WPQ_Remediation_Plan` task-generation prompt | `questionnaire-report-v1` - cross-domain synthesis and narrative |

The two pipelines share the Anthropic API key/model configuration but are otherwise independent: separate classes, separate prompts, separate storage directories, separate submission-level state, and separate admin controls.

### How the report and the workbook stay in agreement

The report's copy points the customer at the remediation workbook, so the two documents must not describe different problems for the same assessment. They are linked rather than independently re-derived:

1. Report generation assigns every priority finding a stable id (`F1`, `F2`, …) - assigned locally, never taken from the model - and stores the validated analysis on the submission (`qr_analysis_json`).
2. When a workbook is generated afterwards, that stored finding list is passed to the task prompt as `report_findings` and named as the canonical set of problems: every finding must be addressed by at least one task, and no problem outside the list may be introduced.
3. Each returned task carries `related_finding_ids`, filtered against the known ids so a hallucinated reference is dropped rather than written into the workbook as a dead link. The built-in workbook surfaces these in a **Report Findings** column; an uploaded workbook template (whose `TASKS` table has a fixed column set) gets them appended to the task description as `Addresses report findings: …`.

If no report has been generated for a submission yet, the workbook plans from the answers and recommendations exactly as before, with no finding links. The stored analysis is deleted alongside the generated artefacts whenever a submission is soft-deleted or a contact anonymised.

### Template placeholder contract

Upload a questionnaire-specific `.docx` template from the questionnaire editor. Placeholders use `{{...}}` syntax (matching the remediation workbook's convention) and are populated with [phpoffice/phpword](https://github.com/PHPOffice/PHPWord)'s `TemplateProcessor`, which correctly handles placeholder text that Word has split across multiple XML runs - a naive find/replace against the raw document XML would miss those.

**Scalars:**

`{{questionnaire.name}}` `{{questionnaire.ref}}` `{{customer.name}}` `{{customer.company}}` `{{assessment.score}}` `{{assessment.grade}}` `{{assessment.verdict}}` `{{assessment.completed_at}}` `{{assessment.domains_count}}` `{{assessment.questions_count}}` `{{report.reference}}` `{{report.generated_at}}` `{{report.title}}` `{{report.executive_summary}}` `{{report.overall_assessment}}` `{{report.conclusion}}`

**Finding tallies** - `{{counts.critical}}` `{{counts.high}}` `{{counts.medium}}` `{{counts.low}}` `{{counts.total}}`. Every level always resolves to a number (`0` when there are no findings of that severity), so a severity summary row never renders an empty cell. These, together with `{{domain.percent}}` below, are what let a template present scores and severity counts as native Word tables rather than embedded chart images - keeping every figure searchable, selectable, and readable by assistive technology.

**Repeating sections** - wrap the repeating paragraph(s) with an opening `{{block_name}}` and closing `{{/block_name}}` marker; every placeholder between the markers repeats once per item, and the whole block is removed if the section has no items:

| Block | Row placeholders |
|---|---|
| `{{strengths}}` … `{{/strengths}}` | `{{strength.title}}` `{{strength.detail}}` `{{strength.evidence_refs}}` |
| `{{priority_findings}}` … `{{/priority_findings}}` | `{{finding.id}}` `{{finding.priority}}` `{{finding.domain}}` `{{finding.title}}` `{{finding.finding}}` `{{finding.business_impact}}` `{{finding.recommendation}}` `{{finding.evidence_refs}}` |
| `{{domain_assessments}}` … `{{/domain_assessments}}` | `{{domain.name}}` `{{domain.score}}` `{{domain.maximum_score}}` `{{domain.percent}}` `{{domain.summary}}` `{{domain.strengths}}` `{{domain.concerns}}` `{{domain.recommendations}}` |
| `{{recommended_next_steps}}` … `{{/recommended_next_steps}}` | `{{step.sequence}}` `{{step.timeframe}}` `{{step.action}}` `{{step.reason}}` `{{step.owner_type}}` |
| `{{limitations}}` … `{{/limitations}}` | `{{limitation.text}}` |
| `{{frameworks}}` … `{{/frameworks}}` | `{{framework.name}}` `{{framework.readiness}}` `{{framework.percent}}` `{{framework.summary}}` `{{framework.strengths}}` `{{framework.gaps}}` `{{framework.recommendations}}` |

`priority_findings` and `domain_assessments` blocks are required; the rest are optional. Only the placeholders a report is meaningless without are enforced - `customer.company`, `assessment.completed_at`, `report.generated_at`, `counts.*`, `report.reference`, `assessment.verdict`, `assessment.domains_count`, `assessment.questions_count`, `finding.id`, and `domain.percent` are all optional, so templates authored against an earlier contract keep validating and adopt the newer placeholders whenever their author adds them. The questionnaire editor validates and reports missing required placeholders/blocks before generation is allowed. All inserted content is XML-escaped, so customer names, free-text answers, and Claude-generated text containing `&`, `<`, or `>` cannot corrupt the document.

### Generation lifecycle

Generation runs as an idempotent WordPress single-event cron job (`wpq_process_questionnaire_report`) so an admin request never blocks on Anthropic or LibreOffice: **queued → analysing → rendering_docx → converting_pdf → completed**, or **partial** (DOCX succeeded, PDF conversion failed/unavailable - the DOCX remains downloadable and PDF conversion can be retried independently) or **failed**. A repeated "Generate" click while a run is active returns the existing state instead of starting a second job; use "Regenerate" once the run reaches a terminal state.

Configure the pipeline from **Settings → AI**:

- **Global Questionnaire Report generation** - enable/disable, with a per-questionnaire `inherit`/`enabled`/`disabled` override in the questionnaire editor. `WPQ_QUESTIONNAIRE_REPORT_ENABLED` (PHP constant) overrides both when defined.
- **Renderer mode** - `docx_template` (default) or `html_dompdf`, with a per-questionnaire override. `html_dompdf` reuses the existing purchased-report HTML/Dompdf renderer (no Claude analysis) and only works for submissions linked to a priced product.
- **Allow HTML/Dompdf fallback** - when the DOCX template is missing/invalid, `docx_template` mode fails clearly by default; enabling this falls back to the HTML/Dompdf renderer instead (same product-link constraint).
- **LibreOffice/soffice executable** - absolute path to the conversion binary. Leave blank to auto-detect common install locations. Conversion runs via `proc_open()` with an argv array (never a shell string), in an isolated per-conversion user-profile directory, with a configurable timeout (default 60s) and PDF-signature verification on the output.

### Storage and downloads

Generated DOCX/PDF files are stored under `wp-content/uploads/wp-questionnaires/questionnaire-reports/{docx,pdf}/` with content-addressed filenames, `index.html`/`.htaccess` deny-all guards, and realpath-containment path resolution (matching the remediation workbook's convention). Administrator downloads are served through capability-checked, nonce-protected `admin-post.php` routes; customer downloads go through the tokenised public route described below. The upload directory itself is never exposed directly in either case.

### Customer delivery

Delivery is configured as a **list of enabled channels** rather than a fixed set of switches, so a future channel needs no schema or settings change:

| Channel | Behaviour |
|---|---|
| `results_link` | Offers a secure download link on the results screen once generation finishes. |
| `post_checkout` | Offers the same link on the post-payment screen. Applies only once a linked priced product is paid for. |
| `email` | Emails the customer a secure link when the report is ready. The report is never attached. |

Set the global list in **Settings → AI**. Each questionnaire can inherit it, disable customer delivery entirely (admin download only), or select its own channels. With no channel enabled, reports still generate but only an administrator can download them.

Completing an assessment automatically queues that customer's report when any channel is enabled. Because generation is asynchronous, the results screen shows progress and then either the link or a note that the report has been emailed; it polls `GET /wpq/v1/questionnaire-report-status/{id}?session_token=…` (authorised by the submission's own session token) a bounded number of times.

Every channel hands out the same thing: a link to `GET /wpq/v1/questionnaire-report/{id}?token=…`. Those tokens are stored hashed, expire after 30 days or 10 downloads, and carry a `purpose` so a token minted for the paid HTML report cannot redeem the Questionnaire Report PDF or vice versa. A token is consumed only after the request is known to be servable, so a failed request does not burn one of the link's uses. Deleting a submission, anonymising a contact, or purging artefacts revokes the submission's tokens, so a link already sitting in a customer's inbox stops working rather than resolving to a missing file.

The delivery email's subject and opening paragraph are editable in **Settings → AI**.

### Data sent to Anthropic

The Claude analysis request includes: questionnaire name/ref/description/category, contact name/company/email, submission reference, overall score/grade/verdict/domain scores, per-question domain/ref/text/human-readable answer/scoring mode/score contribution/recommendation, and findings (including positive/informational ones). It never includes IP address, browser metadata, session tokens, Stripe identifiers, API credentials, or marketing/UTM attribution. See `.roadmap/claude-integration.md` for the full privacy note.

### Troubleshooting

Check **Readiness** for a dedicated "Report (DOCX → PDF)" panel covering: Claude configuration, the PHPWord library and its `gd`/`zip` PHP extension dependencies, renderer mode, PDF converter detection/availability/timeout, DOCX/PDF storage writability, and whether the HTML/Dompdf fallback is enabled. A `partial` status with a `pdf_conversion_failed` code almost always means the LibreOffice executable isn't installed or configured - set **Settings → AI → LibreOffice/soffice executable** and use **Retry PDF Conversion** on the submission.

If a generation request stays at "queued" indefinitely, check the **Cron & Task Processing** and **Cron Task Backlog** panels further down the same Readiness screen. WordPress' pseudo-cron only runs on a subsequent site visit; a queued job with no "last attempt" timestamp means WP-Cron never fired it - confirm whether `DISABLE_WP_CRON` is set and, if so, that a system cron is actually calling `wp-cron.php` on an interval. The backlog table lists every in-flight job with its submission, customer, requested/last-attempt times, attempt count, and a JSON payload preview, plus **Retry** (runs the job inline within that request rather than waiting on cron again) and **Cancel** (returns the submission to not-requested so Generate can be used fresh).

### Known limitations

- Generation is triggered automatically on assessment completion only when the questionnaire has a delivery channel enabled; otherwise it remains admin-triggered. There is no public "generate on demand" control in either case.
- The HTML/Dompdf fallback only applies to submissions linked to a priced product (it reuses the existing purchased-report template, which requires one).
- WordPress' built-in cron only fires on a page load after the scheduled time; sites with no regular traffic and `DISABLE_WP_CRON` set should trigger `wp-cron.php` externally (e.g. a system cron hitting it every few minutes) for prompt processing.

---

## Save & resume

An in-progress assessment can be resumed on any device. The heartbeat persists partial answers server-side as the customer works; the assessment screen's **Save & continue later** control mints a personal resume link (copy it, or have it emailed) via `POST /wpq/v1/resume-link`. The link carries a hashed, purpose-scoped token (30 days / 25 uses, `wpq_report_tokens` with `purpose='resume'`) - never the session credential - and is anchored to a validated same-site page URL.

Opening `?wpq_resume=…` redeems the token via `POST /wpq/v1/resume`: the session token is **rotated** (which also revives sessions blanked by a plugin-update migration), and the saved answers are replayed through the normal input handlers, landing on the first incomplete domain. Same-device return visits get a "Continue where you left off" banner backed by localStorage, verified against the server before being offered. Completed assessments refuse to resume with a clear message; resuming clears the abandoned flag.

## Enquiry forms

The **Enquiries** admin area is a light-weight form composer in the same spirit as the questionnaire composer. A form has a name, description, draft/published status, and up to 30 custom fields - text, textarea, select, or checkbox, each optionally required (choice fields must define their options). Publishing a form yields a shortcode (`[wpq_enquiry ref="EF-XXXXXX"]`) that renders the form on any page: contact name and email (required), company and phone (optional), the custom fields, and an explicit consent checkbox.

Submissions go to `POST /wpq/v1/enquiry` - rate-limited, honeypot-protected, and validated against the form definition (select answers must match a defined option, checkbox answers must be a subset, unknown keys are discarded). Each stored enquiry gets a reference like `ENQ-20260811-A1B2` and appears in the admin list with new/seen status. Per form you can set a notification recipient (defaults to the site admin email), toggle an acknowledgement email to the enquirer, and switch mail delivery off entirely. Enquiry records ride along with the existing GDPR export, anonymise, and delete tooling in Contacts.

## Email delivery

Every email the plugin sends - report delivery links, resume links, enquiry notifications and acknowledgements - is routed through `WPQ_Mailer`, configured under **Settings → Mail**:

| Setting | Purpose |
|---|---|
| Mail delivery | Global on/off switch for all plugin email. Default on. |
| Active provider | `wp_mail()` (default), Gmail API, AWS SES API, or Microsoft 365 (Microsoft Graph). |
| Gmail API | Google Cloud OAuth client ID/secret, refresh token (needs the `gmail.send` scope), and sender address. |
| AWS SES API | Access key, secret key, region, and a SES-verified from address. SigV4 signing is implemented in-plugin - no AWS SDK. |
| Microsoft 365 (Graph) | Entra ID (Azure AD) app registration: directory (tenant) ID, application (client) ID, client secret, and a sender mailbox in that tenant. |

Secrets are write-only password fields (leave blank to keep the stored value) and can instead be supplied via constants or environment variables (`WPQ_GMAIL_CLIENT_ID`, `WPQ_GMAIL_CLIENT_SECRET`, `WPQ_GMAIL_REFRESH_TOKEN`, `WPQ_GMAIL_SENDER`, `WPQ_SES_ACCESS_KEY`, `WPQ_SES_SECRET_KEY`, `WPQ_SES_REGION`, `WPQ_SES_FROM`, `WPQ_M365_TENANT_ID`, `WPQ_M365_CLIENT_ID`, `WPQ_M365_CLIENT_SECRET`, `WPQ_M365_SENDER`), which take precedence over stored options. The settings screen shows provider readiness diagnostics with the last delivery error, plus a test-send button.

Layered under the global switch, each questionnaire (edit screen → *Email delivery*) and each enquiry form has its own inherit/enabled/disabled setting, so mail can be silenced per questionnaire or per form without touching anything else.

### Setting up Microsoft 365 delivery

Microsoft 365 delivery authenticates app-only (OAuth2 client-credentials - there is no signed-in user), via an Entra ID (Azure AD) app registration with the Microsoft Graph **application** permission `Mail.Send`. That permission lets the app send mail as *any* mailbox in the tenant it's granted against, so the sender address configured in the plugin determines which mailbox the mail actually comes from - it is not tied to whoever created the app registration.

1. In the [Azure Portal](https://portal.azure.com/), go to **Entra ID → App registrations → New registration**. Any name/account-type is fine for a single-tenant integration like this (choose "Accounts in this organizational directory only").
2. Note the **Application (client) ID** and **Directory (tenant) ID** shown on the app's Overview page - these go into the plugin's Tenant ID / Client ID fields.
3. **Certificates & secrets → New client secret.** Copy the secret's *value* immediately (it's never shown again) - this goes into the plugin's Client secret field.
4. **API permissions → Add a permission → Microsoft Graph → Application permissions** (not Delegated - there's no user to delegate from) → search for and add `Mail.Send`.
5. Still on API permissions, click **Grant admin consent for [tenant]**. Without this step the permission is requested but inactive, and sends will fail with an authorization error even though the token exchange itself succeeds.
6. Decide which mailbox should appear as the sender (e.g. `reports@yourdomain.com`) and enter it as the Sender mailbox setting. It must be a real, licensed mailbox in the same tenant.
7. Optionally scope `Mail.Send` to specific mailboxes only (rather than every mailbox in the tenant) using an [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) in Exchange Online PowerShell - recommended for production, since an unscoped `Mail.Send` grant can send as any mailbox in the organisation.

Once the four fields are saved, use the **Send a test email** button on the same settings tab to confirm delivery end-to-end before switching the Active provider setting over.

## Bot protection (Cloudflare Turnstile)

The two public endpoints that write a new contact into the system - starting an assessment (`POST /wpq/v1/lead`) and submitting an enquiry (`POST /wpq/v1/enquiry`) - can require a [Cloudflare Turnstile](https://www.cloudflare.com/products/turnstile/) token, configured under **Settings → Turnstile**, and it's free. The widget renders with no `data-appearance` override, so the sitekey's own Widget Mode (Managed, Non-Interactive, or Invisible) - set in the Cloudflare dashboard - controls what visitors actually see; the plugin doesn't force a particular appearance.

| Setting | Purpose |
|---|---|
| Bot protection | Global on/off switch. Default off - requires an admin to configure keys and opt in. |
| Site key / Secret key | From the [Turnstile dashboard](https://dash.cloudflare.com/?to=/:account/turnstile). Constants/environment variables (`WPQ_TURNSTILE_SITE_KEY`, `WPQ_TURNSTILE_SECRET_KEY`) override the stored options. |

Layered under the global switch, each questionnaire and each enquiry form has its own inherit/enabled/disabled override, matching the mail-delivery pattern. Verification is deliberately **fail-open**: if Turnstile is enabled but not fully configured, or Cloudflare's `siteverify` API is unreachable or returns an unexpected response, the submission is allowed through rather than blocked - a misconfiguration or an outage on Cloudflare's side should never lock out a real customer. A missing token when the widget should have supplied one, or an explicit rejection from Cloudflare, fails closed.

## Frameworks & Standards (ATLAS skill imports)

The **Frameworks** admin page imports ATLAS `.skill` bundles (from [alltimeuk/atlas](https://github.com/alltimeuk/atlas/tree/main/Claude-Skills)) into the framework registry:

1. **Import** - upload one or more `.skill` files. Each bundle registers/refreshes a `wpq_frameworks` row (name, version, description from the bundle's `SKILL.md`) and replaces its control catalogue in `wpq_framework_controls`, parsed deterministically from the bundle's markdown. Re-importing a bundle is idempotent.
2. **Register with Anthropic** - pushes the stored bundle to the Anthropic Skills API (`POST /v1/skills`, beta `skills-2025-10-02`) and records the returned skill id/version on the framework row. Re-registering pushes a new skill version. Because the same stored artefact feeds both the catalogue and the API registration, the two cannot drift.

The parser recognises catalogue tables (the reference column is detected, not assumed first - and a column explicitly headed `ID`/`Control ID` is accepted even for digit-free ids such as NIST 800-53 family codes), heading-form catalogues (`### Article 32 - Security of processing`), and CMMC-style tables whose practice id embeds its NIST source; it excludes cross-standard mapping tables, glossaries, revision histories, worked examples, and workflow scaffolding. Bundles that carry no tabular catalogue fall back to curated supplements shipped with the plugin (`includes/framework-control-supplements.php`) authored from the standards' own structure - NIST SP 800-207, 800-39, 800-115, HIPAA, ISO 27018, NIS2, and the UK Cyber Security and Resilience Bill (marked provisional until Royal Assent). A bundle that later ships its own catalogue automatically takes precedence over a fallback supplement; COBIT uses the one `replace`-mode supplement (its canonical 40 objectives beat the bundle's fragmentary list). 38 of the 40 ATLAS skills import with a control catalogue; only ITIL v3/v4 are metadata-only, being process frameworks with no control catalogue by design - still fully usable for readiness analysis.

Bundles are stored under `wp-content/uploads/wp-questionnaires/skills/` with `index.html`/`.htaccess` deny-all guards.

Each questionnaire selects which frameworks it is assessed against (questionnaire editor → *Frameworks assessed*; only Anthropic-registered frameworks are selectable, maximum 8 - each adds a Claude call). Every selected framework is assessed in its own beta Messages call with the framework's ATLAS skill attached via `container.skills` (betas `code-execution-2025-08-25` + `skills-2025-10-02`; skills execute through the code-execution container, so that tool is declared on the request). The assessment contract is strict JSON: a readiness level (aligned / partially aligned / not aligned / insufficient evidence), a percentage **only** when the standard's own methodology yields one (the prompt forbids estimated figures), a posture summary, and per-control strengths and gaps. Every cited control reference is validated against the imported catalogue - a hallucinated ref is cleared while the finding's substance is kept, the same anti-hallucination pattern used for `related_finding_ids`.

This assessment runs independently in two places, each making its own Claude calls rather than sharing one result: automatically at submission time to power the results screen (see *Results screen: Domain Breakdown and Framework Readiness* below), and again during Questionnaire Report generation to populate the report's optional `frameworks` template block. Enabling both surfaces for the same questionnaire therefore calls Claude for framework readiness twice per submission. Failures in either path skip the affected framework and never block the results screen or report generation.

## Results screen: Domain Breakdown and Framework Readiness

Immediately after a customer completes a questionnaire - before any Questionnaire Report or Remediation Plan is ever generated - the results screen shows two chart-driven sections built from that single submission.

### Domain Breakdown

A chart of the customer's score in each of the questionnaire's own domains, drawn from the scoring that has already happened by the time the results screen loads: no Claude call, no async wait, no polling. It renders in the same response as the score ring and Key Findings, alongside the existing exact-value domain score cards (kept as both the precision complement to the chart and the accessible text/semantic representation for screen readers).

It draws as a radar/spider chart when the questionnaire has 3 or more domains, and automatically falls back to horizontal bars below that (a radar needs at least three points to read as a shape). Each point on the radar and each bar carries a short sequential letter (A, B, C… continuing past Z as AA, AB…) so a point can be matched back to its domain without reading full names off the chart itself; hovering a radar point also shows the full name and percentage as a native SVG tooltip.

### Framework Readiness

A chart of the customer's posture against whichever compliance frameworks/standards the questionnaire has been configured to assess (see *Frameworks & Standards* above), shown as horizontal bars, one per assessed framework, coloured and positioned by readiness level.

Unlike Domain Breakdown, this needs a Claude call per framework, so it does not appear instantly:

- It is triggered **automatically the moment a submission completes** - not gated behind the customer requesting an assessment report, and not dependent on a Questionnaire Report ever being generated for that submission. It runs as its own background job (WP-Cron), assessing every selected framework concurrently via `curl_multi` (falling back to one-at-a-time on hosts where `curl_multi_*` is disabled), so total latency is bounded by the slowest single framework rather than their sum.
- While the job is queued or running, the section shows a "Computing your framework readiness…" status and the results screen polls for completion; once assessments are stored, the chart replaces that message without a page reload.
- A maximum of 8 frameworks are assessed per submission. A framework whose assessment fails is skipped (logged, never fatal) rather than blocking the others or the results screen.

### Settings

| Setting | Purpose |
|---|---|
| Global Framework Readiness (Settings → AI) | Global on/off switch, default **on**. `WPQ_FRAMEWORK_READINESS_ENABLED` (PHP constant) overrides it when defined. Disabling it - globally or per questionnaire - means a completed submission never schedules a Claude call for this feature, and the results screen never shows or polls for it; any assessment already stored for a prior submission is left untouched, just not served. |
| Default Domain Breakdown visualisation (Settings → AI) | Global default chart type, **Bar charts** or **Radar / spider chart**, default `bars`. Inherited by any questionnaire left on "Inherit global setting". |
| Framework readiness (questionnaire editor) | Per-questionnaire inherit/enabled/disabled override, layered under the global switch. |
| Frameworks assessed (questionnaire editor) | Checkbox list of Anthropic-registered frameworks to assess this questionnaire's submissions against, capped at 8 selections; unregistered frameworks are shown disabled. |
| Domain Breakdown visualisation (questionnaire editor) | Per-questionnaire inherit/bars/radar override. A radar chart still falls back to bars automatically below 3 domains regardless of this setting. |

An un-migrated or never-configured questionnaire resolves both settings to their backward-compatible defaults (Framework Readiness **enabled**, Domain Breakdown **bars**), so upgrading the plugin never changes what an existing questionnaire's results screen shows unless someone explicitly opts it in.

## Questionnaire library and sample data

The plugin ships with a seeded CS-01 CyberCheck assessment. Additional questionnaires are loaded via **Import / Export**.

The `.sample_data/` directory in the source repository contains optional ready-to-import examples. These files are point-in-time demonstrations of what the plugin can support; they are not included in release ZIPs and are not automatically imported during plugin installation or upgrade.

| File | Contents |
|---|---|
| `ce-2026-danzell.json` | Cyber Essentials 2026 self-assessment (DANZELL v9.0, April 2026) |
| `wpq-import-batch-01.json` – `wpq-import-batch-06.json` | 150 generic questionnaires (QL-001 to QL-150), 25 per file |

Questionnaire refs follow the format `[A-Z]{2,6}-?\d{1,6}` - both `CS-01` and `CS01` are valid. Use the bulk **Publish** action in the Questionnaires screen to publish a batch of imported questionnaires at once.

---

## Stripe and paid reports

One-off paid report checkout is implemented but Feature Gated. Saving Stripe keys does not enable payments on the live site. Product CTAs are hidden from public results unless checkout is enabled through the Settings -> Stripe feature gate or the `WPQ_CHECKOUT_ENABLED` PHP constant, and every checkout capability check passes. If the constant is defined in `wp-config.php` or a must-use plugin, it takes precedence over the database setting.

Checkout supports one-off Stripe Checkout payments only. Subscription products remain unsupported and are rejected by the checkout endpoint.

Stripe configuration is resolved centrally in this order:

1. Plugin constants: `WPQ_STRIPE_PUBLISHABLE_KEY`, `WPQ_STRIPE_SECRET_KEY`, `WPQ_STRIPE_WEBHOOK_SECRET`.
2. Server environment variables: `STRIPE_PUBLISHABLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`.
3. WordPress options saved from Settings → Stripe.

Production deployments should prefer constants or server environment variables for secret values.

REST endpoints:

| Endpoint | Purpose |
|---|---|
| `POST /wp-json/wpq/v1/checkout` | Creates a Stripe Checkout Session for a completed assessment. |
| `POST /wp-json/wpq/v1/stripe/webhook` | Verifies Stripe webhooks, logs payment events, transitions payment state, and generates paid reports. |
| `GET /wp-json/wpq/v1/reports/{id}?token=...` | Serves generated PDF reports after signed token validation. |

Security model:

- Checkout only works for completed assessments and active one-off products belonging to the same questionnaire.
- Payment is never marked as paid from the Stripe redirect URL.
- Only webhook-confirmed `checkout.session.completed` events can transition a submission from `pending` to `paid`.
- Webhook processing is idempotent through the unique Stripe event ID stored in `wpq_payment_events`.
- Reports are not exposed by numeric ID alone. Customer downloads require a signed, expiring report token stored server-side only as a hash.
- Report tokens default to five uses and expire after seven days.

---

## HaloPSA API

WP Questionnaires exposes authenticated REST endpoints so that an external HaloPSA integration tool can pull submission data from WordPress. No HaloPSA credentials are stored in WordPress.

**Setup:**
1. Create a dedicated WP user with the **WPQ HaloPSA API** role.
2. Generate an Application Password for that user.
3. Configure the HaloPSA integration tool with the site URL, username, and application password.

See **Settings → HaloPSA API** in WP Admin for the full endpoint reference and curl examples.

---

## Roles

| Role | Purpose |
|---|---|
| `wpq_halopsa` | Pull-only API access for the HaloPSA integration tool. No WP Admin access. |

The role is created on plugin activation and always removed on uninstall because it is an executable access artefact. Deactivating the plugin preserves the role so that re-activation restores full functionality without reconfiguration.

---

## Privacy and data retention

WP Questionnaires stores lead records (name, email, company, phone), assessment answers, scores, findings, and attribution data in custom database tables.

The public shortcode inherits the active theme font stack by default. The plugin does not enqueue Google Fonts or another third-party font provider.

On plugin deactivation, all data is preserved. On uninstall, the default behaviour is also to preserve all data.

To enable destructive cleanup on uninstall, go to **Settings → Advanced** and enable "Delete all data on uninstall". This option defaults to **off**. Without it set, deleting the plugin from WordPress leaves all business data intact.

Generated Questionnaire Report DOCX/PDF files embed the customer's name and company in their content. Soft-deleting a submission, anonymising a contact (bulk or individual), and permanently deleting a contact's records all immediately remove the generated DOCX/PDF files from disk (in addition to the usual database-level changes), so an anonymised or deleted customer's report can never remain silently downloadable.

**Back up your database before enabling this option.**

---

## Uninstall behaviour

| Data | Default (option off) | Option on |
|---|---|---|
| Rate-limit transients | Deleted | Deleted |
| Plugin database tables | Preserved | Dropped |
| WordPress options (keys, settings) | Preserved | Deleted |
| Generated Questionnaire Report DOCX/PDF files | Preserved | Deleted |
| `wpq_halopsa` role | Removed | Removed |

---

## Release packaging

Use the **Release ZIP** GitHub Actions workflow in `.github/workflows/release.yml` for release artefacts. It runs the quality gates, installs production Composer dependencies, includes `vendor/`, keeps `composer.lock`, excludes CI/test/dev tooling, and uploads a versioned plugin ZIP. Keep `CHANGELOG.md` current with release version, DB version, migration notes, and compatibility notes.

Manual packaging should follow the same shape:

1. Run `composer install --no-dev --prefer-dist --no-interaction --no-progress --optimize-autoloader`.
2. Keep `composer.lock` in source and release artefacts for auditability.
3. Delete development artefacts: `tests/`, `.github/`, PHPUnit/PHPCS/PHPStan config files, `_archive/`, coverage, logs, and temporary build directories. Also delete `includes/data/questionnaire-library-1.0.0.php` (the seeded demo library) - everything else under `includes/` is real code the plugin loads at runtime.
4. Zip the plugin directory as `wp-questionnaires-vX.Y.Z.zip`.
5. Upload to WP Admin or deploy via your release pipeline.

---

## Test strategy

The PHPStan WordPress stubs in `tests/phpstan-wordpress-stubs.php` exist only for static-analysis symbol discovery. They intentionally return safe defaults and should not be treated as runtime or integration coverage.

Default PHPUnit runs pure unit tests plus lightweight WordPress-stub workflow tests. Real WordPress behaviour is covered by the integration suite in `tests/integration/` via `phpunit.integration.xml.dist` with `WP_TESTS_DIR` pointing at the WordPress test suite. The CI `integration` job provisions a MySQL service and installs the WordPress test suite with `bin/install-wp-tests.sh`, but only runs when the `WPQ_RUN_INTEGRATION` repository variable is set to `true` - it is currently gated off (skips green rather than failing) because it requires a `ubuntu-latest` GitHub-hosted runner, which this repository's Actions billing state currently blocks; the rest of CI runs on a registered self-hosted Windows runner instead. Set that repository variable (or point the job at a Linux self-hosted runner) once GitHub-hosted runners are available again.

Integration coverage includes: role and capability creation, REST authentication (401/403/200) for HaloPSA endpoints, public endpoint payload validation (lead/submit/heartbeat/checkout), schema migration from older DB versions, report-token lifecycle (creation, max-uses, expiry, consumption), and Stripe webhook idempotency.

PHPStan level 3 is the current floor. Raise to level 5 in a follow-up pass.
