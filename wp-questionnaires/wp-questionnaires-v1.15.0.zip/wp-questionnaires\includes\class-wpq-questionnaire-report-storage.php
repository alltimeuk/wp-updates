<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Protected on-disk storage for generated Questionnaire Report artefacts
 * (populated DOCX and converted PDF), separate from the Remediation Plan
 * workbook storage and from the HTML/Dompdf report storage.
 */
class WPQ_Questionnaire_Report_Storage {

	private const SUBDIR_DOCX = 'docx';
	private const SUBDIR_PDF  = 'pdf';
	private const SUBDIR_XLSX = 'remediation-xlsx';

	public static function get_storage_dir( string $subdir, bool $ensure = true ): string {
		if ( ! in_array( $subdir, [ self::SUBDIR_DOCX, self::SUBDIR_PDF, self::SUBDIR_XLSX ], true ) ) {
			return '';
		}
		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return '';
		}

		$upload = wp_upload_dir();
		if ( ! is_array( $upload ) || ! empty( $upload['error'] ) || empty( $upload['basedir'] ) ) {
			return '';
		}

		$directory = rtrim( (string) $upload['basedir'], DIRECTORY_SEPARATOR )
			. DIRECTORY_SEPARATOR . 'wp-questionnaires'
			. DIRECTORY_SEPARATOR . 'questionnaire-reports'
			. DIRECTORY_SEPARATOR . $subdir;

		if ( ! $ensure ) {
			return $directory;
		}

		if ( ! is_dir( $directory ) && function_exists( 'wp_mkdir_p' ) && ! wp_mkdir_p( $directory ) ) {
			return '';
		}
		if ( ! is_dir( $directory ) ) {
			return '';
		}

		self::write_access_guards( $directory );
		return $directory;
	}

	public static function store_docx( int $submission_id, string $binary ): array {
		return self::store( self::SUBDIR_DOCX, 'docx', $submission_id, $binary );
	}

	public static function store_pdf( int $submission_id, string $binary ): array {
		return self::store( self::SUBDIR_PDF, 'pdf', $submission_id, $binary );
	}

	public static function store_remediation_xlsx( int $submission_id, string $binary ): array {
		return self::store( self::SUBDIR_XLSX, 'xlsx', $submission_id, $binary );
	}

	private static function store( string $subdir, string $extension, int $submission_id, string $binary ): array {
		if ( $submission_id <= 0 || '' === $binary ) {
			return [];
		}

		$directory = self::get_storage_dir( $subdir );
		if ( '' === $directory ) {
			return [];
		}

		$file_name = preg_replace(
			'/[^A-Za-z0-9._-]/',
			'-',
			sprintf(
				'wpq-questionnaire-report-%d-%s.%s',
				$submission_id,
				substr( hash( 'sha256', $binary . wp_salt( 'auth' ) ), 0, 16 ),
				$extension
			)
		);
		$file_name = $file_name ?: sprintf( 'wpq-questionnaire-report-%d.%s', $submission_id, $extension );
		$path      = $directory . DIRECTORY_SEPARATOR . $file_name;

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Plugin-owned generated artefact in uploads.
		if ( file_put_contents( $path, $binary ) === false ) {
			return [];
		}

		return [
			'path'     => $file_name,
			'name'     => $file_name,
			'checksum' => hash( 'sha256', $binary ),
		];
	}

	public static function resolve_docx_path( string $stored_path ): ?string {
		return self::resolve( self::SUBDIR_DOCX, 'docx', $stored_path );
	}

	public static function resolve_pdf_path( string $stored_path ): ?string {
		return self::resolve( self::SUBDIR_PDF, 'pdf', $stored_path );
	}

	public static function resolve_remediation_xlsx_path( string $stored_path ): ?string {
		return self::resolve( self::SUBDIR_XLSX, 'xlsx', $stored_path );
	}

	private static function resolve( string $subdir, string $extension, string $stored_path ): ?string {
		$stored_path = trim( $stored_path );
		if ( '' === $stored_path || strtolower( pathinfo( $stored_path, PATHINFO_EXTENSION ) ) !== $extension ) {
			return null;
		}

		$directory = self::get_storage_dir( $subdir );
		if ( '' === $directory ) {
			return null;
		}

		$storage_root = realpath( $directory );
		if ( ! is_string( $storage_root ) || '' === $storage_root ) {
			return null;
		}

		$is_absolute = str_starts_with( $stored_path, '/' )
			|| str_starts_with( $stored_path, '\\' )
			|| preg_match( '/^[A-Za-z]:[\/\\\\]/', $stored_path );
		$candidate = $is_absolute
			? $stored_path
			: $storage_root . DIRECTORY_SEPARATOR . ltrim( str_replace( [ '/', '\\' ], DIRECTORY_SEPARATOR, $stored_path ), DIRECTORY_SEPARATOR );

		$resolved = realpath( $candidate );
		if ( ! is_string( $resolved ) || '' === $resolved ) {
			return null;
		}

		$storage_root_compare = self::normalise_path_for_compare( rtrim( $storage_root, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR );
		$resolved_compare     = self::normalise_path_for_compare( $resolved );
		if ( strncmp( $resolved_compare, $storage_root_compare, strlen( $storage_root_compare ) ) !== 0 ) {
			return null;
		}

		return strtolower( pathinfo( $resolved, PATHINFO_EXTENSION ) ) === $extension ? $resolved : null;
	}

	public static function delete_stored_files( ?string $docx_relative, ?string $pdf_relative ): void {
		if ( ! empty( $docx_relative ) ) {
			$path = self::resolve_docx_path( (string) $docx_relative );
			if ( null !== $path ) {
				@unlink( $path );
			}
		}
		if ( ! empty( $pdf_relative ) ) {
			$path = self::resolve_pdf_path( (string) $pdf_relative );
			if ( null !== $path ) {
				@unlink( $path );
			}
		}
	}

	public static function diagnostics(): array {
		$docx_dir = self::get_storage_dir( self::SUBDIR_DOCX, false );
		$pdf_dir  = self::get_storage_dir( self::SUBDIR_PDF, false );

		return [
			'docx' => self::directory_diagnostics( $docx_dir ),
			'pdf'  => self::directory_diagnostics( $pdf_dir ),
		];
	}

	private static function directory_diagnostics( string $directory ): array {
		$parent = $directory !== '' ? self::nearest_existing_parent( $directory ) : '';

		return [
			'path'                   => $directory,
			'available'              => $directory !== '' && is_dir( $directory ),
			'writable'               => $directory !== '' && is_dir( $directory ) && is_writable( $directory ),
			'creatable'              => $directory !== '' && ! is_dir( $directory ) && $parent !== '' && is_writable( $parent ),
			'index_guard_present'    => $directory !== '' && is_file( $directory . DIRECTORY_SEPARATOR . 'index.html' ),
			'htaccess_guard_present' => $directory !== '' && is_file( $directory . DIRECTORY_SEPARATOR . '.htaccess' ),
		];
	}

	private static function nearest_existing_parent( string $path ): string {
		$parent = dirname( $path );
		while ( $parent !== '' && $parent !== '.' && ! is_dir( $parent ) ) {
			$next = dirname( $parent );
			if ( $next === $parent ) {
				return '';
			}
			$parent = $next;
		}

		return is_dir( $parent ) ? $parent : '';
	}

	private static function normalise_path_for_compare( string $path ): string {
		$path = str_replace( '\\', '/', $path );
		return PHP_OS_FAMILY === 'Windows' ? strtolower( $path ) : $path;
	}

	private static function write_access_guards( string $directory ): void {
		$index = $directory . DIRECTORY_SEPARATOR . 'index.html';
		if ( ! is_file( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Static guard file in plugin-owned uploads directory.
			file_put_contents( $index, '' );
		}

		$htaccess = $directory . DIRECTORY_SEPARATOR . '.htaccess';
		if ( ! is_file( $htaccess ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Best-effort Apache guard for generated private artefacts.
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" );
		}
	}
}
