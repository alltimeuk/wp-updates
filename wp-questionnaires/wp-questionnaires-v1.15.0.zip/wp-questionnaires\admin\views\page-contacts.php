<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var array<int, object> $contacts
 * @var int                $total
 * @var int                $per_page
 * @var int                $page
 * @var string             $search
 */
$contacts = $contacts ?? [];
/** @phpstan-ignore-next-line */
$total    = $total    ?? 0;
/** @phpstan-ignore-next-line */
$per_page = $per_page ?? 50;
/** @phpstan-ignore-next-line */
$page     = $page     ?? 1;
/** @phpstan-ignore-next-line */
$search   = $search   ?? '';

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- feedback-only GET params, no data mutation
$anonymised = isset( $_GET['anonymised'] ) ? (int) $_GET['anonymised'] : null;
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$deleted = isset( $_GET['deleted'] ) ? (int) $_GET['deleted'] : null;

$total_pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 1;
$base_url    = admin_url( 'admin.php?page=wpq-contacts' );
?>
<div class="wrap wpq-admin-wrap">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
    <h1 style="margin:0;">Contacts</h1>
    <div style="display:flex;align-items:center;gap:6px;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="button" title="Import contacts">&#8593; Import</a>
      <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=contacts' ), 'wpq_export_contacts' ) ); ?>" class="button" title="Export all contacts">&#8595; Export all</a>
    </div>
  </div>
  <p class="description">Unique submitters across all questionnaires. Use GDPR operations on the contact detail page to comply with data-subject rights requests.</p>

  <?php if ( $anonymised !== null ) : ?>
    <div class="notice notice-success inline" style="margin:12px 0;padding:8px 12px;">
      <p>Anonymised <?php echo esc_html( (string) $anonymised ); ?> submission(s).</p>
    </div>
  <?php endif; ?>
  <?php if ( $deleted !== null ) : ?>
    <div class="notice notice-success inline" style="margin:12px 0;padding:8px 12px;">
      <p>Permanently deleted <?php echo esc_html( (string) $deleted ); ?> submission(s) and removed the contact record.</p>
    </div>
  <?php endif; ?>

  <form method="get" style="margin:16px 0 8px;display:flex;gap:8px;align-items:center;">
    <input type="hidden" name="page" value="wpq-contacts">
    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search name, company, phone or email&hellip;" class="regular-text">
    <button type="submit" class="button">Search</button>
    <?php if ( $search ) : ?>
      <a href="<?php echo esc_url( $base_url ); ?>" class="button">Clear</a>
    <?php endif; ?>
    <span class="description" style="margin-left:8px;"><?php echo esc_html( number_format( $total ) ); ?> contact<?php echo $total !== 1 ? 's' : ''; ?></span>
  </form>

  <!-- Bulk actions bar -->
  <div style="margin:12px 0 4px;display:flex;align-items:center;gap:8px;"
       data-export-type="contacts"
       data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'wpq_export_contacts' ) ); ?>">
    <select id="wpq-bulk-action" class="button" style="height:30px;">
      <option value="">&mdash; Bulk action &mdash;</option>
      <option value="export_selected">Export selected</option>
    </select>
    <button id="wpq-bulk-go" class="button">GO</button>
    <span id="wpq-bulk-status" class="wpq-save-status"></span>
  </div>

  <table class="wp-list-table widefat fixed striped" data-wpq-sortable="true">
    <thead>
      <tr>
        <th style="width:32px;" data-no-sort><input type="checkbox" id="wpq-select-all" title="Select all"></th>
        <th style="width:180px;">Name</th>
        <th style="width:160px;">Company</th>
        <th style="width:130px;">Phone no</th>
        <th>Email</th>
        <th style="width:70px;" title="Total submissions">Subs</th>
        <th style="width:70px;" title="Completed submissions">Done</th>
        <th style="width:60px;" title="Paid submissions">Paid</th>
        <th style="width:120px;">Last seen</th>
        <th style="width:80px;">Opted out</th>
        <th style="width:60px;" data-no-sort></th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $contacts ) ) : ?>
        <tr><td colspan="11">No contacts found<?php echo $search ? ' matching "' . esc_html( $search ) . '"' : ''; ?>.</td></tr>
      <?php else : ?>
        <?php foreach ( $contacts as $c ) : ?>
          <?php
          $detail_url = add_query_arg( [
              'page'       => 'wpq-contacts',
              'wpq_action' => 'view',
              'email'      => rawurlencode( $c->contact_email ),
          ], admin_url( 'admin.php' ) );
          $last_date  = $c->last_submission_at ? wp_date( 'd M Y', strtotime( $c->last_submission_at ) ) : '';
          $link_label = $c->contact_name ? $c->contact_name : $c->contact_email;
          $company    = $c->contact_company ? $c->contact_company : '&mdash;';
          $phone      = $c->contact_phone ? $c->contact_phone : '&mdash;';
          ?>
          <tr>
            <td><input type="checkbox" class="wpq-row-select" value="<?php echo esc_attr( $c->contact_email ); ?>"></td>
            <td><a href="<?php echo esc_url( $detail_url ); ?>"><?php echo esc_html( $link_label ); ?></a></td>
            <td><?php echo wp_kses_post( $company ); ?></td>
            <td><?php echo wp_kses_post( $phone ); ?></td>
            <td><?php echo esc_html( $c->contact_email ); ?></td>
            <td style="text-align:center;"><?php echo (int) $c->submission_count; ?></td>
            <td style="text-align:center;"><?php echo (int) $c->completed_count; ?></td>
            <td style="text-align:center;"><?php echo (int) $c->paid_count; ?></td>
            <td><?php echo $last_date ? esc_html( $last_date ) : wp_kses_post( '&mdash;' ); ?></td>
            <td>
              <?php if ( $c->opted_out ) : ?>
                <span style="color:#d63638;font-weight:600;">Opted out</span>
              <?php else : ?>
                <span class="description">No</span>
              <?php endif; ?>
            </td>
            <td><a href="<?php echo esc_url( $detail_url ); ?>" class="button button-small">View</a></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <?php if ( $total_pages > 1 ) : ?>
    <div style="margin-top:16px;">
      <?php
      // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- paginate_links returns safe HTML
      echo paginate_links( [
          /** @phpstan-ignore-next-line */
          'base'      => add_query_arg( 'paged', '%#%', esc_url( $base_url . ( $search ? '&s=' . rawurlencode( $search ) : '' ) ) ),
          'format'    => '',
          'current'   => $page,
          'total'     => $total_pages,
          'prev_text' => '&laquo;',
          'next_text' => '&raquo;',
      ] );
      // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
      ?>
    </div>
  <?php endif; ?>
</div>
