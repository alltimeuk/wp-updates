<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class WPQ_Submissions_Table extends WP_List_Table {

	public function __construct() {
		parent::__construct( [
			'singular' => 'submission',
			'plural'   => 'submissions',
			'ajax'     => false,
		] );
	}

	public function get_columns(): array {
		return [
			'cb'               => '<input type="checkbox" />',
			'ref'              => 'Ref',
			'contact'          => 'Contact',
			'questionnaire'    => 'Assessment',
			'overall_score'    => 'Score',
			'grade_id'         => 'Grade',
			'abandoned'        => 'Status',
			'remediation_plan' => 'Remediation',
			'halopsa_sync_status' => 'HaloPSA',
			'utm_source'       => 'Source',
			'created_at'       => 'Date',
		];
	}

	public function get_sortable_columns(): array {
		return [
			'ref'                 => [ 'ref', false ],
			'contact'             => [ 'contact', false ],
			'questionnaire'       => [ 'questionnaire', false ],
			'overall_score'       => [ 'overall_score', false ],
			'grade_id'            => [ 'grade_id', false ],
			'abandoned'           => [ 'abandoned', false ],
			'halopsa_sync_status' => [ 'halopsa_sync_status', false ],
			'utm_source'          => [ 'utm_source', false ],
			'created_at'          => [ 'created_at', true ],
		];
	}

	protected function get_bulk_actions(): array {
		return [ 'delete' => 'Delete' ];
	}

	private function get_request_value( string $key, $default = '' ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Callers sanitize according to expected type.
		return isset( $_REQUEST[ $key ] ) ? wp_unslash( $_REQUEST[ $key ] ) : $default;
	}

	public function prepare_items(): void {
		$this->_column_headers = [
			$this->get_columns(),
			[],
			$this->get_sortable_columns(),
		];

		$per_page     = $this->get_items_per_page( 'wpq_submissions_per_page', 20 );
		$current_page = $this->get_pagenum();

		$orderby_raw = sanitize_key( $this->get_request_value( 'orderby', 'created_at' ) );
		$order_raw   = strtoupper( sanitize_key( $this->get_request_value( 'order', 'desc' ) ) );

		$args = [
			'per_page'           => $per_page,
			'page'               => $current_page,
			'questionnaire_id'   => isset( $_REQUEST['questionnaire_id'] ) ? (int) $this->get_request_value( 'questionnaire_id', 0 ) : null,
			'grade_id'           => sanitize_text_field( $this->get_request_value( 'grade_id' ) ) ?: null,
			'halopsa_sync_status'=> sanitize_text_field( $this->get_request_value( 'halopsa_sync_status' ) ) ?: null,
			'search'             => sanitize_text_field( $this->get_request_value( 's' ) ) ?: null,
			'orderby'            => $orderby_raw,
			'order'              => $order_raw === 'ASC' ? 'ASC' : 'DESC',
		];

		$result      = WPQ_Database::get_submissions( array_filter( $args ) );
		$this->items = $result['items'];

		$this->set_pagination_args( [
			'total_items' => $result['total'],
			'per_page'    => $per_page,
			'total_pages' => ceil( $result['total'] / $per_page ),
		] );
	}

	public function column_default( $item, $column_name ): string {
		return esc_html( $item->$column_name ?? '—' );
	}

	public function column_cb( $item ): string {
		return sprintf( '<input type="checkbox" name="submission[]" value="%d" />', $item->id );
	}

	public function column_ref( $item ): string {
		$view_url   = admin_url( 'admin.php?page=wpq-submissions&wpq_action=view&id=' . $item->id );
		$delete_url = wp_nonce_url(
			admin_url( 'admin.php?page=wpq-submissions&wpq_action=delete_submission&id=' . $item->id ),
			'wpq_delete_submission'
		);
		$actions = [
			'view'   => sprintf( '<a href="%s">View</a>', esc_url( $view_url ) ),
			'delete' => sprintf( '<a href="%s" class="wpq-confirm-delete">Delete</a>', esc_url( $delete_url ) ),
		];
		return sprintf( '<a href="%s"><strong>%s</strong></a>%s', esc_url( $view_url ), esc_html( $item->ref ), $this->row_actions( $actions ) );
	}

	public function column_contact( $item ): string {
		return sprintf(
			'<strong>%s</strong><br><a href="mailto:%s">%s</a><br><span class="description">%s</span>',
			esc_html( $item->contact_name ),
			esc_attr( $item->contact_email ),
			esc_html( $item->contact_email ),
			esc_html( $item->contact_company )
		);
	}

	public function column_questionnaire( $item ): string {
		return sprintf( '<span class="wpq-badge">%s</span> %s',
			esc_html( $item->questionnaire_ref ?? '' ),
			esc_html( $item->questionnaire_name ?? '—' )
		);
	}

	public function column_overall_score( $item ): string {
		if ( $item->overall_score === null ) return '<span class="description">—</span>';
		return sprintf( '<strong>%d</strong><span class="description">/100</span>', (int) $item->overall_score );
	}

	public function column_grade_id( $item ): string {
		if ( ! $item->grade_id ) return '—';
		$labels = [
			'strong'          => [ 'Strong',           '#d4f5e5', '#1a5e35' ],
			'moderate'        => [ 'Moderate',          '#e8f4f8', '#1a5068' ],
			'needs_attention' => [ 'Needs Attention',   '#fef3d8', '#7a4e00' ],
			'high_risk'       => [ 'High Risk',         '#fff5f5', '#8a1c22' ],
		];
		[ $label, $bg, $color ] = $labels[ $item->grade_id ] ?? [ ucfirst( $item->grade_id ), '#f5f5f5', '#333' ];
		return sprintf(
			'<span style="background:%s;color:%s;padding:2px 10px;border-radius:10px;font-size:0.8em;font-weight:600;">%s</span>',
			esc_attr( $bg ), esc_attr( $color ), esc_html( $label )
		);
	}

	public function column_abandoned( $item ): string {
		$ab = (int) $item->abandoned;
		if ( $ab === 0 ) return '<span class="wpq-status-completed">&#10003; Completed</span>';
		if ( $ab === 2 ) return '<span class="wpq-status-deleted">&#128465; Deleted (soft)</span>';
		return '<span class="wpq-status-partial">&#8987; Partial</span>';
	}

	public function column_remediation_plan( $item ): string {
		$links = [];
		if ( (int) ( $item->abandoned ?? 1 ) === 0 && ! empty( $item->completed_at ) ) {
			$generate_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wpq_generate_remediation_plan&submission_id=' . (int) $item->id . '&days=90' ),
				'wpq_generate_remediation_plan'
			);
			$links[] = sprintf( '<a class="button button-small" href="%s">%s</a>', esc_url( $generate_url ), esc_html( 'Generate Remediation Plan' ) );
		}

		if ( ! empty( $item->ai_report_docx_path ) && class_exists( 'WPQ_Remediation_Plan' ) && WPQ_Remediation_Plan::resolve_workbook_path( (string) $item->ai_report_docx_path ) ) {
			$download_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wpq_download_remediation_plan&submission_id=' . (int) $item->id ),
				'wpq_download_remediation_plan'
			);
			$links[] = sprintf( '<a href="%s">%s</a>', esc_url( $download_url ), esc_html( 'Download the Plan' ) );
		}

		return $links ? implode( '<br>', $links ) : '<span class="description">—</span>';
	}

	public function column_halopsa_sync_status( $item ): string {
		$map = [
			'synced'        => '<span style="color:#2eb872;">&#10003; Synced</span>',
			'pending'       => '<span style="color:#f5a623;">&#8987; Pending</span>',
			'processing'    => '<span style="color:#0073aa;">&#8635; Processing</span>',
			'failed'        => '<span style="color:#e84855;">&#10007; Failed</span>',
			'retry_pending' => '<span style="color:#d63638;">&#8635; Retry pending</span>',
			'ignored'       => '<span style="color:#888;">&#8212; Ignored</span>',
			'manual_review' => '<span style="color:#dba617;">&#9888; Manual review</span>',
			'skipped'       => '<span style="color:#888;">&#8212; Skipped</span>',
		];
		$status = $item->halopsa_sync_status ?? 'pending';
		return $map[ $status ] ?? esc_html( $status );
	}

	public function column_utm_source( $item ): string {
		return $item->utm_source ? esc_html( $item->utm_source ) : '<span class="description">—</span>';
	}

	public function column_created_at( $item ): string {
		return esc_html( wp_date( 'd M Y H:i', strtotime( $item->created_at ) ) );
	}

	public function extra_tablenav( $which ): void {
		if ( $which !== 'top' ) return;
		$questionnaires = WPQ_Database::get_questionnaire_list();
		$current_q      = (int) $this->get_request_value( 'questionnaire_id', 0 );
		$current_g      = sanitize_text_field( $this->get_request_value( 'grade_id' ) );
		?>
		<div class="alignleft actions">
			<select name="questionnaire_id">
				<option value="">All assessments</option>
				<?php foreach ( $questionnaires as $q ) : ?>
					<option value="<?php echo esc_attr( $q->id ); ?>" <?php selected( $current_q, $q->id ); ?>>
						<?php echo esc_html( '[' . $q->ref . '] ' . $q->name ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<select name="grade_id">
				<option value="">All grades</option>
				<?php foreach ( [ 'strong' => 'Strong', 'moderate' => 'Moderate', 'needs_attention' => 'Needs Attention', 'high_risk' => 'High Risk' ] as $k => $v ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $current_g, $k ); ?>>
						<?php echo esc_html( $v ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<?php submit_button( 'Filter', 'secondary', 'filter_action', false ); ?>
		</div>
		<?php
	}
}
