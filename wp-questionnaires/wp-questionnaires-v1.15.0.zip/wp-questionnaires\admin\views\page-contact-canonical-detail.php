<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Canonical contact detail: profile, identities, organisations,
 * preferences, timeline, linked sources, HaloPSA references, merge/audit
 * history, and the edit/merge forms. Canonical data is clearly separated
 * from historic interaction snapshots (shown on the linked source rows).
 *
 * @var array<string, mixed> $profile Output of WPQ_Contact_Admin::get_profile().
 */
$profile = $profile ?? null;
if ( ! is_array( $profile ) ) {
	echo '<div class="wrap"><h1>Contact</h1><p>Contact not found.</p></div>';
	return;
}
$contact       = $profile['contact'];
$identities    = $profile['identities'];
$organisations = $profile['organisations'];
$preferences   = $profile['preferences'];
$interactions  = $profile['interactions'];
$submissions   = $profile['submissions'];
$enquiries     = $profile['enquiries'];
$merges        = $profile['merges'];
$audit         = $profile['audit'];

$base_url = admin_url( 'admin.php?page=wpq-contacts' );

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Feedback query arg is display-only.
$wpq_notice = isset( $_GET['wpq_contact_notice'] ) ? sanitize_key( (string) $_GET['wpq_contact_notice'] ) : '';
?>
<div class="wrap wpq-admin-wrap">
	<p><a href="<?php echo esc_url( $base_url ); ?>">&larr; All contacts</a></p>
	<h1 style="margin-bottom:0;">
		<?php echo esc_html( (string) ( $contact->display_name ?: '(no name)' ) ); ?>
		<code style="font-size:13px;font-weight:normal;">#<?php echo (int) $contact->id; ?> &middot; <?php echo esc_html( (string) $contact->status ); ?></code>
	</h1>
	<p class="description">UUID <code><?php echo esc_html( (string) $contact->uuid ); ?></code>
		&middot; first observed <?php echo esc_html( (string) ( $contact->first_observed_at ?: '—' ) ); ?>
		&middot; last observed <?php echo esc_html( (string) ( $contact->last_observed_at ?: '—' ) ); ?>
		<?php if ( (int) ( $contact->wp_user_id ?? 0 ) > 0 ) : ?>
			&middot; WP user #<?php echo (int) $contact->wp_user_id; ?>
		<?php endif; ?>
	</p>

	<?php if ( 'edited' === $wpq_notice ) : ?>
		<div class="notice notice-success is-dismissible"><p>Contact updated.</p></div>
	<?php elseif ( 'merged' === $wpq_notice ) : ?>
		<div class="notice notice-success is-dismissible"><p>Merge completed.</p></div>
	<?php elseif ( str_contains( $wpq_notice, 'fail' ) && '' !== $wpq_notice ) : ?>
		<div class="notice notice-error is-dismissible"><p>The last action failed or changed nothing.</p></div>
	<?php endif; ?>

	<h2>Canonical profile</h2>
	<p class="description">Edits here change the canonical record only. Historic submission and enquiry snapshots are never rewritten.</p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:640px;">
		<?php wp_nonce_field( 'wpq_edit_contact' ); ?>
		<input type="hidden" name="action" value="wpq_edit_contact">
		<input type="hidden" name="contact_id" value="<?php echo (int) $contact->id; ?>">
		<table class="form-table" role="presentation">
			<tr><th><label for="wpq-c-name">Display name</label></th>
				<td><input type="text" id="wpq-c-name" name="display_name" class="regular-text" value="<?php echo esc_attr( (string) $contact->display_name ); ?>"></td></tr>
			<tr><th><label for="wpq-c-org">Organisation</label></th>
				<td><input type="text" id="wpq-c-org" name="organisation" class="regular-text" value="<?php echo esc_attr( (string) $contact->organisation ); ?>"></td></tr>
			<tr><th><label for="wpq-c-job">Job title</label></th>
				<td><input type="text" id="wpq-c-job" name="job_title" class="regular-text" value="<?php echo esc_attr( (string) ( $contact->job_title ?? '' ) ); ?>"></td></tr>
			<tr><th><label for="wpq-c-reason">Reason for change</label></th>
				<td><input type="text" id="wpq-c-reason" name="reason" class="regular-text" placeholder="Recorded in the audit history"></td></tr>
		</table>
		<p><button type="submit" class="button button-primary">Save canonical profile</button></p>
	</form>

	<h2>Identities</h2>
	<table class="widefat striped" style="max-width:900px;">
		<thead><tr><th>Type</th><th>Value</th><th>Verification</th><th>Primary</th><th>First / last observed</th></tr></thead>
		<tbody>
		<?php foreach ( $identities as $identity ) : ?>
			<tr>
				<td><code><?php echo esc_html( (string) $identity->type ); ?></code></td>
				<td><?php echo esc_html( (string) $identity->value_original ); ?></td>
				<td><code><?php echo esc_html( (string) $identity->verification ); ?></code></td>
				<td><?php echo ! empty( $identity->is_primary ) ? '&#10003;' : ''; ?></td>
				<td style="font-size:12px;color:#666;"><?php echo esc_html( (string) ( $identity->first_observed_at ?: '—' ) . ' / ' . (string) ( $identity->last_observed_at ?: '—' ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p class="description">Verification changes require evidence-backed workflows (email round-trip or administrator review) and are not a checkbox by design.</p>

	<?php if ( ! empty( $organisations ) ) : ?>
	<h2>Organisation relationships</h2>
	<table class="widefat striped" style="max-width:700px;">
		<thead><tr><th>Organisation</th><th>Relationship</th><th>Primary</th><th>Since</th></tr></thead>
		<tbody>
		<?php foreach ( $organisations as $org ) : ?>
			<tr>
				<td><?php echo esc_html( (string) $org->organisation_name ); ?></td>
				<td><?php echo esc_html( (string) $org->relationship ); ?></td>
				<td><?php echo ! empty( $org->is_primary ) ? '&#10003;' : ''; ?></td>
				<td style="font-size:12px;color:#666;"><?php echo esc_html( (string) ( $org->valid_from ?: '—' ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>

	<h2>Communication preferences</h2>
	<?php if ( empty( $preferences ) ) : ?>
		<p class="description">No recorded consent or preference events for this contact.</p>
	<?php else : ?>
	<table class="widefat striped" style="max-width:700px;">
		<thead><tr><th>Purpose</th><th>Current state</th><th>Scope</th><th>Updated</th></tr></thead>
		<tbody>
		<?php foreach ( $preferences as $preference ) : ?>
			<tr>
				<td><code><?php echo esc_html( (string) $preference->purpose ); ?></code></td>
				<td><code><?php echo esc_html( (string) $preference->state ); ?></code></td>
				<td><?php echo (int) $preference->identity_id > 0 ? 'Identity #' . (int) $preference->identity_id : 'Contact-wide'; ?></td>
				<td style="font-size:12px;color:#666;"><?php echo esc_html( (string) $preference->updated_at ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>

	<h2>Interaction timeline</h2>
	<table class="widefat striped" style="max-width:1000px;">
		<thead><tr><th>When</th><th>Type</th><th>Source</th><th>Ref</th><th>Organisation snapshot</th></tr></thead>
		<tbody>
		<?php if ( empty( $interactions ) ) : ?>
			<tr><td colspan="5">No interactions recorded.</td></tr>
		<?php endif; ?>
		<?php foreach ( $interactions as $interaction ) : ?>
			<tr>
				<td><?php echo esc_html( (string) $interaction->occurred_at ); ?></td>
				<td><code><?php echo esc_html( (string) $interaction->interaction_type ); ?></code></td>
				<td><code><?php echo esc_html( (string) $interaction->source_type . ' #' . (int) $interaction->source_id ); ?></code></td>
				<td><?php echo esc_html( (string) $interaction->source_ref ); ?></td>
				<td><?php echo esc_html( (string) $interaction->organisation ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<h2>Questionnaire submissions (<?php echo count( $submissions ); ?>)</h2>
	<table class="widefat striped">
		<thead><tr><th>Ref</th><th>Snapshot (as supplied)</th><th>Score</th><th>Payment</th><th>HaloPSA</th><th>Completed</th></tr></thead>
		<tbody>
		<?php if ( empty( $submissions ) ) : ?>
			<tr><td colspan="6">No linked submissions.</td></tr>
		<?php endif; ?>
		<?php foreach ( $submissions as $submission ) : ?>
			<tr>
				<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-submissions&wpq_action=view&id=' . (int) $submission->id ) ); ?>">
					<?php echo esc_html( (string) $submission->ref ); ?></a></td>
				<td style="font-size:12px;">
					<?php echo esc_html( (string) $submission->contact_name ); ?> &middot;
					<?php echo esc_html( (string) $submission->contact_email ); ?> &middot;
					<?php echo esc_html( (string) ( $submission->contact_company ?? '' ) ); ?>
				</td>
				<td><?php echo esc_html( (string) ( $submission->overall_score ?? '—' ) ); ?></td>
				<td><code><?php echo esc_html( (string) ( $submission->payment_status ?? 'none' ) ); ?></code></td>
				<td>
					<?php if ( ! empty( $submission->halopsa_lead_id ) ) : ?>
						<code>lead <?php echo esc_html( (string) $submission->halopsa_lead_id ); ?></code>
						<span style="color:#666;font-size:11px;">(<?php echo esc_html( (string) ( $submission->halopsa_sync_status ?? '' ) ); ?>)</span>
					<?php else : ?>
						<span style="color:#666;">—</span>
					<?php endif; ?>
				</td>
				<td><?php echo esc_html( (string) ( $submission->completed_at ?: 'in progress' ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<h2>Enquiries (<?php echo count( $enquiries ); ?>)</h2>
	<table class="widefat striped" style="max-width:900px;">
		<thead><tr><th>Ref</th><th>Snapshot (as supplied)</th><th>Status</th><th>Received</th></tr></thead>
		<tbody>
		<?php if ( empty( $enquiries ) ) : ?>
			<tr><td colspan="4">No linked enquiries.</td></tr>
		<?php endif; ?>
		<?php foreach ( $enquiries as $enquiry ) : ?>
			<tr>
				<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-enquiries&view=enquiry&id=' . (int) $enquiry->id ) ); ?>">
					<?php echo esc_html( (string) $enquiry->ref ); ?></a></td>
				<td style="font-size:12px;"><?php echo esc_html( (string) $enquiry->contact_name . ' · ' . (string) $enquiry->contact_email ); ?></td>
				<td><code><?php echo esc_html( (string) $enquiry->status ); ?></code></td>
				<td><?php echo esc_html( (string) $enquiry->created_at ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<h2>Merge</h2>
	<p class="description">Merging repoints every linked record to the surviving contact, applies the most restrictive marketing state, retains all snapshots, and keeps the absorbed record (status "merged") with a recovery note. This cannot be undone from the UI — recovery is administrator-assisted from the merge log.</p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
		onsubmit="return confirm('Merge the entered contact INTO this one? The other contact will be marked merged and all its records repointed here.');"
		style="display:flex;gap:8px;align-items:center;">
		<?php wp_nonce_field( 'wpq_merge_contacts' ); ?>
		<input type="hidden" name="action" value="wpq_merge_contacts">
		<input type="hidden" name="survivor_id" value="<?php echo (int) $contact->id; ?>">
		<label for="wpq-merge-absorbed">Absorb contact ID:</label>
		<input type="number" id="wpq-merge-absorbed" name="absorbed_id" min="1" style="width:100px;" required>
		<input type="text" name="reason" placeholder="Reason (recorded in merge log)" class="regular-text" required>
		<button type="submit" class="button button-primary">Merge into this contact</button>
	</form>

	<?php if ( ! empty( $merges ) ) : ?>
	<h2>Merge history</h2>
	<table class="widefat striped" style="max-width:900px;">
		<thead><tr><th>When</th><th>Survivor</th><th>Absorbed</th><th>Actor</th><th>Reason</th></tr></thead>
		<tbody>
		<?php foreach ( $merges as $merge ) : ?>
			<tr>
				<td><?php echo esc_html( (string) $merge->created_at ); ?></td>
				<td>#<?php echo (int) $merge->survivor_id; ?></td>
				<td>#<?php echo (int) $merge->absorbed_id; ?></td>
				<td><?php echo esc_html( (string) $merge->actor ); ?></td>
				<td style="font-size:12px;"><?php echo esc_html( (string) ( $merge->reason ?? '' ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>

	<?php if ( ! empty( $audit ) ) : ?>
	<h2>Audit history</h2>
	<table class="widefat striped" style="max-width:1000px;">
		<thead><tr><th>When</th><th>Action</th><th>Actor</th><th>Before</th><th>After</th><th>Reason</th></tr></thead>
		<tbody>
		<?php foreach ( $audit as $entry ) : ?>
			<tr>
				<td><?php echo esc_html( (string) $entry->created_at ); ?></td>
				<td><code><?php echo esc_html( (string) $entry->action ); ?></code></td>
				<td><?php echo esc_html( (string) $entry->actor ); ?></td>
				<td style="font-size:11px;font-family:monospace;"><?php echo esc_html( (string) ( $entry->before_summary ?? '' ) ); ?></td>
				<td style="font-size:11px;font-family:monospace;"><?php echo esc_html( (string) ( $entry->after_summary ?? '' ) ); ?></td>
				<td style="font-size:12px;"><?php echo esc_html( (string) ( $entry->reason ?? '' ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>

	<h2>Privacy actions</h2>
	<p class="description">
		Data-subject rights operations (export, anonymise, delete) run from the
		<a href="<?php echo esc_url( add_query_arg( [ 'wpq_view' => 'legacy' ], $base_url ) ); ?>">legacy email view</a>
		against each of this contact's email identities, and now cover the canonical record too.
	</p>
</div>
