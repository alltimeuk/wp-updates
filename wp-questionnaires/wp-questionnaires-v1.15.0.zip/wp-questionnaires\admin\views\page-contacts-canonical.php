<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Canonical contact list + ambiguous-match review queue.
 *
 * @var array<int, object> $contacts
 * @var array<int, object> $pending_reviews
 * @var int                $total
 * @var int                $per_page
 * @var int                $page
 * @var string             $search
 * @var string             $status_filter
 */
$contacts        = $contacts ?? [];
/** @phpstan-ignore-next-line */
$pending_reviews = $pending_reviews ?? [];
/** @phpstan-ignore-next-line */
$total = $total ?? 0;
/** @phpstan-ignore-next-line */
$per_page = $per_page ?? 50;
/** @phpstan-ignore-next-line */
$page = $page ?? 1;
/** @phpstan-ignore-next-line */
$search = $search ?? '';
/** @phpstan-ignore-next-line */
$status_filter = $status_filter ?? '';

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Feedback query args are display-only.
$wpq_notice = isset( $_GET['wpq_contact_notice'] ) ? sanitize_key( (string) $_GET['wpq_contact_notice'] ) : '';
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$total_pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 1;
$base_url    = admin_url( 'admin.php?page=wpq-contacts' );

$notices = [
	'edited'         => 'Contact updated.',
	'edit_failed'    => 'Nothing was changed — blank values never erase canonical data.',
	'merged'         => 'Contacts merged. The absorbed record is retained with status "merged".',
	'merge_failed'   => 'Merge failed — check that both contacts exist and are not already merged.',
	'review_done'    => 'Review candidate resolved.',
	'review_failed'  => 'Review action failed.',
];
?>
<div class="wrap wpq-admin-wrap">
	<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
		<h1 style="margin:0;">Contacts</h1>
		<div style="display:flex;align-items:center;gap:6px;">
			<a href="<?php echo esc_url( add_query_arg( [ 'wpq_view' => 'legacy' ], $base_url ) ); ?>" class="button">Legacy email view</a>
			<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=contacts' ), 'wpq_export_contacts' ) ); ?>" class="button">&#8595; Export all</a>
		</div>
	</div>
	<p class="description">Canonical contact records: one stable identity per person, with identities, interactions and preferences. Historic snapshots on submissions and enquiries are unchanged.</p>

	<?php if ( '' !== $wpq_notice && isset( $notices[ $wpq_notice ] ) ) : ?>
		<div class="notice <?php echo str_contains( $wpq_notice, 'fail' ) ? 'notice-error' : 'notice-success'; ?> is-dismissible"><p><?php echo esc_html( $notices[ $wpq_notice ] ); ?></p></div>
	<?php endif; ?>

	<?php if ( ! empty( $pending_reviews ) ) : ?>
	<div style="border:1px solid #dba617;background:#fff8e5;border-radius:4px;padding:12px 16px;margin:16px 0;">
		<h2 style="margin:0 0 8px;font-size:14px;">Ambiguous match candidates (<?php echo count( $pending_reviews ); ?>)</h2>
		<p class="description" style="margin:0 0 10px;">These records could not be linked automatically. Review each and choose an action — nothing is merged without your decision.</p>
		<table class="widefat striped">
			<thead><tr><th>Source</th><th>Reason</th><th>Details</th><th>Candidate contacts</th><th>Action</th></tr></thead>
			<tbody>
			<?php foreach ( $pending_reviews as $review ) :
				$details    = json_decode( (string) ( $review->details ?? '' ), true ) ?: [];
				$candidates = array_map( 'intval', array_filter( explode( ',', (string) $review->candidate_contact_ids ) ) );
			?>
				<tr>
					<td><code><?php echo esc_html( (string) $review->source_type . ' #' . (int) $review->source_id ); ?></code><br>
						<span style="color:#666;font-size:11px;"><?php echo esc_html( (string) $review->created_at ); ?></span></td>
					<td><code><?php echo esc_html( (string) $review->reason ); ?></code></td>
					<td style="font-size:12px;">
						<?php echo esc_html( (string) ( $details['submitted_name'] ?? '' ) ); ?><br>
						<span style="color:#666;"><?php echo esc_html( (string) ( $details['email'] ?? '' ) ); ?></span>
					</td>
					<td>
						<?php foreach ( $candidates as $cid ) : ?>
							<a href="<?php echo esc_url( add_query_arg( [ 'wpq_action' => 'cview', 'contact_id' => $cid ], $base_url ) ); ?>">#<?php echo (int) $cid; ?></a>
						<?php endforeach; ?>
					</td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;align-items:center;flex-wrap:wrap;">
							<?php wp_nonce_field( 'wpq_resolve_contact_review' ); ?>
							<input type="hidden" name="action" value="wpq_resolve_contact_review">
							<input type="hidden" name="review_id" value="<?php echo (int) $review->id; ?>">
							<select name="resolution">
								<option value="create_separate_contact">Keep separate (confirm)</option>
								<option value="mark_shared_identity">Shared mailbox — keep separate</option>
								<option value="link_to_existing">Link into contact ID&hellip;</option>
								<option value="defer">Defer</option>
								<option value="ignore_with_reason">Ignore</option>
							</select>
							<input type="number" name="target_contact_id" placeholder="Target ID" style="width:80px;" min="1">
							<input type="text" name="reason" placeholder="Reason" style="width:120px;">
							<button type="submit" class="button button-small">Apply</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endif; ?>

	<form method="get" style="margin:16px 0 8px;display:flex;gap:8px;align-items:center;">
		<input type="hidden" name="page" value="wpq-contacts">
		<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search name, organisation or email&hellip;" class="regular-text">
		<select name="status">
			<option value="">Any status</option>
			<?php foreach ( [ 'provisional', 'active', 'restricted', 'suppressed', 'anonymised' ] as $status_option ) : ?>
				<option value="<?php echo esc_attr( $status_option ); ?>" <?php selected( $status_filter, $status_option ); ?>><?php echo esc_html( ucfirst( $status_option ) ); ?></option>
			<?php endforeach; ?>
		</select>
		<button type="submit" class="button">Filter</button>
		<?php if ( $search || $status_filter ) : ?>
			<a href="<?php echo esc_url( $base_url ); ?>" class="button">Clear</a>
		<?php endif; ?>
		<span class="description" style="margin-left:8px;"><?php echo esc_html( number_format( $total ) ); ?> contact<?php echo 1 !== $total ? 's' : ''; ?></span>
	</form>

	<table class="widefat striped">
		<thead>
			<tr>
				<th>Contact</th><th>Primary email</th><th>Organisation</th><th>Status</th>
				<th>Questionnaires</th><th>Enquiries</th><th>Last interaction</th><th>Marketing</th><th></th>
			</tr>
		</thead>
		<tbody>
		<?php if ( empty( $contacts ) ) : ?>
			<tr><td colspan="9">No canonical contacts yet. Run the historic migration from the Readiness screen, or wait for new submissions and enquiries to arrive.</td></tr>
		<?php endif; ?>
		<?php foreach ( $contacts as $contact ) : ?>
			<tr>
				<td>
					<a href="<?php echo esc_url( add_query_arg( [ 'wpq_action' => 'cview', 'contact_id' => (int) $contact->id ], $base_url ) ); ?>">
						<strong><?php echo esc_html( (string) ( $contact->display_name ?: '(no name)' ) ); ?></strong>
					</a>
					<?php if ( (int) ( $contact->pending_review_count ?? 0 ) > 0 ) : ?>
						<span title="This contact appears in a pending review candidate" style="color:#dba617;">&#9888;</span>
					<?php endif; ?>
				</td>
				<td>
					<?php echo esc_html( (string) ( $contact->primary_email ?? '' ) ); ?>
					<?php if ( 'verified' === (string) ( $contact->primary_email_verification ?? '' ) ) : ?>
						<span title="Verified" style="color:#00a32a;">&#10003;</span>
					<?php endif; ?>
				</td>
				<td><?php echo esc_html( (string) ( $contact->organisation ?? '' ) ); ?></td>
				<td><code><?php echo esc_html( (string) $contact->status ); ?></code></td>
				<td><?php echo (int) ( $contact->submission_count ?? 0 ); ?></td>
				<td><?php echo (int) ( $contact->enquiry_count ?? 0 ); ?></td>
				<td><?php echo esc_html( (string) ( $contact->last_interaction_at ?: '—' ) ); ?></td>
				<td><code><?php echo esc_html( (string) ( $contact->marketing_state ?: 'unknown' ) ); ?></code></td>
				<td><a class="button button-small" href="<?php echo esc_url( add_query_arg( [ 'wpq_action' => 'cview', 'contact_id' => (int) $contact->id ], $base_url ) ); ?>">View</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<?php if ( $total_pages > 1 ) : ?>
		<div class="tablenav"><div class="tablenav-pages">
			<?php echo wp_kses_post( paginate_links( [
				'base'    => add_query_arg( [ 'paged' => '%#%', 's' => $search, 'status' => $status_filter ], $base_url ),
				'format'  => '',
				'current' => $page,
				'total'   => $total_pages,
			] ) ?: '' ); ?>
		</div></div>
	<?php endif; ?>
</div>
