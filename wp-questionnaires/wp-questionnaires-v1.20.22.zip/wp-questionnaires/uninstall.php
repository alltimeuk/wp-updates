<?php
// Runs when the plugin is deleted from WP Admin → Plugins.

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Always clean up rate-limit transients (runtime artefacts, no business value).
// WordPress has no efficient wildcard transient deletion API; these prefixes are
// plugin-owned and never include user input.
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Plugin-owned wildcard transient cleanup.
$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '_transient_wpq_rl_%'
	    OR option_name LIKE '_transient_timeout_wpq_rl_%'"
);

// The custom role is always removed on uninstall — it is a plugin artefact and
// grants no access without the plugin present. Data tables are preserved unless
// the admin has explicitly opted in to destructive deletion.
remove_role( 'wpq_halopsa' );

// Only drop tables and remove settings when the admin has explicitly opted in.
// Default is off so that accidentally deleting the plugin does not destroy lead
// records, assessment data, and reporting history.
if ( get_option( 'wpq_delete_data_on_uninstall' ) !== 'yes' ) {
	return;
}

// Remove questionnaire-specific Claude template attachments only when the admin
// opted in to full data deletion. Attachment IDs are internal plugin metadata.
if ( function_exists( 'wp_delete_attachment' ) ) {
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Internal plugin table name.
	$template_ids = $wpdb->get_col( "SELECT claude_template_attachment_id FROM {$wpdb->prefix}wpq_questionnaires WHERE claude_template_attachment_id IS NOT NULL" );
	foreach ( array_filter( array_map( 'intval', (array) $template_ids ) ) as $attachment_id ) {
		wp_delete_attachment( $attachment_id, true );
	}
}

// Remove generated Questionnaire Report DOCX/PDF artefacts. These live under
// the uploads directory rather than the database, so uninstall must delete
// them explicitly when the admin has opted in to full data deletion.
if ( function_exists( 'wp_upload_dir' ) ) {
	$wpq_upload = wp_upload_dir();
	if ( is_array( $wpq_upload ) && empty( $wpq_upload['error'] ) && ! empty( $wpq_upload['basedir'] ) ) {
		$wpq_reports_dir = rtrim( (string) $wpq_upload['basedir'], '/\\' ) . DIRECTORY_SEPARATOR . 'wp-questionnaires' . DIRECTORY_SEPARATOR . 'questionnaire-reports';
		$wpq_remove_dir  = static function ( string $dir ) use ( &$wpq_remove_dir ): void {
			if ( ! is_dir( $dir ) ) {
				return;
			}
			foreach ( (array) @scandir( $dir ) as $item ) {
				if ( '.' === $item || '..' === $item ) {
					continue;
				}
				$path = $dir . DIRECTORY_SEPARATOR . $item;
				is_dir( $path ) ? $wpq_remove_dir( $path ) : wp_delete_file( $path );
			}
			@rmdir( $dir );
		};
		$wpq_remove_dir( $wpq_reports_dir );
	}
}

$tables = [
	// Fixed internal allow-list only. Never add user-controlled table names here.
	'wpq_contact_match_review',
	'wpq_contact_audit',
	'wpq_contact_merge_log',
	'wpq_contact_preferences_current',
	'wpq_contact_consent_events',
	'wpq_contact_interactions',
	'wpq_contact_organisations',
	'wpq_contact_identities',
	'wpq_contacts',
	'wpq_enquiries',
	'wpq_enquiry_forms',
	'wpq_question_control_mappings',
	'wpq_framework_controls',
	'wpq_frameworks',
	'wpq_report_tokens',
	'wpq_payment_events',
	'wpq_payment_sessions',
	'wpq_submissions',
	'wpq_products',
	'wpq_ctas',
	'wpq_grade_thresholds',
	'wpq_questions',
	'wpq_domains',
	'wpq_questionnaires',
];

foreach ( $tables as $table ) {
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names come from the internal uninstall allow-list above.
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" );
}

delete_option( 'wpq_db_version' );
delete_option( 'wpq_delete_data_on_uninstall' );
delete_option( 'wpq_stripe_publishable_key' );
delete_option( 'wpq_stripe_secret_key' );
delete_option( 'wpq_stripe_webhook_secret' );
delete_option( 'wpq_checkout_enabled' );
delete_option( 'wpq_claude_api_key' );
delete_option( 'wpq_claude_model' );
delete_option( 'wpq_claude_project_id' );
delete_option( 'wpq_claude_debug_enabled' );
delete_option( 'wpq_claude_debug_log' );
delete_option( 'wpq_remediation_plan_enabled' );
delete_option( 'wpq_questionnaire_report_enabled' );
delete_option( 'wpq_questionnaire_report_renderer_mode' );
delete_option( 'wpq_questionnaire_report_html_fallback' );
delete_option( 'wpq_docx_pdf_converter_path' );
delete_option( 'wpq_docx_pdf_converter_timeout' );

// Phase 1 legacy options — may exist on sites that ran an earlier build.
delete_option( 'wpq_halopsa_api_url' );
delete_option( 'wpq_halopsa_client_id' );
delete_option( 'wpq_halopsa_client_secret' );
delete_option( 'wpq_halopsa_prospect_type' );
delete_option( 'wpq_halopsa_field_score' );
delete_option( 'wpq_halopsa_field_grade' );
delete_option( 'wpq_halopsa_field_ref' );
delete_option( 'wpq_halopsa_field_status' );
