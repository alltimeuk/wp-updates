<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Populates the questionnaire-specific Questionnaire Report .docx template.
 *
 * Placeholder contract (documented in README.md):
 *
 *  Scalars:   {{questionnaire.name}} {{questionnaire.ref}} {{customer.name}}
 *             {{customer.company}} {{assessment.score}} {{assessment.grade}}
 *             {{assessment.verdict}} {{assessment.completed_at}}
 *             {{assessment.domains_count}} {{assessment.questions_count}}
 *             {{report.reference}} {{report.generated_at}}
 *             {{report.title}} {{report.executive_summary}}
 *             {{report.overall_assessment}} {{report.conclusion}}
 *             {{counts.critical}} {{counts.high}} {{counts.medium}}
 *               {{counts.low}} {{counts.total}}
 *
 *  Repeating blocks (open/close markers around the row content to repeat):
 *             {{strengths}} ... {{strength.title}} {{strength.detail}}
 *               {{strength.evidence_refs}} ... {{/strengths}}
 *             {{priority_findings}} ... {{finding.id}} {{finding.priority}}
 *               {{finding.domain}} {{finding.title}} {{finding.finding}}
 *               {{finding.business_impact}} {{finding.recommendation}}
 *               {{finding.evidence_refs}} ... {{/priority_findings}}
 *             {{domain_assessments}} ... {{domain.name}} {{domain.score}}
 *               {{domain.maximum_score}} {{domain.percent}} {{domain.summary}}
 *               {{domain.strengths}} {{domain.concerns}}
 *               {{domain.recommendations}} ... {{/domain_assessments}}
 *             {{recommended_next_steps}} ... {{step.sequence}} {{step.timeframe}}
 *               {{step.action}} {{step.reason}} {{step.owner_type}} ... {{/recommended_next_steps}}
 *             {{limitations}} ... {{limitation.text}} ... {{/limitations}}
 *             {{frameworks}} ... {{framework.name}} {{framework.readiness}}
 *               {{framework.percent}} {{framework.summary}}
 *               {{framework.strengths}} {{framework.gaps}}
 *               {{framework.recommendations}} ... {{/frameworks}}
 *
 *  Images (optional): {{framework_radar}} — replaced with the framework
 *             readiness radar PNG when the questionnaire has assessed
 *             frameworks; blanked otherwise.
 *
 * Uses PhpOffice\PhpWord's TemplateProcessor, which fixes runs that Word has
 * split a `{{...}}` placeholder across before scanning for macros, so
 * placeholder text does not need to survive as a single unbroken text run.
 */
class WPQ_Docx_Template_Renderer {

	private const MACRO_OPEN  = '{{';
	private const MACRO_CLOSE = '}}';

	public const REQUIRED_SCALARS = [
		'questionnaire.name',
		'questionnaire.ref',
		'customer.name',
		'assessment.score',
		'assessment.grade',
		'report.title',
		'report.executive_summary',
		'report.overall_assessment',
		'report.conclusion',
	];

	/**
	 * Only the placeholders a report is meaningless without are required. Newer
	 * additions (counts.*, report.reference, assessment.*_count, domain.percent,
	 * finding.id) stay optional so templates authored against an earlier contract
	 * keep validating — an author adopts them by adding them to the template.
	 */
	public const REQUIRED_BLOCKS = [ 'priority_findings', 'domain_assessments' ];
	public const OPTIONAL_BLOCKS = [ 'strengths', 'recommended_next_steps', 'limitations', 'frameworks' ];

	public static function library_available(): bool {
		return class_exists( '\PhpOffice\PhpWord\TemplateProcessor' );
	}

	/**
	 * @return array{valid: bool, errors: array<int,string>, variables: array<int,string>, missing_required_scalars: array<int,string>, missing_required_blocks: array<int,string>}
	 */
	public static function validate_template( string $path ): array {
		$errors = [];

		if ( '' === $path || ! is_readable( $path ) ) {
			$errors[] = 'Template file is missing or unreadable.';
		} elseif ( strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) !== 'docx' ) {
			$errors[] = 'Template must be a .docx file.';
		}

		if ( empty( $errors ) && class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( $zip->open( $path ) !== true ) {
				$errors[] = 'Template is not a valid ZIP/DOCX archive.';
			} else {
				if ( $zip->locateName( 'word/document.xml' ) === false ) {
					$errors[] = 'Template is missing the word/document.xml package part.';
				}
				if ( $zip->locateName( '[Content_Types].xml' ) === false ) {
					$errors[] = 'Template is missing the [Content_Types].xml package part.';
				}
				$zip->close();
			}
		} elseif ( empty( $errors ) && ! class_exists( 'ZipArchive' ) ) {
			$errors[] = 'ZipArchive is not available to validate the template.';
		}

		if ( ! empty( $errors ) ) {
			return [
				'valid'                    => false,
				'errors'                   => $errors,
				'variables'                => [],
				'missing_required_scalars' => self::REQUIRED_SCALARS,
				'missing_required_blocks'  => self::REQUIRED_BLOCKS,
			];
		}

		if ( ! self::library_available() ) {
			$errors[] = 'The PHPWord library is not available.';
			return [
				'valid'                    => false,
				'errors'                   => $errors,
				'variables'                => [],
				'missing_required_scalars' => self::REQUIRED_SCALARS,
				'missing_required_blocks'  => self::REQUIRED_BLOCKS,
			];
		}

		try {
			$processor = new \PhpOffice\PhpWord\TemplateProcessor( $path );
			$processor->setMacroChars( self::MACRO_OPEN, self::MACRO_CLOSE );
			$variables = $processor->getVariables();
		} catch ( Throwable $e ) {
			return [
				'valid'                    => false,
				'errors'                   => [ 'Could not parse the template: ' . $e->getMessage() ],
				'variables'                => [],
				'missing_required_scalars' => self::REQUIRED_SCALARS,
				'missing_required_blocks'  => self::REQUIRED_BLOCKS,
			];
		}

		$missing_scalars = array_values( array_diff( self::REQUIRED_SCALARS, $variables ) );
		$missing_blocks  = [];
		foreach ( self::REQUIRED_BLOCKS as $block ) {
			if ( ! in_array( $block, $variables, true ) || ! in_array( '/' . $block, $variables, true ) ) {
				$missing_blocks[] = $block;
			}
		}

		if ( ! empty( $missing_scalars ) ) {
			$errors[] = 'Template is missing required placeholders: ' . implode( ', ', $missing_scalars );
		}
		if ( ! empty( $missing_blocks ) ) {
			$errors[] = 'Template is missing required repeating sections: ' . implode( ', ', $missing_blocks );
		}

		return [
			'valid'                    => empty( $errors ),
			'errors'                   => $errors,
			'variables'                => $variables,
			'missing_required_scalars' => $missing_scalars,
			'missing_required_blocks'  => $missing_blocks,
		];
	}

	/**
	 * @param array<string, string> $scalars
	 * @param array<string, array<int, array<string, string>>> $blocks
	 * @param array<string, array{path: string, width?: int, height?: int, ratio?: bool}> $images
	 *        Optional image macros ({{framework_radar}}); each is applied only
	 *        when the template actually contains the macro, so templates
	 *        authored before an image existed keep rendering unchanged.
	 */
	public static function render( string $template_path, array $scalars, array $blocks, array $images = [] ): string {
		if ( ! self::library_available() ) {
			throw new RuntimeException( 'The PHPWord library is not available.' );
		}

		// Untrusted content (contact details, free-text answers, Claude output) must be
		// XML-escaped before insertion — PHPWord defaults this off for legacy reasons.
		\PhpOffice\PhpWord\Settings::setOutputEscapingEnabled( true );

		$processor = new \PhpOffice\PhpWord\TemplateProcessor( $template_path );
		$processor->setMacroChars( self::MACRO_OPEN, self::MACRO_CLOSE );

		foreach ( $scalars as $name => $value ) {
			$processor->setValue( $name, self::sanitise_scalar( (string) $value ) );
		}

		if ( ! empty( $images ) ) {
			$template_variables = $processor->getVariables();
			foreach ( $images as $name => $image ) {
				if ( ! in_array( $name, $template_variables, true ) ) {
					continue;
				}
				$path = (string) ( $image['path'] ?? '' );
				if ( '' === $path || ! is_readable( $path ) ) {
					// The macro is present but the image could not be produced
					// (e.g. GD missing): blank it so no literal {{...}} ships.
					$processor->setValue( $name, '' );
					continue;
				}
				try {
					$processor->setImageValue( $name, [
						'path'   => $path,
						'width'  => (int) ( $image['width'] ?? 480 ),
						'height' => (int) ( $image['height'] ?? 0 ) ?: null,
						'ratio'  => (bool) ( $image['ratio'] ?? true ),
					] );
				} catch ( Throwable $e ) {
					$processor->setValue( $name, '' );
				}
			}
		}

		foreach ( array_merge( self::REQUIRED_BLOCKS, self::OPTIONAL_BLOCKS ) as $block_name ) {
			$rows = $blocks[ $block_name ] ?? [];
			$rows = is_array( $rows ) ? array_values( $rows ) : [];

			if ( empty( $rows ) ) {
				try {
					$processor->cloneBlock( $block_name, 0, true );
				} catch ( Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Block marker absent from an optional section; nothing to clean up.
					unset( $e );
				}
				continue;
			}

			$replacements = array_map(
				static function ( array $row ): array {
					$clean = [];
					foreach ( $row as $key => $value ) {
						$clean[ (string) $key ] = self::sanitise_scalar( (string) $value );
					}
					return $clean;
				},
				$rows
			);

			try {
				$processor->cloneBlock( $block_name, count( $replacements ), true, false, $replacements );
			} catch ( Throwable $e ) {
				throw new RuntimeException( 'Could not populate a repeating section of the questionnaire report template.' );
			}
		}

		$temp_path = $processor->save();
		if ( ! is_string( $temp_path ) || ! is_readable( $temp_path ) ) {
			throw new RuntimeException( 'Could not render the populated DOCX.' );
		}

		$binary = file_get_contents( $temp_path );
		wp_delete_file( $temp_path );

		if ( ! is_string( $binary ) || '' === $binary ) {
			throw new RuntimeException( 'Rendered DOCX was empty.' );
		}

		if ( ! self::looks_like_docx( $binary ) ) {
			throw new RuntimeException( 'Rendered output failed DOCX validation.' );
		}

		return $binary;
	}

	public static function looks_like_docx( string $binary ): bool {
		return str_starts_with( $binary, "PK\x03\x04" );
	}

	private static function sanitise_scalar( string $value ): string {
		return str_replace( [ "\r\n", "\r" ], "\n", $value );
	}
}
