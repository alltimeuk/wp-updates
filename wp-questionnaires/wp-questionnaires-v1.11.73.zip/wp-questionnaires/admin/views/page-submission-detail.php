<?php if ( ! defined( 'ABSPATH' ) ) exit;
// $submission is set by the page_submissions() dispatcher.
/** @var object $submission */

$answers       = $submission->answers_json       ? json_decode( $submission->answers_json,       true ) : [];
$domain_scores = $submission->domain_scores_json ? json_decode( $submission->domain_scores_json, true ) : [];
$findings      = $submission->findings_json      ? json_decode( $submission->findings_json,      true ) : [];
$payment_session = ! empty( $submission->stripe_session_id ) ? WPQ_Database::get_payment_session( (string) $submission->stripe_session_id ) : null;
$purchased_product = ! empty( $submission->product_id ) ? WPQ_Database::get_product_admin( (int) $submission->product_id ) : null;
$latest_payment_event = WPQ_Database::get_latest_payment_event_for_submission( (int) $submission->id );
$report_tokens = WPQ_Database::get_report_tokens_for_submission( (int) $submission->id );

// Load questionnaire structure for per-question breakdown and grade display.
$q_structure   = [];
$q_thresholds  = [];
$q_grade_match = null;
if ( ! empty( $submission->questionnaire_id ) ) {
	$q_struct_data = WPQ_Database::get_questionnaire_structure( (int) $submission->questionnaire_id );
	$q_structure   = $q_struct_data['domains']    ?? [];
	$q_thresholds  = $q_struct_data['thresholds'] ?? [];
}
foreach ( $q_thresholds as $qt ) {
	if ( ( $qt['grade_id'] ?? '' ) === ( $submission->grade_id ?? '' ) ) {
		$q_grade_match = $qt;
		break;
	}
}

// Answer display helper — returns human-readable label for a raw answer.
$wpq_fmt_answer = function ( $raw, array $q ): string {
	if ( $raw === null || $raw === '' ) return '—';
	$type = $q['question_type'] ?? 'tri_state';
	if ( $type === 'tri_state' ) {
		return match ( $raw ) { 'yes' => 'Yes', 'partial' => 'Partial', 'no' => 'No', default => (string) $raw };
	}
	if ( $type === 'boolean' ) {
		return $raw === 'yes' ? 'Yes' : 'No';
	}
	if ( in_array( $type, [ 'select', 'radio' ], true ) ) {
		foreach ( $q['options'] ?? [] as $opt ) {
			if ( ( $opt['key'] ?? '' ) === $raw ) return (string) ( $opt['label'] ?? $raw );
		}
		return (string) $raw;
	}
	if ( $type === 'checkbox' ) {
		$sel  = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
		$lbls = [];
		if ( is_array( $sel ) ) {
			foreach ( $sel as $sk ) {
				foreach ( $q['options'] ?? [] as $opt ) {
					if ( ( $opt['key'] ?? '' ) !== $sk ) {
						continue;
					}
					$lbls[] = (string) ( $opt['label'] ?? $sk );
					break;
				}
			}
		}
		return $lbls ? implode( ', ', $lbls ) : (string) $raw;
	}
	$s = (string) $raw;
	return mb_strlen( $s ) > 80 ? mb_substr( $s, 0, 77 ) . '…' : $s;
};

$list_url = admin_url( 'admin.php?page=wpq-submissions' );
$delete_url = wp_nonce_url(
	admin_url( 'admin.php?page=wpq-submissions&wpq_action=delete_submission&id=' . (int) $submission->id ),
	'wpq_delete_submission'
);
?>
<div class="wrap wpq-admin-wrap">
  <h1 class="wp-heading-inline">Submission: <?php echo esc_html( $submission->ref ); ?></h1>
  <a href="<?php echo esc_url( $list_url ); ?>" class="page-title-action">← Back to list</a>
  <hr class="wp-header-end">

  <div class="wpq-detail-grid">

    <!-- ===== Left column ===== -->
    <div>

      <!-- Contact -->
      <div class="wpq-card">
        <h3 style="margin:0 0 12px;">Contact</h3>
        <table class="widefat striped" style="max-width:600px;">
          <tbody>
            <tr><th style="width:160px;">Name</th><td><?php echo esc_html( $submission->contact_name ); ?></td></tr>
            <tr><th>Email</th><td><a href="mailto:<?php echo esc_attr( $submission->contact_email ); ?>"><?php echo esc_html( $submission->contact_email ); ?></a></td></tr>
            <tr><th>Company</th><td><?php echo esc_html( $submission->contact_company ); ?></td></tr>
            <?php if ( $submission->contact_phone ) : ?>
            <tr><th>Phone</th><td><?php echo esc_html( $submission->contact_phone ); ?></td></tr>
            <?php endif; ?>
            <tr><th>IP Address</th><td><?php echo esc_html( $submission->ip_address ?? '—' ); ?></td></tr>
          </tbody>
        </table>
      </div>

      <!-- Domain scores -->
      <?php if ( ! empty( $domain_scores ) ) : ?>
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Domain Scores</h3>
        <table class="widefat striped">
          <thead><tr><th>Domain</th><th style="width:80px;">Score</th><th style="width:80px;">%</th></tr></thead>
          <tbody>
          <?php foreach ( $domain_scores as $di => $ds ) : ?>
            <tr>
              <td><?php echo esc_html( $ds['name'] ?? $ds['slug'] ?? '' ); ?></td>
              <td><?php echo esc_html( ( $ds['score'] ?? '—' ) . ' / ' . ( $ds['max'] ?? '—' ) ); ?></td>
              <td><?php echo isset( $ds['pct'] ) ? esc_html( $ds['pct'] ) . '%' : '—'; ?></td>
            </tr>
            <?php if ( ! empty( $q_structure[ $di ]['questions'] ) ) : ?>
            <tr>
              <td colspan="3" style="padding:0 0 6px 0;background:transparent;">
                <details style="padding:0 8px;">
                  <summary style="cursor:pointer;padding:6px 0;color:#0073aa;font-size:0.8em;list-style:none;user-select:none;">
                    &#9656; <?php echo count( $q_structure[ $di ]['questions'] ); ?> question<?php echo count( $q_structure[ $di ]['questions'] ) !== 1 ? 's' : ''; ?>
                  </summary>
                  <table style="width:100%;border-collapse:collapse;font-size:0.8em;margin:4px 0 8px;">
                    <thead>
                      <tr style="background:#f9f9f9;">
                        <th style="width:52px;padding:4px 8px;text-align:left;border-bottom:1px solid #e0e0e0;font-weight:600;">Ref</th>
                        <th style="padding:4px 8px;text-align:left;border-bottom:1px solid #e0e0e0;font-weight:600;">Question</th>
                        <th style="width:180px;padding:4px 8px;text-align:left;border-bottom:1px solid #e0e0e0;font-weight:600;">Answer</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ( $q_structure[ $di ]['questions'] as $qi => $q ) :
                        $raw_ans  = $answers[ "{$di}_{$qi}" ] ?? null;
                        $mode     = $q['scoring_mode'] ?? '';
                        $is_ns    = $mode === 'non_scoring';
                        $ans_lbl  = $wpq_fmt_answer( $raw_ans, $q );
                        $ans_col  = '';
                        if ( ! $is_ns && $raw_ans !== null ) {
                          if ( in_array( $mode, [ 'legacy_tri_state', 'boolean' ], true ) ) {
                            if ( $raw_ans === 'yes' )     $ans_col = '#1a5e35';
                            elseif ( $raw_ans === 'no' )  $ans_col = '#c0392b';
                            elseif ( $raw_ans === 'partial' ) $ans_col = '#c87c00';
                          } elseif ( $mode === 'reverse_boolean' ) {
                            $ans_col = $raw_ans === 'yes' ? '#c0392b' : '#1a5e35';
                          }
                        }
                      ?>
                      <tr style="border-bottom:1px solid #f5f5f5;">
                        <td style="padding:4px 8px;color:#888;font-family:monospace;white-space:nowrap;"><?php echo esc_html( $q['question_ref'] ?? "{$di}.{$qi}" ); ?></td>
                        <td style="padding:4px 8px;<?php echo $is_ns ? 'color:#aaa;' : ''; ?>"><?php echo esc_html( $q['question'] ); ?></td>
                        <td style="padding:4px 8px;">
                          <?php if ( $raw_ans === null ) : ?>
                            <span style="color:#bbb;">—</span>
                          <?php else : ?>
                            <span style="<?php echo $ans_col ? 'color:' . esc_attr( $ans_col ) . ';font-weight:600;' : ''; ?><?php echo $is_ns ? 'color:#888;' : ''; ?>"><?php echo esc_html( $ans_lbl ); ?></span>
                          <?php endif; ?>
                        </td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </details>
              </td>
            </tr>
            <?php endif; ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>

      <!-- Findings -->
      <?php if ( ! empty( $findings ) ) : ?>
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Findings</h3>
        <table class="widefat striped">
          <thead><tr><th>Priority</th><th>Domain</th><th>Action</th></tr></thead>
          <tbody>
          <?php foreach ( $findings as $f ) : ?>
            <tr>
              <td><?php echo esc_html( ucfirst( $f['priority'] ?? '' ) ); ?></td>
              <td><?php echo esc_html( $f['domain'] ?? '' ); ?></td>
              <td><?php echo esc_html( $f['action'] ?? '' ); ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>

    </div>

    <!-- ===== Right column ===== -->
    <div>

      <!-- Meta -->
      <div class="wpq-card">
        <h3 style="margin:0 0 12px;">Details</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Status</th>
              <td><?php
                $ab = (int) $submission->abandoned;
                if ( $ab === 0 )      echo '<span class="wpq-status-completed">&#10003; Completed</span>';
                elseif ( $ab === 2 )  echo '<span class="wpq-status-deleted">&#128465; Deleted (soft)</span>';
                else                  echo '<span class="wpq-status-partial">&#8987; Partial</span>';
              ?></td>
            </tr>
            <tr><th>Started</th><td><?php echo $submission->started_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $submission->started_at ) ) ) : '—'; ?></td></tr>
            <tr><th>Completed</th><td><?php echo $submission->completed_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $submission->completed_at ) ) ) : '—'; ?></td></tr>
            <tr><th>Duration</th><td><?php echo $submission->duration_seconds !== null ? esc_html( gmdate( 'i\m s\s', (int) $submission->duration_seconds ) ) : '—'; ?></td></tr>
            <?php if ( $submission->last_question_answered ) : ?>
            <tr><th>Last Q answered</th><td><?php echo esc_html( $submission->last_question_answered ); ?></td></tr>
            <?php endif; ?>
            <?php if ( $submission->overall_score !== null ) : ?>
            <tr>
              <th>Result</th>
              <td>
                <span style="font-size:1.1em;font-weight:700;"><?php echo (int) $submission->overall_score; ?></span><span style="color:#888;font-size:0.85em;">&thinsp;/&thinsp;100</span>
                <?php if ( $q_grade_match ) : ?>
                  <span style="display:inline-block;background:<?php echo esc_attr( $q_grade_match['bg'] ); ?>;color:<?php echo esc_attr( $q_grade_match['color'] ); ?>;padding:2px 10px;border-radius:10px;font-weight:700;font-size:0.85em;margin-left:8px;">
                    <?php echo esc_html( $q_grade_match['grade_label'] ); ?>
                  </span>
                  <span style="font-size:0.8em;color:#888;margin-left:4px;"><?php echo esc_html( $q_grade_match['verdict'] ); ?></span>
                <?php elseif ( $submission->grade_id ) : ?>
                  <span style="display:inline-block;background:#f5f5f5;color:#333;padding:2px 10px;border-radius:10px;font-weight:700;font-size:0.85em;margin-left:8px;"><?php echo esc_html( $submission->grade_id ); ?></span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- HaloPSA -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">HaloPSA Sync</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Status</th>
              <td><?php
                $sync_map = [
                  'synced'        => '<span class="wpq-status-completed">&#10003; Synced</span>',
                  'pending'       => '<span class="wpq-status-partial">&#8987; Pending</span>',
                  'processing'    => '<span style="color:#0073aa;">&#8635; Processing</span>',
                  'failed'        => '<span style="color:#e84855;">&#10007; Failed</span>',
                  'retry_pending' => '<span style="color:#d63638;">&#8635; Retry pending</span>',
                  'ignored'       => '<span class="wpq-status-inactive">&#8212; Ignored</span>',
                  'manual_review' => '<span style="color:#dba617;">&#9888; Manual review</span>',
                  'skipped'       => '<span class="wpq-status-inactive">&#8212; Skipped</span>',
                ];
                echo wp_kses_post( $sync_map[ $submission->halopsa_sync_status ?? 'pending' ] ?? esc_html( $submission->halopsa_sync_status ) );
              ?></td>
            </tr>
            <?php if ( $submission->halopsa_lead_id ) : ?>
            <tr><th>HaloPSA ID</th><td><?php echo esc_html( $submission->halopsa_lead_id ); ?></td></tr>
            <?php endif; ?>
            <?php if ( $submission->halopsa_synced_at ) : ?>
            <tr><th>Synced at</th><td><?php echo esc_html( wp_date( 'd M Y H:i', strtotime( $submission->halopsa_synced_at ) ) ); ?></td></tr>
            <?php endif; ?>
            <?php if ( ! empty( $submission->halopsa_last_attempted_at ) ) : ?>
            <tr><th>Last attempt</th><td><?php echo esc_html( wp_date( 'd M Y H:i', strtotime( $submission->halopsa_last_attempted_at ) ) ); ?></td></tr>
            <?php endif; ?>
            <?php if ( ! empty( $submission->halopsa_retry_count ) ) : ?>
            <tr><th>Retry count</th><td><?php echo esc_html( (string) (int) $submission->halopsa_retry_count ); ?></td></tr>
            <?php endif; ?>
            <?php if ( ! empty( $submission->halopsa_sync_error ) ) : ?>
            <tr><th>Last sync error</th><td style="color:#d63638;word-break:break-word;"><?php echo esc_html( $submission->halopsa_sync_error ); ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Claude -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Claude Analysis</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Provider mode</th><td><?php echo esc_html( $submission->claude_provider_mode ?: 'not configured' ); ?></td></tr>
            <tr><th>Status</th><td><?php echo esc_html( $submission->claude_status ?? 'not_started' ); ?></td></tr>
            <tr><th>Project name</th><td><?php echo esc_html( $submission->questionnaire_claude_project_name ?: '—' ); ?></td></tr>
            <tr>
              <th>Project ID</th>
              <td style="word-break:break-all;">
                <?php echo esc_html( $submission->claude_project_id ?: '—' ); ?>
                <?php
                $submission_project_link = class_exists( 'WPQ_Claude' ) ? WPQ_Claude::project_url( (object) [ 'claude_project_url' => $submission->questionnaire_claude_project_url ?? '' ] ) : '';
                if ( '' !== $submission_project_link ) :
                ?>
                  <br><a href="<?php echo esc_url( $submission_project_link ); ?>" target="_blank" rel="noopener noreferrer">Open configured Claude project</a>
                <?php endif; ?>
              </td>
            </tr>
            <tr><th>Conversation title</th><td><?php echo esc_html( $submission->claude_conversation_title ?: '—' ); ?></td></tr>
            <tr><th>Conversation ID</th><td style="word-break:break-all;"><?php echo esc_html( $submission->claude_conversation_id ?: '—' ); ?></td></tr>
            <tr><th>Created</th><td><?php echo ! empty( $submission->claude_created_at ) ? esc_html( wp_date( 'd M Y H:i', strtotime( (string) $submission->claude_created_at ) ) ) : '—'; ?></td></tr>
            <tr><th>Last operation</th><td><?php echo ! empty( $submission->claude_last_success_at ) ? esc_html( wp_date( 'd M Y H:i', strtotime( (string) $submission->claude_last_success_at ) ) ) : '—'; ?></td></tr>
            <tr><th>Model</th><td><?php echo esc_html( $submission->claude_model_used ?: '—' ); ?></td></tr>
            <tr><th>Prompt version</th><td><?php echo esc_html( $submission->claude_prompt_version ?: '—' ); ?></td></tr>
            <tr><th>AI report status</th><td><?php echo esc_html( $submission->ai_report_status ?? 'not_requested' ); ?></td></tr>
            <tr><th>DOCX output</th><td><?php echo esc_html( ! empty( $submission->ai_report_docx_path ) ? basename( (string) $submission->ai_report_docx_path ) : '—' ); ?></td></tr>
            <tr><th>PDF output</th><td><?php echo esc_html( ! empty( $submission->ai_report_pdf_path ) ? basename( (string) $submission->ai_report_pdf_path ) : '—' ); ?></td></tr>
            <?php if ( ! empty( $submission->claude_last_error ) ) : ?>
              <tr><th>Last error</th><td style="color:#d63638;word-break:break-word;"><?php echo esc_html( $submission->claude_last_error ); ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
        <p class="description">Conversation IDs shown here are WordPress-managed API session identifiers unless Anthropic exposes compatible Claude.ai chat lifecycle APIs later.</p>
      </div>

      <!-- Attribution -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Attribution</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <?php foreach ( [ 'utm_source' => 'Source', 'utm_medium' => 'Medium', 'utm_campaign' => 'Campaign', 'utm_term' => 'Term', 'utm_content' => 'Content' ] as $field => $label ) : ?>
              <?php if ( $submission->$field ) : ?>
              <tr><th style="width:130px;"><?php echo esc_html( $label ); ?></th><td><?php echo esc_html( $submission->$field ); ?></td></tr>
              <?php endif; ?>
            <?php endforeach; ?>
            <?php if ( $submission->referrer_url ) : ?>
            <tr><th>Referrer</th><td style="word-break:break-all;"><a href="<?php echo esc_url( $submission->referrer_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $submission->referrer_url ); ?></a></td></tr>
            <?php endif; ?>
            <?php if ( $submission->landing_page ) : ?>
            <tr><th>Landing page</th><td style="word-break:break-all;"><a href="<?php echo esc_url( $submission->landing_page ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $submission->landing_page ); ?></a></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Payment & report -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Payment & Report</h3>
        <table class="widefat" style="font-size:0.85em;">
          <tbody>
            <tr><th style="width:130px;">Payment status</th><td><?php echo esc_html( $submission->payment_status ?? 'none' ); ?></td></tr>
            <tr><th>Stripe session</th><td style="word-break:break-all;"><?php echo esc_html( $submission->stripe_session_id ?? '—' ); ?></td></tr>
            <tr><th>Product</th><td><?php echo $purchased_product ? esc_html( $purchased_product->name ) : '—'; ?></td></tr>
            <?php if ( $payment_session ) : ?>
              <tr><th>Expected amount</th><td><?php echo esc_html( strtoupper( (string) ( $payment_session->currency ?? 'gbp' ) ) . ' ' . number_format( (int) ( $payment_session->amount_total ?? 0 ) / 100, 2 ) ); ?></td></tr>
              <tr><th>Session status</th><td><?php echo esc_html( $payment_session->payment_status ?? '—' ); ?></td></tr>
            <?php endif; ?>
            <?php if ( $latest_payment_event ) : ?>
              <tr><th>Latest event</th><td><?php echo esc_html( $latest_payment_event->event_type ?? '—' ); ?></td></tr>
              <tr><th>Event processed</th><td><?php echo $latest_payment_event->processed_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $latest_payment_event->processed_at ) ) ) : '—'; ?></td></tr>
            <?php endif; ?>
            <tr><th>Report generated</th><td><?php echo $submission->report_generated_at ? esc_html( wp_date( 'd M Y H:i', strtotime( $submission->report_generated_at ) ) ) : '—'; ?></td></tr>
            <tr><th>Report file</th><td style="word-break:break-all;"><?php echo esc_html( $submission->report_path ? basename( (string) $submission->report_path ) : '—' ); ?></td></tr>
            <?php if ( ! empty( $submission->report_error ) ) : ?>
              <tr><th>Report error</th><td><?php echo esc_html( $submission->report_error ); ?></td></tr>
            <?php endif; ?>
            <tr><th>Report tokens</th><td><?php echo esc_html( (string) count( $report_tokens ) ); ?> issued</td></tr>
          </tbody>
        </table>
      </div>

      <!-- Actions -->
      <div class="wpq-card" style="margin-top:16px;">
        <h3 style="margin:0 0 12px;">Actions</h3>
        <a href="<?php echo esc_url( $delete_url ); ?>" class="button button-secondary wpq-confirm-delete"
           style="color:#e84855;border-color:#e84855;">Delete submission</a>
      </div>

    </div>
  </div>
</div>
