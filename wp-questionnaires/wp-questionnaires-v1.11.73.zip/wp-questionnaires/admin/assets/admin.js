/* global wpqAdmin, jQuery */
(function ($) {
  'use strict';

  // -----------------------------------------------------------------------
  // Tab navigation
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-nav-tabs .nav-tab', function (e) {
    e.preventDefault();
    var tab = $(this).data('tab');

    $('.wpq-nav-tabs .nav-tab').removeClass('nav-tab-active');
    $(this).addClass('nav-tab-active');

    $('.wpq-tab-panel').addClass('wpq-hidden');
    $('#tab-' + tab).removeClass('wpq-hidden');

    // Track active tab so the server saves only the relevant section's fields.
    $('#wpq-settings-section').val(tab);
  });


  // -----------------------------------------------------------------------
  // Question type — show/hide conditional score/max fields
  // -----------------------------------------------------------------------

  $(document).on('change', '.wpq-q-type-select', function () {
    var editor  = $(this).closest('.wpq-question-editor');
    var qType   = $(this).val();
    var hasScores  = qType === 'tri_state' || qType === 'boolean';
    var hasOptions = qType === 'select' || qType === 'radio' || qType === 'checkbox';

    editor.find('.wpq-q-scores').toggleClass('wpq-hidden', !hasScores);
    editor.find('.wpq-partial-score').prop('disabled', qType === 'boolean').css('opacity', qType === 'boolean' ? 0.4 : 1);
    editor.find('.wpq-q-options-manager').toggleClass('wpq-hidden', !hasOptions);
    editor.find('.wpq-q-guidance').toggleClass('wpq-hidden', !hasScores);
    editor.find('.wpq-q-recommendation').toggleClass('wpq-hidden', !hasScores);

    // Auto-set a sensible default scoring mode.
    var modeMap = { tri_state: 'legacy_tri_state', boolean: 'boolean', select: 'single_option', radio: 'single_option', checkbox: 'sum_selected', memo: 'non_scoring' };
    editor.find('.wpq-q-mode-select').val(modeMap[qType] || 'legacy_tri_state');
    editor.find('.wpq-q-maxscore').toggleClass('wpq-hidden', qType !== 'checkbox');
  });

  $(document).on('change', '.wpq-q-mode-select', function () {
    var editor = $(this).closest('.wpq-question-editor');
    var mode   = $(this).val();
    editor.find('.wpq-q-maxscore').toggleClass('wpq-hidden', mode !== 'sum_selected' && mode !== 'max_selected');
  });

  // -----------------------------------------------------------------------
  // Question options management
  // -----------------------------------------------------------------------

  function wpqEnsureOptionClientId(row, questionId, index) {
    var clientId = row.attr('data-client-id');
    if (!clientId) {
      clientId = 'q' + questionId + '-opt-' + Date.now() + '-' + index + '-' + Math.floor(Math.random() * 100000);
      row.attr('data-client-id', clientId);
    }
    return clientId;
  }

  function wpqCollectQuestionOptions(editor) {
    var questionId = editor.data('id');
    var options = [];

    editor.find('.wpq-options-table tbody tr').each(function (index) {
      var row = $(this);
      options.push({
        client_id:        wpqEnsureOptionClientId(row, questionId, index),
        option_id:        row.attr('data-option-id') || row.find('.wpq-save-option').data('option-id') || 0,
        option_key:       row.find('[data-field="option_key"]').val(),
        option_label:     row.find('[data-field="option_label"]').val(),
        score:            row.find('[data-field="score"]').val(),
        finding_priority: row.find('[data-field="finding_priority"]').val(),
        finding_action:   row.find('[data-field="finding_action"]').val(),
        sort_order:       row.find('[data-field="sort_order"]').val(),
        is_default:       row.find('[data-field="is_default"]').is(':checked') ? '1' : '0',
        requires_notes:   row.find('[data-field="requires_notes"]').is(':checked') ? '1' : '0',
        exclusive:        row.find('[data-field="exclusive"]').is(':checked') ? '1' : '0',
      });
    });

    return options;
  }

  function wpqApplySavedQuestionOptions(editor, savedOptions) {
    if (!Array.isArray(savedOptions)) {
      return;
    }

    savedOptions.forEach(function (saved) {
      var row = editor.find('.wpq-options-table tbody tr[data-client-id="' + saved.client_id + '"]');
      if (!row.length) {
        return;
      }
      row.attr('data-option-id', saved.option_id);
      row.find('.wpq-save-option').data('option-id', saved.option_id).attr('data-option-id', saved.option_id);
      row.find('.wpq-delete-option').data('option-id', saved.option_id).attr('data-option-id', saved.option_id);
      if (saved.option_key) {
        row.find('[data-field="option_key"]').val(saved.option_key);
      }
    });
  }

  $(document).on('click', '.wpq-save-option', function () {
    var btn        = $(this);
    var questionId = btn.data('question-id');
    var optionId   = btn.data('option-id') || 0;
    var row        = btn.closest('tr');

    var data = {
      action:           'wpq_save_question_option',
      nonce:            wpqAdmin.nonce,
      question_id:      questionId,
      option_id:        optionId,
      option_key:       row.find('[data-field="option_key"]').val(),
      option_label:     row.find('[data-field="option_label"]').val(),
      score:            row.find('[data-field="score"]').val(),
      finding_priority: row.find('[data-field="finding_priority"]').val(),
      finding_action:   row.find('[data-field="finding_action"]').val(),
      sort_order:       row.find('[data-field="sort_order"]').val(),
      is_default:       row.find('[data-field="is_default"]').is(':checked') ? '1' : '0',
      is_active:        row.find('[data-field="is_active"]').is(':checked') ? '1' : '0',
    };

    btn.prop('disabled', true).text('Saving…');

    $.post(wpqAdmin.ajaxUrl, data, function (res) {
      btn.prop('disabled', false).text('Save');
      if (res.success) {
        if (!optionId && res.data.option_id) {
          btn.data('option-id', res.data.option_id);
          row.attr('data-option-id', res.data.option_id);
          row.find('.wpq-delete-option').data('option-id', res.data.option_id).attr('data-option-id', res.data.option_id);
        }
      } else {
        var errMsg = (res.data && res.data.message) ? res.data.message : 'Error saving option.';
        alert(errMsg);
      }
    });
  });

  $(document).on('click', '.wpq-delete-option', function () {
    if (!confirm('Remove this option? This cannot be undone.')) return;
    var btn      = $(this);
    var optionId = btn.data('option-id');
    var row      = btn.closest('tr');

    if (!optionId) {
      row.remove();
      return;
    }

    $.post(wpqAdmin.ajaxUrl, {
      action:    'wpq_delete_question_option',
      nonce:     wpqAdmin.nonce,
      option_id: optionId,
    }, function (res) {
      if (res.success) {
        row.remove();
      } else {
        var errMsg = (res.data && res.data.message) ? res.data.message : 'Error deleting option.';
        alert(errMsg);
      }
    });
  });

  $(document).on('click', '.wpq-add-option', function () {
    var questionId = $(this).data('question-id');
    var tbody      = $(this).closest('table').find('tbody');
    var newRow = $([
      '<tr data-option-id="">',
      '<td><input type="text" class="small-text wpq-opt-field" data-field="option_key" placeholder="key_name"></td>',
      '<td><input type="text" class="regular-text wpq-opt-field" data-field="option_label" placeholder="Display label"></td>',
      '<td><input type="number" class="small-text wpq-opt-field" min="0" max="100" data-field="score" value="1"></td>',
      '<td><select class="wpq-opt-field" data-field="finding_priority"><option value="">—</option><option value="critical">Critical</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></td>',
      '<td><input type="text" class="regular-text wpq-opt-field" data-field="finding_action" placeholder="Action text"></td>',
      '<td><input type="number" class="small-text wpq-opt-field" min="0" data-field="sort_order" value="0"></td>',
      '<td><input type="checkbox" class="wpq-opt-field" data-field="is_default" value="1"></td>',
      '<td>',
      '<button class="button button-small wpq-delete-option" data-option-id="0" style="color:#a00;">Remove</button>',
      '</td>',
      '</tr>',
    ].join(''));
    newRow.find('[data-field="finding_priority"]').append('<option value="good_practice">Good Practice</option>');
    tbody.append(newRow);
  });

  // -----------------------------------------------------------------------
  // Save all grade thresholds
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-save-grades', function () {
    var btn    = $(this);
    var status = $('.wpq-grades-status');
    var grades = [];

    $('.wpq-scoring-table tbody tr').each(function () {
      var row = $(this);
      grades.push({
        id:           row.data('id'),
        min_score:    row.find('[data-field="min_score"]').val(),
        grade_label:  row.find('[data-field="grade_label"]').val(),
        verdict_text: row.find('[data-field="verdict_text"]').val(),
        color_hex:    row.find('[data-field="color_hex"]').val(),
        bg_hex:       row.find('[data-field="bg_hex"]').val(),
      });
    });

    btn.prop('disabled', true).text('Saving...');
    status.removeClass('error').text('Saving grades...').show();

    $.post(wpqAdmin.ajaxUrl, {
      action: 'wpq_save_grades',
      nonce:  wpqAdmin.nonce,
      grades: grades,
    }, function (res) {
      btn.prop('disabled', false).text('Save grades');
      if (res.success) {
        status.removeClass('error').text('Grades saved').show().delay(2000).fadeOut();
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error saving grades.';
        status.addClass('error').text(msg).show().delay(3000).fadeOut();
      }
    });
  });
  // -----------------------------------------------------------------------
  // Add grade threshold
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-add-grade', function () {
    var btn  = $(this);
    var qId  = btn.data('q-id');

    btn.prop('disabled', true).text('Adding…');

    $.post(wpqAdmin.ajaxUrl, {
      action:           'wpq_add_grade',
      nonce:            wpqAdmin.nonce,
      questionnaire_id: qId,
    }, function (res) {
      btn.prop('disabled', false).text('+ Add Grade');
      if (!res.success) {
        alert((res.data && res.data.message) ? res.data.message : 'Error adding grade.');
        return;
      }
      var d   = res.data;
      var row = $('<tr>').attr('data-id', d.id);
      row.append($('<td>').append($('<input>').attr({type:'number','class':'small-text wpq-grade-field',min:0,max:100,'data-field':'min_score'}).val(d.min_score)));
      row.append($('<td>').append($('<code>').text(d.grade_id)));
      row.append($('<td>').append($('<input>').attr({type:'text','class':'regular-text wpq-grade-field','data-field':'grade_label'}).val(d.grade_label)));
      row.append($('<td>').append($('<textarea>').attr({'class':'wpq-grade-field',rows:2,'data-field':'verdict_text'}).val(d.verdict_text)));
      row.append($('<td>').append($('<input>').attr({type:'color','class':'wpq-grade-field','data-field':'color_hex'}).val(d.color_hex)));
      row.append($('<td>').append($('<input>').attr({type:'color','class':'wpq-grade-field','data-field':'bg_hex'}).val(d.bg_hex)));
      var actions = $('<td>');
      actions.append($('<button>').attr({'class':'button button-small wpq-delete-grade','data-id':d.id}).text('Remove'));
      row.append(actions);
      $('.wpq-scoring-table tbody').append(row);
    });
  });

  // -----------------------------------------------------------------------
  // Delete grade threshold
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-delete-grade', function () {
    if (!confirm('Remove this grade? This cannot be undone.')) return;
    var btn = $(this);
    var id  = btn.data('id');
    var row = btn.closest('tr');

    btn.prop('disabled', true);

    $.post(wpqAdmin.ajaxUrl, {
      action: 'wpq_delete_grade',
      nonce:  wpqAdmin.nonce,
      id:     id,
    }, function (res) {
      if (res.success) {
        row.remove();
      } else {
        btn.prop('disabled', false);
        alert((res.data && res.data.message) ? res.data.message : 'Error deleting grade.');
      }
    });
  });

  // -----------------------------------------------------------------------
  // Confirm delete
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-confirm-delete', function () {
    return confirm('Are you sure you want to remove this submission?');
  });

  // -----------------------------------------------------------------------
  // Product editor
  // -----------------------------------------------------------------------

  function peShow(title) {
    $('#wpq-pe-title').text(title);
    $('#wpq-pe-status-msg').hide().text('');
    $('#wpq-product-editor').removeClass('wpq-hidden');
    $('html, body').animate({ scrollTop: $('#wpq-product-editor').offset().top - 32 }, 200);
  }

  function peClear() {
    $('#wpq-pe-id').val('');
    $('#wpq-pe-name').val('');
    $('#wpq-pe-description').val('');
    $('#wpq-pe-questionnaire').val('');
    $('#wpq-pe-price').val('0.00');
    $('#wpq-pe-billing').val('one_off');
    $('#wpq-pe-report').val('professional');
    $('#wpq-pe-stripe').val('');
    $('#wpq-pe-status').val('inactive');
  }

  $(document).on('click', '#wpq-add-product', function () {
    peClear();
    peShow('Add Pricing Option');
  });

  $(document).on('click', '.wpq-edit-product', function () {
    var d = $(this).data();
    $('#wpq-pe-id').val(d.id);
    $('#wpq-pe-name').val(d.name);
    $('#wpq-pe-description').val(d.description);
    $('#wpq-pe-questionnaire').val(d.questionnaire || '');
    $('#wpq-pe-price').val(parseFloat(d.price || 0).toFixed(2));
    $('#wpq-pe-billing').val(d.billing || 'one_off');
    $('#wpq-pe-report').val(d.report || 'professional');
    $('#wpq-pe-stripe').val(d.stripe || '');
    $('#wpq-pe-status').val(d.status || 'inactive');
    peShow('Edit Pricing Option');
  });

  $(document).on('click', '#wpq-cancel-product', function () {
    $('#wpq-product-editor').addClass('wpq-hidden');
    peClear();
  });

  $(document).on('click', '#wpq-save-product', function () {
    var btn = $(this);
    var msg = $('#wpq-pe-status-msg');

    var name = $('#wpq-pe-name').val().trim();
    if (!name) {
      msg.removeClass('wpq-msg-success').addClass('wpq-msg-error').text('Product name is required.').show();
      return;
    }

    var stripe = $('#wpq-pe-stripe').val().trim();
    if (stripe && !/^price_[A-Za-z0-9]+$/.test(stripe)) {
      msg.removeClass('wpq-msg-success').addClass('wpq-msg-error').text('Stripe Price ID must start with price_ and contain only letters and numbers.').show();
      return;
    }

    var postData = {
      action:           'wpq_save_product',
      nonce:            wpqAdmin.nonce,
      id:               $('#wpq-pe-id').val(),
      name:             name,
      description:      $('#wpq-pe-description').val(),
      questionnaire_id: $('#wpq-pe-questionnaire').val(),
      price_gbp:        $('#wpq-pe-price').val(),
      billing_type:     $('#wpq-pe-billing').val(),
      report_type:      $('#wpq-pe-report').val(),
      stripe_price_id:  stripe,
      status:           $('#wpq-pe-status').val(),
    };

    btn.prop('disabled', true).text('Saving…');

    $.post(wpqAdmin.ajaxUrl, postData, function (res) {
      if (res.success) {
        window.location.reload();
      } else {
        btn.prop('disabled', false).text('Save product');
        var errMsg = (res.data && res.data.message) ? res.data.message : 'Error saving product.';
        msg.addClass('wpq-msg-error').text(errMsg).show();
      }
    }).fail(function () {
      btn.prop('disabled', false).text('Save product');
      msg.addClass('wpq-msg-error').text('Request failed. Please try again.').show();
    });
  });

  // -----------------------------------------------------------------------
  // Save questionnaire details
  // -----------------------------------------------------------------------

  $(document).on('click', '#wpq-save-questionnaire', function () {
    var btn    = $(this);
    var id     = btn.data('id');
    var status = $('#wpq-q-save-status');

    var data = {
      action:            'wpq_save_questionnaire',
      nonce:             wpqAdmin.nonce,
      id:                id,
      name:              $('#wpq-q-name').val(),
      description:       $('#wpq-q-desc').val(),
      status:            $('#wpq-q-status').val(),
      stripe_product_id: $('#wpq-stripe-product-id').val(),
      claude_project_id: $('#wpq-claude-project-id').val(),
      claude_project_url: $('#wpq-claude-project-url').val(),
    };

    btn.prop('disabled', true).text('Saving…');

    $.post(wpqAdmin.ajaxUrl, data, function (res) {
      btn.prop('disabled', false).text('Save details');
      if (res.success && res.data && res.data.warning) {
        status.addClass('error').text('Saved. ' + res.data.warning).fadeIn().delay(4000).fadeOut();
        return;
      }
      if (res.success) {
        status.removeClass('error').text('✓ Saved').fadeIn().delay(2000).fadeOut();
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error saving.';
        status.addClass('error').text(msg).fadeIn().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Library: NEW questionnaire modal
  // -----------------------------------------------------------------------

  $(document).on('click', '#wpq-new-q-btn', function (e) {
    e.preventDefault();
    $('#wpq-new-q-modal').removeClass('wpq-hidden').css('display', 'flex');
    $('#wpq-new-q-ref').focus();
  });

  $(document).on('click', '#wpq-new-q-cancel', function (e) {
    e.preventDefault();
    $('#wpq-new-q-modal').addClass('wpq-hidden').hide();
  });

  $(document).on('click', '#wpq-new-q-modal', function (e) {
    if ($(e.target).is('#wpq-new-q-modal')) {
      $('#wpq-new-q-modal').addClass('wpq-hidden').hide();
    }
  });

  $(document).on('click', '#wpq-new-q-submit', function () {
    var btn = $(this);
    var ref  = $('#wpq-new-q-ref').val().trim().toUpperCase();
    var name = $('#wpq-new-q-name').val().trim();
    var err  = $('.wpq-new-q-error');

    if (!ref || !name) {
      err.text('Reference and Name are required.').removeClass('wpq-hidden').show();
      return;
    }

    btn.prop('disabled', true).text('Creating…');
    err.hide();

    $.post(wpqAdmin.ajaxUrl, {
      action:   'wpq_create_questionnaire',
      nonce:    wpqAdmin.nonce,
      ref:      ref,
      name:     name,
      category: $('#wpq-new-q-category').val(),
    }, function (res) {
      btn.prop('disabled', false).text('Create');
      if (res.success) {
        window.location.href = wpqAdmin.ajaxUrl.replace('admin-ajax.php', 'admin.php') +
          '?page=wpq-library&wpq_action=edit&id=' + res.data.id;
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error creating questionnaire.';
        err.text(msg).show();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Library: select all / bulk action
  // -----------------------------------------------------------------------

  $(document).on('change', '#wpq-select-all', function () {
    $('.wpq-row-select').prop('checked', $(this).is(':checked'));
  });

  $(document).on('click', '#wpq-bulk-go', function () {
    var action  = $('#wpq-bulk-action').val();
    var ids     = $('.wpq-row-select:checked').map(function () { return $(this).val(); }).get();
    var status  = $('#wpq-bulk-status');
    var $bar    = $(this).closest('[data-export-type]');

    if (!action) {
      status.addClass('error').text('Select an action first.').show().delay(3000).fadeOut();
      return;
    }
    if (!ids.length) {
      status.addClass('error').text('Select at least one record.').show().delay(3000).fadeOut();
      return;
    }

    // Export selected: form POST to admin-post.php to trigger file download.
    if (action === 'export_selected') {
      var exportType  = $bar.data('export-type');
      var exportNonce = $bar.data('export-nonce');
      if (!exportType || !exportNonce) {
        status.addClass('error').text('Export not configured for this page.').show().delay(3000).fadeOut();
        return;
      }
      var $form = $('<form>', {method: 'post', action: wpqAdmin.adminPostUrl, style: 'display:none'});
      $form.append($('<input>', {type: 'hidden', name: 'action',   value: 'wpq_export'}));
      $form.append($('<input>', {type: 'hidden', name: 'type',     value: exportType}));
      $form.append($('<input>', {type: 'hidden', name: '_wpnonce', value: exportNonce}));
      $.each(ids, function (_, v) {
        $form.append($('<input>', {type: 'hidden', name: 'ids[]', value: v}));
      });
      $('body').append($form);
      $form[0].submit();
      $form.remove();
      return;
    }

    var dangerActions = { remove: 'permanently delete', archive: 'archive', unarchive: 'unarchive', duplicate: 'duplicate' };
    if (!confirm('Are you sure you want to ' + (dangerActions[action] || action) + ' the selected record(s)?')) return;

    var btn = $(this);
    btn.prop('disabled', true);

    var postData = {
      action:      'wpq_bulk_questionnaire_action',
      nonce:       wpqAdmin.nonce,
      bulk_action: action,
    };
    $.each(ids, function (i, v) { postData['ids[' + i + ']'] = v; });

    $.post(wpqAdmin.ajaxUrl, postData, function (res) {
      btn.prop('disabled', false);
      if (res.success) {
        status.removeClass('error').text('✓ Done (' + res.data.ok + ' updated)').show().delay(2000).fadeOut();
        setTimeout(function () { window.location.reload(); }, 1800);
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error.';
        status.addClass('error').text(msg).show().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Domains tab: save all domains
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-save-domains', function () {
    var btn     = $(this);
    var status  = $('.wpq-domains-status');
    var domains = [];

    $('#wpq-domains-tbody tr').each(function () {
      var row = $(this);
      domains.push({
        id:         row.data('id'),
        name:       row.find('[data-field="name"]').val(),
        icon:       row.find('[data-field="icon"]').val(),
        sort_order: row.find('[data-field="sort_order"]').val(),
        brief:      row.find('[data-field="brief"]').val(),
      });
    });

    btn.prop('disabled', true).text('Saving...');
    status.removeClass('error').text('Saving domains...').show();

    $.post(wpqAdmin.ajaxUrl, {
      action:  'wpq_update_domains',
      nonce:   wpqAdmin.nonce,
      domains: domains,
    }, function (res) {
      btn.prop('disabled', false).text('Save domains');
      if (res.success) {
        status.removeClass('error').text('Domains saved').show().delay(2000).fadeOut();
        setTimeout(function () { window.location.reload(); }, 1800);
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error saving domains.';
        status.addClass('error').text(msg).show().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Domains tab: delete domain
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-delete-domain', function () {
    if (!confirm('Delete this domain and ALL its questions? This cannot be undone.')) return;
    var btn = $(this);
    var id  = btn.data('id');

    btn.prop('disabled', true);

    $.post(wpqAdmin.ajaxUrl, {
      action: 'wpq_delete_domain',
      nonce:  wpqAdmin.nonce,
      id:     id,
    }, function (res) {
      if (res.success) {
        window.location.reload();
      } else {
        btn.prop('disabled', false);
        alert((res.data && res.data.message) ? res.data.message : 'Error deleting domain.');
      }
    });
  });

  // -----------------------------------------------------------------------
  // Domains tab: add domain
  // -----------------------------------------------------------------------

  $(document).on('click', '#wpq-add-domain-btn', function () {
    var btn  = $(this);
    var qId  = btn.data('q-id');
    var name = $('#wpq-new-domain-name').val().trim();
    var icon = $('#wpq-new-domain-icon').val().trim();
    var stat = $('#wpq-add-domain-status');

    if (!name) {
      stat.addClass('error').text('Name is required.').show().delay(3000).fadeOut();
      return;
    }

    btn.prop('disabled', true).text('Adding…');

    $.post(wpqAdmin.ajaxUrl, {
      action:           'wpq_add_domain',
      nonce:            wpqAdmin.nonce,
      questionnaire_id: qId,
      name:             name,
      icon:             icon,
    }, function (res) {
      btn.prop('disabled', false).text('+ Add Domain');
      if (res.success) {
        window.location.reload();
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error adding domain.';
        stat.addClass('error').text(msg).show().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Questions tab: save question (extended to include domain_id)
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-save-question', function () {
    var btn    = $(this);
    var id     = btn.data('id');
    var editor = btn.closest('.wpq-question-editor');
    var status = $('.wpq-q-status-' + id);
    var btnText = btn.text();

    var data = {
      action:        'wpq_save_question',
      nonce:         wpqAdmin.nonce,
      id:            id,
      question_text: editor.find('[data-field="question_text"]').val(),
      recommendation: editor.find('[data-field="recommendation"]').val(),
      score_yes:     editor.find('[data-field="score_yes"]').val(),
      score_partial: editor.find('[data-field="score_partial"]').val(),
      score_no:      editor.find('[data-field="score_no"]').val(),
      question_type: editor.find('[data-field="question_type"]').val(),
      scoring_mode:  editor.find('[data-field="scoring_mode"]').val(),
      is_required:   editor.find('[data-field="is_required"]').is(':checked') ? '1' : '0',
      max_score:     editor.find('[data-field="max_score"]').val(),
      help_text:     editor.find('[data-field="help_text"]').val(),
      answer_options: JSON.stringify(wpqCollectQuestionOptions(editor)),
    };

    var domainField = editor.find('[data-field="domain_id"]');
    if (domainField.length) {
      data.domain_id = domainField.val();
    }

    btn.prop('disabled', true).text('Saving…');

    $.post(wpqAdmin.ajaxUrl, data, function (res) {
      btn.prop('disabled', false).text(btnText);
      if (res.success) {
        wpqApplySavedQuestionOptions(editor, res.data && res.data.options);
        status.removeClass('error').text('✓ Saved').show().delay(2000).fadeOut();
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error saving.';
        status.addClass('error').text(msg).show().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Questions tab: add question
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-add-question-btn', function () {
    var btn      = $(this);
    var domainId = btn.data('domain-id');
    var origText = btn.text();
    var stat     = $('.wpq-addq-status-' + domainId);

    btn.prop('disabled', true).text('Adding…');

    $.post(wpqAdmin.ajaxUrl, {
      action:    'wpq_add_question',
      nonce:     wpqAdmin.nonce,
      domain_id: domainId,
    }, function (res) {
      if (res.success) {
        window.location.reload();
      } else {
        btn.prop('disabled', false).text(origText);
        var msg = (res.data && res.data.message) ? res.data.message : 'Error adding question.';
        stat.addClass('error').text(msg).show().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Questions tab: delete question
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-delete-question', function () {
    if (!confirm('Delete this question and all its options? This cannot be undone.')) return;
    var btn = $(this);
    var id  = btn.data('id');

    btn.prop('disabled', true);

    $.post(wpqAdmin.ajaxUrl, {
      action: 'wpq_delete_question',
      nonce:  wpqAdmin.nonce,
      id:     id,
    }, function (res) {
      if (res.success) {
        window.location.reload();
      } else {
        btn.prop('disabled', false);
        alert((res.data && res.data.message) ? res.data.message : 'Error deleting question.');
      }
    });
  });

  // -----------------------------------------------------------------------
  // Questions tab: collapsible domain sections
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-domain-toggle', function () {
    $(this).closest('.wpq-domain-section').toggleClass('wpq-collapsed');
  });

  // -----------------------------------------------------------------------
  // Questions tab: Reset Questions
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-reset-questions-btn', function () {
    var btn = $(this);
    var qId = btn.data('q-id');

    if (!confirm('Reset questions?\n\nThis will permanently delete ALL questions and their answer options for this questionnaire. This cannot be undone.')) return;
    if (!confirm('Are you absolutely sure? All question data will be lost.')) return;

    btn.prop('disabled', true).text('Resetting…');

    $.post(wpqAdmin.ajaxUrl, {
      action:            'wpq_reset_questions',
      nonce:             wpqAdmin.nonce,
      questionnaire_id:  qId,
    }, function (res) {
      if (res.success) {
        window.location.reload();
      } else {
        btn.prop('disabled', false).text('⚠ Reset Questions');
        var msg = (res.data && res.data.message) ? res.data.message : 'Reset failed.';
        alert(msg);
      }
    });
  });

  // -----------------------------------------------------------------------
  // Questions tab: Create Questions form toggle + submit
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-create-questions-btn', function () {
    $(this).closest('.wpq-mass-toolbar').find('.wpq-create-questions-form').removeClass('wpq-hidden').css('display', 'flex');
    $(this).prop('disabled', true);
  });

  $(document).on('click', '.wpq-cq-cancel-btn', function () {
    var toolbar = $(this).closest('.wpq-mass-toolbar');
    toolbar.find('.wpq-create-questions-form').addClass('wpq-hidden');
    toolbar.find('.wpq-create-questions-btn').prop('disabled', false);
    toolbar.find('.wpq-cq-status').text('');
  });

  $(document).on('click', '.wpq-cq-go-btn', function () {
    var btn      = $(this);
    var form     = btn.closest('.wpq-create-questions-form');
    var domainId = form.find('.wpq-cq-domain').val();
    var count    = parseInt(form.find('.wpq-cq-count').val(), 10) || 1;
    var stat     = form.find('.wpq-cq-status');

    if (count < 1 || count > 100) {
      stat.addClass('error').text('Enter a number between 1 and 100.');
      return;
    }

    btn.prop('disabled', true).text('Creating…');
    stat.removeClass('error').text('');

    var done = 0;
    var failed = 0;

    function createOne() {
      if (done + failed >= count) {
        btn.prop('disabled', false).text('Create');
        if (failed === 0) {
          window.location.reload();
        } else {
          stat.addClass('error').text(failed + ' question(s) failed to create.');
        }
        return;
      }

      $.post(wpqAdmin.ajaxUrl, {
        action:    'wpq_add_question',
        nonce:     wpqAdmin.nonce,
        domain_id: domainId,
      }, function (res) {
        if (res.success) {
          done++;
        } else {
          failed++;
        }
        stat.text('Created ' + done + ' / ' + count + '…');
        createOne();
      }).fail(function () {
        failed++;
        stat.text('Created ' + done + ' / ' + count + '…');
        createOne();
      });
    }

    createOne();
  });

  // -----------------------------------------------------------------------
  // Scoring tab: save domain weight
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-save-domain-weight', function () {
    var btn    = $(this);
    var id     = btn.data('id');
    var weight = btn.closest('tr').find('.wpq-domain-weight-input').val();
    var stat   = $('.wpq-dw-status-' + id);

    btn.prop('disabled', true).text('Saving…');

    $.post(wpqAdmin.ajaxUrl, {
      action: 'wpq_save_domain_weight',
      nonce:  wpqAdmin.nonce,
      id:     id,
      weight: weight,
    }, function (res) {
      btn.prop('disabled', false).text('Save');
      if (res.success) {
        stat.removeClass('error').text('✓ Saved').show().delay(2000).fadeOut();
      } else {
        stat.addClass('error').text('Error').show().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Scoring tab: save question scoring (weight + answer scores)
  // -----------------------------------------------------------------------

  $(document).on('click', '.wpq-save-question-scoring', function () {
    var btn  = $(this);
    var id   = btn.data('id');
    var row  = btn.closest('tr');
    var stat = $('.wpq-qs-status-' + id);

    // Collect per-option guidance (radio/select/checkbox questions).
    var optGuidances = {};
    row.find('.wpq-qs-opt-guidance').each(function () {
      optGuidances[$(this).data('option-id')] = $(this).val();
    });

    btn.prop('disabled', true).text('Saving…');

    $.post(wpqAdmin.ajaxUrl, {
      action:           'wpq_save_question_scoring',
      nonce:            wpqAdmin.nonce,
      id:               id,
      question_weight:  row.find('.wpq-qs-weight').val(),
      score_yes:        row.find('[data-field="score_yes"]').val() || 0,
      score_partial:    row.find('[data-field="score_partial"]').val() || 0,
      score_no:         row.find('[data-field="score_no"]').val() || 0,
      guidance_yes:     row.find('.wpq-qs-guidance[data-field="guidance_yes"]').val() || '',
      guidance_partial: row.find('.wpq-qs-guidance[data-field="guidance_partial"]').val() || '',
      guidance_no:      row.find('.wpq-qs-guidance[data-field="guidance_no"]').val() || '',
      option_guidances: JSON.stringify(optGuidances),
    }, function (res) {
      btn.prop('disabled', false).text('Save');
      if (res.success) {
        stat.removeClass('error').text('✓ Saved').show().delay(2000).fadeOut();
      } else {
        stat.addClass('error').text('Error').show().delay(3000).fadeOut();
      }
    });
  });

  // -----------------------------------------------------------------------
  // Coupons page
  // -----------------------------------------------------------------------

  $(document).on('click', '#wpq-add-coupon', function () {
    $('#wpq-coupon-form').removeClass('wpq-hidden');
    $('#wpq-cf-name').focus();
  });

  $(document).on('click', '#wpq-cancel-coupon', function () {
    $('#wpq-coupon-form').addClass('wpq-hidden');
  });

  // Toggle percent / fixed fields.
  $(document).on('change', '[name="wpq_cf_discount_type"]', function () {
    var isFixed = $(this).val() === 'fixed';
    $('#wpq-cf-row-percent').toggleClass('wpq-hidden', isFixed);
    $('#wpq-cf-row-fixed').toggleClass('wpq-hidden', !isFixed);
  });

  // Toggle duration_in_months field.
  $(document).on('change', '#wpq-cf-duration', function () {
    $('#wpq-cf-row-months').toggleClass('wpq-hidden', $(this).val() !== 'repeating');
  });

  // Toggle scope-specific dropdowns.
  $(document).on('change', '#wpq-cf-scope', function () {
    var v = $(this).val();
    $('#wpq-cf-row-questionnaire').toggleClass('wpq-hidden', v !== 'questionnaire');
    $('#wpq-cf-row-product').toggleClass('wpq-hidden', v !== 'catalogue_item');
  });

  // Force promo code to uppercase as user types.
  $(document).on('input', '#wpq-cf-code', function () {
    var pos = this.selectionStart;
    $(this).val($(this).val().toUpperCase().replace(/[^A-Z0-9_-]/g, ''));
    this.setSelectionRange(pos, pos);
  });

  // Create coupon.
  $(document).on('click', '#wpq-save-coupon', function () {
    var btn = $(this);
    var status = $('#wpq-cf-status');
    var discountType = $('[name="wpq_cf_discount_type"]:checked').val();

    var name = $('#wpq-cf-name').val().trim();
    if (!name) {
      status.removeClass('wpq-msg-success').addClass('wpq-msg-error').text('Name is required.').removeClass('wpq-hidden').show();
      return;
    }

    var code = $('#wpq-cf-code').val().trim().toUpperCase();
    if (code && !/^[A-Z0-9_-]{1,50}$/.test(code)) {
      status.removeClass('wpq-msg-success').addClass('wpq-msg-error').text('Invalid promo code format.').removeClass('wpq-hidden').show();
      return;
    }

    var scope = $('#wpq-cf-scope').val();
    var postData = {
      action:             'wpq_create_coupon',
      nonce:              wpqAdmin.nonce,
      name:               name,
      promo_code:         code,
      discount_type:      discountType,
      percent_off:        $('#wpq-cf-percent').val(),
      amount_off:         $('#wpq-cf-amount').val(),
      currency:           $('#wpq-cf-currency').val(),
      duration:           $('#wpq-cf-duration').val(),
      duration_in_months: $('#wpq-cf-months').val(),
      max_redemptions:    $('#wpq-cf-max').val(),
      redeem_by:          $('#wpq-cf-expiry').val(),
      scope:              scope,
      questionnaire_id:   scope === 'questionnaire' ? $('#wpq-cf-questionnaire').val() : '',
      product_id:         scope === 'catalogue_item' ? $('#wpq-cf-product').val() : '',
    };

    btn.prop('disabled', true).text('Creating…');
    status.addClass('wpq-hidden').hide();

    $.post(wpqAdmin.ajaxUrl, postData, function (res) {
      if (res.success) {
        window.location.reload();
      } else {
        btn.prop('disabled', false).text('Create in Stripe');
        var errMsg = (res.data && res.data.message) ? res.data.message : 'Error creating coupon.';
        status.removeClass('wpq-msg-success').addClass('wpq-msg-error').text(errMsg).removeClass('wpq-hidden').show();
      }
    }).fail(function () {
      btn.prop('disabled', false).text('Create in Stripe');
      status.removeClass('wpq-msg-success').addClass('wpq-msg-error').text('Request failed. Please try again.').removeClass('wpq-hidden').show();
    });
  });

  // Delete coupon.
  $(document).on('click', '.wpq-delete-coupon', function () {
    var btn  = $(this);
    var name = btn.data('name');
    var id   = btn.data('id');

    if (!confirm('Delete coupon "' + name + '"?\n\nThis will archive the coupon in Stripe and it can no longer be used. This cannot be undone.')) {
      return;
    }

    btn.prop('disabled', true).text('Deleting…');

    $.post(wpqAdmin.ajaxUrl, {
      action: 'wpq_delete_coupon',
      nonce:  wpqAdmin.nonce,
      id:     id,
    }, function (res) {
      if (res.success) {
        btn.closest('tr').fadeOut(300, function () { $(this).remove(); });
      } else {
        btn.prop('disabled', false).text('Delete');
        var errMsg = (res.data && res.data.message) ? res.data.message : 'Error deleting coupon.';
        alert('Error: ' + errMsg);
      }
    }).fail(function () {
      btn.prop('disabled', false).text('Delete');
      alert('Request failed. Please try again.');
    });
  });

  /* -----------------------------------------------------------------------
     Pricing — delete product
     ----------------------------------------------------------------------- */
  $(document).on('click', '.wpq-delete-product', function () {
    var btn  = $(this);
    var name = btn.data('name');
    var id   = btn.data('id');

    if (!confirm('Delete pricing option "' + name + '"?\n\nIf a Stripe Price ID is set it will be archived in Stripe. This cannot be undone.')) {
      return;
    }

    btn.prop('disabled', true).text('Deleting…');

    $.post(wpqAdmin.ajaxUrl, {
      action: 'wpq_delete_product',
      nonce:  wpqAdmin.nonce,
      id:     id,
    }, function (res) {
      if (res.success) {
        btn.closest('tr').fadeOut(300, function () { $(this).remove(); });
      } else {
        btn.prop('disabled', false).text('Delete');
        var errMsg = (res.data && res.data.message) ? res.data.message : 'Error deleting pricing option.';
        alert('Error: ' + errMsg);
      }
    }).fail(function () {
      btn.prop('disabled', false).text('Delete');
      alert('Request failed. Please try again.');
    });
  });

  /* -----------------------------------------------------------------------
     Contacts — opt-out toggle
     ----------------------------------------------------------------------- */
  $(document).on('click', '.wpq-opt-out-btn', function () {
    var btn       = $(this);
    var email     = btn.data('email');
    var optedOut  = parseInt(btn.data('optedOut'), 10);
    var statusEl  = btn.closest('td, div').find('.wpq-opt-out-status');
    btn.prop('disabled', true).text('Saving…');
    $.post(wpqAdmin.ajaxUrl, {
      action:    'wpq_toggle_contact_opt_out',
      nonce:     wpqAdmin.nonce,
      email:     email,
      opted_out: optedOut,
    }, function (res) {
      btn.prop('disabled', false);
      if (res.success) {
        var nowOut = !!res.data.opted_out;
        btn.data('optedOut', nowOut ? 0 : 1).text(nowOut ? 'Remove opt-out' : 'Mark opted out');
        statusEl.css('color', '#2eb872').text(nowOut ? 'Marked as opted out.' : 'Opt-out removed.');
        setTimeout(function () { location.reload(); }, 800);
      } else {
        var msg = (res.data && res.data.message) ? res.data.message : 'Error.';
        statusEl.css('color', '#d63638').text(msg);
        btn.text(optedOut ? 'Mark opted out' : 'Remove opt-out');
      }
    }).fail(function () {
      btn.prop('disabled', false).text(optedOut ? 'Mark opted out' : 'Remove opt-out');
      statusEl.css('color', '#d63638').text('Request failed.');
    });
  });

  /* -----------------------------------------------------------------------
     Settings — Categories tab
     ----------------------------------------------------------------------- */
  if ($('#wpq-cat-tbody').length) {

    // Auto-generate slug from name input
    $('#wpq-cat-new-name').on('input', function () {
      var slug = $(this).val().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
      $('#wpq-cat-new-slug').val(slug);
    });

    // Show/hide add form
    $('#wpq-cat-add-btn').on('click', function () {
      $('#wpq-cat-add-form').removeClass('wpq-hidden');
      $('#wpq-cat-new-name').focus();
    });
    $('#wpq-cat-create-cancel-btn').on('click', function () {
      $('#wpq-cat-add-form').addClass('wpq-hidden');
      $('#wpq-cat-new-name, #wpq-cat-new-slug').val('');
      $('#wpq-cat-new-order').val('0');
      $('#wpq-cat-create-status').addClass('wpq-hidden').text('');
    });

    // Create category
    $('#wpq-cat-create-btn').on('click', function () {
      var name  = $('#wpq-cat-new-name').val().trim();
      var slug  = $('#wpq-cat-new-slug').val().trim();
      var order = parseInt($('#wpq-cat-new-order').val(), 10) || 0;
      var statusEl = $('#wpq-cat-create-status');
      if (!name || !slug) {
        statusEl.removeClass('wpq-hidden').css('color', '#d63638').text('Name and Slug are required.');
        return;
      }
      var btn = $(this).prop('disabled', true).text('Saving…');
      $.post(wpqAdmin.ajaxUrl, {
        action: 'wpq_create_category', nonce: wpqAdmin.nonce,
        name: name, slug: slug, sort_order: order,
      }, function (res) {
        btn.prop('disabled', false).text('Create');
        if (res.success) {
          statusEl.addClass('wpq-hidden');
          var row = '<tr data-cat-id="' + res.data.id + '">' +
            '<td>' + res.data.sort_order + '</td>' +
            '<td><code>' + $('<span>').text(res.data.slug).html() + '</code></td>' +
            '<td class="wpq-cat-name-cell">' +
              '<span class="wpq-cat-name-display">' + $('<span>').text(res.data.name).html() + '</span>' +
              '<span class="wpq-cat-edit-wrap wpq-hidden">' +
                '<input type="text" class="wpq-cat-name-input regular-text" value="' + $('<span>').text(res.data.name).html() + '">' +
                '<input type="number" class="wpq-cat-order-input small-text" value="' + res.data.sort_order + '" min="0" style="width:56px;margin-left:8px;" title="Sort order">' +
              '</span>' +
            '</td>' +
            '<td>' +
              '<span class="wpq-cat-view-actions">' +
                '<button type="button" class="button button-small wpq-cat-edit-btn">Edit</button>' +
                '<button type="button" class="button button-small wpq-cat-delete-btn" style="margin-left:4px;" data-name="' + $('<span>').text(res.data.name).html() + '">Delete</button>' +
              '</span>' +
              '<span class="wpq-cat-edit-actions wpq-hidden">' +
                '<button type="button" class="button button-primary button-small wpq-cat-save-btn">Save</button>' +
                '<button type="button" class="button button-small wpq-cat-cancel-btn" style="margin-left:4px;">Cancel</button>' +
                '<span class="wpq-cat-row-status" style="margin-left:6px;font-size:.85em;"></span>' +
              '</span>' +
            '</td>' +
          '</tr>';
          $('#wpq-cat-empty').remove();
          $('#wpq-cat-tbody').append(row);
          $('#wpq-cat-new-name, #wpq-cat-new-slug').val('');
          $('#wpq-cat-new-order').val('0');
          $('#wpq-cat-add-form').addClass('wpq-hidden');
        } else {
          var msg = (res.data && res.data.message) ? res.data.message : 'Error creating category.';
          statusEl.removeClass('wpq-hidden').css('color', '#d63638').text(msg);
        }
      }).fail(function () {
        btn.prop('disabled', false).text('Create');
        statusEl.removeClass('wpq-hidden').css('color', '#d63638').text('Request failed.');
      });
    });

    // Edit row — toggle display/edit mode
    $(document).on('click', '.wpq-cat-edit-btn', function () {
      var row = $(this).closest('tr');
      row.find('.wpq-cat-name-display, .wpq-cat-view-actions').addClass('wpq-hidden');
      row.find('.wpq-cat-edit-wrap, .wpq-cat-edit-actions').removeClass('wpq-hidden');
      row.find('.wpq-cat-name-input').focus();
    });

    $(document).on('click', '.wpq-cat-cancel-btn', function () {
      var row = $(this).closest('tr');
      row.find('.wpq-cat-name-display, .wpq-cat-view-actions').removeClass('wpq-hidden');
      row.find('.wpq-cat-edit-wrap, .wpq-cat-edit-actions').addClass('wpq-hidden');
      row.find('.wpq-cat-row-status').text('');
    });

    // Save edit
    $(document).on('click', '.wpq-cat-save-btn', function () {
      var row  = $(this).closest('tr');
      var id   = row.data('catId');
      var name = row.find('.wpq-cat-name-input').val().trim();
      var order = parseInt(row.find('.wpq-cat-order-input').val(), 10) || 0;
      var statusEl = row.find('.wpq-cat-row-status');
      if (!name) { statusEl.css('color', '#d63638').text('Name required.'); return; }
      var btn = $(this).prop('disabled', true).text('Saving…');
      $.post(wpqAdmin.ajaxUrl, {
        action: 'wpq_update_category', nonce: wpqAdmin.nonce,
        id: id, name: name, sort_order: order,
      }, function (res) {
        btn.prop('disabled', false).text('Save');
        if (res.success) {
          row.find('.wpq-cat-name-display').text(name);
          row.find('td:first').text(order);
          row.find('.wpq-cat-delete-btn').data('name', name).attr('data-name', name);
          row.find('.wpq-cat-name-display, .wpq-cat-view-actions').removeClass('wpq-hidden');
          row.find('.wpq-cat-edit-wrap, .wpq-cat-edit-actions').addClass('wpq-hidden');
          statusEl.text('');
        } else {
          var msg = (res.data && res.data.message) ? res.data.message : 'Error saving.';
          statusEl.css('color', '#d63638').text(msg);
        }
      }).fail(function () {
        btn.prop('disabled', false).text('Save');
        statusEl.css('color', '#d63638').text('Request failed.');
      });
    });

    // Delete row
    $(document).on('click', '.wpq-cat-delete-btn', function () {
      var row  = $(this).closest('tr');
      var name = $(this).data('name');
      var id   = row.data('catId');
      if (!confirm('Delete category "' + name + '"?\n\nQuestionnaires using this category will retain their current value but it will no longer appear in the dropdown.')) return;
      var btn = $(this).prop('disabled', true).text('Deleting…');
      $.post(wpqAdmin.ajaxUrl, {
        action: 'wpq_delete_category', nonce: wpqAdmin.nonce, id: id,
      }, function (res) {
        if (res.success) {
          row.fadeOut(300, function () {
            $(this).remove();
            if ($('#wpq-cat-tbody tr').length === 0) {
              $('#wpq-cat-tbody').append('<tr id="wpq-cat-empty"><td colspan="4">No categories found.</td></tr>');
            }
          });
        } else {
          btn.prop('disabled', false).text('Delete');
          var msg = (res.data && res.data.message) ? res.data.message : 'Error deleting.';
          alert('Error: ' + msg);
        }
      }).fail(function () {
        btn.prop('disabled', false).text('Delete');
        alert('Request failed.');
      });
    });
  }

  /* -----------------------------------------------------------------------
     Client-side sortable tables
     Tables with data-wpq-sortable="true" get clickable column headers.
     Add data-no-sort to a <th> to exclude it (action columns, checkboxes).
     ----------------------------------------------------------------------- */
  function wpqInitSortable() {
    $('table[data-wpq-sortable]').each(function () {
      var table = $(this);
      table.find('thead th:not([data-no-sort])').each(function () {
        var th = $(this);
        if (th.text().trim() === '') return;
        th.addClass('wpq-th-sortable');
        th.on('click.wpqSort', function () {
          var asc = !th.hasClass('wpq-sort-asc');
          table.find('thead th').removeClass('wpq-sort-asc wpq-sort-desc');
          th.addClass(asc ? 'wpq-sort-asc' : 'wpq-sort-desc');
          var colIndex = th.index();
          var tbody = table.find('tbody');
          var rows = tbody.find('tr').toArray();
          if (rows.length <= 1) return;
          rows.sort(function (a, b) {
            var aVal = $(a).find('td').eq(colIndex).text().trim();
            var bVal = $(b).find('td').eq(colIndex).text().trim();
            var aStripped = aVal.replace(/[^0-9.-]/g, '');
            var bStripped = bVal.replace(/[^0-9.-]/g, '');
            var aNum = parseFloat(aStripped);
            var bNum = parseFloat(bStripped);
            var cmp;
            if (!isNaN(aNum) && !isNaN(bNum) && aStripped !== '') {
              cmp = aNum - bNum;
            } else {
              cmp = aVal.toLowerCase().localeCompare(bVal.toLowerCase());
            }
            return asc ? cmp : -cmp;
          });
          $.each(rows, function (i, row) { tbody.append(row); });
        });
      });
    });
  }
  wpqInitSortable();

  /* -----------------------------------------------------------------------
     Client-side table filter
     Inputs with class .wpq-table-filter filter the next sibling <table>'s
     tbody rows by matching against each row's full text content.
     ----------------------------------------------------------------------- */
  $(document).on('input', '.wpq-table-filter', function () {
    var q        = $(this).val().toLowerCase();
    var bar      = $(this).closest('div');
    var countEl  = bar.find('.wpq-table-filter-count');
    var table    = bar.nextAll('table').first();
    var rows     = table.find('tbody tr');
    var total    = rows.length;
    var visible  = 0;

    rows.each(function () {
      var match = !q || $(this).text().toLowerCase().indexOf(q) !== -1;
      $(this).toggle(match);
      if (match) visible++;
    });

    if (q) {
      countEl.text(visible + ' of ' + total + ' shown');
    } else {
      countEl.text('');
    }
  });

})(jQuery);
