<?php
/**
 * Plugin Name: WP Questionnaires
 * Plugin URI:  https://alltimetech.co.uk
 * Description: Assessment and lead generation platform. Publishes scored questionnaires, captures leads, syncs to HaloPSA, and sells branded PDF reports via Stripe.
 * Version:     1.11.73
 * Author:      Simon Jackson @ Alltime Technologies Ltd
 * Author URI:  https://alltimetech.co.uk
 * License:     Proprietary
 * Text Domain: wp-questionnaires
 * Requires PHP: 8.1
 * Requires at least: 6.4
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPQ_VERSION',          '1.11.73' );
define( 'WPQ_DB_VERSION',       '1.27.0' );
define( 'WPQ_PLUGIN_FILE',      __FILE__ );
define( 'WPQ_PLUGIN_DIR',       plugin_dir_path( __FILE__ ) );
define( 'WPQ_PLUGIN_URL',       plugin_dir_url( __FILE__ ) );
define( 'WPQ_PLUGIN_BASENAME',  plugin_basename( __FILE__ ) );
define( 'WPQ_REST_NAMESPACE',   'wpq/v1' );

// Phase 3 gate — set true once Stripe checkout endpoints are deployed.
if ( ! defined( 'WPQ_CHECKOUT_ENABLED' ) ) {
	define( 'WPQ_CHECKOUT_ENABLED', false );
}

// Set true only when REMOTE_ADDR is always a trusted reverse proxy that
// sanitises inbound X-Forwarded-For before forwarding to PHP.
if ( ! defined( 'WPQ_TRUST_PROXY_IP' ) ) {
	define( 'WPQ_TRUST_PROXY_IP', false );
}

$autoload = WPQ_PLUGIN_DIR . 'vendor/autoload.php';
if ( is_readable( $autoload ) ) {
	require_once $autoload;
}

require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-activator.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-deactivator.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-database.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-secrets.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-claude.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-stripe.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-report-renderer.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-remediation-plan.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-claude-client.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-scoring.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-library-importer.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-seeder.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-import-export.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-plugin.php';
require_once WPQ_PLUGIN_DIR . 'includes/class-wpq-updater.php';

register_activation_hook( WPQ_PLUGIN_FILE,   [ 'WPQ_Activator',   'activate'   ] );
register_deactivation_hook( WPQ_PLUGIN_FILE, [ 'WPQ_Deactivator', 'deactivate' ] );
add_action( 'admin_init', [ 'WPQ_Activator', 'ensure_schema_current' ] );

// Plugin updater — runs in admin and WP-Cron contexts (where update checks fire).
if ( is_admin() || wp_doing_cron() ) {
	add_action( 'plugins_loaded', static function (): void {
		new WPQ_Updater();
	} );
}

function wpq(): WPQ_Plugin {
	return WPQ_Plugin::instance();
}

wpq();
