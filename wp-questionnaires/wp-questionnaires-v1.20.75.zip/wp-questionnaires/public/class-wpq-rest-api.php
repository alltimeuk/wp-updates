<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_REST_API {
	private const REPORT_DOWNLOAD_HEADER = 'X-WPQ-Report-Download';

	private const DOWNLOAD_KIND_PAID_REPORT           = 'paid_report';
	private const DOWNLOAD_KIND_QUESTIONNAIRE_REPORT  = 'questionnaire_report';
	private const DOWNLOAD_KIND_REMEDIATION_WORKBOOK  = 'remediation_workbook';

	/** @var array<string, string> */
	private static array $report_download_paths = [];

	public static function checkout_capabilities(): array {
		return [
			'checkout'                => method_exists( self::class, 'create_checkout' ) && class_exists( 'WPQ_Stripe' ),
			'webhook'                 => method_exists( self::class, 'stripe_webhook' ) && method_exists( 'WPQ_Database', 'insert_payment_event' ),
			'report_delivery'         => method_exists( self::class, 'download_report' ) && method_exists( 'WPQ_Database', 'consume_report_token' ),
			'report_template'         => class_exists( 'WPQ_Report_Renderer' ) && WPQ_Report_Renderer::template_available(),
			'report_renderer'         => class_exists( 'WPQ_Report_Renderer' ) && WPQ_Report_Renderer::can_render(),
			'report_storage_delivery' => class_exists( 'WPQ_Report_Renderer' ) && WPQ_Report_Renderer::storage_available(),
			'stripe_api_initialised'  => class_exists( 'WPQ_Stripe' ) && WPQ_Stripe::can_initialise(),
		];
	}

	public static function is_checkout_publicly_available(): bool {
		if ( ! ( class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::checkout_enabled() : ( defined( 'WPQ_CHECKOUT_ENABLED' ) && WPQ_CHECKOUT_ENABLED ) ) ) {
			return false;
		}

		$capabilities = self::checkout_capabilities();
		foreach ( [ 'checkout', 'webhook', 'report_delivery', 'report_template', 'report_renderer', 'report_storage_delivery', 'stripe_api_initialised' ] as $capability ) {
			if ( empty( $capabilities[ $capability ] ) ) {
				return false;
			}
		}

		return true;
	}

	public static function register_routes(): void {
		// Questionnaire structure (public - no auth needed).
		register_rest_route( WPQ_REST_NAMESPACE, '/questionnaire/(?P<ref>[A-Z][A-Z0-9_-]{1,29})', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'get_questionnaire' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'ref' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// Public write endpoints carry declarative request schemas (REST args)
		// so malformed types are rejected with a structured 400 before the
		// callback runs. Handlers keep their own validation as defence in
		// depth - the schema is a contract, not a replacement.

		// Lead capture.
		register_rest_route( WPQ_REST_NAMESPACE, '/lead', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'submit_lead' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'ref'               => [ 'type' => 'string', 'required' => true, 'minLength' => 2, 'maxLength' => 30 ],
				'contact_name'      => [ 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 255 ],
				'contact_email'     => [ 'type' => 'string', 'required' => true, 'format' => 'email', 'maxLength' => 254 ],
				'contact_company'   => [ 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 255 ],
				'contact_phone'     => [ 'type' => 'string', 'maxLength' => 30 ],
				'consent'           => [ 'type' => [ 'boolean', 'integer', 'string' ] ],
				'marketing_consent' => [ 'type' => [ 'boolean', 'integer', 'string' ] ],
				'turnstile_token'   => [ 'type' => 'string', 'maxLength' => 4096 ],
			],
		] );

		// Heartbeat (update last answered question).
		register_rest_route( WPQ_REST_NAMESPACE, '/heartbeat', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'heartbeat' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'submission_id' => [ 'type' => 'integer', 'required' => true, 'minimum' => 1 ],
				'session_token' => [ 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 128 ],
				'last_question' => [ 'type' => 'string', 'maxLength' => 50 ],
				'answers'       => [ 'type' => 'object' ],
			],
		] );

		// Assessment submission.
		register_rest_route( WPQ_REST_NAMESPACE, '/submit', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'submit_assessment' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'submission_id' => [ 'type' => 'integer', 'required' => true, 'minimum' => 1 ],
				'session_token' => [ 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 128 ],
				'answers'       => [ 'type' => 'object', 'required' => true ],
			],
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/checkout', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'create_checkout' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'submission_id' => [ 'type' => 'integer', 'required' => true, 'minimum' => 1 ],
				'session_token' => [ 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 128 ],
				'product_id'    => [ 'type' => 'integer', 'required' => true, 'minimum' => 1 ],
			],
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/stripe/webhook', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'stripe_webhook' ],
			'permission_callback' => '__return_true',
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/reports/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'download_report' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/remediation-workbook/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'download_remediation_workbook' ],
			'permission_callback' => '__return_true',
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/remediation-plan', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'download_remediation_plan' ],
			'permission_callback' => '__return_true',
		] );

		// Customer delivery of the Questionnaire Report. The download route is
		// authorised by a single-purpose expiring token (emailed, or minted for the
		// results/post-checkout screen); the status route is authorised by the
		// submission's own session token, because generation is asynchronous and
		// the results screen has to be able to ask whether the report is ready yet.
		register_rest_route( WPQ_REST_NAMESPACE, '/questionnaire-report/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'download_questionnaire_report' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/questionnaire-report-status/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'questionnaire_report_status' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// Customer-initiated: the results screen offers a "Generate your
		// assessment report" button rather than starting generation silently on
		// submit, so a failure is a visible, retryable state instead of an
		// indefinite "being prepared" with nothing actually running.
		register_rest_route( WPQ_REST_NAMESPACE, '/questionnaire-report-request/(?P<id>\d+)', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'questionnaire_report_request' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// Save-and-resume: mint a resume link for an in-progress assessment
		// (session-token authorised), and redeem one (resume-token authorised,
		// or session-token authorised for same-device continuation).
		register_rest_route( WPQ_REST_NAMESPACE, '/resume-link', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'create_resume_link' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'submission_id' => [ 'type' => 'integer', 'required' => true, 'minimum' => 1 ],
				'session_token' => [ 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 128 ],
				'page_url'      => [ 'type' => 'string', 'format' => 'uri', 'maxLength' => 2048 ],
				'email'         => [ 'type' => [ 'boolean', 'integer', 'string' ] ],
			],
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/resume', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'resume_session' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'token' => [ 'type' => 'string', 'maxLength' => 128 ],
			],
		] );

		register_rest_route( WPQ_REST_NAMESPACE, '/enquiry', [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'submit_enquiry' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'ref'             => [ 'type' => 'string', 'required' => true, 'minLength' => 2, 'maxLength' => 30 ],
				'contact_name'    => [ 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 200 ],
				'contact_email'   => [ 'type' => 'string', 'required' => true, 'format' => 'email', 'maxLength' => 190 ],
				'contact_company' => [ 'type' => 'string', 'maxLength' => 200 ],
				'contact_phone'   => [ 'type' => 'string', 'maxLength' => 50 ],
				'consent'         => [ 'type' => [ 'boolean', 'integer', 'string' ], 'required' => true ],
				'fields'          => [ 'type' => 'object' ],
				'website'         => [ 'type' => 'string', 'maxLength' => 255 ],
				'turnstile_token' => [ 'type' => 'string', 'maxLength' => 4096 ],
			],
		] );
	}

	/**
	 * POST /wpq/v1/enquiry - receive a public enquiry-form submission.
	 *
	 * Validates against the composed form definition (unknown fields are
	 * discarded, choice answers must match defined options), stores the
	 * enquiry, and sends the notification and optional acknowledgement emails
	 * through WPQ_Mailer - gated by the global mail switch and the form's own
	 * setting. Mail failure never fails the enquiry: it is stored either way.
	 */
	public static function submit_enquiry( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'enquiry', 5, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		// Honeypot: a hidden field real users never fill. Bots that do are told
		// everything went fine and nothing is stored.
		if ( '' !== trim( (string) ( $body['website'] ?? '' ) ) ) {
			return new WP_REST_Response( [ 'status' => 'ok' ], 200 );
		}

		$form = WPQ_Database::get_enquiry_form_by_ref( sanitize_text_field( (string) ( $body['ref'] ?? '' ) ) );
		if ( ! $form || 'published' !== (string) $form->status ) {
			return self::error( 404, 'NOT_FOUND', 'Enquiry form not found.' );
		}

		if ( class_exists( 'WPQ_Turnstile' ) && WPQ_Turnstile::required_for_form( $form )
			&& ! WPQ_Turnstile::verify( sanitize_text_field( $body['turnstile_token'] ?? '' ), self::get_client_ip() ) ) {
			return self::error( 403, 'TURNSTILE_FAILED', 'Verification failed. Please reload the page and try again.' );
		}

		$contact_name  = mb_substr( sanitize_text_field( (string) ( $body['contact_name'] ?? '' ) ), 0, 200 );
		$contact_email = sanitize_email( (string) ( $body['contact_email'] ?? '' ) );
		if ( '' === trim( $contact_name ) || '' === $contact_email || ! is_email( $contact_email ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'A name and a valid email address are required.' );
		}
		if ( empty( $body['consent'] ) ) {
			return self::error( 400, 'CONSENT_REQUIRED', 'Consent is required to submit an enquiry.' );
		}

		$definitions = WPQ_Enquiry::decode_field_definitions( $form->fields_json ?? null );
		$validated   = WPQ_Enquiry::validate_responses( $definitions, $body['fields'] ?? [] );
		if ( ! $validated['valid'] ) {
			return self::error( 400, 'INVALID_FIELDS', $validated['message'] );
		}

		$ref        = WPQ_Enquiry::generate_ref();
		$enquiry_id = WPQ_Database::insert_enquiry( [
			'form_id'         => (int) $form->id,
			'ref'             => $ref,
			'contact_name'    => $contact_name,
			'contact_email'   => $contact_email,
			'contact_company' => (string) ( $body['contact_company'] ?? '' ),
			'contact_phone'   => (string) ( $body['contact_phone'] ?? '' ),
			'consent'         => true,
			'fields_json'     => (string) wp_json_encode( $validated['values'] ),
		] );
		if ( $enquiry_id <= 0 ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not store the enquiry.' );
		}

		self::link_enquiry_to_contact( $enquiry_id, $ref, [
			'name'         => $contact_name,
			'email'        => $contact_email,
			'telephone'    => (string) ( $body['contact_phone'] ?? '' ),
			'organisation' => (string) ( $body['contact_company'] ?? '' ),
		] );

		if ( class_exists( 'WPQ_Mailer' ) && class_exists( 'WPQ_Email_Template' ) && WPQ_Enquiry::mail_allowed_for_form( $form ) ) {
			$enquiry = WPQ_Database::get_enquiry( $enquiry_id );
			if ( $enquiry ) {
				try {
					$notify = WPQ_Enquiry::notify_recipient( $form );
					if ( '' !== $notify ) {
						$subject = 'New enquiry: ' . (string) $form->name . ' (' . $ref . ')';
						$fields  = WPQ_Enquiry::build_notification_fields( $form, $enquiry, $definitions, $validated['values'] );
						WPQ_Mailer::send( $notify, $subject, WPQ_Email_Template::render( array_merge( [ 'subject' => $subject ], $fields ) ) );
					}
					if ( 'yes' === (string) ( $form->send_ack ?? 'no' ) ) {
						$subject = 'We have received your enquiry (' . $ref . ')';
						$fields  = WPQ_Enquiry::build_acknowledgement_fields( $form, $enquiry );
						WPQ_Mailer::send( $contact_email, $subject, WPQ_Email_Template::render( array_merge( [ 'subject' => $subject ], $fields ) ) );
					}
				} catch ( Throwable $e ) {
					update_option( 'wpq_mail_last_error', sanitize_text_field( gmdate( 'Y-m-d H:i:s' ) . ' UTC ' . $e->getMessage() ), false );
				}
			}
		}

		return new WP_REST_Response( [ 'status' => 'ok', 'ref' => $ref ], 200 );
	}

	// ------------------------------------------------------------------ //
	// GET /wpq/v1/questionnaire/{ref}
	// ------------------------------------------------------------------ //

	public static function get_questionnaire( WP_REST_Request $request ): WP_REST_Response {
		$ref           = strtoupper( sanitize_text_field( $request->get_param( 'ref' ) ) );
		$questionnaire = WPQ_Database::get_questionnaire_by_ref( $ref );

		if ( ! $questionnaire ) {
			return self::error( 404, 'NOT_FOUND', 'Questionnaire not found.' );
		}

		$structure = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		// Products are only surfaced when the Stripe checkout is deployed (Phase 3).
		$checkout_available = self::is_checkout_publicly_available();
		$products  = $checkout_available
			? WPQ_Database::get_products_for_questionnaire( (int) $questionnaire->id )
			: [];

		$response = new WP_REST_Response( [
			'status'        => 'ok',
			'ref'           => $questionnaire->ref,
			'name'          => $questionnaire->name,
			'description'   => $questionnaire->description,
			'domains'       => $structure['domains'],
			'thresholds'    => $structure['thresholds'],
			'products'      => array_map( fn( $p ) => [
				'id'                     => (int) $p->id,
				'name'                   => $p->name,
				'slug'                   => $p->slug,
				'description'            => $p->description,
				'price_gbp'              => (float) $p->price_gbp,
				'billing_type'           => $p->billing_type,
				'report_type'            => $p->report_type,
				'available_for_checkout' => $checkout_available,
			], $products ),
		], 200 );

		// An admin edit (reordered options, changed wording, a new grade
		// threshold) must be visible on the very next page load. This is the
		// one GET route a caching layer is most likely to hold onto by URL
		// pattern regardless of WordPress's own REST defaults, since it looks
		// like static content from the outside.
		$response->set_headers( [
			'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
			'Pragma'        => 'no-cache',
		] );

		return $response;
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/lead
	// ------------------------------------------------------------------ //

	public static function submit_lead( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'lead', 5, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$ref = strtoupper( sanitize_text_field( $body['ref'] ?? '' ) );
		if ( ! $ref ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Missing questionnaire ref.' );
		}

		$questionnaire = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $questionnaire ) {
			return self::error( 404, 'NOT_FOUND', 'Questionnaire not found.' );
		}

		if ( class_exists( 'WPQ_Turnstile' ) && WPQ_Turnstile::required_for_questionnaire( $questionnaire )
			&& ! WPQ_Turnstile::verify( sanitize_text_field( $body['turnstile_token'] ?? '' ), self::get_client_ip() ) ) {
			return self::error( 403, 'TURNSTILE_FAILED', 'Verification failed. Please reload the page and try again.' );
		}

		$name    = substr( sanitize_text_field( $body['contact_name']    ?? '' ), 0, 255 );
		$email   = substr( sanitize_email(     $body['contact_email']   ?? '' ), 0, 254 );
		$company = substr( sanitize_text_field( $body['contact_company'] ?? '' ), 0, 255 );
		$phone   = substr( preg_replace( '/[^\d\s\+\(\)\-]/', '', $body['contact_phone'] ?? '' ), 0, 30 );

		if ( ! $name || ! $email || ! $company ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Name, email, and company are required.' );
		}

		if ( ! is_email( $email ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Email address is not valid.' );
		}

		$now               = current_time( 'mysql', true );
		$token             = bin2hex( random_bytes( 32 ) );
		// session_token column stores HMAC-SHA256 keyed with wp_salt('auth'); the raw token is never persisted.
		$token_hash        = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
		$consented         = ! empty( $body['consent'] ) ? $now : null;
		$marketing_consent = ! empty( $body['marketing_consent'] );
		$id                = WPQ_Database::create_submission( [
			'questionnaire_id'    => (int) $questionnaire->id,
			'contact_name'        => $name,
			'contact_email'       => $email,
			'contact_company'     => $company,
			'contact_phone'       => $phone,
			'consent_accepted_at' => $consented,
			'session_token'       => $token_hash,
			'abandoned'           => 1,
			'halopsa_sync_status' => 'pending',
			'started_at'          => $now,
			'utm_source'         => substr( sanitize_text_field( $body['utm_source']   ?? '' ), 0, 255 ) ?: null,
			'utm_medium'         => substr( sanitize_text_field( $body['utm_medium']   ?? '' ), 0, 255 ) ?: null,
			'utm_campaign'       => substr( sanitize_text_field( $body['utm_campaign'] ?? '' ), 0, 255 ) ?: null,
			'utm_term'           => substr( sanitize_text_field( $body['utm_term']     ?? '' ), 0, 255 ) ?: null,
			'utm_content'        => substr( sanitize_text_field( $body['utm_content']  ?? '' ), 0, 255 ) ?: null,
			'referrer_url'       => substr( esc_url_raw( $body['referrer_url']  ?? '' ), 0, 2048 ) ?: null,
			'landing_page'       => substr( esc_url_raw( $body['landing_page']  ?? '' ), 0, 2048 ) ?: null,
			'ip_address'         => self::get_client_ip(),
		] );

		if ( ! $id ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not create submission.' );
		}

		if ( class_exists( 'WPQ_Claude' ) && ! WPQ_Claude::initialise_submission_session( $id ) ) {
			WPQ_Database::log_error( 'WPQ Claude conversation initialisation failed for submission ' . $id );
		}

		self::link_submission_to_contact( $id, [
			'name'         => $name,
			'email'        => $email,
			'telephone'    => $phone,
			'organisation' => $company,
		], (int) $questionnaire->id, 'questionnaire_started', $now, $marketing_consent );

		return new WP_REST_Response( [
			'status'        => 'ok',
			'submission_id' => $id,
			'session_token' => $token,
			'ref'           => sprintf( 'WPQ-%s-%04d', gmdate( 'Ymd' ), $id ),
		], 201 );
	}

	/**
	 * Resolve or create the canonical contact for an enquiry, record the
	 * timeline interaction, and record the consent event the form actually
	 * represents: a service_delivery grant (the enquirer asked to be contacted
	 * about their enquiry) - never a direct-marketing consent.
	 *
	 * @param array{name: string, email: string, telephone: string, organisation: string} $details
	 */
	private static function link_enquiry_to_contact( int $enquiry_id, string $ref, array $details ): void {
		if ( ! class_exists( 'WPQ_Contact_Service' ) || ! WPQ_Contact_Service::enabled() ) {
			return;
		}

		try {
			$service = WPQ_Contact_Service::instance();
			$now     = current_time( 'mysql', true );

			$result = $service->resolve_or_create( $details, [
				'source'      => 'enquiry_endpoint',
				'source_type' => 'enquiry',
				'source_id'   => $enquiry_id,
				'observed_at' => $now,
			] );
			$contact_id = (int) $result['contact_id'];
			if ( $contact_id <= 0 ) {
				return;
			}

			WPQ_Database::link_enquiry_contact( $enquiry_id, $contact_id );

			$service->record_interaction( $contact_id, [
				'interaction_type' => 'enquiry_submitted',
				'source_type'      => 'enquiry',
				'source_id'        => $enquiry_id,
				'source_ref'       => $ref,
				'occurred_at'      => $now,
				'completion_state' => 'completed',
				'organisation'     => $details['organisation'],
			] );

			$service->record_consent_event( $contact_id, [
				'purpose'     => 'service_delivery',
				'event'       => 'granted',
				'source'      => 'enquiry_form',
				'actor'       => 'data_subject',
				'occurred_at' => $now,
				'evidence'    => [ 'enquiry_ref' => $ref, 'consent_checkbox' => true ],
			] );
		} catch ( Throwable $e ) {
			WPQ_Database::log_error( 'WPQ contact resolution failed for enquiry ' . $enquiry_id . ': ' . $e->getMessage() );
		}
	}

	/**
	 * Resolve or create the canonical contact for a submission and record the
	 * timeline interaction. A resolution failure never fails the customer's
	 * request: the submission keeps contact_id NULL, the error is logged, and
	 * the Readiness screen surfaces unlinked counts for reconciliation.
	 *
	 * $marketing_consent records an explicit direct_marketing_email grant -
	 * separate from and never inferred out of service_delivery/interaction
	 * data - only when true. Leaving the (opt-in, unchecked-by-default)
	 * checkbox unticked writes nothing: the absence of a granted event is
	 * itself the correct "not consented" state, so there is no "declined"
	 * event to log for every visitor who simply didn't opt in.
	 *
	 * @param array{name: string, email: string, telephone: string, organisation: string} $details
	 */
	private static function link_submission_to_contact( int $submission_id, array $details, int $questionnaire_id, string $interaction_type, string $occurred_at, bool $marketing_consent = false ): void {
		if ( ! class_exists( 'WPQ_Contact_Service' ) || ! WPQ_Contact_Service::enabled() ) {
			return;
		}

		try {
			$service = WPQ_Contact_Service::instance();

			$submission = WPQ_Database::get_submission( $submission_id );
			$contact_id = (int) ( $submission->contact_id ?? 0 );

			if ( $contact_id <= 0 ) {
				$result = $service->resolve_or_create( $details, [
					'source'      => 'lead_endpoint',
					'source_type' => 'submission',
					'source_id'   => $submission_id,
					'observed_at' => $occurred_at,
				] );
				$contact_id = (int) $result['contact_id'];
				if ( $contact_id > 0 ) {
					WPQ_Database::link_submission_contact( $submission_id, $contact_id );
				}
			}

			if ( $contact_id > 0 ) {
				$service->record_interaction( $contact_id, [
					'interaction_type' => $interaction_type,
					'source_type'      => 'submission',
					'source_id'        => $submission_id,
					'source_ref'       => sprintf( 'WPQ-%s-%04d', gmdate( 'Ymd' ), $submission_id ),
					'questionnaire_id' => $questionnaire_id,
					'occurred_at'      => $occurred_at,
					'completion_state' => 'questionnaire_completed' === $interaction_type ? 'completed' : 'started',
					'organisation'     => $details['organisation'],
				] );

				if ( $marketing_consent ) {
					$service->record_consent_event( $contact_id, [
						'purpose'     => 'direct_marketing_email',
						'event'       => 'granted',
						'source'      => 'lead_endpoint',
						'actor'       => 'data_subject',
						'occurred_at' => $occurred_at,
						'evidence'    => [ 'submission_id' => $submission_id, 'marketing_consent_checkbox' => true ],
					] );
				}
			}
		} catch ( Throwable $e ) {
			WPQ_Database::log_error( 'WPQ contact resolution failed for submission ' . $submission_id . ': ' . $e->getMessage() );
		}
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/heartbeat
	// ------------------------------------------------------------------ //

	public static function heartbeat( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'heartbeat', 30, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body          = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token         = sanitize_text_field( $body['session_token'] ?? '' );
		$last_key      = sanitize_text_field( $body['last_question'] ?? '' );

		if ( ! $submission_id || ! $token || ! $last_key ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id, session_token, and last_question are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}

		$update = [ 'last_question_answered' => $last_key ];

		// Persist the partial answers alongside the position marker, so a
		// resumed session restores every answer given so far - but never
		// overwrite the answers of an already-completed submission.
		if ( empty( $submission->completed_at ) && isset( $body['answers'] ) && class_exists( 'WPQ_Session_Resume' ) ) {
			$partial = WPQ_Session_Resume::sanitise_partial_answers( $body['answers'] );
			if ( null !== $partial ) {
				$encoded = wp_json_encode( $partial );
				if ( is_string( $encoded ) && strlen( $encoded ) <= 131072 ) {
					$update['answers_json'] = $encoded;
				}
			}
		}

		if ( ! WPQ_Database::update_submission( $submission_id, $update ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission.' );
		}

		return new WP_REST_Response( [ 'status' => 'ok' ], 200 );
	}

	/**
	 * POST /wpq/v1/resume-link - mint (and optionally email) a resume link for
	 * an in-progress assessment. Authorised by the submission's own session
	 * token; the link itself carries a separate purpose-scoped token, so the
	 * session credential never appears in a URL or mailbox.
	 */
	public static function create_resume_link( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'resume_link', 6, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token         = sanitize_text_field( (string) ( $body['session_token'] ?? '' ) );
		$page_url      = esc_url_raw( (string) ( $body['page_url'] ?? '' ) );
		$send_email    = ! empty( $body['email'] );

		if ( ! $submission_id || '' === $token || '' === $page_url ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id, session_token, and page_url are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}

		try {
			$link = WPQ_Session_Resume::mint_link( $submission, $page_url );
		} catch ( Throwable $e ) {
			return self::error( 400, 'RESUME_LINK_FAILED', $e instanceof RuntimeException ? $e->getMessage() : 'Could not create a resume link.' );
		}

		$emailed = false;
		if ( $send_email ) {
			$emailed = WPQ_Session_Resume::email_link( $submission, $link['url'], $link['expires_days'] );
		}

		return new WP_REST_Response( [
			'resume_url'   => $link['url'],
			'expires_days' => $link['expires_days'],
			'emailed'      => $emailed,
		], 200 );
	}

	/**
	 * POST /wpq/v1/resume - hydrate an in-progress assessment.
	 *
	 * Two authorisation paths: a resume token from an emailed/copied link
	 * (which rotates the session credential), or the submission's current
	 * session token for same-device continuation (no rotation).
	 */
	public static function resume_session( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'resume', 10, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$resume_token = sanitize_text_field( (string) ( $body['token'] ?? '' ) );

		if ( '' !== $resume_token ) {
			try {
				$payload = WPQ_Session_Resume::redeem( $resume_token );
			} catch ( Throwable $e ) {
				return self::error( 410, 'RESUME_EXPIRED', $e instanceof RuntimeException ? $e->getMessage() : 'This resume link is no longer valid.' );
			}
			if ( 'completed' === $payload['status'] ) {
				return self::error( 409, 'ALREADY_COMPLETED', 'This assessment has already been submitted.' );
			}
			return new WP_REST_Response( $payload, 200 );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$session_token = sanitize_text_field( (string) ( $body['session_token'] ?? '' ) );
		if ( ! $submission_id || '' === $session_token ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'A resume token, or submission_id and session_token, are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || ! WPQ_Database::verify_submission_session_token( $submission, $session_token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}
		if ( ! empty( $submission->completed_at ) ) {
			return self::completed_resume_response( $submission, $session_token );
		}

		return new WP_REST_Response( WPQ_Session_Resume::progress_payload( $submission, $session_token ), 200 );
	}

	/**
	 * Same-device resume of an already-completed submission (e.g. a page
	 * refresh after finishing): restore the exact results screen the
	 * customer already saw instead of losing it. Rebuilt from the stored
	 * scoring snapshot - see WPQ_Scoring::build_micro_report_from_submission().
	 * Never re-triggers report generation; only reports its current state.
	 */
	private static function completed_resume_response( object $submission, string $session_token ): WP_REST_Response {
		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			return self::error( 404, 'NOT_FOUND', 'Questionnaire not found.' );
		}

		$structure    = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		$domain_breakdown_mode = class_exists( 'WPQ_Feature_Flags' )
			? WPQ_Feature_Flags::domain_breakdown_visualisation_mode_for_questionnaire( $questionnaire )
			: null;
		$micro_report = WPQ_Scoring::build_micro_report_from_submission( $submission, $structure, $domain_breakdown_mode );

		$micro_report['status']             = 'completed';
		$micro_report['submission_id']      = (int) $submission->id;
		$micro_report['session_token']      = $session_token;
		$micro_report['questionnaire_ref']  = (string) ( $questionnaire->ref ?? '' );
		$micro_report['ctas']               = WPQ_Database::get_result_ctas(
			(string) ( $questionnaire->category ?? '' ),
			self::domain_slugs_from_actions( $micro_report['top_actions'] ),
			self::contact_from_submission( $submission )
		);
		$micro_report['report_delivery']    = class_exists( 'WPQ_Questionnaire_Report_Delivery' )
			? WPQ_Questionnaire_Report_Delivery::state_for_submission( $submission, $questionnaire )
			: [];
		$micro_report['remediation_plan_generated'] = ! empty( $submission->remediation_last_generated_at );

		return new WP_REST_Response( $micro_report, 200 );
	}

	// ------------------------------------------------------------------ //
	// POST /wpq/v1/submit
	// ------------------------------------------------------------------ //

	public static function submit_assessment( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'submit', 10, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token         = sanitize_text_field( $body['session_token'] ?? '' );
		$answers       = $body['answers'] ?? null;

		if ( ! $submission_id || ! $token || ! is_array( $answers ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id, session_token, and answers are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission record not found.' );
		}

		if ( ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}

		// Prevent replaying a session token to overwrite an already-completed submission.
		if ( $submission->completed_at ) {
			return self::error( 409, 'ALREADY_COMPLETED', 'This assessment has already been submitted.' );
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			return self::error( 404, 'NOT_FOUND', 'Questionnaire not found.' );
		}

		$structure  = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		$validation = WPQ_Scoring::validate( $answers, $structure );

		if ( $validation !== true ) {
			return self::error( 400, $validation['code'], $validation['message'] );
		}

		$result = WPQ_Scoring::score( $answers, $structure );
		$now    = current_time( 'mysql', true );
		$started = $submission->started_at ?? $now;
		$duration = max( 0, strtotime( $now ) - strtotime( $started ) );
		$ctas = WPQ_Database::get_result_ctas(
			(string) ( $questionnaire->category ?? '' ),
			self::domain_slugs_from_actions( $result['top_actions'] ),
			self::contact_from_submission( $submission )
		);

		$update_data = array_merge( [
			'overall_score'         => $result['overall_score'],
			'grade_id'              => $result['grade']['grade_id'],
			'answers_json'          => wp_json_encode( $answers ),
			'domain_scores_json'    => wp_json_encode( $result['domain_scores'] ),
			'findings_json'         => wp_json_encode( $result['findings'] ),
			'abandoned'             => 0,
			'completed_at'          => $now,
			'duration_seconds'      => $duration,
			'last_question_answered'=> null,
		], self::submission_snapshot_fields( $questionnaire, $structure, $ctas ) );

		if ( ! WPQ_Database::update_submission( $submission_id, $update_data ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission.' );
		}

		if ( class_exists( 'WPQ_Framework_Readiness_Job' ) ) {
			try {
				WPQ_Framework_Readiness_Job::request_generation( $submission_id );
			} catch ( Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Best-effort: framework readiness must never block a completed submission's response.
				unset( $e );
			}
		}

		self::link_submission_to_contact( $submission_id, [
			'name'         => (string) ( $submission->contact_name ?? '' ),
			'email'        => (string) ( $submission->contact_email ?? '' ),
			'telephone'    => (string) ( $submission->contact_phone ?? '' ),
			'organisation' => (string) ( $submission->contact_company ?? '' ),
		], (int) $submission->questionnaire_id, 'questionnaire_completed', $now );

		$domain_breakdown_mode = class_exists( 'WPQ_Feature_Flags' )
			? WPQ_Feature_Flags::domain_breakdown_visualisation_mode_for_questionnaire( $questionnaire )
			: null;
		$micro_report = WPQ_Scoring::build_micro_report( $result, $domain_breakdown_mode );
		$micro_report['ctas'] = $ctas;
		$micro_report['report_delivery'] = self::start_questionnaire_report_delivery( $submission_id, $questionnaire );
		$micro_report['remediation_plan_generated'] = ! empty( $submission->remediation_last_generated_at );

		return new WP_REST_Response( $micro_report, 200 );
	}

	/**
	 * Describe what the results screen should offer for the Questionnaire
	 * Report, when the questionnaire has any delivery channel enabled.
	 *
	 * Generation is customer-initiated (the results screen offers a "Generate
	 * your assessment report" button - see questionnaire_report_request()),
	 * not started automatically here: an auto-triggered background job that
	 * silently failed to queue used to leave the customer staring at "being
	 * prepared" forever with nothing running and no way to retry.
	 *
	 * @return array{channels: array<int,string>, status: string, message: string, download_url: string}
	 */
	private static function start_questionnaire_report_delivery( int $submission_id, object $questionnaire ): array {
		$empty = [ 'channels' => [], 'status' => 'unavailable', 'message' => '', 'download_url' => '' ];

		if ( ! class_exists( 'WPQ_Questionnaire_Report_Delivery' ) || ! class_exists( 'WPQ_Questionnaire_Report' ) ) {
			return $empty;
		}
		if ( ! WPQ_Questionnaire_Report_Delivery::delivery_enabled( $questionnaire ) ) {
			return $empty;
		}

		$submission = WPQ_Database::get_submission( $submission_id );

		return $submission
			? WPQ_Questionnaire_Report_Delivery::state_for_submission( $submission, $questionnaire )
			: $empty;
	}

	public static function download_remediation_plan( WP_REST_Request $request ): WP_REST_Response {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token = sanitize_text_field( $body['session_token'] ?? '' );
		$days = (int) ( $body['days'] ?? 30 );
		if ( ! in_array( $days, [ 30, 60, 90 ], true ) ) {
			$days = 30;
		}

		if ( ! $submission_id || ! $token ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id and session_token are required.' );
		}

		if ( ! WPQ_Remediation_Plan::is_configured() ) {
			return self::error( 409, 'REMEDIATION_NOT_CONFIGURED', 'Remediation plan generation is not configured.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission record not found.' );
		}
		if ( ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}
		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire || ( class_exists( 'WPQ_Feature_Flags' ) && ! WPQ_Feature_Flags::remediation_plan_download_enabled_for_questionnaire( $questionnaire ) ) ) {
			return self::error( 403, 'REMEDIATION_DISABLED', 'Remediation plan downloads are disabled for this questionnaire.' );
		}

		$direct_allowed = ! class_exists( 'WPQ_Remediation_Delivery' )
			|| WPQ_Remediation_Delivery::channel_enabled( $questionnaire, WPQ_Remediation_Delivery::CHANNEL_RESULTS_DOWNLOAD );
		$email_wanted   = class_exists( 'WPQ_Remediation_Delivery' )
			&& WPQ_Remediation_Delivery::channel_enabled( $questionnaire, WPQ_Remediation_Delivery::CHANNEL_EMAIL );
		if ( ! $direct_allowed && ! $email_wanted ) {
			return self::error( 403, 'REMEDIATION_DISABLED', 'Remediation plan delivery is disabled for this questionnaire.' );
		}
		if ( empty( $submission->completed_at ) ) {
			return self::error( 409, 'INCOMPLETE_SUBMISSION', 'Remediation plans require a completed assessment.' );
		}

		try {
			$workbook = WPQ_Remediation_Plan::generate_for_submission( $submission, $days );
		} catch ( Throwable $e ) {
			WPQ_Database::log_error( 'WPQ: Remediation plan generation failed for submission ' . $submission_id . ': ' . $e->getMessage() );
			return self::error( 500, 'REMEDIATION_FAILED', 'Could not generate the remediation plan.' );
		}

		// Purely a "has one been made before" signal for the results screen
		// (Generate vs. Download button label) - the plan itself is still
		// generated fresh on every request, never served from storage here.
		WPQ_Database::update_submission_remediation( $submission_id, [
			'remediation_last_generated_at' => current_time( 'mysql', true ),
		] );

		$email_result = $email_wanted
			? WPQ_Remediation_Delivery::deliver_workbook( $submission, $questionnaire, $workbook )
			: [ 'email_sent' => false, 'reason' => 'email_channel_disabled' ];

		if ( ! $direct_allowed ) {
			// Email-only delivery: never hand the binary to the browser.
			return $email_result['email_sent']
				? new WP_REST_Response( [ 'status' => 'emailed' ], 200 )
				: self::error( 500, 'REMEDIATION_EMAIL_FAILED', 'The remediation plan could not be emailed. Please try again or contact us.' );
		}

		return new WP_REST_Response( [
			'status'       => 'ok',
			'filename'     => $workbook['filename'],
			'content_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'file_base64'  => base64_encode( $workbook['binary'] ),
			'email_sent'   => (bool) $email_result['email_sent'],
		], 200 );
	}

	/**
	 * GET /wpq/v1/remediation-workbook/{id}?token=...
	 *
	 * Serves a stored remediation workbook to a customer holding a valid
	 * purpose-scoped delivery token (minted only by the email channel).
	 */
	public static function download_remediation_workbook( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'remediation_workbook_download', 30, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$submission_id = (int) $request->get_param( 'id' );
		$token         = sanitize_text_field( (string) $request->get_param( 'token' ) );
		if ( ! $submission_id || '' === $token ) {
			return self::error( 403, 'FORBIDDEN', 'A valid download link is required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || empty( $submission->remediation_xlsx_path ) ) {
			return self::error( 404, 'NOT_FOUND', 'Workbook is not available.' );
		}

		$resolved_path = class_exists( 'WPQ_Questionnaire_Report_Storage' )
			? WPQ_Questionnaire_Report_Storage::resolve_remediation_xlsx_path( (string) $submission->remediation_xlsx_path )
			: null;
		if ( ! $resolved_path || ! is_readable( $resolved_path ) ) {
			return self::error( 404, 'NOT_FOUND', 'Workbook file not found.' );
		}

		if ( ! WPQ_Database::consume_report_token( $submission_id, $token, WPQ_Remediation_Delivery::TOKEN_PURPOSE ) ) {
			return self::error( 403, 'FORBIDDEN', 'This download link can no longer be used.' );
		}

		return self::deferred_download_response( $resolved_path, self::DOWNLOAD_KIND_REMEDIATION_WORKBOOK );
	}

	public static function create_checkout( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::is_checkout_feature_enabled() ) {
			return self::error( 403, 'CHECKOUT_DISABLED', 'Checkout is not enabled.' );
		}
		if ( ! self::implementation_ready_for_checkout() ) {
			return self::error( 409, 'CHECKOUT_NOT_READY', 'Checkout is not fully configured.' );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'Request body must be valid JSON.' );
		}

		$submission_id = (int) ( $body['submission_id'] ?? 0 );
		$token = sanitize_text_field( $body['session_token'] ?? '' );
		$product_id = (int) ( $body['product_id'] ?? 0 );
		if ( ! $submission_id || ! $token || ! $product_id ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id, session_token, and product_id are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission record not found.' );
		}
		if ( ! WPQ_Database::verify_submission_session_token( $submission, $token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}
		if ( empty( $submission->completed_at ) || (int) ( $submission->abandoned ?? 1 ) !== 0 ) {
			return self::error( 409, 'INCOMPLETE_SUBMISSION', 'Checkout requires a completed assessment.' );
		}
		$current_payment_status = (string) ( $submission->payment_status ?? 'none' );
		if ( ! in_array( $current_payment_status, [ 'none', 'failed', 'expired' ], true ) ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'This submission is not eligible for checkout.' );
		}
		if ( empty( $submission->answers_json ) ) {
			return self::error( 409, 'MISSING_ANSWERS', 'Completed assessment answers are missing.' );
		}

		$product = WPQ_Database::get_product_admin( $product_id );
		if ( ! $product ) {
			return self::error( 404, 'NOT_FOUND', 'Product not found.' );
		}
		if ( ( $product->status ?? '' ) !== 'active' ) {
			return self::error( 409, 'PRODUCT_INACTIVE', 'Product is not active.' );
		}
		if ( (int) ( $product->questionnaire_id ?? 0 ) !== (int) $submission->questionnaire_id ) {
			return self::error( 409, 'PRODUCT_MISMATCH', 'Product does not belong to this questionnaire.' );
		}
		if ( empty( $product->stripe_price_id ) ) {
			return self::error( 409, 'PRODUCT_NOT_CONFIGURED', 'Product does not have a Stripe Price ID.' );
		}
		if ( ( $product->billing_type ?? '' ) !== 'one_off' ) {
			return self::error( 409, 'UNSUPPORTED_BILLING_TYPE', 'Subscriptions are not supported in this phase.' );
		}

		$answers_hash = WPQ_Database::answers_hash( (string) $submission->answers_json );
		$amount_total = self::product_amount_total( $product );
		$currency = 'gbp';

		if ( ! WPQ_Database::transition_payment_status( $submission_id, $current_payment_status, 'pending' ) ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'Could not move submission into pending payment state.' );
		}

		try {
			$stripe_session = WPQ_Stripe::create_checkout_session(
				$submission,
				$product,
				$answers_hash,
				self::checkout_return_url( 'success' ),
				self::checkout_return_url( 'cancel' )
			);
		} catch ( Throwable $e ) {
			self::fail_pending_checkout( $submission_id, '' );
			return self::error( 500, 'STRIPE_ERROR', 'Could not create Stripe Checkout Session.' );
		}

		$stripe_session_id = sanitize_text_field( (string) ( $stripe_session->id ?? '' ) );
		$checkout_url = esc_url_raw( (string) ( $stripe_session->url ?? '' ) );
		if ( $stripe_session_id === '' || $checkout_url === '' ) {
			self::fail_pending_checkout( $submission_id, $stripe_session_id );
			return self::error( 500, 'STRIPE_ERROR', 'Stripe did not return a usable Checkout Session.' );
		}

		if ( ! WPQ_Database::upsert_payment_session( $stripe_session_id, [
			'submission_id'   => $submission_id,
			'product_id'      => $product_id,
			'payment_status'  => 'pending',
			'answers_hash'    => $answers_hash,
			'amount_total'    => $amount_total,
			'currency'        => $currency,
		] ) ) {
			self::fail_pending_checkout( $submission_id, $stripe_session_id );
			return self::error( 500, 'INTERNAL_ERROR', 'Could not record payment session.' );
		}

		if ( ! WPQ_Database::update_submission( $submission_id, [
			'product_id'         => $product_id,
			'stripe_session_id'  => $stripe_session_id,
		] ) ) {
			self::fail_pending_checkout( $submission_id, $stripe_session_id );
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update submission payment details.' );
		}

		return new WP_REST_Response( [
			'status'            => 'ok',
			'checkout_url'      => $checkout_url,
			'stripe_session_id' => $stripe_session_id,
		], 200 );
	}

	public static function stripe_webhook( WP_REST_Request $request ): WP_REST_Response {
		$payload = method_exists( $request, 'get_body' ) ? (string) $request->get_body() : '';
		$signature = method_exists( $request, 'get_header' ) ? (string) $request->get_header( 'stripe-signature' ) : '';
		if ( $signature === '' ) {
			return self::error( 400, 'MISSING_SIGNATURE', 'Missing Stripe signature.' );
		}

		try {
			$event = WPQ_Stripe::construct_webhook_event( $payload, $signature );
		} catch ( Throwable $e ) {
			return self::error( 400, 'INVALID_SIGNATURE', 'Invalid Stripe webhook signature.' );
		}

		$stripe_event_id = sanitize_text_field( (string) ( $event->id ?? '' ) );
		$event_type = sanitize_text_field( (string) ( $event->type ?? '' ) );
		if ( $stripe_event_id === '' ) {
			return self::error( 400, 'INVALID_EVENT', 'Stripe event ID is missing.' );
		}

		$existing_event = WPQ_Database::get_payment_event( $stripe_event_id );
		if ( $existing_event && ! empty( $existing_event->processed_at ) ) {
			return new WP_REST_Response( [ 'status' => 'ok', 'duplicate' => true ], 200 );
		}
		$allowed_events = [
			'checkout.session.completed'            => 'paid',
			'checkout.session.expired'              => 'expired',
			'checkout.session.async_payment_failed' => 'failed',
		];
		if ( ! isset( $allowed_events[ $event_type ] ) ) {
			return new WP_REST_Response( [ 'status' => 'ignored', 'event_type' => $event_type ], 200 );
		}

		$stripe_session = $event->data->object ?? null;
		if ( ! is_object( $stripe_session ) ) {
			return self::error( 400, 'INVALID_EVENT', 'Stripe Checkout Session is missing.' );
		}

		return self::process_checkout_event( $event, $stripe_session, $existing_event, $allowed_events[ $event_type ] );
	}

	public static function download_report( WP_REST_Request $request ): WP_REST_Response {
		$submission_id = (int) $request->get_param( 'id' );
		$token = sanitize_text_field( (string) $request->get_param( 'token' ) );
		if ( ! $submission_id || $token === '' ) {
			return self::error( 403, 'FORBIDDEN', 'A valid report token is required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || ( $submission->payment_status ?? '' ) !== 'paid' ) {
			return self::error( 403, 'FORBIDDEN', 'Report is not available.' );
		}
		$report_path = (string) ( $submission->report_path ?? '' );
		$resolved_path = class_exists( 'WPQ_Report_Renderer' ) ? WPQ_Report_Renderer::resolve_report_path( $report_path ) : null;
		if ( ! $resolved_path ) {
			return self::error( 404, 'NOT_FOUND', 'Report file not found.' );
		}
		if ( strtolower( pathinfo( $resolved_path, PATHINFO_EXTENSION ) ) !== 'pdf' ) {
			return self::error( 404, 'NOT_FOUND', 'Report file not found.' );
		}
		if ( ! is_readable( $resolved_path ) ) {
			return self::error( 404, 'NOT_FOUND', 'Report file not found.' );
		}

		$report_token = WPQ_Database::consume_report_token( $submission_id, $token );
		if ( ! $report_token ) {
			return self::error( 403, 'FORBIDDEN', 'Report token can no longer be used.' );
		}

		return self::report_download_response( $resolved_path );
	}

	/**
	 * GET /wpq/v1/questionnaire-report/{id}?token=...
	 *
	 * Serves the generated Questionnaire Report PDF to a customer holding a valid
	 * delivery token. Deliberately does not consider payment status: whether this
	 * report reaches the customer at all is decided by the questionnaire's
	 * delivery channels, and a token is only ever minted through them.
	 */
	public static function download_questionnaire_report( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'questionnaire_report_download', 30, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$submission_id = (int) $request->get_param( 'id' );
		$token         = sanitize_text_field( (string) $request->get_param( 'token' ) );
		if ( ! $submission_id || '' === $token ) {
			return self::error( 403, 'FORBIDDEN', 'A valid report link is required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || empty( $submission->qr_pdf_path ) ) {
			if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' ) ) {
				WPQ_Questionnaire_Report_Analysis::log_debug_event( 'questionnaire_report_download_denied', [
					'submission_id' => $submission_id,
					'reason'        => $submission ? 'no_pdf_stored' : 'submission_not_found',
				] );
			}
			return self::error( 404, 'NOT_FOUND', 'Report is not available.' );
		}

		$resolved_path = class_exists( 'WPQ_Questionnaire_Report_Storage' )
			? WPQ_Questionnaire_Report_Storage::resolve_pdf_path( (string) $submission->qr_pdf_path )
			: null;
		if ( ! $resolved_path || ! is_readable( $resolved_path ) ) {
			if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' ) ) {
				WPQ_Questionnaire_Report_Analysis::log_debug_event( 'questionnaire_report_download_denied', [
					'submission_id' => $submission_id,
					'reason'        => 'stored_pdf_unreadable',
				] );
			}
			return self::error( 404, 'NOT_FOUND', 'Report is not available.' );
		}

		// Consumed last, so a request that could not have been served does not burn
		// one of the link's limited uses.
		$consumed = WPQ_Database::consume_report_token(
			$submission_id,
			$token,
			WPQ_Questionnaire_Report_Delivery::TOKEN_PURPOSE
		);
		if ( ! $consumed ) {
			if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' ) ) {
				WPQ_Questionnaire_Report_Analysis::log_debug_event( 'questionnaire_report_download_denied', [
					'submission_id' => $submission_id,
					'reason'        => 'token_expired_or_exhausted',
				] );
			}
			return self::error( 403, 'FORBIDDEN', 'This report link has expired or has already been used too many times.' );
		}

		if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' ) ) {
			WPQ_Questionnaire_Report_Analysis::log_debug_event( 'questionnaire_report_downloaded', [
				'submission_id' => $submission_id,
			] );
		}

		return self::questionnaire_report_download_response( $resolved_path );
	}

	/**
	 * GET /wpq/v1/questionnaire-report-status/{id}?session_token=...
	 *
	 * Lets the results screen ask whether an asynchronously generated report is
	 * ready, and what to tell the customer while it is not.
	 */
	public static function questionnaire_report_status( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'questionnaire_report_status', 60, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$submission_id = (int) $request->get_param( 'id' );
		$session_token = sanitize_text_field( (string) $request->get_param( 'session_token' ) );
		if ( ! $submission_id || '' === $session_token ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id and session_token are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission record not found.' );
		}
		if ( ! WPQ_Database::verify_submission_session_token( $submission, $session_token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );

		// The customer's own poll (every 5s while generating) doubles as a
		// retry for the loopback kick that fires an active job: if a job is
		// still queued and no worker has ever picked it up (qr_last_attempt_at
		// never set) more than a few seconds after it was requested, the
		// original kick most likely never landed - re-kick rather than leave
		// the customer staring at "being prepared" for the rest of the
		// 30-day token window with nothing ever making a second attempt.
		if (
			class_exists( 'WPQ_Questionnaire_Report' )
			&& class_exists( 'WPQ_Cron_Kicker' )
			&& in_array( (string) ( $submission->qr_status ?? '' ), WPQ_Questionnaire_Report::ACTIVE_STATES, true )
			&& empty( $submission->qr_last_attempt_at )
			&& ! empty( $submission->qr_requested_at )
			&& ( time() - (int) strtotime( (string) $submission->qr_requested_at . ' UTC' ) ) > 8
		) {
			WPQ_Cron_Kicker::kick();
		}

		return new WP_REST_Response(
			WPQ_Questionnaire_Report_Delivery::state_for_submission( $submission, $questionnaire ),
			200
		);
	}

	/**
	 * POST /wpq/v1/questionnaire-report-request/{id}  Body: {session_token}
	 *
	 * Customer-initiated: starts (or restarts, from not_requested/failed/partial)
	 * Questionnaire Report generation for this submission. Unlike the old
	 * auto-trigger on submit, failures are returned to the caller rather than
	 * silently discarded - the results screen shows them and lets the customer
	 * try again instead of staring at "being prepared" for a job that never ran.
	 */
	public static function questionnaire_report_request( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::check_rate_limit( 'questionnaire_report_request', 10, 60 ) ) {
			return self::error( 429, 'RATE_LIMITED', 'Too many requests. Please try again shortly.' );
		}

		$submission_id = (int) $request->get_param( 'id' );
		$session_token = sanitize_text_field( (string) $request->get_param( 'session_token' ) );
		if ( ! $submission_id || '' === $session_token ) {
			return self::error( 400, 'INVALID_PAYLOAD', 'submission_id and session_token are required.' );
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return self::error( 404, 'NOT_FOUND', 'Submission record not found.' );
		}
		if ( ! WPQ_Database::verify_submission_session_token( $submission, $session_token ) ) {
			return self::error( 403, 'FORBIDDEN', 'Invalid session.' );
		}
		if ( empty( $submission->completed_at ) ) {
			return self::error( 400, 'INCOMPLETE_SUBMISSION', 'The assessment has not been completed yet.' );
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if (
			! $questionnaire
			|| ! class_exists( 'WPQ_Questionnaire_Report_Delivery' )
			|| ! WPQ_Questionnaire_Report_Delivery::delivery_enabled( $questionnaire )
		) {
			if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' ) ) {
				WPQ_Questionnaire_Report_Analysis::log_debug_event( 'questionnaire_report_delivery_disabled', [
					'submission_id'    => $submission_id,
					'questionnaire_id' => $submission->questionnaire_id ?? null,
					'questionnaire_found' => (bool) $questionnaire,
					'channels'         => $questionnaire && class_exists( 'WPQ_Questionnaire_Report_Delivery' )
						? WPQ_Questionnaire_Report_Delivery::channels_for_questionnaire( $questionnaire )
						: [],
				] );
			}
			return self::error( 400, 'REPORT_DELIVERY_DISABLED', 'The assessment report is not available for this questionnaire.' );
		}
		if ( ! class_exists( 'WPQ_Questionnaire_Report' ) || ! WPQ_Questionnaire_Report::is_configured() ) {
			if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' ) ) {
				WPQ_Questionnaire_Report_Analysis::log_debug_event( 'questionnaire_report_not_configured', [
					'submission_id'           => $submission_id,
					'claude_configured'       => class_exists( 'WPQ_Questionnaire_Report_Analysis' ) && WPQ_Questionnaire_Report_Analysis::is_configured(),
					'docx_library_available'  => class_exists( 'WPQ_Docx_Template_Renderer' ) && WPQ_Docx_Template_Renderer::library_available(),
				] );
			}
			return self::error( 400, 'REPORT_NOT_CONFIGURED', 'The assessment report could not be prepared right now. Please try again shortly.' );
		}

		try {
			WPQ_Questionnaire_Report::request_generation( $submission_id );
		} catch ( Throwable $e ) {
			WPQ_Database::log_error( 'WPQ: Customer-requested report generation failed for submission ' . $submission_id . ': ' . $e->getMessage() );
			return self::error( 500, 'REPORT_REQUEST_FAILED', 'Could not start report generation. Please try again.' );
		}

		return new WP_REST_Response(
			WPQ_Questionnaire_Report_Delivery::state_for_submission( WPQ_Database::get_submission( $submission_id ), $questionnaire ),
			200
		);
	}

	public static function serve_report_download( bool $served, $result, WP_REST_Request $request, $server ): bool {
		if ( $served || ! ( $result instanceof WP_REST_Response ) ) {
			return $served;
		}

		$headers     = $result->get_headers();
		$download_id = sanitize_text_field( (string) ( $headers[ self::REPORT_DOWNLOAD_HEADER ] ?? '' ) );
		if ( $download_id === '' ) {
			return $served;
		}

		// Remove the internal routing header before serving.
		unset( $headers[ self::REPORT_DOWNLOAD_HEADER ] );
		$result->set_headers( $headers );

		$pending = self::$report_download_paths[ $download_id ] ?? [];
		$path    = (string) ( $pending['path'] ?? '' );
		$kind    = (string) ( $pending['kind'] ?? self::DOWNLOAD_KIND_PAID_REPORT );
		if ( $path === '' ) {
			return $served;
		}

		$resolved_path = self::validate_report_stream_path( $path, $kind );
		if ( ! $resolved_path ) {
			unset( self::$report_download_paths[ $download_id ] );
			return $served;
		}

		unset( self::$report_download_paths[ $download_id ] );
		return self::stream_report_file( $resolved_path );
	}

	/**
	 * Admin-triggered replay of a stored webhook event through the same
	 * idempotent processing path the live webhook uses. Signature verification
	 * is deliberately not repeated: the payload comes from our own
	 * wpq_payment_events row, which was only ever written after the original
	 * request's signature verified. An event that already completed processing
	 * is reported as such rather than re-applied.
	 *
	 * @return array{status: string, detail: string}
	 */
	public static function replay_payment_event( string $stripe_event_id ): array {
		$stored = WPQ_Database::get_payment_event( $stripe_event_id );
		if ( ! $stored ) {
			return [ 'status' => 'error', 'detail' => 'Stored event not found.' ];
		}
		if ( ! empty( $stored->processed_at ) ) {
			return [ 'status' => 'already_processed', 'detail' => 'Event was already fully processed on ' . (string) $stored->processed_at . '.' ];
		}

		$event = json_decode( (string) ( $stored->payload_json ?? '' ) );
		if ( ! is_object( $event ) || ! is_object( $event->data->object ?? null ) ) {
			return [ 'status' => 'error', 'detail' => 'Stored payload could not be decoded.' ];
		}

		$allowed_events = [
			'checkout.session.completed'            => 'paid',
			'checkout.session.expired'              => 'expired',
			'checkout.session.async_payment_failed' => 'failed',
		];
		$event_type = (string) ( $stored->event_type ?? '' );
		if ( ! isset( $allowed_events[ $event_type ] ) ) {
			return [ 'status' => 'error', 'detail' => 'Event type is not replayable.' ];
		}

		$response = self::process_checkout_event( $event, $event->data->object, $stored, $allowed_events[ $event_type ] );
		$data     = $response->get_data();
		$code     = method_exists( $response, 'get_status' ) ? (int) $response->get_status() : 200;
		$detail   = is_array( $data ) ? (string) wp_json_encode( $data ) : '';

		return [
			'status' => $code >= 200 && $code < 300 ? 'replayed' : 'failed',
			'detail' => 'HTTP ' . $code . ' - ' . $detail,
		];
	}

	// ------------------------------------------------------------------ //
	// Helpers
	// ------------------------------------------------------------------ //

	private static function process_checkout_event( object $event, object $stripe_session, ?object $existing_event, string $target_status ): WP_REST_Response {
		$stripe_session_id = sanitize_text_field( (string) ( $stripe_session->id ?? '' ) );
		$payment_session = $stripe_session_id !== '' ? WPQ_Database::get_payment_session( $stripe_session_id ) : null;
		if ( ! $payment_session ) {
			return self::error( 409, 'UNKNOWN_SESSION', 'Payment session is not recognised.' );
		}

		$submission = WPQ_Database::get_submission( (int) $payment_session->submission_id );
		$product = WPQ_Database::get_product_admin( (int) $payment_session->product_id );
		if ( ! $submission || ! $product ) {
			return self::error( 409, 'LOCAL_RECORD_MISSING', 'Submission or product record is missing.' );
		}

		$metadata = is_object( $stripe_session->metadata ?? null ) ? $stripe_session->metadata : (object) [];
		$expected = [
			'submission_id' => (string) $payment_session->submission_id,
			'product_id'    => (string) $payment_session->product_id,
			'answers_hash'  => (string) $payment_session->answers_hash,
		];
		foreach ( $expected as $key => $value ) {
			if ( (string) ( $metadata->{$key} ?? '' ) !== $value ) {
				return self::error( 409, 'METADATA_MISMATCH', 'Stripe session metadata does not match local records.' );
			}
		}

		$amount_total = (int) ( $stripe_session->amount_total ?? -1 );
		$currency = strtolower( sanitize_text_field( (string) ( $stripe_session->currency ?? '' ) ) );
		if ( $amount_total !== (int) $payment_session->amount_total ) {
			return self::error( 409, 'AMOUNT_MISMATCH', 'Stripe amount does not match expected amount.' );
		}
		if ( $currency !== (string) $payment_session->currency ) {
			return self::error( 409, 'CURRENCY_MISMATCH', 'Stripe currency does not match expected currency.' );
		}

		$stripe_event_id = sanitize_text_field( (string) $event->id );
		if ( ! $existing_event ) {
			$inserted_event = WPQ_Database::insert_payment_event( [
				'stripe_event_id' => $stripe_event_id,
				'stripe_session_id' => $stripe_session_id,
				'submission_id' => (int) $payment_session->submission_id,
				'product_id' => (int) $payment_session->product_id,
				'event_type' => sanitize_text_field( (string) $event->type ),
				'previous_status' => (string) $submission->payment_status,
				'new_status' => $target_status,
				'amount_total' => $amount_total,
				'currency' => $currency,
				'payload_json' => $event,
			] );
			if ( ! $inserted_event ) {
				return new WP_REST_Response( [ 'status' => 'ok', 'duplicate' => true ], 200 );
			}
		}

		$previous_status = (string) $submission->payment_status;
		if ( $previous_status === 'paid' && $target_status !== 'paid' ) {
			WPQ_Database::mark_payment_event_processed( $stripe_event_id, $previous_status, 'paid' );
			return new WP_REST_Response( [ 'status' => 'ok', 'ignored_terminal' => true ], 200 );
		}
		if ( $previous_status === 'pending' && ! WPQ_Database::transition_payment_status( (int) $submission->id, 'pending', $target_status ) ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'Could not update payment state.' );
		}
		if ( $previous_status !== 'pending' && $previous_status !== $target_status ) {
			return self::error( 409, 'INVALID_PAYMENT_STATE', 'Payment is not pending.' );
		}

		if ( ! WPQ_Database::update_payment_session_status( $stripe_session_id, $target_status ) ) {
			return self::error( 500, 'INTERNAL_ERROR', 'Could not update payment session.' );
		}

		if ( $target_status !== 'paid' ) {
			WPQ_Database::mark_payment_event_processed( $stripe_event_id, $previous_status, $target_status );
			return new WP_REST_Response( [ 'status' => 'ok', 'payment_status' => $target_status ], 200 );
		}

		try {
			$existing_report = empty( $submission->report_path ) || ! class_exists( 'WPQ_Report_Renderer' )
				? null
				: WPQ_Report_Renderer::resolve_report_path( (string) $submission->report_path );
			if ( ! $existing_report || ! is_readable( $existing_report ) ) {
				WPQ_Report_Renderer::generate_and_store( (int) $submission->id, (int) $product->id );
			}
			$token = WPQ_Database::create_report_token( (int) $submission->id );
			if ( empty( $token['token'] ) ) {
				throw new RuntimeException( 'Could not create report token.' );
			}
		} catch ( Throwable $e ) {
			if ( ! WPQ_Database::update_submission_report( (int) $submission->id, (int) $product->id, (string) ( $submission->report_path ?? '' ), $e->getMessage() ) ) {
				WPQ_Database::log_error( 'WPQ could not record report generation failure for submission ' . (int) $submission->id );
			}
			return self::error( 500, 'REPORT_GENERATION_FAILED', 'Payment was confirmed, but report generation failed.' );
		}

		WPQ_Database::mark_payment_event_processed( $stripe_event_id, $previous_status, 'paid' );

		return new WP_REST_Response( [
			'status' => 'ok',
			'report_url' => self::report_download_url( (int) $submission->id, (string) $token['token'] ),
		], 200 );
	}

	private static function is_checkout_feature_enabled(): bool {
		// When a test Stripe session is injected, bypass the feature flag entirely.
		if ( class_exists( 'WPQ_Stripe' ) && WPQ_Stripe::has_test_checkout_session() ) {
			return true;
		}
		if ( defined( 'WPQ_TESTING' ) && isset( $GLOBALS['wpq_test_checkout_enabled'] ) ) {
			return (bool) $GLOBALS['wpq_test_checkout_enabled'];
		}

		return class_exists( 'WPQ_Feature_Flags' )
			? WPQ_Feature_Flags::checkout_enabled()
			: ( defined( 'WPQ_CHECKOUT_ENABLED' ) && WPQ_CHECKOUT_ENABLED );
	}

	private static function implementation_ready_for_checkout(): bool {
		// When a test Stripe session is injected, skip capability checks.
		if ( class_exists( 'WPQ_Stripe' ) && WPQ_Stripe::has_test_checkout_session() ) {
			return true;
		}
		$capabilities = self::checkout_capabilities();
		foreach ( [ 'checkout', 'webhook', 'report_delivery', 'report_template', 'report_renderer', 'report_storage_delivery', 'stripe_api_initialised' ] as $capability ) {
			if ( empty( $capabilities[ $capability ] ) ) {
				return false;
			}
		}

		return true;
	}

	private static function product_amount_total( object $product ): int {
		return (int) round( (float) $product->price_gbp * 100 );
	}

	private static function fail_pending_checkout( int $submission_id, string $stripe_session_id ): void {
		if ( $stripe_session_id !== '' ) {
			WPQ_Database::update_payment_session_status( $stripe_session_id, 'failed' );
		}

		WPQ_Database::transition_payment_status( $submission_id, 'pending', 'failed' );
	}

	private static function checkout_return_url( string $status ): string {
		if ( function_exists( 'home_url' ) ) {
			return home_url( '/?wpq_checkout=' . rawurlencode( $status ) );
		}

		return 'https://example.test/?wpq_checkout=' . rawurlencode( $status );
	}

	private static function report_download_url( int $submission_id, string $token ): string {
		$path = WPQ_REST_NAMESPACE . '/reports/' . $submission_id . '?token=' . rawurlencode( $token );
		if ( function_exists( 'rest_url' ) ) {
			return rest_url( $path );
		}

		return 'https://example.test/wp-json/' . $path;
	}

	private static function submission_snapshot_fields( object $questionnaire, array $structure, array $ctas ): array {
		$domains    = is_array( $structure['domains'] ?? null ) ? $structure['domains'] : [];
		$thresholds = is_array( $structure['thresholds'] ?? null ) ? $structure['thresholds'] : [];

		return [
			'questionnaire_ref_snapshot'       => substr( sanitize_text_field( (string) ( $questionnaire->ref ?? '' ) ), 0, 20 ),
			'questionnaire_version_snapshot'   => self::questionnaire_snapshot_version( $questionnaire ),
			'scoring_schema_version'           => WPQ_Scoring::SCHEMA_VERSION,
			'question_snapshot_json'           => self::encode_snapshot_json( self::question_snapshot( $domains ) ),
			'option_snapshot_json'             => self::encode_snapshot_json( self::option_snapshot( $domains ) ),
			'grade_threshold_snapshot_json'    => self::encode_snapshot_json( $thresholds ),
			'cta_snapshot_json'                => self::encode_snapshot_json( $ctas ),
		];
	}

	private static function questionnaire_snapshot_version( object $questionnaire ): string {
		foreach ( [ 'source_version', 'library_version', 'version' ] as $property ) {
			$value = isset( $questionnaire->{$property} ) ? trim( (string) $questionnaire->{$property} ) : '';
			if ( $value !== '' ) {
				return substr( sanitize_text_field( $value ), 0, 50 );
			}
		}

		return WPQ_VERSION;
	}

	private static function question_snapshot( array $domains ): array {
		return array_map(
			static function ( array $domain ): array {
				$questions = is_array( $domain['questions'] ?? null ) ? $domain['questions'] : [];
				$domain_snapshot = $domain;
				$domain_snapshot['questions'] = array_map(
					static function ( array $question ): array {
						unset( $question['options'] );
						return $question;
					},
					$questions
				);

				return $domain_snapshot;
			},
			$domains
		);
	}

	private static function option_snapshot( array $domains ): array {
		$snapshot = [];
		foreach ( $domains as $domain ) {
			$questions = is_array( $domain['questions'] ?? null ) ? $domain['questions'] : [];
			foreach ( $questions as $question ) {
				$key = (string) ( $question['question_ref'] ?? '' );
				if ( $key === '' ) {
					$key = 'question_' . (int) ( $question['id'] ?? 0 );
				}

				$snapshot[ $key ] = [
					'question_id' => (int) ( $question['id'] ?? 0 ),
					'options'     => is_array( $question['options'] ?? null ) ? $question['options'] : [],
				];
			}
		}

		return $snapshot;
	}

	private static function encode_snapshot_json( array $snapshot ): ?string {
		$json = wp_json_encode( $snapshot );
		return is_string( $json ) ? $json : null;
	}

	private static function report_download_response( string $path ): WP_REST_Response {
		return self::deferred_download_response( $path, self::DOWNLOAD_KIND_PAID_REPORT );
	}

	private static function questionnaire_report_download_response( string $path ): WP_REST_Response {
		return self::deferred_download_response( $path, self::DOWNLOAD_KIND_QUESTIONNAIRE_REPORT );
	}

	/**
	 * Hand the file off to the late-stage streaming hook. The path is re-validated
	 * there against the storage it came from, so the kind must travel with it -
	 * the two artefacts live in different directories with different containment
	 * rules.
	 */
	private static function deferred_download_response( string $path, string $kind ): WP_REST_Response {
		$download_id = hash_hmac( 'sha256', $path . '|' . microtime( true ) . '|' . wp_generate_uuid4(), wp_salt( 'auth' ) );
		self::$report_download_paths[ $download_id ] = [ 'path' => $path, 'kind' => $kind ];

		return new WP_REST_Response( [], 200, [ self::REPORT_DOWNLOAD_HEADER => $download_id ] );
	}

	private static function validate_report_stream_path( string $path, string $kind = self::DOWNLOAD_KIND_PAID_REPORT ): ?string {
		$expected_extension = 'pdf';
		if ( self::DOWNLOAD_KIND_QUESTIONNAIRE_REPORT === $kind ) {
			$resolved_path = class_exists( 'WPQ_Questionnaire_Report_Storage' )
				? WPQ_Questionnaire_Report_Storage::resolve_pdf_path( $path )
				: null;
		} elseif ( self::DOWNLOAD_KIND_REMEDIATION_WORKBOOK === $kind ) {
			$expected_extension = 'xlsx';
			$resolved_path      = class_exists( 'WPQ_Questionnaire_Report_Storage' )
				? WPQ_Questionnaire_Report_Storage::resolve_remediation_xlsx_path( $path )
				: null;
		} else {
			$resolved_path = class_exists( 'WPQ_Report_Renderer' ) ? WPQ_Report_Renderer::resolve_report_path( $path ) : null;
		}

		if ( ! $resolved_path ) {
			return null;
		}
		if ( strtolower( pathinfo( $resolved_path, PATHINFO_EXTENSION ) ) !== $expected_extension ) {
			return null;
		}
		if ( ! is_readable( $resolved_path ) ) {
			return null;
		}

		return $resolved_path;
	}

	private static function report_stream_headers( string $path ): array {
		$file_name = preg_replace( '/[^A-Za-z0-9._-]/', '-', basename( $path ) );
		$file_name = $file_name ?: 'wpq-report.pdf';
		$is_xlsx   = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) === 'xlsx';
		$headers   = [
			'Content-Type'           => $is_xlsx
				? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				: 'application/pdf',
			'Content-Disposition'    => 'attachment; filename="' . $file_name . '"',
			'X-Content-Type-Options' => 'nosniff',
			'Cache-Control'          => 'no-store, no-cache, must-revalidate, max-age=0',
			'Pragma'                 => 'no-cache',
			'Expires'                => '0',
		];
		$size = filesize( $path );
		if ( $size !== false ) {
			$headers['Content-Length'] = (string) $size;
		}
		return $headers;
	}

	private static function stream_report_file( string $path ): bool {
		$headers = self::report_stream_headers( $path );

		if ( defined( 'WPQ_TESTING' ) && WPQ_TESTING ) {
			$GLOBALS['wpq_test_streamed_report'] = [
				'path'    => $path,
				'headers' => $headers,
			];
			return true;
		}

		if ( function_exists( 'status_header' ) ) {
			status_header( 200 );
		}
		foreach ( $headers as $name => $value ) {
			header( $name . ': ' . $value );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Controlled plugin-generated PDF path after token validation.
		readfile( $path );
		return true;
	}

	private static function check_rate_limit( string $endpoint, int $limit, int $window_seconds ): bool {
		$ip   = self::get_client_ip();
		$database_result = WPQ_Database::check_rate_limit( $endpoint, $ip, $limit, $window_seconds );
		if ( $database_result !== null ) {
			return $database_result;
		}

		$key  = 'wpq_rl_' . md5( $endpoint . $ip );
		$data = get_transient( $key );

		if ( $data === false ) {
			// First request - open a fixed window starting now.
			set_transient( $key, [ 'count' => 1, 'expires' => time() + $window_seconds ], $window_seconds );
			return true;
		}

		if ( $data['count'] >= $limit ) {
			return false;
		}

		// Increment but preserve the original window expiry (not a sliding window).
		$remaining = max( 1, (int) $data['expires'] - time() );
		set_transient( $key, [ 'count' => $data['count'] + 1, 'expires' => $data['expires'] ], $remaining );
		return true;
	}

	private static function get_client_ip(): string {
		// Only trust X-Forwarded-For when WPQ_TRUST_PROXY_IP is explicitly enabled,
		// i.e. when REMOTE_ADDR is always a trusted reverse proxy that strips inbound XFF.
		if ( WPQ_TRUST_PROXY_IP && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) )[0] );
			if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return $ip;
			}
		}
		$ip = trim( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ) );
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	private static function domain_slugs_from_actions( array $actions ): array {
		$slugs = [];
		foreach ( $actions as $action ) {
			if ( ! is_array( $action ) ) {
				continue;
			}
			$slug = sanitize_key( (string) ( $action['domain_slug'] ?? '' ) );
			if ( $slug !== '' && ! in_array( $slug, $slugs, true ) ) {
				$slugs[] = $slug;
			}
		}

		return $slugs;
	}

	/** @return array{name:string,email:string,company:string,phone:string} */
	private static function contact_from_submission( object $submission ): array {
		return [
			'name'    => (string) ( $submission->contact_name ?? '' ),
			'email'   => (string) ( $submission->contact_email ?? '' ),
			'company' => (string) ( $submission->contact_company ?? '' ),
			'phone'   => (string) ( $submission->contact_phone ?? '' ),
		];
	}

	private static function error( int $status, string $code, string $message ): WP_REST_Response {
		return new WP_REST_Response( [
			'status'  => 'error',
			'code'    => $code,
			'message' => $message,
		], $status );
	}
}
