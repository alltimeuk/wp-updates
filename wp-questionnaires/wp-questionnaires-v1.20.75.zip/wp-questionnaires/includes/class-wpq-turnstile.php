<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Cloudflare Turnstile bot protection for the public lead and enquiry
 * endpoints - the two places an unauthenticated request writes a new contact
 * identity into the system, which is what a scraper submitting false data
 * actually targets.
 *
 * Behind a global kill switch (Settings -> Turnstile) plus a per-enquiry-form
 * inherit/enabled/disabled override, matching the WPQ_Mailer pattern.
 * Questionnaires have no such override - global settings only. Site key and
 * secret resolve constant -> environment -> option, matching WPQ_Secrets'
 * convention.
 *
 * Verification fails OPEN on anything that isn't a definite "no" from
 * Cloudflare: not configured, and a network/API error both let the
 * submission through (never let our own misconfiguration or a Cloudflare
 * outage block a genuine customer). A missing token when the widget should
 * have supplied one, or an explicit failure response, is a definite "no" and
 * is rejected - otherwise a bot can just omit the field and the whole
 * mechanism does nothing.
 */
class WPQ_Turnstile {

	private const VERIFY_URL = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
	public const SCRIPT_URL  = 'https://challenges.cloudflare.com/turnstile/v0/api.js';

	private const OPTION_ENABLED = 'wpq_turnstile_enabled';
	private const LAST_ERROR_OPTION = 'wpq_turnstile_last_error';
	private const REQUEST_TIMEOUT = 10;

	// ------------------------------------------------------------------ //
	// Configuration
	// ------------------------------------------------------------------ //

	/** The global kill switch. Default off: requires an admin to configure keys and opt in. */
	public static function globally_enabled(): bool {
		return 'enabled' === get_option( self::OPTION_ENABLED, 'disabled' );
	}

	/**
	 * @return array{value: string, source: string}
	 */
	public static function get_setting_details( string $option, string $constant, string $environment_key ): array {
		if ( defined( $constant ) && constant( $constant ) ) {
			return [ 'value' => (string) constant( $constant ), 'source' => 'constant' ];
		}
		$environment_value = getenv( $environment_key );
		if ( is_string( $environment_value ) && '' !== $environment_value ) {
			return [ 'value' => $environment_value, 'source' => 'environment' ];
		}
		$option_value = (string) get_option( $option, '' );
		return [ 'value' => $option_value, 'source' => '' !== $option_value ? 'option' : 'none' ];
	}

	public static function site_key(): string {
		return self::get_setting_details( 'wpq_turnstile_site_key', 'WPQ_TURNSTILE_SITE_KEY', 'WPQ_TURNSTILE_SITE_KEY' )['value'];
	}

	public static function secret_key(): string {
		return self::get_setting_details( 'wpq_turnstile_secret_key', 'WPQ_TURNSTILE_SECRET_KEY', 'WPQ_TURNSTILE_SECRET_KEY' )['value'];
	}

	/** Both keys present - the only state in which verification can actually run. */
	public static function configured(): bool {
		return '' !== self::site_key() && '' !== self::secret_key();
	}

	/**
	 * Whether a public endpoint should render the widget and verify its
	 * token: the global switch, actual configuration, and the entity's own
	 * inherit/enabled/disabled override all have to agree.
	 */
	public static function required_for( ?object $entity, string $override_field ): bool {
		if ( ! self::globally_enabled() || ! self::configured() ) {
			return false;
		}
		return 'disabled' !== (string) ( $entity->{$override_field} ?? 'inherit' );
	}

	/**
	 * Same inherit/enabled/disabled override as required_for_form() - lets a
	 * questionnaire opt out of its own start-step Turnstile widget, e.g. when
	 * an enquiry form embedded in that questionnaire's own results screen
	 * already renders a second Turnstile widget on the same page (a pattern
	 * some browsers' tracking-prevention heuristics flag and block storage
	 * for), without weakening bot protection anywhere else.
	 */
	public static function required_for_questionnaire( ?object $questionnaire ): bool {
		return self::required_for( $questionnaire, 'turnstile_enabled' );
	}

	public static function required_for_form( ?object $form ): bool {
		return self::required_for( $form, 'turnstile_enabled' );
	}

	/**
	 * @return array{enabled: bool, configured: bool, missing: array<int, string>, last_error: string}
	 */
	public static function diagnostics(): array {
		$missing = [];
		if ( '' === self::site_key() ) {
			$missing[] = 'site_key';
		}
		if ( '' === self::secret_key() ) {
			$missing[] = 'secret_key';
		}

		return [
			'enabled'    => self::globally_enabled(),
			'configured' => empty( $missing ),
			'missing'    => $missing,
			'last_error' => (string) get_option( self::LAST_ERROR_OPTION, '' ),
		];
	}

	// ------------------------------------------------------------------ //
	// Verification
	// ------------------------------------------------------------------ //

	/**
	 * Verify a submitted Turnstile token. Call only when required_for_*()
	 * is true for the relevant entity - this method does not itself check
	 * the global switch or configuration state, so a caller that skips the
	 * required_for_*() gate would always fail closed on an empty token.
	 */
	public static function verify( string $token, string $remote_ip = '' ): bool {
		if ( ! self::configured() ) {
			return true; // Fail open: nothing to verify against.
		}
		if ( '' === trim( $token ) ) {
			return false; // A properly configured widget always supplies a token; a bot skipping it does not.
		}

		$payload = [
			'secret'   => self::secret_key(),
			'response' => $token,
		];
		if ( '' !== $remote_ip ) {
			$payload['remoteip'] = $remote_ip;
		}

		$response = wp_remote_post( self::VERIFY_URL, [
			'timeout' => self::REQUEST_TIMEOUT,
			'body'    => $payload,
		] );

		if ( is_wp_error( $response ) ) {
			self::record_error( 'Turnstile request failed: ' . $response->get_error_message() );
			return true; // Fail open: cannot reach Cloudflare, do not block a genuine customer for it.
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 || ! is_array( $body ) ) {
			self::record_error( 'Turnstile returned an unexpected HTTP ' . $code . ' response.' );
			return true; // Fail open: an outage on Cloudflare's side is not the customer's fault.
		}

		if ( ! empty( $body['success'] ) ) {
			update_option( self::LAST_ERROR_OPTION, '' );
			return true;
		}

		// A real failure verdict from Cloudflare - fail closed, this is the
		// mechanism actually working, not an error condition to swallow.
		$codes = implode( ', ', array_map( 'strval', (array) ( $body['error-codes'] ?? [] ) ) );
		self::record_error( '' !== $codes ? 'Turnstile rejected the token: ' . $codes : 'Turnstile rejected the token.' );
		return false;
	}

	private static function record_error( string $message ): void {
		update_option( self::LAST_ERROR_OPTION, sanitize_text_field( gmdate( 'Y-m-d H:i:s' ) . ' UTC ' . $message ) );
	}
}
