<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Orchestrates the Questionnaire Report lifecycle: context -> Claude analysis
 * -> DOCX population -> PDF conversion -> protected storage. Separate from
 * WPQ_Remediation_Plan, which produces an unrelated XLSX operational task
 * workbook. Runs as an idempotent WordPress single-event background job so a
 * public/admin request never blocks on Anthropic or LibreOffice.
 */
class WPQ_Questionnaire_Report {

	public const CRON_HOOK       = 'wpq_process_questionnaire_report';
	public const RETRY_CRON_HOOK = 'wpq_retry_questionnaire_report_pdf';

	public const ACTIVE_STATES = [ 'queued', 'analysing', 'rendering_docx', 'converting_pdf' ];
	public const RESTARTABLE_STATES = [ 'not_requested', 'completed', 'partial', 'failed' ];

	private static ?WPQ_Docx_Pdf_Converter_Interface $test_converter = null;

	/** Test seam only — mirrors WPQ_Report_Renderer::set_test_pdf_binary(). */
	public static function set_test_converter( ?WPQ_Docx_Pdf_Converter_Interface $converter ): void {
		self::$test_converter = $converter;
	}

	public static function is_configured(): bool {
		return WPQ_Questionnaire_Report_Analysis::is_configured() && WPQ_Docx_Template_Renderer::library_available();
	}

	/**
	 * Claim and schedule a full generation run. A repeated call while a run is
	 * already active returns the current (unchanged) state instead of queuing a
	 * second job; call this again once the prior run reaches a terminal state to
	 * regenerate.
	 */
	public static function request_generation( int $submission_id ): array {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			throw new RuntimeException( 'Submission not found.' );
		}
		if ( empty( $submission->completed_at ) ) {
			throw new RuntimeException( 'Questionnaire Report generation requires a completed assessment.' );
		}

		if ( in_array( (string) $submission->qr_status, self::ACTIVE_STATES, true ) ) {
			return self::state_snapshot( $submission );
		}

		$token   = wp_generate_password( 20, false, false );
		$claimed = WPQ_Database::claim_questionnaire_report_job( $submission_id, $token, self::RESTARTABLE_STATES, 'queued' );
		if ( ! $claimed ) {
			return self::state_snapshot( WPQ_Database::get_submission( $submission_id ) );
		}

		wp_schedule_single_event( time(), self::CRON_HOOK, [ $submission_id, $token ] );

		return self::state_snapshot( WPQ_Database::get_submission( $submission_id ) );
	}

	/**
	 * Claim and schedule a PDF-only retry from an existing generated DOCX.
	 * Only valid while the report is in the "partial" state (DOCX succeeded,
	 * PDF conversion failed or was unavailable).
	 */
	public static function retry_pdf_conversion( int $submission_id ): array {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			throw new RuntimeException( 'Submission not found.' );
		}
		if ( 'partial' !== (string) $submission->qr_status || empty( $submission->qr_docx_path ) ) {
			throw new RuntimeException( 'PDF retry is only available for a partially generated report.' );
		}

		$token   = wp_generate_password( 20, false, false );
		$claimed = WPQ_Database::claim_questionnaire_report_job( $submission_id, $token, [ 'partial' ], 'converting_pdf' );
		if ( ! $claimed ) {
			return self::state_snapshot( WPQ_Database::get_submission( $submission_id ) );
		}

		wp_schedule_single_event( time(), self::RETRY_CRON_HOOK, [ $submission_id, $token ] );

		return self::state_snapshot( WPQ_Database::get_submission( $submission_id ) );
	}

	/**
	 * WP-Cron single-event handler for a full generation run.
	 */
	public static function process( int $submission_id, string $token ): void {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || (string) $submission->qr_generation_token !== $token ) {
			return; // Superseded or stale duplicate cron firing.
		}
		if ( 'queued' !== (string) $submission->qr_status ) {
			return;
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			self::fail( $submission_id, $token, 'analysing', 'questionnaire_missing', 'The parent questionnaire could not be found.' );
			return;
		}

		$renderer_mode = WPQ_Feature_Flags::questionnaire_report_renderer_mode_for_questionnaire( $questionnaire );

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_status'        => 'analysing',
			'qr_last_stage'    => 'analysing',
			'qr_renderer_mode' => $renderer_mode,
		] );

		if ( WPQ_Feature_Flags::RENDERER_HTML_DOMPDF === $renderer_mode ) {
			self::process_html_fallback( $submission, $questionnaire, $token );
			return;
		}

		$template = self::template_status( $questionnaire );
		if ( ! $template['ready'] ) {
			if ( WPQ_Feature_Flags::questionnaire_report_html_fallback_allowed() ) {
				self::process_html_fallback( $submission, $questionnaire, $token );
				return;
			}
			self::fail( $submission_id, $token, 'analysing', 'template_invalid', implode( ' ', $template['errors'] ) ?: 'Questionnaire Report template is not ready.' );
			return;
		}

		try {
			$context = WPQ_Questionnaire_Report_Context::build_for_submission( $submission );
			$context['traceability']['prompt_version'] = WPQ_Questionnaire_Report_Analysis::PROMPT_VERSION;
		} catch ( Throwable $e ) {
			self::fail( $submission_id, $token, 'analysing', 'context_build_failed', 'Could not build the assessment context.' );
			return;
		}

		try {
			$analysis = WPQ_Questionnaire_Report_Analysis::analyse( $context );
		} catch ( Throwable $e ) {
			self::fail( $submission_id, $token, 'analysing', 'claude_analysis_failed', 'Could not generate the questionnaire report analysis. Enable Claude debug logging in Settings -> AI for response details.' );
			return;
		}

		if ( ! self::still_claimed( $submission_id, $token ) ) {
			return;
		}

		// The validated analysis is stored, not just its request metadata: it is the
		// canonical finding list the remediation workbook links against, and it allows
		// a template refresh to re-render the same report without a second (and
		// necessarily different) Claude call.
		$analysis_json = wp_json_encode( $analysis['data'] );

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_status'            => 'rendering_docx',
			'qr_last_stage'        => 'rendering_docx',
			'qr_claude_request_id' => (string) ( $analysis['meta']['request_id'] ?? '' ),
			'qr_model_used'        => (string) ( $analysis['meta']['model'] ?? '' ),
			'qr_prompt_version'    => WPQ_Questionnaire_Report_Analysis::PROMPT_VERSION,
			'qr_context_version'   => WPQ_Questionnaire_Report_Context::CONTEXT_VERSION,
			'qr_template_checksum' => $template['checksum'],
			'qr_analysis_json'     => is_string( $analysis_json ) ? $analysis_json : null,
		] );

		try {
			$docx_binary = self::render_docx( $template['path'], $context, $analysis['data'] );
		} catch ( Throwable $e ) {
			self::fail( $submission_id, $token, 'rendering_docx', 'docx_render_failed', 'Could not populate the questionnaire report template: ' . self::safe_reason( $e ) );
			return;
		}

		$stored_docx = WPQ_Questionnaire_Report_Storage::store_docx( $submission_id, $docx_binary );
		if ( empty( $stored_docx['path'] ) ) {
			self::fail( $submission_id, $token, 'rendering_docx', 'docx_store_failed', 'Could not store the generated DOCX.' );
			return;
		}

		if ( ! self::still_claimed( $submission_id, $token ) ) {
			return;
		}

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_status'        => 'converting_pdf',
			'qr_last_stage'    => 'converting_pdf',
			'qr_docx_path'     => (string) $stored_docx['path'],
			'qr_docx_checksum' => (string) $stored_docx['checksum'],
		] );

		try {
			self::convert_and_store_pdf( $submission_id, (string) $stored_docx['path'] );
		} catch ( Throwable $e ) {
			WPQ_Database::update_submission_questionnaire_report( $submission_id, [
				'qr_status'           => 'partial',
				'qr_last_stage'       => 'converting_pdf',
				'qr_failure_code'     => 'pdf_conversion_failed',
				'qr_failure_message'  => 'PDF conversion is unavailable or failed. The DOCX report remains available; retry conversion once a converter is configured.',
			] );
			return;
		}

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_status'      => 'completed',
			'qr_last_stage'  => 'completed',
			'qr_generated_at' => current_time( 'mysql', true ),
		] );

		self::dispatch_delivery( $submission_id );
	}

	/**
	 * Hand a finished report to whichever delivery channels the questionnaire has
	 * enabled. Delivery failure never fails the generation run: the report exists
	 * and stays downloadable from the admin screen either way.
	 */
	private static function dispatch_delivery( int $submission_id ): void {
		if ( ! class_exists( 'WPQ_Questionnaire_Report_Delivery' ) ) {
			return;
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			return;
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );

		try {
			WPQ_Questionnaire_Report_Delivery::deliver( $submission, $questionnaire );
		} catch ( Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Report is generated and downloadable; delivery is best-effort.
			unset( $e );
		}
	}

	/**
	 * WP-Cron single-event handler for a PDF-only retry.
	 */
	public static function process_pdf_retry( int $submission_id, string $token ): void {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || (string) $submission->qr_generation_token !== $token ) {
			return;
		}
		if ( 'converting_pdf' !== (string) $submission->qr_status || empty( $submission->qr_docx_path ) ) {
			return;
		}

		try {
			self::convert_and_store_pdf( $submission_id, (string) $submission->qr_docx_path );
		} catch ( Throwable $e ) {
			WPQ_Database::update_submission_questionnaire_report( $submission_id, [
				'qr_status'          => 'partial',
				'qr_last_stage'      => 'converting_pdf',
				'qr_failure_code'    => 'pdf_conversion_failed',
				'qr_failure_message' => 'PDF conversion failed again. The DOCX report remains available.',
			] );
			return;
		}

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_status'       => 'completed',
			'qr_last_stage'   => 'completed',
			'qr_generated_at' => current_time( 'mysql', true ),
		] );

		self::dispatch_delivery( $submission_id );
	}

	/**
	 * Fallback path when the DOCX template is not ready and the site has
	 * explicitly opted into the HTML/Dompdf fallback, or the renderer mode is
	 * pinned to html_dompdf. Reuses the existing purchased-report renderer, so
	 * it is only available for submissions linked to a product.
	 */
	private static function process_html_fallback( object $submission, object $questionnaire, string $token ): void {
		$submission_id = (int) $submission->id;
		$product_id    = (int) ( $submission->product_id ?? $submission->report_product_id ?? 0 );

		if ( $product_id <= 0 || ! class_exists( 'WPQ_Report_Renderer' ) || ! WPQ_Report_Renderer::can_render() ) {
			self::fail( $submission_id, $token, 'analysing', 'html_fallback_unavailable', 'The HTML/Dompdf fallback requires a linked priced product and Dompdf to be available.' );
			return;
		}

		try {
			$html = WPQ_Report_Renderer::render_report_html( $submission_id, $product_id );
			$pdf  = WPQ_Report_Renderer::generate_pdf( $html );
		} catch ( Throwable $e ) {
			self::fail( $submission_id, $token, 'analysing', 'html_fallback_failed', 'Could not render the HTML/Dompdf fallback report.' );
			return;
		}

		$stored = WPQ_Questionnaire_Report_Storage::store_pdf( $submission_id, $pdf );
		if ( empty( $stored['path'] ) ) {
			self::fail( $submission_id, $token, 'converting_pdf', 'html_fallback_store_failed', 'Could not store the HTML/Dompdf fallback PDF.' );
			return;
		}

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_status'       => 'completed',
			'qr_last_stage'   => 'completed',
			'qr_renderer_mode' => WPQ_Feature_Flags::RENDERER_HTML_DOMPDF,
			'qr_pdf_path'     => (string) $stored['path'],
			'qr_pdf_checksum' => (string) $stored['checksum'],
			'qr_generated_at' => current_time( 'mysql', true ),
		] );

		self::dispatch_delivery( $submission_id );
	}

	private static function convert_and_store_pdf( int $submission_id, string $docx_relative_path ): void {
		$docx_path = WPQ_Questionnaire_Report_Storage::resolve_docx_path( $docx_relative_path );
		if ( null === $docx_path ) {
			throw new RuntimeException( 'Stored DOCX could not be resolved.' );
		}

		$converter = self::converter();
		if ( ! $converter->is_available() ) {
			throw new RuntimeException( 'PDF converter is not available.' );
		}

		$output_dir = rtrim( sys_get_temp_dir(), DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'wpq-qr-pdf-' . wp_generate_password( 12, false, false );
		if ( ! wp_mkdir_p( $output_dir ) ) {
			throw new RuntimeException( 'Could not create a temporary conversion directory.' );
		}

		try {
			$pdf_path = $converter->convert( $docx_path, $output_dir );
			$binary   = file_get_contents( $pdf_path );
		} finally {
			self::remove_directory( $output_dir );
		}

		if ( ! is_string( $binary ) || '' === $binary ) {
			throw new RuntimeException( 'Converted PDF could not be read.' );
		}

		$stored = WPQ_Questionnaire_Report_Storage::store_pdf( $submission_id, $binary );
		if ( empty( $stored['path'] ) ) {
			throw new RuntimeException( 'Could not store the converted PDF.' );
		}

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_pdf_path'     => (string) $stored['path'],
			'qr_pdf_checksum' => (string) $stored['checksum'],
		] );
	}

	public static function converter(): WPQ_Docx_Pdf_Converter_Interface {
		return self::$test_converter ?? new WPQ_LibreOffice_Pdf_Converter();
	}

	/**
	 * @return array{ready: bool, errors: array<int,string>, checksum: string, path: string, validation: array|null}
	 */
	public static function template_status( object $questionnaire ): array {
		$attachment_id = (int) ( $questionnaire->claude_template_attachment_id ?? 0 );
		if ( $attachment_id <= 0 ) {
			return [ 'ready' => false, 'errors' => [ 'No Questionnaire Report template has been uploaded.' ], 'checksum' => '', 'path' => '', 'validation' => null ];
		}

		$path = function_exists( 'get_attached_file' ) ? get_attached_file( $attachment_id ) : false;
		if ( ! is_string( $path ) || ! is_readable( $path ) ) {
			return [ 'ready' => false, 'errors' => [ 'Questionnaire Report template attachment is missing or unreadable.' ], 'checksum' => '', 'path' => '', 'validation' => null ];
		}

		$validation = WPQ_Docx_Template_Renderer::validate_template( $path );

		return [
			'ready'      => $validation['valid'],
			'errors'     => $validation['errors'],
			'checksum'   => (string) ( $questionnaire->claude_template_checksum ?? '' ),
			'path'       => $path,
			'validation' => $validation,
		];
	}

	private static function render_docx( string $template_path, array $context, array $analysis ): string {
		$assessment = $context['assessment'] ?? [];
		$counts     = self::severity_counts( $analysis['priority_findings'] ?? [] );
		$scalars = [
			'questionnaire.name'        => (string) ( $context['questionnaire']['name'] ?? '' ),
			'questionnaire.ref'         => (string) ( $context['questionnaire']['ref'] ?? '' ),
			'customer.name'             => (string) ( $context['customer']['name'] ?? '' ),
			'customer.company'          => (string) ( $context['customer']['company'] ?? '' ),
			'assessment.score'          => null !== ( $assessment['overall_score'] ?? null ) ? (string) $assessment['overall_score'] : '',
			'assessment.grade'          => (string) ( $assessment['grade_label'] ?: ( $assessment['grade_id'] ?? '' ) ),
			'assessment.verdict'        => (string) ( $assessment['verdict'] ?? '' ),
			'assessment.completed_at'   => self::format_date( (string) ( $context['questionnaire']['completion_date'] ?? '' ) ),
			'assessment.domains_count'  => (string) count( (array) ( $assessment['domain_scores'] ?? [] ) ),
			'assessment.questions_count' => (string) count( (array) ( $context['questions'] ?? [] ) ),
			'report.reference'          => (string) ( $context['customer']['submission_ref'] ?? '' ),
			'report.generated_at'       => self::format_date( current_time( 'mysql', true ) ),
			'report.title'              => (string) ( $analysis['report_title'] ?? '' ),
			'report.executive_summary'  => (string) ( $analysis['executive_summary'] ?? '' ),
			'report.overall_assessment' => (string) ( $analysis['overall_assessment'] ?? '' ),
			'report.conclusion'         => (string) ( $analysis['conclusion'] ?? '' ),
			'counts.critical'           => (string) $counts['Critical'],
			'counts.high'               => (string) $counts['High'],
			'counts.medium'             => (string) $counts['Medium'],
			'counts.low'                => (string) $counts['Low'],
			'counts.total'              => (string) array_sum( $counts ),
		];

		$blocks = [
			'strengths' => array_map( static fn( array $row ): array => [
				'strength.title'         => (string) ( $row['title'] ?? '' ),
				'strength.detail'        => (string) ( $row['detail'] ?? '' ),
				'strength.evidence_refs' => implode( ', ', (array) ( $row['evidence_refs'] ?? [] ) ),
			], $analysis['strengths'] ?? [] ),
			'priority_findings' => array_map( static fn( array $row ): array => [
				'finding.id'              => (string) ( $row['id'] ?? '' ),
				'finding.priority'        => (string) ( $row['priority'] ?? '' ),
				'finding.domain'          => (string) ( $row['domain'] ?? '' ),
				'finding.title'           => (string) ( $row['title'] ?? '' ),
				'finding.finding'         => (string) ( $row['finding'] ?? '' ),
				'finding.business_impact' => (string) ( $row['business_impact'] ?? '' ),
				'finding.recommendation'  => (string) ( $row['recommendation'] ?? '' ),
				'finding.evidence_refs'   => implode( ', ', (array) ( $row['evidence_refs'] ?? [] ) ),
			], $analysis['priority_findings'] ?? [] ),
			'domain_assessments' => array_map( static fn( array $row ): array => [
				'domain.name'            => (string) ( $row['domain'] ?? '' ),
				'domain.score'           => null !== ( $row['score'] ?? null ) ? (string) $row['score'] : '',
				'domain.maximum_score'   => null !== ( $row['maximum_score'] ?? null ) ? (string) $row['maximum_score'] : '',
				'domain.percent'         => self::percent_label( $row['score'] ?? null, $row['maximum_score'] ?? null ),
				'domain.summary'         => (string) ( $row['summary'] ?? '' ),
				'domain.strengths'       => implode( '; ', (array) ( $row['strengths'] ?? [] ) ),
				'domain.concerns'        => implode( '; ', (array) ( $row['concerns'] ?? [] ) ),
				'domain.recommendations' => implode( '; ', (array) ( $row['recommendations'] ?? [] ) ),
			], $analysis['domain_assessments'] ?? [] ),
			'recommended_next_steps' => array_map( static fn( array $row ): array => [
				'step.sequence'   => (string) ( $row['sequence'] ?? '' ),
				'step.timeframe'  => (string) ( $row['timeframe'] ?? '' ),
				'step.action'     => (string) ( $row['action'] ?? '' ),
				'step.reason'     => (string) ( $row['reason'] ?? '' ),
				'step.owner_type' => (string) ( $row['owner_type'] ?? '' ),
			], $analysis['recommended_next_steps'] ?? [] ),
			'limitations' => array_map( static fn( string $text ): array => [ 'limitation.text' => $text ], $analysis['limitations'] ?? [] ),
		];

		return WPQ_Docx_Template_Renderer::render( $template_path, $scalars, $blocks );
	}

	/**
	 * Tally of findings per priority, always covering all four levels (a level
	 * with no findings reports 0 rather than being absent), so a template's
	 * severity row never has an empty cell.
	 *
	 * @return array<string, int>
	 */
	private static function severity_counts( array $findings ): array {
		$counts = [ 'Critical' => 0, 'High' => 0, 'Medium' => 0, 'Low' => 0 ];
		foreach ( $findings as $finding ) {
			$priority = (string) ( $finding['priority'] ?? '' );
			if ( isset( $counts[ $priority ] ) ) {
				$counts[ $priority ]++;
			}
		}
		return $counts;
	}

	/** Domain score as a whole-number percentage label, for table-based score bars. */
	private static function percent_label( mixed $score, mixed $maximum ): string {
		if ( ! is_numeric( $score ) || ! is_numeric( $maximum ) || (float) $maximum <= 0.0 ) {
			return '';
		}
		return (string) (int) round( ( (float) $score / (float) $maximum ) * 100 );
	}

	private static function format_date( string $mysql_datetime ): string {
		if ( '' === $mysql_datetime ) {
			return '';
		}
		$timestamp = strtotime( $mysql_datetime );
		return $timestamp ? (string) wp_date( 'd M Y H:i', $timestamp ) : $mysql_datetime;
	}

	private static function fail( int $submission_id, string $token, string $stage, string $code, string $message ): void {
		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || (string) $submission->qr_generation_token !== $token ) {
			return; // Superseded by a newer claim.
		}

		WPQ_Database::update_submission_questionnaire_report( $submission_id, [
			'qr_status'          => 'failed',
			'qr_last_stage'      => $stage,
			'qr_failure_code'    => $code,
			'qr_failure_message' => $message,
		] );
	}

	private static function still_claimed( int $submission_id, string $token ): bool {
		$submission = WPQ_Database::get_submission( $submission_id );
		return (bool) $submission && (string) $submission->qr_generation_token === $token;
	}

	private static function safe_reason( Throwable $e ): string {
		return get_class( $e ) === RuntimeException::class ? $e->getMessage() : 'see Claude debug log';
	}

	/**
	 * @return array{status: string, renderer_mode: string, last_stage: string, failure_code: string, failure_message: string, docx_available: bool, pdf_available: bool}
	 */
	public static function state_snapshot( ?object $submission ): array {
		if ( ! $submission ) {
			return [
				'status'           => 'not_requested',
				'renderer_mode'    => '',
				'last_stage'       => '',
				'failure_code'     => '',
				'failure_message'  => '',
				'docx_available'   => false,
				'pdf_available'    => false,
			];
		}

		return [
			'status'          => (string) ( $submission->qr_status ?? 'not_requested' ),
			'renderer_mode'   => (string) ( $submission->qr_renderer_mode ?? '' ),
			'last_stage'      => (string) ( $submission->qr_last_stage ?? '' ),
			'failure_code'    => (string) ( $submission->qr_failure_code ?? '' ),
			'failure_message' => (string) ( $submission->qr_failure_message ?? '' ),
			'docx_available'  => ! empty( $submission->qr_docx_path ),
			'pdf_available'   => ! empty( $submission->qr_pdf_path ),
		];
	}

	public static function readiness(): array {
		$converter = self::converter();

		return [
			'claude_configured'   => WPQ_Questionnaire_Report_Analysis::is_configured(),
			'phpword_available'   => WPQ_Docx_Template_Renderer::library_available(),
			'converter'           => $converter->diagnostics(),
			'storage'             => WPQ_Questionnaire_Report_Storage::diagnostics(),
			'renderer_mode'       => WPQ_Feature_Flags::questionnaire_report_global_renderer_mode(),
			'html_fallback_allowed' => WPQ_Feature_Flags::questionnaire_report_html_fallback_allowed(),
			'html_dompdf_ready'   => class_exists( 'WPQ_Report_Renderer' ) && WPQ_Report_Renderer::can_render(),
		];
	}

	private static function remove_directory( string $directory ): void {
		if ( ! is_dir( $directory ) ) {
			return;
		}
		$items = @scandir( $directory );
		if ( ! is_array( $items ) ) {
			return;
		}
		foreach ( $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}
			$path = $directory . DIRECTORY_SEPARATOR . $item;
			if ( is_dir( $path ) ) {
				self::remove_directory( $path );
			} else {
				@unlink( $path );
			}
		}
		@rmdir( $directory );
	}
}
