/* global wpqConfig */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', bootAll);

  function bootAll() {
    const roots = Array.prototype.slice.call(document.querySelectorAll('.wpq-wrap[data-wpq-config]'));
    const legacyRoot = document.getElementById('wpq-app');
    if (!roots.length && legacyRoot) {
      roots.push(legacyRoot);
    }

    roots.forEach(root => {
      if (root.dataset.wpqInitialised === '1') {
        return;
      }

      let config = {};
      try {
        config = root.dataset.wpqConfig
          ? JSON.parse(root.dataset.wpqConfig)
          : (typeof wpqConfig !== 'undefined' ? wpqConfig : {});
      } catch (err) {
        console.error('[WPQ] Assessment config could not be parsed.', err);
        return;
      }

      if (!config || !config.ref || !config.restUrl) {
        console.error('[WPQ] Assessment config is incomplete.');
        return;
      }

      root.dataset.wpqInitialised = '1';
      mountAssessment(root, config);
    });
  }

  function mountAssessment(root, config) {
    function byId(id) {
      return root.querySelector('#' + id);
    }

  // -----------------------------------------------------------------------
  // State
  // -----------------------------------------------------------------------

  let questionnaire    = null;  // loaded from REST
  let submissionId     = null;  // assigned after lead form submit
  let sessionToken     = null;  // unguessable token returned with submission_id
  let answers          = {};    // { "0_0": "yes", ... }
  let currentDomain    = 0;
  let currentView      = 'questions'; // 'brief' | 'questions'
  let microReport      = null;
  let heartbeatTimer   = null;
  let pendingHeartbeat = null;

  const HEARTBEAT_DELAY = 3000; // ms debounce

  // -----------------------------------------------------------------------
  // Init
  // -----------------------------------------------------------------------

  function init() {
    const required = [
      'wpq-lead-form', 'wpq-back-btn', 'wpq-next-btn',
      'wpq-retry-btn', 'wpq-restart-btn',
      'wpq-step-lead', 'wpq-step-assessment', 'wpq-step-results',
      'wpq-loading', 'wpq-error-state',
    ];
    const missing = required.filter(id => !byId(id));
    if (missing.length) {
      console.error('[WPQ] Assessment shortcode template is incomplete. Missing elements:', missing);
      return;
    }

    captureAttribution();
    loadQuestionnaire();

    byId('wpq-lead-form').addEventListener('submit', onLeadSubmit);
    byId('wpq-back-btn').addEventListener('click', goBack);
    byId('wpq-next-btn').addEventListener('click', goNext);
    byId('wpq-retry-btn').addEventListener('click', loadQuestionnaire);
    byId('wpq-restart-btn').addEventListener('click', restart);
  }

  // -----------------------------------------------------------------------
  // Attribution
  // -----------------------------------------------------------------------

  function captureAttribution() {
    const params = new URLSearchParams(window.location.search);
    setValue('wpq-utm-source',   params.get('utm_source')   || '');
    setValue('wpq-utm-medium',   params.get('utm_medium')   || '');
    setValue('wpq-utm-campaign', params.get('utm_campaign') || '');
    setValue('wpq-utm-term',     params.get('utm_term')     || '');
    setValue('wpq-utm-content',  params.get('utm_content')  || '');
    setValue('wpq-referrer',     document.referrer          || '');
    setValue('wpq-landing',      window.location.href       || '');
  }

  function setValue(id, val) {
    const el = byId(id);
    if (el) el.value = val;
  }

  // -----------------------------------------------------------------------
  // Load questionnaire from REST
  // -----------------------------------------------------------------------

  async function loadQuestionnaire() {
    showLoading(true);
    hideError();

    try {
      const data = await apiFetch('GET', 'questionnaire/' + config.ref);
      questionnaire = data;
      showStep('lead');
      populateLeadHeader();
    } catch (err) {
      const detail = err.code ? ' (' + err.code + ')' : err.status ? ' [HTTP ' + err.status + ']' : '';
      showError('We could not load the assessment' + detail + '. Please check your connection and try again.');
    } finally {
      showLoading(false);
    }
  }

  function populateLeadHeader() {
    setText('wpq-questionnaire-name', questionnaire.name);
    setText('wpq-questionnaire-desc', questionnaire.description);
  }

  // -----------------------------------------------------------------------
  // Lead form
  // -----------------------------------------------------------------------

  async function onLeadSubmit(e) {
    e.preventDefault();
    if (!validateLeadForm()) return;

    const form    = e.target;
    const payload = {
      ref:             config.ref,
      contact_name:    form.contact_name.value.trim(),
      contact_email:   form.contact_email.value.trim(),
      contact_company: form.contact_company.value.trim(),
      contact_phone:   form.contact_phone.value.trim(),
      consent:         form.consent.checked,
      utm_source:      form.utm_source.value,
      utm_medium:      form.utm_medium.value,
      utm_campaign:    form.utm_campaign.value,
      utm_term:        form.utm_term.value,
      utm_content:     form.utm_content.value,
      referrer_url:    form.referrer_url.value,
      landing_page:    form.landing_page.value,
    };

    const btn = byId('wpq-lead-submit');
    btn.disabled = true;
    btn.textContent = 'Starting…';

    try {
      const res  = await apiFetch('POST', 'lead', payload);
      submissionId = res.submission_id;
      sessionToken = res.session_token;
      buildQuestionnaire();
      showStep('assessment');
    } catch (err) {
      showError(err.message || 'Could not start the assessment. Please try again.');
    } finally {
      btn.disabled    = false;
      btn.textContent = 'Start assessment →';
    }
  }

  function validateLeadForm() {
    let valid = true;
    const form = byId('wpq-lead-form');

    const name    = form.contact_name.value.trim();
    const email   = form.contact_email.value.trim();
    const co      = form.contact_company.value.trim();
    const consent = form.consent.checked;

    setFieldError('wpq-name-error',    !name    ? 'Please enter your name.'           : '');
    setFieldError('wpq-email-error',   !email || !isEmail(email) ? 'Please enter a valid email address.' : '');
    setFieldError('wpq-company-error', !co      ? 'Please enter your company name.'   : '');
    setFieldError('wpq-consent-error', !consent ? 'You must accept the privacy notice to continue.' : '');

    if (!name || !email || !isEmail(email) || !co || !consent) valid = false;
    return valid;
  }

  function setFieldError(id, msg) {
    const el = byId(id);
    if (!el) return;
    el.textContent = msg;
    el.classList.toggle('visible', !!msg);
  }

  function isEmail(str) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
  }

  // -----------------------------------------------------------------------
  // Build questionnaire UI
  // -----------------------------------------------------------------------

  function buildQuestionnaire() {
    buildDomainTabs();
    buildPanels();
    buildBriefPanels();
    updateConditionalVisibility();
    updateProgress();
    navigateTo(0, hasBrief(0) ? 'brief' : 'questions');
  }

  function hasBrief(di) {
    return !!(questionnaire.domains[di] && (questionnaire.domains[di].brief || '').trim());
  }

  function buildBriefPanels() {
    const container = byId('wpq-brief-panels');
    container.innerHTML = '';

    questionnaire.domains.forEach((domain, di) => {
      const panel = document.createElement('div');
      panel.className = 'wpq-brief-panel wpq-hidden';
      panel.id = `wpq-brief-panel-${di}`;

      const heading = document.createElement('div');
      heading.className = 'wpq-brief-heading';
      if (domain.icon) {
        const icon = document.createElement('span');
        icon.className = 'wpq-brief-icon';
        icon.setAttribute('aria-hidden', 'true');
        icon.textContent = domain.icon;
        heading.appendChild(icon);
      }
      const nameSpan = document.createElement('span');
      nameSpan.textContent = domain.name;
      heading.appendChild(nameSpan);
      panel.appendChild(heading);

      const body = document.createElement('div');
      body.className = 'wpq-brief-body';
      const text = (domain.brief || '').trim();
      if (text) {
        text.split(/\n\n+/).forEach(para => {
          const trimmed = para.trim();
          if (!trimmed) return;
          const p = document.createElement('p');
          p.textContent = trimmed;
          body.appendChild(p);
        });
      }
      panel.appendChild(body);
      container.appendChild(panel);
    });
  }

  function navigateTo(di, view) {
    if (view === 'brief' && !hasBrief(di)) view = 'questions';

    currentDomain = di;
    currentView   = view;

    if (view === 'brief') {
      byId('wpq-brief-panels').classList.remove('wpq-hidden');
      byId('wpq-panels').classList.add('wpq-hidden');
      root.querySelectorAll('.wpq-brief-panel').forEach((p, i) => {
        p.classList.toggle('wpq-hidden', i !== di);
      });
    } else {
      byId('wpq-brief-panels').classList.add('wpq-hidden');
      byId('wpq-panels').classList.remove('wpq-hidden');
      root.querySelectorAll('.wpq-panel').forEach((p, i) => {
        p.classList.toggle('active', i === di);
      });
    }

    // Domain tabs.
    root.querySelectorAll('.wpq-dtab').forEach((tab, i) => {
      const active = i === di;
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
      tab.classList.toggle('active', active);
    });
    updateDomainTabs();

    const total      = questionnaire.domains.length;
    const isLastDomain = di === total - 1;

    // Back button: hidden at the very first assessment screen.
    const backBtn = byId('wpq-back-btn');
    const isFirst = di === 0 && (view === 'brief' || !hasBrief(0));
    backBtn.style.visibility = isFirst ? 'hidden' : 'visible';

    // Next button label.
    const nextBtn = byId('wpq-next-btn');
    if (view === 'brief') {
      nextBtn.textContent = 'Continue →';
    } else {
      nextBtn.textContent = isLastDomain ? 'See my results →' : 'Next domain →';
    }

    // Scroll to top of widget.
    const anchor = root.querySelector('.wpq-tool-header') || root;
    if (anchor) anchor.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function buildDomainTabs() {
    const container = byId('wpq-domain-tabs');
    container.innerHTML = '';

    if (questionnaire.domains.length <= 1) {
      container.classList.add('wpq-hidden');
      return;
    }
    container.classList.remove('wpq-hidden');

    questionnaire.domains.forEach((domain, di) => {
      const btn = document.createElement('button');
      btn.className = 'wpq-dtab';
      btn.dataset.di = di;
      btn.setAttribute('role', 'tab');
      btn.setAttribute('aria-selected', di === 0 ? 'true' : 'false');

      const iconSpan = document.createElement('span');
      iconSpan.setAttribute('aria-hidden', 'true');
      iconSpan.textContent = domain.icon || '';
      const nameSpan = document.createElement('span');
      nameSpan.textContent = domain.name;
      btn.appendChild(iconSpan);
      btn.appendChild(nameSpan);

      btn.addEventListener('click', () => setDomain(di));
      container.appendChild(btn);
    });
  }

  function buildPanels() {
    const container = byId('wpq-panels');
    container.innerHTML = '';

    questionnaire.domains.forEach((domain, di) => {
      const panel    = document.createElement('div');
      panel.className = 'wpq-panel';
      panel.id        = `wpq-panel-${di}`;
      panel.setAttribute('role', 'tabpanel');

      const heading = document.createElement('div');
      heading.className = 'wpq-domain-heading';
      const headingIcon = document.createElement('span');
      headingIcon.className = 'wpq-domain-icon';
      headingIcon.setAttribute('aria-hidden', 'true');
      headingIcon.textContent = domain.icon || '';
      const headingName = document.createElement('span');
      headingName.textContent = domain.name;
      heading.appendChild(headingIcon);
      heading.appendChild(headingName);
      if (questionnaire.domains.length > 1) {
        panel.appendChild(heading);
      }

      domain.questions.forEach((question, qi) => {
        const qEl = buildQuestion(di, qi, domain, question);
        panel.appendChild(qEl);
      });

      container.appendChild(panel);
    });
  }

  function buildQuestion(di, qi, domain, question) {
    const qType = question.question_type || 'tri_state';
    switch (qType) {
      case 'boolean':    return buildBooleanQuestion(di, qi, domain, question);
      case 'select':     return buildSelectQuestion(di, qi, domain, question);
      case 'radio':      return buildRadioQuestion(di, qi, domain, question);
      case 'checkbox':   return buildCheckboxQuestion(di, qi, domain, question);
      case 'memo':       return buildMemoQuestion(di, qi, domain, question);
      case 'short_text': return buildShortTextQuestion(di, qi, domain, question);
      default:           return buildTriStateQuestion(di, qi, domain, question);
    }
  }

  function makeQuestionShell(di, qi, domain, question) {
    const el = document.createElement('div');
    el.className  = 'wpq-question';
    el.dataset.di = di;
    el.dataset.qi = qi;

    const header = document.createElement('div');
    header.className = 'wpq-question-header';

    const num = document.createElement('span');
    num.className   = 'wpq-question-num';
    const optional = question.is_required === false ? ' (optional)' : '';
    num.textContent = `Q${qi + 1}:${optional}`;

    const text = document.createElement('p');
    text.className   = 'wpq-question-text';
    text.textContent = question.question;

    header.appendChild(num);
    header.appendChild(text);
    el.appendChild(header);

    if (question.help_text) {
      const tipWrap  = document.createElement('span');
      tipWrap.className = 'wpq-tip-wrap';
      const tipIcon  = document.createElement('span');
      tipIcon.className   = 'wpq-tip-icon';
      tipIcon.textContent = 'ⓘ';
      tipIcon.setAttribute('tabindex', '0');
      tipIcon.setAttribute('aria-label', 'Show guidance');
      const tipPopup = document.createElement('div');
      tipPopup.className   = 'wpq-tip-popup';
      tipPopup.setAttribute('role', 'tooltip');
      tipPopup.textContent = question.help_text;
      tipWrap.appendChild(tipIcon);
      tipWrap.appendChild(tipPopup);
      text.appendChild(tipWrap);
    }

    return el;
  }

  function buildTriStateQuestion(di, qi, domain, question) {
    const el = makeQuestionShell(di, qi, domain, question);

    const answersEl = document.createElement('div');
    answersEl.className = 'wpq-answers';
    answersEl.setAttribute('role', 'group');
    answersEl.setAttribute('aria-label', question.question);

    [
      { value: 'yes',     label: '✓ Yes'       },
      { value: 'partial', label: '~ Partially' },
      { value: 'no',      label: '✗ No'        },
    ].forEach(opt => {
      const btn         = document.createElement('button');
      btn.type          = 'button';
      btn.className     = 'wpq-answer-btn';
      btn.dataset.value = opt.value;
      btn.textContent   = opt.label;
      btn.addEventListener('click', () => selectAnswer(di, qi, opt.value, answersEl));
      answersEl.appendChild(btn);
    });

    el.appendChild(answersEl);
    return el;
  }

  function buildBooleanQuestion(di, qi, domain, question) {
    const el = makeQuestionShell(di, qi, domain, question);

    const answersEl = document.createElement('div');
    answersEl.className = 'wpq-answers';
    answersEl.setAttribute('role', 'group');
    answersEl.setAttribute('aria-label', question.question);

    [
      { value: 'yes', label: '✓ Yes' },
      { value: 'no',  label: '✗ No'  },
    ].forEach(opt => {
      const btn         = document.createElement('button');
      btn.type          = 'button';
      btn.className     = 'wpq-answer-btn';
      btn.dataset.value = opt.value;
      btn.textContent   = opt.label;
      btn.addEventListener('click', () => selectAnswer(di, qi, opt.value, answersEl));
      answersEl.appendChild(btn);
    });

    el.appendChild(answersEl);
    return el;
  }

  function buildSelectQuestion(di, qi, domain, question) {
    const el = makeQuestionShell(di, qi, domain, question);

    const answersEl = document.createElement('div');
    answersEl.className = 'wpq-answers wpq-answers-select';

    const sel = document.createElement('select');
    sel.className = 'wpq-answer-select';
    sel.setAttribute('aria-label', question.question);

    const blank = document.createElement('option');
    blank.value       = '';
    blank.textContent = '— Please select —';
    sel.appendChild(blank);

    (question.options || []).forEach(opt => {
      const o       = document.createElement('option');
      o.value       = opt.key;
      o.textContent = opt.label;
      sel.appendChild(o);
    });

    sel.addEventListener('change', () => {
      if (sel.value) selectAnswer(di, qi, sel.value, answersEl);
    });

    answersEl.appendChild(sel);
    el.appendChild(answersEl);
    return el;
  }

  function optionGridColumnCount(options) {
    const labels = (options || [])
      .map(o => (o.label || '').trim())
      .filter(Boolean);

    if (!labels.length) return 1;

    const optionCount = labels.length;
    const avgLength = labels.reduce((sum, label) => sum + label.length, 0) / optionCount;
    const longestLength = labels.reduce((max, label) => Math.max(max, label.length), 0);

    let columns;
    if (longestLength > 140 || avgLength > 95) {
      columns = 1;
    } else if (longestLength > 95 || avgLength > 65) {
      columns = 2;
    } else if (longestLength > 70 || avgLength > 45) {
      columns = 3;
    } else if (longestLength > 45 || avgLength > 30) {
      columns = 4;
    } else {
      columns = 5;
    }

    return Math.max(1, Math.min(columns, optionCount, 5));
  }

  function gridColClass(options) {
    return `wpq-cols-${optionGridColumnCount(options)}`;
  }

  function buildRadioQuestion(di, qi, domain, question) {
    const el = makeQuestionShell(di, qi, domain, question);
    const name = `wpq_q_${di}_${qi}`;

    const answersEl = document.createElement('div');
    answersEl.className = `wpq-answers wpq-answers-radio ${gridColClass(question.options)}`;
    answersEl.setAttribute('role', 'radiogroup');
    answersEl.setAttribute('aria-label', question.question);

    (question.options || []).forEach(opt => {
      const wrap   = document.createElement('label');
      wrap.className = 'wpq-radio-label';

      const radio  = document.createElement('input');
      radio.type   = 'radio';
      radio.name   = name;
      radio.value  = opt.key;
      radio.addEventListener('change', () => selectAnswer(di, qi, opt.key, answersEl));

      wrap.appendChild(radio);
      wrap.append(' ' + opt.label);
      answersEl.appendChild(wrap);
    });

    el.appendChild(answersEl);
    return el;
  }

  function buildCheckboxQuestion(di, qi, domain, question) {
    const el = makeQuestionShell(di, qi, domain, question);

    const answersEl = document.createElement('div');
    answersEl.className = `wpq-answers wpq-answers-checkbox ${gridColClass(question.options)}`;
    answersEl.setAttribute('role', 'group');
    answersEl.setAttribute('aria-label', question.question);

    if (question.max_selections) {
      const hint = document.createElement('p');
      hint.className   = 'wpq-checkbox-hint';
      hint.textContent = `Select up to ${question.max_selections} option${question.max_selections !== 1 ? 's' : ''}.`;
      answersEl.appendChild(hint);
    }

    (question.options || []).forEach(opt => {
      const wrap  = document.createElement('label');
      wrap.className = 'wpq-checkbox-label';
      if (opt.exclusive) wrap.dataset.exclusive = '1';

      const cb    = document.createElement('input');
      cb.type     = 'checkbox';
      cb.value    = opt.key;
      cb.addEventListener('change', () => toggleCheckboxAnswer(di, qi, opt.key, question, answersEl));

      wrap.appendChild(cb);
      wrap.append(' ' + opt.label);
      answersEl.appendChild(wrap);
    });

    el.appendChild(answersEl);
    return el;
  }

  function buildMemoQuestion(di, qi, domain, question) {
    const el = makeQuestionShell(di, qi, domain, question);

    const answersEl = document.createElement('div');
    answersEl.className = 'wpq-answers wpq-answers-memo';

    const ta = document.createElement('textarea');
    ta.className     = 'wpq-answer-memo';
    ta.rows          = 4;
    ta.maxLength     = 2000;
    ta.placeholder   = 'Enter your response (optional, max 2000 characters)';
    ta.setAttribute('aria-label', question.question);

    const counter = document.createElement('div');
    counter.className = 'wpq-memo-counter';
    counter.textContent = '0 / 2000';

    ta.addEventListener('input', () => {
      counter.textContent = ta.value.length + ' / 2000';
      updateMemoAnswer(di, qi, ta.value);
    });

    answersEl.appendChild(ta);
    answersEl.appendChild(counter);
    el.appendChild(answersEl);
    return el;
  }

  function buildShortTextQuestion(di, qi, domain, question) {
    const el = makeQuestionShell(di, qi, domain, question);

    const answersEl = document.createElement('div');
    answersEl.className = 'wpq-answers wpq-answers-short-text';

    const input = document.createElement('input');
    input.type        = 'text';
    input.className   = 'wpq-answer-short-text';
    input.maxLength   = 255;
    input.placeholder = question.is_required !== false ? 'Required' : 'Optional';
    input.setAttribute('aria-label', question.question);

    input.addEventListener('input', () => {
      updateMemoAnswer(di, qi, input.value);
    });

    answersEl.appendChild(input);
    el.appendChild(answersEl);
    return el;
  }

  function selectAnswer(di, qi, value, answersEl) {
    const key = `${di}_${qi}`;
    answers[key] = value;

    answersEl.querySelectorAll('.wpq-answer-btn').forEach(btn => {
      btn.classList.remove('selected-yes', 'selected-partial', 'selected-no');
    });
    const selected = answersEl.querySelector(`[data-value="${value}"]`);
    if (selected) selected.classList.add(`selected-${value}`);

    const qEl = root.querySelector(`.wpq-question[data-di="${di}"][data-qi="${qi}"]`);
    if (qEl) qEl.classList.remove('wpq-question-unanswered');

    updateProgress();
    updateDomainTabs();
    updateConditionalVisibility();
    scheduleHeartbeat(key);
  }

  function toggleCheckboxAnswer(di, qi, optKey, question, answersEl) {
    const key     = `${di}_${qi}`;
    const current = answers[key] ? JSON.parse(answers[key]) : [];
    const opts    = question ? (question.options || []) : [];
    const maxSel  = question ? (question.max_selections || null) : null;

    const clickedOpt  = opts.find(o => o.key === optKey);
    const isExclusive = clickedOpt && clickedOpt.exclusive;
    const idx = current.indexOf(optKey);

    if (idx >= 0) {
      // Uncheck.
      current.splice(idx, 1);
    } else {
      if (isExclusive) {
        // Exclusive option: clear all others.
        current.length = 0;
        current.push(optKey);
      } else {
        // Non-exclusive: clear any exclusive option already selected.
        const exclusiveKeys = opts.filter(o => o.exclusive).map(o => o.key);
        exclusiveKeys.forEach(k => {
          const i = current.indexOf(k);
          if (i >= 0) current.splice(i, 1);
        });
        // Enforce max_selections.
        if (maxSel !== null && current.length >= maxSel) {
          // Revert the checkbox visually (the UI checked it before we got here).
          if (answersEl) {
            const cb = answersEl.querySelector(`input[value="${optKey}"]`);
            if (cb) cb.checked = false;
          }
          return; // Discard — max already reached.
        }
        current.push(optKey);
      }
      // Sync exclusive uncheck to DOM.
      if (answersEl) {
        answersEl.querySelectorAll('input[type="checkbox"]').forEach(cb => {
          if (cb.value !== optKey) {
            const existingOpt = opts.find(o => o.key === cb.value);
            if (isExclusive || (existingOpt && existingOpt.exclusive)) {
              cb.checked = false;
            }
          }
        });
      }
    }

    if (current.length > 0) {
      answers[key] = JSON.stringify(current);
      const qEl = root.querySelector(`.wpq-question[data-di="${di}"][data-qi="${qi}"]`);
      if (qEl) qEl.classList.remove('wpq-question-unanswered');
    } else {
      delete answers[key];
    }
    updateProgress();
    updateDomainTabs();
    updateConditionalVisibility();
    scheduleHeartbeat(key);
  }

  function updateMemoAnswer(di, qi, value) {
    const key = `${di}_${qi}`;
    if (value.trim() !== '') {
      answers[key] = value;
      const qEl = root.querySelector(`.wpq-question[data-di="${di}"][data-qi="${qi}"]`);
      if (qEl) qEl.classList.remove('wpq-question-unanswered');
    } else {
      delete answers[key];
    }
    updateProgress();
    updateDomainTabs();
    updateConditionalVisibility();
    scheduleHeartbeat(key);
  }

  // -----------------------------------------------------------------------
  // Conditional visibility
  // -----------------------------------------------------------------------

  function evaluateCondition(condition) {
    if (!condition) return true;
    const controlRaw = answers[condition.key];
    if (controlRaw === undefined || controlRaw === null) return false;

    const condVal = String(condition.value);
    const op      = condition.op || 'eq';
    const scalar  = String(controlRaw);

    if (op === 'contains' || op === 'not_contains') {
      let arr = [scalar];
      try { const p = JSON.parse(controlRaw); if (Array.isArray(p)) arr = p.map(String); } catch(e) {}
      return op === 'contains' ? arr.includes(condVal) : !arr.includes(condVal);
    }
    if (op === 'eq') return scalar === condVal;
    if (op === 'ne') return scalar !== condVal;
    return false;
  }

  function updateConditionalVisibility() {
    if (!questionnaire) return;
    root.querySelectorAll('.wpq-question').forEach(qEl => {
      const di       = parseInt(qEl.dataset.di, 10);
      const qi       = parseInt(qEl.dataset.qi, 10);
      const question = questionnaire.domains[di] && questionnaire.domains[di].questions[qi];
      if (!question) return;

      const visible = evaluateCondition(question.condition || null);
      const wasHidden = qEl.classList.contains('wpq-question-hidden');
      qEl.classList.toggle('wpq-question-hidden', !visible);

      // Clear answer if question just became hidden.
      if (!visible && !wasHidden) {
        delete answers[`${di}_${qi}`];
      }
    });
  }

  // -----------------------------------------------------------------------
  // Navigation
  // -----------------------------------------------------------------------

  function setDomain(di) {
    // Tab clicks always go directly to questions (not brief).
    navigateTo(di, 'questions');
  }

  function goBack() {
    if (currentView === 'brief') {
      if (currentDomain > 0) navigateTo(currentDomain - 1, 'questions');
      // else: back button is hidden — should not be reachable
    } else {
      if (hasBrief(currentDomain)) {
        navigateTo(currentDomain, 'brief');
      } else if (currentDomain > 0) {
        navigateTo(currentDomain - 1, 'questions');
      }
    }
  }

  function unansweredInDomain(di) {
    const domain = questionnaire.domains[di];
    const missing = [];
    domain.questions.forEach((q, qi) => {
      if (isQuestionHidden(di, qi)) return;
      if (q.is_required === false) return;
      if (answers[`${di}_${qi}`] !== undefined) return;
      const el = root.querySelector(`.wpq-question[data-di="${di}"][data-qi="${qi}"]`);
      if (el) missing.push({ qi, el });
    });
    return missing;
  }

  function clearValidationHighlights() {
    root.querySelectorAll('.wpq-question-unanswered').forEach(el => {
      el.classList.remove('wpq-question-unanswered');
    });
  }

  async function goNext() {
    // Brief page → go to domain questions.
    if (currentView === 'brief') {
      navigateTo(currentDomain, 'questions');
      return;
    }

    // Questions page.
    const total = questionnaire.domains.length;
    if (currentDomain < total - 1) {
      const missing = unansweredInDomain(currentDomain);
      if (missing.length > 0) {
        clearValidationHighlights();
        missing.forEach(({ el }) => el.classList.add('wpq-question-unanswered'));
        missing[0].el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        showError(
          `Please answer ${missing.length} required question${missing.length !== 1 ? 's' : ''} in this section (highlighted in red) before continuing.`
        );
        return;
      }
      clearValidationHighlights();
      hideError();
      const nextDi = currentDomain + 1;
      navigateTo(nextDi, hasBrief(nextDi) ? 'brief' : 'questions');
      return;
    }
    // Submit.
    await submitAssessment();
  }

  // -----------------------------------------------------------------------
  // Progress tracking
  // -----------------------------------------------------------------------

  function isQuestionHidden(di, qi) {
    const qEl = root.querySelector(`.wpq-question[data-di="${di}"][data-qi="${qi}"]`);
    return qEl ? qEl.classList.contains('wpq-question-hidden') : false;
  }

  function updateProgress() {
    let totalQ   = 0;
    let answered = 0;
    questionnaire.domains.forEach((domain, di) => {
      domain.questions.forEach((q, qi) => {
        if (isQuestionHidden(di, qi)) return;
        totalQ++;
        if (answers[`${di}_${qi}`] !== undefined) answered++;
      });
    });
    const pct = totalQ > 0 ? Math.round((answered / totalQ) * 100) : 0;

    setText('wpq-answered-label', `${answered} of ${totalQ} answered`);
    setText('wpq-pct-label', `${pct}%`);

    const fill = byId('wpq-progress-fill');
    if (fill) fill.style.width = `${pct}%`;

    const bar = byId('wpq-progress-bar-wrap');
    if (bar) bar.setAttribute('aria-valuenow', pct);
  }

  function updateDomainTabs() {
    root.querySelectorAll('.wpq-dtab').forEach((tab, di) => {
      const domain   = questionnaire.domains[di];
      const complete = domain.questions.every((q, qi) => {
        if (isQuestionHidden(di, qi)) return true;
        if (q.is_required === false) return true;
        return answers[`${di}_${qi}`] !== undefined;
      });
      tab.classList.toggle('completed', complete && di !== currentDomain);
    });
  }

  // -----------------------------------------------------------------------
  // Heartbeat
  // -----------------------------------------------------------------------

  function scheduleHeartbeat(key) {
    pendingHeartbeat = key;
    clearTimeout(heartbeatTimer);
    heartbeatTimer = setTimeout(sendHeartbeat, HEARTBEAT_DELAY);
  }

  function sendHeartbeat() {
    if (!submissionId || !sessionToken || !pendingHeartbeat) return;
    apiFetch('POST', 'heartbeat', {
      submission_id:  submissionId,
      session_token:  sessionToken,
      last_question:  pendingHeartbeat,
    }).catch(() => {}); // fire and forget — errors are non-fatal
  }

  // -----------------------------------------------------------------------
  // Submit assessment
  // -----------------------------------------------------------------------

  async function submitAssessment() {
    const nextBtn = byId('wpq-next-btn');
    nextBtn.disabled    = true;
    nextBtn.textContent = 'Calculating…';

    showLoading(true);

    try {
      const payload = {
        submission_id:  submissionId,
        session_token:  sessionToken,
        answers:        answers,
      };

      const report = await apiFetch('POST', 'submit', payload);
      microReport  = report;
      hideError();
      renderResults(report);
      showStep('results');
    } catch (err) {
      if (err.code === 'INCOMPLETE_ANSWERS') {
        showError('Please answer all questions before submitting. Check all domain tabs for unanswered questions.');
        showStep('assessment');
      } else {
        showError(err.message || 'Something went wrong. Please try again.');
      }
    } finally {
      showLoading(false);
      nextBtn.disabled    = false;
      nextBtn.textContent = 'See my results →';
    }
  }

  // -----------------------------------------------------------------------
  // Results rendering
  // -----------------------------------------------------------------------

  // ---------------------------------------------------------------- //
  // Questionnaire Report delivery
  // ---------------------------------------------------------------- //

  let reportDeliveryPollTimer = null;

  // The report is generated in the background after submission, so the results
  // screen shows progress and then either a secure download link or the note
  // that it has been emailed. Polling stops as soon as it reaches a settled
  // state, and gives up after a bounded number of attempts so a stuck job
  // cannot leave the page polling forever.
  function renderReportDelivery(state) {
    const container = byId('wpq-report-delivery');
    const message   = byId('wpq-report-delivery-message');
    const download  = byId('wpq-report-delivery-download');
    if (!container || !message || !download) { return; }

    if (!state || !state.channels || !state.channels.length) {
      container.classList.add('wpq-hidden');
      return;
    }

    container.classList.remove('wpq-hidden');
    message.textContent = state.message || '';

    if (state.status === 'ready' && state.download_url) {
      download.href = state.download_url;
      download.classList.remove('wpq-hidden');
    } else {
      download.classList.add('wpq-hidden');
    }

    if (state.status === 'generating') {
      startReportDeliveryPolling();
    } else {
      stopReportDeliveryPolling();
    }
  }

  function startReportDeliveryPolling(attempt = 0) {
    stopReportDeliveryPolling();
    if (attempt >= 40 || !submissionId || !sessionToken) { return; }

    reportDeliveryPollTimer = setTimeout(async () => {
      try {
        const state = await apiFetch(
          'GET',
          'questionnaire-report-status/' + encodeURIComponent(submissionId) +
            '?session_token=' + encodeURIComponent(sessionToken)
        );
        renderReportDelivery(state);
        if (state && state.status === 'generating') {
          startReportDeliveryPolling(attempt + 1);
        }
      } catch (err) {
        // A failed poll is not worth surfacing: the customer still has their
        // on-screen results, and the email channel (if enabled) is unaffected.
        startReportDeliveryPolling(attempt + 1);
      }
    }, 5000);
  }

  function stopReportDeliveryPolling() {
    if (reportDeliveryPollTimer) {
      clearTimeout(reportDeliveryPollTimer);
      reportDeliveryPollTimer = null;
    }
  }

  function renderResults(report) {
    const overallPct = normalisePercent(report.overall_score);
    renderReportDelivery(report.report_delivery);

    // Score ring.
    const circumference = 2 * Math.PI * 52; // 326.73
    const offset = circumference - (overallPct / 100) * circumference;
    const fill = byId('wpq-ring-fill');
    const gradeStyle = gradeStyleForScore(overallPct, report);
    const color = gradeStyle.color;

    if (fill) {
      fill.style.stroke = color;
      setTimeout(() => { fill.style.strokeDashoffset = offset; }, 50);
    }

    animateCounter('wpq-score-numeral', 0, overallPct, 1000, '%');
    const scoreNumeral = byId('wpq-score-numeral');
    if (scoreNumeral) {
      scoreNumeral.style.color = color;
    }
    const ringBg = root.querySelector('.wpq-ring-bg');
    if (ringBg) {
      ringBg.style.stroke = gradeStyle.bg;
    }

    // Grade pill.
    const pill = byId('wpq-grade-pill');
    if (pill) {
      pill.textContent = report.grade_label;
      pill.style.background = gradeStyle.bg;
      pill.style.color = color;
    }

    setText('wpq-verdict', report.verdict);

    // Domain grid.
    const grid = byId('wpq-domain-grid');
    if (grid) {
      grid.innerHTML = '';
      report.domains.forEach(d => {
        const pct = normalisePercent(d.pct);
        const barStyle = gradeStyleForDomain(d, report);
        const card = document.createElement('div');
        card.className = 'wpq-domain-card';

        const header = document.createElement('div');
        header.className = 'wpq-domain-card-header';
        const cardName = document.createElement('span');
        cardName.className = 'wpq-domain-card-name';
        cardName.textContent = d.name;
        const cardPct = document.createElement('span');
        cardPct.className = 'wpq-domain-card-pct';
        cardPct.style.color = barStyle.color;
        cardPct.textContent = pct + '%';
        header.appendChild(cardName);
        header.appendChild(cardPct);

        const track = document.createElement('div');
        track.className = 'wpq-domain-bar-track';
        track.style.background = barStyle.bg;
        const fill = document.createElement('div');
        fill.className = 'wpq-domain-bar-fill';
        fill.style.width = '0%';
        fill.style.background = barStyle.color;
        fill.dataset.pct = pct;
        track.appendChild(fill);

        card.appendChild(header);
        card.appendChild(track);
        grid.appendChild(card);
      });
      // Animate bars after paint.
      setTimeout(() => {
        grid.querySelectorAll('.wpq-domain-bar-fill').forEach(el => {
          el.style.width = el.dataset.pct + '%';
        });
      }, 100);
    }

    // Recommendations.
    const list = byId('wpq-findings-list');
    const filterCt = byId('wpq-findings-filters');
    if (list) {
      list.innerHTML = '';
      if (filterCt) filterCt.innerHTML = '';
      const actions = Array.isArray(report.top_actions) ? report.top_actions : [];
      const actionablePriorities = new Set(['critical', 'high', 'medium', 'low']);
      const severityRank = { critical: 0, high: 1, medium: 2, low: 3, good: 4 };
      const severityLabels = { critical: 'Critical', high: 'High', medium: 'Medium', low: 'Low', good: 'Good Practice' };
      const sortedActions = actions
        .sort(function(a, b) {
          const domainA = (a.domain || '').toLowerCase();
          const domainB = (b.domain || '').toLowerCase();
          const domainCmp = domainA.localeCompare(domainB);
          if (domainCmp !== 0) return domainCmp;

          const sevA = severityRank[normalisePriority(a.priority)] ?? 99;
          const sevB = severityRank[normalisePriority(b.priority)] ?? 99;
          if (sevA !== sevB) return sevA - sevB;

          return (a.question || a.action || '').localeCompare(b.question || b.action || '');
        });
      const actionableActions = sortedActions.filter(f => actionablePriorities.has(normalisePriority(f.priority)));

      function makeFindingCard(f) {
        const priority = normalisePriority(f.priority);
        const li = document.createElement('li');
        li.className = 'wpq-finding ' + priority;
        li.dataset.severity = priority;
        li.dataset.domain = f.domain || '';
        li.dataset.domainSlug = f.domain_slug || '';

        const body = document.createElement('div');
        body.className = 'wpq-finding-body';

        const hdr = document.createElement('div');
        hdr.className = 'wpq-finding-header';
        const lbl = document.createElement('span');
        lbl.className = 'wpq-finding-label';
        lbl.textContent = severityLabels[priority] || 'Finding';
        hdr.appendChild(lbl);
        if (f.domain) {
          const dm = document.createElement('span');
          dm.className = 'wpq-finding-domain';
          dm.textContent = f.domain;
          hdr.appendChild(dm);
        }
        body.appendChild(hdr);

        if (f.question) {
          const q = document.createElement('p');
          q.className = 'wpq-finding-question';
          q.textContent = f.question;
          body.appendChild(q);
        }

        if (f.answer_label) {
          const a = document.createElement('p');
          a.className = 'wpq-finding-answer';
          const key = document.createElement('span');
          key.className = 'wpq-finding-answer-key';
          key.textContent = 'You answered:';
          a.appendChild(key);
          a.appendChild(document.createTextNode(' ' + f.answer_label));
          body.appendChild(a);
        }

        const rec = document.createElement('p');
        rec.className = 'wpq-finding-text';
        rec.textContent = f.action || f.question || '';
        body.appendChild(rec);

        li.appendChild(body);
        return li;
      }

      function makeCtaCard(cta, domainName) {
        const li = document.createElement('li');
        li.className = 'wpq-finding wpq-result-cta';
        li.dataset.severity = 'cta';
        li.dataset.domain = domainName || '';
        li.dataset.domainSlug = cta.domain_slug || '';

        const body = document.createElement('div');
        body.className = 'wpq-result-cta-body';
        body.innerHTML = cta.html || '';
        li.appendChild(body);
        return li;
      }

      const ctas = report.ctas || {};
      const domainCtas = Array.isArray(ctas.domains) ? ctas.domains : [];
      const visibleDomainSlugs = new Set(actionableActions.map(f => f.domain_slug || '').filter(Boolean));
      const domainCtaMap = new Map(
        shuffleArray(domainCtas.filter(cta => visibleDomainSlugs.has(cta.domain_slug || '')))
          .slice(0, 3)
          .map(cta => [cta.domain_slug || '', cta])
      );
      const appendedDomainCtas = new Set();
      const domainNamesBySlug = new Map();
      sortedActions.forEach(f => {
        if (f.domain_slug && f.domain) {
          domainNamesBySlug.set(f.domain_slug, f.domain);
        }
      });
      const nextActionableDomainByFinding = new Map();
      actionableActions.forEach((f, index) => {
        nextActionableDomainByFinding.set(f, (actionableActions[index + 1] || {}).domain_slug || null);
      });

      sortedActions.forEach(f => {
        list.appendChild(makeFindingCard(f));
        const thisDomainSlug = f.domain_slug || '';
        const nextDomainSlug = nextActionableDomainByFinding.get(f);
        if (
          actionablePriorities.has(normalisePriority(f.priority)) &&
          thisDomainSlug &&
          thisDomainSlug !== nextDomainSlug &&
          domainCtaMap.has(thisDomainSlug) &&
          !appendedDomainCtas.has(thisDomainSlug)
        ) {
          list.appendChild(makeCtaCard(domainCtaMap.get(thisDomainSlug), domainNamesBySlug.get(thisDomainSlug) || f.domain || ''));
          appendedDomainCtas.add(thisDomainSlug);
        }
      });

      const categoryCta = byId('wpq-category-cta');
      if (categoryCta) {
        if (ctas.category && ctas.category.html) {
          categoryCta.innerHTML = ctas.category.html;
          categoryCta.classList.remove('wpq-hidden');
        } else {
          categoryCta.innerHTML = '';
          categoryCta.classList.add('wpq-hidden');
        }
      }

      // Filter controls — built dynamically from findings data.
      if (filterCt && sortedActions.length > 0) {
        const domains = [...new Set(sortedActions.map(f => f.domain).filter(Boolean))];
        const priorities = [...new Set(sortedActions.map(f => normalisePriority(f.priority)).filter(Boolean))]
          .sort((a, b) => (severityRank[a] ?? 99) - (severityRank[b] ?? 99));

        function makeFilterGroup(labelText, items, dataAttr, activeVal) {
          const grp = document.createElement('div');
          grp.className = 'wpq-filter-group';
          const lbl = document.createElement('span');
          lbl.className = 'wpq-filter-label';
          lbl.textContent = labelText;
          grp.appendChild(lbl);
          const row = document.createElement('div');
          row.className = 'wpq-filter-btns';
          items.forEach(item => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'wpq-filter-btn' + (item.value === activeVal ? ' active' : '');
            btn.dataset[dataAttr] = item.value;
            btn.textContent = item.label;
            row.appendChild(btn);
          });
          grp.appendChild(row);
          return grp;
        }

        const sevItems = [
          {value:'actionable', label:'Actionable'},
          {value:'all', label:'All'},
          ...priorities.map(p => ({value:p, label:severityLabels[p] || p}))
        ];
        const sevGrp = makeFilterGroup('Severity', sevItems, 'filterSeverity', 'actionable');
        filterCt.appendChild(sevGrp);

        if (domains.length > 1) {
          const domItems = [{value:'all', label:'All'}, ...domains.map(d => ({value:d, label:d}))];
          filterCt.appendChild(makeFilterGroup('Domain', domItems, 'filterDomain', 'all'));
        }

        function applyFilters() {
          const sevEl = filterCt.querySelector('[data-filter-severity].active');
          const domEl = filterCt.querySelector('[data-filter-domain].active');
          const activeSev = sevEl ? sevEl.dataset.filterSeverity : 'all';
          const activeDom = domEl ? domEl.dataset.filterDomain : 'all';
          list.querySelectorAll('.wpq-finding').forEach(item => {
            const showSev = activeSev === 'all'
              || item.dataset.severity === activeSev
              || (activeSev === 'actionable' && (actionablePriorities.has(item.dataset.severity) || item.dataset.severity === 'cta'));
            const showDom = activeDom === 'all' || item.dataset.domain === activeDom;
            item.style.display = showSev && showDom ? '' : 'none';
          });
        }

        filterCt.addEventListener('click', function(e) {
          const btn = e.target.closest('.wpq-filter-btn');
          if (!btn) return;
          if ('filterSeverity' in btn.dataset) {
            filterCt.querySelectorAll('[data-filter-severity]').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            // Reset domain to All (mutually exclusive).
            filterCt.querySelectorAll('[data-filter-domain]').forEach(b => {
              b.classList.toggle('active', b.dataset.filterDomain === 'all');
            });
          } else if ('filterDomain' in btn.dataset) {
            filterCt.querySelectorAll('[data-filter-domain]').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            // Reset severity to All (mutually exclusive).
            filterCt.querySelectorAll('[data-filter-severity]').forEach(b => {
              b.classList.toggle('active', b.dataset.filterSeverity === 'all');
            });
          }
          applyFilters();
        });
        applyFilters();
      }
    }

    setupRemediationPlan();

    // Upgrade CTA.
    const products = questionnaire.products || [];
    const ctaEl    = byId('wpq-upgrade-cta');
    const listEl   = byId('wpq-product-list');

    if (config.showPricing && products.length > 0 && ctaEl && listEl) {
      listEl.innerHTML = '';
      products.forEach(p => {
        const billing = p.billing_type === 'one_off' ? 'one-off payment'
                      : p.billing_type === 'subscription_annual' ? 'per year'
                      : 'per month';
        const card = document.createElement('div');
        card.className = 'wpq-product-card';

        const priceEl = document.createElement('div');
        priceEl.className = 'wpq-product-price';
        priceEl.textContent = '£' + Number(p.price_gbp).toFixed(2);

        const billingEl = document.createElement('div');
        billingEl.className = 'wpq-product-billing';
        billingEl.textContent = billing;

        const descEl = document.createElement('div');
        descEl.className = 'wpq-product-desc';
        descEl.textContent = p.description;

        const btnEl = document.createElement('button');
        btnEl.className = 'wpq-product-btn';
        btnEl.dataset.productId = p.id;
        btnEl.setAttribute('aria-label', 'Purchase ' + p.name);
        btnEl.textContent = p.name + ' →';

        card.appendChild(priceEl);
        card.appendChild(billingEl);
        card.appendChild(descEl);
        card.appendChild(btnEl);
        listEl.appendChild(card);
      });

      listEl.querySelectorAll('.wpq-product-btn').forEach(btn => {
        btn.addEventListener('click', () => initiateCheckout(Number(btn.dataset.productId), btn));
      });

      ctaEl.classList.remove('wpq-hidden');
    }
  }

  function setupRemediationPlan() {
    const panel = byId('wpq-remediation-plan');
    const button = byId('wpq-remediation-download');
    const status = byId('wpq-remediation-status');
    const days = byId('wpq-remediation-days');
    if (!panel || !button || !status || !days) return;

    if (!config.remediationPlanEnabled) {
      panel.classList.add('wpq-hidden');
      return;
    }

    panel.classList.remove('wpq-hidden');
    button.onclick = () => downloadRemediationPlan(button, status, days);
  }

  async function downloadRemediationPlan(button, status, daysSelect) {
    if (!submissionId || !sessionToken) {
      status.textContent = 'We could not find this assessment session. Please refresh and try again.';
      return;
    }

    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = 'Generating...';
    status.textContent = 'Generating your workbook. This can take a moment.';

    try {
      const response = await apiFetch('POST', 'remediation-plan', {
        submission_id: submissionId,
        session_token: sessionToken,
        days: Number(daysSelect.value || 90),
      }, 60000);

      if (!response.file_base64 || !response.filename) {
        throw new Error('The remediation plan was not returned.');
      }

      const blob = base64ToBlob(
        response.file_base64,
        response.content_type || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      );
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = response.filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      status.textContent = 'Your remediation plan has downloaded.';
    } catch (err) {
      status.textContent = err.message || 'Could not generate the remediation plan. Please try again.';
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  }

  function base64ToBlob(base64, contentType) {
    const binary = window.atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new Blob([bytes], { type: contentType });
  }

  async function initiateCheckout(productId, button) {
    if (!submissionId || !sessionToken || !productId) {
      showError('We could not start checkout for this assessment. Please refresh and try again.');
      return;
    }

    const originalText = button ? button.textContent : '';
    if (button) {
      button.disabled = true;
      button.textContent = 'Starting checkout...';
    }
    hideError();

    try {
      const response = await apiFetch('POST', 'checkout', {
        submission_id: submissionId,
        session_token: sessionToken,
        product_id: productId,
      });

      if (!response.checkout_url) {
        throw new Error('Checkout is not available right now.');
      }

      window.location.assign(response.checkout_url);
    } catch (err) {
      showError(err.message || 'Could not start checkout. Please try again.');
      if (button) {
        button.disabled = false;
        button.textContent = originalText;
      }
    }
  }

  // -----------------------------------------------------------------------
  // Restart
  // -----------------------------------------------------------------------

  function restart() {
    answers          = {};
    currentDomain    = 0;
    currentView      = 'questions';
    submissionId     = null;
    sessionToken     = null;
    microReport      = null;
    pendingHeartbeat = null;
    clearTimeout(heartbeatTimer);

    stopReportDeliveryPolling();
    byId('wpq-upgrade-cta').classList.add('wpq-hidden');
    byId('wpq-category-cta').classList.add('wpq-hidden');
    byId('wpq-remediation-plan').classList.add('wpq-hidden');
    byId('wpq-report-delivery').classList.add('wpq-hidden');
    byId('wpq-lead-form').reset();
    captureAttribution();
    showStep('lead');
  }

  // -----------------------------------------------------------------------
  // UI helpers
  // -----------------------------------------------------------------------

  function showStep(name) {
    ['lead', 'assessment', 'results'].forEach(n => {
      byId(`wpq-step-${n}`).classList.toggle('wpq-hidden', n !== name);
    });
  }

  function showLoading(visible) {
    byId('wpq-loading').classList.toggle('wpq-hidden', !visible);
  }

  function showError(msg) {
    const el  = byId('wpq-error-state');
    const txt = byId('wpq-error-message');
    if (txt) txt.textContent = msg;
    el.classList.remove('wpq-hidden');
  }

  function hideError() {
    byId('wpq-error-state').classList.add('wpq-hidden');
  }

  function setText(id, text) {
    const el = byId(id);
    if (el) el.textContent = text;
  }

  function esc(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function normalisePercent(value) {
    const pct = Number(value);
    if (!Number.isFinite(pct)) return 0;
    return Math.max(0, Math.min(100, Math.round(pct)));
  }

  function normalisePriority(value) {
    const priority = String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
    if (['good', 'good_practice', 'informational', 'information', 'info'].includes(priority)) {
      return 'good';
    }
    return priority;
  }

  function shuffleArray(items) {
    const shuffled = items.slice();
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  function fallbackDomainColor(pct) {
    const safePct = normalisePercent(pct);
    if (safePct >= 70) return '#2eb872';
    if (safePct >= 40) return '#f5a623';
    return '#e84855';
  }

  function fallbackDomainBg(pct) {
    const safePct = normalisePercent(pct);
    if (safePct >= 70) return '#d4f5e5';
    if (safePct >= 40) return '#fef3d8';
    return '#fff5f5';
  }

  function safeHexColor(value, fallback) {
    if (typeof value !== 'string') return fallback;
    const trimmed = value.trim();
    return /^#[0-9a-f]{6}$/i.test(trimmed) || /^#[0-9a-f]{3}$/i.test(trimmed) ? trimmed : fallback;
  }

  function gradeStyleForScore(score, report) {
    const safePct = normalisePercent(score);
    const fallback = {
      color: safeHexColor(report && report.grade_color, fallbackDomainColor(safePct)),
      bg: safeHexColor(report && report.grade_bg, fallbackDomainBg(safePct)),
    };

    const gradeScale = report && Array.isArray(report.grade_scale)
      ? report.grade_scale
      : questionnaire && Array.isArray(questionnaire.thresholds)
        ? questionnaire.thresholds
        : [];

    if (!gradeScale.length) {
      return fallback;
    }

    const scale = gradeScale
      .map(grade => ({
        min: Number(grade.min_score),
        color: safeHexColor(grade.color || grade.color_hex || grade.grade_color, fallback.color),
        bg: safeHexColor(grade.bg || grade.bg_hex || grade.grade_bg, fallback.bg),
      }))
      .filter(grade => Number.isFinite(grade.min))
      .sort((a, b) => b.min - a.min);

    const match = scale.find(grade => safePct >= grade.min);
    if (!match) return fallback;

    return {
      color: match.color,
      bg: match.bg,
    };
  }

  function gradeStyleForDomain(domain, report) {
    const style = gradeStyleForScore(domain && domain.pct, report);

    return {
      color: safeHexColor(domain && (domain.grade_color || domain.color || domain.color_hex), style.color),
      bg: safeHexColor(domain && (domain.grade_bg || domain.bg || domain.bg_hex), style.bg),
    };
  }

  function animateCounter(id, from, to, duration, suffix = '') {
    const el    = byId(id);
    if (!el) return;
    const start = performance.now();
    const step  = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      el.textContent = Math.round(from + (to - from) * easeOut(progress)) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

  // -----------------------------------------------------------------------
  // API fetch
  // -----------------------------------------------------------------------

  async function apiFetch(method, endpoint, body = null, timeoutMs = 15000) {
    const controller = new AbortController();
    const timeout    = setTimeout(() => controller.abort(), timeoutMs);

    const opts = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      signal: controller.signal,
    };

    if (body && method !== 'GET') {
      opts.body = JSON.stringify(body);
    }

    try {
      const url  = config.restUrl + endpoint;
      const res  = await fetch(url, opts);
      const data = await res.json();

      if (!res.ok) {
        const err  = new Error(data.message || 'Request failed');
        err.code   = data.code;
        err.status = res.status;
        throw err;
      }

      return data;
    } catch (err) {
      if (err.name === 'AbortError') {
        throw new Error('We could not reach the server. Please check your connection and try again.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }

  init();
  }

})();
