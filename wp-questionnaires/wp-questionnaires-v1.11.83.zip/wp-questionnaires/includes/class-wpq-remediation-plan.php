<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Remediation_Plan {

	private const API_URL = 'https://api.anthropic.com/v1/messages';
	private const MODELS_URL = 'https://api.anthropic.com/v1/models';
	private const API_VERSION = '2023-06-01';
	private const MODEL_CACHE_KEY = 'wpq_claude_models';
	private const MODEL_CACHE_TTL = 6 * HOUR_IN_SECONDS;
	private const FALLBACK_MODEL = 'claude-haiku-4-5-20251001';
	private const REQUEST_TIMEOUT = 120;
	private const REQUEST_MAX_TOKENS = 5000;
	private const DAY_SECONDS = 86400;
	private const DEBUG_ENABLED_OPTION = 'wpq_claude_debug_enabled';
	private const DEBUG_LOG_OPTION = 'wpq_claude_debug_log';
	private const DEBUG_LOG_LIMIT = 50;

	public static function is_configured(): bool {
		$details = self::get_api_key_details();
		return ! empty( $details['present'] );
	}

	public static function get_api_key_details(): array {
		$value  = '';
		$source = 'none';

		if ( defined( 'WPQ_CLAUDE_API_KEY' ) && constant( 'WPQ_CLAUDE_API_KEY' ) ) {
			$value  = (string) constant( 'WPQ_CLAUDE_API_KEY' );
			$source = 'constant';
		} else {
			$environment_value = getenv( 'CLAUDE_API_KEY' );
			if ( ! is_string( $environment_value ) || $environment_value === '' ) {
				$environment_value = getenv( 'ANTHROPIC_API_KEY' );
			}
			if ( is_string( $environment_value ) && $environment_value !== '' ) {
				$value  = $environment_value;
				$source = 'environment';
			} else {
				$option_value = (string) get_option( 'wpq_claude_api_key', '' );
				if ( $option_value !== '' ) {
					$value  = $option_value;
					$source = 'option';
				}
			}
		}

		return [
			'value'   => $value,
			'source'  => $source,
			'present' => $value !== '',
			'valid'   => $value !== '' && preg_match( '/^sk-ant-/', $value ) === 1,
		];
	}

	public static function generate_for_submission( object $submission, int $days ): array {
		if ( ! in_array( $days, [ 30, 60, 90 ], true ) ) {
			$days = 30;
		}

		$context = self::build_context( $submission, $days );
		self::log_debug_event( 'remediation_generation_start', [
			'submission_id' => (int) ( $submission->id ?? 0 ),
			'submission_ref' => (string) ( $submission->ref ?? '' ),
			'plan_days'     => $days,
			'context'       => self::context_summary( $context ),
		] );

		try {
			$tasks = self::request_tasks( $context, $days );
		} catch ( Throwable $e ) {
			self::log_debug_event( 'remediation_generation_failed', [
				'submission_id' => (int) ( $submission->id ?? 0 ),
				'submission_ref' => (string) ( $submission->ref ?? '' ),
				'plan_days'     => $days,
				'error_type'    => get_class( $e ),
				'error'         => $e->getMessage(),
			] );
			throw $e;
		}
		try {
			$binary = self::build_workbook( $context, $tasks, $days );
		} catch ( Throwable $e ) {
			self::log_debug_event( 'workbook_generation_failed', [
				'submission_id' => (int) ( $submission->id ?? 0 ),
				'submission_ref' => (string) ( $submission->ref ?? '' ),
				'error'         => $e->getMessage(),
			] );
			throw $e;
		}
		$ref     = preg_replace( '/[^A-Za-z0-9_-]+/', '-', (string) ( $submission->ref ?? 'submission-' . (int) $submission->id ) );

		self::log_debug_event( 'remediation_generation_success', [
			'submission_id' => (int) ( $submission->id ?? 0 ),
			'submission_ref' => (string) ( $submission->ref ?? '' ),
			'task_count'    => count( $tasks ),
			'bytes'         => strlen( $binary ),
		] );

		return [
			'filename' => 'wpq-remediation-plan-' . trim( (string) $ref, '-' ) . '.xlsx',
			'binary'   => $binary,
		];
	}

	public static function store_workbook( int $submission_id, string $filename, string $binary ): array {
		if ( $submission_id <= 0 || '' === $binary ) {
			return [];
		}

		$directory = self::get_storage_dir();
		if ( '' === $directory ) {
			return [];
		}

		$base_name = sanitize_file_name( $filename );
		if ( '' === $base_name || strtolower( pathinfo( $base_name, PATHINFO_EXTENSION ) ) !== 'xlsx' ) {
			$base_name = 'wpq-remediation-plan-' . $submission_id . '.xlsx';
		}

		$stem      = pathinfo( $base_name, PATHINFO_FILENAME );
		$file_name = preg_replace( '/[^A-Za-z0-9._-]/', '-', sprintf(
			'%s-%s.xlsx',
			$stem !== '' ? $stem : 'wpq-remediation-plan-' . $submission_id,
			substr( hash( 'sha256', $binary . wp_salt( 'auth' ) ), 0, 16 )
		) );
		$file_name = $file_name ?: 'wpq-remediation-plan-' . $submission_id . '.xlsx';
		$path      = $directory . DIRECTORY_SEPARATOR . $file_name;

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Plugin-owned generated workbook in uploads.
		if ( file_put_contents( $path, $binary ) === false ) {
			return [];
		}

		return [
			'path' => $file_name,
			'name' => $file_name,
		];
	}

	public static function get_storage_dir( bool $ensure = true ): string {
		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return '';
		}

		$upload = wp_upload_dir();
		if ( ! is_array( $upload ) || ! empty( $upload['error'] ) || empty( $upload['basedir'] ) ) {
			return '';
		}

		$directory = rtrim( (string) $upload['basedir'], DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'wp-questionnaires' . DIRECTORY_SEPARATOR . 'remediation-plans';
		if ( ! $ensure ) {
			return $directory;
		}

		if ( ! is_dir( $directory ) && function_exists( 'wp_mkdir_p' ) && ! wp_mkdir_p( $directory ) ) {
			return '';
		}
		if ( ! is_dir( $directory ) ) {
			return '';
		}

		self::write_access_guards( $directory );
		return $directory;
	}

	public static function resolve_workbook_path( string $stored_path ): ?string {
		$stored_path = trim( $stored_path );
		if ( '' === $stored_path || strtolower( pathinfo( $stored_path, PATHINFO_EXTENSION ) ) !== 'xlsx' ) {
			return null;
		}

		$directory = self::get_storage_dir();
		if ( '' === $directory ) {
			return null;
		}

		$storage_root = realpath( $directory );
		if ( ! is_string( $storage_root ) || '' === $storage_root ) {
			return null;
		}

		$is_absolute = str_starts_with( $stored_path, '/' )
			|| str_starts_with( $stored_path, '\\' )
			|| preg_match( '/^[A-Za-z]:[\/\\\\]/', $stored_path );
		$candidate = $is_absolute
			? $stored_path
			: $storage_root . DIRECTORY_SEPARATOR . ltrim( str_replace( [ '/', '\\' ], DIRECTORY_SEPARATOR, $stored_path ), DIRECTORY_SEPARATOR );

		$resolved = realpath( $candidate );
		if ( ! is_string( $resolved ) || '' === $resolved ) {
			return null;
		}

		$storage_root     = self::normalise_path_for_compare( rtrim( $storage_root, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR );
		$resolved_compare = self::normalise_path_for_compare( $resolved );
		if ( strncmp( $resolved_compare, $storage_root, strlen( $storage_root ) ) !== 0 ) {
			return null;
		}

		return strtolower( pathinfo( $resolved, PATHINFO_EXTENSION ) ) === 'xlsx' ? $resolved : null;
	}

	private static function normalise_path_for_compare( string $path ): string {
		$path = str_replace( '\\', '/', $path );
		return PHP_OS_FAMILY === 'Windows' ? strtolower( $path ) : $path;
	}

	private static function build_context( object $submission, int $days ): array {
		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire ) {
			throw new RuntimeException( 'Questionnaire not found.' );
		}

		$structure = WPQ_Database::get_questionnaire_structure( (int) $questionnaire->id );
		$answers   = json_decode( (string) ( $submission->answers_json ?? '{}' ), true );
		$findings  = json_decode( (string) ( $submission->findings_json ?? '[]' ), true );
		$domains   = json_decode( (string) ( $submission->domain_scores_json ?? '[]' ), true );

		if ( ! is_array( $answers ) ) {
			$answers = [];
		}
		if ( ! is_array( $findings ) ) {
			$findings = [];
		}
		if ( ! is_array( $domains ) ) {
			$domains = [];
		}

		return [
			'customer' => [
				'name'    => (string) ( $submission->contact_name ?? '' ),
				'company' => (string) ( $submission->contact_company ?? '' ),
				'email'   => (string) ( $submission->contact_email ?? '' ),
			],
			'assessment' => [
				'questionnaire_id' => (int) ( $questionnaire->id ?? 0 ),
				'submission_id'  => (int) ( $submission->id ?? 0 ),
				'ref'            => (string) ( $questionnaire->ref ?? '' ),
				'name'           => (string) ( $questionnaire->name ?? '' ),
				'plan_days'      => $days,
				'overall_score'  => (int) ( $submission->overall_score ?? 0 ),
				'grade_label'    => (string) ( $submission->grade_label ?? '' ),
				'completed_at'   => (string) ( $submission->completed_at ?? '' ),
			],
			'answers'  => self::build_answer_summary( $structure, $answers ),
			'domains'  => $domains,
			'findings' => self::actionable_findings( array_values( $findings ) ),
			'meta'     => [
				'source_finding_count' => count( $findings ),
			],
		];
	}

	private static function actionable_findings( array $findings ): array {
		return array_values( array_filter(
			$findings,
			static fn( mixed $finding ): bool => is_array( $finding )
				&& ! in_array(
					self::normalise_priority( (string) ( $finding['priority'] ?? $finding['finding_priority'] ?? $finding['severity'] ?? '' ) ),
					[ 'good', 'good_practice', 'informational', 'information', 'info' ],
					true
				)
		) );
	}

	private static function normalise_priority( string $priority ): string {
		return strtolower( str_replace( [ ' ', '-' ], '_', trim( $priority ) ) );
	}

	private static function build_answer_summary( array $structure, array $answers ): array {
		$rows = [];

		foreach ( $structure['domains'] ?? [] as $di => $domain ) {
			foreach ( $domain['questions'] ?? [] as $qi => $question ) {
				$key    = "{$di}_{$qi}";
				$answer = $answers[ $key ] ?? null;
				$label  = self::answer_label( $question, $answer );
				$rows[] = [
					'domain'         => (string) ( $domain['name'] ?? '' ),
					'domain_slug'    => (string) ( $domain['slug'] ?? '' ),
					'question_ref'   => (string) ( $question['question_ref'] ?? '' ),
					'question'       => (string) ( $question['question'] ?? '' ),
					'answer'         => $label,
					'recommendation' => (string) ( $question['recommendation'] ?? '' ),
				];
			}
		}

		return $rows;
	}

	private static function answer_label( array $question, mixed $answer ): string {
		if ( is_array( $answer ) ) {
			return implode( ', ', array_map( static fn( $item ) => self::answer_label( $question, $item ), $answer ) );
		}

		if ( is_string( $answer ) ) {
			$decoded = json_decode( $answer, true );
			if ( is_array( $decoded ) ) {
				return implode( ', ', array_map( static fn( $item ) => self::answer_label( $question, $item ), $decoded ) );
			}
		}

		foreach ( $question['options'] ?? [] as $option ) {
			if ( (string) ( $option['key'] ?? '' ) === (string) $answer ) {
				return (string) ( $option['label'] ?? $answer );
			}
		}

		return is_scalar( $answer ) ? (string) $answer : '';
	}

	private static function request_tasks( array $context, int $days ): array {
		$key_details = self::get_api_key_details();
		$api_key     = (string) ( $key_details['value'] ?? '' );
		if ( $api_key === '' ) {
			throw new RuntimeException( 'Claude API key missing.' );
		}

		$model  = self::select_model( $api_key );
		$prompt = self::build_prompt( $context, $days );
		$request_meta = [
			'endpoint'     => 'messages',
			'model'        => $model,
			'plan_days'    => $days,
			'prompt_chars' => strlen( $prompt ),
			'context'      => self::context_summary( $context ),
		];
		self::log_debug_event( 'claude_messages_request', $request_meta );

		$payload = wp_json_encode( [
			'model'      => $model,
			'max_tokens' => self::REQUEST_MAX_TOKENS,
			'system'     => 'You create practical cyber remediation plans. Return only valid JSON.',
			'messages'   => [
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			],
		] );
		if ( ! is_string( $payload ) || '' === $payload ) {
			self::log_debug_event( 'claude_messages_payload_encode_failed', $request_meta );
			throw new RuntimeException( 'Claude request payload could not be encoded.' );
		}

		self::log_debug_event( 'claude_messages_dispatch', $request_meta + [
			'timeout'       => self::REQUEST_TIMEOUT,
			'max_tokens'    => self::REQUEST_MAX_TOKENS,
			'payload_bytes' => strlen( $payload ),
		] );

		$started = microtime( true );
		$response = wp_remote_post(
			self::API_URL,
			[
				'timeout' => self::REQUEST_TIMEOUT,
				'headers' => [
					'content-type'      => 'application/json',
					'x-api-key'         => $api_key,
					'anthropic-version' => self::API_VERSION,
				],
				'body'    => $payload,
			]
		);
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		if ( is_wp_error( $response ) ) {
			self::log_debug_event( 'claude_messages_wp_error', $request_meta + [
				'elapsed_ms' => $elapsed_ms,
				'error'      => $response->get_error_message(),
			] );
			throw new RuntimeException( 'Claude request failed.' );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body_text = wp_remote_retrieve_body( $response );
		self::log_debug_event( 'claude_messages_response', $request_meta + [
			'status_code'      => $code,
			'request_id'       => self::response_header( $response, 'request-id' ),
			'elapsed_ms'       => $elapsed_ms,
			'body_chars'       => strlen( $body_text ),
			'body_excerpt'     => self::excerpt( $body_text, 1800 ),
			'usage'            => self::response_usage_summary( $body_text ),
		] );
		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( 'Claude returned an error response.' );
		}

		$body = json_decode( $body_text, true );
		if ( ! is_array( $body ) ) {
			self::log_debug_event( 'claude_messages_invalid_json', $request_meta + [
				'status_code'  => $code,
				'body_excerpt' => self::excerpt( $body_text, 1800 ),
			] );
			throw new RuntimeException( 'Claude response was not JSON.' );
		}

		self::store_provider_conversation_id( (int) ( $context['assessment']['submission_id'] ?? 0 ), $body );

		$text = '';
		foreach ( $body['content'] ?? [] as $part ) {
			if ( is_array( $part ) && ( $part['type'] ?? '' ) === 'text' ) {
				$text .= (string) ( $part['text'] ?? '' );
			}
		}

		try {
			$tasks = self::parse_tasks( $text );
		} catch ( Throwable $e ) {
			self::log_debug_event( 'claude_task_parse_failed', $request_meta + [
				'status_code'  => $code,
				'text_chars'   => strlen( $text ),
				'text_excerpt' => self::excerpt( $text, 1800 ),
				'error'        => $e->getMessage(),
			] );
			throw $e;
		}

		self::log_debug_event( 'claude_task_parse_success', $request_meta + [
			'status_code' => $code,
			'task_count'  => count( $tasks ),
			'text_chars'  => strlen( $text ),
		] );

		return $tasks;
	}

	private static function store_provider_conversation_id( int $submission_id, array $body ): void {
		if ( $submission_id <= 0 ) {
			return;
		}

		foreach ( [ 'conversation_id', 'session_id' ] as $key ) {
			$value = $body[ $key ] ?? '';
			if ( ! is_string( $value ) || '' === $value ) {
				continue;
			}

			if ( WPQ_Database::update_submission_claude_conversation_id( $submission_id, $value ) ) {
				self::log_debug_event( 'claude_provider_conversation_id_stored', [
					'submission_id' => $submission_id,
					'id_field'      => $key,
				] );
			}
			return;
		}
	}

	private static function write_access_guards( string $directory ): void {
		$index = $directory . DIRECTORY_SEPARATOR . 'index.html';
		if ( ! is_file( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Static guard file in plugin-owned uploads directory.
			file_put_contents( $index, '' );
		}

		$htaccess = $directory . DIRECTORY_SEPARATOR . '.htaccess';
		if ( ! is_file( $htaccess ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Best-effort Apache guard for generated private workbooks.
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" );
		}
	}

	public static function debug_logging_enabled(): bool {
		return get_option( self::DEBUG_ENABLED_OPTION, 'no' ) === 'yes';
	}

	public static function get_debug_log(): array {
		$rows = get_option( self::DEBUG_LOG_OPTION, [] );
		return is_array( $rows ) ? array_values( array_filter( $rows, 'is_array' ) ) : [];
	}

	public static function clear_debug_log(): void {
		delete_option( self::DEBUG_LOG_OPTION );
	}

	public static function get_model_preference(): string {
		$preference = sanitize_text_field( (string) get_option( 'wpq_claude_model', 'auto' ) );
		return $preference !== '' ? $preference : 'auto';
	}

	public static function select_model( string $api_key ): string {
		$preference = self::get_model_preference();
		if ( 'auto' !== $preference ) {
			return $preference;
		}

		$models = self::get_available_models( $api_key );
		$model  = self::choose_balanced_model( $models );

		return $model !== '' ? $model : self::FALLBACK_MODEL;
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_available_models( string $api_key ): array {
		$cached = get_transient( self::MODEL_CACHE_KEY );
		if ( is_array( $cached ) ) {
			return array_values( array_filter( $cached, 'is_array' ) );
		}

		$models   = [];
		$after_id = '';

		do {
			$url = self::MODELS_URL;
			if ( '' !== $after_id ) {
				$url = add_query_arg( [ 'after_id' => $after_id ], $url );
			}

			$response = wp_remote_get(
				$url,
				[
					'timeout' => 15,
					'headers' => [
						'x-api-key'         => $api_key,
						'anthropic-version' => self::API_VERSION,
					],
				]
			);

			if ( is_wp_error( $response ) ) {
				self::log_debug_event( 'claude_models_wp_error', [
					'endpoint' => 'models',
					'url'      => self::redact_url( $url ),
					'error'    => $response->get_error_message(),
				] );
				break;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body_text = wp_remote_retrieve_body( $response );
			self::log_debug_event( 'claude_models_response', [
				'endpoint'     => 'models',
				'url'          => self::redact_url( $url ),
				'status_code'  => $code,
				'request_id'   => self::response_header( $response, 'request-id' ),
				'body_chars'   => strlen( $body_text ),
				'body_excerpt' => self::excerpt( $body_text, 1200 ),
			] );
			if ( $code < 200 || $code >= 300 ) {
				break;
			}

			$body = json_decode( $body_text, true );
			if ( ! is_array( $body ) || ! isset( $body['data'] ) || ! is_array( $body['data'] ) ) {
				break;
			}

			foreach ( $body['data'] as $model ) {
				if ( is_array( $model ) && ! empty( $model['id'] ) ) {
					$models[] = $model;
				}
			}

			$has_more = ! empty( $body['has_more'] );
			$after_id = $has_more ? (string) ( $body['last_id'] ?? '' ) : '';
		} while ( $has_more && '' !== $after_id );

		set_transient( self::MODEL_CACHE_KEY, $models, self::MODEL_CACHE_TTL );
		return $models;
	}

	/**
	 * Pick the newest balanced model from the list returned by Anthropic.
	 *
	 * The Models API returns recently released models first. For remediation
	 * planning we prefer Haiku because this workload is structured JSON
	 * generation with a bounded workbook output. Sonnet remains the fallback for
	 * quality, and Opus is avoided unless no cheaper current model is listed.
	 *
	 * @param array<int, array<string, mixed>> $models Available model records.
	 */
	public static function choose_balanced_model( array $models ): string {
		foreach ( [ 'haiku', 'sonnet', 'opus' ] as $family ) {
			foreach ( $models as $model ) {
				$id   = strtolower( (string) ( $model['id'] ?? '' ) );
				$name = strtolower( (string) ( $model['display_name'] ?? '' ) );
				if ( '' !== $id && self::model_has_message_capacity( $model ) && ( str_contains( $id, $family ) || str_contains( $name, $family ) ) ) {
					return (string) $model['id'];
				}
			}
		}

		$first = $models[0]['id'] ?? '';
		return is_string( $first ) ? $first : '';
	}

	public static function get_model_diagnostics(): array {
		$details = self::get_api_key_details();
		$api_key = (string) ( $details['value'] ?? '' );
		$models  = $api_key !== '' ? self::get_available_models( $api_key ) : [];
		$selected = $api_key !== '' ? self::select_model( $api_key ) : self::FALLBACK_MODEL;

		return [
			'preference'      => self::get_model_preference(),
			'selected_model'  => $selected,
			'available_count' => count( $models ),
			'auto_available'  => ! empty( $models ),
		];
	}

	private static function model_has_message_capacity( array $model ): bool {
		$max_input = isset( $model['max_input_tokens'] ) ? (int) $model['max_input_tokens'] : 0;
		$max_output = isset( $model['max_tokens'] ) ? (int) $model['max_tokens'] : 0;
		if ( $max_input > 0 && $max_input < 50000 ) {
			return false;
		}
		if ( $max_output > 0 && $max_output < self::REQUEST_MAX_TOKENS ) {
			return false;
		}

		$capabilities = $model['capabilities'] ?? null;
		if ( is_array( $capabilities ) && isset( $capabilities['messages'] ) && false === (bool) $capabilities['messages'] ) {
			return false;
		}

		return true;
	}

	private static function log_debug_event( string $event, array $data = [] ): void {
		if ( ! self::debug_logging_enabled() ) {
			return;
		}

		$rows = self::get_debug_log();
		array_unshift( $rows, [
			'time'  => current_time( 'mysql', true ),
			'event' => sanitize_key( $event ),
			'data'  => self::sanitise_debug_data( $data ),
		] );

		$rows = array_slice( $rows, 0, self::DEBUG_LOG_LIMIT );
		update_option( self::DEBUG_LOG_OPTION, $rows, false );
	}

	private static function sanitise_debug_data( mixed $data ): mixed {
		if ( is_array( $data ) ) {
			$out = [];
			foreach ( $data as $key => $value ) {
				$clean_key = is_string( $key ) ? sanitize_key( $key ) : (int) $key;
				if ( in_array( (string) $clean_key, [ 'api_key', 'x-api-key', 'authorization', 'password', 'secret' ], true ) ) {
					$out[ $clean_key ] = '[redacted]';
					continue;
				}
				$out[ $clean_key ] = self::sanitise_debug_data( $value );
			}
			return $out;
		}

		if ( is_bool( $data ) || is_int( $data ) || is_float( $data ) || $data === null ) {
			return $data;
		}

		return self::excerpt( sanitize_textarea_field( (string) $data ), 2000 );
	}

	private static function context_summary( array $context ): array {
		return [
			'assessment_ref' => (string) ( $context['assessment']['ref'] ?? '' ),
			'plan_days'      => (int) ( $context['assessment']['plan_days'] ?? 0 ),
			'answer_count'   => is_array( $context['answers'] ?? null ) ? count( $context['answers'] ) : 0,
			'domain_count'   => is_array( $context['domains'] ?? null ) ? count( $context['domains'] ) : 0,
			'finding_count'  => is_array( $context['findings'] ?? null ) ? count( $context['findings'] ) : 0,
			'source_finding_count' => (int) ( $context['meta']['source_finding_count'] ?? 0 ),
		];
	}

	private static function response_usage_summary( string $body_text ): array {
		$body = json_decode( $body_text, true );
		if ( ! is_array( $body ) || ! isset( $body['usage'] ) || ! is_array( $body['usage'] ) ) {
			return [];
		}

		return [
			'input_tokens'  => isset( $body['usage']['input_tokens'] ) ? (int) $body['usage']['input_tokens'] : null,
			'output_tokens' => isset( $body['usage']['output_tokens'] ) ? (int) $body['usage']['output_tokens'] : null,
		];
	}

	private static function response_header( mixed $response, string $name ): string {
		if ( function_exists( 'wp_remote_retrieve_header' ) ) {
			$value = wp_remote_retrieve_header( $response, $name );
			return is_scalar( $value ) ? (string) $value : '';
		}

		return '';
	}

	private static function excerpt( string $text, int $limit ): string {
		$text = trim( preg_replace( '/\s+/', ' ', $text ) ?? $text );
		if ( strlen( $text ) <= $limit ) {
			return $text;
		}

		return substr( $text, 0, max( 0, $limit - 3 ) ) . '...';
	}

	private static function redact_url( string $url ): string {
		return remove_query_arg( [ 'api_key', 'key', 'token' ], $url );
	}

	private static function build_prompt( array $context, int $days ): string {
		$payload = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return "Create a {$days}-day remediation tasklist for this completed questionnaire.\n"
			. "Return strict JSON only with this shape: {\"tasks\":[{\"phase\":\"30|60|90\",\"due_day\":7,\"effort\":3,\"priority\":\"High|Medium|Low\",\"domain\":\"...\",\"task\":\"...\",\"details\":\"...\",\"success_criteria\":\"...\",\"owner\":\"...\"}]}.\n"
			. "Use effort as estimated working days from 1 to 20. Keep due_day inside the selected plan length.\n"
			. "Make tasks specific to the answers and recommendations. Use UK business-friendly wording. Do not include markdown.\n"
			. "Assessment context JSON:\n{$payload}";
	}

	private static function parse_tasks( string $text ): array {
		$text = trim( $text );
		if ( $text === '' ) {
			throw new RuntimeException( 'Claude response was empty.' );
		}

		$decoded = json_decode( $text, true );
		if ( ! is_array( $decoded ) ) {
			if ( preg_match( '/\{.*\}/s', $text, $matches ) ) {
				$decoded = json_decode( $matches[0], true );
			}
		}

		if ( ! is_array( $decoded ) || ! isset( $decoded['tasks'] ) || ! is_array( $decoded['tasks'] ) ) {
			throw new RuntimeException( 'Claude response did not contain tasks.' );
		}

		$tasks = [];
		foreach ( $decoded['tasks'] as $task ) {
			if ( ! is_array( $task ) ) {
				continue;
			}
			$tasks[] = [
				'phase'            => sanitize_text_field( (string) ( $task['phase'] ?? '' ) ),
				'due_day'          => max( 1, (int) ( $task['due_day'] ?? 1 ) ),
				'effort'           => isset( $task['effort'] ) ? max( 1, min( 20, (int) $task['effort'] ) ) : null,
				'priority'         => sanitize_text_field( (string) ( $task['priority'] ?? 'Medium' ) ),
				'domain'           => sanitize_text_field( (string) ( $task['domain'] ?? '' ) ),
				'task'             => sanitize_text_field( (string) ( $task['task'] ?? '' ) ),
				'details'          => sanitize_textarea_field( (string) ( $task['details'] ?? '' ) ),
				'success_criteria' => sanitize_textarea_field( (string) ( $task['success_criteria'] ?? '' ) ),
				'owner'            => sanitize_text_field( (string) ( $task['owner'] ?? 'Customer' ) ),
				'status'           => 'Not started',
			];
		}

		if ( empty( $tasks ) ) {
			throw new RuntimeException( 'Claude response did not contain usable tasks.' );
		}

		return $tasks;
	}

	private static function build_workbook( array $context, array $tasks, int $days ): string {
		$template_path = self::remediation_template_path( (int) ( $context['assessment']['questionnaire_id'] ?? 0 ) );
		if ( $template_path !== '' ) {
			try {
				return self::build_workbook_from_template( $template_path, $context, $tasks );
			} catch ( Throwable $e ) {
				self::log_debug_event( 'workbook_template_generation_failed', [
					'questionnaire_id' => (int) ( $context['assessment']['questionnaire_id'] ?? 0 ),
					'error'            => $e->getMessage(),
				] );
				throw $e;
			}
		}

		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( 'ZipArchive is not available.' );
		}

		$tmp = tempnam( sys_get_temp_dir(), 'wpq-remediation-' );
		if ( ! is_string( $tmp ) || $tmp === '' ) {
			throw new RuntimeException( 'Could not create workbook.' );
		}

		$zip = new ZipArchive();
		if ( $zip->open( $tmp, ZipArchive::OVERWRITE ) !== true ) {
			throw new RuntimeException( 'Could not open workbook archive.' );
		}

		$planner_rows = [
			[ 'Field', 'Value' ],
			[ 'Customer', (string) ( $context['customer']['name'] ?? '' ) ],
			[ 'Company', (string) ( $context['customer']['company'] ?? '' ) ],
			[ 'Questionnaire', (string) ( $context['assessment']['name'] ?? '' ) ],
			[ 'Questionnaire Ref', (string) ( $context['assessment']['ref'] ?? '' ) ],
			[ 'Overall Score', (string) ( $context['assessment']['overall_score'] ?? '' ) ],
			[ 'Grade', (string) ( $context['assessment']['grade_label'] ?? '' ) ],
			[ 'Plan Length', $days . ' days' ],
			[ 'Generated At', gmdate( 'c' ) ],
		];

		$task_rows = [
			[ 'Phase', 'Due Day', 'Priority', 'Domain', 'Task', 'Details', 'Success Criteria', 'Owner', 'Status' ],
		];
		foreach ( $tasks as $task ) {
			$task_rows[] = [
				(string) $task['phase'],
				(string) $task['due_day'],
				(string) $task['priority'],
				(string) $task['domain'],
				(string) $task['task'],
				(string) $task['details'],
				(string) $task['success_criteria'],
				(string) $task['owner'],
				(string) $task['status'],
			];
		}

		$zip->addFromString( '[Content_Types].xml', self::content_types_xml() );
		$zip->addFromString( '_rels/.rels', self::root_rels_xml() );
		$zip->addFromString( 'docProps/app.xml', self::app_xml() );
		$zip->addFromString( 'docProps/core.xml', self::core_xml() );
		$zip->addFromString( 'xl/workbook.xml', self::workbook_xml() );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', self::workbook_rels_xml() );
		$zip->addFromString( 'xl/styles.xml', self::styles_xml() );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', self::worksheet_xml( $planner_rows ) );
		$zip->addFromString( 'xl/worksheets/sheet2.xml', self::worksheet_xml( $task_rows ) );
		$zip->close();

		$binary = file_get_contents( $tmp );
		@unlink( $tmp );
		if ( ! is_string( $binary ) ) {
			throw new RuntimeException( 'Could not read workbook.' );
		}

		return $binary;
	}

	private static function remediation_template_path( int $questionnaire_id ): string {
		if ( $questionnaire_id <= 0 || ! function_exists( 'get_attached_file' ) ) {
			return '';
		}

		$questionnaire = WPQ_Database::get_questionnaire( $questionnaire_id );
		$attachment_id = (int) ( $questionnaire->remediation_template_attachment_id ?? 0 );
		if ( $attachment_id <= 0 ) {
			return '';
		}

		$path = get_attached_file( $attachment_id );
		return is_string( $path ) && is_readable( $path ) && strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) === 'xlsx' ? $path : '';
	}

	private static function build_workbook_from_template( string $template_path, array $context, array $tasks ): string {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( 'ZipArchive is not available.' );
		}

		$template = new ZipArchive();
		if ( $template->open( $template_path ) !== true ) {
			throw new RuntimeException( 'Could not open remediation workbook template.' );
		}

		$entries = [];
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- ZipArchive exposes this built-in property as numFiles.
		$num_files = (int) $template->numFiles;
		for ( $i = 0; $i < $num_files; $i++ ) {
			$name = $template->getNameIndex( $i );
			if ( ! is_string( $name ) || $name === 'xl/calcChain.xml' ) {
				continue;
			}
			$content = $template->getFromIndex( $i );
			if ( is_string( $content ) ) {
				$entries[ $name ] = $content;
			}
		}
		$template->close();
		if ( isset( $entries['xl/_rels/workbook.xml.rels'] ) ) {
			$entries['xl/_rels/workbook.xml.rels'] = preg_replace( '/<Relationship\b[^>]*Target="calcChain\.xml"[^>]*\/>/', '', $entries['xl/_rels/workbook.xml.rels'] ) ?? $entries['xl/_rels/workbook.xml.rels'];
		}
		if ( isset( $entries['[Content_Types].xml'] ) ) {
			$entries['[Content_Types].xml'] = preg_replace( '/<Override\b[^>]*PartName="\/xl\/calcChain\.xml"[^>]*\/>/', '', $entries['[Content_Types].xml'] ) ?? $entries['[Content_Types].xml'];
		}

		$sheet_path = self::template_sheet_path( $entries, 'Tasklist' );
		$table_path = self::template_table_path( $entries, 'TASKS' );
		if ( $sheet_path === '' || $table_path === '' || empty( $entries[ $sheet_path ] ) || empty( $entries[ $table_path ] ) ) {
			throw new RuntimeException( 'Remediation template must include a Tasklist sheet with a TASKS table.' );
		}

		$table_ref = self::table_ref( $entries[ $table_path ] );
		if ( $table_ref === [] ) {
			throw new RuntimeException( 'Remediation TASKS table range could not be read.' );
		}

		$rows = self::template_task_rows( $tasks );
		$entries[ $sheet_path ] = self::tasklist_sheet_xml( $entries[ $sheet_path ], $table_ref, $rows );
		$entries[ $table_path ] = self::update_table_range_xml( $entries[ $table_path ], $table_ref, count( $rows ) );

		$replacements = self::workbook_placeholder_values( $context, count( $rows ) );
		foreach ( $entries as $name => $content ) {
			if ( str_ends_with( $name, '.xml' ) ) {
				$entries[ $name ] = strtr( $content, $replacements );
			}
		}

		return self::zip_entries( $entries );
	}

	private static function template_sheet_path( array $entries, string $sheet_name ): string {
		$workbook = $entries['xl/workbook.xml'] ?? '';
		$rels     = $entries['xl/_rels/workbook.xml.rels'] ?? '';
		if ( ! is_string( $workbook ) || ! is_string( $rels ) ) {
			return '';
		}

		if ( ! preg_match( '/<sheet\b[^>]*name="' . preg_quote( $sheet_name, '/' ) . '"[^>]*r:id="([^"]+)"/', $workbook, $match ) ) {
			return '';
		}
		$rid = $match[1];
		if ( ! preg_match( '/<Relationship\b[^>]*Id="' . preg_quote( $rid, '/' ) . '"[^>]*Target="([^"]+)"/', $rels, $match ) ) {
			return '';
		}

		return 'xl/' . ltrim( str_replace( '\\', '/', $match[1] ), '/' );
	}

	private static function template_table_path( array $entries, string $table_name ): string {
		foreach ( $entries as $name => $content ) {
			if ( ! str_starts_with( (string) $name, 'xl/tables/' ) || ! is_string( $content ) ) {
				continue;
			}
			if ( preg_match( '/\b(?:name|displayName)="' . preg_quote( $table_name, '/' ) . '"/i', $content ) ) {
				return (string) $name;
			}
		}

		return '';
	}

	private static function table_ref( string $table_xml ): array {
		if ( ! preg_match( '/\bref="([A-Z]+)(\d+):([A-Z]+)(\d+)"/', $table_xml, $match ) ) {
			return [];
		}

		return [
			'start_col' => self::column_index( $match[1] ),
			'start_row' => (int) $match[2],
			'end_col'   => self::column_index( $match[3] ),
			'end_row'   => (int) $match[4],
		];
	}

	private static function template_task_rows( array $tasks ): array {
		$rows = [];
		$phase_counts = [];
		$base = strtotime( gmdate( 'Y-m-d' ) );
		foreach ( $tasks as $task ) {
			$phase = preg_replace( '/[^0-9]/', '', (string) ( $task['phase'] ?? '' ) );
			$phase = $phase !== '' ? $phase : '30';
			$phase_label = $phase . ' Day';
			$phase_counts[ $phase ] = ( $phase_counts[ $phase ] ?? 0 ) + 1;
			$effort = max( 1, min( 20, (int) ( $task['effort'] ?? self::default_effort_for_priority( (string) ( $task['priority'] ?? '' ) ) ) ) );
			$due_day = max( 1, (int) ( $task['due_day'] ?? $effort ) );
			$start_day = max( 1, $due_day - $effort + 1 );
			$start = $base + ( ( $start_day - 1 ) * self::DAY_SECONDS );
			$end = $base + ( ( $due_day - 1 ) * self::DAY_SECONDS );

			$rows[] = [
				'PHASE'       => $phase_label,
				'ID'          => self::phase_number( $phase ) . '.' . $phase_counts[ $phase ],
				'TASK'        => (string) ( $task['task'] ?? '' ),
				'RESOURCE'    => (string) ( $task['owner'] ?? 'Customer' ),
				'START DATE'  => self::excel_date_serial( $start ),
				'EFFORT'      => $effort,
				'END DATE'    => self::excel_date_serial( $end ),
				'STATUS'      => 'Not Started',
				'%'           => 0,
				'DESCRIPTION' => trim( (string) ( $task['details'] ?? '' ) . "\n" . (string) ( $task['success_criteria'] ?? '' ) ),
			];
		}

		return $rows;
	}

	private static function default_effort_for_priority( string $priority ): int {
		return match ( strtolower( trim( $priority ) ) ) {
			'high' => 5,
			'medium' => 3,
			default => 2,
		};
	}

	private static function phase_number( string $phase ): int {
		return match ( $phase ) {
			'30' => 1,
			'60' => 2,
			'90' => 3,
			default => 1,
		};
	}

	private static function excel_date_serial( int $timestamp ): int {
		return (int) floor( $timestamp / self::DAY_SECONDS ) + 25569;
	}

	private static function tasklist_sheet_xml( string $original_xml, array $table_ref, array $rows ): string {
		$headers = [ 'PHASE', 'ID', 'TASK', 'RESOURCE', 'START DATE', 'EFFORT', 'END DATE', 'STATUS', '%', 'DESCRIPTION' ];
		$header_row = (int) $table_ref['start_row'];
		$last_row = $header_row + count( $rows );
		$table_parts = '';
		if ( preg_match( '/<tableParts\b.*<\/tableParts>/sU', $original_xml, $match ) ) {
			$table_parts = $match[0];
		}

		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
		$xml .= '<dimension ref="A1:J' . $last_row . '"/><sheetData>';
		$xml .= self::worksheet_row_xml( $header_row, $headers, [] );
		foreach ( $rows as $index => $row ) {
			$row_values = [];
			foreach ( $headers as $header ) {
				$row_values[] = $row[ $header ] ?? '';
			}
			$xml .= self::worksheet_row_xml( $header_row + $index + 1, $row_values, [ 5, 7, 6, 9 ] );
		}
		$xml .= '</sheetData>';
		if ( $table_parts !== '' ) {
			$xml .= $table_parts;
		}
		return $xml . '</worksheet>';
	}

	private static function worksheet_row_xml( int $row_number, array $values, array $numeric_columns ): string {
		$xml = '<row r="' . $row_number . '">';
		foreach ( array_values( $values ) as $index => $value ) {
			$column = $index + 1;
			$cell = self::column_name( $column ) . $row_number;
			if ( in_array( $column, $numeric_columns, true ) ) {
				$xml .= '<c r="' . $cell . '"><v>' . self::xml( (string) $value ) . '</v></c>';
			} else {
				$xml .= '<c r="' . $cell . '" t="inlineStr"><is><t>' . self::xml( (string) $value ) . '</t></is></c>';
			}
		}
		return $xml . '</row>';
	}

	private static function update_table_range_xml( string $table_xml, array $table_ref, int $row_count ): string {
		$start_col = self::column_name( (int) $table_ref['start_col'] );
		$end_col   = self::column_name( (int) $table_ref['end_col'] );
		$start_row = (int) $table_ref['start_row'];
		$end_row   = $start_row + $row_count;
		$ref       = $start_col . $start_row . ':' . $end_col . $end_row;
		$table_xml = preg_replace( '/\bref="[A-Z]+\d+:[A-Z]+\d+"/', 'ref="' . $ref . '"', $table_xml ) ?? $table_xml;
		return preg_replace( '/<autoFilter\b[^>]*ref="[A-Z]+\d+:[A-Z]+\d+"[^>]*\/>/', '<autoFilter ref="' . $ref . '"/>', $table_xml ) ?? $table_xml;
	}

	private static function workbook_placeholder_values( array $context, int $task_count ): array {
		$instructions = "Project owner instructions:\n"
			. "1. Review the Tasklist sheet first and assign realistic owners where the default resource is not right for your organisation.\n"
			. "2. Use the Planner sheet to track phases, dates, effort and progress. The Gantt chart is driven from the TASKS table.\n"
			. "3. Prioritise 30-day High priority tasks before moving into 60 and 90-day actions.\n"
			. "4. Update Status and % as work progresses, and keep evidence notes with the responsible owner.\n"
			. '5. Review the plan weekly until all critical and high priority tasks are complete.';

		$values = [
			'{{questionnaire.name}}' => (string) ( $context['assessment']['name'] ?? '' ),
			'{{questionnaire.ref}}'  => (string) ( $context['assessment']['ref'] ?? '' ),
			'{{customer.name}}'      => (string) ( $context['customer']['name'] ?? '' ),
			'{{customer.company}}'   => (string) ( $context['customer']['company'] ?? '' ),
			'{{customer.email}}'     => (string) ( $context['customer']['email'] ?? '' ),
			'{{score.overall}}'      => (string) ( $context['assessment']['overall_score'] ?? '' ),
			'{{grade.label}}'        => (string) ( $context['assessment']['grade_label'] ?? '' ),
			'{{task.count}}'         => (string) $task_count,
			'{{generated_at}}'       => gmdate( 'Y-m-d H:i:s' ),
			'{{project_owner.instructions}}' => $instructions,
			'{{plan.instructions}}'  => $instructions,
		];

		return array_map( static fn( string $value ): string => self::xml( $value ), $values );
	}

	private static function zip_entries( array $entries ): string {
		$tmp = tempnam( sys_get_temp_dir(), 'wpq-template-' );
		if ( ! is_string( $tmp ) || $tmp === '' ) {
			throw new RuntimeException( 'Could not create workbook.' );
		}

		$zip = new ZipArchive();
		if ( $zip->open( $tmp, ZipArchive::OVERWRITE ) !== true ) {
			throw new RuntimeException( 'Could not create workbook archive.' );
		}
		foreach ( $entries as $name => $content ) {
			$zip->addFromString( (string) $name, (string) $content );
		}
		$zip->close();

		$binary = file_get_contents( $tmp );
		@unlink( $tmp );
		if ( ! is_string( $binary ) ) {
			throw new RuntimeException( 'Could not read workbook.' );
		}

		return $binary;
	}

	private static function worksheet_xml( array $rows ): string {
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
		foreach ( array_values( $rows ) as $r => $row ) {
			$row_num = $r + 1;
			$xml .= '<row r="' . $row_num . '">';
			foreach ( array_values( $row ) as $c => $value ) {
				$cell = self::cell_name( $c, $row_num );
				$xml .= '<c r="' . $cell . '" t="inlineStr"><is><t>' . self::xml( (string) $value ) . '</t></is></c>';
			}
			$xml .= '</row>';
		}
		return $xml . '</sheetData></worksheet>';
	}

	private static function cell_name( int $column, int $row ): string {
		$name = '';
		$column++;
		while ( $column > 0 ) {
			$mod  = ( $column - 1 ) % 26;
			$name = chr( 65 + $mod ) . $name;
			$column = (int) floor( ( $column - $mod ) / 26 );
		}
		return $name . $row;
	}

	private static function column_name( int $column ): string {
		$name = '';
		while ( $column > 0 ) {
			$mod  = ( $column - 1 ) % 26;
			$name = chr( 65 + $mod ) . $name;
			$column = (int) floor( ( $column - $mod ) / 26 );
		}

		return $name !== '' ? $name : 'A';
	}

	private static function column_index( string $column ): int {
		$column = strtoupper( $column );
		$index  = 0;
		for ( $i = 0, $length = strlen( $column ); $i < $length; $i++ ) {
			$index = ( $index * 26 ) + ( ord( $column[ $i ] ) - 64 );
		}

		return max( 1, $index );
	}

	private static function xml( string $value ): string {
		return htmlspecialchars( $value, ENT_XML1 | ENT_COMPAT, 'UTF-8' );
	}

	private static function content_types_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';
	}

	private static function root_rels_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>';
	}

	private static function workbook_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Planner" sheetId="1" r:id="rId1"/><sheet name="Tasklist" sheetId="2" r:id="rId2"/></sheets></workbook>';
	}

	private static function workbook_rels_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
	}

	private static function styles_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellXfs></styleSheet>';
	}

	private static function app_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>WP Questionnaires</Application></Properties>';
	}

	private static function core_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>WP Questionnaires</dc:creator><dc:title>Remediation Plan</dc:title><dcterms:created xsi:type="dcterms:W3CDTF">' . self::xml( gmdate( 'c' ) ) . '</dcterms:created></cp:coreProperties>';
	}
}
