<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Shortcode {

	public static function register(): void {
		add_shortcode( 'wpq_questionnaire', [ self::class, 'render' ] );
		add_shortcode( 'wpq_assessment',    [ self::class, 'render' ] );
		add_shortcode( 'wpq_assessments',   [ self::class, 'render' ] );
		add_shortcode( 'wpq_product',       [ self::class, 'render' ] );
		add_shortcode( 'wpq_title',       [ self::class, 'render_title' ] );
		add_shortcode( 'wpq_description', [ self::class, 'render_description' ] );
		add_shortcode( 'wpq_questions',   [ self::class, 'render_questions' ] );
		add_shortcode( 'wpq_domains',     [ self::class, 'render_domains' ] );
		add_shortcode( 'wpq_time',        [ self::class, 'render_minutes' ] );
		add_shortcode( 'wpq_estimate',    [ self::class, 'render_estimate' ] );
		add_shortcode( 'wpq_minutes',     [ self::class, 'render_minutes' ] );
		add_shortcode( 'wpq_submissions', [ self::class, 'render_submissions' ] );
		add_shortcode( 'wpq_status',      [ self::class, 'render_status' ] );
		add_shortcode( 'wpq_enquiry',     [ self::class, 'render_enquiry' ] );
	}

	public static function enqueue_assets(): void {
		wp_enqueue_style(
			'wpq-assessment',
			WPQ_PLUGIN_URL . 'public/assets/assessment.css',
			[],
			WPQ_VERSION
		);
		wp_enqueue_script(
			'wpq-assessment',
			WPQ_PLUGIN_URL . 'public/assets/assessment.js',
			[],
			WPQ_VERSION,
			true
		);
	}

	public static function render( array $atts ): string {
		$atts = shortcode_atts( [
			'ref'          => '',
			'show_pricing' => 'true',
			'layout'       => 'wide',
		], $atts, 'wpq_questionnaire' );

		$ref = strtoupper( sanitize_text_field( $atts['ref'] ) );
		if ( ! $ref ) {
			return '<p class="wpq-error">Questionnaire reference is required. Usage: [wpq_questionnaire ref="CS-01"]</p>';
		}

		$questionnaire = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $questionnaire ) {
			return '<p class="wpq-error">Questionnaire not found.</p>';
		}

		self::enqueue_assets();
		$asset_fallback = self::render_asset_fallback_tags();
		$layout = sanitize_key( (string) $atts['layout'] );
		if ( ! in_array( $layout, [ 'wide', 'contained' ], true ) ) {
			$layout = 'wide';
		}

		$wpq_instance_config = [
			'restUrl'                => esc_url( rest_url( WPQ_REST_NAMESPACE . '/' ) ),
			'ref'                    => esc_js( $ref ),
			'showPricing'            => filter_var( $atts['show_pricing'], FILTER_VALIDATE_BOOLEAN ),
			'remediationPlanEnabled' => class_exists( 'WPQ_Remediation_Plan' )
				&& WPQ_Remediation_Plan::is_configured()
				&& ( ! class_exists( 'WPQ_Feature_Flags' ) || WPQ_Feature_Flags::remediation_plan_download_enabled_for_questionnaire( $questionnaire ) ),
		];

		wp_localize_script( 'wpq-assessment', 'wpqConfig', $wpq_instance_config );

		ob_start();
		include WPQ_PLUGIN_DIR . 'public/views/assessment-shortcode.php';
		return $asset_fallback . ob_get_clean();
	}

	/** [wpq_enquiry ref="EF-XXXXXX"] — renders a composed enquiry form. */
	public static function render_enquiry( array $atts ): string {
		$atts = shortcode_atts( [ 'ref' => '' ], $atts, 'wpq_enquiry' );

		$ref = sanitize_text_field( (string) $atts['ref'] );
		if ( '' === $ref ) {
			return '<p class="wpq-error">Enquiry form reference is required. Usage: [wpq_enquiry ref="EF-XXXXXX"]</p>';
		}

		$form = WPQ_Database::get_enquiry_form_by_ref( $ref );
		if ( ! $form || 'published' !== (string) $form->status ) {
			return '<p class="wpq-error">Enquiry form not found.</p>';
		}

		wp_enqueue_style( 'wpq-assessment', WPQ_PLUGIN_URL . 'public/assets/assessment.css', [], WPQ_VERSION );
		wp_enqueue_script( 'wpq-enquiry', WPQ_PLUGIN_URL . 'public/assets/enquiry.js', [], WPQ_VERSION, true );
		wp_localize_script( 'wpq-enquiry', 'wpqEnquiryConfig', [
			'restUrl' => esc_url( rest_url( WPQ_REST_NAMESPACE . '/' ) ),
			'ref'     => esc_js( (string) $form->ref ),
		] );

		$wpq_enquiry_fields = WPQ_Enquiry::decode_field_definitions( $form->fields_json ?? null );

		ob_start();
		include WPQ_PLUGIN_DIR . 'public/views/enquiry-shortcode.php';
		return (string) ob_get_clean();
	}

	private static function render_asset_fallback_tags(): string {
		if ( function_exists( 'did_action' ) && did_action( 'wp_head' ) < 1 ) {
			return '';
		}
		if ( function_exists( 'wp_style_is' ) && wp_style_is( 'wpq-assessment', 'done' ) ) {
			return '';
		}

		$href = esc_url( WPQ_PLUGIN_URL . 'public/assets/assessment.css?ver=' . rawurlencode( WPQ_VERSION ) );

		return '<style id="wpq-assessment-late-critical">.wpq-hidden{display:none!important}</style>' . "\n"
			// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Fallback for shortcode renders that happen after wp_head.
			. '<link rel="stylesheet" id="wpq-assessment-late-css" href="' . $href . '" media="all" />' . "\n";
	}

	public static function render_title( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_title' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		return $q ? esc_html( $q->name ) : '';
	}

	public static function render_description( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_description' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		return $q ? esc_html( $q->description ) : '';
	}

	public static function render_questions( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_questions' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		return (string) WPQ_Database::count_questions_for_questionnaire( (int) $q->id );
	}

	public static function render_domains( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_domains' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		return (string) count( WPQ_Database::get_domains( (int) $q->id ) );
	}

	public static function render_estimate( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_estimate' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		$count   = WPQ_Database::count_questions_for_questionnaire( (int) $q->id );
		$minutes = (int) ceil( $count * 42 / 60 );
		return $minutes . ' ' . ( $minutes === 1 ? 'minute' : 'minutes' );
	}

	public static function render_minutes( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_minutes' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		$count = WPQ_Database::count_questions_for_questionnaire( (int) $q->id );
		return (string) (int) ceil( $count * 42 / 60 );
	}

	public static function render_submissions( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_submissions' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_by_ref( $ref );
		if ( ! $q ) {
			return '';
		}
		return (string) WPQ_Database::count_submissions_for_questionnaire( (int) $q->id );
	}

	public static function render_status( array $atts ): string {
		$ref = self::resolve_ref( $atts, 'wpq_status' );
		if ( ! $ref ) {
			return '';
		}
		$q = WPQ_Database::get_questionnaire_any_status_by_ref( $ref );
		return $q ? esc_html( (string) $q->status ) : '';
	}

	private static function resolve_ref( array $raw_atts, string $tag ): string {
		$atts = shortcode_atts( [ 'ref' => '' ], $raw_atts, $tag );
		return strtoupper( sanitize_text_field( $atts['ref'] ) );
	}
}
