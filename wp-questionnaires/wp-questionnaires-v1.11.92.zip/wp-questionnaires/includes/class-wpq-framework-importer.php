<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Imports an ATLAS `.skill` bundle (a ZIP of SKILL.md + references/*.md) into
 * the framework registry: one wpq_frameworks row per bundle, and the control
 * catalogue parsed out of the bundle's reference tables into
 * wpq_framework_controls.
 *
 * The same uploaded bundle is later registered with the Anthropic Skills API,
 * so the control catalogue in the database and the skill Claude analyses with
 * always come from one artefact and cannot drift.
 *
 * Parsing is deterministic (no AI): reference files vary in column layout
 * across the 40+ ATLAS skills, so the parser works from structure — a
 * markdown table whose first column looks like a control reference, with the
 * nearest heading supplying the domain — rather than fixed column positions.
 * Cross-standard mapping tables (two ref-like columns) are skipped, as are
 * template/generator/overlay reference files, which describe outputs rather
 * than the standard's own catalogue.
 */
class WPQ_Framework_Importer {

	private const SKILLS_API_URL     = 'https://api.anthropic.com/v1/skills';
	private const SKILLS_BETA_HEADER = 'skills-2025-10-02';
	private const API_VERSION        = '2023-06-01';
	private const REQUEST_TIMEOUT    = 120;

	private const MAX_BUNDLE_BYTES = 5 * 1024 * 1024;
	private const MAX_ENTRY_BYTES  = 2 * 1024 * 1024;

	/** Reference files that never describe the standard's own control catalogue. */
	private const SKIP_FILE_HINTS = [ 'mapping', 'template', 'generator', 'overlay' ];

	/**
	 * Sections that contain ref-shaped rows which are not this standard's
	 * catalogue: crosswalks to other standards, worked examples, glossaries.
	 */
	private const SKIP_DOMAIN_HINTS = [ 'mapping', 'crosswalk', 'comparison', 'example', 'glossary', ' vs ', 'versus', 'maturity', 'register' ];

	private static function is_skippable_domain( string $domain ): bool {
		$lower = ' ' . strtolower( $domain ) . ' ';
		foreach ( self::SKIP_DOMAIN_HINTS as $hint ) {
			if ( str_contains( $lower, $hint ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Control references look like "A.5.1", "GV.OC-01", "AC.L2-3.1.1", "PR.AA-05",
	 * "CC6.1", "Req-3.5.1", "5.1.1", "Article 32". Ordinary prose does not.
	 */
	private const REF_PATTERN = '/^(?:[A-Z][A-Za-z]{0,11}[ .\-]{0,2})*\d[\d.\-]*(?:\([a-z0-9()]+\))?$/';

	/**
	 * "Word N" refs are accepted only for framework vocabulary — "Article 32",
	 * "Clause 6.1", "Regulation 5" — never for document structure ("Step 3",
	 * "Phase 2", "Tier 1"), which is what turns template walkthroughs into
	 * phantom controls.
	 */
	private const REF_WORD_ALLOWLIST = [
		'article', 'art', 'clause', 'requirement', 'req', 'regulation', 'reg',
		'rule', 'annex', 'control', 'principle', 'safeguard', 'objective',
	];

	// ------------------------------------------------------------------ //
	// Bundle reading
	// ------------------------------------------------------------------ //

	/**
	 * Read and validate a .skill ZIP from disk into memory.
	 *
	 * @return array{slug: string, files: array<string, string>} Files keyed by
	 *         path inside the bundle, without the root directory prefix.
	 */
	public static function read_bundle( string $path ): array {
		if ( ! is_readable( $path ) ) {
			throw new RuntimeException( 'Skill bundle is not readable.' );
		}
		$size = filesize( $path );
		if ( ! is_int( $size ) || $size <= 0 || $size > self::MAX_BUNDLE_BYTES ) {
			throw new RuntimeException( 'Skill bundle is empty or too large.' );
		}
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( 'ZipArchive is not available on this server.' );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) {
			throw new RuntimeException( 'Skill bundle is not a valid ZIP archive.' );
		}

		$files = [];
		try {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- ZipArchive's own property name.
			$entry_count = $zip->numFiles;
			for ( $i = 0; $i < $entry_count; $i++ ) {
				$stat = $zip->statIndex( $i );
				if ( ! is_array( $stat ) ) {
					continue;
				}
				$name = (string) $stat['name'];
				// Directory entries, oversized members, and traversal names are skipped.
				if ( str_ends_with( $name, '/' ) || (int) $stat['size'] > self::MAX_ENTRY_BYTES ) {
					continue;
				}
				if ( str_contains( $name, '..' ) || str_starts_with( $name, '/' ) ) {
					continue;
				}
				if ( ! str_ends_with( strtolower( $name ), '.md' ) ) {
					continue;
				}
				$content = $zip->getFromIndex( $i );
				if ( is_string( $content ) ) {
					$files[ $name ] = $content;
				}
			}
		} finally {
			$zip->close();
		}

		if ( empty( $files ) ) {
			throw new RuntimeException( 'Skill bundle contains no markdown files.' );
		}

		// ATLAS bundles wrap everything in one root directory (e.g. "iso27001/");
		// that directory name doubles as a clean, stable slug.
		$slug     = '';
		$stripped = [];
		foreach ( $files as $name => $content ) {
			$parts = explode( '/', $name, 2 );
			if ( count( $parts ) === 2 && '' !== $parts[0] ) {
				if ( '' === $slug ) {
					$slug = strtolower( $parts[0] );
				}
				if ( strtolower( $parts[0] ) === $slug ) {
					$stripped[ $parts[1] ] = $content;
					continue;
				}
			}
			$stripped[ $name ] = $content;
		}

		if ( ! isset( $stripped['SKILL.md'] ) ) {
			throw new RuntimeException( 'Skill bundle is missing SKILL.md.' );
		}

		$slug = sanitize_key( $slug ?: pathinfo( $path, PATHINFO_FILENAME ) );
		if ( '' === $slug ) {
			throw new RuntimeException( 'Could not derive a slug for the skill bundle.' );
		}

		return [ 'slug' => $slug, 'files' => $stripped ];
	}

	// ------------------------------------------------------------------ //
	// Metadata
	// ------------------------------------------------------------------ //

	/**
	 * Framework name/description from SKILL.md: YAML frontmatter first, first
	 * heading as the display-name fallback.
	 *
	 * @return array{name: string, description: string, version: string}
	 */
	public static function parse_metadata( string $skill_md ): array {
		$name        = '';
		$description = '';

		if ( preg_match( '/^---\R(.*?)\R---/s', $skill_md, $matches ) ) {
			$frontmatter = $matches[1];
			if ( preg_match( '/^name:\s*(.+)$/m', $frontmatter, $m ) ) {
				$name = trim( $m[1], " \t\"'" );
			}
			if ( preg_match( '/^description:\s*>?\s*\R((?:[ \t]+.+\R?)+)/m', $frontmatter, $m ) ) {
				$description = trim( preg_replace( '/\s+/', ' ', $m[1] ) ?? '' );
			} elseif ( preg_match( '/^description:\s*(.+)$/m', $frontmatter, $m ) ) {
				$description = trim( $m[1], " \t\"'" );
			}
		}

		// The frontmatter "name" is a machine id (e.g. "iso27001"); the first
		// heading is the human-readable title (e.g. "ISO 27001 Compliance Skill").
		$display = '';
		if ( preg_match( '/^#\s+(.+)$/m', $skill_md, $m ) ) {
			$display = trim( $m[1] );
			$display = preg_replace( '/\s*(?:Compliance\s+|Certification\s+)?Skill$/i', '', $display ) ?? $display;
			$display = rtrim( $display, " \t-\xE2\x80\x93\xE2\x80\x94:" );
		}
		if ( '' !== $display ) {
			$name = $display;
		}

		$version = '';
		if ( preg_match( '/\b(?:ISO(?:\/IEC)?\s*[\d-]+:|version\s+|v)(\d{4}|\d+(?:\.\d+)+)\b/i', $skill_md, $m ) ) {
			$version = $m[1];
		}

		// The first sentence is enough for a registry row; the full trigger text
		// is written for Claude, not for humans.
		if ( '' !== $description ) {
			$sentences = preg_split( '/(?<=[.!?])\s+/', $description, 3 );
			if ( is_array( $sentences ) && count( $sentences ) > 1 ) {
				$description = trim( $sentences[0] . ' ' . ( $sentences[1] ?? '' ) );
			}
		}

		return [
			'name'        => mb_substr( $name, 0, 200 ),
			'description' => mb_substr( $description, 0, 1000 ),
			'version'     => mb_substr( $version, 0, 50 ),
		];
	}

	// ------------------------------------------------------------------ //
	// Control catalogue parsing
	// ------------------------------------------------------------------ //

	/**
	 * Parse the control catalogue out of a bundle's markdown files.
	 *
	 * Tables are scanned in SKILL.md and references alike (some standards — DORA,
	 * NIS2 — carry their catalogue tables in SKILL.md). Heading-form catalogues
	 * ("### Article 32 - Security of processing") are scanned in references only:
	 * SKILL.md headings describe the skill's own workflow, not the standard.
	 *
	 * @param array<string, string> $files Bundle files keyed by relative path.
	 * @return array<int, array{control_ref: string, control_name: string, domain: string, description: string}>
	 */
	public static function parse_controls( array $files ): array {
		$controls = [];
		$seen     = [];

		$add = static function ( array $rows ) use ( &$controls, &$seen ): void {
			foreach ( $rows as $row ) {
				$key = strtolower( $row['control_ref'] );
				if ( isset( $seen[ $key ] ) ) {
					continue; // First occurrence wins across files.
				}
				$seen[ $key ] = true;
				$controls[]   = $row;
			}
		};

		foreach ( $files as $path => $content ) {
			$lower        = strtolower( $path );
			$is_skill_md  = 'skill.md' === $lower;
			$is_reference = str_starts_with( $lower, 'references/' );
			if ( ! $is_skill_md && ! $is_reference ) {
				continue;
			}
			if ( $is_reference ) {
				$basename = basename( $lower );
				foreach ( self::SKIP_FILE_HINTS as $hint ) {
					if ( str_contains( $basename, $hint ) ) {
						continue 2;
					}
				}
			}

			$add( self::parse_control_tables( $content ) );
			if ( $is_reference ) {
				$add( self::parse_control_headings( $content ) );
			}
		}

		return $controls;
	}

	/**
	 * Extract heading-form catalogue entries: a level 2–4 heading whose text is
	 * "REF <dash> Name". The dash separator is load-bearing — template sections
	 * are written "1. Scope" / "Section 2: ...", real catalogue headings
	 * "7.2.1 - Identify and Document Purpose" / "Article 5 - Prohibited Practices".
	 *
	 * @return array<int, array{control_ref: string, control_name: string, domain: string, description: string}>
	 */
	public static function parse_control_headings( string $markdown ): array {
		$rows    = [];
		$domains = []; // Heading level => most recent heading text at that level.

		foreach ( preg_split( '/\R/', $markdown ) ?: [] as $line ) {
			if ( ! preg_match( '/^(#{2,4})\s+(.+)$/', $line, $m ) ) {
				continue;
			}
			$level = strlen( $m[1] );
			$text  = self::clean_cell( $m[2] );

			// A ref-dash-name heading is a catalogue entry; anything else opens a
			// section. HITRUST's zero-padded domain ids ("00 - Information Security
			// Management Program") are the one bare-numeric heading form accepted.
			$is_entry = preg_match( '/^(.{1,40}?)\s+[-\x{2013}\x{2014}]\s+(.+)$/u', $text, $parts )
				&& ( self::looks_like_ref( $parts[1] ) || preg_match( '/^\d{2}$/', trim( $parts[1] ) ) );
			if ( ! $is_entry ) {
				$domains[ $level ] = $text;
				continue;
			}

			// Domain = the nearest still-open heading above this one.
			$domain = '';
			for ( $parent = $level - 1; $parent >= 2; $parent-- ) {
				if ( isset( $domains[ $parent ] ) ) {
					$domain = $domains[ $parent ];
					break;
				}
			}
			if ( self::is_skippable_domain( $domain ) ) {
				continue;
			}

			$rows[] = [
				'control_ref'  => mb_substr( self::clean_cell( $parts[1] ), 0, 50 ),
				'control_name' => mb_substr( self::clean_cell( $parts[2] ), 0, 200 ),
				'domain'       => mb_substr( $domain, 0, 100 ),
				'description'  => self::clean_cell( $parts[2] ),
			];
		}

		return $rows;
	}

	/**
	 * Extract control rows from every markdown table in one document.
	 *
	 * @return array<int, array{control_ref: string, control_name: string, domain: string, description: string}>
	 */
	public static function parse_control_tables( string $markdown ): array {
		$rows    = [];
		$domain  = '';
		$lines   = preg_split( '/\R/', $markdown ) ?: [];
		$total   = count( $lines );

		for ( $i = 0; $i < $total; $i++ ) {
			$line = $lines[ $i ];

			if ( preg_match( '/^#{2,4}\s+(.+)$/', $line, $m ) ) {
				$domain = self::clean_cell( $m[1] );
				// "A.5 Organisational Controls (37 controls)" → drop the count suffix.
				$domain = trim( preg_replace( '/\s*\(\d+\s+controls?\)\s*$/i', '', $domain ) ?? $domain );
				continue;
			}

			// A table starts at a header row followed by a |---| separator row.
			if ( ! self::is_table_row( $line ) || $i + 1 >= $total || ! self::is_separator_row( $lines[ $i + 1 ] ) ) {
				continue;
			}

			$headers = self::split_row( $line );
			$i += 2;

			$table_rows = [];
			for ( ; $i < $total && self::is_table_row( $lines[ $i ] ); $i++ ) {
				$cells = self::split_row( $lines[ $i ] );
				if ( ! empty( $cells ) ) {
					$table_rows[] = $cells;
				}
			}
			$i--; // The for-loop increment will move past the table's last row.

			foreach ( self::table_to_controls( $headers, $table_rows, $domain ) as $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * Convert one parsed table to control rows, or nothing when the table is
	 * not a catalogue.
	 *
	 * The ref column is detected, not assumed: it is the single column where
	 * most values look like control references (DORA's catalogue keys its ref
	 * in column two). Two ref-like columns mean a cross-standard mapping table
	 * — skipped. A "definition" header means a glossary — skipped.
	 *
	 * @param array<int, string>              $headers
	 * @param array<int, array<int, string>>  $rows
	 * @return array<int, array{control_ref: string, control_name: string, domain: string, description: string}>
	 */
	private static function table_to_controls( array $headers, array $rows, string $domain ): array {
		if ( empty( $rows ) || self::is_skippable_domain( $domain ) ) {
			return [];
		}

		foreach ( $headers as $header ) {
			$lower = strtolower( $header );
			// Glossaries and document revision-history tables carry ref-shaped
			// cells ("Art. 3(1)", "1.0") that are not catalogue entries.
			if ( str_contains( $lower, 'definition' ) || str_contains( $lower, 'version' ) ) {
				return [];
			}
		}

		$threshold   = max( 1, (int) ceil( count( $rows ) * 0.6 ) );
		$ref_columns = [];
		$columns     = max( count( $headers ), ...array_map( 'count', $rows ) );
		for ( $col = 0; $col < $columns; $col++ ) {
			$col_ref_like = 0;
			foreach ( $rows as $cells ) {
				if ( self::looks_like_ref( $cells[ $col ] ?? '' ) ) {
					$col_ref_like++;
				}
			}
			if ( $col_ref_like >= $threshold ) {
				$ref_columns[] = $col;
			}
		}

		// A column explicitly headed "ID"/"Control ID" is the catalogue key even
		// when its values fail the shape test — NIST 800-53 family codes ("AC",
		// "SR") carry no digit, so only the header identifies them.
		$header_keyed = false;
		if ( empty( $ref_columns ) ) {
			foreach ( $headers as $col => $header ) {
				if ( ! in_array( strtolower( self::clean_cell( $header ) ), [ 'id', 'control id', 'ref', 'control ref' ], true ) ) {
					continue;
				}
				$code_like = 0;
				foreach ( $rows as $cells ) {
					if ( preg_match( '/^[A-Z]{2,4}$/', self::clean_cell( $cells[ $col ] ?? '' ) ) ) {
						$code_like++;
					}
				}
				if ( $code_like >= $threshold ) {
					$ref_columns  = [ $col ];
					$header_keyed = true;
					break;
				}
			}
		}

		if ( empty( $ref_columns ) ) {
			return [];
		}
		if ( count( $ref_columns ) === 2 ) {
			// Two ref columns usually mean a cross-standard mapping — but when one
			// column's ids contain the other's (CMMC's "AC.L2-3.1.1 | 3.1.1", the
			// practice id embedding its NIST source), the table IS the catalogue,
			// keyed by the containing column.
			[ $a, $b ]  = $ref_columns;
			$containing = 0;
			foreach ( $rows as $cells ) {
				$va = self::clean_cell( $cells[ $a ] ?? '' );
				$vb = self::clean_cell( $cells[ $b ] ?? '' );
				if ( '' !== $va && '' !== $vb && ( str_contains( $va, $vb ) || str_contains( $vb, $va ) ) ) {
					$containing++;
				}
			}
			if ( $containing >= $threshold ) {
				$ref_columns = [ $a ]; // Keep the first (the standard's own id).
			} else {
				return [];
			}
		} elseif ( count( $ref_columns ) > 2 ) {
			return [];
		}
		$ref_col = $ref_columns[0];

		$out = [];
		foreach ( $rows as $cells ) {
			$ref      = self::clean_cell( $cells[ $ref_col ] ?? '' );
			$accepted = $header_keyed
				? (bool) preg_match( '/^[A-Z]{2,4}$/', $ref )
				: self::looks_like_ref( $ref );
			if ( '' === $ref || ! $accepted ) {
				continue;
			}

			// Everything except the ref cell is content, in original column order,
			// each cell labelled with its header so no catalogue detail is lost.
			$data = [];
			foreach ( $cells as $col => $cell ) {
				if ( $col === $ref_col ) {
					continue;
				}
				$clean = self::clean_cell( $cell );
				if ( '' !== $clean ) {
					$data[] = [ 'header' => self::clean_cell( $headers[ $col ] ?? '' ), 'value' => $clean ];
				}
			}
			if ( empty( $data ) ) {
				continue;
			}

			$name = $data[0]['value'];
			if ( count( $data ) === 1 ) {
				// Two-column tables (e.g. NIST CSF "ID | Subcategory"): the single
				// text cell is the control statement — name and description alike.
				$description = $name;
			} else {
				$last        = count( $data ) - 1;
				$description = $data[ $last ]['value'];
				$extras      = [];
				for ( $j = 1; $j < $last; $j++ ) {
					$extras[] = ( '' !== $data[ $j ]['header'] ? $data[ $j ]['header'] . ': ' : '' ) . $data[ $j ]['value'];
				}
				if ( ! empty( $extras ) ) {
					$description = implode( '. ', $extras ) . '. ' . $description;
				}
			}

			$out[] = [
				'control_ref'  => mb_substr( $ref, 0, 50 ),
				'control_name' => mb_substr( $name, 0, 200 ),
				'domain'       => mb_substr( $domain, 0, 100 ),
				'description'  => $description,
			];
		}

		return $out;
	}

	public static function looks_like_ref( string $cell ): bool {
		$cell = self::clean_cell( $cell );
		if ( '' === $cell || mb_strlen( $cell ) > 40 ) {
			return false;
		}
		// Bare integers ("1", "42") are list positions; dates and vulnerability
		// database ids pass the shape test but are never framework refs.
		if ( preg_match( '/^\d+$/', $cell )
			|| preg_match( '/^\d{4}-\d{2}-\d{2}$/', $cell )
			|| preg_match( '/^(?:CWE|CVE)-/i', $cell )
			|| preg_match( '/^Q\d+$/i', $cell ) ) {
			return false;
		}
		// "§164.308(a)(1)" style regulatory refs.
		if ( preg_match( '/^§\s?\d[\d.()a-z]*$/i', $cell ) ) {
			return true;
		}
		if ( ! preg_match( self::REF_PATTERN, $cell ) ) {
			return false;
		}
		// A word-style ref ("Article 32", "Clause 6.1") is only real framework
		// vocabulary, never document structure ("Step 3", "Phase 2", "Tier 1").
		// Compound ids without spaces (GV.OC-01, AC.L2-3.1.1) are not word-style.
		if ( str_contains( $cell, ' ' ) && preg_match( '/^([A-Za-z]+)\.?\s/', $cell, $m ) ) {
			return in_array( strtolower( $m[1] ), self::REF_WORD_ALLOWLIST, true );
		}
		return true;
	}

	private static function is_table_row( string $line ): bool {
		$line = trim( $line );
		return str_starts_with( $line, '|' ) && substr_count( $line, '|' ) >= 2;
	}

	private static function is_separator_row( string $line ): bool {
		return (bool) preg_match( '/^\s*\|[\s:|-]+\|\s*$/', $line );
	}

	/** @return array<int, string> */
	private static function split_row( string $line ): array {
		$line = trim( $line );
		$line = trim( $line, '|' );
		return array_map( 'trim', explode( '|', $line ) );
	}

	/** Strip markdown emphasis and decorative markers (e.g. "⭐NEW") from a cell. */
	public static function clean_cell( string $cell ): string {
		$cell = trim( $cell );
		$cell = str_replace( [ '**', '`' ], '', $cell );
		$cell = preg_replace( '/[\x{2B50}\x{2705}\x{274C}\x{26A0}\x{FE0F}]\s*NEW\b/iu', '', $cell ) ?? $cell;
		$cell = preg_replace( '/[\x{2B50}\x{2705}\x{274C}\x{26A0}\x{FE0F}\x{1F300}-\x{1FAFF}]/u', '', $cell ) ?? $cell;
		return trim( preg_replace( '/\s+/', ' ', $cell ) ?? $cell );
	}

	// ------------------------------------------------------------------ //
	// Supplemental catalogues
	// ------------------------------------------------------------------ //

	/**
	 * Parsed controls when the bundle carries a catalogue, the curated
	 * supplement otherwise — except for 'replace'-mode supplements, where the
	 * curated catalogue is authoritative and wins even over a partial parse
	 * (COBIT's bundle yields a fragmentary objective list; the canonical set
	 * of 40 objectives is fixed and complete).
	 *
	 * @param array<string, string> $files
	 * @return array<int, array{control_ref: string, control_name: string, domain: string, description: string}>
	 */
	public static function extract_controls( string $slug, array $files ): array {
		$supplement = self::supplement_controls( $slug );
		if ( ! empty( $supplement ) && 'replace' === self::supplement_mode( $slug ) ) {
			return $supplement;
		}

		$controls = self::parse_controls( $files );
		if ( ! empty( $controls ) ) {
			return $controls;
		}
		return $supplement;
	}

	/**
	 * @return array<int, array{control_ref: string, control_name: string, domain: string, description: string}>
	 */
	public static function supplement_controls( string $slug ): array {
		$entry    = self::supplement_entry( $slug );
		$controls = $entry['controls'] ?? [];
		return is_array( $controls ) ? $controls : [];
	}

	/** 'fallback' (default) applies only when the bundle parses to nothing; 'replace' always wins. */
	public static function supplement_mode( string $slug ): string {
		$entry = self::supplement_entry( $slug );
		return 'replace' === ( $entry['mode'] ?? '' ) ? 'replace' : 'fallback';
	}

	/** @return array{mode?: string, controls?: array<int, array<string, string>>} */
	private static function supplement_entry( string $slug ): array {
		static $supplements = null;
		if ( null === $supplements ) {
			$file        = __DIR__ . '/data/framework-control-supplements.php';
			$loaded      = is_readable( $file ) ? require $file : [];
			$supplements = is_array( $loaded ) ? $loaded : [];
		}
		$entry = $supplements[ strtolower( $slug ) ] ?? [];
		return is_array( $entry ) ? $entry : [];
	}

	// ------------------------------------------------------------------ //
	// Import orchestration
	// ------------------------------------------------------------------ //

	/**
	 * Import one .skill bundle from disk: parse, store the bundle in protected
	 * storage, and upsert the framework + control catalogue.
	 *
	 * @return array{framework_id: int, slug: string, name: string, control_count: int, checksum: string}
	 */
	public static function import_bundle_file( string $path ): array {
		$bundle   = self::read_bundle( $path );
		$metadata = self::parse_metadata( $bundle['files']['SKILL.md'] );
		$controls = self::extract_controls( $bundle['slug'], $bundle['files'] );

		$binary = file_get_contents( $path );
		if ( ! is_string( $binary ) || '' === $binary ) {
			throw new RuntimeException( 'Could not read the skill bundle.' );
		}
		$checksum = hash( 'sha256', $binary );

		$stored = self::store_bundle( $bundle['slug'], $binary );
		if ( '' === $stored ) {
			throw new RuntimeException( 'Could not store the skill bundle.' );
		}

		$framework_id = WPQ_Database::upsert_framework( [
			'slug'           => $bundle['slug'],
			'name'           => '' !== $metadata['name'] ? $metadata['name'] : $bundle['slug'],
			'version'        => $metadata['version'],
			'description'    => $metadata['description'],
			'skill_checksum' => $checksum,
			'skill_bundle'   => $stored,
		] );
		if ( $framework_id <= 0 ) {
			throw new RuntimeException( 'Could not save the framework record.' );
		}

		WPQ_Database::replace_framework_controls( $framework_id, $controls );

		return [
			'framework_id'  => $framework_id,
			'slug'          => $bundle['slug'],
			'name'          => '' !== $metadata['name'] ? $metadata['name'] : $bundle['slug'],
			'control_count' => count( $controls ),
			'checksum'      => $checksum,
		];
	}

	// ------------------------------------------------------------------ //
	// Bundle storage (same protected-uploads convention as report artefacts)
	// ------------------------------------------------------------------ //

	public static function get_storage_dir( bool $ensure = true ): string {
		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return '';
		}
		$upload = wp_upload_dir();
		if ( ! is_array( $upload ) || ! empty( $upload['error'] ) || empty( $upload['basedir'] ) ) {
			return '';
		}

		$directory = rtrim( (string) $upload['basedir'], DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'wp-questionnaires' . DIRECTORY_SEPARATOR . 'skills';
		if ( ! $ensure ) {
			return $directory;
		}
		if ( ! is_dir( $directory ) && function_exists( 'wp_mkdir_p' ) && ! wp_mkdir_p( $directory ) ) {
			return '';
		}
		if ( ! is_dir( $directory ) ) {
			return '';
		}

		self::write_access_guards( $directory );
		return $directory;
	}

	private static function store_bundle( string $slug, string $binary ): string {
		$directory = self::get_storage_dir();
		if ( '' === $directory ) {
			return '';
		}
		$file_name = sanitize_file_name( $slug . '.skill' );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Plugin-owned bundle in protected uploads.
		if ( file_put_contents( $directory . DIRECTORY_SEPARATOR . $file_name, $binary ) === false ) {
			return '';
		}
		return $file_name;
	}

	public static function resolve_bundle_path( string $stored ): ?string {
		$stored = trim( $stored );
		if ( '' === $stored || strtolower( pathinfo( $stored, PATHINFO_EXTENSION ) ) !== 'skill' ) {
			return null;
		}
		$directory = self::get_storage_dir();
		if ( '' === $directory ) {
			return null;
		}
		$path = $directory . DIRECTORY_SEPARATOR . basename( $stored );
		$real = realpath( $path );
		$root = realpath( $directory );
		if ( ! is_string( $real ) || ! is_string( $root ) || ! str_starts_with( $real, $root . DIRECTORY_SEPARATOR ) ) {
			return null;
		}
		return is_readable( $real ) ? $real : null;
	}

	private static function write_access_guards( string $directory ): void {
		$index = $directory . DIRECTORY_SEPARATOR . 'index.html';
		if ( ! file_exists( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Access guard.
			file_put_contents( $index, '' );
		}
		$htaccess = $directory . DIRECTORY_SEPARATOR . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Access guard.
			file_put_contents( $htaccess, "Require all denied\n" );
		}
	}

	// ------------------------------------------------------------------ //
	// Anthropic Skills API registration
	// ------------------------------------------------------------------ //

	/**
	 * Register (or version) a framework's stored bundle with the Anthropic
	 * Skills API, so it can be attached to readiness-analysis requests.
	 *
	 * Creates a skill on first registration; creates a new version when the
	 * framework already has a skill_id (a re-uploaded bundle re-imports the
	 * catalogue and then re-registers here).
	 *
	 * @return array{skill_id: string, skill_version: string}
	 */
	public static function register_with_anthropic( int $framework_id ): array {
		$framework = WPQ_Database::get_framework( $framework_id );
		if ( ! $framework ) {
			throw new RuntimeException( 'Framework not found.' );
		}
		$bundle_path = self::resolve_bundle_path( (string) ( $framework->skill_bundle ?? '' ) );
		if ( null === $bundle_path ) {
			throw new RuntimeException( 'No stored skill bundle for this framework. Re-import the .skill file first.' );
		}

		if ( ! class_exists( 'WPQ_Remediation_Plan' ) ) {
			throw new RuntimeException( 'Claude configuration is unavailable.' );
		}
		$details = WPQ_Remediation_Plan::get_api_key_details();
		$api_key = (string) ( $details['value'] ?? '' );
		if ( '' === $api_key ) {
			throw new RuntimeException( 'Claude API key missing.' );
		}

		$bundle = self::read_bundle( $bundle_path );

		$existing_skill_id = trim( (string) ( $framework->skill_id ?? '' ) );
		$url               = '' !== $existing_skill_id
			? self::SKILLS_API_URL . '/' . rawurlencode( $existing_skill_id ) . '/versions'
			: self::SKILLS_API_URL;

		$boundary = 'wpqskill' . bin2hex( random_bytes( 12 ) );
		$body     = self::build_multipart_body(
			$boundary,
			(string) $framework->name,
			$bundle['slug'],
			$bundle['files']
		);

		$response = wp_remote_post( $url, [
			'timeout' => self::REQUEST_TIMEOUT,
			'headers' => [
				'content-type'      => 'multipart/form-data; boundary=' . $boundary,
				'x-api-key'         => $api_key,
				'anthropic-version' => self::API_VERSION,
				'anthropic-beta'    => self::SKILLS_BETA_HEADER,
			],
			'body'    => $body,
		] );

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'Skills API request failed: ' . esc_html( $response->get_error_message() ) );
		}

		$code      = (int) wp_remote_retrieve_response_code( $response );
		$body_text = wp_remote_retrieve_body( $response );
		$decoded   = json_decode( $body_text, true );

		if ( $code < 200 || $code >= 300 || ! is_array( $decoded ) ) {
			$message = is_array( $decoded ) ? (string) ( $decoded['error']['message'] ?? '' ) : '';
			throw new RuntimeException(
				'Skills API returned HTTP ' . (int) $code . ( '' !== $message ? ': ' . esc_html( $message ) : '.' )
			);
		}

		// A create returns the skill object; a version create returns the version
		// object (whose "skill_id" points back at the parent).
		$skill_id = (string) ( $decoded['id'] ?? '' );
		if ( '' !== $existing_skill_id ) {
			$skill_id = (string) ( $decoded['skill_id'] ?? $existing_skill_id );
		}
		$skill_version = (string) ( $decoded['latest_version'] ?? $decoded['version'] ?? '' );

		if ( '' === $skill_id ) {
			throw new RuntimeException( 'Skills API response did not include a skill id.' );
		}

		WPQ_Database::update_framework_skill_registration( $framework_id, $skill_id, $skill_version );

		return [ 'skill_id' => $skill_id, 'skill_version' => $skill_version ];
	}

	/**
	 * @param array<string, string> $files
	 */
	public static function build_multipart_body( string $boundary, string $display_title, string $slug, array $files ): string {
		$eol  = "\r\n";
		$body = '';

		$body .= '--' . $boundary . $eol;
		$body .= 'Content-Disposition: form-data; name="display_title"' . $eol . $eol;
		$body .= $display_title . $eol;

		foreach ( $files as $path => $content ) {
			// The Skills API expects each file's path inside the skill directory
			// as its filename, root folder included.
			$body .= '--' . $boundary . $eol;
			$body .= 'Content-Disposition: form-data; name="files[]"; filename="' . $slug . '/' . str_replace( '"', '', $path ) . '"' . $eol;
			$body .= 'Content-Type: text/markdown' . $eol . $eol;
			$body .= $content . $eol;
		}

		$body .= '--' . $boundary . '--' . $eol;
		return $body;
	}
}
