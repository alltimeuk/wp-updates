/* global wpqEnquiryConfig */
/**
 * Enquiry form submitter. Collects the contact block, the composed custom
 * fields (keyed by their data-field-key), the consent flag, and the honeypot,
 * and posts to /wpq/v1/enquiry. Supports multiple forms on one page.
 */
(function () {
  'use strict';

  document.querySelectorAll('.wpq-enquiry-root').forEach(initEnquiryForm);

  function initEnquiryForm(rootEl) {
    const config = (typeof wpqEnquiryConfig !== 'undefined') ? wpqEnquiryConfig : null;
    const form   = rootEl.querySelector('.wpq-enquiry-form');
    if (!config || !form) return;

    const ref      = rootEl.dataset.wpqEnquiryRef || config.ref;
    const statusEl = form.querySelector('.wpq-enquiry-status');
    const doneEl   = rootEl.querySelector('.wpq-enquiry-done');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const fields = {};
      rootEl.querySelectorAll('.wpq-enquiry-field').forEach((fieldEl) => {
        const key  = fieldEl.dataset.fieldKey;
        const type = fieldEl.dataset.fieldType;
        if (!key) return;

        if (type === 'checkbox') {
          const chosen = Array.from(fieldEl.querySelectorAll('input[type="checkbox"]:checked'))
            .map((cb) => cb.value);
          if (chosen.length) fields[key] = chosen;
        } else {
          const input = fieldEl.querySelector('input, select, textarea');
          if (input && input.value.trim() !== '') fields[key] = input.value.trim();
        }
      });

      const payload = {
        ref:             ref,
        contact_name:    (form.contact_name.value || '').trim(),
        contact_email:   (form.contact_email.value || '').trim(),
        contact_company: (form.contact_company.value || '').trim(),
        contact_phone:   (form.contact_phone.value || '').trim(),
        consent:         form.consent.checked,
        website:         form.website ? form.website.value : '',
        fields:          fields,
      };
      const tsField = form.querySelector('[name="cf-turnstile-response"]');
      if (tsField) payload.turnstile_token = tsField.value;

      const button = form.querySelector('button[type="submit"]');
      button.disabled = true;
      setStatus('Sending…');

      try {
        const res  = await fetch(config.restUrl + 'enquiry', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error((data && data.message) || 'Your enquiry could not be sent.');
        }
        form.classList.add('wpq-hidden');
        if (doneEl) {
          const refEl = doneEl.querySelector('.wpq-enquiry-done-ref');
          if (refEl && data.ref) refEl.textContent = ' (reference ' + data.ref + ')';
          doneEl.classList.remove('wpq-hidden');
        }
      } catch (err) {
        setStatus(err.message || 'Your enquiry could not be sent. Please try again.');
        button.disabled = false;
      }
    });

    function setStatus(text) {
      if (statusEl) statusEl.textContent = text;
    }
  }
})();
