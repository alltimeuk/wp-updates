<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

require_once WPQ_PLUGIN_DIR . 'admin/class-wpq-submissions-table.php';

class WPQ_Admin {

	public function __construct() {
		add_action( 'admin_menu',            [ $this, 'register_menus' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'admin_init',            [ $this, 'handle_actions' ] );
		add_action( 'admin_notices',         [ $this, 'admin_notices' ] );
		add_action( 'admin_post_wpq_dismiss_session_expiry_notice', [ $this, 'dismiss_session_expiry_notice' ] );
		add_action( 'admin_post_wpq_export_diagnostics',           [ $this, 'handle_export_diagnostics' ] );
		add_action( 'admin_post_wpq_export_purgeable',              [ $this, 'handle_export_purgeable' ] );
		add_action( 'admin_post_wpq_purge_abandoned',               [ $this, 'handle_purge_abandoned' ] );
		add_action( 'admin_post_wpq_anonymise_old',                 [ $this, 'handle_anonymise_old' ] );
		add_action( 'admin_post_wpq_export_contact',                [ $this, 'handle_export_contact' ] );
		add_action( 'admin_post_wpq_anonymise_contact',             [ $this, 'handle_anonymise_contact' ] );
		add_action( 'admin_post_wpq_delete_contact',                [ $this, 'handle_delete_contact' ] );
		add_action( 'admin_post_wpq_save_cta',                      [ $this, 'handle_save_cta' ] );
		add_action( 'admin_post_wpq_delete_cta',                    [ $this, 'handle_delete_cta' ] );
		add_action( 'admin_post_wpq_verify_claude_project',         [ $this, 'handle_verify_claude_project' ] );
		add_action( 'admin_post_wpq_upload_claude_template',        [ $this, 'handle_upload_claude_template' ] );
		add_action( 'admin_post_wpq_remove_claude_template',        [ $this, 'handle_remove_claude_template' ] );
		add_action( 'admin_post_wpq_generate_remediation_plan',     [ $this, 'handle_generate_remediation_plan' ] );
		add_action( 'admin_post_wpq_download_remediation_plan',     [ $this, 'handle_download_remediation_plan' ] );
		add_action( 'wp_ajax_wpq_toggle_contact_opt_out',           [ $this, 'ajax_toggle_contact_opt_out' ] );
		add_action( 'wp_ajax_wpq_save_questionnaire',   [ $this, 'ajax_save_questionnaire' ] );
		add_action( 'wp_ajax_wpq_create_questionnaire', [ $this, 'ajax_create_questionnaire' ] );
		add_action( 'wp_ajax_wpq_bulk_questionnaire_action', [ $this, 'ajax_bulk_questionnaire_action' ] );
		add_action( 'wp_ajax_wpq_save_question',        [ $this, 'ajax_save_question' ] );
		add_action( 'wp_ajax_wpq_add_question',         [ $this, 'ajax_add_question' ] );
		add_action( 'wp_ajax_wpq_delete_question',      [ $this, 'ajax_delete_question' ] );
		add_action( 'wp_ajax_wpq_reset_questions',      [ $this, 'ajax_reset_questions' ] );
		add_action( 'wp_ajax_wpq_save_grade',           [ $this, 'ajax_save_grade' ] );
		add_action( 'wp_ajax_wpq_save_grades',          [ $this, 'ajax_save_grades' ] );
		add_action( 'wp_ajax_wpq_add_grade',            [ $this, 'ajax_add_grade' ] );
		add_action( 'wp_ajax_wpq_delete_grade',         [ $this, 'ajax_delete_grade' ] );
		add_action( 'wp_ajax_wpq_save_product',         [ $this, 'ajax_save_product' ] );
		add_action( 'wp_ajax_wpq_delete_product',       [ $this, 'ajax_delete_product' ] );
		add_action( 'wp_ajax_wpq_create_coupon',        [ $this, 'ajax_create_coupon' ] );
		add_action( 'wp_ajax_wpq_delete_coupon',        [ $this, 'ajax_delete_coupon' ] );
		add_action( 'wp_ajax_wpq_create_category',      [ $this, 'ajax_create_category' ] );
		add_action( 'wp_ajax_wpq_update_category',      [ $this, 'ajax_update_category' ] );
		add_action( 'wp_ajax_wpq_delete_category',      [ $this, 'ajax_delete_category' ] );
		add_action( 'wp_ajax_wpq_save_question_option', [ $this, 'ajax_save_question_option' ] );
		add_action( 'wp_ajax_wpq_delete_question_option', [ $this, 'ajax_delete_question_option' ] );
		add_action( 'wp_ajax_wpq_add_domain',           [ $this, 'ajax_add_domain' ] );
		add_action( 'wp_ajax_wpq_update_domain',        [ $this, 'ajax_update_domain' ] );
		add_action( 'wp_ajax_wpq_update_domains',       [ $this, 'ajax_update_domains' ] );
		add_action( 'wp_ajax_wpq_delete_domain',        [ $this, 'ajax_delete_domain' ] );
		add_action( 'wp_ajax_wpq_save_domain_weight',   [ $this, 'ajax_save_domain_weight' ] );
		add_action( 'wp_ajax_wpq_save_question_scoring', [ $this, 'ajax_save_question_scoring' ] );
		add_action( 'admin_post_wpq_export',              [ $this, 'handle_export' ] );
		add_action( 'wp_ajax_wpq_import_analyse',         [ $this, 'ajax_import_analyse' ] );
		add_action( 'wp_ajax_wpq_import_apply',           [ $this, 'ajax_import_apply' ] );
	}

	public function register_menus(): void {
		add_menu_page(
			'Questionnaires',
			'Questionnaires',
			'manage_options',
			'wpq-submissions',
			[ $this, 'page_submissions' ],
			'dashicons-clipboard',
			30
		);

		add_submenu_page(
			'wpq-submissions',
			'Submissions',
			'Submissions',
			'manage_options',
			'wpq-submissions',
			[ $this, 'page_submissions' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Contacts',
			'Contacts',
			'manage_options',
			'wpq-contacts',
			[ $this, 'page_contacts' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Orders',
			'Orders',
			'manage_options',
			'wpq-orders',
			[ $this, 'page_orders' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Questionnaires',
			'Questionnaires',
			'manage_options',
			'wpq-library',
			[ $this, 'page_library' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Pricing',
			'Pricing',
			'manage_options',
			'wpq-products',
			[ $this, 'page_products' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Coupons & Promo Codes',
			'Coupons',
			'manage_options',
			'wpq-coupons',
			[ $this, 'page_coupons' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Call to Action',
			'Call to Action',
			'manage_options',
			'wpq-ctas',
			[ $this, 'page_ctas' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Readiness',
			'Readiness',
			'manage_options',
			'wpq-readiness',
			[ $this, 'page_readiness' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Settings',
			'Settings',
			'manage_options',
			'wpq-settings',
			[ $this, 'page_settings' ]
		);

		add_submenu_page(
			'wpq-submissions',
			'Import / Export',
			'Import / Export',
			'manage_options',
			'wpq-import-export',
			[ $this, 'page_import_export' ]
		);
	}

	public function enqueue_assets( string $hook ): void {
		if ( strpos( $hook, 'wpq-' ) === false ) return;

		wp_enqueue_style(
			'wpq-admin',
			WPQ_PLUGIN_URL . 'admin/assets/admin.css',
			[],
			WPQ_VERSION
		);

		wp_enqueue_script(
			'wpq-admin',
			WPQ_PLUGIN_URL . 'admin/assets/admin.js',
			[ 'jquery' ],
			WPQ_VERSION,
			true
		);

		wp_localize_script( 'wpq-admin', 'wpqAdmin', [
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'adminPostUrl' => admin_url( 'admin-post.php' ),
			'nonce'        => wp_create_nonce( 'wpq_admin' ),
		] );
	}

	public function admin_notices(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$diagnostics = WPQ_Activator::get_migration_diagnostics();
		if ( ! empty( $diagnostics['last_migration_error'] ) ) {
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html( 'WP Questionnaires schema migration reported an error. Open Questionnaires -> Settings -> Diagnostics for details.' )
			);
		}

		$expired = (int) get_option( 'wpq_expired_in_progress_sessions_notice', 0 );
		if ( $expired <= 0 ) {
			return;
		}

		$dismiss_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=wpq_dismiss_session_expiry_notice' ),
			'wpq_dismiss_session_expiry_notice'
		);

		printf(
			'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
			esc_html( sprintf(
				'WP Questionnaires expired %d in-progress assessment session(s) during the session-token security migration. Affected users will need to restart their assessment.',
				$expired
			) ),
			esc_url( $dismiss_url ),
			esc_html( 'Dismiss notice' )
		);
	}

	public function dismiss_session_expiry_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'wpq_dismiss_session_expiry_notice' );
		delete_option( 'wpq_expired_in_progress_sessions_notice' );
		wp_safe_redirect( wp_get_referer() ?: admin_url() );
		exit;
	}

	private function get_input( array $source, string $key, $default = '' ) {
		return isset( $source[ $key ] ) ? wp_unslash( $source[ $key ] ) : $default;
	}

	public function get_checkout_readiness( array $products ): array {
		$active_products = array_filter( $products, static fn( $product ) => ( $product->status ?? '' ) === 'active' );
		$priced_products = array_filter(
			$active_products,
			static fn( $product ) => ! empty( $product->stripe_price_id )
		);
		$publishable_key = WPQ_Secrets::get_stripe_publishable_key_details();
		$secret_key = WPQ_Secrets::get_stripe_secret_key_details();
		$webhook_secret = WPQ_Secrets::get_stripe_webhook_secret_details();
		$capabilities = WPQ_REST_API::checkout_capabilities();
		$checkout_route_registered = ! empty( $capabilities['checkout'] );
		$webhook_route_registered = ! empty( $capabilities['webhook'] );
		$report_delivery_route_registered = ! empty( $capabilities['report_delivery'] );
		$report_template_available = ! empty( $capabilities['report_template'] );
		$report_renderer_available = ! empty( $capabilities['report_renderer'] );
		$report_storage_delivery_configured = ! empty( $capabilities['report_storage_delivery'] );
		$stripe_api_initialised = ! empty( $capabilities['stripe_api_initialised'] );
		$stripe_library_available = class_exists( '\Stripe\StripeClient' );
		$dompdf_library_available = class_exists( '\Dompdf\Dompdf' );
		$report_storage = class_exists( 'WPQ_Report_Renderer' ) ? WPQ_Report_Renderer::storage_diagnostics() : [];
		$atomic_report_token_support = method_exists( 'WPQ_Database', 'consume_report_token' );
		$config_ready = $publishable_key['valid']
			&& $secret_key['valid']
			&& $webhook_secret['valid']
			&& count( $priced_products ) > 0
			&& $stripe_library_available
			&& $dompdf_library_available;
		$implementation_ready = $checkout_route_registered
			&& $webhook_route_registered
			&& $report_delivery_route_registered
			&& $report_template_available
			&& $report_renderer_available
			&& $report_storage_delivery_configured
			&& $stripe_api_initialised;
		$checkout_enabled = class_exists( 'WPQ_Feature_Flags' )
			? WPQ_Feature_Flags::checkout_enabled()
			: ( defined( 'WPQ_CHECKOUT_ENABLED' ) && WPQ_CHECKOUT_ENABLED );
		$production_ready = $checkout_enabled
			&& $config_ready
			&& $implementation_ready;

		$readiness_status = 'configuration_missing';
		if ( $production_ready ) {
			$readiness_status = 'production_ready';
		} elseif ( ! $checkout_enabled ) {
			$readiness_status = 'feature_disabled';
		} elseif ( ! $implementation_ready ) {
			$readiness_status = 'implementation_incomplete';
		}

		return [
			'checkout_enabled'                => $checkout_enabled,
			'checkout_flag_source'            => class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::checkout_source() : 'constant',
			'checkout_flag_option'            => class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::checkout_option_state() : 'disabled',
			'checkout_constant_controlled'    => class_exists( 'WPQ_Feature_Flags' ) && WPQ_Feature_Flags::checkout_constant_controls(),
			'publishable_key_present'         => $publishable_key['present'],
			'publishable_key_valid'           => $publishable_key['valid'],
			'publishable_key_source'          => $publishable_key['source'],
			'secret_key_present'              => $secret_key['present'],
			'secret_key_valid'                => $secret_key['valid'],
			'secret_key_source'               => $secret_key['source'],
			'webhook_secret_present'          => $webhook_secret['present'],
			'webhook_secret_valid'            => $webhook_secret['valid'],
			'webhook_secret_source'           => $webhook_secret['source'],
			'active_product_count'            => count( $active_products ),
			'priced_product_count'            => count( $priced_products ),
			'checkout_route_registered'       => $checkout_route_registered,
			'webhook_route_registered'        => $webhook_route_registered,
			'report_delivery_route_registered'=> $report_delivery_route_registered,
			'checkout_route_status'           => $checkout_route_registered ? 'implemented' : 'phase_3_not_implemented',
			'webhook_route_status'            => $webhook_route_registered ? 'implemented' : 'phase_3_not_implemented',
			'report_delivery_route_status'    => $report_delivery_route_registered ? 'implemented' : 'phase_3_not_implemented',
			'report_template_available'       => $report_template_available,
			'report_renderer_available'       => $report_renderer_available,
			'report_storage_delivery_configured'=> $report_storage_delivery_configured,
			'report_storage_path'             => (string) ( $report_storage['path'] ?? '' ),
			'report_storage_path_available'   => (bool) ( $report_storage['available'] ?? false ),
			'report_storage_writable'         => (bool) ( $report_storage['writable'] ?? false ),
			'report_storage_creatable'        => (bool) ( $report_storage['creatable'] ?? false ),
			'report_storage_index_guard_present' => (bool) ( $report_storage['index_guard_present'] ?? false ),
			'report_storage_htaccess_guard_present' => (bool) ( $report_storage['htaccess_guard_present'] ?? false ),
			'atomic_report_token_support'     => $atomic_report_token_support,
			'stripe_api_initialised'          => $stripe_api_initialised,
			'stripe_library_available'        => $stripe_library_available,
			'dompdf_library_available'        => $dompdf_library_available,
			'readiness_status'                => $readiness_status,
			'production_ready'                => $production_ready,
		];
	}

	public function delete_submissions( array $ids ): array {
		$deleted = 0;
		$failed  = 0;

		foreach ( array_filter( array_map( 'intval', $ids ) ) as $id ) {
			if ( WPQ_Database::delete_submission( $id ) ) {
				$deleted++;
			} else {
				$failed++;
			}
		}

		return [
			'deleted' => $deleted,
			'failed'  => $failed,
		];
	}

	// ------------------------------------------------------------------ //
	// Admin action handler
	// ------------------------------------------------------------------ //

	public function handle_actions(): void {
		$page = sanitize_text_field( $this->get_input( $_GET, 'page' ) );
		if ( ! $page || strpos( $page, 'wpq-' ) === false ) return;
		if ( ! current_user_can( 'manage_options' ) ) return;

		$action = sanitize_text_field( $this->get_input( $_REQUEST, 'wpq_action' ) );

		// Single-row delete.
		if ( $action === 'delete_submission' && isset( $_REQUEST['id'] ) ) {
			check_admin_referer( 'wpq_delete_submission' );
			$result = $this->delete_submissions( [ (int) $this->get_input( $_REQUEST, 'id', 0 ) ] );
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-submissions&deleted=' . $result['deleted'] . '&failed=' . $result['failed'] ) );
			exit;
		}

		// Bulk delete — WP_List_Table submits action or action2 with bulk-submissions nonce.
		$bulk = sanitize_text_field( $this->get_input( $_REQUEST, 'action' ) );
		if ( $bulk === '-1' ) {
			$bulk = sanitize_text_field( $this->get_input( $_REQUEST, 'action2' ) );
		}
		if ( $bulk === 'delete' && ! empty( $_REQUEST['submission'] ) ) {
			check_admin_referer( 'bulk-submissions' );
			$ids = array_filter( array_map( 'intval', (array) $this->get_input( $_REQUEST, 'submission', [] ) ) );
			$result = $this->delete_submissions( $ids );
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-submissions&deleted=' . $result['deleted'] . '&failed=' . $result['failed'] ) );
			exit;
		}
	}

	// ------------------------------------------------------------------ //
	// Pages
	// ------------------------------------------------------------------ //

	public function page_submissions(): void {
		$action = sanitize_text_field( $this->get_input( $_GET, 'wpq_action' ) );

		if ( $action === 'view' && isset( $_GET['id'] ) ) {
			$submission = WPQ_Database::get_submission( (int) $this->get_input( $_GET, 'id', 0 ) );
			if ( $submission ) {
				include WPQ_PLUGIN_DIR . 'admin/views/page-submission-detail.php';
				return;
			}
		}

		$table = new WPQ_Submissions_Table();
		$table->prepare_items();
		include WPQ_PLUGIN_DIR . 'admin/views/page-submissions.php';
	}

	public function page_library(): void {
		$action = sanitize_text_field( $this->get_input( $_GET, 'wpq_action' ) );

		if ( $action === 'edit' && isset( $_GET['id'] ) ) {
			$q_id          = (int) $this->get_input( $_GET, 'id', 0 );
			$questionnaire = WPQ_Database::get_questionnaire( $q_id );
			$domains       = WPQ_Database::get_domains( $q_id );
			$thresholds    = WPQ_Database::get_grade_thresholds( $q_id );
			$q_products    = WPQ_Database::get_all_products_for_questionnaire( $q_id );
			include WPQ_PLUGIN_DIR . 'admin/views/page-questionnaire-edit.php';
			return;
		}

		$questionnaires = WPQ_Database::get_questionnaire_list();
		$categories     = WPQ_Database::get_categories();
		include WPQ_PLUGIN_DIR . 'admin/views/page-questionnaires.php';
	}

	public function page_products(): void {
		$products = WPQ_Database::get_all_products();
		$checkout_readiness = $this->get_checkout_readiness( $products );
		include WPQ_PLUGIN_DIR . 'admin/views/page-products.php';
	}

	public function page_coupons(): void {
		$coupons        = WPQ_Database::get_all_coupons();
		$questionnaires = WPQ_Database::get_questionnaire_list();
		$products       = WPQ_Database::get_all_products();
		include WPQ_PLUGIN_DIR . 'admin/views/page-coupons.php';
	}

	public function page_ctas(): void {
		$categories = WPQ_Database::get_categories();
		$ctas       = WPQ_Database::get_ctas();
		$edit_id    = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$edit_cta   = $edit_id > 0 ? WPQ_Database::get_cta( $edit_id ) : null;
		$domains_by_category = [];

		foreach ( $categories as $category ) {
			$domains_by_category[ (string) $category->slug ] = WPQ_Database::get_unique_domains_for_category( (string) $category->slug );
		}

		include WPQ_PLUGIN_DIR . 'admin/views/page-ctas.php';
	}

	public function handle_save_cta(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}
		check_admin_referer( 'wpq_save_cta' );

		$category_slug = sanitize_key( $this->get_input( $_POST, 'category_slug' ) );
		if ( $category_slug === '' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-ctas&error=missing_category' ) );
			exit;
		}

		$id = WPQ_Database::upsert_cta( [
			'id'            => (int) $this->get_input( $_POST, 'id', 0 ),
			'category_slug' => $category_slug,
			'domain_slug'   => sanitize_key( $this->get_input( $_POST, 'domain_slug' ) ),
			'body_html'     => $this->get_input( $_POST, 'body_html' ),
			'status'        => sanitize_key( $this->get_input( $_POST, 'status', 'active' ) ),
		] );

		$args = $id > 0 ? [ 'saved' => 1, 'id' => $id ] : [ 'error' => 'save_failed' ];
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=wpq-ctas' ) ) );
		exit;
	}

	public function handle_delete_cta(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}
		check_admin_referer( 'wpq_delete_cta' );

		$id      = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0;
		$deleted = $id > 0 && WPQ_Database::delete_cta( $id );
		wp_safe_redirect( add_query_arg( $deleted ? [ 'deleted' => 1 ] : [ 'error' => 'delete_failed' ], admin_url( 'admin.php?page=wpq-ctas' ) ) );
		exit;
	}

	private function redirect_to_questionnaire_editor( int $questionnaire_id, array $args = [] ): void {
		$url = add_query_arg(
			array_merge(
				[
					'page'       => 'wpq-library',
					'wpq_action' => 'edit',
					'id'         => $questionnaire_id,
				],
				$args
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	private function redirect_to_submission_detail( int $submission_id, array $args = [] ): void {
		$url = add_query_arg(
			array_merge(
				[
					'page'       => 'wpq-submissions',
					'wpq_action' => 'view',
					'id'         => $submission_id,
				],
				$args
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	public function handle_verify_claude_project(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'wpq_verify_claude_project' );
		$id = (int) $this->get_input( $_POST, 'questionnaire_id', 0 );

		$ok = class_exists( 'WPQ_Claude' ) && WPQ_Claude::provision_project_for_questionnaire( $id );
		$this->redirect_to_questionnaire_editor( $id, $ok ? [ 'claude_verified' => 1 ] : [ 'claude_error' => 'verify_failed' ] );
	}

	public function handle_upload_claude_template(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'wpq_upload_claude_template' );
		$id = (int) $this->get_input( $_POST, 'questionnaire_id', 0 );

		if ( $id <= 0 || ! WPQ_Database::get_questionnaire( $id ) ) {
			$this->redirect_to_questionnaire_editor( $id, [ 'claude_error' => 'invalid_questionnaire' ] );
		}

		$file = $_FILES['claude_template'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- File array is validated below before WordPress handles upload.
		if ( ! is_array( $file ) || (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK ) {
			$this->redirect_to_questionnaire_editor( $id, [ 'claude_error' => 'upload_failed' ] );
		}

		$name = sanitize_file_name( (string) ( $file['name'] ?? '' ) );
		if ( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) !== 'docx' ) {
			$this->redirect_to_questionnaire_editor( $id, [ 'claude_error' => 'invalid_template_type' ] );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_id = media_handle_upload( 'claude_template', 0, [ 'post_title' => 'WPQ Claude template ' . $id ] );
		if ( is_wp_error( $attachment_id ) ) {
			$this->redirect_to_questionnaire_editor( $id, [ 'claude_error' => 'upload_failed' ] );
		}

		$path = get_attached_file( (int) $attachment_id );
		if ( ! is_string( $path ) || ! is_readable( $path ) || strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) !== 'docx' ) {
			wp_delete_attachment( (int) $attachment_id, true );
			$this->redirect_to_questionnaire_editor( $id, [ 'claude_error' => 'invalid_template_type' ] );
		}

		$checksum = hash_file( 'sha256', $path );
		if ( ! is_string( $checksum ) || ! WPQ_Database::update_questionnaire_claude_template( $id, (int) $attachment_id, $checksum ) ) {
			wp_delete_attachment( (int) $attachment_id, true );
			$this->redirect_to_questionnaire_editor( $id, [ 'claude_error' => 'template_save_failed' ] );
		}

		$this->redirect_to_questionnaire_editor( $id, [ 'claude_template_uploaded' => 1 ] );
	}

	public function handle_remove_claude_template(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'wpq_remove_claude_template' );
		$id = (int) $this->get_input( $_POST, 'questionnaire_id', 0 );

		$questionnaire = WPQ_Database::get_questionnaire( $id );
		if ( ! $questionnaire ) {
			$this->redirect_to_questionnaire_editor( $id, [ 'claude_error' => 'invalid_questionnaire' ] );
		}

		$attachment_id = (int) ( $questionnaire->claude_template_attachment_id ?? 0 );
		$cleared       = WPQ_Database::clear_questionnaire_claude_template( $id );
		if ( $cleared && $attachment_id > 0 ) {
			wp_delete_attachment( $attachment_id, true );
		}

		$this->redirect_to_questionnaire_editor( $id, $cleared ? [ 'claude_template_removed' => 1 ] : [ 'claude_error' => 'template_remove_failed' ] );
	}

	public function handle_generate_remediation_plan(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'wpq_generate_remediation_plan' );

		$submission_id = (int) $this->get_input( $_REQUEST, 'submission_id', 0 );
		$days          = (int) $this->get_input( $_REQUEST, 'days', 90 );
		if ( ! in_array( $days, [ 30, 60, 90 ], true ) ) {
			$days = 90;
		}

		if ( $submission_id <= 0 ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-submissions&claude_error=invalid_submission' ) );
			exit;
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission ) {
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'submission_not_found' ] );
		}

		if ( empty( $submission->completed_at ) ) {
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'incomplete_submission' ] );
		}

		if ( ! class_exists( 'WPQ_Remediation_Plan' ) || ! WPQ_Remediation_Plan::is_configured() ) {
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'remediation_not_configured' ] );
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		if ( ! $questionnaire || ( class_exists( 'WPQ_Feature_Flags' ) && ! WPQ_Feature_Flags::remediation_plan_download_enabled_for_questionnaire( $questionnaire ) ) ) {
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'remediation_disabled' ] );
		}

		if ( class_exists( 'WPQ_Claude' ) && ! WPQ_Claude::initialise_submission_session( $submission_id ) ) {
			error_log( 'WPQ: Admin Claude session initialisation failed for submission ' . $submission_id );
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'session_initialisation_failed' ] );
		}

		WPQ_Database::update_submission_claude_report( $submission_id, [
			'ai_report_status' => 'processing',
			'claude_status'    => 'processing',
		] );

		try {
			$workbook = WPQ_Remediation_Plan::generate_for_submission( $submission, $days );
		} catch ( Throwable $e ) {
			error_log( 'WPQ: Admin Claude remediation generation failed: ' . $e->getMessage() );
			WPQ_Database::update_submission_claude_report( $submission_id, [
				'ai_report_status'  => 'failed',
				'claude_status'     => 'failed',
				'claude_last_error' => 'Could not generate the remediation plan. Enable Claude debug logging for response details.',
			] );
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'generation_failed' ] );
		}

		$filename = sanitize_file_name( (string) ( $workbook['filename'] ?? 'wpq-remediation-plan.xlsx' ) );
		$binary   = (string) ( $workbook['binary'] ?? '' );
		if ( $filename === '' || $binary === '' ) {
			WPQ_Database::update_submission_claude_report( $submission_id, [
				'ai_report_status'  => 'failed',
				'claude_status'     => 'failed',
				'claude_last_error' => 'Claude remediation generation returned an empty workbook.',
			] );
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'empty_workbook' ] );
		}

		$stored = WPQ_Remediation_Plan::store_workbook( $submission_id, $filename, $binary );
		if ( empty( $stored['path'] ) ) {
			WPQ_Database::update_submission_claude_report( $submission_id, [
				'ai_report_status'  => 'failed',
				'claude_status'     => 'failed',
				'claude_last_error' => 'Could not store the generated remediation workbook.',
			] );
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'download_failed' ] );
		}

		WPQ_Database::update_submission_claude_report( $submission_id, [
			'ai_report_status'      => 'completed',
			'claude_status'         => 'completed',
			'claude_last_error'     => null,
			'ai_report_docx_path'   => (string) $stored['path'],
			'ai_report_generated_at' => current_time( 'mysql', true ),
		] );

		$this->stream_remediation_workbook( (string) $stored['path'], $filename );
	}

	public function handle_download_remediation_plan(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'wpq_download_remediation_plan' );

		$submission_id = (int) $this->get_input( $_REQUEST, 'submission_id', 0 );
		if ( $submission_id <= 0 ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-submissions&claude_error=invalid_submission' ) );
			exit;
		}

		$submission = WPQ_Database::get_submission( $submission_id );
		if ( ! $submission || empty( $submission->ai_report_docx_path ) ) {
			$this->redirect_to_submission_detail( $submission_id, [ 'claude_error' => 'download_failed' ] );
		}

		$this->stream_remediation_workbook( (string) $submission->ai_report_docx_path );
	}

	private function stream_remediation_workbook( string $stored_path, string $download_name = '' ): void {
		$path = class_exists( 'WPQ_Remediation_Plan' ) ? WPQ_Remediation_Plan::resolve_workbook_path( $stored_path ) : null;
		if ( ! is_string( $path ) || ! is_readable( $path ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-submissions&claude_error=download_failed' ) );
			exit;
		}

		$filename = sanitize_file_name( $download_name !== '' ? $download_name : basename( $path ) );
		if ( '' === $filename || strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) !== 'xlsx' ) {
			$filename = 'wpq-remediation-plan.xlsx';
		}

		if ( headers_sent() ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-submissions&claude_error=download_failed' ) );
			exit;
		}

		$file_size = filesize( $path );
		if ( ! is_int( $file_size ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wpq-submissions&claude_error=download_failed' ) );
			exit;
		}

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . $file_size );
		header( 'X-Content-Type-Options: nosniff' );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Controlled plugin-generated workbook path after admin validation.
		readfile( $path );
		exit;
	}

	public function page_settings(): void {
		/** @var array<string, string> $stripe_save_feedback Per-field save status shown inline after a successful save. */
		$stripe_save_feedback = [];

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- This reads the nonce before verifying it on the next line.
		$settings_nonce = $this->get_input( $_POST, 'wpq_settings_nonce' );
		if ( $settings_nonce && wp_verify_nonce( $settings_nonce, 'wpq_settings' ) ) {
			$section = sanitize_key( $this->get_input( $_POST, 'wpq_settings_section', 'stripe' ) );

			if ( $section === 'stripe' ) {
				if ( class_exists( 'WPQ_Feature_Flags' ) && ! WPQ_Feature_Flags::checkout_constant_controls() ) {
					$checkout_enabled = WPQ_Feature_Flags::normalise_enabled_state(
						(string) $this->get_input( $_POST, 'wpq_checkout_enabled', WPQ_Feature_Flags::DISABLED ),
						WPQ_Feature_Flags::DISABLED
					);
					update_option( 'wpq_checkout_enabled', $checkout_enabled );
					WPQ_Feature_Flags::clear_cache();
				}

				// Publishable key is not secret — always update.
				$pub = sanitize_text_field( $this->get_input( $_POST, 'stripe_publishable_key' ) );
				update_option( 'wpq_stripe_publishable_key', $pub );
				if ( $pub !== '' ) {
					$stripe_save_feedback['publishable_key'] = preg_match( '/^pk_(?:test|live)_/', $pub )
						? 'Updated — format OK.'
						: 'Updated — format looks unexpected (expected pk_test_… or pk_live_…).';
				} else {
					$stripe_save_feedback['publishable_key'] = 'Saved as empty.';
				}

				// Secret values: only update when a non-empty value is submitted (blank = keep existing).
				$secret = sanitize_text_field( $this->get_input( $_POST, 'stripe_secret_key' ) );
				if ( $secret !== '' ) {
					update_option( 'wpq_stripe_secret_key', $secret );
					$stripe_save_feedback['secret_key'] = preg_match( '/^sk_(?:test|live)_/', $secret )
						? 'Updated — format OK.'
						: 'Updated — format looks unexpected (expected sk_test_… or sk_live_…).';
				} else {
					$stripe_save_feedback['secret_key'] = 'Blank — existing value kept.';
				}

				$webhook = sanitize_text_field( $this->get_input( $_POST, 'stripe_webhook_secret' ) );
				if ( $webhook !== '' ) {
					update_option( 'wpq_stripe_webhook_secret', $webhook );
					$stripe_save_feedback['webhook_secret'] = preg_match( '/^whsec_/', $webhook )
						? 'Updated — format OK.'
						: 'Updated — format looks unexpected (expected whsec_…).';
				} else {
					$stripe_save_feedback['webhook_secret'] = 'Blank — existing value kept.';
				}

				add_settings_error( 'wpq_settings', 'saved', 'Stripe settings saved.', 'success' );
			}

			if ( $section === 'ai' ) {
				if ( class_exists( 'WPQ_Feature_Flags' ) && ! WPQ_Feature_Flags::remediation_constant_controls() ) {
					$remediation_enabled = WPQ_Feature_Flags::normalise_enabled_state(
						(string) $this->get_input( $_POST, 'wpq_remediation_plan_enabled', WPQ_Feature_Flags::ENABLED ),
						WPQ_Feature_Flags::ENABLED
					);
					update_option( 'wpq_remediation_plan_enabled', $remediation_enabled );
					WPQ_Feature_Flags::clear_cache();
				}

				$claude_key = sanitize_text_field( $this->get_input( $_POST, 'claude_api_key' ) );
				if ( $claude_key !== '' ) {
					update_option( 'wpq_claude_api_key', $claude_key );
				}

				$model = sanitize_text_field( $this->get_input( $_POST, 'claude_model', 'auto' ) );
				update_option( 'wpq_claude_model', $model !== '' ? $model : 'auto' );
				update_option(
					'wpq_claude_debug_enabled',
					$this->get_input( $_POST, 'wpq_claude_debug_enabled' ) === 'yes' ? 'yes' : 'no'
				);
				if ( $this->get_input( $_POST, 'wpq_clear_claude_debug_log' ) === 'yes' && class_exists( 'WPQ_Remediation_Plan' ) ) {
					WPQ_Remediation_Plan::clear_debug_log();
				}

				delete_transient( 'wpq_claude_models' );
				add_settings_error( 'wpq_settings', 'saved', 'AI settings saved.', 'success' );
			}

			if ( $section === 'advanced' ) {
				// Data retention: explicit opt-in required; absence of the checkbox clears to 'no'.
				update_option(
					'wpq_delete_data_on_uninstall',
					$this->get_input( $_POST, 'wpq_delete_data_on_uninstall' ) === 'yes' ? 'yes' : 'no'
				);
				// Retention policy — 0 means disabled; positive integer is the age threshold in days.
				$purge_days     = max( 0, (int) $this->get_input( $_POST, 'wpq_purge_abandoned_days', 0 ) );
				$anonymise_days = max( 0, (int) $this->get_input( $_POST, 'wpq_anonymise_completed_days', 0 ) );
				update_option( 'wpq_purge_abandoned_days',      $purge_days );
				update_option( 'wpq_anonymise_completed_days',  $anonymise_days );
				add_settings_error( 'wpq_settings', 'saved', 'Advanced settings saved.', 'success' );
			}
		}
		$products = WPQ_Database::get_all_products();
		$checkout_readiness = $this->get_checkout_readiness( $products );
		$migration_diagnostics = WPQ_Activator::get_migration_diagnostics();

		$purge_days     = (int) get_option( 'wpq_purge_abandoned_days', 0 );
		$anonymise_days = (int) get_option( 'wpq_anonymise_completed_days', 0 );
		$retention_diagnostics = [
			'purge_days'               => $purge_days,
			'anonymise_days'           => $anonymise_days,
			'purgeable_abandoned_count'=> $purge_days > 0 ? WPQ_Database::count_purgeable_abandoned( $purge_days ) : 0,
			'anonymisable_count'       => $anonymise_days > 0 ? WPQ_Database::count_anonymisable_completed( $anonymise_days ) : 0,
		];

		$categories = WPQ_Database::get_categories();

		include WPQ_PLUGIN_DIR . 'admin/views/page-settings.php';
	}

	public function ajax_create_category(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$name  = sanitize_text_field( $this->get_input( $_POST, 'name' ) );
		$slug  = sanitize_key( $this->get_input( $_POST, 'slug' ) );
		$order = max( 0, (int) $this->get_input( $_POST, 'sort_order', 0 ) );

		if ( ! $name || ! $slug ) {
			wp_send_json_error( [ 'message' => 'Name and Slug are required.' ] );
			return;
		}
		if ( WPQ_Database::category_slug_exists( $slug ) ) {
			wp_send_json_error( [ 'message' => 'A category with that slug already exists.' ] );
			return;
		}

		$id = WPQ_Database::insert_category( $slug, $name, $order );
		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Could not save category.' ] );
			return;
		}
		wp_send_json_success( [ 'id' => $id, 'slug' => $slug, 'name' => $name, 'sort_order' => $order ] );
	}

	public function ajax_update_category(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id    = (int) $this->get_input( $_POST, 'id', 0 );
		$name  = sanitize_text_field( $this->get_input( $_POST, 'name' ) );
		$order = max( 0, (int) $this->get_input( $_POST, 'sort_order', 0 ) );

		if ( ! $id || ! $name ) {
			wp_send_json_error( [ 'message' => 'ID and Name are required.' ] );
			return;
		}

		$ok = WPQ_Database::update_category( $id, $name, $order );
		if ( ! $ok ) {
			wp_send_json_error( [ 'message' => 'Could not update category.' ] );
			return;
		}
		wp_send_json_success( [ 'updated' => true ] );
	}

	public function ajax_delete_category(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );
		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid ID.' ] );
			return;
		}

		$ok = WPQ_Database::delete_category( $id );
		if ( ! $ok ) {
			wp_send_json_error( [ 'message' => 'Could not delete category.' ] );
			return;
		}

		wp_send_json_success( [ 'deleted' => true ] );
	}

	public function page_contacts(): void {
		$action = sanitize_text_field( $this->get_input( $_GET, 'wpq_action' ) );

		if ( $action === 'view' && isset( $_GET['email'] ) ) {
			$email       = sanitize_email( $this->get_input( $_GET, 'email' ) );
			$submissions = WPQ_Database::get_contact_submissions( $email );
			$payments    = WPQ_Database::get_contact_payments( $email );
			$opt_out     = WPQ_Database::get_contact_opt_out( $email );
			include WPQ_PLUGIN_DIR . 'admin/views/page-contact-detail.php';
			return;
		}

		$search   = sanitize_text_field( $this->get_input( $_GET, 's' ) );
		$per_page = 50;
		$page     = max( 1, (int) $this->get_input( $_GET, 'paged', 1 ) );
		$contacts = WPQ_Database::get_contacts( [ 'search' => $search, 'per_page' => $per_page, 'page' => $page ] );
		$total    = WPQ_Database::count_contacts( $search );
		include WPQ_PLUGIN_DIR . 'admin/views/page-contacts.php';
	}

	public function page_orders(): void {
		$search   = sanitize_text_field( $this->get_input( $_GET, 's' ) );
		$per_page = 50;
		$page     = max( 1, (int) $this->get_input( $_GET, 'paged', 1 ) );
		$orders   = WPQ_Database::get_orders( [ 'search' => $search, 'per_page' => $per_page, 'page' => $page ] );
		$total    = WPQ_Database::count_orders( $search );
		include WPQ_PLUGIN_DIR . 'admin/views/page-orders.php';
	}

	public function ajax_toggle_contact_opt_out(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$email     = sanitize_email( $this->get_input( $_POST, 'email' ) );
		$opted_out = (bool) (int) $this->get_input( $_POST, 'opted_out', 0 );
		if ( ! $email ) {
			wp_send_json_error( [ 'message' => 'Invalid email.' ] );
			return;
		}
		$ok = WPQ_Database::set_contact_opt_out( $email, $opted_out, get_current_user_id() );
		if ( ! $ok ) {
			wp_send_json_error( [ 'message' => 'Could not update contact preference.' ] );
			return;
		}

		wp_send_json_success( [ 'opted_out' => $opted_out ] );
	}

	public function handle_export_contact(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );
		check_admin_referer( 'wpq_export_contact' );

		$email = sanitize_email( $this->get_input( $_POST, 'email' ) );
		if ( ! $email ) wp_die( 'Invalid email.' );

		$data     = WPQ_Database::export_contact_data( $email );
		$filename = 'wpq-contact-' . sanitize_title( $email ) . '-' . gmdate( 'Ymd-His' ) . '.json';
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: no-cache, must-revalidate' );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON with Content-Type set.
		echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	public function handle_anonymise_contact(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );
		check_admin_referer( 'wpq_anonymise_contact' );

		$email = sanitize_email( $this->get_input( $_POST, 'email' ) );
		if ( ! $email ) wp_die( 'Invalid email.' );

		$count = WPQ_Database::anonymise_contact( $email );
		wp_safe_redirect( add_query_arg( [
			'page'       => 'wpq-contacts',
			'anonymised' => $count,
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_delete_contact(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );
		check_admin_referer( 'wpq_delete_contact' );

		$email = sanitize_email( $this->get_input( $_POST, 'email' ) );
		if ( ! $email ) wp_die( 'Invalid email.' );

		$count = WPQ_Database::delete_contact( $email );
		wp_safe_redirect( add_query_arg( [
			'page'    => 'wpq-contacts',
			'deleted' => $count,
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_export_purgeable(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}
		check_admin_referer( 'wpq_export_purgeable' );

		$days = max( 1, (int) get_option( 'wpq_purge_abandoned_days', 0 ) );
		$rows = WPQ_Database::get_purgeable_abandoned_summaries( $days );

		$filename = 'wpq-purgeable-abandoned-' . gmdate( 'Ymd-His' ) . '.csv';
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: no-cache, must-revalidate' );

		$out = fopen( 'php://output', 'w' );
		if ( $out !== false ) {
			fputcsv( $out, [ 'id', 'ref', 'questionnaire_ref', 'contact_name', 'contact_email', 'contact_company', 'contact_phone', 'ip_address', 'started_at' ] );
			foreach ( $rows as $row ) {
				fputcsv( $out, [
					$row->id,
					$row->ref,
					$row->questionnaire_ref,
					$row->contact_name,
					$row->contact_email,
					$row->contact_company,
					$row->contact_phone,
					$row->ip_address,
					$row->started_at,
				] );
			}
			fclose( $out );
		}
		exit;
	}

	public function handle_purge_abandoned(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}
		check_admin_referer( 'wpq_purge_abandoned' );

		$days  = (int) get_option( 'wpq_purge_abandoned_days', 0 );
		$count = $days > 0 ? WPQ_Database::purge_abandoned_submissions( $days ) : 0;
		wp_safe_redirect( add_query_arg( [
			'page'           => 'wpq-settings',
			'wpq_tab'        => 'advanced',
			'purged'         => $count,
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_anonymise_old(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}
		check_admin_referer( 'wpq_anonymise_old' );

		$days  = (int) get_option( 'wpq_anonymise_completed_days', 0 );
		$count = $days > 0 ? WPQ_Database::anonymise_old_submissions( $days ) : 0;
		wp_safe_redirect( add_query_arg( [
			'page'        => 'wpq-settings',
			'wpq_tab'     => 'advanced',
			'anonymised'  => $count,
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_export_diagnostics(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}
		check_admin_referer( 'wpq_export_diagnostics' );

		$products  = WPQ_Database::get_all_products();
		$readiness = $this->get_operational_readiness();
		// Strip live key values — export contains metadata only, not secrets.
		unset( $readiness['pub_key'], $readiness['sec_key'], $readiness['whsec'] );
		if ( isset( $readiness['claude_key']['value'] ) ) {
			unset( $readiness['claude_key']['value'] );
		}
		$checkout = $this->get_checkout_readiness( $products );
		// Strip source hints that might reveal key prefixes.
		unset( $checkout['publishable_key_source'], $checkout['secret_key_source'], $checkout['webhook_secret_source'] );

		$export = [
			'exported_at'           => gmdate( 'Y-m-d\TH:i:s\Z' ),
			'plugin_version'        => WPQ_VERSION,
			'db_version_code'       => WPQ_DB_VERSION,
			'db_version_installed'  => (string) get_option( 'wpq_db_version', '0' ),
			'migration_diagnostics' => WPQ_Activator::get_migration_diagnostics(),
			'checkout_readiness'    => $checkout,
			'operational_readiness' => $readiness,
		];

		$filename = 'wpq-diagnostics-' . gmdate( 'Ymd-His' ) . '.json';
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: no-cache, must-revalidate' );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON-encoded, Content-Type set.
		echo wp_json_encode( $export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}

	// ------------------------------------------------------------------ //
	// Import / Export                                                       //
	// ------------------------------------------------------------------ //

	public function page_import_export(): void {
		include WPQ_PLUGIN_DIR . 'admin/views/page-import-export.php';
	}

	public function handle_export(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce verified on next line via check_admin_referer.
		$type = sanitize_key( $this->get_input( $_REQUEST, 'type' ) );
		check_admin_referer( 'wpq_export_' . $type );

		$ids = isset( $_POST['ids'] ) && is_array( $_POST['ids'] )
			? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['ids'] ) )
			: [];

		$export = WPQ_Import_Export::export( $type, $ids );

		$suffix   = ! empty( $ids ) ? '-selected' : '-all';
		$filename = 'wpq-' . $type . $suffix . '-' . gmdate( 'Ymd-His' ) . '.json';
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: no-cache, must-revalidate' );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON-encoded, Content-Type set.
		echo wp_json_encode( $export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	public function ajax_import_analyse(): void {
		check_ajax_referer( 'wpq_import_export', 'nonce' );

		$payload_raw = $this->get_input( $_POST, 'payload' );
		if ( '' === $payload_raw ) {
			$content_len = isset( $_SERVER['CONTENT_LENGTH'] ) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
			if ( $content_len > 0 ) {
				$mb = round( $content_len / 1048576, 1 );
				wp_send_json_error(
					"Payload empty despite Content-Length of {$mb} MB — the POST body was likely dropped by PHP "
					. '(post_max_size=' . ini_get( 'post_max_size' ) . '). '
					. 'Use smaller files (< 7 MB each) or raise post_max_size / nginx client_max_body_size.'
				);
				return;
			}
			wp_send_json_error( 'Payload missing.' );
			return;
		}

		$payload = json_decode( $payload_raw, true );
		if ( ! is_array( $payload ) ) {
			wp_send_json_error( 'Invalid JSON payload — could not decode.' );
			return;
		}

		$result = WPQ_Import_Export::analyse( $payload );
		wp_send_json_success( $result );
	}

	public function ajax_import_apply(): void {
		check_ajax_referer( 'wpq_import_export', 'nonce' );

		$payload_raw     = $this->get_input( $_POST, 'payload' );
		$resolutions_raw = $this->get_input( $_POST, 'resolutions', '{}' );

		if ( '' === $payload_raw ) {
			$content_len = isset( $_SERVER['CONTENT_LENGTH'] ) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
			if ( $content_len > 0 ) {
				$mb = round( $content_len / 1048576, 1 );
				wp_send_json_error(
					"Payload empty despite Content-Length of {$mb} MB — POST body dropped by the server. "
					. 'post_max_size=' . ini_get( 'post_max_size' ) . '. Use smaller files or raise the limit.'
				);
				return;
			}
			wp_send_json_error( 'Payload missing.' );
			return;
		}

		$payload     = json_decode( $payload_raw, true );
		$resolutions = json_decode( $resolutions_raw, true );

		if ( ! is_array( $payload ) ) {
			wp_send_json_error( 'Invalid JSON payload — could not decode.' );
			return;
		}

		$result = WPQ_Import_Export::apply( $payload, is_array( $resolutions ) ? $resolutions : [] );
		wp_send_json_success( $result );
	}

	public function page_readiness(): void {
		$r                  = $this->get_operational_readiness();
		$products           = WPQ_Database::get_all_products();
		$checkout_readiness = $this->get_checkout_readiness( $products );
		include WPQ_PLUGIN_DIR . 'admin/views/page-readiness.php';
	}

	public function get_operational_readiness(): array {
		$installed_db  = (string) get_option( 'wpq_db_version', '0' );
		$schema        = WPQ_Activator::get_migration_diagnostics();
		$migration_log = get_option( 'wpq_migration_log', [] );
		if ( ! is_array( $migration_log ) ) {
			$migration_log = [];
		}

		$pub_key = WPQ_Secrets::get_stripe_publishable_key_details();
		$sec_key = WPQ_Secrets::get_stripe_secret_key_details();
		$whsec   = WPQ_Secrets::get_stripe_webhook_secret_details();
		$claude_key = class_exists( 'WPQ_Remediation_Plan' )
			? WPQ_Remediation_Plan::get_api_key_details()
			: [ 'present' => false, 'valid' => false, 'source' => 'none' ];
		$claude_model = class_exists( 'WPQ_Remediation_Plan' )
			? WPQ_Remediation_Plan::get_model_diagnostics()
			: [ 'preference' => 'auto', 'selected_model' => '', 'available_count' => 0 ];
		$claude_capabilities = class_exists( 'WPQ_Claude_Client' )
			? WPQ_Claude_Client::documented_capabilities()
			: [];

		$storage      = class_exists( 'WPQ_Report_Renderer' ) ? WPQ_Report_Renderer::storage_diagnostics() : [];
		$capabilities = WPQ_REST_API::checkout_capabilities();
		$rate_limit_storage = method_exists( 'WPQ_Database', 'rate_limit_storage_status' )
			? WPQ_Database::rate_limit_storage_status()
			: [ 'table' => '', 'available' => false, 'error' => 'Rate-limit storage helper is missing.' ];

		$halopsa_role    = get_role( 'wpq_halopsa' );
		$halopsa_role_ok = $halopsa_role instanceof WP_Role;
		$halopsa_cap_ok  = $halopsa_role_ok && ! empty( $halopsa_role->capabilities['wpq_halopsa_api'] );
		$halopsa_users   = $halopsa_role_ok ? count( get_users( [ 'role' => 'wpq_halopsa', 'fields' => 'ID', 'number' => 100 ] ) ) : 0;

		$sync_counts = method_exists( 'WPQ_Database', 'get_submission_sync_counts' )
			? WPQ_Database::get_submission_sync_counts()
			: [
				'sync'    => [ 'pending' => 0, 'synced' => 0, 'failed' => 0, 'skipped' => 0 ],
				'payment' => [ 'none' => 0, 'pending' => 0, 'paid' => 0, 'failed' => 0, 'expired' => 0 ],
				'total'   => 0,
			];

		$db_match  = version_compare( $installed_db, WPQ_DB_VERSION, '>=' );
		$tables_ok = ! empty( $schema['table_health'] ) && array_reduce(
			$schema['table_health'],
			static fn( bool $carry, array $t ) => $carry && $t['exists'],
			true
		);
		$errors   = [];
		$warnings = [];

		if ( ! $db_match ) {
			$errors[] = 'DB schema version mismatch — run activation or migration.';
		}
		if ( ! $tables_ok ) {
			$errors[] = 'One or more required database tables are missing.';
		}
		if ( ! empty( $schema['last_migration_error'] ) ) {
			$warnings[] = 'Last migration reported an error: ' . $schema['last_migration_error'];
		}
		if ( ! $halopsa_role_ok || ! $halopsa_cap_ok || $halopsa_users === 0 ) {
			$warnings[] = 'HaloPSA API role is not fully configured.';
		}
		if ( ( $sync_counts['sync']['failed'] ?? 0 ) > 0 ) {
			$warnings[] = sprintf( '%d submission(s) failed HaloPSA sync.', $sync_counts['sync']['failed'] );
		}
		$checkout_enabled = class_exists( 'WPQ_Feature_Flags' )
			? WPQ_Feature_Flags::checkout_enabled()
			: ( defined( 'WPQ_CHECKOUT_ENABLED' ) && WPQ_CHECKOUT_ENABLED );
		if ( $checkout_enabled && ( ! $pub_key['valid'] || ! $sec_key['valid'] || ! $whsec['valid'] ) ) {
			$warnings[] = 'Checkout is enabled but one or more Stripe keys are invalid.';
		}

		return [
			'plugin_version'       => WPQ_VERSION,
			'db_version_code'      => WPQ_DB_VERSION,
			'db_version_installed' => $installed_db,
			'db_version_match'     => $db_match,
			'checkout_enabled'     => $checkout_enabled,
			'checkout_flag_source' => class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::checkout_source() : 'constant',
			'checkout_flag_option' => class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::checkout_option_state() : 'disabled',
			'remediation_plan_global_enabled' => class_exists( 'WPQ_Feature_Flags' ) && WPQ_Feature_Flags::remediation_global_enabled(),
			'remediation_plan_global_source' => class_exists( 'WPQ_Feature_Flags' ) ? WPQ_Feature_Flags::remediation_global_source() : 'constant',
			'schema'               => $schema,
			'migration_log'        => $migration_log,
			'pub_key'              => $pub_key,
			'sec_key'              => $sec_key,
			'whsec'                => $whsec,
			'stripe_library'       => class_exists( '\Stripe\StripeClient' ),
			'dompdf_library'       => class_exists( '\Dompdf\Dompdf' ),
			'stripe_initialised'   => ! empty( $capabilities['stripe_api_initialised'] ),
			'claude_key'           => $claude_key,
			'claude_model'         => $claude_model,
			'claude_capabilities'  => $claude_capabilities,
			'claude_client_initialised' => class_exists( 'WPQ_Claude_Client' ) && WPQ_Claude_Client::can_initialise(),
			'storage'              => $storage,
			'rate_limit_storage'   => $rate_limit_storage,
			'capabilities'         => $capabilities,
			'core_routes'          => [
				'GET /questionnaire/{ref}' => method_exists( 'WPQ_REST_API', 'get_questionnaire' ),
				'POST /lead'              => method_exists( 'WPQ_REST_API', 'submit_lead' ),
				'POST /heartbeat'         => method_exists( 'WPQ_REST_API', 'heartbeat' ),
				'POST /submit'            => method_exists( 'WPQ_REST_API', 'submit_assessment' ),
				'POST /checkout'          => method_exists( 'WPQ_REST_API', 'create_checkout' ),
				'POST /stripe/webhook'    => method_exists( 'WPQ_REST_API', 'stripe_webhook' ),
				'GET /reports/{id}'       => method_exists( 'WPQ_REST_API', 'download_report' ),
			],
			'api_routes'           => [
				'GET /api/submissions'          => method_exists( 'WPQ_HaloPSA_API', 'list_submissions' ),
				'GET /api/submissions/pending'  => method_exists( 'WPQ_HaloPSA_API', 'list_pending' ),
				'GET /api/submissions/{id}'     => method_exists( 'WPQ_HaloPSA_API', 'get_submission' ),
				'POST /api/submissions/{id}/acknowledge' => method_exists( 'WPQ_HaloPSA_API', 'acknowledge' ),
			],
			'halopsa_role_ok'  => $halopsa_role_ok,
			'halopsa_cap_ok'   => $halopsa_cap_ok,
			'halopsa_users'    => $halopsa_users,
			'sync_counts'      => $sync_counts,
			'overall_errors'   => $errors,
			'overall_warnings' => $warnings,
			'overall_status'   => count( $errors ) > 0 ? 'error' : ( count( $warnings ) > 0 ? 'warning' : 'ok' ),
		];
	}

	// ------------------------------------------------------------------ //
	// AJAX handlers
	// ------------------------------------------------------------------ //

	public function ajax_save_questionnaire(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );

		$data = [
			'name'              => sanitize_text_field( $this->get_input( $_POST, 'name' ) ),
			'description'       => sanitize_textarea_field( $this->get_input( $_POST, 'description' ) ),
			'status'            => in_array( $this->get_input( $_POST, 'status' ), [ 'draft', 'preview', 'live', 'retired' ], true )
			                       ? sanitize_text_field( $this->get_input( $_POST, 'status' ) ) : 'draft',
			'stripe_product_id' => sanitize_text_field( $this->get_input( $_POST, 'stripe_product_id' ) ) ?: null,
			'claude_project_id' => substr( sanitize_text_field( $this->get_input( $_POST, 'claude_project_id' ) ), 0, 200 ) ?: null,
			'remediation_plan_enabled' => class_exists( 'WPQ_Feature_Flags' )
				? WPQ_Feature_Flags::normalise_inherit_state( (string) $this->get_input( $_POST, 'remediation_plan_enabled', WPQ_Feature_Flags::INHERIT ) )
				: 'inherit',
		];

		if ( WPQ_Stripe::can_initialise() ) {
			$existing = WPQ_Database::get_questionnaire( $id );
			if ( $existing ) {
				try {
					if ( ! empty( $existing->stripe_product_id ) ) {
						WPQ_Stripe::update_product( $existing->stripe_product_id, [
							'name'        => $data['name'],
							'description' => $data['description'] ?: null,
						] );
						$data['stripe_product_id'] = $existing->stripe_product_id;
					} elseif ( empty( $data['stripe_product_id'] ) && $data['status'] === 'live' ) {
						$stripe_product            = WPQ_Stripe::create_product( $data['name'], $data['description'] );
						$data['stripe_product_id'] = $stripe_product->id;
					}
				} catch ( Throwable $e ) {
					unset( $e ); // Stripe sync is non-fatal; DB save proceeds.
				}
			}
		}

		$ok = WPQ_Database::update_questionnaire( $id, $data );
		if ( $ok === false ) {
			wp_send_json_error( [ 'message' => 'Database error — questionnaire could not be saved.' ] );
			return;
		}
		$claude_warning = '';
		if ( 'live' === $data['status'] && class_exists( 'WPQ_Claude' ) && ! WPQ_Claude::provision_project_for_questionnaire( $id ) ) {
			$claude_warning = 'Claude project status could not be updated.';
		}

		wp_send_json_success( [ 'updated' => $ok, 'warning' => $claude_warning ] );
	}

	public function ajax_create_questionnaire(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$ref      = strtoupper( sanitize_text_field( $this->get_input( $_POST, 'ref' ) ) );
		$name     = sanitize_text_field( $this->get_input( $_POST, 'name' ) );
		$category = sanitize_key( $this->get_input( $_POST, 'category', 'cyber_security' ) );
		$valid_cats = array_column( WPQ_Database::get_categories(), 'slug' );
		if ( empty( $valid_cats ) ) {
			$valid_cats = [ 'cyber_security' ];
		}
		if ( ! in_array( $category, $valid_cats, true ) ) {
			$category = $valid_cats[0];
		}

		if ( ! $ref || ! $name ) {
			wp_send_json_error( [ 'message' => 'Reference and Name are required.' ] );
			return;
		}
		if ( WPQ_Database::get_questionnaire_any_status_by_ref( $ref ) ) {
			wp_send_json_error( [ 'message' => 'A questionnaire with that reference already exists.' ] );
			return;
		}

		$now = current_time( 'mysql', true );
		$new_id = WPQ_Database::insert_questionnaire( [
			'organisation_id' => 1,
			'ref'             => $ref,
			'category'        => $category,
			'name'            => $name,
			'description'     => '',
			'status'          => 'draft',
			'created_at'      => $now,
			'updated_at'      => $now,
		] );

		if ( ! $new_id ) {
			wp_send_json_error( [ 'message' => 'Could not create questionnaire.' ] );
			return;
		}

		if ( ! WPQ_Database::insert_default_grade_thresholds( $new_id ) ) {
			WPQ_Database::delete_questionnaire( $new_id );
			wp_send_json_error( [ 'message' => 'Could not create default grade thresholds.' ] );
			return;
		}

		wp_send_json_success( [ 'id' => $new_id ] );
	}

	public function ajax_bulk_questionnaire_action(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$action  = sanitize_text_field( $this->get_input( $_POST, 'bulk_action' ) );
		$raw_ids = $this->get_input( $_POST, 'ids', [] );
		$ids     = array_filter( array_map( 'intval', is_array( $raw_ids ) ? $raw_ids : [] ) );
		$valid   = [ 'publish', 'archive', 'unarchive', 'remove', 'duplicate' ];

		if ( ! in_array( $action, $valid, true ) || empty( $ids ) ) {
			wp_send_json_error( [ 'message' => 'Invalid action or no items selected.' ] );
			return;
		}

		$results = [ 'ok' => 0, 'skipped' => 0, 'new_ids' => [] ];

		foreach ( $ids as $id ) {
			$q = WPQ_Database::get_questionnaire( $id );
			if ( ! $q ) {
				$results['skipped']++;
				continue;
			}
			if ( $action === 'publish' ) {
				if ( WPQ_Database::update_questionnaire( $id, [ 'status' => 'live' ] ) ) {
					if ( class_exists( 'WPQ_Claude' ) ) {
						WPQ_Claude::provision_project_for_questionnaire( $id );
					}
					$results['ok']++;
				} else {
					$results['skipped']++;
				}
			} elseif ( $action === 'archive' ) {
				if ( WPQ_Database::update_questionnaire( $id, [ 'status' => 'retired' ] ) ) {
					$results['ok']++;
				} else {
					$results['skipped']++;
				}
			} elseif ( $action === 'unarchive' ) {
				if ( $q->status !== 'retired' ) {
					$results['skipped']++;
					continue;
				}
				if ( WPQ_Database::update_questionnaire( $id, [ 'status' => 'draft' ] ) ) {
					$results['ok']++;
				} else {
					$results['skipped']++;
				}
			} elseif ( $action === 'remove' ) {
				if ( $q->status !== 'retired' ) {
					$results['skipped']++;
					continue;
				}
				if ( ! empty( $q->stripe_product_id ) && WPQ_Stripe::can_initialise() ) {
					try {
						WPQ_Stripe::archive_product( $q->stripe_product_id );
					} catch ( Throwable $e ) {
						unset( $e ); // Non-fatal; DB delete proceeds.
					}
				}
				if ( WPQ_Database::delete_questionnaire( $id ) ) {
					$results['ok']++;
				} else {
					$results['skipped']++;
				}
			} elseif ( $action === 'duplicate' ) {
				$new_id = WPQ_Database::duplicate_questionnaire( $id );
				if ( $new_id ) {
					$results['ok']++;
					$results['new_ids'][] = $new_id;
				} else {
					$results['skipped']++;
				}
			}
		}

		wp_send_json_success( $results );
	}

	public function ajax_save_question(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );

		$valid_types        = [ 'tri_state', 'boolean', 'select', 'radio', 'checkbox', 'memo', 'short_text', 'number' ];
		$valid_scoring_modes = [ 'legacy_tri_state', 'boolean', 'reverse_boolean', 'single_option', 'sum_selected', 'max_selected', 'non_scoring' ];

		$q_type       = sanitize_text_field( $this->get_input( $_POST, 'question_type', 'tri_state' ) );
		$scoring_mode = sanitize_text_field( $this->get_input( $_POST, 'scoring_mode', 'legacy_tri_state' ) );

		if ( ! in_array( $q_type, $valid_types, true ) ) {
			$q_type = 'tri_state';
		}
		if ( ! in_array( $scoring_mode, $valid_scoring_modes, true ) ) {
			$scoring_mode = 'legacy_tri_state';
		}

		$max_score_raw = $this->get_input( $_POST, 'max_score', '' );
		$max_score     = $max_score_raw !== '' ? max( 0, (int) $max_score_raw ) : null;

		$min_sel_raw = $this->get_input( $_POST, 'min_selections', '' );
		$max_sel_raw = $this->get_input( $_POST, 'max_selections', '' );

		$valid_cond_ops = [ 'eq', 'ne', 'contains', 'not_contains' ];
		$condition_op   = sanitize_key( $this->get_input( $_POST, 'condition_op', 'eq' ) );
		if ( ! in_array( $condition_op, $valid_cond_ops, true ) ) {
			$condition_op = 'eq';
		}

		$data = [
			'question_text'    => sanitize_textarea_field( $this->get_input( $_POST, 'question_text' ) ),
			'recommendation'   => sanitize_textarea_field( $this->get_input( $_POST, 'recommendation' ) ),
			'score_yes'        => max( 0, (int) $this->get_input( $_POST, 'score_yes', 2 ) ),
			'score_partial'    => max( 0, (int) $this->get_input( $_POST, 'score_partial', 1 ) ),
			'score_no'         => max( 0, (int) $this->get_input( $_POST, 'score_no', 0 ) ),
			'question_type'    => $q_type,
			'is_required'      => $this->get_input( $_POST, 'is_required' ) === '1' ? 1 : 0,
			'scoring_mode'     => $scoring_mode,
			'max_score'        => $max_score,
			'help_text'        => sanitize_textarea_field( $this->get_input( $_POST, 'help_text' ) ),
			'question_ref'     => sanitize_text_field( $this->get_input( $_POST, 'question_ref' ) ),
			'min_selections'   => $min_sel_raw !== '' ? max( 1, (int) $min_sel_raw ) : null,
			'max_selections'   => $max_sel_raw !== '' ? max( 1, (int) $max_sel_raw ) : null,
			'condition_on_ref' => sanitize_text_field( $this->get_input( $_POST, 'condition_on_ref' ) ),
			'condition_value'  => sanitize_text_field( $this->get_input( $_POST, 'condition_value' ) ),
			'condition_op'     => $condition_op,
		];

		$domain_id_raw = $this->get_input( $_POST, 'domain_id', '' );
		if ( $domain_id_raw !== '' && (int) $domain_id_raw > 0 ) {
			$data['domain_id'] = (int) $domain_id_raw;
		}

		$options_result = [ 'options' => [] ];
		$options_raw = $this->get_input( $_POST, 'answer_options', '' );
		if ( $options_raw !== '' ) {
			$options_result = $this->normalise_question_answer_options( $id, (string) $options_raw );
			if ( ! empty( $options_result['error'] ) ) {
				wp_send_json_error( [ 'message' => $options_result['error'] ] );
				return;
			}
		}

		$ok = WPQ_Database::update_question( $id, $data );
		if ( $ok === false ) {
			wp_send_json_error( [ 'message' => 'Database error — question could not be saved.' ] );
			return;
		}
		$saved_options = [];
		if ( ! empty( $options_result['options'] ) ) {
			$save_result = $this->save_question_answer_options( $options_result['options'] );
			if ( ! empty( $save_result['error'] ) ) {
				wp_send_json_error( [ 'message' => $save_result['error'] ] );
				return;
			}
			$saved_options = $save_result['options'];
		}

		wp_send_json_success( [
			'updated' => $ok,
			'options' => $saved_options,
		] );
	}

	private function normalise_question_answer_options( int $question_id, string $raw_options ): array {
		$decoded = json_decode( $raw_options, true );
		if ( ! is_array( $decoded ) ) {
			return [ 'error' => 'Answer options payload is invalid.' ];
		}

		$seen_keys = [];
		$options = [];
		foreach ( array_values( $decoded ) as $index => $option ) {
			if ( ! is_array( $option ) ) {
				return [ 'error' => 'Answer option row is invalid.' ];
			}

			$label = sanitize_text_field( (string) ( $option['option_label'] ?? '' ) );
			$key = sanitize_key( (string) ( $option['option_key'] ?? '' ) );
			if ( $label === '' && $key === '' ) {
				continue;
			}
			if ( $label === '' ) {
				return [ 'error' => 'Answer option labels are required.' ];
			}
			if ( $key === '' ) {
				$key = sanitize_key( $label );
			}
			if ( $key === '' ) {
				$key = 'option';
			}

			$base_key = $key;
			$suffix = 2;
			while ( isset( $seen_keys[ $key ] ) ) {
				$key = $base_key . '_' . $suffix;
				$suffix++;
			}
			$seen_keys[ $key ] = true;

			$valid_priorities = [ '', 'critical', 'high', 'medium', 'low' ];
			$priority = sanitize_text_field( (string) ( $option['finding_priority'] ?? '' ) );
			if ( ! in_array( $priority, $valid_priorities, true ) ) {
				$priority = '';
			}

			$options[] = [
				'client_id' => sanitize_text_field( (string) ( $option['client_id'] ?? '' ) ),
				'option_id' => max( 0, (int) ( $option['option_id'] ?? 0 ) ),
				'data'      => [
					'question_id'      => $question_id,
					'option_key'       => $key,
					'option_label'     => $label,
					'score'            => max( 0, (int) ( $option['score'] ?? 0 ) ),
					'risk_level'       => sanitize_text_field( (string) ( $option['risk_level'] ?? '' ) ),
					'finding_priority' => $priority,
					'finding_action'   => sanitize_textarea_field( (string) ( $option['finding_action'] ?? '' ) ),
					'sort_order'       => $index + 1,
					'is_default'       => (string) ( $option['is_default'] ?? '' ) === '1' ? 1 : 0,
					'is_active'        => 1,
					'requires_notes'   => (string) ( $option['requires_notes'] ?? '' ) === '1' ? 1 : 0,
					'exclusive'        => (string) ( $option['exclusive'] ?? '' ) === '1' ? 1 : 0,
				],
			];
		}

		return [ 'options' => $options ];
	}

	private function save_question_answer_options( array $options ): array {
		$saved = [];
		foreach ( $options as $option ) {
			$option_id = (int) $option['option_id'];
			$data = $option['data'];
			if ( $option_id > 0 ) {
				if ( WPQ_Database::update_question_option( $option_id, $data ) === false ) {
					return [ 'error' => 'Database error - answer option could not be updated.' ];
				}
			} else {
				$option_id = WPQ_Database::insert_question_option( $data );
				if ( ! $option_id ) {
					return [ 'error' => 'Database error - answer option could not be created.' ];
				}
			}

			$saved[] = [
				'client_id'  => (string) $option['client_id'],
				'option_id'  => $option_id,
				'option_key' => (string) $data['option_key'],
			];
		}

		return [ 'options' => $saved ];
	}

	public function ajax_add_question(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$domain_id = (int) $this->get_input( $_POST, 'domain_id', 0 );
		if ( ! $domain_id ) {
			wp_send_json_error( [ 'message' => 'Domain is required.' ] );
			return;
		}

		global $wpdb;
		$max_order = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT MAX(sort_order) FROM {$wpdb->prefix}wpq_questions WHERE domain_id = %d",
			$domain_id
		) );

		$new_id = WPQ_Database::insert_question( [
			'domain_id'     => $domain_id,
			'sort_order'    => $max_order + 1,
			'question_text' => 'New question',
			'guidance_yes'  => '',
			'guidance_no'   => '',
			'score_yes'     => 2,
			'score_partial' => 1,
			'score_no'      => 0,
			'question_type' => 'tri_state',
			'is_required'   => 1,
			'scoring_mode'  => 'legacy_tri_state',
		] );

		if ( ! $new_id ) {
			wp_send_json_error( [ 'message' => 'Could not create question.' ] );
			return;
		}
		wp_send_json_success( [ 'id' => $new_id ] );
	}

	public function ajax_delete_question(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );
		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid ID.' ] );
			return;
		}
		if ( ! WPQ_Database::delete_question( $id ) ) {
			wp_send_json_error( [ 'message' => 'Could not remove question.' ] );
			return;
		}

		wp_send_json_success();
	}

	public function ajax_reset_questions(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$questionnaire_id = (int) $this->get_input( $_POST, 'questionnaire_id', 0 );
		if ( ! $questionnaire_id ) {
			wp_send_json_error( [ 'message' => 'Questionnaire ID required.' ] );
			return;
		}

		global $wpdb;
		$domain_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_domains WHERE questionnaire_id = %d",
			$questionnaire_id
		) );

		if ( empty( $domain_ids ) ) {
			wp_send_json_success( [ 'deleted' => 0 ] );
			return;
		}

		$question_ids = [];
		foreach ( $domain_ids as $did ) {
			$ids = $wpdb->get_col( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}wpq_questions WHERE domain_id = %d",
				(int) $did
			) );
			$question_ids = array_merge( $question_ids, $ids );
		}

		$deleted = 0;
		$failed  = 0;
		foreach ( $question_ids as $q_id ) {
			if ( WPQ_Database::delete_question( (int) $q_id ) ) {
				$deleted++;
			} else {
				$failed++;
			}
		}

		if ( $failed > 0 ) {
			wp_send_json_error( [
				'message' => sprintf( '%d question(s) could not be removed.', $failed ),
				'deleted' => $deleted,
				'failed'  => $failed,
			] );
			return;
		}

		wp_send_json_success( [ 'deleted' => $deleted ] );
	}

	public function ajax_add_domain(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$questionnaire_id = (int) $this->get_input( $_POST, 'questionnaire_id', 0 );
		$name             = sanitize_text_field( $this->get_input( $_POST, 'name' ) );
		$icon             = sanitize_text_field( $this->get_input( $_POST, 'icon' ) );

		if ( ! $questionnaire_id || ! $name ) {
			wp_send_json_error( [ 'message' => 'Questionnaire and name are required.' ] );
			return;
		}

		global $wpdb;
		$max_order = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT MAX(sort_order) FROM {$wpdb->prefix}wpq_domains WHERE questionnaire_id = %d",
			$questionnaire_id
		) );

		$slug   = sanitize_title( $name );
		$new_id = WPQ_Database::insert_domain( [
			'questionnaire_id' => $questionnaire_id,
			'sort_order'       => $max_order + 1,
			'slug'             => $slug ?: 'domain-' . ( $max_order + 1 ),
			'name'             => $name,
			'icon'             => $icon,
			'domain_weight'    => 100,
		] );

		if ( ! $new_id ) {
			wp_send_json_error( [ 'message' => 'Could not create domain.' ] );
			return;
		}
		wp_send_json_success( [ 'id' => $new_id ] );
	}

	public function ajax_update_domain(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id         = (int) $this->get_input( $_POST, 'id', 0 );
		$data       = $this->sanitize_domain_payload( $_POST, $id );

		if ( ! $id || $data['name'] === '' ) {
			wp_send_json_error( [ 'message' => 'ID and name are required.' ] );
			return;
		}

		$ok = WPQ_Database::update_domain( $id, $data );

		if ( ! $ok ) {
			wp_send_json_error( [ 'message' => 'Could not update domain.' ] );
			return;
		}
		wp_send_json_success();
	}

	public function ajax_update_domains(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$raw_domains = $this->get_input( $_POST, 'domains', [] );
		if ( ! is_array( $raw_domains ) ) {
			wp_send_json_error( [ 'message' => 'No domains were submitted.' ] );
			return;
		}

		$updated = 0;
		$failed  = 0;
		foreach ( $raw_domains as $raw_domain ) {
			if ( ! is_array( $raw_domain ) ) {
				$failed++;
				continue;
			}

			$id = (int) ( $raw_domain['id'] ?? 0 );
			if ( $id <= 0 ) {
				$failed++;
				continue;
			}

			$data = $this->sanitize_domain_payload( $raw_domain, $id );
			if ( $data['name'] === '' ) {
				$failed++;
				continue;
			}

			$ok = WPQ_Database::update_domain( $id, $data );
			if ( $ok === false ) {
				$failed++;
			} else {
				$updated++;
			}
		}

		if ( $failed > 0 ) {
			wp_send_json_error( [
				'message' => sprintf( '%d domain row(s) could not be saved.', $failed ),
				'updated' => $updated,
				'failed'  => $failed,
			] );
			return;
		}

		wp_send_json_success( [ 'updated' => $updated ] );
	}

	private function sanitize_domain_payload( array $source, int $id ): array {
		$name = sanitize_text_field( $this->get_input( $source, 'name' ) );

		return [
			'name'       => $name,
			'icon'       => sanitize_text_field( $this->get_input( $source, 'icon' ) ),
			'sort_order' => (int) $this->get_input( $source, 'sort_order', 0 ),
			'slug'       => sanitize_title( $name ) ?: 'domain-' . $id,
			'brief'      => sanitize_textarea_field( $this->get_input( $source, 'brief' ) ),
		];
	}

	public function ajax_delete_domain(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );
		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid ID.' ] );
			return;
		}
		if ( ! WPQ_Database::delete_domain( $id ) ) {
			wp_send_json_error( [ 'message' => 'Could not remove domain.' ] );
			return;
		}

		wp_send_json_success();
	}

	public function ajax_save_domain_weight(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id     = (int) $this->get_input( $_POST, 'id', 0 );
		$weight = max( 0, (int) $this->get_input( $_POST, 'weight', 100 ) );

		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid ID.' ] );
			return;
		}
		if ( ! WPQ_Database::update_domain( $id, [ 'domain_weight' => $weight ] ) ) {
			wp_send_json_error( [ 'message' => 'Could not save domain weight.' ] );
			return;
		}

		wp_send_json_success();
	}

	public function ajax_save_question_scoring(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id     = (int) $this->get_input( $_POST, 'id', 0 );
		$weight = max( 0, (int) $this->get_input( $_POST, 'question_weight', 100 ) );

		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid ID.' ] );
			return;
		}
		$data = [
			'score_yes'        => max( 0, (int) $this->get_input( $_POST, 'score_yes', 2 ) ),
			'score_partial'    => max( 0, (int) $this->get_input( $_POST, 'score_partial', 1 ) ),
			'score_no'         => max( 0, (int) $this->get_input( $_POST, 'score_no', 0 ) ),
			'question_weight'  => $weight,
			'guidance_yes'     => sanitize_textarea_field( $this->get_input( $_POST, 'guidance_yes' ) ),
			'guidance_partial' => sanitize_textarea_field( $this->get_input( $_POST, 'guidance_partial' ) ),
			'guidance_no'      => sanitize_textarea_field( $this->get_input( $_POST, 'guidance_no' ) ),
		];
		if ( ! WPQ_Database::update_question( $id, $data ) ) {
			wp_send_json_error( [ 'message' => 'Could not save question scoring.' ] );
			return;
		}

		// Per-option guidance (radio / select / checkbox questions).
		$option_failures = 0;
		$raw = $this->get_input( $_POST, 'option_guidances', '' );
		if ( $raw !== '' ) {
			$map = json_decode( wp_unslash( $raw ), true );
			if ( is_array( $map ) ) {
				foreach ( $map as $opt_id => $text ) {
					$opt_id = (int) $opt_id;
					if ( $opt_id > 0 ) {
						$ok = WPQ_Database::update_question_option( $opt_id, [
							'guidance' => sanitize_textarea_field( (string) $text ),
						] );
						if ( ! $ok ) {
							$option_failures++;
						}
					}
				}
			}
		}

		if ( $option_failures > 0 ) {
			wp_send_json_error( [
				'message' => sprintf( '%d option guidance row(s) could not be saved.', $option_failures ),
				'failed'  => $option_failures,
			] );
			return;
		}

		wp_send_json_success();
	}

	public function ajax_save_question_option(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$option_id   = (int) $this->get_input( $_POST, 'option_id', 0 );
		$question_id = (int) $this->get_input( $_POST, 'question_id', 0 );

		if ( ! $question_id ) {
			wp_send_json_error( [ 'message' => 'Question ID is required.' ] );
			return;
		}

		$valid_priorities = [ '', 'critical', 'high', 'medium', 'low' ];
		$priority         = sanitize_text_field( $this->get_input( $_POST, 'finding_priority' ) );
		if ( ! in_array( $priority, $valid_priorities, true ) ) {
			$priority = '';
		}

		$data = [
			'question_id'      => $question_id,
			'option_key'       => sanitize_key( $this->get_input( $_POST, 'option_key' ) ),
			'option_label'     => sanitize_text_field( $this->get_input( $_POST, 'option_label' ) ),
			'score'            => (int) $this->get_input( $_POST, 'score', 0 ),
			'risk_level'       => sanitize_text_field( $this->get_input( $_POST, 'risk_level' ) ),
			'finding_priority' => $priority,
			'finding_action'   => sanitize_textarea_field( $this->get_input( $_POST, 'finding_action' ) ),
			'sort_order'       => (int) $this->get_input( $_POST, 'sort_order', 0 ),
			'is_default'       => $this->get_input( $_POST, 'is_default' ) === '1' ? 1 : 0,
			'is_active'        => 1,
			'requires_notes'   => $this->get_input( $_POST, 'requires_notes' ) === '1' ? 1 : 0,
			'exclusive'        => $this->get_input( $_POST, 'exclusive' ) === '1' ? 1 : 0,
		];

		if ( ! $data['option_key'] || ! $data['option_label'] ) {
			wp_send_json_error( [ 'message' => 'Option key and label are required.' ] );
			return;
		}

		if ( $option_id ) {
			$ok = WPQ_Database::update_question_option( $option_id, $data );
			if ( $ok === false ) {
				wp_send_json_error( [ 'message' => 'Database error — option could not be updated.' ] );
				return;
			}
			wp_send_json_success( [ 'option_id' => $option_id ] );
		} else {
			$new_id = WPQ_Database::insert_question_option( $data );
			if ( ! $new_id ) {
				wp_send_json_error( [ 'message' => 'Database error — option could not be created.' ] );
				return;
			}
			wp_send_json_success( [ 'option_id' => $new_id ] );
		}
	}

	public function ajax_delete_question_option(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$option_id = (int) $this->get_input( $_POST, 'option_id', 0 );
		if ( ! $option_id ) {
			wp_send_json_error( [ 'message' => 'Option ID is required.' ] );
			return;
		}

		$ok = WPQ_Database::delete_question_option( $option_id );
		if ( ! $ok ) {
			wp_send_json_error( [ 'message' => 'Option could not be deleted.' ] );
			return;
		}
		wp_send_json_success( [ 'deleted' => $option_id ] );
	}

	public function ajax_save_grade(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id   = (int) $this->get_input( $_POST, 'id', 0 );
		$data = $this->sanitize_grade_payload( $_POST );

		$ok = WPQ_Database::update_grade_threshold( $id, $data );
		if ( $ok === false ) {
			wp_send_json_error( [ 'message' => 'Database error — grade could not be saved.' ] );
			return;
		}
		wp_send_json_success( [ 'updated' => $ok ] );
	}

	public function ajax_save_grades(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$raw_grades = $this->get_input( $_POST, 'grades', [] );
		if ( ! is_array( $raw_grades ) ) {
			wp_send_json_error( [ 'message' => 'No grades were submitted.' ] );
			return;
		}

		$updated = 0;
		$failed  = 0;
		foreach ( $raw_grades as $raw_grade ) {
			if ( ! is_array( $raw_grade ) ) {
				$failed++;
				continue;
			}

			$id = (int) ( $raw_grade['id'] ?? 0 );
			if ( $id <= 0 ) {
				$failed++;
				continue;
			}

			$ok = WPQ_Database::update_grade_threshold( $id, $this->sanitize_grade_payload( $raw_grade ) );
			if ( $ok === false ) {
				$failed++;
			} else {
				$updated++;
			}
		}

		if ( $failed > 0 ) {
			wp_send_json_error( [
				'message' => sprintf( '%d grade row(s) could not be saved.', $failed ),
				'updated' => $updated,
				'failed'  => $failed,
			] );
			return;
		}

		wp_send_json_success( [ 'updated' => $updated ] );
	}

	private function sanitize_grade_payload( array $source ): array {
		return [
			'grade_label'  => sanitize_text_field( $this->get_input( $source, 'grade_label' ) ),
			'verdict_text' => sanitize_textarea_field( $this->get_input( $source, 'verdict_text' ) ),
			'min_score'    => max( 0, min( 100, (int) $this->get_input( $source, 'min_score', 0 ) ) ),
			'color_hex'    => sanitize_hex_color( $this->get_input( $source, 'color_hex', '#333333' ) ) ?: '#333333',
			'bg_hex'       => sanitize_hex_color( $this->get_input( $source, 'bg_hex', '#f5f5f5' ) ) ?: '#f5f5f5',
		];
	}

	public function ajax_add_grade(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$q_id = (int) $this->get_input( $_POST, 'questionnaire_id', 0 );
		if ( ! $q_id ) {
			wp_send_json_error( [ 'message' => 'Invalid questionnaire ID.' ] );
			return;
		}

		$id = WPQ_Database::insert_grade_threshold( [
			'questionnaire_id' => $q_id,
			'min_score'        => 0,
			'grade_id'         => 'grade_new',
			'grade_label'      => 'New Grade',
			'verdict_text'     => '',
			'color_hex'        => '#333333',
			'bg_hex'           => '#f5f5f5',
		] );

		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Failed to create grade.' ] );
			return;
		}

		$grade_id = 'grade_' . $id;
		if ( ! WPQ_Database::update_grade_threshold( $id, [ 'grade_id' => $grade_id ] ) ) {
			wp_send_json_error( [ 'message' => 'Failed to initialise grade.' ] );
			return;
		}

		wp_send_json_success( [
			'id'           => $id,
			'grade_id'     => $grade_id,
			'min_score'    => 0,
			'grade_label'  => 'New Grade',
			'verdict_text' => '',
			'color_hex'    => '#333333',
			'bg_hex'       => '#f5f5f5',
		] );
	}

	public function ajax_delete_grade(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );
		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid grade ID.' ] );
			return;
		}

		$ok = WPQ_Database::delete_grade_threshold( $id );
		if ( ! $ok ) {
			wp_send_json_error( [ 'message' => 'Failed to delete grade.' ] );
			return;
		}
		wp_send_json_success( [ 'deleted' => $id ] );
	}

	public function ajax_save_product(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id              = (int) $this->get_input( $_POST, 'id', 0 );
		$name            = sanitize_text_field( $this->get_input( $_POST, 'name' ) );
		$stripe_price_id = sanitize_text_field( $this->get_input( $_POST, 'stripe_price_id' ) );

		if ( ! $name ) {
			wp_send_json_error( [ 'message' => 'Name is required.' ] );
			return;
		}

		if ( $stripe_price_id && ! preg_match( '/^price_[A-Za-z0-9]+$/', $stripe_price_id ) ) {
			wp_send_json_error( [ 'message' => 'Stripe Price ID must start with price_ and contain only letters and numbers.' ] );
			return;
		}

		$valid_billing = [ 'one_off', 'subscription_annual', 'subscription_monthly' ];
		$valid_report  = [ 'professional', 'annual', 'bundle' ];
		$valid_status  = [ 'active', 'inactive' ];

		$status = in_array( $this->get_input( $_POST, 'status' ), $valid_status, true ) ? sanitize_text_field( $this->get_input( $_POST, 'status' ) ) : 'inactive';

		// Validate questionnaire existence when one is selected.
		$q_id_raw = $this->get_input( $_POST, 'questionnaire_id' );
		$q_id     = $q_id_raw !== '' ? (int) $q_id_raw : null;
		if ( $q_id && ! WPQ_Database::get_questionnaire( $q_id ) ) {
			wp_send_json_error( [ 'message' => 'Selected questionnaire does not exist.' ] );
			return;
		}

		// Active products require a Stripe Price ID, unless Stripe can auto-create one.
		if ( $status === 'active' && $stripe_price_id === '' ) {
			$can_auto = false;
			if ( $q_id && WPQ_Stripe::can_initialise() ) {
				$linked_q = WPQ_Database::get_questionnaire( $q_id );
				$can_auto = $linked_q && ! empty( $linked_q->stripe_product_id );
			}
			if ( ! $can_auto ) {
				wp_send_json_error( [ 'message' => 'Active products require a Stripe Price ID. Save the linked questionnaire first to auto-create its Stripe product.' ] );
				return;
			}
		}

		$data = [
			'name'             => $name,
			'description'      => sanitize_textarea_field( $this->get_input( $_POST, 'description' ) ),
			'price_gbp'        => round( max( 0.0, (float) $this->get_input( $_POST, 'price_gbp', 0 ) ), 2 ),
			'stripe_price_id'  => $stripe_price_id,
			'billing_type'     => in_array( $this->get_input( $_POST, 'billing_type' ), $valid_billing, true ) ? sanitize_text_field( $this->get_input( $_POST, 'billing_type' ) ) : 'one_off',
			'report_type'      => in_array( $this->get_input( $_POST, 'report_type' ), $valid_report,  true ) ? sanitize_text_field( $this->get_input( $_POST, 'report_type' ) ) : 'professional',
			'status'           => $status,
			'questionnaire_id' => $q_id,
		];

		if ( $id ) {
			// Verify the product exists before attempting an update.
			if ( ! WPQ_Database::get_product_admin( $id ) ) {
				wp_send_json_error( [ 'message' => 'Product not found.' ] );
				return;
			}
			$ok = WPQ_Database::update_product( $id, $data );
			if ( $ok === false ) {
				wp_send_json_error( [ 'message' => 'Database error — product could not be saved.' ] );
				return;
			}
			// Auto-create Stripe Price if none is set yet and the questionnaire has a Stripe product.
			if ( $stripe_price_id === '' && $q_id && WPQ_Stripe::can_initialise() ) {
				$linked_q = WPQ_Database::get_questionnaire( $q_id );
				if ( $linked_q && ! empty( $linked_q->stripe_product_id ) ) {
					try {
						$amount_pence = (int) round( $data['price_gbp'] * 100 );
						$new_price    = WPQ_Stripe::create_price( $linked_q->stripe_product_id, $amount_pence, 'gbp', $data['billing_type'] );
						if ( ! WPQ_Database::update_product( $id, [ 'stripe_price_id' => $new_price->id ] ) ) {
							wp_send_json_error( [ 'message' => 'Stripe Price was created, but the product could not be updated.' ] );
							return;
						}
					} catch ( Throwable $e ) {
						unset( $e ); // Non-fatal; price_id can be set manually.
					}
				}
			}
		} else {
			$slug = sanitize_title( $name );
			if ( WPQ_Database::slug_exists( $slug ) ) {
				wp_send_json_error( [ 'message' => 'A product with this name already exists. Please use a unique name.' ] );
				return;
			}
			$data['slug'] = $slug;
			$new_id = WPQ_Database::insert_product( $data );
			if ( ! $new_id ) {
				wp_send_json_error( [ 'message' => 'Database error — product could not be created.' ] );
				return;
			}
			// Auto-create Stripe Price if the questionnaire has a Stripe product.
			if ( $stripe_price_id === '' && $q_id && WPQ_Stripe::can_initialise() ) {
				$linked_q = WPQ_Database::get_questionnaire( $q_id );
				if ( $linked_q && ! empty( $linked_q->stripe_product_id ) ) {
					try {
						$amount_pence = (int) round( $data['price_gbp'] * 100 );
						$new_price    = WPQ_Stripe::create_price( $linked_q->stripe_product_id, $amount_pence, 'gbp', $data['billing_type'] );
						if ( ! WPQ_Database::update_product( $new_id, [ 'stripe_price_id' => $new_price->id ] ) ) {
							wp_send_json_error( [ 'message' => 'Stripe Price was created, but the product could not be updated.' ] );
							return;
						}
					} catch ( Throwable $e ) {
						unset( $e ); // Non-fatal; price_id can be set manually.
					}
				}
			}
		}

		wp_send_json_success( [ 'updated' => true ] );
	}

	public function ajax_create_coupon(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$name          = sanitize_text_field( $this->get_input( $_POST, 'name' ) );
		$promo_code    = strtoupper( sanitize_text_field( $this->get_input( $_POST, 'promo_code' ) ) );
		$discount_type = in_array( $this->get_input( $_POST, 'discount_type' ), [ 'percent', 'fixed' ], true ) ? $this->get_input( $_POST, 'discount_type' ) : 'percent';
		$percent_off   = max( 1, min( 100, (int) $this->get_input( $_POST, 'percent_off', 0 ) ) );
		$amount_off    = (int) round( max( 0.0, (float) $this->get_input( $_POST, 'amount_off', 0 ) ) * 100 );
		$currency      = sanitize_text_field( $this->get_input( $_POST, 'currency', 'GBP' ) );
		$duration      = in_array( $this->get_input( $_POST, 'duration' ), [ 'once', 'repeating', 'forever' ], true ) ? $this->get_input( $_POST, 'duration' ) : 'once';
		$duration_months = max( 1, (int) $this->get_input( $_POST, 'duration_in_months', 1 ) );
		$max_raw         = $this->get_input( $_POST, 'max_redemptions', '' );
		$max_redemptions = $max_raw !== '' ? max( 1, (int) $max_raw ) : null;
		$redeem_by_raw   = $this->get_input( $_POST, 'redeem_by', '' );
		$redeem_by_ts    = $redeem_by_raw !== '' ? strtotime( $redeem_by_raw ) : null;
		$scope           = in_array( $this->get_input( $_POST, 'scope' ), [ 'all', 'questionnaire', 'catalogue_item' ], true ) ? $this->get_input( $_POST, 'scope' ) : 'all';
		$questionnaire_id = $this->get_input( $_POST, 'questionnaire_id', '' ) !== '' ? (int) $this->get_input( $_POST, 'questionnaire_id' ) : null;
		$product_id       = $this->get_input( $_POST, 'product_id', '' ) !== '' ? (int) $this->get_input( $_POST, 'product_id' ) : null;

		if ( ! $name ) {
			wp_send_json_error( [ 'message' => 'Name is required.' ] );
			return;
		}
		if ( $discount_type === 'percent' && ( $percent_off < 1 || $percent_off > 100 ) ) {
			wp_send_json_error( [ 'message' => 'Percent off must be between 1 and 100.' ] );
			return;
		}
		if ( $discount_type === 'fixed' && $amount_off <= 0 ) {
			wp_send_json_error( [ 'message' => 'Amount off must be greater than zero.' ] );
			return;
		}
		if ( $promo_code && ! preg_match( '/^[A-Z0-9_-]{1,50}$/', $promo_code ) ) {
			wp_send_json_error( [ 'message' => 'Promo code may only contain letters, numbers, hyphens, and underscores (max 50 characters).' ] );
			return;
		}
		if ( ! WPQ_Stripe::can_initialise() ) {
			wp_send_json_error( [ 'message' => 'Stripe is not configured. Please set your API keys in Settings → Stripe.' ] );
			return;
		}

		$stripe_params = [
			'name'     => $name,
			'duration' => $duration,
		];
		if ( $discount_type === 'percent' ) {
			$stripe_params['percent_off'] = $percent_off;
		} else {
			$stripe_params['amount_off'] = $amount_off;
			$stripe_params['currency']   = strtolower( $currency );
		}
		if ( $duration === 'repeating' ) {
			$stripe_params['duration_in_months'] = $duration_months;
		}
		if ( $max_redemptions !== null ) {
			$stripe_params['max_redemptions'] = $max_redemptions;
		}
		if ( $redeem_by_ts !== null && $redeem_by_ts !== false ) {
			$stripe_params['redeem_by'] = $redeem_by_ts;
		}

		if ( $scope === 'questionnaire' && $questionnaire_id ) {
			$questionnaire = WPQ_Database::get_questionnaire( $questionnaire_id );
			if ( $questionnaire && ! empty( $questionnaire->stripe_product_id ) ) {
				$stripe_params['applies_to'] = [ 'products' => [ $questionnaire->stripe_product_id ] ];
			}
		}

		try {
			$coupon = WPQ_Stripe::create_coupon( $stripe_params );
		} catch ( Throwable $e ) {
			error_log( 'WPQ: Stripe coupon creation failed: ' . $e->getMessage() );
			wp_send_json_error( [ 'message' => 'Stripe coupon could not be created.' ] );
			return;
		}

		$promo_id = null;
		if ( $promo_code ) {
			try {
				$promo    = WPQ_Stripe::create_promotion_code( $coupon->id, $promo_code, $max_redemptions, ( $redeem_by_ts !== null && $redeem_by_ts !== false ) ? (int) $redeem_by_ts : null );
				$promo_id = $promo->id;
			} catch ( Throwable $e ) {
				try {
					WPQ_Stripe::delete_coupon( $coupon->id );
				} catch ( Throwable $cleanup_err ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- best-effort cleanup; error is unactionable
					error_log( 'WPQ: Stripe coupon cleanup failed: ' . $cleanup_err->getMessage() );
				}
				error_log( 'WPQ: Stripe promo code creation failed: ' . $e->getMessage() );
				wp_send_json_error( [ 'message' => 'Stripe promotion code could not be created.' ] );
				return;
			}
		}

		$db_data = [
			'stripe_coupon_id'   => $coupon->id,
			'stripe_promo_id'    => $promo_id,
			'promo_code'         => $promo_code ?: null,
			'name'               => $name,
			'discount_type'      => $discount_type,
			'percent_off'        => $discount_type === 'percent' ? $percent_off : null,
			'amount_off'         => $discount_type === 'fixed' ? $amount_off : null,
			'currency'           => $discount_type === 'fixed' ? strtoupper( $currency ) : null,
			'duration'           => $duration,
			'duration_in_months' => $duration === 'repeating' ? $duration_months : null,
			'max_redemptions'    => $max_redemptions,
			'redeem_by'          => ( $redeem_by_ts !== null && $redeem_by_ts !== false ) ? gmdate( 'Y-m-d H:i:s', (int) $redeem_by_ts ) : null,
			'scope'              => $scope,
			'questionnaire_id'   => $scope === 'questionnaire' ? $questionnaire_id : null,
			'product_id'         => $scope === 'catalogue_item' ? $product_id : null,
			'status'             => 'active',
			'created_at'         => current_time( 'mysql', true ),
		];

		$new_id = WPQ_Database::insert_coupon( $db_data );
		if ( ! $new_id ) {
			try {
					WPQ_Stripe::delete_coupon( $coupon->id );
				} catch ( Throwable $cleanup_err ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- best-effort cleanup; error is unactionable
					error_log( 'WPQ: Stripe coupon cleanup failed: ' . $cleanup_err->getMessage() );
				}
			wp_send_json_error( [ 'message' => 'Database error — coupon could not be saved.' ] );
			return;
		}

		wp_send_json_success( [ 'created' => true ] );
	}

	public function ajax_delete_coupon(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );
		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid coupon ID.' ] );
			return;
		}

		$coupon = WPQ_Database::get_coupon( $id );
		if ( ! $coupon ) {
			wp_send_json_error( [ 'message' => 'Coupon not found.' ] );
			return;
		}

		if ( WPQ_Stripe::can_initialise() ) {
			try {
				WPQ_Stripe::delete_coupon( $coupon->stripe_coupon_id );
			} catch ( Throwable $e ) {
				if ( strpos( $e->getMessage(), 'No such coupon' ) === false ) {
					error_log( 'WPQ: Stripe coupon deletion failed: ' . $e->getMessage() );
					wp_send_json_error( [ 'message' => 'Stripe coupon could not be deleted.' ] );
					return;
				}
			}
		}

		if ( ! WPQ_Database::update_coupon( $id, [ 'status' => 'deleted' ] ) ) {
			wp_send_json_error( [ 'message' => 'Could not update coupon status.' ] );
			return;
		}

		wp_send_json_success( [ 'deleted' => true ] );
	}

	public function ajax_delete_product(): void {
		check_ajax_referer( 'wpq_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

		$id = (int) $this->get_input( $_POST, 'id', 0 );
		if ( ! $id ) {
			wp_send_json_error( [ 'message' => 'Invalid pricing option ID.' ] );
			return;
		}

		$product = WPQ_Database::get_product_admin( $id );
		if ( ! $product ) {
			wp_send_json_error( [ 'message' => 'Pricing option not found.' ] );
			return;
		}

		if ( ! empty( $product->stripe_price_id ) && WPQ_Stripe::can_initialise() ) {
			try {
				WPQ_Stripe::archive_price( $product->stripe_price_id );
			} catch ( Throwable $e ) {
				if ( strpos( $e->getMessage(), 'No such price' ) === false ) {
					error_log( 'WPQ: Stripe price archive failed: ' . $e->getMessage() );
					wp_send_json_error( [ 'message' => 'Stripe price could not be archived.' ] );
					return;
				}
			}
		}

		if ( ! WPQ_Database::delete_product( $id ) ) {
			wp_send_json_error( [ 'message' => 'Could not remove pricing option.' ] );
			return;
		}

		wp_send_json_success( [ 'deleted' => true ] );
	}

}
