<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** @var array<int, object> $categories */
/** @var array<int, object> $ctas */
/** @var array<string, array<int, object>> $domains_by_category */
/** @var object|null $edit_cta */

$edit_cta = $edit_cta ?? null;
$selected_category = $edit_cta ? (string) $edit_cta->category_slug : (string) ( $categories[0]->slug ?? '' );
$selected_domain   = $edit_cta ? (string) $edit_cta->domain_slug : '';
$domain_map        = [];
$domain_names      = [];

foreach ( $domains_by_category as $category_slug => $domains ) {
	$domain_map[ $category_slug ] = array_map(
		static fn( $domain ) => [
			'slug' => (string) $domain->slug,
			'name' => (string) $domain->name,
		],
		$domains
	);

	$domain_names[ $category_slug ] = [];
	foreach ( $domains as $domain ) {
		$domain_names[ $category_slug ][ (string) $domain->slug ] = (string) $domain->name;
	}
}

$domain_label = static function ( object $cta ) use ( $domain_names ): string {
	$domain_slug = (string) $cta->domain_slug;
	if ( $domain_slug === '' ) {
		return 'Category-wide';
	}

	$category_slug = (string) $cta->category_slug;
	return $domain_names[ $category_slug ][ $domain_slug ] ?? $domain_slug;
};

$cta_schedule_label = static function ( object $cta ): string {
	$start = (string) ( $cta->start_date ?? '' );
	$end   = (string) ( $cta->end_date ?? '' );
	if ( '' === $start && '' === $end ) {
		return 'Forever';
	}
	return ( '' !== $start ? wp_date( 'd M Y', strtotime( $start ) ) : 'Any time' )
		. ' - '
		. ( '' !== $end ? wp_date( 'd M Y', strtotime( $end ) ) : 'no end' );
};

$cta_is_live = static function ( object $cta ): bool {
	if ( 'active' !== (string) $cta->status ) {
		return false;
	}
	$today = current_time( 'Y-m-d', true );
	$start = (string) ( $cta->start_date ?? '' );
	$end   = (string) ( $cta->end_date ?? '' );
	return ( '' === $start || $start <= $today ) && ( '' === $end || $end >= $today );
};
?>
<div class="wrap wpq-admin-wrap">
  <h1>Call to Action
    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-import-export' ) ); ?>" class="page-title-action">Import</a>
    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpq_export&type=ctas' ), 'wpq_export_ctas' ) ); ?>" class="page-title-action">Export all</a>
  </h1>

  <?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
    <div class="notice notice-success is-dismissible"><p>Call to action saved.</p></div>
  <?php endif; ?>
  <?php if ( isset( $_GET['deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
    <div class="notice notice-success is-dismissible"><p>Call to action deleted.</p></div>
  <?php endif; ?>
  <?php if ( isset( $_GET['error'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
    <div class="notice notice-error is-dismissible"><p>Could not save the call to action. Please check the selected category and try again.</p></div>
  <?php endif; ?>

  <p class="description" style="max-width:900px;">
    Create small rich-text CTA sections for questionnaire result pages. A category CTA appears below the full key findings list.
    A domain CTA appears after the matching domain's recommendations. The public result page shows at most three domain CTAs plus one category CTA.
    A category or domain can hold more than one CTA - give one a start/end date (e.g. a Christmas special) and it takes over from
    the evergreen "forever" CTA for that window automatically, handing back once it ends.
  </p>

  <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:1000px;margin:20px 0 30px;">
    <input type="hidden" name="action" value="wpq_save_cta">
    <input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $edit_cta->id ?? 0 ) ); ?>">
    <?php wp_nonce_field( 'wpq_save_cta' ); ?>

    <table class="form-table" role="presentation">
      <tr>
        <th scope="row"><label for="wpq-cta-category">Category</label></th>
        <td>
          <select id="wpq-cta-category" name="category_slug" required>
            <?php foreach ( $categories as $category ) : ?>
              <option value="<?php echo esc_attr( (string) $category->slug ); ?>" <?php selected( $selected_category, (string) $category->slug ); ?>>
                <?php echo esc_html( (string) $category->name ); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </td>
      </tr>
      <tr>
        <th scope="row"><label for="wpq-cta-domain">Domain</label></th>
        <td>
          <select id="wpq-cta-domain" name="domain_slug" data-selected="<?php echo esc_attr( $selected_domain ); ?>">
            <option value="">Category-wide CTA</option>
          </select>
          <p class="description">Domain options are built from every questionnaire linked to the selected category, de-duplicated and sorted alphabetically.</p>
        </td>
      </tr>
      <tr>
        <th scope="row"><label for="wpq-cta-status">Status</label></th>
        <td>
          <select id="wpq-cta-status" name="status">
            <option value="active" <?php selected( (string) ( $edit_cta->status ?? 'active' ), 'active' ); ?>>Active</option>
            <option value="inactive" <?php selected( (string) ( $edit_cta->status ?? 'active' ), 'inactive' ); ?>>Inactive</option>
          </select>
        </td>
      </tr>
      <tr>
        <th scope="row"><label for="wpq-cta-start-date">Start date</label></th>
        <td>
          <input type="date" id="wpq-cta-start-date" name="start_date" value="<?php echo esc_attr( (string) ( $edit_cta->start_date ?? '' ) ); ?>">
          <p class="description">Leave blank to run from the start (no earlier limit).</p>
        </td>
      </tr>
      <tr>
        <th scope="row"><label for="wpq-cta-end-date">End date</label></th>
        <td>
          <input type="date" id="wpq-cta-end-date" name="end_date" value="<?php echo esc_attr( (string) ( $edit_cta->end_date ?? '' ) ); ?>">
          <p class="description">
            Leave both dates blank to run forever. A category or domain can hold more than one CTA -
            when today falls within this one's dates, it is shown instead of any other CTA for the
            same category/domain; outside that window, the best-matching CTA with no dates ("forever")
            is shown instead.
          </p>
        </td>
      </tr>
    </table>

    <?php
    wp_editor(
      (string) ( $edit_cta->body_html ?? '' ),
      'wpq_cta_body',
      [
        'textarea_name' => 'body_html',
        'textarea_rows' => 8,
        'media_buttons' => false,
        'teeny'         => true,
      ]
    );
    ?>

    <p>
      <button type="submit" class="button button-primary"><?php echo $edit_cta ? esc_html( 'Update CTA' ) : esc_html( 'Create CTA' ); ?></button>
      <?php if ( $edit_cta ) : ?>
        <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=wpq-ctas' ) ); ?>">Create new</a>
      <?php endif; ?>
    </p>
  </form>

  <h2>Existing CTAs</h2>
  <table class="widefat striped" style="max-width:1100px;">
    <thead>
      <tr>
        <th>Category</th>
        <th>Domain</th>
        <th>Status</th>
        <th>Dates</th>
        <th>Preview</th>
        <th style="width:150px;">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $ctas ) ) : ?>
        <tr><td colspan="6">No calls to action have been created yet.</td></tr>
      <?php endif; ?>
      <?php foreach ( $ctas as $cta ) : ?>
        <tr>
          <td><code><?php echo esc_html( (string) $cta->category_slug ); ?></code></td>
          <td><?php echo esc_html( $domain_label( $cta ) ); ?></td>
          <td><?php echo esc_html( ucfirst( (string) $cta->status ) ); ?></td>
          <td>
            <?php echo esc_html( $cta_schedule_label( $cta ) ); ?>
            <?php if ( $cta_is_live( $cta ) ) : ?>
              <br><strong style="color:#2eb872;">Live now</strong>
            <?php endif; ?>
          </td>
          <td><?php echo wp_kses_post( wp_trim_words( wp_strip_all_tags( (string) $cta->body_html ), 24 ) ); ?></td>
          <td>
            <a class="button button-small" href="<?php echo esc_url( add_query_arg( [ 'page' => 'wpq-ctas', 'id' => (int) $cta->id ], admin_url( 'admin.php' ) ) ); ?>">Edit</a>
            <a class="button button-small" href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'wpq_delete_cta', 'id' => (int) $cta->id ], admin_url( 'admin-post.php' ) ), 'wpq_delete_cta' ) ); ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script>
(function() {
  const domainsByCategory = <?php echo wp_json_encode( $domain_map ); ?>;
  const category = document.getElementById('wpq-cta-category');
  const domain = document.getElementById('wpq-cta-domain');
  if (!category || !domain) return;

  function fillDomains() {
    const selected = domain.dataset.selected || '';
    const rows = domainsByCategory[category.value] || [];
    domain.innerHTML = '';
    const categoryOption = document.createElement('option');
    categoryOption.value = '';
    categoryOption.textContent = 'Category-wide CTA';
    domain.appendChild(categoryOption);
    rows.forEach(function(row) {
      const option = document.createElement('option');
      option.value = row.slug;
      option.textContent = row.name;
      domain.appendChild(option);
    });
    domain.value = selected;
    if (domain.value !== selected) {
      domain.value = '';
    }
  }

  category.addEventListener('change', function() {
    domain.dataset.selected = '';
    fillDomains();
  });
  fillDomains();
})();
</script>
