<?php
// Runs when the plugin is deleted from WP Admin → Plugins.

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Always clean up rate-limit transients (runtime artefacts, no business value).
// WordPress has no efficient wildcard transient deletion API; these prefixes are
// plugin-owned and never include user input.
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Plugin-owned wildcard transient cleanup.
$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '_transient_wpq_rl_%'
	    OR option_name LIKE '_transient_timeout_wpq_rl_%'"
);

// The custom role is always removed on uninstall — it is a plugin artefact and
// grants no access without the plugin present. Data tables are preserved unless
// the admin has explicitly opted in to destructive deletion.
remove_role( 'wpq_halopsa' );

// Only drop tables and remove settings when the admin has explicitly opted in.
// Default is off so that accidentally deleting the plugin does not destroy lead
// records, assessment data, and reporting history.
if ( get_option( 'wpq_delete_data_on_uninstall' ) !== 'yes' ) {
	return;
}

$tables = [
	// Fixed internal allow-list only. Never add user-controlled table names here.
	'wpq_question_control_mappings',
	'wpq_framework_controls',
	'wpq_frameworks',
	'wpq_report_tokens',
	'wpq_payment_events',
	'wpq_payment_sessions',
	'wpq_submissions',
	'wpq_products',
	'wpq_ctas',
	'wpq_grade_thresholds',
	'wpq_questions',
	'wpq_domains',
	'wpq_questionnaires',
];

foreach ( $tables as $table ) {
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names come from the internal uninstall allow-list above.
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" );
}

delete_option( 'wpq_db_version' );
delete_option( 'wpq_delete_data_on_uninstall' );
delete_option( 'wpq_stripe_publishable_key' );
delete_option( 'wpq_stripe_secret_key' );
delete_option( 'wpq_stripe_webhook_secret' );
delete_option( 'wpq_claude_api_key' );
delete_option( 'wpq_claude_model' );
delete_option( 'wpq_claude_project_id' );

// Phase 1 legacy options — may exist on sites that ran an earlier build.
delete_option( 'wpq_halopsa_api_url' );
delete_option( 'wpq_halopsa_client_id' );
delete_option( 'wpq_halopsa_client_secret' );
delete_option( 'wpq_halopsa_prospect_type' );
delete_option( 'wpq_halopsa_field_score' );
delete_option( 'wpq_halopsa_field_grade' );
delete_option( 'wpq_halopsa_field_ref' );
delete_option( 'wpq_halopsa_field_status' );
