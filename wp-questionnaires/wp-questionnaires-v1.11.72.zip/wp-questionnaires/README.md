# WP Questionnaires

A generic WordPress assessment and lead-generation platform. Publishes scored questionnaires, captures lead data, optionally syncs to HaloPSA, and sells branded PDF reports via Stripe.

**CyberCheck (CS-01)** is the first seeded assessment product that ships with the plugin. The platform is designed to host multiple assessment products over time — WP Questionnaires is the platform; CyberCheck is a dataset that runs inside it.

---

## Requirements

| Dependency | Version |
|---|---|
| PHP | 8.1+ |
| WordPress | 6.4+ |
| Composer | Required for `vendor/` |

---

## Installation

1. Clone or unzip the plugin into `wp-content/plugins/wp-questionnaires/`.
2. Run `composer install` to install PHP dependencies (dompdf, etc.).
3. Activate the plugin from **WP Admin → Plugins**.
4. Activation creates all database tables and seeds the CS-01 CyberCheck questionnaire.

---

## Shortcodes

Place a questionnaire on any WordPress page or post:

```
[wpq_questionnaire ref="CS-01"]
[wpq_questionnaire ref="CS-01" show_pricing="false"]
```

Legacy aliases `[wpq_assessment]`, `[wpq_assessments]`, and `[wpq_product]` remain supported for existing content.

| Attribute | Default | Description |
|---|---|---|
| `ref` | (required) | Questionnaire reference code, e.g. `CS-01` |
| `show_pricing` | `true` | Whether to allow the paid product CTA after results. Products are still hidden unless checkout is explicitly enabled. |

Helper shortcodes for editorial copy:

| Shortcode | Returns |
|---|---|
| `[wpq_title ref="CS-01"]` | Questionnaire title |
| `[wpq_description ref="CS-01"]` | Questionnaire description |
| `[wpq_questions ref="CS-01"]` | Total question count |
| `[wpq_domains ref="CS-01"]` | Total domain count |
| `[wpq_time ref="CS-01"]` | Estimated completion time as a plain number |
| `[wpq_minutes ref="CS-01"]` | Alias for `[wpq_time]` |
| `[wpq_submissions ref="CS-01"]` | Non-deleted submission count |
| `[wpq_status ref="CS-01"]` | Questionnaire status |

---

## Admin screens

| Screen | Menu label | Purpose |
|---|---|---|
| Submissions | Questionnaires → Submissions | View and manage all assessment submissions. Filter by status, questionnaire, date, and payment state. |
| Contacts | Questionnaires → Contacts | Deduplicated contact records built from submission lead data. |
| Orders | Questionnaires → Orders | Paid report orders, Stripe payment status, and report download links. |
| Questionnaires | Questionnaires → Questionnaires | Manage the questionnaire library: publish, archive, duplicate, bulk-publish, and delete assessments. |
| Pricing | Questionnaires → Pricing | Products and pricing for paid PDF reports attached to questionnaires. |
| Coupons | Questionnaires → Coupons | Discount codes and promotional pricing rules. |
| Calls to Action | Questionnaires → Calls to Action | Rich-text category and domain CTAs injected into questionnaire results. |
| Readiness | Questionnaires → Readiness | Site health checks for plugin configuration (Stripe keys, HaloPSA, checkout gate). |
| Settings | Questionnaires → Settings | Plugin configuration: Stripe credentials, HaloPSA API, general options, and advanced/destructive settings. |
| Import / Export | Questionnaires → Import / Export | Bulk import or export questionnaire definitions as JSON. Supports single questionnaires and batch files. |

---

## Calls to action and remediation plans

The **Calls to Action** admin screen stores small rich-text CTA bodies. Category-wide CTAs appear below the key findings section after a customer completes a questionnaire. Domain CTAs are selected from the unique domains used by questionnaires in the selected category and are inserted after the matching domain recommendations. Result pages show at most three domain CTAs plus one category CTA.

AI remediation plans are configured in **Settings → AI**. Claude API keys are resolved in this order:

1. `WPQ_CLAUDE_API_KEY` constant.
2. `CLAUDE_API_KEY` or `ANTHROPIC_API_KEY` server environment variable.
3. WordPress option saved from Settings → AI.

When configured, completed questionnaire results show a **Download Remediation Plan** button for 30, 60, or 90 day plans. The plugin sends the customer, answer, scoring, and recommendation context to Claude, asks for structured remediation tasks, and then creates the returned workbook locally with `Planner` and `Tasklist` worksheets.

The Claude model setting defaults to `auto`. In this mode the plugin calls Anthropic's Models API and selects the newest available Sonnet model as the balanced cost/quality choice for remediation planning. If Sonnet is unavailable it falls back to Haiku, and Opus is only selected if no balanced model family is available. A specific model ID can still be entered manually when needed.

The optional Claude Project ID setting is stored for traceability and future Claude Project/Compliance integrations. The current direct Messages API workflow does not create visible Claude.ai Project chats or attach generated conversations to Claude.ai Projects; remediation plan history remains in WordPress submission/report records and the downloaded workbook.

---

## Questionnaire library and sample data

The plugin ships with a seeded CS-01 CyberCheck assessment. Additional questionnaires are loaded via **Import / Export**.

The `.sample_data/` directory in the source repository contains optional ready-to-import examples. These files are point-in-time demonstrations of what the plugin can support; they are not included in release ZIPs and are not automatically imported during plugin installation or upgrade.

| File | Contents |
|---|---|
| `ce-2026-danzell.json` | Cyber Essentials 2026 self-assessment (DANZELL v9.0, April 2026) |
| `wpq-import-batch-01.json` – `wpq-import-batch-06.json` | 150 generic questionnaires (QL-001 to QL-150), 25 per file |

Questionnaire refs follow the format `[A-Z]{2,6}-?\d{1,6}` — both `CS-01` and `CS01` are valid. Use the bulk **Publish** action in the Questionnaires screen to publish a batch of imported questionnaires at once.

---

## Stripe and paid reports

Phase 3 one-off paid report checkout is implemented but remains gated. Saving Stripe keys does not enable payments on the live site. Product CTAs are hidden from public results unless `WPQ_CHECKOUT_ENABLED` is explicitly set to `true` and every checkout capability check passes.

Phase 3 supports one-off Stripe Checkout payments only. Subscription products remain unsupported and are rejected by the checkout endpoint.

Stripe configuration is resolved centrally in this order:

1. Plugin constants: `WPQ_STRIPE_PUBLISHABLE_KEY`, `WPQ_STRIPE_SECRET_KEY`, `WPQ_STRIPE_WEBHOOK_SECRET`.
2. Server environment variables: `STRIPE_PUBLISHABLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`.
3. WordPress options saved from Settings → Stripe.

Production deployments should prefer constants or server environment variables for secret values.

REST endpoints:

| Endpoint | Purpose |
|---|---|
| `POST /wp-json/wpq/v1/checkout` | Creates a Stripe Checkout Session for a completed assessment. |
| `POST /wp-json/wpq/v1/stripe/webhook` | Verifies Stripe webhooks, logs payment events, transitions payment state, and generates paid reports. |
| `GET /wp-json/wpq/v1/reports/{id}?token=...` | Serves generated PDF reports after signed token validation. |

Security model:

- Checkout only works for completed assessments and active one-off products belonging to the same questionnaire.
- Payment is never marked as paid from the Stripe redirect URL.
- Only webhook-confirmed `checkout.session.completed` events can transition a submission from `pending` to `paid`.
- Webhook processing is idempotent through the unique Stripe event ID stored in `wpq_payment_events`.
- Reports are not exposed by numeric ID alone. Customer downloads require a signed, expiring report token stored server-side only as a hash.
- Report tokens default to five uses and expire after seven days.

---

## HaloPSA API

WP Questionnaires exposes authenticated REST endpoints so that an external HaloPSA integration tool can pull submission data from WordPress. No HaloPSA credentials are stored in WordPress.

**Setup:**
1. Create a dedicated WP user with the **WPQ HaloPSA API** role.
2. Generate an Application Password for that user.
3. Configure the HaloPSA integration tool with the site URL, username, and application password.

See **Settings → HaloPSA API** in WP Admin for the full endpoint reference and curl examples.

---

## Roles

| Role | Purpose |
|---|---|
| `wpq_halopsa` | Pull-only API access for the HaloPSA integration tool. No WP Admin access. |

The role is created on plugin activation and always removed on uninstall because it is an executable access artefact. Deactivating the plugin preserves the role so that re-activation restores full functionality without reconfiguration.

---

## Privacy and data retention

WP Questionnaires stores lead records (name, email, company, phone), assessment answers, scores, findings, and attribution data in custom database tables.

The public shortcode inherits the active theme font stack by default. The plugin does not enqueue Google Fonts or another third-party font provider.

On plugin deactivation, all data is preserved. On uninstall, the default behaviour is also to preserve all data.

To enable destructive cleanup on uninstall, go to **Settings → Advanced** and enable "Delete all data on uninstall". This option defaults to **off**. Without it set, deleting the plugin from WordPress leaves all business data intact.

**Back up your database before enabling this option.**

---

## Uninstall behaviour

| Data | Default (option off) | Option on |
|---|---|---|
| Rate-limit transients | Deleted | Deleted |
| Plugin database tables | Preserved | Dropped |
| WordPress options (keys, settings) | Preserved | Deleted |
| `wpq_halopsa` role | Removed | Removed |

---

## Release packaging

Use the **Release ZIP** GitHub Actions workflow in `.github/workflows/release.yml` for release artefacts. It runs the quality gates, installs production Composer dependencies, includes `vendor/`, keeps `composer.lock`, excludes CI/test/dev tooling, and uploads a versioned plugin ZIP. Keep `CHANGELOG.md` current with release version, DB version, migration notes, and compatibility notes.

Manual packaging should follow the same shape:

1. Run `composer install --no-dev --prefer-dist --no-interaction --no-progress --optimize-autoloader`.
2. Keep `composer.lock` in source and release artefacts for auditability.
3. Delete development artefacts: `tests/`, `.github/`, PHPUnit/PHPCS/PHPStan config files, `_archive/`, coverage, logs, and temporary build directories.
4. Zip the plugin directory as `wp-questionnaires-vX.Y.Z.zip`.
5. Upload to WP Admin or deploy via your release pipeline.

---

## Test strategy

The PHPStan WordPress stubs in `tests/phpstan-wordpress-stubs.php` exist only for static-analysis symbol discovery. They intentionally return safe defaults and should not be treated as runtime or integration coverage.

Default PHPUnit runs pure unit tests plus lightweight WordPress-stub workflow tests. Real WordPress behaviour is covered by the integration suite in `tests/integration/` via `phpunit.integration.xml.dist` with `WP_TESTS_DIR` pointing at the WordPress test suite. The CI `integration` job provisions a MySQL service, installs the WordPress test suite with `bin/install-wp-tests.sh`, and runs the suite automatically.

Integration coverage includes: role and capability creation, REST authentication (401/403/200) for HaloPSA endpoints, public endpoint payload validation (lead/submit/heartbeat/checkout), schema migration from older DB versions, report-token lifecycle (creation, max-uses, expiry, consumption), and Stripe webhook idempotency.

PHPStan level 3 is the current floor. Raise to level 5 in a follow-up pass.
