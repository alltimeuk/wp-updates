# Changelog

## 1.20.42 - 2026-08-26

DB version: unchanged (1.43.0).

### Fixed

- **Questionnaire Report DOCX could come out corrupt ("needs repair" in
  Word) whenever the template had a "Document History" table with
  Author/Publish Date content controls before any of this plugin's own
  `{{...}}` placeholders.** Root-caused from a real failed download
  (`wpq-questionnaire-report-225.docx`) by manually tokenising the raw
  `word/document.xml` and locating the exact byte where an `<w:sdtPr>`
  opened but was never closed, then confirmed with a standalone
  reproduction against the actual PhpOffice\PhpWord vendor code: its
  `TemplateProcessor::fixBrokenMacros()` runs unconditionally in the
  constructor (no hook to intervene afterwards) and treats any lone `{`
  not immediately followed by a second `{` as a Word-split macro opening,
  then scans forward for the next `>{` sequence and strips every XML tag
  in between via `strip_tags()`. A content control's
  `w:dataBinding w:storeItemID="{GUID}"` attribute - a completely
  ordinary Word feature, unrelated to this plugin's macros, and present
  on any Author/Date field a template author inserts from Word's own UI -
  satisfies that "lone `{`" trigger, and the next real `{{macro}}`
  anywhere later in the same document part satisfies the `>{` it scans
  for. Everything in between - the content control's own closing tags,
  table cells, paragraph boundaries - gets flattened into tag-less text,
  leaving unclosed `<w:sdt>`/`<w:tbl>` elements Word can no longer parse.
  Fixed by entity-encoding the braces in `w:storeItemID="{GUID}"`
  attributes (`WPQ_Docx_Template_Renderer::sanitise_template_for_processor()`)
  in a sanitised copy of the template before `TemplateProcessor` ever
  reads it - semantically identical to Word, invisible to
  `fixBrokenMacros()`'s regex. Added a second, independent backstop:
  `render()` now parses its own output's `word/document.xml` with
  `DOMDocument` before returning it and fails loudly
  (`docx_render_failed`) rather than shipping a malformed file, in case
  some other trigger of the same PHPWord defect surfaces later.
  Regression test reproduces the exact structure (a content control with
  a real `storeItemID` GUID ahead of the template's own macros) and
  asserts the output is well-formed XML with balanced `<w:sdt>`/`<w:tbl>`
  tags - it needs the `zip` PHP extension PHPWord's own writer requires,
  which this session's local PHP CLI doesn't have (a pre-existing,
  documented local-only gap - `RemediationTemplateValidationTest` already
  has the same constraint), so it's proven in CI, not locally.

## 1.20.41 - 2026-08-25

DB version: unchanged (1.43.0).

### Added

- **Readiness now reports whether `proc_open()` is even usable, before
  reporting whether a converter binary was found.** A live report on this
  session's host generated its DOCX successfully but then failed PDF
  conversion with "PDF converter is not available" - the existing
  diagnostic only says whether a LibreOffice/soffice binary was detected,
  which doesn't distinguish "nothing is installed" from "this host's PHP
  has proc_open() disabled entirely (a common shared-hosting hardening
  measure), so no local binary, however it gets installed, can ever run
  here." The new "PHP proc_open (required to run any local converter)"
  row in Settings -> Readiness answers that up front, so a portable/
  self-installed LibreOffice binary isn't chased on a host where it could
  never have worked.

## 1.20.40 - 2026-08-25

DB version: unchanged (1.43.0).

### Fixed

- **Submission detail: the Report/Remediation Plan cards and their Generate
  buttons were crossed.** After the 1.20.37 consolidation, the two status
  cards were ordered Remediation Plan (left) then Report (right), but the
  Generate buttons below them were ordered Generate Report (left) then
  Generate Remediation Plan (right) - a diagonal mismatch between each
  button and the card it controls. Reordered the cards to Report (left)
  then Remediation Plan (right) so both rows read left-to-right in the
  same order.

## 1.20.39 - 2026-08-25

DB version: unchanged (1.43.0).

### Fixed

- **Release ZIP workflow failed to build for 1.20.38: PHPStan doesn't
  know `number_format_i18n()`.** The new Readiness diagnostics row
  (added in 1.20.38) called `number_format_i18n()`, a real WordPress
  core function, but this project's PHPStan WordPress stub file doesn't
  declare it, so CI's static-analysis gate failed with
  `Function number_format_i18n not found` before the build step ever
  ran. Switched to plain `number_format()` - the value being formatted
  (max output tokens) isn't user-facing i18n content, so there's no
  behavioural loss. Root cause: PHPStan was never run locally this
  session, only PHPUnit and PHPCS, so this gap wasn't caught until CI
  ran it. PHPStan is now part of the standing pre-push checklist
  (`php -d error_reporting=8191 vendor/phpstan/phpstan/phpstan analyse
  --no-progress --memory-limit=1G` - the default 128M memory_limit
  crashes it).

## 1.20.38 - 2026-08-25

DB version: unchanged (1.43.0).

### Changed

- **Max output tokens is now an admin setting (Settings -> AI), not a
  fixed constant.** Both the remediation plan and the questionnaire
  report shared a hardcoded `REQUEST_MAX_TOKENS`/`REQUEST_TIMEOUT` pair
  in their own class - the exact 8000-token ceiling that caused every
  report failure this session was one of these. Replaced with one
  admin-configurable value (`WPQ_Remediation_Plan::get_max_tokens_preference()`,
  default 40,000, clamped 1,024-128,000 - the real ceiling for the
  currently configured model) shared by both call sites, the same way
  model selection already is. The request timeout is derived from this
  value automatically (`timeout_for_max_tokens()`) rather than being a
  second setting to keep in sync, so raising the ceiling also gives
  Claude enough wall-clock time to actually finish. Also added an
  explicit `stop_reason === 'max_tokens'` truncation check to the
  questionnaire report's own response handling, matching the remediation
  plan's existing one - a future truncation now logs a direct
  `questionnaire_report_truncated` event instead of only surfacing as an
  opaque "not valid JSON" failure. Surfaced in Settings -> Readiness
  alongside Model preference / Selected model.

## 1.20.37 - 2026-08-25

DB version: unchanged (1.43.0).

### Changed

- **Submission detail: Claude Analysis and Report are now one grouped
  summary, with both Generate buttons on one line.** Previously two
  separate cards with their own headings; now one card with a shared
  Claude-connection block up top and Remediation Plan / Report status
  side by side below it. The `claude_status` row was dropped from the
  connection block since every write site sets it identically to
  `ai_report_status`, which is now shown once, correctly labelled, under
  Remediation Plan. The two Generate actions sit in a single row in the
  order requested - Generate Report, plan-length dropdown, Generate
  Remediation Plan - each still its own form (they post to different
  handlers; the dropdown stays inside the plan's own form since it's a
  real parameter of that submission). Secondary actions (retry PDF,
  re-render, re-issue link, re-send email) remain a separate row below.

## 1.20.36 - 2026-08-25

DB version: unchanged (1.43.0).

### Fixed

- **Questionnaire Report analysis always failed with "response was not
  valid JSON."** Confirmed root cause via a live run: Claude's response
  hit exactly `REQUEST_MAX_TOKENS` (8000) with the text visibly cut off
  mid-sentence, before the JSON could close - a real report (executive
  summary, overall assessment, and per-domain findings/recommendations
  across up to 40 findings) routinely needs more than that. Raised to
  16000, matching `WPQ_Remediation_Plan`'s own proven ceiling for the
  same model (`claude-haiku-4-5-20251001`, whose real output-token cap is
  128000 per the Models API). Raised `REQUEST_TIMEOUT` from 120s to 240s
  in step: the truncated run generated 8000 tokens in ~82s, so a full
  16000-token response needs comfortably more than 120s to complete, and
  this call runs inside the WP-Cron job rather than the customer's own
  request, so the longer wall-clock time has no UX cost.

## 1.20.35 - 2026-08-25

DB version: unchanged (1.43.0).

### Changed

- **Log the template's actual parsed range and column order.** The
  row-position bug identified earlier this session (generated tasks
  landing at row 10 instead of row 2) was never root-caused - the
  investigation moved to the claim-query fix before it was resolved, and
  it's very likely also behind the column scrambling seen in the latest
  generated workbook (PHASE/ID and `%`/DESCRIPTION reading as swapped).
  `build_workbook_from_template()` now logs `remediation_template_parsed`
  with the exact `table_ref` (start/end row and column) and `columns`
  (the ordered header list) as read from the template's own XML, so the
  next generation gives ground truth directly rather than requiring the
  template's raw XML to be extracted and pasted in by hand again.

## 1.20.34 - 2026-08-25

DB version: unchanged (1.43.0).

### Fixed

- **The "Generate your assessment report" button disappeared while
  generating, unlike the remediation-plan button.** It now stays visible
  and disabled with a "Generating..." label during the run, matching the
  remediation button's own pattern, instead of vanishing and leaving only
  a text message to explain what's happening. Failed/partial states also
  now keep the button visible and retryable, rather than stranding the
  customer after a failure with no way to try again short of a refresh.

### Changed

- **Investigative logging for a stuck-at-"queued" report job.** The
  1.20.33 fix confirmed `questionnaire_report_claimed` now fires
  correctly, but the job can still sit at `qr_status: queued` with no
  `questionnaire_report_process_fired` ever appearing - meaning WP-Cron's
  handler is never actually invoked, despite both the immediate
  post-claim kick and the admin-page-view overdue sweep that exist
  specifically to work around `DISABLE_WP_CRON`. `WPQ_Cron_Kicker::kick()`
  now logs `cron_kick_dispatch_error` if the loopback `wp_remote_post()`
  call itself reports a `WP_Error` (the one failure mode a fire-and-forget
  request could otherwise hide entirely), and the overdue sweep logs
  `cron_kick_overdue_sweep` when it actually finds a ready job and kicks.
  This is deliberately exploratory, not a fix - the loopback's own
  construction mirrors WordPress core's `spawn_cron()` closely enough that
  changing it without evidence would be another guess, not a correction.

## 1.20.33 - 2026-08-25

DB version: unchanged (1.43.0).

### Fixed

- **Questionnaire Report generation could never claim a job - root cause
  of every "Generate your assessment report" failure this session.**
  `claim_questionnaire_report_job()`'s `$wpdb->prepare()` call binds
  placeholders by position, left to right through the SQL string - not
  by type. The SQL has four `%s` (the SET clause), then `%d` (`id`),
  then a run of `%s` for the `IN (...)` clause, but the values array put
  `$submission_id` *last*, after `$from_states`. Every claim attempt
  therefore evaluated `id = (int) 'not_requested'` (= `0`) with the real
  submission ID shifted into the `IN (...)` list as a string - matching
  no row, every time, for every submission. Reordered the array to match
  the placeholders' actual position in the string. This is the same
  claim mechanism `retry_pdf_conversion()` uses, so that path was
  affected identically.

  No new automated test accompanies this fix: proving it requires a real
  `$wpdb` executing the built SQL, which only the Integration test tier
  provides, and that tier doesn't run in this project's current CI
  (needs Linux/Docker/MySQL the self-hosted Windows runner can't
  provide; GitHub-hosted runners are billing-blocked). Tracked as a
  coverage gap rather than left silently unverified.

## 1.20.32 - 2026-08-25

DB version: unchanged (1.43.0).

### Changed

- **`questionnaire_report_claim_failed` now explains itself.** A live
  test showed the claim failing with `qr_status: "not_requested"` -
  already an allowed restartable state, so the bare status alone
  couldn't explain the failure. The claim UPDATE's WHERE clause also
  requires `deleted_at IS NULL`, and `$wpdb->query()` returns `false`
  (indistinguishable from "0 rows matched" by the existing bool check)
  on a genuine SQL error. The log now also carries `deleted_at`,
  whether a prior generation token already existed, and
  `$wpdb->last_error`, so the next occurrence identifies the actual
  cause instead of needing a further round of instrumentation.

## 1.20.31 - 2026-08-25

DB version: unchanged (1.43.0).

### Changed

- **End-to-end trace for Questionnaire Report generation, button press
  through download.** 1.20.30 covered the request/claim stage; this adds
  the rest of the pipeline to the same shared Claude debug log:
  `questionnaire_report_process_fired` (proves WP-Cron actually invoked
  the handler, and why it may have declined to proceed - previously
  indistinguishable from outside the database), `_context_built`,
  `_docx_ready`, `_pdf_failed`, `_completed`, `_delivered` /
  `_delivery_failed`, and `_downloaded` / `_download_denied` (with a
  reason) on the actual client download request. `fail()` itself now
  logs a `questionnaire_report_failed` event with stage/code/message,
  which covers every existing and future failure branch in `process()`
  for free rather than instrumenting each throw site separately. Routine
  status polling is deliberately not logged, to keep the 50-entry log
  from being crowded out by noise.

## 1.20.30 - 2026-08-25

DB version: unchanged (1.43.0).

### Changed

- **Questionnaire Report generation logs its full early lifecycle, not
  just one guard.** 1.20.27 logged only the `is_configured()` rejection;
  a submission whose `qr_status` never left `not_requested` after a
  customer click could still fail silently at three other points with no
  trace anywhere - `REPORT_DELIVERY_DISABLED` in the REST layer, or
  `request_generation()`'s own "already active" / "claim failed" returns,
  neither of which throws. All three now log to the same Claude debug
  log, plus a `questionnaire_report_claimed` event on the success path so
  a stuck-after-claiming job (a cron/loopback problem, not a config one)
  is distinguishable from never having been claimed at all.

## 1.20.29 - 2026-08-25

DB version: unchanged (1.43.0).

### Changed

- **Remediation workbook's PHASE column writes 1/2/3, not "30 Day"/"60
  Day"/"90 Day".** The day-count labels weren't meaningful on their own;
  the PHASE column now reuses the same `phase_number()` mapping the ID
  column already relies on for its "1.1"/"2.1"-style numbering.

## 1.20.28 - 2026-08-25

DB version: unchanged (1.43.0).

### Fixed

- **Results-screen action rows now align right, and the status line
  collapses when empty.** The actions row (button, or plan-length dropdown
  + button) already spanned the card's full width after the 1.20.26
  stacking fix, but its content sat left-aligned, leaving a large empty
  gap on the right. Right-aligned via `justify-content: flex-end`. The
  status line below it (e.g. "Generating your workbook...") is a separate
  row and already sat on its own line, but reserved a gap even with no
  message; it now collapses to zero height via `:empty` when there's
  nothing to show, and expands back as soon as JS populates it.

## 1.20.27 - 2026-08-24

DB version: unchanged (1.43.0).

### Fixed

- **Remediation plan generation failing with "TASKS table has no readable
  columns" on a genuine, valid template.** The table-column reader only
  matched self-closing `<tableColumn .../>` XML, but a `<tableColumn>` with
  a calculated-column formula (or simply re-saved by a tool that doesn't
  self-close empty elements) is legal, common OOXML that pairs its open and
  close tags instead. It now matches the opening tag regardless of how it
  closes. Added a regression test covering the non-self-closing case.

### Changed

- **Questionnaire Report "not configured" rejections are now logged.**
  `questionnaire_report_request()` returned `REPORT_NOT_CONFIGURED`
  silently - nothing was written anywhere, so a customer clicking "Generate
  your assessment report" and getting nothing visible left no trail to
  diagnose from. It now logs a `questionnaire_report_not_configured` event
  to the same Claude debug log as generation itself, recording which half
  of the check failed (the Claude API key, or the DOCX template library).

## 1.20.26 - 2026-08-24

DB version: unchanged (1.43.0).

### Fixed

- **Results-screen action cards no longer look squashed.** The assessment
  report and remediation plan cards forced a text/actions row layout that
  didn't have enough room at typical content-column widths, wrapping the
  heading and cramming the description into a narrow column. Both cards
  now stack full-width (heading and description on top, actions below),
  matching the other results-screen cards. This also lets the remediation
  plan's length dropdown and button sit in one natural row again, since
  they're no longer squeezed into a narrow right-hand column.

## 1.20.25 - 2026-08-24

DB version: unchanged (1.43.0).

### Fixed

- **Radio/checkbox answer clicks no longer misfire on a small mouse drag.**
  `.wpq-radio-label` and `.wpq-checkbox-label` wrap their option text in a
  plain `<label>`, which browsers make text-selectable by default (unlike
  the `<button>` tiles used for yes/no/partial questions, which already
  block this). A few pixels of movement between mousedown and mouseup -
  common with trackpads or an imprecise mouse - was being read as a
  text-selection drag instead of a click. Added `user-select: none` to
  both labels, matching the existing `.wpq-tip-icon` pattern.

## 1.20.24 - 2026-08-24

DB version: unchanged (1.43.0).

### Fixed

- **Key Findings items no longer render as a checkmark list.** The results
  screen built its list of findings as `<ul><li>`, which the site's global
  theme CSS turns into a tick-mark bullet on every `<li>` - making critical
  and high-severity findings look like positive confirmations instead of
  problems needing attention. The list is now built from plain `<div>`
  elements (`role="list"`/`role="listitem"` preserve the same screen-reader
  semantics), keeping the existing vertical stacking with no visual bullet
  of any kind.

## 1.20.23 - 2026-08-24

DB version: unchanged (1.43.0).

### Fixed

- **Results-screen action cards no longer wrap unevenly.** The remediation
  plan card's "Plan length" dropdown and its Generate button could wrap onto
  separate lines depending on viewport width, while the assessment report
  card's single button never did - making the two matched cards look
  inconsistent. The plan-length label and dropdown are now grouped as one
  unit, and both cards' action areas are always a right-aligned vertical
  stack instead of an unpredictable wrap.

## 1.20.22 - 2026-08-23

DB version: unchanged (1.43.0).

### Changed

- **Replaced 11 `unlink()` calls with `wp_delete_file()`** across
  `class-wpq-questionnaire-style-generator.php`,
  `class-wpq-docx-template-renderer.php`,
  `class-wpq-libreoffice-pdf-converter.php`,
  `class-wpq-questionnaire-report-storage.php`,
  `class-wpq-questionnaire-report.php` (x2),
  `class-wpq-remediation-plan.php` (x2), `uninstall.php`, and
  `admin/class-wpq-admin.php`. `wp_delete_file()` is WordPress core's own
  thin wrapper - same effect, and it already suppresses errors internally,
  so this also removes now-redundant `@` suppressions and one
  `phpcs:ignore` comment. Every site was fire-and-forget cleanup whose
  return value was never checked, so this is a pure drop-in swap - no
  behaviour change. Added a `wp_delete_file()` stub to the test bootstrap.
  Prompted by the first batch of ERROR-level findings from a WordPress.org
  Plugin Check pass - most of that report's findings turned out to be
  either never-shipped files (tests/, bin/, `.sample_data/`, a stray local
  `build/` copy) or deliberate design choices (proprietary license, the
  self-hosted updater, Cloudflare Turnstile) rather than real fixes; this
  is the first of the genuinely-real subset.

## 1.20.21 - 2026-08-23

DB version: **1.43.0** (new nullable `wpq_submissions.remediation_last_generated_at` column).

### Changed

- **Results-screen card headings and remediation-plan button copy.** "Your
  assessment report" → "Get your assessment report"; "Download your
  remediation plan" → "Get your remediation plan"; the remediation-plan
  button now reads "Generate your Remediation Plan" before a plan has been
  produced, and **"Download your Remediation Plan"** afterwards.
- **The remediation-plan button's Generate/Download state now survives a
  page refresh.** The plan itself is still generated fresh on every click
  (never stored) - the new `remediation_last_generated_at` timestamp is
  purely a "has one been made before" signal, set whenever
  `POST /remediation-plan` succeeds and returned via `/submit` and
  `/resume` as `remediation_plan_generated`, so the button shows the right
  label immediately on restore instead of always starting at "Generate."
- **Added a shared note below both result cards** explaining reports/plans
  take a little time, survive a refresh, arrive by email as a fallback, and
  are held for 30 days before removal - shown only when at least one of the
  two cards is actually visible.
- **Fixed another silently-swallowed exception**: `download_remediation_plan()`
  discarded generation failures with no logging at all, unlike the
  Questionnaire Report path fixed in 1.20.16. It now logs via
  `WPQ_Database::log_error()` (gated behind `WP_DEBUG_LOG`) like everywhere
  else.

## 1.20.20 - 2026-08-23

DB version: unchanged (1.42.0).

### Changed

- **Questionnaire Report generation is now customer-initiated, not a silent
  background trigger.** Previously, submitting an assessment auto-fired report
  generation server-side; any failure to queue it (a thrown exception in
  `start_questionnaire_report_delivery()`) was silently discarded, and the
  results screen's status endpoint had a deliberate fudge that reported
  `not_requested` submissions as `generating` - to avoid telling a customer to
  keep waiting for a report nothing would ever produce, it instead told them
  to keep waiting for a report **nothing had ever started**, indefinitely,
  with no recovery path. The results screen now shows a **"Generate your
  assessment report"** button (matching the remediation plan card's style -
  new shared `.wpq-result-card` CSS classes replace the plan-specific ones so
  both cards look and behave identically); clicking it calls the new
  `POST /questionnaire-report-request/{id}` endpoint, which performs the same
  checks the admin's manual "Generate Report" button already did and returns
  a real, visible error if it can't start - no more silent swallowing. Once
  running, the existing polling takes over and the button becomes a
  **"Download your assessment report"** link when ready, or reports having
  been emailed. A `failed` or `partial` prior run now also offers the same
  button as a "try again" action rather than a blank status line.
- **Equalised the two results-screen action cards' visual weight** as part of
  the above: the remediation-plan and Questionnaire Report cards now share
  identical box, heading, and button styling.

## 1.20.19 - 2026-08-23

DB version: unchanged (1.42.0).

### Fixed

- **Equalised the lead-form checkbox styling.** The optional marketing-consent
  checkbox rendered in a visibly lighter/muted colour than the required
  privacy-notice checkbox above it (`assessment.css`'s
  `.wpq-consent-row-optional` override) - a deliberate de-emphasis at the
  time, but it read as an inconsistency rather than a signal. Both checkboxes
  now render with the same text colour and weight.

## 1.20.18 - 2026-08-22

DB version: unchanged (1.42.0).

### Added

- **Reviewed and expanded the marketing-distribution-lists planning sketch**
  (`.roadmap/distribution-lists/PLAN.md`, drafted in the sibling
  `halopsa-wp-contacts-sync` repo). No code, schema, or behaviour change - this
  adds three open questions the original draft didn't cover (sync-loop
  prevention between the Halo-push and Halo-pull directions, which consent
  event a Halo-originated unsubscribe should map to, and unsubscribe-token
  binding against link-leak exposure) plus an explicit acknowledgement of the
  operational cost of a third sibling plugin, ahead of any real schema/ADR
  work on this feature.

## 1.20.17 - 2026-08-20

DB version: unchanged (1.42.0).

### Fixed

- **Fixed the release build for real this time**: 1.20.16 repeated the exact
  version-tracking mistake it was meant to fix - the sample export's
  `plugin_version` got bumped to match the *pending* version instead of the
  one actually shipped, because the version bump in `wp-questionnaires.php`
  happened after the last local test run rather than before it. Both
  releases' CI and Release ZIP builds failed at the PHPUnit step as a
  result; neither produced a ZIP or reached wp-updates, so no customer saw
  either. Bumped `.sample_data/`'s `plugin_version` to `1.20.17` and, this
  time, ran the full suite *after* the version bump before tagging.

## 1.20.16 - 2026-08-20

DB version: unchanged (1.42.0).

### Fixed

- **Documented the safety of three dynamically-built SQL queries flagged by
  the WordPress.org Plugin Check tool.** `WPQ_Contact_Admin::list_contacts()`,
  `::count_contacts()`, and `WPQ_Database::get_questionnaire_list()` build
  `$sql` from static fragments plus `$wpdb->prefix` and a `$where` clause
  built entirely from `%s`/`%d` placeholders (or, in the database.php case,
  a `$where` that's already the output of `$wpdb->prepare()`) - every
  user-controlled value reaches the database through bound parameters, never
  string concatenation. Extended the existing
  `phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared` comments to also cover
  `PluginCheck.Security.DirectDB.UnescapedDBParameter`, which flags variables
  like this without tracing the prepare-then-execute flow. No behaviour
  change.
- **Gated all `error_log()` calls behind `WP_DEBUG_LOG`.** The plugin
  previously wrote to the PHP error log unconditionally - on every Stripe
  API failure, DB insert failure, Claude/report-generation failure, and
  cron retry - on every site running it, regardless of whether the site
  owner wanted that. Added `WPQ_Database::log_error()`, the sole remaining
  `error_log()` call site, gated behind `WP_DEBUG_LOG` per WordPress
  convention; routed all 18 call sites across `admin/class-wpq-admin.php`,
  `includes/class-wpq-database.php`, and `public/class-wpq-rest-api.php`
  through it. Silences the Plugin Check tool's
  `WordPress.PHP.DevelopmentFunctions.error_log_error_log` warning.
  **Behaviour change:** sites without `WP_DEBUG_LOG` enabled will no longer
  see these errors in their PHP error log - enable it to restore the
  previous visibility.
- **Fixed a version-tracking gap in the 1.20.15 release**: the
  `.sample_data/` sample questionnaire export's embedded `plugin_version`
  wasn't bumped alongside `WPQ_VERSION`, which the test suite catches
  (`SecurityWorkflowTest::test_sample_questionnaire_export_metadata_is_current`)
  but which slipped through because that specific test wasn't run before
  tagging. CI for v1.20.15 will show this as a red run; harmless, and fixed
  here.

## 1.20.15 - 2026-08-20

DB version: unchanged (1.42.0).

### Fixed

- **Simplified the direct-file-access guard in the contact-master domain.**
  The 10 files under `includes/contacts/` plus
  `includes/class-wpq-remediation-delivery.php` guarded against direct
  access with `! defined( 'ABSPATH' ) && ! defined( 'WPQ_TESTING' )`
  instead of the plain `! defined( 'ABSPATH' )` check every other file in
  the plugin uses. The `WPQ_TESTING` half was dead weight -
  `tests/bootstrap.php` already defines `ABSPATH` itself before requiring
  any plugin file, so the compound condition never changed behaviour in
  production or under the test suite. It did, however, trip the
  WordPress.org Plugin Check tool's `missing_direct_file_access_protection`
  rule, which doesn't recognise the compound form. Switched all 10 files
  to the standard guard for consistency; confirmed via `phpunit` (534
  tests, no new failures) and `phpcs --no-cache` (clean).

## 1.20.14 - 2026-08-18

DB version: unchanged (1.42.0).

### Added

- **Explicit marketing-consent opt-in on the lead-capture form.** A new,
  unchecked-by-default checkbox - separate from the existing required
  privacy-notice consent - lets a customer explicitly grant permission
  to be contacted about services and offers, with a plain-English
  reassurance that their details are never shared with third parties.
  Deliberately optional and never gates starting the assessment: the
  plugin's own canonical consent model already treats direct-marketing
  consent as legally distinct from service-delivery consent (see the
  enquiry form's existing `service_delivery` grant, and the roadmap's
  explicit "never infer marketing consent from an interaction" rule) -
  bundling it as a condition of taking the assessment would risk not
  being "freely given" consent under GDPR. When checked, a
  `direct_marketing_email` / `granted` consent event is recorded against
  the canonical contact (mirroring the enquiry form's existing
  `record_consent_event()` pattern exactly); leaving it unchecked writes
  nothing - the absence of a granted event is itself the correct "not
  consented" state, so there is no "declined" event logged for every
  visitor who simply didn't opt in. Verified end-to-end against the real
  local WordPress environment via WP-CLI: checked → a `granted` event
  and a projected `granted` preference state; unchecked → zero events
  written.

## 1.20.13 - 2026-08-18

DB version: unchanged (1.42.0).

### Added

- **Save & resume now genuinely covers completion, not just mid-assessment
  progress.** Refreshing the results page (or closing the tab and coming
  back) used to lose everything - the client cleared its local progress
  record on completion and the server explicitly rejected resuming a
  completed submission (`ALREADY_COMPLETED`), so there was no way back to
  a customer's own results short of an emailed report-delivery link, if
  one was even configured. The same-device resume path
  (`POST /wpq/v1/resume` with `submission_id`/`session_token`) now
  restores a completed submission's exact original results screen
  instead of erroring - rebuilt from the submission's stored scoring
  snapshot (`WPQ_Scoring::build_micro_report_from_submission()`), not a
  re-score, so it can never silently drift if the questionnaire is
  edited after the customer finished. A job already in flight, or a
  submission with an already-generated report, still surfaces correctly
  even if report generation is unconfigured afterwards. Verified against
  the real local WordPress environment via WP-CLI, not just the test
  stub. The emailed-resume-link path is unchanged for now (still shows
  "already completed").

## 1.20.12 - 2026-08-18

DB version: unchanged (1.42.0).

### Fixed

- **A fresh or unconfigured site could show a "Your assessment report"
  section on the results screen with an empty message and no button -
  for a report that could never actually be generated.** The one-time
  activation backfill (1.20.7) defaults the delivery-channel option to
  `results_link` independently of whether report generation itself is
  configured (Claude/analysis key, DOCX renderer). The results-screen
  section's visibility was driven purely by "is a delivery channel
  enabled", not "is generation actually possible", so any site with the
  default channel but no Claude key showed a heading with nothing
  useful under it. `state_for_submission()` now also hides the section
  entirely when generation was never configured and nothing has ever
  run or completed for that submission - a job already in flight, or a
  submission with an already-generated report, still surfaces normally
  even if generation is unconfigured afterwards.

## 1.20.11 - 2026-08-18

DB version: unchanged (1.42.0).

### Fixed

- **A finding card's domain label (top-right of each Key Findings card
  on the results screen) could run past the card's right edge instead
  of wrapping, for long domain names.** `.wpq-finding-domain` sits in a
  `display:flex` header row and is pushed right via `margin-left:auto`;
  as a flex item it had no explicit `min-width`, which some browser/font
  combinations can use as license not to shrink text below its
  preferred one-line width. Reproduced with the real CSS in isolation
  and couldn't force an overflow in Chromium at any tested width, so
  this is a defensive hardening rather than a confirmed single root
  cause: `.wpq-finding-domain` now sets `min-width: 0`, `max-width:
  100%`, and `overflow-wrap: break-word`, and `.wpq-finding-header`
  gets `flex-wrap: wrap` (with `.wpq-finding-label` pinned via
  `flex-shrink: 0`) as a second line of defence if the domain label
  ever can't fit beside the severity label on one line.

## 1.20.10 - 2026-08-18

DB version: unchanged (1.42.0).

### Fixed

- **The Readiness tab's status banner ("Review recommended" / "Action
  required" / "All checks passed") floated up next to the page title,
  fully visible, regardless of which Settings tab was actually active.**
  WordPress core's admin JS relocates any `.notice` element to right
  after the page `<h1>` unless it carries the `inline` class, which
  opts a notice out of that relocation - every other custom notice on
  the Settings page already used `notice ... inline`, but the three
  status banners in `page-readiness.php` didn't, so core's JS pulled
  them out of the `wpq-hidden`-wrapped Readiness tab panel and dropped
  them beside the title on every tab. Added the missing `inline` class
  so the banner now only renders where the Readiness tab actually
  displays it.

## 1.20.9 - 2026-08-17

DB version: unchanged (1.42.0).

### Fixed

- **"Generate report" could hand the admin a raw HTTP 500 instead of a
  friendly error.** `handle_generate_questionnaire_report()` only wrapped
  the final `request_generation()` call in a `try/catch(Throwable)` - the
  preceding submission/questionnaire lookups and config checks ran
  unguarded. Any exception thrown there bubbled all the way up uncaught.
  The whole request-generation path (from the submission lookup onward) is
  now inside one try/catch, so any Throwable degrades to a logged,
  graceful redirect back to the submission with an error flag, the same
  way a failure inside `request_generation()` itself already did. The
  error log entry now also includes the file and line the exception was
  thrown from, to speed up diagnosing whatever trips it next.
- **The results screen could tell a customer "your report is being
  prepared" forever for a report that was never actually queued.** The
  customer-facing auto-trigger (`start_questionnaire_report_delivery()`,
  fired the moment an assessment completes) called
  `WPQ_Questionnaire_Report::request_generation()` unconditionally, unlike
  the admin manual-trigger which already checks `is_configured()` first.
  When generation isn't configured (Claude/analysis or the DOCX renderer
  library unavailable), the call was a no-op and `qr_status` stayed
  `not_requested` - a state `WPQ_Questionnaire_Report_Delivery::state_for_submission()`
  displayed identically to a genuinely in-progress job, so the page kept
  polling and promising a report that nothing would ever produce. Both
  are fixed: the auto-trigger now checks `is_configured()` before
  claiming/scheduling a job (mirroring the admin path), and
  `not_requested` only renders as "generating" when a run is actually
  possible - otherwise it falls through to the existing "could not be
  prepared automatically" message.

## 1.20.8 - 2026-08-17

DB version: unchanged (1.42.0).

### Fixed

- **A queued report that the loopback kick never reached could sit at
  "being prepared" forever.** The customer's own results-screen poll
  (every 5s while generating) now doubles as a retry: if a job is still
  queued and no worker has ever picked it up (`qr_last_attempt_at` never
  set) more than a few seconds after it was requested, the poll fires a
  fresh loopback kick itself, instead of trusting the original one-shot
  kick to have landed. Genuinely in-progress jobs (a worker has already
  attempted them) and freshly-queued jobs (too soon to conclude anything)
  are left alone.
- **Test suite gap**: `WPQ_Cron_Kicker` was never loaded in the PHPUnit
  bootstrap, so every test touching a code path that kicks the loopback
  (report generation, retry, re-render - since 1.16.0) silently exercised
  a no-op stand-in the whole time. Fixed, plus the bootstrap's
  `add_query_arg()` stub now supports both of core's calling conventions
  (the array form, and the `(key, value, url)` form `WPQ_Cron_Kicker`
  uses) rather than only the former.


## 1.20.7 - 2026-08-17

DB version: bumped to 1.42.0 (one-time option backfill, no schema change).

### Changed

- **Questionnaire Report delivery now defaults to on.** A site that has
  never explicitly chosen a delivery channel gets "Secure link on the
  results screen" enabled automatically on upgrade - enabling report
  generation now actually reaches a customer out of the box, instead of
  requiring a second, easy-to-miss trip to Settings -> AI first (the gap
  the 1.20.4 Readiness warning surfaces). One-time only: an admin's later
  deliberate choice to disable every channel is never re-overridden by a
  subsequent upgrade.


## 1.20.6 - 2026-08-17

DB version: unchanged (1.41.0).

### Changed

- **Readiness moved from its own top-level page into a Settings tab**
  (Settings -> Readiness), matching every other operational check the
  plugin surfaces. Old bookmarks/links to the standalone page redirect
  automatically; internal links (cron retry/cancel, contact migration)
  updated to the new location.
- **Submissions table Contact column narrowed** (~40%) - it had absorbed
  the space freed by the 1.20.5 width fix and read too wide for its
  content.


## 1.20.5 - 2026-08-17

DB version: unchanged (1.41.0).

### Fixed

- **Submissions table column widths corrected.** The 1.16.0 width fix left
  both Assessment and Contact unconstrained; under the list-table's
  "fixed" layout, an unconstrained column gets an equal share of remaining
  space regardless of content, so Assessment (a short badge and name)
  absorbed as much room as Contact while Ref and Date were sized too
  narrow for their own content, wrapping the reference code and the date
  apart. Every column now has a width sized to its real content (Ref and
  Date on a single line); Contact is the one column deliberately left
  unconstrained, so it alone receives the space that frees up. Verified by
  rendering the real admin.css against the actual column markup.


## 1.20.4 - 2026-08-17

DB version: unchanged (1.41.0).

### Added

- **Readiness now flags "report generation enabled with no delivery
  channel configured".** "Report generation: Enabled" controls whether the
  backend produces a DOCX/PDF at all; "delivery channels" (Settings -> AI)
  separately control whether the customer is ever shown a way to reach it.
  With generation on but no channel enabled, reports were generated (and
  billed for, on Claude) with nothing on the results screen, post-checkout
  screen, or in an email ever pointing at them - a silent combination
  since neither setting alone looks broken.

### Fixed

- **The questionnaire structure REST endpoint (`GET /questionnaire/{ref}`)
  now sends explicit no-cache headers.** It previously relied on
  WordPress's own REST defaults; on a host with an aggressive edge/page
  cache that caches by URL pattern regardless of REST semantics, an admin
  edit (reordered answer options, changed wording, a new grade threshold)
  could keep serving the pre-edit structure to customers after saving.

### Verified, no code change

- **Answer-option reordering (the ↑/↓ Move buttons) works correctly** -
  confirmed by executing the real admin.js in a browser and clicking the
  buttons: DOM order, the collected save payload, and persisted
  `sort_order` all update as expected on save and reload.


## 1.20.3 - 2026-08-17

DB version: unchanged (1.41.0).

### Fixed

- **Remediation plan XLSX wrote task data into the wrong columns against a
  custom template (and left stale template rows in place on older
  installs).** The generator assumed every uploaded template's TASKS table
  has a fixed 10-column layout (`PHASE, ID, TASK, RESOURCE, START DATE,
  EFFORT, END DATE, STATUS, %, DESCRIPTION`) and wrote values into columns by
  hardcoded position. A real 12-column template (adding `PRIORITY` and
  `DOMAIN`, renaming `RESOURCE`, adding `TODO`) silently shifted every
  column: PRIORITY got TASK's text, TASK went blank, DOMAIN got a date
  serial, START DATE got EFFORT's day-count, and so on - confirmed
  reproducing exactly this corruption against a real customer template.
  Column mapping is now resolved from the template's own `<tableColumn>`
  names at generation time (`table_columns()`), so any column set, order,
  or extra column (like `TODO`, correctly left blank rather than guessed at)
  is followed as authored, instead of assumed.
- **"Start again" on the results screen no longer leaves the visitor
  scrolled down at a blank lead form.** Restarting now scrolls back to the
  top of the questionnaire.


## 1.20.2 - 2026-08-17

DB version: unchanged (1.41.0).

### Fixed

- **Paid-report storage diagnostics no longer misreport a fresh install.**
  `WPQ_Report_Renderer::storage_diagnostics()` probed with `$ensure=false`,
  so a never-yet-used `reports/` directory (the paid HTML/Dompdf report's
  own storage, separate from the Questionnaire Report's docx/pdf storage
  fixed in 1.16.0) always read as "not writable" on the Readiness page even
  though the render path creates it fine on first real use.


## 1.20.1 - 2026-08-16

DB version: unchanged (1.41.0).

### Fixed

- **Results screen crashed with "el.className.replace is not a function"
  when submitting an assessment.** The applyGradeClass/applyPercentClass
  helpers (introduced in the 1.12.0 CSP refactor) string-assigned
  el.className, which works on HTML elements but throws on the SVG
  score-ring circles, where className is an SVGAnimatedString object -
  killing the entire results render on "See my results". The helpers now
  use classList exclusively; verified against a real SVG element in
  Chromium, and a test pin forbids className.replace from reappearing in
  assessment.js.


## 1.20.0 - 2026-08-16

DB version: unchanged (1.41.0).

### Changed

- **Version realignment to 1.20.0.** No functional changes over 1.17.0 -
  the minor version jumps to align with the wider product versioning
  scheme. Supersedes and retracts the mistakenly numbered 2.20.0 release
  (published briefly on 2026-08-16, functionally identical); the 2.x tag
  and release have been withdrawn so the update feed continues on 1.x.

## 1.17.0 - 2026-08-16

DB version: unchanged (1.41.0).

### Added

- **Framework readiness radar.** A colour-coded spider chart of the
  customer's relative position against each compliance framework enabled on
  the questionnaire, drawn deterministically from the framework assessments
  already stored in the report analysis (zero extra Claude calls). One spoke
  per framework; radius is the readiness position (explicit
  readiness_percent where the standard's methodology yields one, otherwise
  derived from cited control strengths vs gaps, otherwise the readiness
  level band - derived values are marked "≈"/indicative); colour is the
  readiness level (green aligned, amber partially, red not aligned, grey
  insufficient evidence). Fewer than three frameworks fall back to
  colour-coded bars. Surfaced in four places from one renderer
  (`WPQ_Framework_Radar`):
  - **Admin submission detail** - inline SVG card under the Report panel.
  - **Customer DOCX report** - new optional `{{framework_radar}}` image
    macro (GD-drawn PNG; templates without the macro are untouched; the
    macro is blanked when there is nothing to draw). The template renderer
    gained general optional-image support.
  - **Dompdf HTML/PDF report** - a Framework Readiness section with the
    chart embedded as a data URI plus a readiness table. The html_dompdf
    fallback path now also runs the framework readiness assessment (it
    previously bypassed the analyse stage entirely, so html_dompdf sites
    never assessed frameworks at all) and stores it in qr_analysis_json.
  - **Customer results screen** - server-rendered SVG delivered through the
    report-status payload and injected CSP-safely (presentation attributes
    only, no inline styles or scripts).


## 1.16.2 - 2026-08-16

DB version: unchanged (1.41.0).

### Changed

- **Results findings restyled as a formal report.** The findings list was a
  dense stack of tinted rows: 10px padding, 8px gaps, and each finding's
  narrative + recommendation squashed into one paragraph. Now: white cards
  with a severity accent edge and subtle shadow, generous padding and
  spacing, a proper hierarchy (severity/domain header rule, larger question
  heading, italic "You answered" line), body text at a readable measure
  (72ch, 1.65 line height) - and the embedded "Recommendation:" sentence is
  split out into its own labelled block. Text without the marker renders
  unchanged.


## 1.16.1 - 2026-08-16

DB version: unchanged (1.41.0).

### Fixed

- **Marketing opt-out toggle restored to the canonical contact view.** The
  1.16.0 inline GDPR panel carried Export/Anonymise/Delete but left the
  fourth control of the legacy widget - the marketing opt-out toggle - one
  click away on the legacy email view. It now sits inline per email identity
  too (same AJAX handler and nonce as the legacy view), with an "Opted out"
  badge on identities that are suppressed, completing the button set.


## 1.16.0 - 2026-08-16

DB version: unchanged (1.41.0).

### Fixed

- **Admin "Generate Report" no longer returns HTTP 500 on managed hosts.**
  The admin handlers previously ran the full Claude analysis + DOCX/PDF
  render inline inside the admin-post request; on managed containers the
  gateway kills long requests (~60s), handing the admin an HTTP 500 with
  nothing in the PHP error log while the redirect never sends. Generation,
  re-render, PDF retry, and the backlog Retry action now queue the job and
  fire it immediately in a separate background request via the new cron
  kicker, then redirect straight away ("queued and started - refresh").
- **Report storage diagnostics no longer misreport a fresh install.** The
  Readiness probe refused to create the questionnaire-reports docx/pdf
  directories (`$ensure=false`) and then flagged the not-yet-existing
  directories as "not writable", surfacing a false permissions alarm in the
  banner. Diagnostics now ensure the directories exist - the same idempotent
  creation generation performs on first use, access guards included - so the
  panel reflects what a real run will encounter and the banner only fires on
  genuine failures. No server-side chmod/chown was ever needed.
- **GDPR actions are reachable from the canonical contact view.** The
  "Privacy actions" section previously linked to the legacy contacts list,
  which has no export/anonymise/delete controls - a dead end. The canonical
  contact detail now carries the GDPR Data Subject Rights panel inline (one
  block per email identity, posting to the same nonce-checked handlers as the
  legacy email view), plus a link to each identity's full email history. The
  canonical contacts list now also renders the anonymised/deleted result
  notices those handlers redirect back with.

### Changed

- **WP-Cron self-sufficiency on hosts without a system cron.** New
  `WPQ_Cron_Kicker`: every report job schedule fires a non-blocking loopback
  POST to wp-cron.php immediately (`spawn_cron` semantics, deliberately
  ignoring DISABLE_WP_CRON, which only suppresses core auto-spawning), and a
  once-a-minute throttled sweep on admin page views kicks any overdue
  scheduled events - covering retention automation and contact-migration
  batches. The Readiness cron panel wording now reflects this instead of
  demanding a crontab the container cannot provide.
- **Canonical contact detail restored to the two-column card layout** (main
  record left, actions right) in place of the vertically stacked tables.
- **Submissions list: Remediation column removed** - the Generate/Download
  remediation-plan actions live on the submission detail page. Narrow data
  columns now have fixed widths so Contact/Assessment get the freed space,
  and the contact email no longer wraps on wide screens.


## 1.15.1 - 2026-08-16

DB version: unchanged (1.41.0).

### Fixed

- **Unwritable report storage now reaches the Readiness banner.** The top
  banner previously flagged only the HaloPSA role while questionnaire-report
  DOCX/PDF storage being unwritable - which silently fails every generation
  run at the store step - sat as a row deep in its panel. Storage
  availability/writability problems now aggregate into the banner with the
  affected path and the consequence spelled out.

## 1.15.0 - 2026-08-15

DB version: unchanged (1.41.0).

### Added

- **Shared canonical contacts with wp-reconnaissance.** When
  wp-reconnaissance is active, `WPQ_Customer_Platform_Bridge` publishes this
  plugin's canonical contact service on recon's
  `alltime_customer_platform_contact_service` discovery hook (filter
  priority 1, deterministically beating recon's default-10 self-provide), so
  both products resolve ONE canonical contact in the wpq_* tables - the
  richer model and the one HaloPSA reconciles against. A contact then holds
  many questionnaire submissions and many reconnaissance reports. The
  interface-implementing adapter is loaded only after an
  `interface_exists()` probe, so neither plugin hard-depends on the other.
  Component inventory and merge decisions: `.roadmap/shared-components.md`.
  (Originally landed and reverted during 1.14.0 development; restored here.)

## 1.14.0 - 2026-08-15

DB version: unchanged (1.41.0).

### Added

- **wp-cron.php reachability probe** on the Readiness screen's Cron & Task
  Processing panel - an active HTTP check (cached 10 minutes) replacing the
  previous "not checked automatically" note. An unreachable endpoint
  (staging basic-auth, firewalled loopback, broken local TLS) is the common
  silent cause of report jobs stuck at "queued".
- **Re-render from Stored Analysis** on the submission screen (AC17):
  rebuilds the Questionnaire Report DOCX/PDF from the persisted
  `qr_analysis_json` against the questionnaire's current template with **no
  Claude call** - a template refresh no longer changes report content or
  spends API tokens. Delivery e-mail stays idempotent.
- **Admin recovery tooling** closing four Phase 3 deferred-backlog items:
  issue a fresh customer download link after token expiry/exhaustion
  (purpose-scoped, displayed once, never stored in plain text); re-send the
  report delivery e-mail with a fresh link; regenerate the paid HTML/Dompdf
  report through the same path the webhook uses; and replay a stored,
  never-completed Stripe webhook event through the idempotent handler.
- **Retention automation** (Settings → Advanced, explicit opt-in): the
  existing purge/anonymise thresholds now also run on a daily WP-Cron
  schedule, with an audit-log entry for every run that touches rows.
- **Admin mutation audit logging**: contact anonymise/delete, abandoned-
  submission purge, and old-submission anonymise now write to
  `wpq_audit_log` (counts and thresholds only - never the contact's email,
  which must not outlive the very anonymisation the row documents).
- **Declarative REST request schemas** on every public write endpoint
  (lead, heartbeat, submit, checkout, resume-link, resume, enquiry) so
  malformed types get a structured 400 before the handler; handlers keep
  their own validation as defence in depth.

### Changed

- **GDPR flows are now transactional**: contact merge, contact anonymise,
  and contact hard-delete each run inside a single database transaction, so
  a mid-flight failure can no longer leave a half-applied privacy action.
  File artefact deletions stay outside (they cannot roll back; removing
  them first is the privacy-safe direction).
- **Release pipeline**: the GitHub Release is now created only after the
  wp-updates Pages feed deploys (closing the window where a release existed
  while update.json still advertised the previous version), and re-running
  the workflow for an existing tag updates its assets instead of failing.
  Package sha256 verification already existed in `WPQ_Updater` and the
  update feed; `.roadmap/auto-updates.md`'s hardening list predated it.
- PHPStan gate measured at levels 4/5 (135 findings, ~96 of them artifacts
  of the deliberately simplified WordPress analysis stubs) and held at
  level 3; raising the gate now depends on stub-fidelity work, not code
  fixes.

## 1.13.0 - 2026-08-15

DB version: 1.41.0 (adds `qr_last_attempt_at`, `qr_attempt_count` to `wpq_submissions`; migration is additive, no destructive changes).

### Added

- **Revenue screen** consolidates Pricing, Coupons & Promo Codes, and Orders
  into one admin screen (`Questionnaires → Revenue`) as three independently
  collapsible sections, replacing the three separate menu items. A summary
  header shows active pricing options, active coupons, total orders, and
  paid revenue per currency. All existing per-section functionality (add/edit/
  delete pricing, create/delete coupons, order search/export/pagination) is
  unchanged. The shared select-all/bulk-export toolbar, previously assuming
  only one such toolbar existed per page, is now scoped per section so three
  copies on one screen don't interfere with each other.
- **Cron Task Backlog** on the Readiness screen lists every Questionnaire
  Report generation job currently queued or in progress - submission,
  customer, questionnaire, status, requested/last-attempt timestamps, attempt
  count, and a JSON analysis payload preview - with **Retry** (runs the job
  inline within the request rather than only rescheduling another WP-Cron
  event) and **Cancel** actions. A new **Cron & Task Processing** panel
  reports whether the site is running on WordPress' pseudo-cron or has
  `DISABLE_WP_CRON` set (expecting a system cron), plus the count and next
  run time of scheduled report-generation events. Submissions now record
  `qr_last_attempt_at`/`qr_attempt_count` distinct from `qr_requested_at`, so
  a job that was queued but never actually attempted (the WP-Cron-not-firing
  failure mode) is now distinguishable from one that ran and is retrying.
- **Readiness** now also checks the `gd` and `zip` PHP extensions that
  PHPWord requires, alongside the existing PHPWord/Dompdf/Stripe library
  checks.

### Changed

- Replaced "Phase 3" terminology in user-facing Readiness/Settings copy with
  "Feature Gated" for Stripe checkout and its dependent routes/capabilities,
  which were never phase-numbered from a user's perspective.

## 1.12.0 - 2026-08-15

### Fixed

- **Frontend no longer relies on `unsafe-inline` for styles or scripts.**
  Under a strict Content-Security-Policy (`style-src-attr 'none'`, no
  hash/nonce support for style attributes), the assessment shortcode's
  results screen was generating hundreds of CSP violations per page load -
  every dynamic progress-bar width, score-ring stroke, and grade colour was
  being set via `element.style.*`, which such a policy blocks outright with
  no allowlisting path available. Fixed by:
  - Replacing every `.style.*` mutation in `assessment.js` with `classList`
    toggles against precomputed CSS (101 percentage-bucket classes each for
    bar widths and the score ring's `stroke-dashoffset`).
  - Publishing each questionnaire's admin-configured grade colours as a
    small, cached, publicly-readable stylesheet (`WPQ_Questionnaire_Style_Generator`)
    loaded via `<link>` instead of inline `style`/`<style>` - external
    stylesheets are outside CSP's reach regardless of nonce/hash support
    anywhere in the chain, so this preserves full "any hex colour" admin
    flexibility with no precision loss.
  - Removing both `wp_localize_script()` calls (`wpqConfig`, `wpqEnquiryConfig`),
    which rendered inline `<script>` tags; config now reaches the frontend
    entirely via `data-*` attributes already present in the markup.
  - Removing a redundant inline `<style>` fallback for late/AJAX-rendered
    shortcodes - the one rule it carried already lives in `assessment.css`.

## 1.11.108 - 2026-08-12

### Fixed

- **Turnstile widget honours the sitekey's own Widget Mode.** The plugin
  was hardcoding `data-appearance="interaction-only"` on the rendered
  widget, which overrides whatever Widget Mode (Managed, Non-Interactive,
  Invisible) is chosen for that sitekey in the Cloudflare dashboard -
  a site configured for "Managed" was silently forced into invisible
  behaviour. The attribute is no longer set, so the dashboard's Widget
  Mode setting now actually takes effect. Settings → Turnstile copy
  updated to match.

## 1.11.107 - 2026-08-12

### Changed

- **Enquiry form footer**, aligned with the questionnaire lead-capture form:
  the consent checkbox now reads "I have read and accept the privacy
  notice," with "privacy notice" linking to the site's configured Privacy
  Policy page (falling back to a plain-text explanation when no policy page
  is set), and a footer note - "We use your details to follow up on your
  enquiry, and manage our service." - sits alongside the submit button.

## 1.11.106 - 2026-08-12

### Added

- **Cloudflare Turnstile bot protection**, configured under Settings →
  Turnstile. Protects the two public endpoints that write a new contact
  identity into the system - starting an assessment (`POST /wpq/v1/lead`)
  and submitting an enquiry (`POST /wpq/v1/enquiry`) - behind a global
  on/off switch plus a per-questionnaire and per-enquiry-form
  inherit/enabled/disabled override, mirroring the existing mail-delivery
  pattern. The widget renders with `data-appearance="interaction-only"`,
  so genuine visitors see nothing unless Cloudflare's risk signals
  actually call for a challenge, and the Turnstile script itself is only
  ever loaded when a given questionnaire or form actually requires it.
  Verification is deliberately fail-open: an unconfigured setup, an
  unreachable `siteverify` API, or an unexpected response never blocks a
  submission - only a missing token (a bot skipping the widget) or an
  explicit rejection from Cloudflare does. Site/secret keys resolve
  constant → environment → option, matching the plugin's existing
  secrets convention.

### Changed

- Database schema 1.40.0: `turnstile_enabled` on `wpq_questionnaires`
  and `wpq_enquiry_forms`.

## 1.11.105 - 2026-08-12

### Changed

- **Enquiry Fields editor aligned with the question editor's UX.** Each
  field is now a card (Label, Type, Required, Remove) with an Options
  section that appears only for field types that use one (Select,
  Checkboxes) - the same "the type you pick decides what's visible"
  behaviour as the questionnaire question editor's answer-type select,
  instead of a flat table that always showed an irrelevant Options
  column for Text and Text area fields. No change to the saved field
  data shape or the enquiry engine.

## 1.11.104 - 2026-08-12

### Fixed

- **A pinned Claude model no longer queries the Models API.**
  `get_model_diagnostics()` - called on every view of Settings → AI and
  Readiness - always fetched the live model list to report an "available
  models" count, even when a specific model was configured and the
  fetched list was never actually used (`select_model()` already
  short-circuits past it for a pinned model). Combined with the AI
  settings save clearing the 6-hour model-list cache, this meant a
  pinned-model site could burn a live Anthropic API call on nearly every
  admin page load. The models list is now only ever fetched when the
  preference is `auto`; the Settings page explains why the count is
  absent otherwise.
- **Report generation no longer silently stalls at "queued".**
  Generating or retrying a Report from the submission detail screen
  scheduled a WP-Cron event and relied entirely on it firing - but
  WP-Cron only runs on a subsequent site request, and not at all if it's
  disabled or the host blocks the loopback HTTP request that spawns it
  (common on staging sites behind basic auth or a firewall). A job could
  sit at "queued" indefinitely with nothing in the debug log, which is
  indistinguishable from the feature being broken. The admin-triggered
  Generate/Regenerate Report and Retry PDF Conversion actions now also
  run the job synchronously in the same request - the customer-facing
  results page is untouched and stays deliberately asynchronous.

## 1.11.103 - 2026-08-12

### Added

- **Remediation Plan template validation.** The questionnaire editor's
  Remediation Plan workbook section gains the same live Valid/Invalid
  panel the Report template already had - `WPQ_Remediation_Plan` now
  checks that the uploaded `.xlsx` actually defines a genuine Excel
  Table named `TASKS` on a `Tasklist` sheet (not just a plain range of
  cells with matching column headers, the exact gap that produced the
  "Repaired" workbook in 1.11.101), and reports specifically which part
  is missing when it doesn't.
- **Optional-section visibility for the Report template.** The Report
  template panel now lists whether each optional section - Framework
  readiness, Strengths, Recommended next steps, Limitations - is
  actually present in the uploaded template, since a missing optional
  block is silently skipped at render time with no other indication.
  If Framework readiness is present but no frameworks are selected for
  the questionnaire, a warning explains the section will render empty.

### Changed

- **UI relabelling**: "Questionnaire Report" is now "Report", and "AI
  Remediation Plan" is now "Remediation Plan", throughout the admin
  screens (questionnaire editor, Settings, Readiness, submission
  detail, Frameworks). Internal class names, hooks, database columns,
  and option keys are unchanged - this is a display-label change only.
- The Remediation Plan template description now explains the `TASKS`
  table requirement precisely: it must be a named Excel Table object,
  not a sheet that merely has the right column headers.

## 1.11.102 - 2026-08-12

### Changed

- **Plugin description updated** to reflect current capabilities. The
  header, README, deployed update manifest (`update.json` `sections.description`)
  and the auto-updates design doc all still described the plugin as it
  was before enquiries, email delivery, the contact master, and AI-driven
  reports/remediation plans existed. Now: "Assessment and lead-generation
  platform with a canonical contact master. Publishes scored
  questionnaires with save & resume, captures leads and enquiries,
  generates AI-driven questionnaire reports and remediation plans,
  delivers email via wp_mail/Gmail/SES, and sells branded PDF reports
  via Stripe - with HaloPSA sync throughout."

## 1.11.101 - 2026-08-12

### Fixed

- **Remediation workbook tasks now land inside the TASKS data-table.**
  Generation previously rebuilt the Tasklist sheet from scratch, which
  destroyed the template's authored content (title block, second table,
  styled header) and left the task rows as a plain cell range - Excel
  opened the workbook as "Repaired" with generic Column1…Column12
  headers, and dates rendered as raw serial numbers. The sheet is now
  edited surgically: every authored row outside the table survives, the
  template's styled header row is kept, generated rows are inserted into
  the table's data region (inheriting the template's per-column number
  formats, so dates display as dates), rows below the table shift when
  the plan outgrows the template range, and the table and autoFilter
  ranges track the data - so the TASKS table drives the Planner/Gantt
  exactly as authored.

## 1.11.100 - 2026-08-12

### Added

- **Enquiry export.** Import / Export gains an *Enquiries* export: every
  enquiry form with its field definitions and settings, each with its
  received enquiries (contact snapshot, consent, decoded responses,
  status, received time). Enquiries whose form has since been deleted are
  included under a null form so nothing silently drops out of the export.
  The Enquiries screen gains a matching "Export all" button.

### Removed

- The informational "Claude Project IDs" row on the Settings AI tab
  (project IDs are configured per questionnaire in the questionnaire
  editor; the placeholder row added nothing).

## 1.11.99 - 2026-08-11

### Added

- **Canonical contact master - Phase 4 (external integration contract).**
  Other Alltime plugins (WP-Reconnaissance and future products) can now use
  canonical contacts without touching `wpq_*` tables:
  - Versioned service discovery:
    `apply_filters( 'alltime_contact_service', null, '1.0' )` returns a
    `WPQ_Contact_Service_Interface` implementation for compatible contract
    versions (same major, not newer than implemented), `null` otherwise -
    including when the contact master feature flag is off. An
    already-answering provider is never displaced.
  - The full event set now fires: `alltime_contact_created`,
    `alltime_contact_updated`, `alltime_contact_merged`,
    `alltime_contact_interaction_recorded`, and
    `alltime_contact_preference_changed`, with documented payload
    stability rules.
  - Integration documentation (contract, trust rules for
    `wp_user_id`/`trusted_uuid`, interaction idempotency, consent
    purposes, hook catalogue):
    `.roadmap/contact-master/integration-api.md`.
  - A compatibility fixture suite proves discovery, version negotiation,
    feature-flag behaviour, provider precedence and the complete method
    contract. This completes the four-phase canonical contact master
    delivery.

## 1.11.98 - 2026-08-11

### Added

- **Canonical contact master - Phase 3 (administration and privacy).**
  - The **Contacts screen now reads the canonical model**: one row per
    person with primary email (verification-flagged), organisation,
    lifecycle status, questionnaire/enquiry counts, last interaction,
    current marketing state and a review warning; searchable and
    filterable by status. The legacy email-keyed view remains reachable
    (it hosts the email-scoped GDPR operations).
  - **Contact detail screen**: canonical profile (editable with mandatory
    audit trail - blank values never erase, snapshots never rewritten),
    identities with verification state, organisation relationships,
    purpose-aware communication preferences, interaction timeline, linked
    submissions (with their historic snapshots, payment status and
    HaloPSA references) and enquiries, merge history, and full audit
    history.
  - **Ambiguous-match review queue** on the Contacts screen: each pending
    candidate shows its source record, reason and details, with actions -
    keep separate, mark shared mailbox, link into a chosen contact
    (executed as an audited merge), defer, or ignore with reason.
  - **Deliberate merge workflow**: repoints submissions, enquiries,
    identities, organisations, interactions and consent events to the
    survivor; reprojects preferences so the most restrictive marketing
    state wins; folds in only missing profile fields; marks the absorbed
    contact `merged` (never deleted) with recovery metadata in the merge
    log; emits `alltime_contact_merged`.
  - **Privacy actions extended to the canonical model**: the data-subject
    export now includes canonical profiles, identities, organisation
    relationships, consent history and interaction timelines for contacts
    holding the requested email; anonymisation clears canonical PII and
    revokes identities while retaining hashed suppression evidence so
    marketing objections survive; hard deletion additionally marks the
    canonical record `deleted` without destroying merge/audit integrity.

### Changed

- Database schema 1.39.0: new `wpq_contact_audit` table (before/after
  summaries for every canonical edit, merge and privacy action).

## 1.11.97 - 2026-08-11

### Added

- **Canonical contact master - Phase 2 (historic migration).** Batched,
  resumable, idempotent migration of existing data into the canonical
  model (runbook: `.roadmap/contact-master/migration-runbook.md`):
  - Historic submissions and enquiries link to canonical contacts through
    the same resolution service as live traffic, with timeline
    interactions recorded at their historic timestamps. Only unlinked
    records are candidates; the interaction dedupe key makes re-runs safe;
    checkpoints and counters live in a non-autoloaded state option; a
    transient lock prevents concurrent workers; batches are bounded
    (100 records / 20 seconds) and chain automatically via WP-Cron.
  - Ambiguity goes to the review queue, never an automatic merge: role
    mailboxes, materially conflicting names, and multi-candidate emails
    each produce a separate provisional contact plus a pending
    `wpq_contact_match_review` row.
  - Legacy email opt-outs migrate as `direct_marketing_email`
    **suppressed** consent events where the email maps to exactly one
    contact; ambiguous or orphaned suppressions are counted and the legacy
    preference rows are always retained - an opt-out is never weakened or
    lost.
  - The Readiness screen gains a *Canonical Contact Master* card: contact
    counts, unlinked submissions/enquiries, pending review candidates,
    live migration progress and errors, plus Run/Reset controls. After
    completion the same control re-scans for records that failed live
    resolution (reconciliation).
  - New CI integration tests cover cross-source identity linking,
    duplicate-free re-runs, role-mailbox separation with review queueing,
    opt-out suppression survival, and canonical linking on the live lead
    endpoint.

## 1.11.96 - 2026-08-11

### Added

- **Canonical contact master - Phase 1 (schema and service).** The first
  stage of replacing the derived Contacts view with a true contact master
  (design records in `.roadmap/contact-master/`):
  - New canonical tables: `wpq_contacts` (stable identity: numeric PK +
    crypto-random UUID, lifecycle status, WP-user link),
    `wpq_contact_identities` (email/telephone as mutable, verifiable
    attributes - email is *not* the contact key), `wpq_contact_organisations`,
    `wpq_contact_interactions` (idempotent timeline events),
    `wpq_contact_consent_events` + `wpq_contact_preferences_current`
    (purpose-aware consent event log with a most-restrictive-wins
    projection), `wpq_contact_merge_log`, and `wpq_contact_match_review`
    (ambiguity queue).
  - `WPQ_Contact_Service` (isolated under `includes/contacts/`): resolution
    precedence WP user → trusted UUID → verified identity → single
    unambiguous email match → new provisional contact. Role mailboxes
    (`info@`, `sales@`, …) and material name conflicts never auto-link -
    they create a provisional contact plus a review-queue entry. Blank
    input never erases; unverified input never overwrites a verified
    contact's conflicting values.
  - New submissions and enquiries now populate both their historic snapshot
    fields (unchanged, still driving reports) and a canonical `contact_id`,
    and record `questionnaire_started` / `questionnaire_completed` /
    `enquiry_submitted` interactions plus the enquiry's `service_delivery`
    consent event (never treated as marketing consent). Resolution failures
    are logged and leave records unlinked for reconciliation rather than
    failing the customer's request.
  - Feature-flagged via the `wpq_contact_master_enabled` option (default
    enabled; linking is purely additive).
  - Phases 2–4 (historic migration + review UI, canonical admin screens +
    privacy workflows, external plugin service contract) follow separately.

### Changed

- Database schema 1.38.0: eight canonical contact tables plus nullable
  indexed `contact_id` columns on `wpq_submissions` and `wpq_enquiries`.

## 1.11.95 - 2026-08-11

### Fixed

- **Skills API registration failed for long framework names.** The
  Anthropic Skills API limits `display_title` to 64 characters, and
  several imported ATLAS bundle names (e.g. "NIST SP 800-161 Rev 1 -
  Cybersecurity Supply Chain Risk Management (C-SCRM)") exceed it, so
  registration returned HTTP 400. Titles are now truncated at a word
  boundary with an ellipsis before registration, so every framework can
  register regardless of its stored name.

### Added

- **Framework rename in the GUI.** Each row on the Frameworks &
  Standards screen has an "Edit name" control to rename an imported
  framework in place. Names longer than the Skills API limit show a
  preview of the truncated title that will be registered. Renaming does
  not touch the stored bundle; push a new version to update the
  registered skill's title.

## 1.11.94 - 2026-08-11

### Fixed

- **Remediation plan generation failing on larger assessments.** The Claude
  request capped output at 5,000 tokens, so a 40-finding assessment came
  back cut off mid-JSON and parsing failed with "Claude response did not
  contain tasks". The cap is now 16,000 tokens; the parser strips markdown
  code fences (which the model adds despite instructions); and if a
  response still hits the ceiling, every fully-received task is salvaged
  instead of discarding the whole plan (with a `claude_messages_truncated`
  debug event recording that it happened).

### Added

- **Remediation plan delivery controls**, mirroring the Questionnaire
  Report delivery architecture. A global channel list (Settings → AI →
  AI Remediation Plans) and a per-questionnaire override (inherit / none /
  custom) control how the workbook reaches the customer:
  - *Direct download on the results screen* (the default - existing
    behaviour), and/or
  - *Email the customer a secure link*: the generated workbook is stored
    and a purpose-scoped tokenised link (30 days / 10 downloads) is
    emailed via the configured mail provider, served by
    `GET /wpq/v1/remediation-workbook/{id}`. With email-only delivery the
    results screen offers "Email me my remediation plan" instead of a
    direct download.

### Changed

- Database schema 1.37.0: `remediation_delivery_channels` on
  `wpq_questionnaires` and `remediation_xlsx_path` on `wpq_submissions`.

## 1.11.93 - 2026-08-11

### Changed

- **Settings layout.** Email Delivery moved out of the AI tab into its own
  **Mail** tab (global switch, provider preference, Gmail/SES credentials,
  diagnostics, and the test-send form, which now lives inside the tab).
  The AI tab is reordered so Claude configuration (API key, model, project
  IDs, debug log and clear control) comes first, followed by the AI
  Remediation Plans and Questionnaire Reports sections. After saving a
  section or sending a test email, the settings page now reopens on the
  tab you were using instead of dropping back to Stripe.

## 1.11.92 - 2026-08-11

### Fixed

- **Resume did not restore radio and dropdown answers.** Continuing a saved
  assessment (via the same-device banner or a resume link) replayed
  tri-state, yes/no, checkbox, and text answers but silently skipped
  `radio` and `select` question types - so questionnaires built from those
  types (including CyberCheck) came back showing 0 answered despite the
  banner correctly counting the saved answers. Replay now clicks the
  matching radio input and re-selects the dropdown option.

## 1.11.91 - 2026-08-11

### Added

- **Enquiry forms.** A new *Enquiries* admin area lets you compose contact
  forms the same way questionnaires are composed: name, description,
  draft/published status, and up to 30 custom fields (text, textarea,
  select, checkbox) with per-field required flags. Each form gets a
  shortcode - `[wpq_enquiry ref="EF-XXXXXX"]` - that renders a front-end
  form collecting name, email, company, phone, the custom fields and an
  explicit consent checkbox. Submissions post to `POST /wpq/v1/enquiry`
  (rate-limited, honeypot-protected, options-whitelisted validation) and
  are stored with a human-friendly reference (`ENQ-YYYYMMDD-XXXX`),
  browsable in the admin with new/seen status. Enquiry records are included
  in the existing GDPR export/anonymise/delete tooling.
- **Pluggable email delivery.** A new `WPQ_Mailer` service routes every
  email the plugin sends (report delivery, resume links, enquiry
  notifications and acknowledgements) through a configurable provider:
  - **WordPress `wp_mail()`** (default - behaviour unchanged),
  - **Gmail API** (Google Cloud OAuth client + refresh token, RFC 5322
    MIME built in-plugin, header-injection safe), or
  - **AWS SES v2** (SigV4 request signing implemented natively - no AWS
    SDK dependency).
  Settings → AI gains an *Email Delivery* section with a global
  enable/disable switch, provider preference, per-provider credentials
  (secrets are write-only password fields; constants/environment variables
  `WPQ_GMAIL_*` / `WPQ_SES_*` override stored options), provider readiness
  diagnostics with last-error display, and a test-send button.
- **Per-scope mail switches.** Each questionnaire and each enquiry form has
  its own inherit/enabled/disabled email setting layered under the global
  switch, so mail can be turned off for a single questionnaire or enquiry
  form without affecting the rest of the site.

### Changed

- Database schema 1.36.0: new `wpq_enquiry_forms` and `wpq_enquiries`
  tables, and a `mail_enabled` column on `wpq_questionnaires`.

## 1.11.90 - 2026-08-10

### Added

- **Save & resume.** A customer part-way through an assessment can now leave
  and pick up exactly where they left off:
  - The heartbeat now persists the partial answers server-side (sanitised,
    size-capped), not just a position marker, so progress survives the
    browser as well as the tab.
  - A "Save & continue later" control on the assessment screen hands out a
    personal resume link - copyable, and optionally emailed to the contact -
    via `POST /wpq/v1/resume-link` (session-token authorised). The link
    carries a hashed, purpose-scoped token (`resume`, 30 days / 25 uses) on
    the existing token table; the session credential itself never appears in
    a URL or mailbox. Link anchors are validated same-site, with stale
    `wpq_resume`/`utm_*` parameters stripped.
  - Opening a resume link (`?wpq_resume=…`) redeems it via
    `POST /wpq/v1/resume`, which **rotates the session token** and returns
    the saved answers and position; the front end rebuilds the assessment and
    replays every saved answer through the normal input handlers, landing on
    the first incomplete domain. Rotation also revives sessions whose tokens
    were blanked by a plugin-update migration.
  - Same-device return visits (no link needed) get a "Continue where you left
    off" banner, backed by localStorage and verified against the server
    before it is offered. Completed or purged submissions clear silently;
    redeeming a link for a completed assessment says so instead of resuming.
  - Resuming clears the abandoned flag; completing or restarting clears the
    saved local state.

No database schema change (the resume token reuses `wpq_report_tokens` with
`purpose = 'resume'`).

## 1.11.89 - 2026-08-08

### Added

- Questionnaire Reports can now include a **framework readiness** section.
  Each questionnaire selects which imported frameworks its reports are
  assessed against (questionnaire editor; only frameworks registered with
  the Anthropic Skills API are selectable; maximum 8 per report). During
  report generation, each selected framework is assessed in its own beta
  Messages call with the framework's ATLAS skill attached via
  `container.skills` (betas `code-execution-2025-08-25` +
  `skills-2025-10-02`, with the required code-execution tool declared).
- Assessments return a strict JSON contract: a readiness level
  (aligned / partially aligned / not aligned / insufficient evidence), a
  percentage only when the standard's own methodology yields one (the
  prompt forbids estimated figures; the value is clamped 0–100 or null),
  a posture summary, and per-control strengths and gaps. Every cited
  control reference is validated against the framework's imported
  catalogue - a hallucinated ref is cleared while the finding's substance
  is kept.
- New optional `frameworks` template block: `{{framework.name}}`
  `{{framework.readiness}}` `{{framework.percent}}` `{{framework.summary}}`
  `{{framework.strengths}}` `{{framework.gaps}}`
  `{{framework.recommendations}}`. Templates without the block are
  unaffected.
- Readiness is an enhancement, never a blocker: a framework whose
  assessment fails is skipped (logged to the Claude debug log), and a
  questionnaire with no selected frameworks produces no section.

### Changed

- Database schema version is now `1.35.0`: `wpq_questionnaires` gains
  `framework_ids`.

## 1.11.88 - 2026-08-07

### Added

- Added curated control catalogues for the last four content-bearing
  frameworks: COBIT 2019 (all 40 governance/management objectives across
  EDM/APO/BAI/DSS/MEA), HIPAA (the Security Rule's 22 standards,
  45 CFR §164.308–§164.316, plus the four Breach Notification duties),
  ISO/IEC 27018 (the Annex A extended control set for PII protection,
  organised by the eleven ISO 29100 privacy principles, A.2–A.12), and
  EU NIS2 (governance Art. 20, the ten minimum risk-management measures
  Art. 21(2)(a)–(j), and incident reporting Art. 23).
- Supplements now support a `replace` mode for standards whose canonical
  catalogue is fixed and complete: COBIT's bundle yields only a fragmentary
  objective list, so the curated 40 replace the partial scrape. All other
  supplements remain fallback-only, deferring to any catalogue an ATLAS
  bundle ships.
- 38 of the 40 ATLAS skills now import with a control catalogue; the only
  metadata-only imports are ITIL v3 and ITIL v4, which are process
  frameworks with no control catalogue by design.

## 1.11.87 - 2026-08-06

### Added

- The framework importer now recognises catalogue tables keyed by an
  explicit `ID`/`Control ID` header even when the ids carry no digit -
  NIST SP 800-53 control-family codes (`AC` … `SR`). This surfaces the 20
  control families from the NIST SP 800-53A, FedRAMP, and GovRAMP bundles,
  the six functions of NIST CSF 2.0 (now 112 entries), and the full RMF task
  catalogue in NIST SP 800-37 (now 64).
- Added curated supplemental catalogues, applied only when a bundle carries
  no tabular catalogue of its own (a bundle that later ships one
  automatically takes precedence): NIST SP 800-207 (the seven Zero Trust
  tenets §2.1 and three core logical components §3), NIST SP 800-39 (the
  three-tier model §2.1 and four-component risk process Ch. 3), NIST SP
  800-115 (technique classes §3–§5 and assessment lifecycle §6–§8), and the
  UK Cyber Security and Resilience Bill (eight key measures, explicitly
  marked pre-Royal Assent and subject to change while the Bill remains
  before the Lords). Every NIST SP skill and the UK CSRB now import with a
  control catalogue; remaining metadata-only imports are HIPAA, ISO 27018,
  NIS2, and the ITIL/COBIT process frameworks, whose bundles are prose
  guides.

## 1.11.86 - 2026-08-06

### Added

- Added a **Frameworks** admin page that imports ATLAS `.skill` bundles into
  the previously reserved framework registry tables. Each uploaded bundle
  (multiple can be imported in one go) registers or refreshes a
  `wpq_frameworks` row and replaces that framework's control catalogue in
  `wpq_framework_controls`, parsed deterministically from the bundle's
  markdown: catalogue tables (the reference column is detected, not assumed
  first - DORA keys its catalogue in column two), heading-form catalogues
  ("Article 32 - Security of processing"), CMMC-style tables whose practice id
  embeds its NIST source, with cross-standard mappings, glossaries, revision
  histories, worked examples, and workflow scaffolding all excluded. Validated
  against all 40 published ATLAS skills: every bundle imports; 29 yield
  control catalogues (ISO 27001 209, PCI DSS 341, CMMC 129, NIST CSF 106,
  SOC 2 63, …) and 11 are correctly metadata-only because their bundles
  contain guides rather than catalogues (ITIL, COBIT, FedRAMP, HIPAA, …).
- Imported bundles are stored in protected uploads
  (`wp-content/uploads/wp-questionnaires/skills/`) and can be registered with
  the Anthropic Skills API from the same page (`POST /v1/skills`, beta
  `skills-2025-10-02`; a re-registration pushes a new skill version). The
  returned skill id/version is recorded on the framework row, so the control
  catalogue in the database and the skill Claude will analyse readiness with
  always come from the same artefact.

### Changed

- Database schema version is now `1.34.0`: `wpq_frameworks` gains `skill_id`,
  `skill_version`, `skill_checksum`, `skill_bundle`, and `skill_imported_at`.

## 1.11.85 - 2026-08-06

### Added

- Questionnaire Reports can now be delivered to the customer, not just
  downloaded by an administrator. Delivery is configured as a list of enabled
  channels - a secure link on the results screen, a secure link after checkout,
  and an emailed secure link - in **Settings → AI**, with a per-questionnaire
  override that can inherit the global list, disable customer delivery
  entirely, or select its own channels. Adding a future channel needs no schema
  or settings-shape change.
- Added a public tokenised download route
  (`GET /wpq/v1/questionnaire-report/{id}?token=…`). Tokens are stored hashed,
  expire after 30 days or 10 downloads, and are scoped by purpose so a token
  minted for the paid HTML report cannot redeem the Questionnaire Report PDF or
  vice versa. The report is only ever linked, never emailed as an attachment,
  and the storage directory is still never exposed.
- Added a status route
  (`GET /wpq/v1/questionnaire-report-status/{id}?session_token=…`), authorised
  by the submission's own session token, so the results screen can report
  progress while the report generates in the background and then offer the
  link. The results screen polls it, with a bounded number of attempts.
- Completing an assessment now queues the customer's Questionnaire Report
  automatically when any delivery channel is enabled for that questionnaire.
  Queuing failures never block the results screen.
- Added admin-editable delivery email subject and opening copy.

### Changed

- Database schema version is now `1.33.0`: `wpq_questionnaires` gains
  `questionnaire_report_delivery_channels`, `wpq_submissions` gains
  `qr_email_sent_at` (making email delivery idempotent), and
  `wpq_report_tokens` gains `purpose`.
- Deleting a submission, anonymising a contact, or purging report artefacts now
  revokes that submission's download tokens, so a link already sitting in a
  customer's inbox stops working instead of resolving to a missing file. A GDPR
  hard delete removes the token rows outright.

## 1.11.84 - 2026-08-06

### Added

- Questionnaire Report templates can now present scores and severity counts as
  native Word tables instead of embedded chart images, via new optional
  placeholders: `{{counts.critical}}` / `{{counts.high}}` / `{{counts.medium}}` /
  `{{counts.low}}` / `{{counts.total}}` (every level always resolves to a number,
  `0` included), `{{domain.percent}}`, `{{report.reference}}`,
  `{{assessment.verdict}}`, `{{assessment.domains_count}}`,
  `{{assessment.questions_count}}`, and `{{finding.id}}`. Every figure therefore
  stays searchable, selectable, and readable by assistive technology. Existing
  templates are unaffected - none of the new placeholders are required.
- Questionnaire Report findings are now assigned stable ids (`F1`, `F2`, …),
  assigned locally rather than taken from the model, and the validated analysis
  is stored on the submission (`qr_analysis_json`).
- The remediation workbook now plans against the report's findings when a report
  exists: the stored finding list is passed to the task prompt as the canonical
  set of problems, and each task carries `related_finding_ids` filtered against
  the known ids so a hallucinated reference is dropped rather than written in as
  a dead link. The built-in workbook gains a **Report Findings** column;
  uploaded workbook templates (fixed `TASKS` column set) get the links appended
  to the task description. Submissions without a report are planned from the
  answers exactly as before.

### Changed

- Database schema version is now `1.32.0`, adding the `qr_analysis_json` column
  to the submissions table.
- The stored Questionnaire Report analysis is deleted alongside the generated
  DOCX/PDF artefacts when a submission is soft-deleted or a contact anonymised,
  so customer-derived narrative cannot outlive the artefacts it produced.

### Fixed

- Updated `squizlabs/php_codesniffer` to 3.13.6 for CVE-2026-67434 (OS command
  injection), which was failing `composer audit` in CI.

## 1.11.83 - 2026-08-06

### Added

- Implemented the complete Questionnaire Report generation pipeline: the
  uploaded questionnaire-specific `.docx` template is now populated with a
  Claude-generated analytical assessment (`questionnaire-report-v1` prompt)
  and converted to PDF, as a separate artefact from the Remediation Plan XLSX
  workflow. New classes: `WPQ_Questionnaire_Report` (orchestration),
  `WPQ_Questionnaire_Report_Context` (versioned assessment context,
  `questionnaire-report-context-v1`), `WPQ_Questionnaire_Report_Analysis`
  (Claude prompt/response validation), `WPQ_Docx_Template_Renderer`
  (PHPWord `TemplateProcessor`-based population with `{{...}}` placeholders
  and repeating block sections), `WPQ_Docx_Pdf_Converter_Interface` and
  `WPQ_LibreOffice_Pdf_Converter` (local headless LibreOffice conversion via
  `proc_open()` with an argv command, never a shell string), and
  `WPQ_Questionnaire_Report_Storage` (protected DOCX/PDF storage).
- Added `phpoffice/phpword` as a production Composer dependency for
  run-fragmentation-safe DOCX template population.
- Generation runs as an idempotent WordPress single-event cron job
  (`wpq_process_questionnaire_report` / `wpq_retry_questionnaire_report_pdf`)
  through explicit states (`queued`, `analysing`, `rendering_docx`,
  `converting_pdf`, `completed`, `partial`, `failed`) so admin requests never
  block on Anthropic or LibreOffice. Concurrent/duplicate "Generate" clicks
  are prevented by an atomic per-submission job claim.
- Added a "Questionnaire Report" section to the submission detail admin
  screen (status, renderer mode, model, prompt/context version, template
  checksum, DOCX/PDF downloads, Generate/Regenerate/Retry PDF Conversion),
  and template validation/readiness display to the questionnaire editor's
  Questionnaire Report template card.
- Added global and per-questionnaire Questionnaire Report enable and
  renderer-mode (`docx_template` / `html_dompdf`) settings, plus a
  LibreOffice executable path and conversion timeout setting, in
  **Settings → AI**.
- Added a "Questionnaire Report (DOCX → PDF)" readiness panel covering
  Claude configuration, the PHPWord library, PDF converter detection, and
  DOCX/PDF storage.
- Generated Questionnaire Report DOCX/PDF files are now removed immediately
  on submission soft-deletion, contact anonymisation, and contact hard
  deletion (they embed the customer's name/company in their content), and on
  full uninstall when "Delete all data on uninstall" is enabled.

### Database

- Bumped `WPQ_DB_VERSION` to `1.31.0`. Added `questionnaire_report_enabled`
  and `questionnaire_report_renderer_mode` to `wpq_questionnaires` (the DOCX
  template itself reuses the existing `claude_template_*` columns). Added
  `qr_status`, `qr_renderer_mode`, `qr_claude_request_id`, `qr_model_used`,
  `qr_prompt_version`, `qr_context_version`, `qr_template_checksum`,
  `qr_docx_path`, `qr_docx_checksum`, `qr_pdf_path`, `qr_pdf_checksum`,
  `qr_generated_at`, `qr_requested_at`, `qr_last_stage`, `qr_failure_code`,
  `qr_failure_message`, and `qr_generation_token` to `wpq_submissions` -
  kept separate from the Remediation Plan's `ai_report_*` columns, which
  remain XLSX-specific.

## 1.11.82 - 2026-08-04

### Added

- Added a questionnaire-level Remediation Plan workbook template upload for
  `.xlsx` files, separate from the Questionnaire Report `.docx` template.
- Remediation workbook generation can now populate a template `TASKS` table on
  the `Tasklist` sheet while preserving Planner formulas and Gantt layout.
- Added customer/project-owner instruction placeholders for remediation workbook
  templates.

### Changed

- Clarified the questionnaire editor template areas so Remediation Plan
  workbooks and Questionnaire Reports are treated as separate artefacts.

### Database

- Bumped `WPQ_DB_VERSION` to `1.30.0` and added remediation workbook template
  attachment metadata to questionnaires.

## 1.11.81 - 2026-08-04

### Changed

- Claude remediation-plan generation now prefers a capable Haiku model in
  automatic mode to reduce test-run cost, with Sonnet and Opus retained as
  fallbacks.
- Increased the Anthropic Messages request timeout and added dispatch, elapsed
  time and generation-failure diagnostics so failed remediation-plan attempts
  leave a clearer audit trail.
- Remediation prompts now omit informational/Good Practice findings by default,
  reducing prompt size and keeping generated tasklists focused on actionable
  remediation work.

## 1.11.80 - 2026-08-04

### Added

- Added remediation plan actions to the admin submissions list so completed
  submissions can generate a remediation workbook and download an existing
  generated plan.
- Generated AI remediation workbooks are now stored under a plugin-owned
  uploads directory and recorded against the submission for later admin
  download.

### Changed

- Renamed the submission detail action to "Generate Remediation Plan" and
  added a "Download the Plan" link when a workbook has already been generated.
- Made the questionnaire-level remediation-plan inherit setting show the
  current global state and link to Settings -> AI, and renamed the global
  control to "Global remediation plan downloads".

## 1.11.79 - 2026-08-04

### Changed

- Stopped generating WordPress-local `wpqconv_*` Claude conversation IDs for
  submissions. The Claude conversation ID field now remains empty unless a
  provider-generated conversation or session identifier is returned by
  Anthropic.
- Updated the submission detail Claude Analysis copy to clarify that the
  current Anthropic Messages API does not create a Claude.ai chat conversation
  ID.

## 1.11.78 - 2026-08-04

### Added

- Added an admin-only "Submit this to Claude" action on submission detail
  pages so completed submissions can generate the same remediation workbook as
  the public result-page download flow without needing the customer's session
  token.
- Claude admin-triggered remediation generation now records processing,
  completed, and failed AI report states while keeping public/admin error
  messages safe.

## 1.11.77 - 2026-08-04

### Added

- Added a temporary Settings -> AI Claude API debug log toggle and recent-log
  view for remediation plan troubleshooting.
- Claude diagnostics now record capped Anthropic request/response metadata,
  status codes, request IDs where available, token usage, parsing failures, and
  workbook generation failures without storing API keys or full prompts.

## 1.11.76 - 2026-08-04

### Changed

- Replaced visible answer-option key and numeric order fields with compact
  move up/down controls in the questionnaire question editor.
- Answer-option row order is now saved from the visual row sequence, so public
  questionnaires render answers in the same order administrators arrange them.

## 1.11.75 - 2026-08-04

### Added

- Added a database-backed Settings -> Stripe checkout feature-gate dropdown
  that is used when `WPQ_CHECKOUT_ENABLED` is not defined in PHP
  configuration.
- Added a global Settings -> AI remediation-plan download toggle.
- Added a per-questionnaire remediation-plan download toggle with
  `inherit`, `enabled`, and `disabled` states.

### Changed

- Public checkout availability, checkout readiness, the remediation download
  button, and the remediation download REST endpoint now resolve feature flags
  through a central in-memory helper.

### Schema

- Bumped `WPQ_DB_VERSION` to `1.29.0`.
- Added `remediation_plan_enabled` to `wpq_questionnaires`.

## 1.11.74 - 2026-08-04

### Changed

- Moved Claude Project ID configuration fully to questionnaire records and
  removed the global Settings -> AI Project ID field.
- Removed the separate Claude Project URL field/link from admin screens and
  import/export handling.

### Schema

- Bumped `WPQ_DB_VERSION` to `1.28.0`.
- New installs no longer create the unused `claude_project_url` column.
- Upgrade cleanup removes the obsolete global `wpq_claude_project_id` option.

## 1.11.73 - 2026-08-03

### Added

- Added questionnaire-level Claude project metadata, manual configuration
  status, safe project URL validation, and DOCX template attachment tracking.
- Added submission-level Claude provider/session metadata and AI report
  artefact status fields, with schema diagnostics and indexed status/session
  columns.
- Added a small Claude API adapter documenting the supported Anthropic
  Messages/Models/Files surface and explicitly marking Claude.ai Project/chat
  lifecycle automation as unsupported by the public API.
- Added questionnaire editor controls for Claude project configuration and
  template upload/removal, plus a Claude Analysis section on submission detail
  pages.
- Added `.roadmap/claude-integration.md` covering the verified API boundary,
  data model, lifecycle, report-generation boundary, privacy, and future
  customer correlation model.

### Changed

- Initialises a WordPress-managed Claude session snapshot when a lead
  submission is created, using `{company} - {contact}` naming with deterministic
  fallbacks and without blocking public lead capture when manual configuration
  is required.
- Updated Settings -> Shortcodes examples to display hyphen-free questionnaire
  references such as `CS01` without changing stored refs or parser behaviour.
- Export/import now preserves portable Claude project metadata while avoiding
  site-local template attachment IDs.

### Schema

- Bumped `WPQ_DB_VERSION` to `1.27.0`.
- Added Claude project/template columns to `wpq_questionnaires`.
- Added Claude session and AI report artefact columns to `wpq_submissions`.

## 1.11.72 - 2026-08-03

### Changed

- Reworked Claude remediation plan generation to support an `auto` model
  preference that queries Anthropic's Models API and selects the newest
  balanced Sonnet model, falling back to Haiku before Opus.
- Added a Claude Project ID setting for traceability and future Project/
  Compliance API integrations.
- Documented the current Claude Project limitation: the direct Messages API
  workflow does not create visible Claude.ai Project chats from WordPress.

## 1.11.71 - 2026-08-03

### Fixed

- Added a read-time updater transient scrubber so WordPress cannot display a
  same-version WP Questionnaires update offer from stale cached
  `update_plugins` data after a successful update.
- Clear WordPress' plugin update transient after WP Questionnaires updates,
  forcing the next check to rebuild update state from the installed version.
- Refreshed the CSQ013 sample export metadata to match the current plugin
  release.

## 1.11.70 - 2026-08-03

### Fixed

- Refreshed the bundled CSQ013 sample export metadata to match the current
  plugin release, keeping the release packaging workflow aligned with
  `WPQ_VERSION`.

## 1.11.69 - 2026-08-03

### Fixed

- Refreshed the assessment domain tab completion state immediately after
  navigating to the next domain, so a completed section is marked as complete
  as soon as the user clicks Next.

## 1.11.68 - 2026-08-03

### Fixed

- Corrected the updater same-version suppression to compare remote metadata
  against the loaded `WPQ_VERSION`, while still clearing stale WordPress
  update-transient entries. This prevents stale cached `checked` values from
  reintroducing same-version update prompts after a successful manual update.
- Refreshed the CSQ013 sample export metadata to match the current plugin
  version.

## 1.11.67 - 2026-08-03

### Fixed

- Hardened the self-hosted updater so stale WordPress update-transient entries
  for WP Questionnaires are cleared before current update state is injected,
  preventing same-version "update available" prompts such as `1.11.65` to
  `1.11.65`.
- Compared remote update metadata against WordPress's checked installed plugin
  version for the active plugin file, rather than relying only on the loaded
  version constant.
- Refreshed the CSQ013 sample export metadata to match the current plugin
  version.

## 1.11.66 - 2026-08-03

### Fixed

- Changed the self-hosted update feed to advertise immutable versioned ZIP
  URLs for WordPress updates, preventing checksum mismatches when a site has
  cached metadata for one release and `wp-questionnaires-latest.zip` has
  already been replaced by a newer release.
- Kept `wp-questionnaires-latest.zip` as a manual-download alias only.
- Refreshed the CSQ013 sample export metadata to match the current plugin
  version.

## 1.11.65 - 2026-08-03

### Changed

- Updated the plugin author metadata to display "Simon Jackson @ Alltime
  Technologies Ltd" in WordPress and the self-hosted update feed.
- Added a direct Settings action link to the WordPress Plugins list entry.
- Refreshed the CSQ013 sample export metadata to match the current plugin
  version.

## 1.11.64 - 2026-08-03

### Changed

- Adjusted the questionnaire shortcode `layout="wide"` behaviour so it anchors
  to the surrounding content column and expands rightward, avoiding the
  left-heavy viewport breakout seen in ACF page layouts.
- Refreshed the CSQ013 sample export metadata to match the current plugin
  version.

## 1.11.63 - 2026-08-03

### Fixed

- Made the questionnaire shortcode `layout` attribute functional, with
  `layout="wide"` expanding beyond narrow theme/ACF columns and
  `layout="contained"` using a 1200px contained layout.
- Made self-hosted update package verification fail closed when checksum
  metadata cannot be verified.
- Made default grade threshold seeding report failures during questionnaire
  creation and roll back the partially-created questionnaire.
- Replaced raw Stripe exception text in admin AJAX responses with controlled
  messages while retaining server-side logs.
- Refreshed the CSQ013 sample export metadata to match the current plugin
  version.

## 1.11.62 - 2026-08-01

### Changed

- Hardened admin mutation handlers so category, contact preference, questionnaire,
  question, domain, grade, product, and coupon actions now report database write
  failures instead of returning optimistic success.
- Added SHA-256 package verification for the self-hosted updater and publish the
  latest ZIP checksum in the update feed.

## 1.11.61 - 2026-08-01

### Changed

- Updated Dompdf and WordPress Coding Standards dependencies to resolve
  Composer audit advisories reported by GitHub Actions.

## 1.11.60 - 2026-07-31

### Changed

- Added a repository line-ending policy so text files stay LF-normalised on
  Windows checkouts and Git/PHPCS no longer produce CRLF line-ending noise.

## 1.11.59 - 2026-07-31

### Fixed

- Hardened shortcode compatibility with nested Advanced Custom Fields values,
  including groups, repeaters, and flexible content field structures.
- Added a late-render CSS fallback so ACF/template-rendered assessments keep
  hidden loading/error/form states hidden when the shortcode renders after
  `wp_head`.

## 1.11.58 - 2026-07-31

### Fixed

- Improved shortcode compatibility with Advanced Custom Fields by detecting
  assessment shortcodes stored in post meta before frontend assets are queued.
- Ensured the assessment shortcode enqueues its own public CSS/JS when rendered
  from ACF fields, templates, or other non-native shortcode execution paths.

## 1.11.57 - 2026-07-10

### Changed

- Updated the Contacts admin table to show name, company, phone number, email,
  and existing activity/status columns, with the contact detail link moved onto
  the name column.
- Extended Contacts search to include phone numbers.

## 1.11.56 - 2026-07-09

### Changed

- Updated public key findings so Good Practice entries render with a very
  light green background and are hidden by the default Actionable filter until
  the user selects All or a specific severity.
- Reduced assessment/results spacing slightly.
- Added Good Practice as an admin-selectable answer-option finding priority.

## 1.11.55 - 2026-07-09

### Changed

- Renamed the admin Call to Action menu/page/import-export labels from
  plural to singular.

## 1.11.54 - 2026-07-09

### Added

- Added Calls to Action to the main Import / Export workflow, including JSON
  export, conflict analysis by category/domain scope, skip/overwrite import
  handling, and CTA page import/export shortcuts.

## 1.11.53 - 2026-07-09

### Fixed

- Reissued the demo-data exclusion release with release packaging that removes
  the empty `includes/data` directory as well as its generated contents.

## 1.11.52 - 2026-07-09

### Changed

- Stopped automatic seeding of the generated questionnaire library during
  activation and schema upgrades.
- Excluded generated/demo questionnaire library payloads from release ZIPs;
  `.sample_data` remains source-only optional import material.
- Updated package smoke tests to fail if demo questionnaire data is bundled.

## 1.11.51 - 2026-07-09

### Added

- Added Composer PSR-4 autoloading for new `Alltime\WPQ\` classes and a
  minimal internal service registry.
- Added immutable completion-time submission snapshots for questionnaire,
  scoring, grade threshold, option, and CTA context.
- Added a named WPQ administrator capability set as the first step toward
  delegated access controls.

### Changed

- Bumped the database schema to `1.26.0` for the new submission snapshot
  columns.
- Updated release packaging to include the new `src/` namespace tree.

## 1.11.50 - 2026-07-09

### Fixed

- Reissued the stabilisation groundwork release with PHPCS-compatible SQL
  string formatting for the database-backed rate limiter.

## 1.11.49 - 2026-07-09

### Added

- Added stabilisation groundwork for durable admin audit logging and atomic
  public rate limiting with new `wpq_audit_log` and `wpq_rate_limits` tables.
- Added central database transaction helpers for upcoming high-risk write-path
  hardening.
- Added readiness and schema diagnostics for rate-limit storage.

### Changed

- Public REST rate limiting now prefers the database-backed limiter when the
  new storage table is available, with the previous transient limiter retained
  as an upgrade-safe fallback.
- Bumped the database schema to `1.25.0` for the audit and rate-limit tables.

## 1.11.48 - 2026-07-08

### Changed

- Reduced the default key findings display to actionable critical, high, medium,
  and low entries, sorted by domain and then severity.
- Updated result CTA placement and styling so domain CTAs are capped at three,
  randomly distributed across eligible domains, and visually slot into the
  findings list with a right-edge accent.
- Removed the circular severity marker from public key findings.

## 1.11.47 - 2026-07-08

### Fixed

- Aligned public result gauge and domain-breakdown colours with the
  questionnaire's configured grade thresholds and grade colours.

## 1.11.46 - 2026-07-08

### Changed

- Renamed Call to Action "Scope" admin labels to "Domain" and removed the
  repeated domain slug from domain dropdown labels.
- Replaced per-row domain saves in the questionnaire editor with one master
  Save domains action.

## 1.11.45 - 2026-07-08

### Changed

- Replaced per-row grade saves with one master Save grades action in the
  questionnaire editor.
- Renamed answer-option and grade row actions from Delete to Remove to clarify
  that the row is being removed, not the parent question or questionnaire.

## 1.11.44 - 2026-07-07

### Fixed

- Cleared the plugin's private update metadata cache when WordPress clears its
  plugin update transient or when the Update Core screen is loaded, so the
  self-hosted updater detects freshly published releases promptly.
- Reduced the self-hosted update metadata cache from 12 hours to 30 minutes.

## 1.11.43 - 2026-07-07

### Added

- Added admin-managed category and domain call-to-action sections for public
  questionnaire results.
- Added Claude-powered remediation plan generation with downloadable workbook
  output for completed assessments.

### Fixed

- Preserved domain `brief` content during questionnaire import/export and
  questionnaire duplication.

### Changed

- Bumped the database schema to `1.24.0` for the new CTA storage table.

## 1.11.42 - 2026-07-07

### Changed

- Reissued the grade-colour release so the tag includes the wp-updates release
  workflow cleanup.
- Fixed the wp-updates deploy commit message to avoid a doubled `v` prefix and
  added a clearer preflight error when `WP_UPDATES_TOKEN` is missing.

## 1.11.41 - 2026-07-07

### Changed

- New questionnaires now start with the standard four grade thresholds:
  Strong, Moderate, Needs Attention, and High Risk, using the requested
  green, amber, red, and blue text/background palette.
- Public assessment results now colour the overall score gauge, grade pill,
  and domain breakdown bars from the questionnaire's configured grade
  thresholds instead of fixed percentage colour bands.

## 1.11.40 - 2026-07-07

### Changed

- Changed `[wpq_time ref="..."]` to return only the numeric minute estimate so
  page templates can supply their own surrounding copy.
- Documented `[wpq_minutes]` as a backwards-compatible alias for the numeric
  time shortcode and kept `[wpq_estimate]` for formatted "X minutes" output.

## 1.11.39 - 2026-07-07

### Added

- Added canonical `[wpq_questionnaire ref="..."]` shortcode for embedding a
  questionnaire, while keeping `[wpq_assessment]`, `[wpq_assessments]`, and
  `[wpq_product]` as backwards-compatible aliases.
- Added helper shortcodes for post/page copy: `[wpq_domains]`, `[wpq_time]`,
  `[wpq_submissions]`, and `[wpq_status]`.
- Expanded the Settings -> Shortcodes screen with copy/paste examples,
  editorial guidance, and per-questionnaire shortcode snippets.

### Changed

- Updated shortcode documentation to prefer `[wpq_questionnaire]` and list all
  available metadata helper shortcodes.

## 1.11.38 - 2026-07-07

### Fixed

- Fixed `single_option` radio questionnaire scoring when imported questions have
  `max_score` stored as `0`; those questions now derive their maximum score from
  answer options so overall and domain percentages calculate correctly.
- Updated the public results gauge and domain bars to display clamped percentage
  values with an explicit `%` suffix.
- Preserved blank/null max-score values during questionnaire import/export so
  option-scored questionnaires do not reintroduce zero denominators.

## 1.11.37 - 2026-07-06

### Changed

- Advanced the release version for a fresh GitHub release tag after the
  v1.11.36 release object already existed.

## 1.11.36 - 2026-07-06

### Fixed

- Question editor Save now persists answer options alongside the question fields,
  including newly pasted option rows.
- Public assessment answer layouts now use the wider panel space more effectively by
  capping option-grid columns to the actual option count and stretching answer cells.

### Changed

- Results copy now labels the findings section as "Key Findings".

## 1.11.35 - 2026-07-03

### Added

- **Consent persistence** - privacy consent acceptance is now stored server-side. A new
  `consent_accepted_at` column (DATETIME, nullable) is added to `wpq_submissions` via DB
  migration 1.23.0. When the lead form is submitted with the consent checkbox ticked, the
  server records the UTC timestamp against the submission row. The admin Contacts → record
  view displays "Privacy consent: ✓ Accepted dd Mon YYYY HH:mm" in the contact info card
  (earliest consent across all submissions), and a per-submission Consent column (✓ / -) in
  the submissions table.

## 1.11.34 - 2026-07-03

### Added

- **Privacy consent checkbox** - lead capture form now requires an explicit opt-in tick before
  submission. Label links to the WordPress privacy policy page (via `get_privacy_policy_url()`),
  falling back to a plain-text statement if no URL is configured. Satisfies EU GDPR informed
  consent requirements for processing personal data collected via the assessment form.

## 1.11.33 - 2026-07-02

### Added

- **`wpq_product` shortcode** - alias for `[wpq_assessment ref="…"]`; both names are now
  registered and fully interchangeable.
- **`wpq_minutes` shortcode** - returns the estimated completion time as a plain integer
  (minutes), e.g. `5`. Use when you need just the number without the "minutes" suffix (which
  `wpq_estimate` already provides as "5 minutes").

### Changed

- **Questionnaire status lifecycle** - the four lifecycle stages are now `draft → preview →
  live → retired` (replacing `draft / published / archived`):
  - **Draft** - questionnaire is being built; not accessible via shortcode; no Stripe product
    required or auto-created.
  - **Preview** - accessible via shortcode for internal testing; does not require Stripe.
  - **Live** - accessible via shortcode; saving with Live status auto-creates a Stripe Product
    if one does not yet exist.
  - **Retired** - shortcode returns nothing; Stripe Product is kept (not archived).
- **Stripe Product auto-create** - moved from "on every save" to "first save in Live status
  only". Creating or saving a Draft/Preview questionnaire no longer touches Stripe.
- **DB schema migration** (`WPQ_DB_VERSION 1.22.0`) - `wpq_questionnaires.status` ENUM updated
  from `(draft, published, archived)` to `(draft, preview, live, retired)`. Existing rows are
  migrated: `published → live`, `archived → retired`.
- Bulk action labels updated: "Publish" → "Go Live", "Archive" → "Retire",
  "Unarchive" → "Revert to Draft (Retired only)", "Remove" → "Remove (Retired only)".

## 1.11.32 - 2026-07-02

### Added

- **Stripe full lifecycle sync - questionnaires** - creating a questionnaire now auto-creates a
  Stripe Product (`prod_…`) and saves its ID back to the questionnaire. Saving a questionnaire
  (name or description change) updates the Stripe Product name/description. Bulk-removing an
  archived questionnaire archives the Stripe Product (`active: false`). If Stripe is not
  initialised the save proceeds unchanged.
- **Stripe full lifecycle sync - pricing options** - saving a pricing option (create or update)
  now auto-creates a Stripe Price (`price_…`) if the linked questionnaire has a Stripe Product
  and the Stripe Price field is empty. The amount and billing type (one-off, monthly, annual) are
  mapped automatically. Deleting a pricing option archives its Stripe Price first.
- **Delete pricing option** - a Delete button is now shown alongside Edit in the Pricing table.
  Clicking it confirms, archives the Stripe Price (if set), and removes the row from the DB.
  The Stripe Price ID field hint is updated to reflect auto-creation.

## 1.11.31 - 2026-07-02

### Fixed

- **Add Pricing Option - questionnaire dropdown** - questionnaires are now sorted alphabetically
  by name. The underlying `get_questionnaire_list()` query order (category, ref) is unchanged
  for other views; the sort is applied at the call site in `page-products.php`.

## 1.11.30 - 2026-07-02

### Changed

- **Questions editor - tip icon removed** - the floating ⓘ icon overlaid on the question textarea
  is removed from the admin UI; it served no purpose there. The Tip label and input field in the
  behaviour row are unchanged.
- **Questions editor - Tip input width** - Tip input now fills the remaining width of the behaviour
  row (flex: 1) rather than being a fixed 25em `regular-text` box, giving it roughly half the row.

## 1.11.29 - 2026-07-02

### Changed

- **Question number colour** - question number now renders in Alltime Dark Pink (`--wpq-pink`, `#E20979`)
  to match the Next button, replacing the previous muted grey.
- **Domains table - Brief column** - removed `regular-text` class from the Name input (it was forcing
  25em width and overflowing into the Brief column); Name input now fills its cell at `width:100%`.
  Name `<th>` widened to 200px; Brief `<th>` and `<td>` gain 12px left padding to create clear visual
  separation between columns.

## 1.11.28 - 2026-07-02

### Changed

- **Plugin update endpoint** - migrated from `gh-pages` branch in `wp-questionnaires` to a dedicated
  public `alltimeuk/wp-updates` repository. Each plugin deploys into its own subdirectory
  (`wp-questionnaires/`), enabling the same repo to serve multiple plugins without cross-plugin
  interference. `WPQ_Updater::UPDATE_URL` updated to
  `https://alltimeuk.github.io/wp-updates/wp-questionnaires/update.json`.
- **GitHub Actions deploy step** - switched from `github_token` + `force_orphan: true` to
  `personal_token: ${{ secrets.WP_UPDATES_TOKEN }}` + `external_repository: alltimeuk/wp-updates` +
  `destination_dir: wp-questionnaires` + `keep_files: true`. This preserves other plugins' directories
  on every push rather than wiping the entire repo.

## 1.11.27 - 2026-07-02

### Changed

- **Question font size** - both question number and question text reduced from 1.1rem to 1.05em,
  improving readability on mobile without sacrificing legibility on desktop.
- **Questions editor - recommendation field** - recommendation textarea is now placed adjacent to the
  question textarea in a 50/50 flex layout rather than below it; collapses to hidden automatically for
  question types that don't support recommendations.
- **Domains table alignment** - Brief textarea column cells are now top-aligned (`vertical-align: top`)
  so all inputs within a domain row sit at the top of the row rather than floating to the vertical centre.

### Fixed

- **PHPStan stubs** - added missing WordPress function stubs (`delete_transient`, `get_bloginfo`,
  `is_wp_error`, `wp_doing_cron`, `wp_remote_get`, `wp_remote_retrieve_response_code`,
  `wp_remote_retrieve_body`) and constants (`WPQ_PLUGIN_BASENAME`, `HOUR_IN_SECONDS`); fixed
  `add_action` stub to accept optional `$priority` and `$accepted_args` parameters.

## 1.11.26 - 2026-07-02

### Added

- **Plugin self-update** - `WPQ_Updater` hooks into WordPress's built-in update mechanism. The plugin
  polls `update.json` from the GitHub Pages endpoint (12 h cache on success, 1 h on failure) and
  injects available-update data into the `update_plugins` transient so site admins see standard WP
  update notifications and can use the native one-click update flow.
- **GitHub Pages update endpoint** - `release.yml` now deploys a `gh-pages` branch on every tagged
  release, publishing `update.json` (machine-readable version metadata), `wp-questionnaires-latest.zip`
  (the plugin ZIP, overwritten each release), and `index.html` (human-readable landing page).
- **Kill-switch constant** - define `WPQ_DISABLE_AUTO_UPDATE = true` in `wp-config.php` on staging or
  local environments to suppress automatic background updates; WordPress's per-plugin toggle is still
  respected when the constant is absent or false.

## 1.11.25 - 2026-07-02

### Changed

- **Question text colours** - both question number and question text set to `--wpq-text-mid` (#666666);
  removes the harsh near-black on question text and lifts the muted grey on the number so they match.

## 1.11.24 - 2026-07-02

### Changed

- **Question divider line** - colour changed from light grey to `--wpq-navy` (#2D2C94); 5 px extra
  padding/margin added above and below the line to improve readability between questions.
- **Form width** - max-width increased from 860 px to 1000 px; fully responsive on mobile.
- **Question number** - no space between "Q" and the digit (e.g. `Q1:` not `Q 1:`); font size
  raised to 1.1 rem to match the question text.
- **Tri-state / Boolean button gap** - column gap between answer buttons widened from 10 px to 30 px.

## 1.11.23 - 2026-07-02

### Added

- **Domain Brief** - new `brief` TEXT column on `wpq_domains`. Visible as a resizable textarea in the
  Domains tab (admin), right of the Name column. Supports up to ~5 paragraphs separated by blank lines.
- **Brief page in customer journey** - if a domain has a brief, a full-screen "brief page" is shown
  before the domain's questions each time the user enters that domain. User journey becomes:
  Lead form → Domain 1 Brief → Domain 1 Questions → Domain 2 Brief → Domain 2 Questions → … → Report.
  Domains with no brief skip straight to questions.
- **Back button** - fully wired. From a brief page: Back returns to the previous domain's questions
  (hidden on the first brief/question screen). From a questions page: Back goes to that domain's brief
  if one exists, otherwise to the previous domain's questions.
- DB migration block for `1.21.0` adds `brief TEXT NULL AFTER domain_weight` to `wpq_domains`.

## 1.11.22 - 2026-07-02

### Fixed

- **Import oversized file** - size check now fires instantly from `File.size`
  before the browser reads or parses the file. Previously the check ran after
  `JSON.parse` + `JSON.stringify` of the whole file, which caused the browser
  tab to freeze on very large files (e.g. 43 MB combined export) and surface a
  misleading "server unreachable" error instead of a clear size message.

## 1.11.21 - 2026-07-02

### Added

- **Collapsible domain sections** - clicking a domain heading (blue) collapses or expands all
  questions beneath it; question count shown in heading.
- **Reset Questions** button above the question list - two-step confirmation before deleting all
  questions for the questionnaire (new `wpq_reset_questions` AJAX endpoint).
- **Create Questions** form - specify domain + count, creates N empty questions sequentially via
  existing `wpq_add_question`, with live progress indicator.
- **Save/Delete buttons** moved to a right-aligned column adjacent to the question label, top-aligned.

### Changed

- Answer options column renamed "Finding action" → "Recommendation".

## 1.11.20 - 2026-07-02

### Changed

- **Question editor layout** - removed per-question domain dropdown (now a
  hidden field; domain assignment is shown in the section heading). Removed the
  "Type & behaviour" sub-heading. Type, Scoring mode, Required, and Tip controls
  are now a single bottom-aligned flex row with Tip moved inline as a 4th cell,
  eliminating the separate Tip row below.

### Fixed

- **Import oversized payload** - added pre-send 8 MB size check and an
  `httpError()` helper that surfaces HTTP status codes (including HTTP 413
  guidance to use smaller files) instead of a generic "Request failed" message.
  PHP-side: detects empty `$_POST` with non-zero `Content-Length` and returns an
  actionable error message rather than silently failing.

## 1.11.19 - 2026-07-01

### Added

- **Multi-file import** - the import drop-zone now accepts multiple JSON files
  at once. All files are read and analysed in sequence, then presented together
  so conflicts can be resolved in one pass before a single "Import N files"
  click processes them all.
- **Set all conflicts to** bar - a single "Set all conflicts to: [Skip |
  Overwrite] Apply to all" control above the conflict tables sets every
  per-row dropdown simultaneously, with individual rows still overridable.
- **Detailed import error reporting** - question-level failures now surface the
  exact MySQL error string (e.g. "Column 'condition_op' cannot be null"), the
  question ref/row number, and the count of failed rows per questionnaire.
  Errors are shown per-file in a collapsible `<details>` block, and a final
  collapsible summary lists every error across all files.

### Changed

- Import conflict table collapses (hides) after a file has been successfully
  imported; only the per-file badge (✓ N imported) and any errors remain
  visible, keeping the page readable when processing many files at once.

## 1.11.18 - 2026-07-01

### Fixed

- Import: questions failing to insert when `condition_op` is absent from the
  JSON - the column is `ENUM NOT NULL DEFAULT 'eq'` and MySQL 8 strict mode
  rejects a SQL NULL on a NOT NULL column, silently dropping every question row.
  Now defaults to `'eq'` when no value is supplied, matching the DB default.
  This was the root cause of CE-2026-V16 importing with domains but zero
  questions.

### Changed

- Results screen: verdict text (e.g. "Significant cyber security gaps
  identified. Immediate action required.") is now displayed in Alltime navy
  (`#2D2C94`) at 1.05 rem / medium weight so it stands out next to the score
  ring, rather than being muted grey at 0.95 rem.

## 1.11.17 - 2026-07-01

### Changed

- Submission detail page - **Result** section removed as a standalone card;
  score and grade are now shown as a single row inside the **Details** panel,
  colour-coded using the questionnaire's own grade threshold colours and
  displaying the configured grade label (e.g. "E") with the verdict text.
- **Domain Scores** - each domain row now has a collapsible `▶ N questions`
  toggle underneath it. Expanding it reveals a per-question sub-table showing
  the question ref, question text, and the answer the respondent gave.
  Answers to scored yes/no/partial questions are colour-coded (green / red /
  amber). Non-scoring questions are shown in muted text.

## 1.11.16 - 2026-07-01

### Changed

- Renamed "Key findings" section on the results screen to **Recommendations**.
- Recommendations cards redesigned: priority badge (Critical/Medium) and domain
  name are now separate elements; each card shows the question, the answer the
  respondent gave ("You answered: …"), and the recommendation text as distinct
  rows, making it clear what was asked, how it was answered, and what action
  is required.
- Removed the previous 5-item cap on recommendations so all findings from the
  assessment are surfaced, not just the top five.

### Added

- Filter controls above the Recommendations list. A **Severity** group filters
  by Critical / Medium; a **Domain** group (shown when findings span more than
  one domain) filters by domain name. The two groups are mutually exclusive -
  selecting a severity filter resets the domain filter to "All", and vice
  versa, so the respondent can browse one dimension at a time.

## 1.11.15 - 2026-07-01

### Added

- Client-side filter input on the Questionnaires, Coupons, and Pricing admin
  list tables. Typing in the "Filter…" box instantly narrows visible rows by
  matching against all text in each row (ref, name, status, Stripe ID, etc.).
  A live count shows "N of M shown" while a query is active.
  Contacts, Orders, and Submissions already had server-side search and are
  unchanged.

## 1.11.14 - 2026-07-01

### Fixed

- REST route regex for the questionnaire endpoint broadened from
  `[A-Z]{2,6}-?\d{1,6}` to `[A-Z][A-Z0-9_-]{1,29}`, allowing refs that
  contain letters after digits, longer prefixes, or underscores/hyphens in
  any position. Previously any non-standard ref silently produced a 404 from
  WordPress route matching even though the questionnaire existed in the DB.
- Assessment load error now shows the actual error code (e.g. `NOT_FOUND`,
  `[HTTP 404]`) instead of the generic connection message, making it easier
  to diagnose why a questionnaire failed to load.

## 1.11.13 - 2026-07-01

### Changed

- Question text font-size increased to `1.1rem` (was `11pt`).
- Answer option font-size increased to `1rem` across all input types: tri-state
  buttons, radio labels, checkbox labels, select, textarea, and short-text.
- Added `text-rendering: optimizeLegibility` and
  `-webkit-font-smoothing: subpixel-antialiased` to the questionnaire wrapper.
- Radio/checkbox grid columns changed from `repeat(N, max-content)` to
  `repeat(N, minmax(0, 1fr))` - options now fill the container width instead
  of overflowing when there are 4–5 long labels per row.

### Added

- "Next domain" now validates that all required visible questions in the current
  domain are answered before advancing. Unanswered questions are highlighted
  in red; the viewport scrolls to the first unanswered question automatically.
- Advancing to a new domain (or pressing "← Back") now smoothly scrolls the
  viewport back to the top of the questionnaire widget.
- Validation highlights clear automatically when the question is answered.

## 1.11.12 - 2026-07-01

### Added

- `WPQ_Stripe::has_test_checkout_session()` and `has_test_webhook_event()` - test-mode
  introspection helpers used by integration tests without exposing internal state.
- `CheckoutEndpointIntegrationTest` - 15 integration tests covering the full checkout
  validation chain: gate disabled, all server-side validation failures (submission, token,
  payment state, product), retry from failed/expired, and the happy-path with a mocked
  Stripe session.
- `WebhookEndpointIntegrationTest` - 12 integration tests covering webhook processing:
  missing/invalid signature, unsupported event types, completed/expired transitions,
  idempotency replay guard, currency/amount/metadata mismatch guards, and report
  generation on payment.
- `ReportDownloadIntegrationTest` - 7 integration tests covering the report download
  endpoint: no token, unpaid submission, valid token (triggers download header), token
  consumed after use, exhausted token, expired token, and cross-submission rejection.

### Fixed

- `is_checkout_feature_enabled()` and `implementation_ready_for_checkout()` now short-
  circuit to `true` when a test Stripe session is injected via
  `WPQ_Stripe::set_test_checkout_session()`, allowing integration tests to exercise the
  full checkout validation chain without real Stripe credentials.

## 1.11.11 - 2026-07-01

### Fixed

- `get_products_for_questionnaire` now filters out active products without a `stripe_price_id`,
  preventing a product card and checkout button appearing in the assessment UI for products that
  are not yet fully configured in Stripe. The server already rejected such requests with
  `PRODUCT_NOT_CONFIGURED`; this closes the frontend gap so the CTA is never shown.

## 1.11.10 - 2026-07-01

### Fixed

- REST route regex now accepts hyphenated refs (e.g. `QL-001`, `CS-01`); previously the pattern
  `[A-Z]{2,4}\d{2,4}` rejected any ref containing a hyphen, causing "We could not load the
  assessment" for all questionnaires imported from the batch files.
- Questionnaire bulk actions now include **Publish**, allowing imported questionnaires to be
  published in bulk without opening each one individually.

### Changed

- `wpq-import-batch-01.json` through `wpq-import-batch-06.json`: all 150 questionnaires changed
  from `"status": "draft"` to `"status": "published"` so they import as published by default.

## 1.11.9 - 2026-07-01

### Changed

- `ce-2026-danzell.json`: scoring and recommendations updated to align with the IASME Assessor
  Marking Scheme Danzell v9.0 (April 2026 edition).
  - **Auto-fail** (`finding_priority: critical`): A6.1 (unsupported OS), A6.4 (14-day OS/firmware patching),
    A6.5 (14-day application patching), A7.16 (admin MFA), A7.17 (user MFA).
  - **Non-compliance** (`finding_priority: medium`): A4.1–A4.7, A4.10, A5.1–A5.3, A5.5, A5.7–A5.9,
    A6.2, A6.3, A6.6, A7.2, A7.8, A7.9, A7.13, A8.1–A8.5. These allow up to 2 non-compliances
    across the whole assessment before certification is denied.
  - **Information-only** (`non_scoring`): A4.1.1, A4.9, A5.4, A7.14 corrected from scored to
    information-only - always marked compliant if answered, fail if blank.
  - All `recommendation` and `finding_action` fields updated with wording drawn directly from the
    IASME marking guide (requirement references, CE-compliant control descriptions).
  - Grade thresholds revised to reflect CE pass/fail structure: ≥95% = Compliant (≤2
    non-compliances), ≥85% = Minor Gaps, ≥70% = Significant Gaps, <70% = Non-Compliant.

## 1.11.8 - 2026-06-30

### Added

- `.sample_data/` directory containing questionnaire source data and pre-built WPQ JSON import files:
  - `ce-2026-danzell.json` - Cyber Essentials 2026 self-assessment (DANZELL v16, 106 questions across 8 domains, 38 scored) with extrapolated answer options, CE-compliant scoring, grade thresholds, and finding actions.
  - `wpq-import-batch-01.json` through `wpq-import-batch-06.json` - bulk import batches for the 150-questionnaire library (QL-001 to QL-150), 25 questionnaires per file.
  - Source xlsx files: `cyber_security_questionnaire_library.xlsx`, `_expanded.xlsx`, `_expanded_v2.xlsx`, `_expanded_v3.xlsx`.
  - `CE Marking Scheme and Assessor Guidance Danzell v9.0_GREEN 1.pdf` - IASME/NCSC assessor reference document.

## 1.11.7 - 2026-06-30

### Fixed

- Submission error banner is now dismissed (`hideError()`) on a successful submit, so a previous failed-validation warning no longer persists on the results screen.
- `single_option` (radio) questions now auto-generate a medium finding when the selected answer scores below the question maximum and no explicit `finding_priority`/`finding_action` is set on the option. Falls back to the question's `recommendation` field, or a derived sentence if that is also empty.

## 1.11.6 - 2026-06-30

### Fixed

- Radio/checkbox grid columns now use `max-content` so each column is exactly as wide as its longest label - no equal-width stretching, no wrapping. Grid is left-aligned within the question body with a 15 px column gap.

## 1.11.5 - 2026-06-30

### Fixed

- Radio and checkbox grid columns now use `minmax(max-content, 1fr)` so each column is at least as wide as its longest label, preventing text wrapping. Column gap reduced to 15 px.

## 1.11.4 - 2026-06-30

### Changed

- Select (combobox) now spans full width with rounded corners and consistent padding matching other input types.
- Short-text input no longer capped at 440 px - spans full width.
- Boolean and tri-state answer buttons are now centre-aligned within the question body.

## 1.11.3 - 2026-06-30

### Changed

- Radio and checkbox answer grids now use a dynamic column count based on the average option label length: 5 columns (≤ 50 chars), 4 (≤ 80), 3 (≤ 100), 2 (≤ 150), 1 (> 150). Column count is computed at render time in JS and applied as a `wpq-cols-N` class. Mobile (≤ 600 px) always collapses to a single column.

## 1.11.2 - 2026-06-30

### Fixed

- Radio and checkbox answer options now always render in a 2-column grid on desktop - changed from `repeat(auto-fill, minmax(180px, 1fr))` to `repeat(2, 1fr)` so the grid is stable regardless of the theme or page-builder column width.

## 1.11.1 - 2026-06-30

### Added

- **Import/Export on every list view** - Import and Export All buttons now appear in the top-right header of every admin list page (Questionnaires, Contacts, Orders, Pricing, Coupons, Settings).
- **Export Selected bulk action** - every table now has a checkbox column and an "Export selected" bulk action; selecting records and clicking GO POSTs the IDs to the export handler and triggers a browser file download.

### Fixed

- `$_POST['ids']` in `handle_export()` now correctly applies both `wp_unslash` and `sanitize_text_field` in a single pass, resolving the remaining PHPCS strict-security `InputNotSanitized` error.

## 1.11.0 - 2026-06-30

### Added

- **Import / Export** - new admin page (Settings → Import / Export) supporting full round-trip data transfer for all six entity types:
  - **Questionnaires** - full structure including domains, questions, answer options, and grade thresholds.
  - **Contacts & Submissions** - all submission data keyed by contact email.
  - **Orders** - payment session records linked to submissions and products.
  - **Pricing** - all product tiers, cross-referenced by questionnaire ref and slug.
  - **Coupons** - Stripe coupon/promo definitions with questionnaire and product linkage.
  - **Settings** - all 14 plugin option keys (Stripe + HaloPSA).
- Export: each entity type downloads as a dated JSON file via a dedicated admin-post handler (`wpq_export`).
- Import: drag-and-drop or file-browse upload; automatic conflict detection with per-record Skip / Overwrite resolution before applying; result summary shows imported and skipped counts plus any per-record errors.

## 1.10.4 - 2026-06-30

### Changed

- Answer options table: removed the "Active" column. All options are now always visible to respondents; `is_active` is hardcoded to 1 on save. Any options previously hidden (`is_active = 0`) are re-activated on upgrade (DB migration v1.20.0).

## 1.10.3 - 2026-06-30

### Changed

- Questionnaire Details tab: replaced the raw Price / Currency inputs with a read-only "Pricing" table that cross-references `wpq_products` for all price tiers linked to this questionnaire (name, billing type, GBP price, Stripe Price ID, status). A direct link to the Pricing admin page is included.

## 1.10.2 - 2026-06-29

### Changed

- Scoring tab: score inputs (Yes / Partial / No) are now displayed inline with their corresponding recommendation textarea rather than in separate columns. Each answer row shows its label, recommendation field, and score number in a single horizontal group. The separate Yes / Partial / No column headers have been removed.

## 1.10.1 - 2026-06-29

### Changed

- Scoring tab: "Guidance" column heading renamed to "Recommendations".
- Recommendation field placeholder updated to remove the word "Guidance".

## 1.10.0 - 2026-06-29

### Added

- **Guidance fields in Scoring tab**: Per-question guidance is now edited inside the scoring matrix rather than on the Questions editor page.
  - Boolean questions: separate True / False guidance fields.
  - Tri-state questions: separate Yes / Partial / No guidance fields.
  - Option-based questions (radio, select, checkbox): one guidance field per answer option.
  - Memo / non-scoring questions: no guidance fields (shown as "-").
- Database: `guidance_partial` column added to `wpq_questions`; `guidance` column added to `wpq_question_options` (migration v1.19.0).

### Changed

- Guidance fields removed from the Questions editor tab (they are now exclusively in the Scoring tab).
- Duplicate-questionnaire and export helpers carry the new `guidance_partial` and per-option `guidance` values through.

## 1.9.6 - 2026-06-29

### Changed

- Question numbering label changed from "QUESTION X OF Y" to "Q X:" and now appears inline with the question text (10 px gap, baseline-aligned) rather than on a separate line above it.
- Radio and checkbox option grids: strengthened CSS selector specificity (`.wpq-answers.wpq-answers-radio`) to guarantee the grid display overrides the parent flex rule on all browsers and WordPress caching configurations.

## 1.9.5 - 2026-06-29

### Fixed

- Key findings: label no longer shows the generic domain name "Questions" when no meaningful action text exists. The label now shows just the priority word ("Critical" / "Medium"); the finding body falls back to the question text when no recommendation or guidance is set. Questionnaires with proper recommendation text continue to show "Priority - Domain" as before.
- Scoring: `top_actions` now includes `question` so the JS can use the question text as a fallback body for library questionnaire findings.

## 1.9.4 - 2026-06-29

### Changed

- Radio and checkbox option lists now render in a responsive CSS grid (`auto-fill`, min 180 px per column) instead of a centred vertical stack. At typical desktop widths this produces 3–4 columns; narrows to 2 at tablet widths and 1 on mobile.
- Exclusive checkbox options (e.g. "None of these") span the full grid row and are separated by a hairline rule.
- Hint text ("Select up to N options") spans the full grid row via `grid-column: 1 / -1`.

## 1.9.3 - 2026-06-29

### Changed

- Admin menu: "All Submissions" → "Submissions", "Questionnaire Library" → "Questionnaires", "Pricing Catalogue" → "Pricing".
- Page headings updated to match: Questionnaires library page, questionnaire editor breadcrumb, and Pricing page.

## 1.9.2 - 2026-06-29

### Added

- **Library questionnaire scoring** (DB 1.18.0). All 18+ CSQ library questionnaires now ship with full scoring logic built in by default. Seven of the 15 template questions are scored per questionnaire:
  - Q04 / Q09 (`boolean`): Yes = 2, No = 0 - "Documented baseline" and "Exceptions recorded".
  - Q05 / Q06 (`sum_selected`, max 2): Each positive option scores 1 - "Control areas documented" and "Evidence available". Negative options ("None of these", "No evidence available") score 0.
  - Q07 (`single_option`, max 2): Review frequency - Never/Ad hoc = 0, Annually = 1, Monthly/Quarterly/Event-driven = 2.
  - Q08 (`single_option`, max 2): Maturity level - Not started/Informal = 0, Partially implemented = 1, Implemented/Managed = 2.
  - Q13 (`single_option`, max 2): Budget/project route - No budget/Unknown = 0, Under consideration = 1, Allocated/In progress = 2.
- `WPQ_Seeder::backfill_library_scoring()` - idempotent DB backfill that applies scoring modes and option scores to all existing library questions (`created_by_seed = 1, library_version IS NOT NULL`) that are still `non_scoring`. Runs automatically on plugin activation/upgrade.
- `WPQ_Questionnaire_Library_Importer::SCORING_DEFAULTS` and `OPTION_SCORE_DEFAULTS` constants - new imports get correct scoring applied at seed time without requiring the backfill.

## 1.9.1 - 2026-06-29

### Added

- **Orders admin page** (`wpq-orders` submenu). Read-only paginated sortable table of all Stripe payment sessions with contact email, contact name, questionnaire name, product name, payment status (colour-coded badge), amount, and truncated session ID.
- `WPQ_Database::get_orders()` and `WPQ_Database::count_orders()` - paginated/searchable query across `wpq_payment_sessions` joined to submissions, questionnaires, and products. Sortable by date, amount, status, or contact email.

### Fixed

- PHPStan `Variable on left side of ?? always exists and is not nullable` errors in `page-contacts.php` and `page-contact-detail.php`.
- PHPStan `Function paginate_links not found` and `Function add_query_arg invoked with 3 parameters` in Contacts list view.

## 1.9.0 - 2026-06-29

### Added

- **Contacts admin page** (`wpq-contacts` submenu). Aggregate view of all unique submitters grouped by email: submission count, completed count, paid count, last seen date, opt-out status. Searchable and sortable.
- **Contact detail page** (`?wpq_action=view&email=…`): contact info, full submission history, payment history, and a GDPR operations panel.
- **GDPR data-subject rights operations** on the contact detail page:
  - **Export data** - downloads all submission and payment data as a JSON file.
  - **Anonymise** - replaces name, email, company, phone, and IP address with anonymous placeholders. Scores preserved.
  - **Delete** - permanently hard-deletes all submissions for the contact and removes the contact preferences record.
  - **Mark opted-out / Remove opt-out** - records a marketing suppression preference without deleting data.
- `wpq_contact_preferences` DB table (DB 1.17.0): stores per-email opt-out preference with timestamp and acting user ID.
- `WPQ_Database` contact methods: `get_contacts()`, `count_contacts()`, `get_contact_submissions()`, `get_contact_payments()`, `export_contact_data()`, `anonymise_contact()`, `delete_contact()`, `get_contact_opt_out()`, `set_contact_opt_out()`.
- AJAX action `wpq_toggle_contact_opt_out`; POST handlers `wpq_export_contact`, `wpq_anonymise_contact`, `wpq_delete_contact`.

## 1.8.9 - 2026-06-29

### Added

- **Questionnaire Categories** managed from Settings → Categories tab (DB 1.16.0). New `wpq_categories` table with slug, name, and sort order. Ten pre-populated categories: Cyber Security, Data Privacy, Business Continuity, Risk & Compliance, Operational Resilience, IT Governance, Supplier Risk, Cloud Security, Physical Security, HR & People Security.
- Full AJAX CRUD in the Categories tab: add category (name auto-generates slug), inline edit (name and sort order), delete with confirmation.
- Questionnaire Library and New Questionnaire modal now populate the category dropdown from the DB instead of a hardcoded array.
- `WPQ_Database::seed_categories()`, `get_categories()`, `insert_category()`, `update_category()`, `delete_category()`, `category_slug_exists()`.
- AJAX actions: `wpq_create_category`, `wpq_update_category`, `wpq_delete_category`.

### Changed

- Existing `wpq_questionnaires.category` slugs are remapped on upgrade: `it_managed_services` → `it_governance`, `isms` / `business_management` / `risk_management` → `risk_compliance`.

## 1.8.8 - 2026-06-29

### Added

- Sortable columns on all admin tables: Questionnaire Library, Pricing Catalogue, and Coupons tables now support client-side column sorting (click any header to sort ascending/descending; action and checkbox columns excluded). Submissions table already had server-side sorting via `WP_List_Table`; extended to cover Contact, Questionnaire, Grade, Abandoned, HaloPSA Status, and UTM Source columns in addition to the existing Ref, Score, and Date columns.
- Renamed "Assessment Submissions" page heading to "Submissions".

## 1.8.7 - 2026-06-29

### Added

- **Coupons & Promo Codes** admin page (`wpq-coupons` submenu). Create Stripe coupons (percent off or fixed amount off) with optional customer-facing promotion codes, duration control, max redemptions, and expiry. Coupons can be scoped to all products, a specific questionnaire (Stripe Product), or a specific pricing catalogue item.
- `WPQ_Stripe::create_coupon()`, `create_promotion_code()`, `delete_coupon()` - Stripe SDK wrappers for coupon lifecycle management.
- `wpq_coupons` DB table (DB 1.15.0): stores coupon metadata locally alongside Stripe IDs for display and association tracking.
- `WPQ_Database::insert_coupon()`, `get_all_coupons()`, `get_coupon()`, `update_coupon()` - CRUD methods for the coupons table.
- AJAX actions `wpq_create_coupon` and `wpq_delete_coupon`: create/archive in Stripe with rollback on DB failure; delete gracefully handles already-archived Stripe coupons.

## 1.8.6 - 2026-06-29

### Added

- New `recommendation` field on `wpq_questions` (DB 1.14.0): stores the actionable text shown in the results report when a respondent answers No. Separate from `guidance_no`, which is the inline contextual help displayed to respondents during the questionnaire.
- `WPQ_Seeder::backfill_recommendation()`: idempotent migration that copies `guidance_no` → `recommendation` for every existing question where `recommendation` is empty and `guidance_no` is set, preserving current report output on upgrade.
- Recommendation textarea in the question editor (visible for `boolean`/`tri_state` types only, same row-visibility rule as Guidance). Placeholder text indicates it falls back to Guidance - No when left blank.

### Changed

- Scoring engine (`WPQ_Scoring`) now uses `recommendation` as the finding `action` text for `legacy_tri_state` and `boolean` questions; falls back to `guidance_no` when `recommendation` is empty (backward-compatible).
- `WPQ_Seeder::insert_q()` now seeds `recommendation` from the question's `recommendation` key, defaulting to `guidance_no` if not explicitly set.

## 1.8.5 - 2026-06-29

### Added

- `WPQ_Seeder::backfill_option_scores()`: idempotent enrichment pass that assigns default scores to every radio/checkbox/select/combobox question whose scoring mode is `single_option`, `sum_selected`, or `max_selected` and where ALL options currently have `score = 0`. `sum_selected` (checkbox) options each receive `score = 1`; `single_option`/`max_selected` (radio/select) options receive descending scores by sort order (first option = N-1, last = 0). Questions with any non-zero option score are left untouched.
- DB version bumped to 1.13.0 to trigger the backfill pass on existing installs.

### Fixed

- Question editor: new options added via `+ Add option` now default to `score = 1` instead of `0`, ensuring every option-based question contributes to the domain score from the moment options are added.

## 1.8.4 - 2026-06-29

### Fixed

- `.wpq-hidden` now uses `display: none !important` so utility-class visibility is never overridden by element-specific `display` rules (e.g. `.wpq-q-scores { display: flex }` was winning over `.wpq-hidden`).
- Question editor: Guidance Yes/No fields are now hidden for non-boolean/tri-state question types (radio, checkbox, select, memo), matching the same condition as the Scores row. Both PHP initial render and the JS type-change handler updated.
- Question editor: "Help text" label renamed to "Tip". An ⓘ icon appears to the right of the question textarea when a tip is set; it is hidden when no tip exists. Clicking the icon focuses the Tip input. The icon updates live as you type.

## 1.8.3 - 2026-06-26

### Fixed

- Question editor: options manager (`+ Add option` / edit / delete rows) is now always rendered in the DOM and toggled visible by the type dropdown. Previously it was conditionally omitted for non-option types (`tri_state`, `boolean`, `memo`), so switching a question to `radio`, `checkbox`, or `select` showed no options panel because the element did not exist.
- Question editor: "New Questionnaire" modal auto-opening on page load resolved by removing `display:flex` from the modal's static inline style - the CSS class `wpq-hidden` (`display:none`) was being overridden by the higher-specificity inline style.

## 1.8.2 - 2026-06-26

### Fixed

- `get_questionnaire_list()`: rewrote query to use non-correlated derived tables so each physical table is referenced exactly once, fixing MySQL "Can't reopen table" errors caused by the WordPress test suite's use of `TEMPORARY TABLE`.
- Library table Status column: replaced HTML-string `$status_labels` with CSS-class-based rendering to prevent WordPress escaping functions from outputting raw HTML.
- Library table Domains/Questions columns: use `(int)` cast instead of `absint()` (PHPStan lacked WordPress stubs for the view file).
- Library table Scoring/Grading tick/cross: use `esc_attr()` on class attribute and HTML entities for the symbol characters.
- `ajax_bulk_questionnaire_action()`: split compound one-liner statements onto separate lines to satisfy PHPCS `DisallowMultipleStatements`.

### Changed

- Admin menu: "Site Health" renamed to "Readiness".
- Admin menu: "Products" renamed to "Pricing Catalogue".
- Readiness page: title updated to "Readiness"; Payment Readiness section added (checkout flag, pricing configured, Stripe API, libraries, routes, report generation, token delivery).
- Pricing Catalogue page: Payment Readiness checklist moved to the Readiness page; page now shows only the pricing options table.
- All "Product/Products" labels in the Pricing Catalogue page and JS updated to "Pricing option/Pricing options".

## 1.8.1 - 2026-06-24

### Added

- Questionnaire Library table: Domains column (count), Questions column (count), Scoring column (✓ if any scored questions exist), Grading column (✓ if grade thresholds exist).
- `WPQ_Seeder::enrich_library_questionnaires()`: idempotently adds a default "Questions" domain and A–E grade thresholds to any questionnaire missing them.
- `WPQ_Database::get_questionnaire_list()` now returns `domain_count`, `question_count`, `grade_count`, and `scored_question_count` via subqueries.

### Changed

- DB schema version bumped to `1.12.0` to trigger `enrich_library_questionnaires()` on existing installs.

## 1.8.0 - 2026-06-24

### Added

- `stripe_price` (INT pence) and `stripe_currency` (VARCHAR 3, default GBP) columns on `wpq_questionnaires`.
- `domain_weight` (SMALLINT, default 100) column on `wpq_domains`.
- `question_weight` (SMALLINT, default 100) column on `wpq_questions`.
- Questionnaire Library: NEW button with modal to create a blank questionnaire.
- Questionnaire Library: per-row SELECT checkboxes with ACTIONS dropdown + GO button (Archive, Unarchive, Remove, Duplicate).
- Questionnaire Library: price rendered as currency symbol + value (e.g. `£ 49.99`).
- Questionnaire editor: split into 5 tabs - Details, Domains, Questions, Scoring, Grades.
- Details tab: Stripe Price and Currency fields.
- Domains tab: ADD / EDIT / REMOVE domains; auto-labelled A, B, C… by sort order.
- Questions tab: domain selector per question; question label shows domain + position (e.g. C2); Add Question and Delete Question per domain.
- Scoring tab: Domain Weights table; Question Scoring Matrix (per-question weight + answer scores inline).
- Grades tab: grade thresholds table (unchanged content, now its own tab).
- `WPQ_Database::delete_domain()`, `delete_question()`, `delete_questionnaire()`, `duplicate_questionnaire()`.
- AJAX actions: `wpq_create_questionnaire`, `wpq_bulk_questionnaire_action`, `wpq_add_domain`, `wpq_update_domain`, `wpq_delete_domain`, `wpq_save_domain_weight`, `wpq_add_question`, `wpq_delete_question`, `wpq_save_question_scoring`.

### Changed

- `wpq_save_questionnaire` AJAX now accepts `stripe_price` and `stripe_currency`.
- `wpq_save_question` AJAX now accepts optional `domain_id` (moves question to a different domain).
- DB schema version bumped to `1.11.0`.

## 1.7.4 - 2026-06-24

### Added

- `[wpq_title ref="CSQ001"]` shortcode: returns the questionnaire name (published only).
- `[wpq_description ref="CSQ001"]` shortcode: returns the questionnaire description (published only).
- `[wpq_questions ref="CSQ001"]` shortcode: returns the total question count.
- `[wpq_estimate ref="CSQ001"]` shortcode: returns estimated completion time - 42 s per question, rounded up, formatted as "X minutes".
- `stripe_product_id` column on `wpq_questionnaires`: stores the Stripe Product ID for each questionnaire.
- Stripe Product ID is visible in the Questionnaire Library table and editable from the questionnaire Details tab.

### Changed

- DB schema version bumped to `1.10.0`.

## 1.7.3 - 2026-06-24

### Changed

- Questionnaire title (`.wpq-step-header h2`): Poppins, weight 600, 1.6 em.

## 1.7.2 - 2026-06-24

### Fixed

- `white-space: normal` added to `.wpq-wrap` - prevents the ~500 px blank-space bug that occurs when the shortcode is placed inside a Gutenberg "Preformatted" (`<pre>`) block, which sets `white-space: preserve` and renders every blank line in the plugin template as visible space.
- Removed `min-height: 200px` from `.wpq-wrap` (unnecessary now that all hidden steps use `display: none`).

## 1.7.1 - 2026-06-24

### Fixed

- Reduced excess whitespace in the lead capture step: `step-header` margin-bottom 32 → 16 px, lead form padding 32 → 20/24 px, loading spinner padding 60 → 32 px.

## 1.7.0 - 2026-06-24

### Changed

- Assessment frontend completely restyled.
- Questions rendered in Poppins 11 pt; all answer controls, buttons, and inputs in Aptos 10 pt.
- Help text replaced by an inline `ⓘ` icon adjacent to the question; tooltip reveals on hover or keyboard focus - no longer always visible.
- Yes/No and tri-state answer buttons vertically centred within their row.
- Memo textarea expands to full panel width; character counter sits right-aligned below it.
- Select, radio, checkbox, and short-text inputs styled consistently (Aptos, matching border/focus-ring treatment).
- Single-domain questionnaires hide the domain tab bar and redundant domain heading automatically.
- Question panel padding reduced (28 → 20 px), question spacing reduced (28 → 20 px), domain-heading margin tightened (24 → 16 px), minimum panel height removed.
- Grade threshold editor: `+ Add Grade` and `Delete` buttons added to Scoring & Grades tab in the questionnaire editor.

## 1.6.2 - 2026-06-24

### Added

- Grade threshold management in the questionnaire editor: new `+ Add Grade` button creates a default grade row inline without a page reload; new `Delete` button on each row removes it with a confirmation prompt.

## 1.6.1 - 2026-06-24

### Fixed

- `condition_op NOT NULL` constraint violation: CS01 seeder was passing explicit `NULL` for `condition_op` on questions without conditional visibility; MySQL strict mode rejected this even though the column has `DEFAULT 'eq'`. Fixed by defaulting to `'eq'` in `insert_q()`.
- `[wpq_assessment ref="CSQxxx"]` shortcodes showed "Assessment not found": library questionnaires were seeded as `draft` but `get_questionnaire_by_ref()` requires `status = 'published'`. Fixed by seeding library questionnaires as `published` and promoting any existing `draft` library records on activation.
- REST questionnaire route regex (`[A-Z]{2}-\d{2}`) rejected `CS01` and all `CSQ001`–`CSQ150` refs. Widened to `[A-Z]{2,4}\d{2,4}`.
- Integration tests used old `CS-01` ref throughout; updated to `CS01`.

## 1.6.0 - 2026-06-24

### Added

- Cyber Security Questionnaire Library (`1.0.0`): 150 questionnaires, 2,250 questions, 10,750 options imported from `cyber_security_questionnaire_library.xlsx` and committed as `includes/data/questionnaire-library-1.0.0.php`.
- New `WPQ_Questionnaire_Library_Importer` class: reads the committed seed data file and inserts questionnaires idempotently on activation. Skips questionnaires already owned by the library (`created_by_seed = 1`) and never overwrites customised records (`is_customised = 1`).
- New question type `number`: free-form numeric input; always resolves to `non_scoring`; validated with `is_numeric()`.
- DB migration `1.9.0`: new columns on `wpq_questionnaires` (`source_type`, `source_sheet`, `library_version`, `library_id`, `library_family`, `created_by_seed`, `is_customised`); new columns on `wpq_questions` (`answer_type_raw`, `created_by_seed`, `library_version`); `number` added to the `question_type` ENUM; new column `created_by_seed` on `wpq_question_options`; new `wpq_library_log` table for diagnostics.
- `WPQ_Seeder::seed_library()`: called on activation after CS01 seeding; delegates to `WPQ_Questionnaire_Library_Importer::import()`.
- Library questionnaires seeded with `status = 'draft'` and default `scoring_mode = 'non_scoring'`; each gets a single auto-created domain with `slug = 'general'`.
- Column E guidance preserved as `help_text` on each question.
- 41 PHPUnit test cases in `tests/Unit/LibraryTest.php` covering seed file structure, data completeness, type mapping, option fidelity, idempotency, scoring engine compatibility, and legacy backwards compatibility.
- `includes/data/` excluded from PHPCS scanning (generated file; causes OOM in the duplicate-key sniff).

### Changed

- Plugin version bumped to `1.6.0`; DB version to `1.9.0`.
- `WPQ_Scoring::resolve_scoring_mode()`: `number` joins `memo` and `short_text` as always `non_scoring`.
- `WPQ_Scoring::validate()`: `number` case added - rejects non-numeric input.
- `WPQ_Admin::$valid_types`: `number` added to the admin question-type selector.
- `WPQ_Questionnaire_Library_Importer::import()` uses `WPQ_PLUGIN_DIR` constant instead of `plugin_dir_path()` for test compatibility.

### Backwards Compatibility

- Existing CS01 (DANZELL CE 2026) is not affected by the library import; library uses separate `CSQ001–CSQ150` refs.
- All prior submissions, scores, and questionnaire customisations are preserved.
- New columns are nullable or have zero defaults; existing records continue to function without change.

## 1.5.0 - 2026-06-24

### Added

- New question type `short_text` (free-text single-line input, always `non_scoring`).
- New scoring mode `reverse_boolean`: answering "no" is compliant and scores `score_no` points; answering "yes" triggers a finding using `guidance_yes` as the action text.
- New columns on `wpq_questions`: `question_ref` (display reference e.g. `A4.3`), `min_selections`, `max_selections` (checkbox cardinality enforcement), `condition_on_ref`, `condition_value`, `condition_op` (conditional visibility by ref string; resolved to `di_qi` key in `get_questionnaire_structure()`).
- New columns on `wpq_question_options`: `requires_notes` (free-text note required when option selected), `exclusive` (selecting this option invalidates all other selections).
- Source metadata columns on `wpq_questionnaires`: `source_name`, `source_question_set`, `source_effective_date`, `source_version`, `source_file` - supports questionnaire library versioning.
- Conditional visibility in the frontend assessment: questions with `condition` are shown or hidden based on the referenced question's current answer; hidden questions are excluded from scoring and validation.
- CyberCheck - Security Assessment (`CS01`) seeded with the full Cyber Essentials 2026 DANZELL self-assessment question set (Version 16, effective 27 April 2026): 10 domains, 76 questions, grade thresholds at 90 / 70 / 50 / 0 percent, and two products (CyberCheck Professional Report £49, CyberCheck Annual Plan £99).
- `WPQ_Seeder::seed_cs01_update()` public method to bump source metadata when a newer question-set version is available.

### Changed

- DB schema version bumped to `1.8.0`.
- `WPQ_Seeder::seed_all()` now checks for `CS01` (was `CS-01`).
- Existing `CS-01` questionnaire ref renamed to `CS01` via migration on first activation after upgrade.
- `WPQ_Scoring::validate()` enforces `min_selections` / `max_selections` for checkbox questions and the `exclusive` flag; hidden (condition-not-met) questions are skipped.
- `WPQ_Scoring::score()` skips hidden questions; `reverse_boolean` mode scores `score_no` on "no" and records a finding on "yes".
- Frontend assessment sends `question_ref` alongside `domain_slug` and `question_index` in answer payloads to support ref-based condition resolution.

### Backwards Compatibility

- All existing questionnaire data, submissions, and scoring results are unaffected.
- New columns are nullable or have zero defaults; existing questions without the new fields continue to function as before.

## 1.4.0 - 2026-06-23

### Added

- Introduced a multi-type question model extending the legacy `tri_state` (Yes / Partial / No) model with `boolean`, `select`, `radio`, `checkbox`, and `memo` question types.
- Added `wpq_question_options` table for option-based answer types; supports `option_key`, `option_label`, `score`, `risk_level`, `finding_priority`, `finding_action`, `sort_order`, `is_default`, and `is_active`.
- New columns on `wpq_questions`: `question_type`, `is_required`, `scoring_mode`, `max_score`, `help_text`.
- Six scoring modes: `legacy_tri_state`, `boolean`, `single_option`, `sum_selected`, `max_selected`, `non_scoring`.
- Type-aware validation in `WPQ_Scoring::validate()`: `boolean` rejects `partial`; `select`/`radio` validate against active option keys; `checkbox` accepts arrays; `memo` sanitises strings and enforces max length.
- Updated scoring engine to handle all six modes; `non_scoring` questions excluded from denominator.
- Public questionnaire REST response now includes `question_type`, `is_required`, `scoring_mode`, `max_score`, and active options per question.
- Frontend assessment renders question-type-specific controls: Yes/Partial/No buttons, Yes/No buttons, `<select>`, radio inputs, checkboxes, and textarea.
- Admin questionnaire editor now exposes question type selector, is-required toggle, scoring mode, max score, help text, and an inline options manager for option-based types.
- New admin AJAX handlers: `wpq_save_question_option`, `wpq_delete_question_option`.

### Changed

- DB schema version is now `1.7.0`.
- `WPQ_Scoring::validate()` and `::score()` are now type-aware; all existing `tri_state` questions remain fully backwards-compatible.
- `WPQ_Database::get_questionnaire_structure()` includes new question fields and active options.

### Backwards Compatibility

- Existing `tri_state` questions (without `question_type`) default to `legacy_tri_state` scoring; no data loss.
- Legacy `score_yes`, `score_partial`, `score_no` columns preserved; not removed in this phase.
- Existing `answers_json` remains readable.

## 1.3.1 - 2026-06-23

### Fixed

- Fatal error on activation: `WPQ_Submissions_Table::extra_tablenav` and `column_default` declared narrower parameter types than `WP_List_Table`, which PHP 8.0+ enforces as a fatal incompatibility.
- `table_exists()` now uses `SELECT 1 FROM table LIMIT 0` with `suppress_errors()` instead of `SHOW TABLES LIKE`, eliminating MySQL 8.0 LIKE-pattern escaping false negatives.
- Integration tests: replaced `INFORMATION_SCHEMA.COLUMNS` queries with `SHOW COLUMNS FROM … LIKE`, since the WordPress test framework creates temporary tables that `INFORMATION_SCHEMA` does not expose.

### Changed

- GitHub Actions bumped to Node.js 24-compatible versions: `actions/checkout@v7`, `actions/cache@v6`, `actions/upload-artifact@v7`.
- Release workflow now creates a GitHub Release with the ZIP attached when triggered by a `v*` tag; `workflow_dispatch` from a branch runs checks only.

## 1.3.0 - 2026-06-22

### Added

- Implemented Phase 3 one-off Stripe Checkout flow for completed assessments.
- Added `POST /wpq/v1/checkout`, `POST /wpq/v1/stripe/webhook`, and `GET /wpq/v1/reports/{id}`.
- Added Stripe SDK wrapper for Checkout Session creation and webhook signature verification.
- Added Dompdf report rendering, plugin-owned report storage, and signed report-token delivery.
- Added `wpq_report_tokens` for hashed, expiring report download tokens.
- Added expected `amount_total` and `currency` fields to `wpq_payment_sessions`.
- Added report reference fields to submissions: `report_product_id`, `report_path`, `report_generated_at`, and `report_error`.
- Added admin submission payment/report visibility.
- Added production readiness dashboard at Settings → Site Health, aggregating plugin version, DB version, schema health, Stripe configuration, report storage, REST routes, HaloPSA API role, submission sync counts, and recent migration errors.
- Expanded HaloPSA sync state machine from 4 to 8 states: `pending`, `processing`, `synced`, `failed`, `retry_pending`, `ignored`, `manual_review`, `skipped`.
- Added `halopsa_last_attempted_at`, `halopsa_retry_count`, and `halopsa_sync_error` columns to `wpq_submissions` to support external pull-worker operation.
- Added `POST /wpq/v1/api/submissions/{id}/start` - claims a submission for processing, transitions to `processing`, and records the attempt timestamp; rejects terminal states with HTTP 409.
- Added `POST /wpq/v1/api/submissions/{id}/fail` - records a failed sync attempt; `"retry": true` queues the submission as `retry_pending`, `"retry": false` marks it permanently `failed`.
- Pending submission export (`GET /wpq/v1/api/submissions/pending`) now includes `retry_pending` submissions alongside `pending` ones.
- Added bin/check-versions.sh version-alignment script; CI enforces plugin header == WPQ_VERSION constant == CHANGELOG heading on every push; release workflow additionally enforces tag match and no ## Unreleased section.
- Added WordPress integration test suite (`tests/integration/`) covering role/capability creation, REST authentication (401/403/200), public endpoint payload validation, schema migration verification, report-token lifecycle, and Stripe webhook idempotency. CI provisions a MySQL service and runs the suite automatically.
- Improved admin Settings UX: section-specific save confirmations, per-field Stripe key format feedback, diagnostics JSON export, copy-to-clipboard buttons for API endpoint URLs, test-access curl guide, and full pull-worker lifecycle example.
- Added data retention controls: configurable purge threshold for abandoned sessions, configurable anonymisation threshold for completed assessments (preserves scores), CSV export of purgeable submissions before purging, per-operation confirmation dialogs, and retention diagnostics in Settings → Advanced.

### Changed

- Database schema version is now `1.6.0`.
- Public product exposure remains gated by `WPQ_CHECKOUT_ENABLED` plus all Phase 3 capability checks.
- Payment remains webhook-confirmed only; checkout redirect success does not mark submissions as paid.

### Migration Notes

- Existing payment sessions gain nullable `amount_total` and `currency` columns.
- Existing submissions gain nullable report reference/error columns.
- New installs and upgrades create `wpq_report_tokens`.
- Existing `halopsa_sync_status` ENUM is widened to 8 values; `halopsa_last_attempted_at`, `halopsa_retry_count`, and `halopsa_sync_error` are added with safe defaults and no data loss.

### Upgrade Notes

- Configure Stripe keys and webhook secret via constants/environment variables where possible.
- Set `WPQ_CHECKOUT_ENABLED` only after confirming Settings → Site Health and checkout readiness are green.

### Rollback Notes

- Back up the database and generated reports before downgrading from DB version `1.6.0`.

## 1.2.0 - 2026-06-20

- Plugin version: 1.2.0.
- Database schema version: 1.4.0.

### Added

- Added security-focused CI checks, PHPStan, PHPUnit suites, and release ZIP automation.
- Added migration diagnostics for DB version, migration errors, expired sessions, and schema health.
- Added soft-delete support for submissions and centralized payment status transitions.
- Added checkout readiness checks for required routes, Stripe/Dompdf libraries, and Stripe secret resolution.
- Added a release manifest (`release.json`) to release ZIPs with commit, ref, build time, plugin version, and DB version.
- Added diagnostics-only strict schema checks for critical indexes, column types, enum values, and nullability.
- Added packaged-plugin smoke loading to the release workflow.
- Added `wpq_payment_events` for future Stripe webhook idempotency and audit trails.
- Added payment-event database helpers for webhook idempotency and processing audit records.
- Added `Phase3Spec.md` covering checkout, webhook, and report-delivery route contracts.

### Changed

- Stripe publishable key, secret key, and webhook secret now resolve from plugin constants first, server environment variables second, and WordPress options last.
- Product slugs remain immutable when products are renamed.
- Checkout readiness now labels Phase 3 endpoint handlers as intentionally not implemented instead of generic missing routes.
- Release ZIP builds now validate extracted version metadata, packaged PHP syntax, required packaged files, and `release.json`.
- Public product exposure now requires the full Phase 3 checkout capability contract, not only `WPQ_CHECKOUT_ENABLED`.
- Payment sessions now use the same payment status vocabulary as submissions: `none`, `pending`, `paid`, `failed`, and `expired`.

### Security Fixes

- Admin submission delete actions now report actual successful and failed soft-delete counts.
- Checkout readiness no longer treats stored option values alone as production readiness.

### Migration Notes

- Schema upgrades target DB version 1.4.0.
- Migration diagnostics report missing tables/columns and recorded migration errors.
- Older in-progress plaintext session tokens may be expired during the token-hash migration.
- Older payment-session rows using `unpaid` are migrated to `pending`.

### Breaking Changes

- None currently expected for public questionnaire embeds.

### Upgrade Notes

- Review Settings -> Diagnostics after deployment and confirm the installed DB version matches 1.4.0.
- Prefer `WPQ_STRIPE_SECRET_KEY` or `STRIPE_SECRET_KEY` for production Stripe secrets instead of storing secrets in WordPress options.

### Rollback Notes

- Back up the WordPress database before upgrading production sites.
- If rolling back after a schema migration, verify custom table compatibility manually before reactivating an older plugin build.

Compatibility notes:

- Requires PHP 8.1+ and WordPress 6.4+.
- Current database schema version: 1.4.0.
