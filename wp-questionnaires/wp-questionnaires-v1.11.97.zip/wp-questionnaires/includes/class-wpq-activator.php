<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Activator {
	private const MIGRATION_LOG_OPTION = 'wpq_migration_log';
	private const ADMIN_CAPABILITIES = [
		'wpq_view_submissions',
		'wpq_manage_submissions',
		'wpq_manage_questionnaires',
		'wpq_manage_products',
		'wpq_manage_settings',
		'wpq_view_reports',
		'wpq_export_data',
		'wpq_manage_integrations',
	];

	/** @var array<int, string> */
	private static array $migration_errors = [];

	private static int $expired_session_count = 0;

	public static function activate(): void {
		self::install_or_upgrade();
	}

	public static function ensure_schema_current(): void {
		if ( get_option( 'wpq_db_version', '0' ) === WPQ_DB_VERSION ) {
			return;
		}

		self::install_or_upgrade();
	}

	public static function get_migration_diagnostics(): array {
		$log = get_option( self::MIGRATION_LOG_OPTION, [] );
		if ( ! is_array( $log ) ) {
			$log = [];
		}
		if ( isset( $log['last_migration_errors'] ) && ! is_array( $log['last_migration_errors'] ) ) {
			$log['last_migration_errors'] = [ (string) $log['last_migration_errors'] ];
		}

		return array_merge(
			[
				'installed_db_version'  => get_option( 'wpq_db_version', '0' ),
				'target_db_version'     => WPQ_DB_VERSION,
				'last_migration_run'    => '',
				'last_migration_error'  => '',
				'last_migration_errors' => [],
				'expired_session_count' => 0,
				'table_health'          => [],
				'strict_schema_health'   => [],
			],
			$log,
			[
				'table_health'        => self::get_schema_health(),
				'strict_schema_health' => self::get_strict_schema_health(),
			]
		);
	}

	private static function install_or_upgrade(): void {
		$installed = get_option( 'wpq_db_version', '0' );
		self::$migration_errors = [];
		self::$expired_session_count = 0;

		self::write_migration_log( [
			'installed_db_version'  => $installed,
			'target_db_version'     => WPQ_DB_VERSION,
			'last_migration_run'    => current_time( 'mysql', true ),
			'last_migration_error'  => '',
			'expired_session_count' => 0,
		] );

		try {
			self::create_tables();
			self::record_db_error( 'create_tables' );
			self::maybe_migrate();
			self::create_roles();

			// Seed CS01 if it does not already exist (check by ref, not table emptiness).
			if ( ! WPQ_Database::get_questionnaire_any_status_by_ref( 'CS01' ) ) {
				WPQ_Seeder::seed_all();
				self::record_db_error( 'seed_questionnaire' );
			}

			// Keep sample questionnaires opt-in. Demo/library payloads live outside
			// the packaged plugin and must not be reseeded during routine updates.

			// Enrich existing questionnaires: add default domains and grade thresholds where missing.
			WPQ_Seeder::enrich_library_questionnaires();
			self::record_db_error( 'enrich_library_questionnaires' );

			// Backfill default option scores for radio/checkbox/select questions where all scores are 0.
			WPQ_Seeder::backfill_option_scores();
			self::record_db_error( 'backfill_option_scores' );

			WPQ_Seeder::backfill_recommendation();
			self::record_db_error( 'backfill_recommendation' );

			WPQ_Seeder::backfill_library_scoring();
			self::record_db_error( 'backfill_library_scoring' );

			WPQ_Database::seed_categories();
			self::record_db_error( 'seed_categories' );

			if ( ! empty( self::$migration_errors ) ) {
				self::write_migration_log( [
					'installed_db_version'  => $installed,
					'target_db_version'     => WPQ_DB_VERSION,
					'last_migration_run'    => current_time( 'mysql', true ),
					'last_migration_error'  => implode( '; ', self::$migration_errors ),
					'last_migration_errors' => self::$migration_errors,
					'expired_session_count' => self::$expired_session_count,
				] );
				return;
			}

			update_option( 'wpq_db_version', WPQ_DB_VERSION );

			self::write_migration_log( [
				'installed_db_version'  => WPQ_DB_VERSION,
				'target_db_version'     => WPQ_DB_VERSION,
				'last_migration_run'    => current_time( 'mysql', true ),
				'last_migration_error'  => '',
				'last_migration_errors' => [],
				'expired_session_count' => self::$expired_session_count,
			] );
		} catch ( Throwable $e ) {
			self::write_migration_log( [
				'installed_db_version'  => $installed,
				'target_db_version'     => WPQ_DB_VERSION,
				'last_migration_run'    => current_time( 'mysql', true ),
				'last_migration_error'  => $e->getMessage(),
				'last_migration_errors' => [ $e->getMessage() ],
				'expired_session_count' => self::$expired_session_count,
			] );
			throw $e;
		}
	}

	private static function maybe_migrate(): void {
		$installed = get_option( 'wpq_db_version', '0' );
		$had_prior_version = $installed !== '0';
		if ( version_compare( $installed, '1.1.0', '<' ) ) {
			global $wpdb;
			// halopsa_lead_id was INT — widen to VARCHAR(100) to hold non-numeric IDs like "HALO-4421".
			$table = $wpdb->prefix . 'wpq_submissions';
			if ( self::column_exists( $table, 'halopsa_lead_id' ) ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
				$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $table ) . ' MODIFY COLUMN `halopsa_lead_id` VARCHAR(100) NULL' );
				self::record_db_error( 'migrate_halopsa_lead_id' );
			}
		}
		if ( version_compare( $installed, '1.2.0', '<' ) ) {
			global $wpdb;
			// Add soft-delete columns so admin deletes are recoverable.
			$table = $wpdb->prefix . 'wpq_submissions';
			self::add_column_if_missing( $table, 'deleted_at', 'DATETIME NULL AFTER `abandoned`' );
			self::add_column_if_missing( $table, 'deleted_by_user_id', 'BIGINT NULL AFTER `deleted_at`' );
			if ( $had_prior_version ) {
				self::expire_in_progress_session_tokens( $table );
			}
		}
		if ( $had_prior_version && version_compare( $installed, '1.4.0', '<' ) ) {
			global $wpdb;
			$table = $wpdb->prefix . 'wpq_payment_sessions';
			if ( self::table_exists( $table ) && self::column_exists( $table, 'payment_status' ) ) {
				// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
				$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $table ) . " MODIFY COLUMN `payment_status` ENUM('none','pending','paid','failed','expired','unpaid') NOT NULL DEFAULT 'pending'" );
				self::record_db_error( 'migrate_payment_sessions_status_superset' );
				$wpdb->query( 'UPDATE ' . self::quote_identifier( $table ) . " SET `payment_status` = 'pending' WHERE `payment_status` = 'unpaid'" );
				self::record_db_error( 'migrate_payment_sessions_unpaid_to_pending' );
				$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $table ) . " MODIFY COLUMN `payment_status` ENUM('none','pending','paid','failed','expired') NOT NULL DEFAULT 'pending'" );
				self::record_db_error( 'migrate_payment_sessions_status_final' );
				// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared
			}
		}
		if ( $had_prior_version && version_compare( $installed, '1.5.0', '<' ) ) {
			global $wpdb;
			$payment_sessions = $wpdb->prefix . 'wpq_payment_sessions';
			self::add_column_if_missing( $payment_sessions, 'amount_total', 'BIGINT NULL AFTER `answers_hash`' );
			self::add_column_if_missing( $payment_sessions, 'currency', 'VARCHAR(10) NULL AFTER `amount_total`' );

			$submissions = $wpdb->prefix . 'wpq_submissions';
			self::add_column_if_missing( $submissions, 'report_product_id', 'INT UNSIGNED NULL AFTER `stripe_session_id`' );
			self::add_column_if_missing( $submissions, 'report_path', 'VARCHAR(500) NULL AFTER `report_product_id`' );
			self::add_column_if_missing( $submissions, 'report_generated_at', 'DATETIME NULL AFTER `report_path`' );
			self::add_column_if_missing( $submissions, 'report_error', 'TEXT NULL AFTER `report_generated_at`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.6.0', '<' ) ) {
			global $wpdb;
			$submissions = $wpdb->prefix . 'wpq_submissions';
			// Expand halopsa_sync_status ENUM first (superset) so new column values are valid
			// before adding the new lifecycle columns.
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
			$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $submissions ) . " MODIFY COLUMN `halopsa_sync_status` ENUM('pending','processing','synced','failed','retry_pending','ignored','manual_review','skipped') NOT NULL DEFAULT 'pending'" );
			self::record_db_error( 'migrate_halopsa_sync_status_enum_1_6_0' );
			// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared
			self::add_column_if_missing( $submissions, 'halopsa_last_attempted_at', 'DATETIME NULL AFTER `halopsa_synced_at`' );
			self::add_column_if_missing( $submissions, 'halopsa_retry_count', 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER `halopsa_last_attempted_at`' );
			self::add_column_if_missing( $submissions, 'halopsa_sync_error', 'TEXT NULL AFTER `halopsa_retry_count`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.7.0', '<' ) ) {
			global $wpdb;
			$questions = $wpdb->prefix . 'wpq_questions';
			self::add_column_if_missing( $questions, 'question_type', "ENUM('tri_state','boolean','select','radio','checkbox','memo') NOT NULL DEFAULT 'tri_state' AFTER `score_no`" );
			self::add_column_if_missing( $questions, 'is_required',   'TINYINT(1) NOT NULL DEFAULT 1 AFTER `question_type`' );
			self::add_column_if_missing( $questions, 'scoring_mode',  "ENUM('legacy_tri_state','boolean','single_option','sum_selected','max_selected','non_scoring') NOT NULL DEFAULT 'legacy_tri_state' AFTER `is_required`" );
			self::add_column_if_missing( $questions, 'max_score',     'TINYINT NULL AFTER `scoring_mode`' );
			self::add_column_if_missing( $questions, 'help_text',     'TEXT NULL AFTER `max_score`' );
			// wpq_question_options is created fresh by create_tables() / dbDelta above.
		}
		if ( $had_prior_version && version_compare( $installed, '1.8.0', '<' ) ) {
			global $wpdb;

			// wpq_questionnaires — source-metadata columns for library items.
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			self::add_column_if_missing( $questionnaires, 'source_name',           'VARCHAR(200) NULL AFTER `description`' );
			self::add_column_if_missing( $questionnaires, 'source_question_set',   'VARCHAR(100) NULL AFTER `source_name`' );
			self::add_column_if_missing( $questionnaires, 'source_effective_date', 'DATE NULL AFTER `source_question_set`' );
			self::add_column_if_missing( $questionnaires, 'source_version',        'VARCHAR(20) NULL AFTER `source_effective_date`' );
			self::add_column_if_missing( $questionnaires, 'source_file',           'VARCHAR(200) NULL AFTER `source_version`' );

			// wpq_questions — widen question_type enum, add ref, selections, condition columns.
			$questions = $wpdb->prefix . 'wpq_questions';
			// Widen question_type ENUM to add short_text.
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
			$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $questions ) . " MODIFY COLUMN `question_type` ENUM('tri_state','boolean','select','radio','checkbox','memo','short_text') NOT NULL DEFAULT 'tri_state'" );
			self::record_db_error( 'migrate_question_type_add_short_text' );
			// Widen scoring_mode ENUM to add reverse_boolean.
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
			$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $questions ) . " MODIFY COLUMN `scoring_mode` ENUM('legacy_tri_state','boolean','single_option','sum_selected','max_selected','non_scoring','reverse_boolean') NOT NULL DEFAULT 'legacy_tri_state'" );
			self::record_db_error( 'migrate_scoring_mode_add_reverse_boolean' );
			self::add_column_if_missing( $questions, 'question_ref',    'VARCHAR(20) NULL AFTER `help_text`' );
			self::add_column_if_missing( $questions, 'min_selections',  'TINYINT NULL AFTER `question_ref`' );
			self::add_column_if_missing( $questions, 'max_selections',  'TINYINT NULL AFTER `min_selections`' );
			self::add_column_if_missing( $questions, 'condition_on_ref', 'VARCHAR(20) NULL AFTER `max_selections`' );
			self::add_column_if_missing( $questions, 'condition_value',  'VARCHAR(100) NULL AFTER `condition_on_ref`' );
			self::add_column_if_missing( $questions, 'condition_op',     "ENUM('eq','ne','contains','not_contains') NOT NULL DEFAULT 'eq' AFTER `condition_value`" );

			// wpq_question_options — requires_notes and exclusive flags.
			$options = $wpdb->prefix . 'wpq_question_options';
			self::add_column_if_missing( $options, 'requires_notes', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_active`' );
			self::add_column_if_missing( $options, 'exclusive',      'TINYINT(1) NOT NULL DEFAULT 0 AFTER `requires_notes`' );

			// Rename CS-01 → CS01 if the old default seeded name is still in use.
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal values are hard-coded constants.
			$wpdb->query( $wpdb->prepare(
				"UPDATE {$wpdb->prefix}wpq_questionnaires SET ref = %s WHERE ref = %s AND name LIKE %s",
				'CS01',
				'CS-01',
				'CyberCheck%'
			) );
			self::record_db_error( 'migrate_cs01_ref_rename' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.9.0', '<' ) ) {
			global $wpdb;

			// wpq_questionnaires — library import columns.
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			self::add_column_if_missing( $questionnaires, 'source_type',    'VARCHAR(50) NULL AFTER `source_file`' );
			self::add_column_if_missing( $questionnaires, 'source_sheet',   'VARCHAR(100) NULL AFTER `source_type`' );
			self::add_column_if_missing( $questionnaires, 'library_version','VARCHAR(20) NULL AFTER `source_sheet`' );
			self::add_column_if_missing( $questionnaires, 'library_id',     'VARCHAR(20) NULL AFTER `library_version`' );
			self::add_column_if_missing( $questionnaires, 'library_family', 'VARCHAR(100) NULL AFTER `library_id`' );
			self::add_column_if_missing( $questionnaires, 'created_by_seed','TINYINT(1) NOT NULL DEFAULT 0 AFTER `library_family`' );
			self::add_column_if_missing( $questionnaires, 'is_customised',  'TINYINT(1) NOT NULL DEFAULT 0 AFTER `created_by_seed`' );

			// wpq_questions — library tracking columns + number type.
			$questions = $wpdb->prefix . 'wpq_questions';
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
			$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $questions ) . " MODIFY COLUMN `question_type` ENUM('tri_state','boolean','select','radio','checkbox','memo','short_text','number') NOT NULL DEFAULT 'tri_state'" );
			self::record_db_error( 'migrate_question_type_add_number' );
			self::add_column_if_missing( $questions, 'answer_type_raw', 'VARCHAR(50) NULL AFTER `condition_op`' );
			self::add_column_if_missing( $questions, 'created_by_seed', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER `answer_type_raw`' );
			self::add_column_if_missing( $questions, 'library_version', 'VARCHAR(20) NULL AFTER `created_by_seed`' );

			// wpq_question_options — library tracking column.
			$options = $wpdb->prefix . 'wpq_question_options';
			self::add_column_if_missing( $options, 'created_by_seed', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER `exclusive`' );

			// New table: wpq_library_log.
			if ( function_exists( 'dbDelta' ) || ( require_once ABSPATH . 'wp-admin/includes/upgrade.php' ) ) {
				$charset = $wpdb->get_charset_collate();
				dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_library_log (
					id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
					library_version  VARCHAR(20)  NOT NULL,
					run_at           DATETIME     NOT NULL,
					q_seeded         INT          NOT NULL DEFAULT 0,
					q_skipped        INT          NOT NULL DEFAULT 0,
					q_errors         INT          NOT NULL DEFAULT 0,
					questions_seeded INT          NOT NULL DEFAULT 0,
					options_seeded   INT          NOT NULL DEFAULT 0,
					unsupported_types TEXT             NULL,
					skipped_refs      TEXT             NULL,
					PRIMARY KEY (id)
				) {$charset};" );
				self::record_db_error( 'create_library_log_table' );
			}
		}
		if ( $had_prior_version && version_compare( $installed, '1.10.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			self::add_column_if_missing( $questionnaires, 'stripe_product_id', 'VARCHAR(100) NULL AFTER `is_customised`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.11.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			$domains        = $wpdb->prefix . 'wpq_domains';
			$questions      = $wpdb->prefix . 'wpq_questions';
			self::add_column_if_missing( $questionnaires, 'stripe_price',    'INT UNSIGNED NULL AFTER `stripe_product_id`' );
			self::add_column_if_missing( $questionnaires, 'stripe_currency', "VARCHAR(3) NOT NULL DEFAULT 'GBP' AFTER `stripe_price`" );
			self::add_column_if_missing( $domains,        'domain_weight',   'SMALLINT UNSIGNED NOT NULL DEFAULT 100 AFTER `icon`' );
			self::add_column_if_missing( $questions,      'question_weight', 'SMALLINT UNSIGNED NOT NULL DEFAULT 100 AFTER `library_version`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.14.0', '<' ) ) {
			global $wpdb;
			$questions = $wpdb->prefix . 'wpq_questions';
			self::add_column_if_missing( $questions, 'recommendation', "TEXT NOT NULL DEFAULT '' AFTER `guidance_no`" );
		}
		if ( $had_prior_version && version_compare( $installed, '1.19.0', '<' ) ) {
			global $wpdb;
			$tq  = $wpdb->prefix . 'wpq_questions';
			$tqo = $wpdb->prefix . 'wpq_question_options';
			self::add_column_if_missing( $tq,  'guidance_partial', "TEXT NOT NULL DEFAULT '' AFTER `guidance_no`" );
			self::add_column_if_missing( $tqo, 'guidance',         'TEXT NULL AFTER `finding_action`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.20.0', '<' ) ) {
			global $wpdb;
			// Ensure all existing options are visible — is_active is no longer admin-editable.
			$wpdb->query( "UPDATE {$wpdb->prefix}wpq_question_options SET is_active = 1 WHERE is_active = 0" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		}
		if ( $had_prior_version && version_compare( $installed, '1.21.0', '<' ) ) {
			global $wpdb;
			$domains = $wpdb->prefix . 'wpq_domains';
			self::add_column_if_missing( $domains, 'brief', 'TEXT NULL AFTER `domain_weight`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.22.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
			$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $questionnaires ) . " MODIFY COLUMN `status` ENUM('draft','preview','live','retired','published','archived') NOT NULL DEFAULT 'draft'" );
			self::record_db_error( 'migrate_questionnaire_status_enum_superset' );
			$wpdb->query( "UPDATE {$wpdb->prefix}wpq_questionnaires SET status = 'live'    WHERE status = 'published'" );
			self::record_db_error( 'migrate_questionnaire_status_published_to_live' );
			$wpdb->query( "UPDATE {$wpdb->prefix}wpq_questionnaires SET status = 'retired' WHERE status = 'archived'" );
			self::record_db_error( 'migrate_questionnaire_status_archived_to_retired' );
			$wpdb->query( 'ALTER TABLE ' . self::quote_identifier( $questionnaires ) . " MODIFY COLUMN `status` ENUM('draft','preview','live','retired') NOT NULL DEFAULT 'draft'" );
			self::record_db_error( 'migrate_questionnaire_status_enum_final' );
			// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared
		}
		if ( $had_prior_version && version_compare( $installed, '1.23.0', '<' ) ) {
			global $wpdb;
			$submissions = $wpdb->prefix . 'wpq_submissions';
			self::add_column_if_missing( $submissions, 'consent_accepted_at', 'DATETIME NULL AFTER `abandoned`' );
		}
		if ( version_compare( $installed, '1.16.0', '<' ) ) {
			WPQ_Database::seed_categories();
			self::record_db_error( 'seed_categories' );

			// Remap legacy hardcoded category slugs to the new canonical set.
			// wpq_categories.slug is the authoritative list from 1.16.0 onward.
			if ( $had_prior_version ) {
				global $wpdb;
				$slug_map = [
					'it_managed_services' => 'it_governance',
					'isms'                => 'risk_compliance',
					'business_management' => 'risk_compliance',
					'risk_management'     => 'risk_compliance',
				];
				foreach ( $slug_map as $old => $new ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- migration, one-time
					$wpdb->query( $wpdb->prepare(
						"UPDATE {$wpdb->prefix}wpq_questionnaires SET category = %s WHERE category = %s",
						$new,
						$old
					) );
					self::record_db_error( 'migrate_category_slug_' . $old );
				}
			}
		}
		if ( $had_prior_version && version_compare( $installed, '1.26.0', '<' ) ) {
			global $wpdb;
			$submissions = $wpdb->prefix . 'wpq_submissions';
			self::add_column_if_missing( $submissions, 'questionnaire_ref_snapshot', 'VARCHAR(20) NULL AFTER `questionnaire_id`' );
			self::add_column_if_missing( $submissions, 'questionnaire_version_snapshot', 'VARCHAR(50) NULL AFTER `questionnaire_ref_snapshot`' );
			self::add_column_if_missing( $submissions, 'scoring_schema_version', 'VARCHAR(20) NULL AFTER `questionnaire_version_snapshot`' );
			self::add_column_if_missing( $submissions, 'question_snapshot_json', 'LONGTEXT NULL AFTER `findings_json`' );
			self::add_column_if_missing( $submissions, 'option_snapshot_json', 'LONGTEXT NULL AFTER `question_snapshot_json`' );
			self::add_column_if_missing( $submissions, 'grade_threshold_snapshot_json', 'LONGTEXT NULL AFTER `option_snapshot_json`' );
			self::add_column_if_missing( $submissions, 'cta_snapshot_json', 'LONGTEXT NULL AFTER `grade_threshold_snapshot_json`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.27.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			self::add_column_if_missing( $questionnaires, 'claude_project_id', 'VARCHAR(200) NULL AFTER `stripe_currency`' );
			self::add_column_if_missing( $questionnaires, 'claude_project_name', 'VARCHAR(200) NULL AFTER `claude_project_id`' );
			self::add_column_if_missing( $questionnaires, 'claude_project_status', "ENUM('not_started','configured','manual_configuration_required','failed') NOT NULL DEFAULT 'not_started' AFTER `claude_project_name`" );
			self::add_column_if_missing( $questionnaires, 'claude_project_verified_at', 'DATETIME NULL AFTER `claude_project_status`' );
			self::add_column_if_missing( $questionnaires, 'claude_project_last_error', 'TEXT NULL AFTER `claude_project_verified_at`' );
			self::add_column_if_missing( $questionnaires, 'claude_template_attachment_id', 'BIGINT UNSIGNED NULL AFTER `claude_project_last_error`' );
			self::add_column_if_missing( $questionnaires, 'claude_template_checksum', 'VARCHAR(64) NULL AFTER `claude_template_attachment_id`' );
			self::add_column_if_missing( $questionnaires, 'claude_template_updated_at', 'DATETIME NULL AFTER `claude_template_checksum`' );

			$submissions = $wpdb->prefix . 'wpq_submissions';
			self::add_column_if_missing( $submissions, 'claude_provider_mode', 'VARCHAR(50) NULL AFTER `cta_snapshot_json`' );
			self::add_column_if_missing( $submissions, 'claude_project_id', 'VARCHAR(200) NULL AFTER `claude_provider_mode`' );
			self::add_column_if_missing( $submissions, 'claude_conversation_id', 'VARCHAR(100) NULL AFTER `claude_project_id`' );
			self::add_column_if_missing( $submissions, 'claude_conversation_title', 'VARCHAR(255) NULL AFTER `claude_conversation_id`' );
			self::add_column_if_missing( $submissions, 'claude_status', "ENUM('not_started','pending','ready','processing','completed','failed','manual_configuration_required') NOT NULL DEFAULT 'not_started' AFTER `claude_conversation_title`" );
			self::add_column_if_missing( $submissions, 'claude_created_at', 'DATETIME NULL AFTER `claude_status`' );
			self::add_column_if_missing( $submissions, 'claude_last_success_at', 'DATETIME NULL AFTER `claude_created_at`' );
			self::add_column_if_missing( $submissions, 'claude_last_error', 'TEXT NULL AFTER `claude_last_success_at`' );
			self::add_column_if_missing( $submissions, 'claude_request_id', 'VARCHAR(100) NULL AFTER `claude_last_error`' );
			self::add_column_if_missing( $submissions, 'claude_model_used', 'VARCHAR(100) NULL AFTER `claude_request_id`' );
			self::add_column_if_missing( $submissions, 'claude_prompt_version', 'VARCHAR(50) NULL AFTER `claude_model_used`' );
			self::add_column_if_missing( $submissions, 'ai_report_status', "ENUM('not_requested','pending','processing','completed','failed') NOT NULL DEFAULT 'not_requested' AFTER `claude_prompt_version`" );
			self::add_column_if_missing( $submissions, 'ai_report_docx_path', 'VARCHAR(500) NULL AFTER `ai_report_status`' );
			self::add_column_if_missing( $submissions, 'ai_report_pdf_path', 'VARCHAR(500) NULL AFTER `ai_report_docx_path`' );
			self::add_column_if_missing( $submissions, 'ai_report_generated_at', 'DATETIME NULL AFTER `ai_report_pdf_path`' );
			self::add_column_if_missing( $submissions, 'ai_report_template_checksum', 'VARCHAR(64) NULL AFTER `ai_report_generated_at`' );
			self::add_column_if_missing( $submissions, 'ai_report_output_checksum', 'VARCHAR(64) NULL AFTER `ai_report_template_checksum`' );
			self::add_index_if_missing( $submissions, 'claude_conversation_id', 'claude_conversation_id' );
			self::add_index_if_missing( $submissions, 'claude_status', 'claude_status' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.28.0', '<' ) ) {
			delete_option( 'wpq_claude_project_id' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.29.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			self::add_column_if_missing( $questionnaires, 'remediation_plan_enabled', "ENUM('inherit','enabled','disabled') NOT NULL DEFAULT 'inherit' AFTER `claude_template_updated_at`" );
		}
		if ( $had_prior_version && version_compare( $installed, '1.30.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			self::add_column_if_missing( $questionnaires, 'remediation_template_attachment_id', 'BIGINT UNSIGNED NULL AFTER `remediation_plan_enabled`' );
			self::add_column_if_missing( $questionnaires, 'remediation_template_checksum', 'VARCHAR(64) NULL AFTER `remediation_template_attachment_id`' );
			self::add_column_if_missing( $questionnaires, 'remediation_template_updated_at', 'DATETIME NULL AFTER `remediation_template_checksum`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.31.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			$submissions    = $wpdb->prefix . 'wpq_submissions';

			// Questionnaire Report (DOCX -> PDF) enable/renderer-mode overrides. The
			// DOCX template itself reuses the existing claude_template_* columns.
			self::add_column_if_missing( $questionnaires, 'questionnaire_report_enabled', "ENUM('inherit','enabled','disabled') NOT NULL DEFAULT 'inherit' AFTER `remediation_template_updated_at`" );
			self::add_column_if_missing( $questionnaires, 'questionnaire_report_renderer_mode', "ENUM('inherit','docx_template','html_dompdf') NOT NULL DEFAULT 'inherit' AFTER `questionnaire_report_enabled`" );

			// Questionnaire Report generation lifecycle — kept separate from the
			// remediation plan's ai_report_* columns, which remain XLSX-specific.
			self::add_column_if_missing( $submissions, 'qr_status', "ENUM('not_requested','queued','analysing','rendering_docx','converting_pdf','completed','partial','failed') NOT NULL DEFAULT 'not_requested' AFTER `ai_report_output_checksum`" );
			self::add_column_if_missing( $submissions, 'qr_renderer_mode', 'VARCHAR(20) NULL AFTER `qr_status`' );
			self::add_column_if_missing( $submissions, 'qr_claude_request_id', 'VARCHAR(100) NULL AFTER `qr_renderer_mode`' );
			self::add_column_if_missing( $submissions, 'qr_model_used', 'VARCHAR(100) NULL AFTER `qr_claude_request_id`' );
			self::add_column_if_missing( $submissions, 'qr_prompt_version', 'VARCHAR(50) NULL AFTER `qr_model_used`' );
			self::add_column_if_missing( $submissions, 'qr_context_version', 'VARCHAR(50) NULL AFTER `qr_prompt_version`' );
			self::add_column_if_missing( $submissions, 'qr_template_checksum', 'VARCHAR(64) NULL AFTER `qr_context_version`' );
			self::add_column_if_missing( $submissions, 'qr_docx_path', 'VARCHAR(500) NULL AFTER `qr_template_checksum`' );
			self::add_column_if_missing( $submissions, 'qr_docx_checksum', 'VARCHAR(64) NULL AFTER `qr_docx_path`' );
			self::add_column_if_missing( $submissions, 'qr_pdf_path', 'VARCHAR(500) NULL AFTER `qr_docx_checksum`' );
			self::add_column_if_missing( $submissions, 'qr_pdf_checksum', 'VARCHAR(64) NULL AFTER `qr_pdf_path`' );
			self::add_column_if_missing( $submissions, 'qr_generated_at', 'DATETIME NULL AFTER `qr_pdf_checksum`' );
			self::add_column_if_missing( $submissions, 'qr_requested_at', 'DATETIME NULL AFTER `qr_generated_at`' );
			self::add_column_if_missing( $submissions, 'qr_last_stage', 'VARCHAR(30) NULL AFTER `qr_requested_at`' );
			self::add_column_if_missing( $submissions, 'qr_failure_code', 'VARCHAR(50) NULL AFTER `qr_last_stage`' );
			self::add_column_if_missing( $submissions, 'qr_failure_message', 'TEXT NULL AFTER `qr_failure_code`' );
			self::add_column_if_missing( $submissions, 'qr_generation_token', 'VARCHAR(64) NULL AFTER `qr_failure_message`' );
			self::add_column_if_missing( $submissions, 'qr_analysis_json', 'LONGTEXT NULL AFTER `qr_generation_token`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.33.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			$submissions    = $wpdb->prefix . 'wpq_submissions';
			$report_tokens  = $wpdb->prefix . 'wpq_report_tokens';

			// Customer delivery of the Questionnaire Report: an enabled-channel list
			// per questionnaire (empty inherits the global list), a stamp making email
			// delivery idempotent, and a purpose scoping each download token to one
			// artefact so a token minted for the paid HTML report cannot redeem the
			// Questionnaire Report PDF or vice versa.
			self::add_column_if_missing( $questionnaires, 'questionnaire_report_delivery_channels', "VARCHAR(191) NOT NULL DEFAULT '' AFTER `questionnaire_report_renderer_mode`" );
			self::add_column_if_missing( $submissions, 'qr_email_sent_at', 'DATETIME NULL AFTER `qr_analysis_json`' );
			self::add_column_if_missing( $report_tokens, 'purpose', "VARCHAR(30) NOT NULL DEFAULT 'paid_report' AFTER `token_hash`" );
		}
		if ( $had_prior_version && version_compare( $installed, '1.34.0', '<' ) ) {
			global $wpdb;
			$frameworks = $wpdb->prefix . 'wpq_frameworks';

			// ATLAS skill registry: the framework row records which uploaded .skill
			// bundle it came from (checksum + stored file) and, once registered with
			// the Anthropic Skills API, the skill id/version used at analysis time.
			self::add_column_if_missing( $frameworks, 'skill_id', 'VARCHAR(100) NULL AFTER `status`' );
			self::add_column_if_missing( $frameworks, 'skill_version', 'VARCHAR(50) NULL AFTER `skill_id`' );
			self::add_column_if_missing( $frameworks, 'skill_checksum', 'VARCHAR(64) NULL AFTER `skill_version`' );
			self::add_column_if_missing( $frameworks, 'skill_bundle', 'VARCHAR(255) NULL AFTER `skill_checksum`' );
			self::add_column_if_missing( $frameworks, 'skill_imported_at', 'DATETIME NULL AFTER `skill_bundle`' );
		}
		if ( $had_prior_version && version_compare( $installed, '1.35.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';

			// Framework readiness: which imported frameworks each questionnaire's
			// reports are assessed against (comma-separated framework ids; empty
			// means the report carries no frameworks section).
			self::add_column_if_missing( $questionnaires, 'framework_ids', "VARCHAR(500) NOT NULL DEFAULT '' AFTER `questionnaire_report_delivery_channels`" );
		}
		if ( $had_prior_version && version_compare( $installed, '1.36.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';

			// Per-questionnaire outbound-mail gate (report delivery and resume
			// emails); enquiry forms carry their own equivalent column. The
			// enquiry tables themselves are created by dbDelta below.
			self::add_column_if_missing( $questionnaires, 'mail_enabled', "ENUM('inherit','enabled','disabled') NOT NULL DEFAULT 'inherit' AFTER `framework_ids`" );
		}

		if ( $had_prior_version && version_compare( $installed, '1.37.0', '<' ) ) {
			global $wpdb;
			$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
			$submissions    = $wpdb->prefix . 'wpq_submissions';

			// Remediation workbook delivery: per-questionnaire channel override
			// ('' inherit / 'none' / CSV) and the stored-workbook path used by
			// the email channel's tokenised download link.
			self::add_column_if_missing( $questionnaires, 'remediation_delivery_channels', "VARCHAR(191) NOT NULL DEFAULT '' AFTER `mail_enabled`" );
			self::add_column_if_missing( $submissions, 'remediation_xlsx_path', 'VARCHAR(255) NULL AFTER `qr_email_sent_at`' );
		}

		if ( $had_prior_version && version_compare( $installed, '1.38.0', '<' ) ) {
			global $wpdb;
			$submissions = $wpdb->prefix . 'wpq_submissions';
			$enquiries   = $wpdb->prefix . 'wpq_enquiries';

			// Canonical contact linkage (Phase 1). Snapshot contact_* columns are
			// deliberately untouched; contact_id is the additional canonical
			// relationship. The canonical tables are created by dbDelta below.
			self::add_column_if_missing( $submissions, 'contact_id', 'BIGINT UNSIGNED NULL AFTER `questionnaire_id`' );
			self::add_column_if_missing( $enquiries, 'contact_id', 'BIGINT UNSIGNED NULL AFTER `form_id`' );
			self::add_index_if_missing( $submissions, 'contact_id', 'contact_id' );
			self::add_index_if_missing( $enquiries, 'contact_id', 'contact_id' );
		}
	}

	private static function create_roles(): void {
		// Dedicated role for the HaloPSA integration tool.
		// Grants access to pull API endpoints only — no WP Admin access.
		$role = get_role( 'wpq_halopsa' );
		if ( ! $role ) {
			add_role( 'wpq_halopsa', 'WPQ HaloPSA API', [
				'read'            => true,
				'wpq_halopsa_api' => true,
			] );
			$role = get_role( 'wpq_halopsa' );
		}

		if ( $role && ! $role->has_cap( 'wpq_halopsa_api' ) ) {
			$role->add_cap( 'wpq_halopsa_api' );
		}

		$admin_role = get_role( 'administrator' );
		if ( $admin_role ) {
			foreach ( self::ADMIN_CAPABILITIES as $capability ) {
				if ( ! $admin_role->has_cap( $capability ) ) {
					$admin_role->add_cap( $capability );
				}
			}
		}
	}

	public static function get_admin_capabilities(): array {
		return self::ADMIN_CAPABILITIES;
	}

	private static function add_column_if_missing( string $table, string $column, string $definition ): void {
		global $wpdb;
		if ( ! self::table_exists( $table ) || self::column_exists( $table, $column ) ) {
			return;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifiers quoted by quote_identifier().
		$wpdb->query(
			'ALTER TABLE ' . self::quote_identifier( $table )
			. ' ADD COLUMN ' . self::quote_identifier( $column ) . ' ' . $definition
		);
		self::record_db_error( 'add_column_' . $column );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared
	}

	private static function add_index_if_missing( string $table, string $index_name, string $column ): void {
		global $wpdb;
		if ( ! self::table_exists( $table ) || self::index_exists( $table, $column, false ) ) {
			return;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifiers quoted by quote_identifier().
		$wpdb->query(
			'ALTER TABLE ' . self::quote_identifier( $table )
			. ' ADD KEY ' . self::quote_identifier( $index_name )
			. ' (' . self::quote_identifier( $column ) . ')'
		);
		self::record_db_error( 'add_index_' . $index_name );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared
	}

	// Identifier helpers are for internal schema constants only; never pass user input.
	private static function table_exists( string $table ): bool {
		global $wpdb;
		// SELECT LIMIT 0 is the most robust table-existence check across MySQL versions:
		// no LIKE pattern escaping, no information_schema privilege concerns — if the
		// query succeeds the table exists, if MySQL returns a "doesn't exist" error it
		// doesn't. Error suppression prevents the wp_die error handler from aborting.
		$prev = $wpdb->suppress_errors( true );
		$wpdb->query( 'SELECT 1 FROM ' . self::quote_identifier( $table ) . ' LIMIT 0' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $table is an internal schema constant, never user input.
		$exists = ( '' === $wpdb->last_error );
		$wpdb->suppress_errors( $prev );
		return $exists;
	}

	private static function column_exists( string $table, string $column ): bool {
		global $wpdb;
		if ( ! self::table_exists( $table ) ) {
			return false;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
		return (bool) $wpdb->get_var( $wpdb->prepare(
			'SHOW COLUMNS FROM ' . self::quote_identifier( $table ) . ' LIKE %s',
			$column
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared
	}

	private static function quote_identifier( string $identifier ): string {
		return '`' . str_replace( '`', '``', $identifier ) . '`';
	}

	private static function expire_in_progress_session_tokens( string $table ): void {
		global $wpdb;
		if ( ! self::column_exists( $table, 'session_token' ) ) {
			return;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
		$expired = $wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::quote_identifier( $table ) . '
			 SET session_token = %s, updated_at = %s
			 WHERE abandoned = 1
			   AND completed_at IS NULL
			   AND session_token != %s
			   AND deleted_at IS NULL',
			'',
			current_time( 'mysql', true ),
			''
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared

		if ( $expired > 0 ) {
			self::$expired_session_count = (int) $expired;
			update_option( 'wpq_expired_in_progress_sessions_notice', (int) $expired );
		}
		self::record_db_error( 'expire_in_progress_session_tokens' );
	}

	private static function write_migration_log( array $updates ): void {
		$existing = get_option( self::MIGRATION_LOG_OPTION, [] );
		if ( ! is_array( $existing ) ) {
			$existing = [];
		}

		update_option( self::MIGRATION_LOG_OPTION, array_merge( $existing, $updates ) );
	}

	private static function record_db_error( string $context ): void {
		global $wpdb;
		if ( ! empty( $wpdb->last_error ) ) {
			self::$migration_errors[] = $context . ': ' . $wpdb->last_error;
		}
	}

	private static function get_schema_health(): array {
		global $wpdb;
		$submissions = $wpdb->prefix . 'wpq_submissions';
		$checks = [
			$wpdb->prefix . 'wpq_questionnaires' => [ 'id', 'organisation_id', 'ref', 'category', 'name', 'description', 'source_name', 'source_question_set', 'source_effective_date', 'source_version', 'source_file', 'status', 'stripe_product_id', 'stripe_price', 'stripe_currency', 'claude_project_id', 'claude_project_name', 'claude_project_status', 'claude_project_verified_at', 'claude_project_last_error', 'claude_template_attachment_id', 'claude_template_checksum', 'claude_template_updated_at', 'remediation_plan_enabled', 'remediation_template_attachment_id', 'remediation_template_checksum', 'remediation_template_updated_at', 'questionnaire_report_enabled', 'questionnaire_report_renderer_mode', 'questionnaire_report_delivery_channels', 'framework_ids', 'mail_enabled', 'remediation_delivery_channels', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_domains' => [ 'id', 'questionnaire_id', 'sort_order', 'slug', 'name', 'icon', 'domain_weight', 'brief' ],
			$wpdb->prefix . 'wpq_questions' => [ 'id', 'domain_id', 'sort_order', 'question_text', 'guidance_yes', 'guidance_no', 'guidance_partial', 'recommendation', 'score_yes', 'score_partial', 'score_no', 'question_type', 'is_required', 'scoring_mode', 'max_score', 'help_text', 'question_ref', 'min_selections', 'max_selections', 'condition_on_ref', 'condition_value', 'condition_op' ],
			$wpdb->prefix . 'wpq_question_options' => [ 'id', 'question_id', 'option_key', 'option_label', 'score', 'risk_level', 'finding_priority', 'finding_action', 'guidance', 'sort_order', 'is_default', 'is_active', 'requires_notes', 'exclusive' ],
			$wpdb->prefix . 'wpq_grade_thresholds' => [ 'id', 'questionnaire_id', 'min_score', 'grade_id', 'grade_label', 'verdict_text', 'color_hex', 'bg_hex' ],
			$wpdb->prefix . 'wpq_ctas' => [ 'id', 'category_slug', 'domain_slug', 'body_html', 'status', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_products' => [ 'id', 'organisation_id', 'questionnaire_id', 'name', 'slug', 'description', 'price_gbp', 'stripe_price_id', 'billing_type', 'report_type', 'status', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_coupons'     => [ 'id', 'stripe_coupon_id', 'stripe_promo_id', 'promo_code', 'name', 'discount_type', 'percent_off', 'amount_off', 'currency', 'duration', 'duration_in_months', 'max_redemptions', 'redeem_by', 'scope', 'questionnaire_id', 'product_id', 'status', 'created_at' ],
			$wpdb->prefix . 'wpq_categories'           => [ 'id', 'slug', 'name', 'sort_order' ],
			$wpdb->prefix . 'wpq_contact_preferences' => [ 'id', 'email', 'opted_out', 'opted_out_at', 'opted_out_by_user_id' ],
			$submissions => [
				'id',
				'organisation_id',
				'questionnaire_id',
				'contact_id',
				'questionnaire_ref_snapshot',
				'questionnaire_version_snapshot',
				'scoring_schema_version',
				'ref',
				'contact_name',
				'contact_email',
				'contact_company',
				'contact_phone',
				'overall_score',
				'grade_id',
				'answers_json',
				'domain_scores_json',
				'findings_json',
				'question_snapshot_json',
				'option_snapshot_json',
				'grade_threshold_snapshot_json',
				'cta_snapshot_json',
				'claude_provider_mode',
				'claude_project_id',
				'claude_conversation_id',
				'claude_conversation_title',
				'claude_status',
				'claude_created_at',
				'claude_last_success_at',
				'claude_last_error',
				'claude_request_id',
				'claude_model_used',
				'claude_prompt_version',
				'ai_report_status',
				'ai_report_docx_path',
				'ai_report_pdf_path',
				'ai_report_generated_at',
				'ai_report_template_checksum',
				'ai_report_output_checksum',
				'qr_status',
				'qr_renderer_mode',
				'qr_claude_request_id',
				'qr_model_used',
				'qr_prompt_version',
				'qr_context_version',
				'qr_template_checksum',
				'qr_docx_path',
				'qr_docx_checksum',
				'qr_pdf_path',
				'qr_pdf_checksum',
				'qr_generated_at',
				'qr_requested_at',
				'qr_last_stage',
				'qr_failure_code',
				'qr_failure_message',
				'qr_generation_token',
				'qr_analysis_json',
				'qr_email_sent_at',
				'remediation_xlsx_path',
				'product_id',
				'payment_status',
				'stripe_session_id',
				'report_product_id',
				'report_path',
				'report_generated_at',
				'report_error',
				'halopsa_lead_id',
				'session_token',
				'halopsa_synced_at',
				'halopsa_sync_status',
				'utm_source',
				'utm_medium',
				'utm_campaign',
				'utm_term',
				'utm_content',
				'referrer_url',
				'landing_page',
				'started_at',
				'completed_at',
				'duration_seconds',
				'abandoned',
				'deleted_at',
				'deleted_by_user_id',
				'last_question_answered',
				'ip_address',
				'created_at',
				'updated_at',
			],
			$wpdb->prefix . 'wpq_payment_sessions' => [ 'session_id', 'submission_id', 'product_id', 'payment_status', 'answers_hash', 'amount_total', 'currency', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_payment_events' => [ 'id', 'stripe_event_id', 'stripe_session_id', 'submission_id', 'product_id', 'event_type', 'previous_status', 'new_status', 'amount_total', 'currency', 'payload_json', 'processed_at', 'created_at' ],
			$wpdb->prefix . 'wpq_report_tokens' => [ 'id', 'submission_id', 'token_hash', 'purpose', 'expires_at', 'used_at', 'use_count', 'max_uses', 'created_at', 'revoked_at' ],
			$wpdb->prefix . 'wpq_audit_log' => [ 'id', 'event_type', 'actor_user_id', 'actor_email', 'object_type', 'object_id', 'before_summary', 'after_summary', 'ip_hash', 'user_agent', 'created_at' ],
			$wpdb->prefix . 'wpq_rate_limits' => [ 'id', 'bucket_key', 'endpoint', 'client_hash', 'questionnaire_ref', 'submission_id', 'email_hash', 'window_start', 'request_count', 'expires_at', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_frameworks' => [ 'id', 'slug', 'name', 'version', 'description', 'status', 'skill_id', 'skill_version', 'skill_checksum', 'skill_bundle', 'skill_imported_at' ],
			$wpdb->prefix . 'wpq_enquiry_forms' => [ 'id', 'ref', 'name', 'description', 'status', 'fields_json', 'mail_enabled', 'notify_email', 'send_ack', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_enquiries' => [ 'id', 'form_id', 'contact_id', 'ref', 'contact_name', 'contact_email', 'contact_company', 'contact_phone', 'consent', 'fields_json', 'status', 'created_at' ],
			$wpdb->prefix . 'wpq_contacts' => [ 'id', 'uuid', 'wp_user_id', 'given_name', 'family_name', 'display_name', 'organisation', 'job_title', 'status', 'merged_into_contact_id', 'created_source', 'first_observed_at', 'last_observed_at', 'verified_at', 'anonymised_at', 'deleted_at', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_contact_identities' => [ 'id', 'contact_id', 'type', 'value_original', 'value_normalised', 'value_hash', 'verification', 'verified_at', 'is_primary', 'source_type', 'source_id', 'first_observed_at', 'last_observed_at', 'superseded_at', 'created_at', 'updated_at' ],
			$wpdb->prefix . 'wpq_contact_organisations' => [ 'id', 'contact_id', 'organisation_name', 'organisation_id', 'relationship', 'is_primary', 'source', 'valid_from', 'valid_until', 'created_at' ],
			$wpdb->prefix . 'wpq_contact_interactions' => [ 'id', 'contact_id', 'product', 'interaction_type', 'source_type', 'source_id', 'source_ref', 'questionnaire_id', 'occurred_at', 'completion_state', 'organisation', 'attribution', 'created_at' ],
			$wpdb->prefix . 'wpq_contact_consent_events' => [ 'id', 'contact_id', 'identity_id', 'purpose', 'event', 'statement_version', 'notice_version', 'source', 'actor', 'occurred_at', 'evidence', 'reason', 'created_at' ],
			$wpdb->prefix . 'wpq_contact_preferences_current' => [ 'id', 'contact_id', 'purpose', 'identity_id', 'state', 'updated_at' ],
			$wpdb->prefix . 'wpq_contact_merge_log' => [ 'id', 'survivor_id', 'absorbed_id', 'reason', 'actor', 'before_summary', 'resolutions', 'recovery', 'created_at' ],
			$wpdb->prefix . 'wpq_contact_match_review' => [ 'id', 'source_type', 'source_id', 'candidate_contact_ids', 'reason', 'details', 'status', 'resolution', 'resolved_by', 'resolved_at', 'created_at' ],
			$wpdb->prefix . 'wpq_framework_controls' => [ 'id', 'framework_id', 'control_ref', 'control_name', 'domain', 'description' ],
			$wpdb->prefix . 'wpq_question_control_mappings' => [ 'id', 'question_id', 'framework_control_id', 'relevance' ],
		];

		$health = [];
		foreach ( $checks as $table => $columns ) {
			$missing_columns = [];
			$exists = self::table_exists( $table );
			if ( $exists ) {
				foreach ( $columns as $column ) {
					if ( ! self::column_exists( $table, $column ) ) {
						$missing_columns[] = $column;
					}
				}
			}
			$health[ $table ] = [
				'exists'          => $exists,
				'missing_columns' => $missing_columns,
			];
		}

		return $health;
	}

	private static function get_strict_schema_health(): array {
		global $wpdb;

		$submissions = $wpdb->prefix . 'wpq_submissions';
		$questionnaires = $wpdb->prefix . 'wpq_questionnaires';
		$products    = $wpdb->prefix . 'wpq_products';
		$payment_sessions = $wpdb->prefix . 'wpq_payment_sessions';
		$payment_events = $wpdb->prefix . 'wpq_payment_events';
		$report_tokens = $wpdb->prefix . 'wpq_report_tokens';
		$audit_log = $wpdb->prefix . 'wpq_audit_log';
		$rate_limits = $wpdb->prefix . 'wpq_rate_limits';

		return [
			$questionnaires => [
				'unique_ref_key' => self::strict_check(
					self::table_exists( $questionnaires ) && self::index_exists( $questionnaires, 'ref', true ),
					'Questionnaire ref has a unique index.'
				),
				'claude_project_status_enum' => self::column_enum_check( $questionnaires, 'claude_project_status', [ 'not_started', 'configured', 'manual_configuration_required', 'failed' ] ),
				'claude_project_id_type' => self::column_type_check( $questionnaires, 'claude_project_id', 'varchar(200)' ),
				'claude_template_attachment_type' => self::column_type_prefix_check( $questionnaires, 'claude_template_attachment_id', 'bigint' ),
				'claude_template_checksum_type' => self::column_type_check( $questionnaires, 'claude_template_checksum', 'varchar(64)' ),
				'remediation_template_attachment_type' => self::column_type_prefix_check( $questionnaires, 'remediation_template_attachment_id', 'bigint' ),
				'remediation_template_checksum_type' => self::column_type_check( $questionnaires, 'remediation_template_checksum', 'varchar(64)' ),
				'remediation_plan_enabled_enum' => self::column_enum_check( $questionnaires, 'remediation_plan_enabled', [ 'inherit', 'enabled', 'disabled' ] ),
			],
			$submissions => [
				'unique_ref_key' => self::strict_check(
					self::table_exists( $submissions ) && self::index_exists( $submissions, 'ref', true ),
					'Submission ref has a unique index.'
				),
				'questionnaire_id_index' => self::index_check( $submissions, 'questionnaire_id' ),
				'contact_email_index' => self::index_check( $submissions, 'contact_email' ),
				'halopsa_sync_status_index' => self::index_check( $submissions, 'halopsa_sync_status' ),
				'abandoned_index' => self::index_check( $submissions, 'abandoned' ),
				'session_token_type' => self::column_type_check( $submissions, 'session_token', 'varchar(64)' ),
				'payment_status_enum' => self::column_enum_check( $submissions, 'payment_status', [ 'none', 'pending', 'paid', 'failed', 'expired' ] ),
				'halopsa_sync_status_enum' => self::column_enum_check( $submissions, 'halopsa_sync_status', [ 'pending', 'processing', 'synced', 'failed', 'retry_pending', 'ignored', 'manual_review', 'skipped' ] ),
				'halopsa_last_attempted_at_type' => self::column_type_and_null_check( $submissions, 'halopsa_last_attempted_at', 'datetime', true ),
				'halopsa_retry_count_type' => self::column_type_prefix_check( $submissions, 'halopsa_retry_count', 'int' ),
				'deleted_at_nullable_datetime' => self::column_type_and_null_check( $submissions, 'deleted_at', 'datetime', true ),
				'claude_conversation_id_index' => self::index_check( $submissions, 'claude_conversation_id' ),
				'claude_status_index' => self::index_check( $submissions, 'claude_status' ),
				'claude_provider_mode_type' => self::column_type_check( $submissions, 'claude_provider_mode', 'varchar(50)' ),
				'claude_status_enum' => self::column_enum_check( $submissions, 'claude_status', [ 'not_started', 'pending', 'ready', 'processing', 'completed', 'failed', 'manual_configuration_required' ] ),
				'ai_report_status_enum' => self::column_enum_check( $submissions, 'ai_report_status', [ 'not_requested', 'pending', 'processing', 'completed', 'failed' ] ),
				'ai_report_docx_path_type' => self::column_type_check( $submissions, 'ai_report_docx_path', 'varchar(500)' ),
				'ai_report_pdf_path_type' => self::column_type_check( $submissions, 'ai_report_pdf_path', 'varchar(500)' ),
				'qr_status_enum' => self::column_enum_check( $submissions, 'qr_status', [ 'not_requested', 'queued', 'analysing', 'rendering_docx', 'converting_pdf', 'completed', 'partial', 'failed' ] ),
				'qr_docx_path_type' => self::column_type_check( $submissions, 'qr_docx_path', 'varchar(500)' ),
				'qr_pdf_path_type' => self::column_type_check( $submissions, 'qr_pdf_path', 'varchar(500)' ),
			],
			$products => [
				'unique_slug_key' => self::strict_check(
					self::table_exists( $products ) && self::index_exists( $products, 'slug', true ),
					'Product slug has a unique index.'
				),
				'questionnaire_id_index' => self::index_check( $products, 'questionnaire_id' ),
				'price_gbp_type' => self::column_type_check( $products, 'price_gbp', 'decimal(8,2)' ),
				'stripe_price_id_type' => self::column_type_check( $products, 'stripe_price_id', 'varchar(100)' ),
				'billing_type_enum' => self::column_enum_check( $products, 'billing_type', [ 'one_off', 'subscription_annual', 'subscription_monthly' ] ),
				'report_type_enum' => self::column_enum_check( $products, 'report_type', [ 'professional', 'annual', 'bundle' ] ),
				'status_enum' => self::column_enum_check( $products, 'status', [ 'active', 'inactive' ] ),
			],
			$payment_sessions => [
				'session_id_primary_key' => self::primary_key_check( $payment_sessions, 'session_id' ),
				'submission_id_index' => self::index_check( $payment_sessions, 'submission_id' ),
				'payment_status_enum' => self::column_enum_check( $payment_sessions, 'payment_status', [ 'none', 'pending', 'paid', 'failed', 'expired' ] ),
				'answers_hash_type' => self::column_type_check( $payment_sessions, 'answers_hash', 'varchar(64)' ),
				'amount_total_type' => self::column_type_prefix_check( $payment_sessions, 'amount_total', 'bigint' ),
				'currency_type' => self::column_type_check( $payment_sessions, 'currency', 'varchar(10)' ),
			],
			$payment_events => [
				'id_primary_key' => self::primary_key_check( $payment_events, 'id' ),
				'unique_stripe_event_id_key' => self::strict_check(
					self::table_exists( $payment_events ) && self::index_exists( $payment_events, 'stripe_event_id', true ),
					'Stripe event id has a unique index.'
				),
				'stripe_session_id_index' => self::index_check( $payment_events, 'stripe_session_id' ),
				'submission_id_index' => self::index_check( $payment_events, 'submission_id' ),
			],
			$report_tokens => [
				'id_primary_key' => self::primary_key_check( $report_tokens, 'id' ),
				'unique_token_hash_key' => self::strict_check(
					self::table_exists( $report_tokens ) && self::index_exists( $report_tokens, 'token_hash', true ),
					'Report token hash has a unique index.'
				),
				'submission_id_index' => self::index_check( $report_tokens, 'submission_id' ),
				'expires_at_index' => self::index_check( $report_tokens, 'expires_at' ),
			],
			$audit_log => [
				'id_primary_key' => self::primary_key_check( $audit_log, 'id' ),
				'event_type_index' => self::index_check( $audit_log, 'event_type' ),
				'actor_user_id_index' => self::index_check( $audit_log, 'actor_user_id' ),
				'object_type_id_index' => self::index_check( $audit_log, 'object_type' ),
				'created_at_index' => self::index_check( $audit_log, 'created_at' ),
			],
			$rate_limits => [
				'id_primary_key' => self::primary_key_check( $rate_limits, 'id' ),
				'unique_bucket_key' => self::strict_check(
					self::table_exists( $rate_limits ) && self::index_exists( $rate_limits, 'bucket_key', true ),
					'Rate-limit bucket key has a unique index.'
				),
				'endpoint_expires_index' => self::index_check( $rate_limits, 'endpoint' ),
				'expires_at_index' => self::index_check( $rate_limits, 'expires_at' ),
				'submission_id_index' => self::index_check( $rate_limits, 'submission_id' ),
				'email_hash_index' => self::index_check( $rate_limits, 'email_hash' ),
			],
			$wpdb->prefix . 'wpq_question_options' => [
				'id_primary_key'     => self::primary_key_check( $wpdb->prefix . 'wpq_question_options', 'id' ),
				'question_id_index'  => self::index_check( $wpdb->prefix . 'wpq_question_options', 'question_id' ),
				'unique_question_option_key' => self::strict_check(
					self::composite_index_exists( $wpdb->prefix . 'wpq_question_options', [ 'question_id', 'option_key' ], true ),
					'question_option unique key exists on question_id and option_key.',
					'question_option should be a unique key on question_id and option_key.'
				),
			],
		];
	}

	private static function index_check( string $table, string $column ): array {
		return self::strict_check(
			self::table_exists( $table ) && self::index_exists( $table, $column, false ),
			"{$column} has an index.",
			"{$column} should have an index."
		);
	}

	private static function primary_key_check( string $table, string $column ): array {
		return self::strict_check(
			self::table_exists( $table ) && self::primary_key_exists( $table, $column ),
			"{$column} is the primary key.",
			"{$column} should be the primary key."
		);
	}

	private static function strict_check( bool $ok, string $success_message, string $failure_message = '' ): array {
		return [
			'ok'      => $ok,
			'message' => $ok ? $success_message : ( $failure_message ?: 'Schema check failed.' ),
		];
	}

	private static function column_type_check( string $table, string $column, string $expected_type ): array {
		$definition = self::get_column_definition( $table, $column );
		if ( ! $definition ) {
			return self::strict_check( false, '', "{$column} column is missing." );
		}

		$actual_type = strtolower( self::object_property( $definition, 'Type' ) );
		return self::strict_check(
			$actual_type === strtolower( $expected_type ),
			"{$column} is {$expected_type}.",
			"{$column} should be {$expected_type}; found {$actual_type}."
		);
	}

	private static function column_type_prefix_check( string $table, string $column, string $expected_prefix ): array {
		$definition = self::get_column_definition( $table, $column );
		if ( ! $definition ) {
			return self::strict_check( false, '', "{$column} column is missing." );
		}

		$actual_type = strtolower( self::object_property( $definition, 'Type' ) );
		return self::strict_check(
			str_starts_with( $actual_type, strtolower( $expected_prefix ) ),
			"{$column} type starts with {$expected_prefix}.",
			"{$column} should start with {$expected_prefix}; found {$actual_type}."
		);
	}

	private static function column_type_and_null_check( string $table, string $column, string $expected_type, bool $nullable ): array {
		$definition = self::get_column_definition( $table, $column );
		if ( ! $definition ) {
			return self::strict_check( false, '', "{$column} column is missing." );
		}

		$actual_type = strtolower( self::object_property( $definition, 'Type' ) );
		$is_nullable = strtoupper( self::object_property( $definition, 'Null' ) ) === 'YES';
		return self::strict_check(
			$actual_type === strtolower( $expected_type ) && $is_nullable === $nullable,
			"{$column} is {$expected_type} " . ( $nullable ? 'NULL' : 'NOT NULL' ) . '.',
			"{$column} should be {$expected_type} " . ( $nullable ? 'NULL' : 'NOT NULL' ) . "; found {$actual_type} " . ( $is_nullable ? 'NULL' : 'NOT NULL' ) . '.'
		);
	}

	private static function column_enum_check( string $table, string $column, array $expected_values ): array {
		$definition = self::get_column_definition( $table, $column );
		if ( ! $definition ) {
			return self::strict_check( false, '', "{$column} column is missing." );
		}

		$actual_type = strtolower( self::object_property( $definition, 'Type' ) );
		$missing_values = array_filter(
			$expected_values,
			static fn( string $value ): bool => strpos( $actual_type, "'" . strtolower( $value ) . "'" ) === false
		);

		return self::strict_check(
			str_starts_with( $actual_type, 'enum(' ) && empty( $missing_values ),
			"{$column} enum contains required values.",
			"{$column} enum is missing required value(s): " . implode( ', ', $missing_values ) . '.'
		);
	}

	private static function get_column_definition( string $table, string $column ): ?object {
		global $wpdb;
		if ( ! self::table_exists( $table ) ) {
			return null;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
		$columns = $wpdb->get_results( 'SHOW FULL COLUMNS FROM ' . self::quote_identifier( $table ) ) ?: [];
		foreach ( $columns as $definition ) {
			if ( self::object_property( $definition, 'Field' ) === $column ) {
				return $definition;
			}
		}

		return null;
	}

	private static function index_exists( string $table, string $column, bool $unique ): bool {
		global $wpdb;
		if ( ! self::table_exists( $table ) ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
		$indexes = $wpdb->get_results( 'SHOW INDEX FROM ' . self::quote_identifier( $table ) ) ?: [];
		foreach ( $indexes as $index ) {
			$is_unique = (int) self::object_property( $index, 'Non_unique', '1' ) === 0;
			if ( self::object_property( $index, 'Column_name' ) === $column && ( ! $unique || $is_unique ) ) {
				return true;
			}
		}

		return false;
	}

	private static function composite_index_exists( string $table, array $columns, bool $unique ): bool {
		global $wpdb;
		if ( ! self::table_exists( $table ) || empty( $columns ) ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
		$indexes = $wpdb->get_results( 'SHOW INDEX FROM ' . self::quote_identifier( $table ) ) ?: [];
		$by_key  = [];
		foreach ( $indexes as $index ) {
			$key_name = self::object_property( $index, 'Key_name' );
			if ( $key_name === '' ) {
				continue;
			}
			$by_key[ $key_name ][] = [
				'column' => self::object_property( $index, 'Column_name' ),
				'seq'    => (int) self::object_property( $index, 'Seq_in_index', '0' ),
				'unique' => (int) self::object_property( $index, 'Non_unique', '1' ) === 0,
			];
		}

		foreach ( $by_key as $parts ) {
			usort( $parts, static fn( array $a, array $b ): int => $a['seq'] <=> $b['seq'] );
			$actual_columns = array_column( $parts, 'column' );
			$is_unique      = ! empty( $parts[0]['unique'] );
			if ( $actual_columns === $columns && ( ! $unique || $is_unique ) ) {
				return true;
			}
		}

		return false;
	}

	private static function primary_key_exists( string $table, string $column ): bool {
		global $wpdb;
		if ( ! self::table_exists( $table ) ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal schema identifier quoted by quote_identifier().
		$indexes = $wpdb->get_results( 'SHOW INDEX FROM ' . self::quote_identifier( $table ) ) ?: [];
		foreach ( $indexes as $index ) {
			if ( self::object_property( $index, 'Key_name' ) === 'PRIMARY' && self::object_property( $index, 'Column_name' ) === $column ) {
				return true;
			}
		}

		return false;
	}

	private static function object_property( object $object, string $property, string $default = '' ): string {
		return isset( $object->{$property} ) ? (string) $object->{$property} : $default;
	}

	private static function create_tables(): void {
		global $wpdb;
		$charset = $wpdb->get_charset_collate();
		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		// ------------------------------------------------------------------ //
		// wpq_questionnaires
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_questionnaires (
			id                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
			organisation_id       BIGINT       NOT NULL DEFAULT 1,
			ref                   VARCHAR(20)  NOT NULL,
			category              VARCHAR(50)  NOT NULL,
			name                  VARCHAR(200) NOT NULL,
			description           TEXT         NOT NULL,
			source_name           VARCHAR(200)     NULL,
			source_question_set   VARCHAR(100)     NULL,
			source_effective_date DATE             NULL,
			source_version        VARCHAR(20)      NULL,
			source_file           VARCHAR(200)     NULL,
			source_type           VARCHAR(50)      NULL,
			source_sheet          VARCHAR(100)     NULL,
			library_version       VARCHAR(20)      NULL,
			library_id            VARCHAR(20)      NULL,
			library_family        VARCHAR(100)     NULL,
			created_by_seed       TINYINT(1)   NOT NULL DEFAULT 0,
			is_customised         TINYINT(1)   NOT NULL DEFAULT 0,
			stripe_product_id     VARCHAR(100)     NULL,
			stripe_price          INT UNSIGNED     NULL,
			stripe_currency       VARCHAR(3)   NOT NULL DEFAULT 'GBP',
			claude_project_id     VARCHAR(200)     NULL,
			claude_project_name   VARCHAR(200)     NULL,
			claude_project_status ENUM('not_started','configured','manual_configuration_required','failed') NOT NULL DEFAULT 'not_started',
			claude_project_verified_at DATETIME    NULL,
			claude_project_last_error TEXT         NULL,
			claude_template_attachment_id BIGINT UNSIGNED NULL,
			claude_template_checksum VARCHAR(64)   NULL,
			claude_template_updated_at DATETIME    NULL,
			remediation_plan_enabled ENUM('inherit','enabled','disabled') NOT NULL DEFAULT 'inherit',
			remediation_template_attachment_id BIGINT UNSIGNED NULL,
			remediation_template_checksum VARCHAR(64)   NULL,
			remediation_template_updated_at DATETIME    NULL,
			questionnaire_report_enabled ENUM('inherit','enabled','disabled') NOT NULL DEFAULT 'inherit',
			questionnaire_report_renderer_mode ENUM('inherit','docx_template','html_dompdf') NOT NULL DEFAULT 'inherit',
			questionnaire_report_delivery_channels VARCHAR(191) NOT NULL DEFAULT '',
			framework_ids VARCHAR(500) NOT NULL DEFAULT '',
			mail_enabled ENUM('inherit','enabled','disabled') NOT NULL DEFAULT 'inherit',
			remediation_delivery_channels VARCHAR(191) NOT NULL DEFAULT '',
			status                ENUM('draft','preview','live','retired') NOT NULL DEFAULT 'draft',
			created_at            DATETIME     NOT NULL,
			updated_at            DATETIME     NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY ref (ref)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_domains
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_domains (
			id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
			questionnaire_id   INT UNSIGNED NOT NULL,
			sort_order         INT          NOT NULL DEFAULT 0,
			slug               VARCHAR(50)  NOT NULL,
			name               VARCHAR(100) NOT NULL,
			icon               VARCHAR(10)  NOT NULL DEFAULT '',
			domain_weight      SMALLINT UNSIGNED NOT NULL DEFAULT 100,
			brief              TEXT NULL,
			PRIMARY KEY (id),
			KEY questionnaire_id (questionnaire_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_questions
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_questions (
			id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
			domain_id        INT UNSIGNED NOT NULL,
			sort_order       INT          NOT NULL DEFAULT 0,
			question_text    TEXT         NOT NULL,
			guidance_yes     TEXT         NOT NULL,
			guidance_no      TEXT         NOT NULL,
			guidance_partial TEXT         NOT NULL DEFAULT '',
			recommendation   TEXT         NOT NULL DEFAULT '',
			score_yes        TINYINT      NOT NULL DEFAULT 2,
			score_partial    TINYINT      NOT NULL DEFAULT 1,
			score_no         TINYINT      NOT NULL DEFAULT 0,
			question_type    ENUM('tri_state','boolean','select','radio','checkbox','memo','short_text','number') NOT NULL DEFAULT 'tri_state',
			is_required      TINYINT(1)   NOT NULL DEFAULT 1,
			scoring_mode     ENUM('legacy_tri_state','boolean','single_option','sum_selected','max_selected','non_scoring','reverse_boolean') NOT NULL DEFAULT 'legacy_tri_state',
			max_score        TINYINT          NULL,
			help_text        TEXT             NULL,
			question_ref     VARCHAR(20)      NULL,
			min_selections   TINYINT          NULL,
			max_selections   TINYINT          NULL,
			condition_on_ref VARCHAR(20)      NULL,
			condition_value  VARCHAR(100)     NULL,
			condition_op     ENUM('eq','ne','contains','not_contains') NOT NULL DEFAULT 'eq',
			answer_type_raw  VARCHAR(50)      NULL,
			created_by_seed  TINYINT(1)   NOT NULL DEFAULT 0,
			library_version  VARCHAR(20)      NULL,
			question_weight  SMALLINT UNSIGNED NOT NULL DEFAULT 100,
			PRIMARY KEY (id),
			KEY domain_id (domain_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_question_options
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_question_options (
			id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
			question_id      INT UNSIGNED NOT NULL,
			option_key       VARCHAR(100) NOT NULL,
			option_label     VARCHAR(255) NOT NULL,
			score            TINYINT      NOT NULL DEFAULT 0,
			risk_level       VARCHAR(30)      NULL,
			finding_priority VARCHAR(30)      NULL,
			finding_action   TEXT             NULL,
			guidance         TEXT             NULL,
			sort_order       INT          NOT NULL DEFAULT 0,
			is_default       TINYINT(1)   NOT NULL DEFAULT 0,
			is_active        TINYINT(1)   NOT NULL DEFAULT 1,
			requires_notes   TINYINT(1)   NOT NULL DEFAULT 0,
			exclusive        TINYINT(1)   NOT NULL DEFAULT 0,
			created_by_seed  TINYINT(1)   NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY question_id (question_id),
			UNIQUE KEY question_option (question_id, option_key)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_grade_thresholds
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_grade_thresholds (
			id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
			questionnaire_id  INT UNSIGNED NOT NULL,
			min_score         INT          NOT NULL,
			grade_id          VARCHAR(30)  NOT NULL,
			grade_label       VARCHAR(100) NOT NULL,
			verdict_text      TEXT         NOT NULL,
			color_hex         VARCHAR(7)   NOT NULL DEFAULT '#333333',
			bg_hex            VARCHAR(7)   NOT NULL DEFAULT '#f5f5f5',
			PRIMARY KEY (id),
			KEY questionnaire_id (questionnaire_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_ctas
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_ctas (
			id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			category_slug  VARCHAR(100)    NOT NULL,
			domain_slug    VARCHAR(100)    NOT NULL DEFAULT '',
			body_html      LONGTEXT        NOT NULL,
			status         ENUM('active','inactive') NOT NULL DEFAULT 'active',
			created_at     DATETIME        NOT NULL,
			updated_at     DATETIME        NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY category_domain (category_slug, domain_slug),
			KEY category_slug (category_slug),
			KEY domain_slug (domain_slug),
			KEY status (status)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_products
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_products (
			id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
			organisation_id   BIGINT       NOT NULL DEFAULT 1,
			questionnaire_id  INT UNSIGNED     NULL,
			name              VARCHAR(200) NOT NULL,
			slug              VARCHAR(100) NOT NULL,
			description       TEXT         NOT NULL,
			price_gbp         DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			stripe_price_id   VARCHAR(100) NOT NULL DEFAULT '',
			billing_type      ENUM('one_off','subscription_annual','subscription_monthly') NOT NULL DEFAULT 'one_off',
			report_type       ENUM('professional','annual','bundle') NOT NULL DEFAULT 'professional',
			status            ENUM('active','inactive') NOT NULL DEFAULT 'active',
			created_at        DATETIME     NOT NULL,
			updated_at        DATETIME     NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY slug (slug),
			KEY questionnaire_id (questionnaire_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_submissions
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_submissions (
			id                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
			organisation_id       BIGINT       NOT NULL DEFAULT 1,
			questionnaire_id      INT UNSIGNED NOT NULL,
			contact_id            BIGINT UNSIGNED  NULL,
			questionnaire_ref_snapshot VARCHAR(20)  NULL,
			questionnaire_version_snapshot VARCHAR(50) NULL,
			scoring_schema_version VARCHAR(20)      NULL,
			ref                   VARCHAR(20)  NOT NULL,
			contact_name          VARCHAR(200) NOT NULL DEFAULT '',
			contact_email         VARCHAR(200) NOT NULL DEFAULT '',
			contact_company       VARCHAR(200) NOT NULL DEFAULT '',
			contact_phone         VARCHAR(50)  NOT NULL DEFAULT '',
			overall_score         INT              NULL,
			grade_id              VARCHAR(30)      NULL,
			answers_json          LONGTEXT         NULL,
			domain_scores_json    LONGTEXT         NULL,
			findings_json         LONGTEXT         NULL,
			question_snapshot_json LONGTEXT        NULL,
			option_snapshot_json  LONGTEXT         NULL,
			grade_threshold_snapshot_json LONGTEXT NULL,
			cta_snapshot_json     LONGTEXT         NULL,
			claude_provider_mode  VARCHAR(50)      NULL,
			claude_project_id     VARCHAR(200)     NULL,
			claude_conversation_id VARCHAR(100)    NULL,
			claude_conversation_title VARCHAR(255) NULL,
			claude_status         ENUM('not_started','pending','ready','processing','completed','failed','manual_configuration_required') NOT NULL DEFAULT 'not_started',
			claude_created_at     DATETIME         NULL,
			claude_last_success_at DATETIME        NULL,
			claude_last_error     TEXT             NULL,
			claude_request_id     VARCHAR(100)     NULL,
			claude_model_used     VARCHAR(100)     NULL,
			claude_prompt_version VARCHAR(50)      NULL,
			ai_report_status      ENUM('not_requested','pending','processing','completed','failed') NOT NULL DEFAULT 'not_requested',
			ai_report_docx_path   VARCHAR(500)     NULL,
			ai_report_pdf_path    VARCHAR(500)     NULL,
			ai_report_generated_at DATETIME        NULL,
			ai_report_template_checksum VARCHAR(64) NULL,
			ai_report_output_checksum VARCHAR(64)  NULL,
			qr_status             ENUM('not_requested','queued','analysing','rendering_docx','converting_pdf','completed','partial','failed') NOT NULL DEFAULT 'not_requested',
			qr_renderer_mode      VARCHAR(20)      NULL,
			qr_claude_request_id  VARCHAR(100)     NULL,
			qr_model_used         VARCHAR(100)     NULL,
			qr_prompt_version     VARCHAR(50)      NULL,
			qr_context_version    VARCHAR(50)      NULL,
			qr_template_checksum  VARCHAR(64)      NULL,
			qr_docx_path          VARCHAR(500)     NULL,
			qr_docx_checksum      VARCHAR(64)      NULL,
			qr_pdf_path           VARCHAR(500)     NULL,
			qr_pdf_checksum       VARCHAR(64)      NULL,
			qr_generated_at       DATETIME         NULL,
			qr_requested_at       DATETIME         NULL,
			qr_last_stage         VARCHAR(30)      NULL,
			qr_failure_code       VARCHAR(50)      NULL,
			qr_failure_message    TEXT             NULL,
			qr_generation_token   VARCHAR(64)      NULL,
			qr_analysis_json      LONGTEXT         NULL,
			qr_email_sent_at      DATETIME         NULL,
			remediation_xlsx_path VARCHAR(255)     NULL,
			product_id            INT UNSIGNED     NULL,
			payment_status        ENUM('none','pending','paid','failed','expired') NOT NULL DEFAULT 'none',
			stripe_session_id     VARCHAR(255)     NULL,
			report_product_id     INT UNSIGNED     NULL,
			report_path           VARCHAR(500)     NULL,
			report_generated_at   DATETIME         NULL,
			report_error          TEXT             NULL,
			halopsa_lead_id           VARCHAR(100)     NULL,
			session_token             VARCHAR(64)  NOT NULL DEFAULT '',
			halopsa_sync_status       ENUM('pending','processing','synced','failed','retry_pending','ignored','manual_review','skipped') NOT NULL DEFAULT 'pending',
			halopsa_synced_at         DATETIME         NULL,
			halopsa_last_attempted_at DATETIME         NULL,
			halopsa_retry_count       INT UNSIGNED NOT NULL DEFAULT 0,
			halopsa_sync_error        TEXT             NULL,
			utm_source            VARCHAR(200)     NULL,
			utm_medium            VARCHAR(200)     NULL,
			utm_campaign          VARCHAR(200)     NULL,
			utm_term              VARCHAR(200)     NULL,
			utm_content           VARCHAR(200)     NULL,
			referrer_url          VARCHAR(500)     NULL,
			landing_page          VARCHAR(500)     NULL,
			started_at            DATETIME         NULL,
			completed_at          DATETIME         NULL,
			duration_seconds      INT              NULL,
			abandoned             TINYINT     NOT NULL DEFAULT 1,
			consent_accepted_at   DATETIME         NULL,
			deleted_at            DATETIME         NULL,
			deleted_by_user_id    BIGINT           NULL,
			last_question_answered VARCHAR(10)     NULL,
			ip_address            VARCHAR(45)      NULL,
			created_at            DATETIME     NOT NULL,
			updated_at            DATETIME     NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY ref (ref),
			KEY questionnaire_id (questionnaire_id),
			KEY contact_email (contact_email),
			KEY claude_conversation_id (claude_conversation_id),
			KEY claude_status (claude_status),
			KEY halopsa_sync_status (halopsa_sync_status),
			KEY abandoned (abandoned)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_payment_sessions
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_payment_sessions (
			session_id      VARCHAR(255) NOT NULL,
			submission_id   INT UNSIGNED NOT NULL,
			product_id      INT UNSIGNED     NULL,
			payment_status  ENUM('none','pending','paid','failed','expired') NOT NULL DEFAULT 'pending',
			answers_hash    VARCHAR(64)  NOT NULL DEFAULT '',
			amount_total    BIGINT           NULL,
			currency        VARCHAR(10)      NULL,
			created_at      DATETIME     NOT NULL,
			updated_at      DATETIME     NOT NULL,
			PRIMARY KEY (session_id),
			KEY submission_id (submission_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_frameworks  (reserved — Phase 5)
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_payment_events (
			id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			stripe_event_id    VARCHAR(255)    NOT NULL,
			stripe_session_id  VARCHAR(255)    NOT NULL,
			submission_id      INT UNSIGNED    NOT NULL,
			product_id         INT UNSIGNED        NULL,
			event_type         VARCHAR(100)    NOT NULL DEFAULT '',
			previous_status    VARCHAR(30)         NULL,
			new_status         VARCHAR(30)     NOT NULL DEFAULT '',
			amount_total       BIGINT              NULL,
			currency           VARCHAR(10)         NULL,
			payload_json       LONGTEXT            NULL,
			processed_at       DATETIME            NULL,
			created_at         DATETIME        NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY stripe_event_id (stripe_event_id),
			KEY stripe_session_id (stripe_session_id),
			KEY submission_id (submission_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_report_tokens
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_report_tokens (
			id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			submission_id  INT UNSIGNED    NOT NULL,
			token_hash     VARCHAR(64)     NOT NULL,
			purpose        VARCHAR(30)     NOT NULL DEFAULT 'paid_report',
			expires_at     DATETIME        NOT NULL,
			used_at        DATETIME            NULL,
			use_count      INT             NOT NULL DEFAULT 0,
			max_uses       INT             NOT NULL DEFAULT 5,
			created_at     DATETIME        NOT NULL,
			revoked_at     DATETIME            NULL,
			PRIMARY KEY (id),
			UNIQUE KEY token_hash (token_hash),
			KEY submission_id (submission_id),
			KEY expires_at (expires_at)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_enquiry_forms  (admin-composed contact forms)
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_enquiry_forms (
			id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
			ref           VARCHAR(50)  NOT NULL,
			name          VARCHAR(200) NOT NULL,
			description   TEXT         NOT NULL,
			status        ENUM('draft','published') NOT NULL DEFAULT 'draft',
			fields_json   LONGTEXT         NULL,
			mail_enabled  ENUM('inherit','enabled','disabled') NOT NULL DEFAULT 'inherit',
			notify_email  VARCHAR(190)     NULL,
			send_ack      ENUM('yes','no') NOT NULL DEFAULT 'no',
			created_at    DATETIME     NOT NULL,
			updated_at    DATETIME     NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY ref (ref)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_enquiries  (received enquiries — registered contacts)
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_enquiries (
			id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id         INT UNSIGNED NOT NULL,
			contact_id      BIGINT UNSIGNED  NULL,
			ref             VARCHAR(50)  NOT NULL,
			contact_name    VARCHAR(200) NOT NULL,
			contact_email   VARCHAR(190) NOT NULL,
			contact_company VARCHAR(200)     NULL,
			contact_phone   VARCHAR(50)      NULL,
			consent         TINYINT(1)   NOT NULL DEFAULT 0,
			fields_json     LONGTEXT         NULL,
			status          ENUM('new','seen') NOT NULL DEFAULT 'new',
			created_at      DATETIME     NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY ref (ref),
			KEY form_id (form_id),
			KEY contact_email (contact_email)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_audit_log
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_audit_log (
			id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_type      VARCHAR(100)    NOT NULL,
			actor_user_id   BIGINT UNSIGNED     NULL,
			actor_email     VARCHAR(190)        NULL,
			object_type     VARCHAR(100)    NOT NULL,
			object_id       BIGINT UNSIGNED     NULL,
			before_summary  LONGTEXT            NULL,
			after_summary   LONGTEXT            NULL,
			ip_hash         VARCHAR(64)         NULL,
			user_agent      VARCHAR(255)        NULL,
			created_at      DATETIME        NOT NULL,
			PRIMARY KEY (id),
			KEY event_type (event_type),
			KEY actor_user_id (actor_user_id),
			KEY object_type_id (object_type, object_id),
			KEY created_at (created_at)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_rate_limits
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_rate_limits (
			id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			bucket_key         VARCHAR(191)    NOT NULL,
			endpoint           VARCHAR(100)    NOT NULL,
			client_hash        VARCHAR(64)     NOT NULL,
			questionnaire_ref  VARCHAR(50)         NULL,
			submission_id      BIGINT UNSIGNED     NULL,
			email_hash         VARCHAR(64)         NULL,
			window_start       DATETIME        NOT NULL,
			request_count      INT UNSIGNED    NOT NULL DEFAULT 1,
			expires_at         DATETIME        NOT NULL,
			created_at         DATETIME        NOT NULL,
			updated_at         DATETIME        NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY bucket_key (bucket_key),
			KEY endpoint_expires (endpoint, expires_at),
			KEY expires_at (expires_at),
			KEY submission_id (submission_id),
			KEY email_hash (email_hash)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_frameworks (
			id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
			slug         VARCHAR(50)  NOT NULL,
			name         VARCHAR(200) NOT NULL,
			version      VARCHAR(50)  NOT NULL DEFAULT '',
			description  TEXT         NOT NULL,
			status       ENUM('active','inactive') NOT NULL DEFAULT 'active',
			skill_id     VARCHAR(100)     NULL,
			skill_version VARCHAR(50)     NULL,
			skill_checksum VARCHAR(64)    NULL,
			skill_bundle VARCHAR(255)     NULL,
			skill_imported_at DATETIME    NULL,
			PRIMARY KEY (id),
			UNIQUE KEY slug (slug)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_framework_controls  (reserved — Phase 5)
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_framework_controls (
			id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
			framework_id  INT UNSIGNED NOT NULL,
			control_ref   VARCHAR(50)  NOT NULL,
			control_name  VARCHAR(200) NOT NULL,
			domain        VARCHAR(100) NOT NULL DEFAULT '',
			description   TEXT         NOT NULL,
			PRIMARY KEY (id),
			KEY framework_id (framework_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_question_control_mappings  (reserved — Phase 5)
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_question_control_mappings (
			id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
			question_id          INT UNSIGNED NOT NULL,
			framework_control_id INT UNSIGNED NOT NULL,
			relevance            ENUM('primary','secondary') NOT NULL DEFAULT 'primary',
			PRIMARY KEY (id),
			KEY question_id (question_id),
			KEY framework_control_id (framework_control_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_coupons
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_coupons (
			id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
			stripe_coupon_id   VARCHAR(100) NOT NULL,
			stripe_promo_id    VARCHAR(100)     NULL,
			promo_code         VARCHAR(50)      NULL,
			name               VARCHAR(200) NOT NULL,
			discount_type      ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
			percent_off        TINYINT UNSIGNED NULL,
			amount_off         INT UNSIGNED NULL,
			currency           VARCHAR(3)       NULL,
			duration           ENUM('once','repeating','forever') NOT NULL DEFAULT 'once',
			duration_in_months SMALLINT UNSIGNED NULL,
			max_redemptions    INT UNSIGNED NULL,
			redeem_by          DATETIME         NULL,
			scope              ENUM('all','questionnaire','catalogue_item') NOT NULL DEFAULT 'all',
			questionnaire_id   INT UNSIGNED     NULL,
			product_id         INT UNSIGNED     NULL,
			status             ENUM('active','deleted') NOT NULL DEFAULT 'active',
			created_at         DATETIME         NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY stripe_coupon_id (stripe_coupon_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_contact_preferences
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_preferences (
			id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
			email                VARCHAR(200) NOT NULL,
			opted_out            TINYINT(1)   NOT NULL DEFAULT 1,
			opted_out_at         DATETIME     NOT NULL,
			opted_out_by_user_id BIGINT           NULL,
			PRIMARY KEY (id),
			UNIQUE KEY email (email)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// Canonical contact master (schema reference: .roadmap/contact-master/)
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contacts (
			id                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			uuid                   CHAR(36)        NOT NULL,
			wp_user_id             BIGINT UNSIGNED     NULL,
			given_name             VARCHAR(100)    NOT NULL DEFAULT '',
			family_name            VARCHAR(100)    NOT NULL DEFAULT '',
			display_name           VARCHAR(191)    NOT NULL DEFAULT '',
			organisation           VARCHAR(191)    NOT NULL DEFAULT '',
			job_title              VARCHAR(100)        NULL,
			status                 ENUM('provisional','active','restricted','suppressed','anonymised','merged','deleted') NOT NULL DEFAULT 'provisional',
			merged_into_contact_id BIGINT UNSIGNED     NULL,
			created_source         VARCHAR(50)     NOT NULL DEFAULT '',
			first_observed_at      DATETIME            NULL,
			last_observed_at       DATETIME            NULL,
			verified_at            DATETIME            NULL,
			anonymised_at          DATETIME            NULL,
			deleted_at             DATETIME            NULL,
			created_at             DATETIME        NOT NULL,
			updated_at             DATETIME        NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY uuid (uuid),
			KEY wp_user_id (wp_user_id),
			KEY status (status),
			KEY last_observed_at (last_observed_at)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_identities (
			id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id        BIGINT UNSIGNED NOT NULL,
			type              ENUM('email','telephone') NOT NULL DEFAULT 'email',
			value_original    VARCHAR(255)    NOT NULL,
			value_normalised  VARCHAR(255)    NOT NULL,
			value_hash        CHAR(64)        NOT NULL,
			verification      ENUM('unverified','verified','bounced','complained','revoked','superseded') NOT NULL DEFAULT 'unverified',
			verified_at       DATETIME            NULL,
			is_primary        TINYINT(1)      NOT NULL DEFAULT 0,
			source_type       VARCHAR(30)     NOT NULL DEFAULT '',
			source_id         BIGINT UNSIGNED     NULL,
			first_observed_at DATETIME            NULL,
			last_observed_at  DATETIME            NULL,
			superseded_at     DATETIME            NULL,
			created_at        DATETIME        NOT NULL,
			updated_at        DATETIME        NOT NULL,
			PRIMARY KEY (id),
			KEY contact_id (contact_id),
			KEY type_hash (type, value_hash)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_organisations (
			id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id        BIGINT UNSIGNED NOT NULL,
			organisation_name VARCHAR(191)    NOT NULL,
			organisation_id   BIGINT UNSIGNED     NULL,
			relationship      VARCHAR(30)     NOT NULL DEFAULT 'employee',
			is_primary        TINYINT(1)      NOT NULL DEFAULT 0,
			source            VARCHAR(50)     NOT NULL DEFAULT '',
			valid_from        DATETIME            NULL,
			valid_until       DATETIME            NULL,
			created_at        DATETIME        NOT NULL,
			PRIMARY KEY (id),
			KEY contact_id (contact_id)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_interactions (
			id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id       BIGINT UNSIGNED NOT NULL,
			product          VARCHAR(40)     NOT NULL DEFAULT 'wp-questionnaires',
			interaction_type VARCHAR(40)     NOT NULL,
			source_type      VARCHAR(40)     NOT NULL,
			source_id        BIGINT UNSIGNED NOT NULL,
			source_ref       VARCHAR(64)     NOT NULL DEFAULT '',
			questionnaire_id INT UNSIGNED        NULL,
			occurred_at      DATETIME        NOT NULL,
			completion_state VARCHAR(20)     NOT NULL DEFAULT '',
			organisation     VARCHAR(191)    NOT NULL DEFAULT '',
			attribution      VARCHAR(191)        NULL,
			created_at       DATETIME        NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY dedupe (product, source_type, source_id, interaction_type),
			KEY contact_id (contact_id),
			KEY interaction_type (interaction_type),
			KEY occurred_at (occurred_at)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_consent_events (
			id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id        BIGINT UNSIGNED NOT NULL,
			identity_id       BIGINT UNSIGNED     NULL,
			purpose           VARCHAR(40)     NOT NULL,
			event             ENUM('granted','declined','withdrawn','objected','suppressed','administratively_corrected') NOT NULL,
			statement_version VARCHAR(20)     NOT NULL DEFAULT '',
			notice_version    VARCHAR(20)     NOT NULL DEFAULT '',
			source            VARCHAR(50)     NOT NULL DEFAULT '',
			actor             VARCHAR(100)    NOT NULL DEFAULT '',
			occurred_at       DATETIME        NOT NULL,
			evidence          TEXT                NULL,
			reason            TEXT                NULL,
			created_at        DATETIME        NOT NULL,
			PRIMARY KEY (id),
			KEY contact_purpose (contact_id, purpose)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_preferences_current (
			id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id  BIGINT UNSIGNED NOT NULL,
			purpose     VARCHAR(40)     NOT NULL,
			identity_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			state       VARCHAR(20)     NOT NULL,
			updated_at  DATETIME        NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY contact_purpose_identity (contact_id, purpose, identity_id)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_merge_log (
			id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			survivor_id    BIGINT UNSIGNED NOT NULL,
			absorbed_id    BIGINT UNSIGNED NOT NULL,
			reason         TEXT                NULL,
			actor          VARCHAR(100)    NOT NULL DEFAULT '',
			before_summary LONGTEXT            NULL,
			resolutions    LONGTEXT            NULL,
			recovery       LONGTEXT            NULL,
			created_at     DATETIME        NOT NULL,
			PRIMARY KEY (id),
			KEY survivor_id (survivor_id),
			KEY absorbed_id (absorbed_id)
		) $charset;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_contact_match_review (
			id                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source_type           VARCHAR(40)     NOT NULL,
			source_id             BIGINT UNSIGNED NOT NULL,
			candidate_contact_ids VARCHAR(255)    NOT NULL DEFAULT '',
			reason                VARCHAR(100)    NOT NULL DEFAULT '',
			details               LONGTEXT            NULL,
			status                ENUM('pending','resolved','deferred','ignored') NOT NULL DEFAULT 'pending',
			resolution            VARCHAR(40)         NULL,
			resolved_by           VARCHAR(100)        NULL,
			resolved_at           DATETIME            NULL,
			created_at            DATETIME        NOT NULL,
			PRIMARY KEY (id),
			KEY status (status),
			KEY source (source_type, source_id)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_categories
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_categories (
			id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
			slug       VARCHAR(50)  NOT NULL,
			name       VARCHAR(100) NOT NULL,
			sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			UNIQUE KEY slug (slug)
		) $charset;" );

		// ------------------------------------------------------------------ //
		// wpq_library_log
		// ------------------------------------------------------------------ //
		dbDelta( "CREATE TABLE {$wpdb->prefix}wpq_library_log (
			id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
			library_version  VARCHAR(20)  NOT NULL,
			run_at           DATETIME     NOT NULL,
			q_seeded         INT          NOT NULL DEFAULT 0,
			q_skipped        INT          NOT NULL DEFAULT 0,
			q_errors         INT          NOT NULL DEFAULT 0,
			questions_seeded INT          NOT NULL DEFAULT 0,
			options_seeded   INT          NOT NULL DEFAULT 0,
			unsupported_types TEXT             NULL,
			skipped_refs      TEXT             NULL,
			PRIMARY KEY (id)
		) $charset;" );
	}
}
