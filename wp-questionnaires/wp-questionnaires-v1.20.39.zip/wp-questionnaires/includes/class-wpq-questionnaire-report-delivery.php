<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Decides how a finished Questionnaire Report reaches the customer.
 *
 * Delivery is configured as a *list of enabled channel keys* rather than a
 * fixed set of on/off settings, so adding a future channel means adding one
 * entry to self::channels() - no schema change, no option-shape change, and no
 * new column. A site can enable any combination, globally or per questionnaire.
 *
 * Every channel hands out the same thing: a tokenised, expiring, use-limited
 * link to the generated PDF, served through a single public route. The report
 * is never attached to an email and the storage directory is never exposed, so
 * access can always be withdrawn by revoking the token or deleting the
 * artefact.
 */
class WPQ_Questionnaire_Report_Delivery {

	/** Link offered on the results screen once the report finishes generating. */
	public const CHANNEL_RESULTS_LINK = 'results_link';

	/** Link offered on the post-payment screen, for submissions tied to a priced product. */
	public const CHANNEL_POST_CHECKOUT = 'post_checkout';

	/** Link emailed to the customer when the report finishes generating. */
	public const CHANNEL_EMAIL = 'email';

	public const TOKEN_PURPOSE = 'questionnaire_report';

	/** A delivery link outlives a slow reader but not a stale mailbox. */
	public const TOKEN_TTL_SECONDS = 30 * DAY_IN_SECONDS;
	public const TOKEN_MAX_USES    = 10;

	private const OPTION_CHANNELS      = 'wpq_questionnaire_report_delivery_channels';
	private const OPTION_EMAIL_SUBJECT = 'wpq_questionnaire_report_email_subject';
	private const OPTION_EMAIL_INTRO   = 'wpq_questionnaire_report_email_intro';

	/** Report generation states in which a customer-facing "still working" message is honest. */
	private const GENERATING_STATES = [ 'queued', 'analysing', 'rendering_docx', 'converting_pdf' ];

	/**
	 * The available delivery channels. This is the single place a channel is
	 * defined; everything else works from these keys.
	 *
	 * @return array<string, array{label: string, description: string, pull: bool}>
	 */
	public static function channels(): array {
		return [
			self::CHANNEL_RESULTS_LINK => [
				'label'       => 'Secure link on the results screen',
				'description' => 'Offers a download link on the results screen once the report has finished generating.',
				'pull'        => true,
			],
			self::CHANNEL_POST_CHECKOUT => [
				'label'       => 'Secure link after checkout',
				'description' => 'Offers the same download link on the post-payment screen. Applies only to submissions linked to a priced product.',
				'pull'        => true,
			],
			self::CHANNEL_EMAIL => [
				'label'       => 'Email the customer a secure link',
				'description' => 'Emails the customer a download link when the report is ready. The report itself is never attached.',
				'pull'        => false,
			],
		];
	}

	/** @return array<int, string> */
	public static function channel_keys(): array {
		return array_keys( self::channels() );
	}

	/**
	 * Channels enabled site-wide. Unknown keys (e.g. a channel removed in a later
	 * release) are dropped rather than trusted.
	 *
	 * @return array<int, string>
	 */
	public static function global_channels(): array {
		return self::normalise( (string) get_option( self::OPTION_CHANNELS, '' ) );
	}

	/**
	 * Channels for one questionnaire: its own list when it defines one, the
	 * global list otherwise. An empty per-questionnaire value means "inherit",
	 * which is why disabling every channel for a single questionnaire is
	 * expressed with the explicit "none" marker rather than an empty string.
	 *
	 * @return array<int, string>
	 */
	public static function channels_for_questionnaire( ?object $questionnaire ): array {
		$override = trim( (string) ( $questionnaire->questionnaire_report_delivery_channels ?? '' ) );
		if ( '' === $override ) {
			return self::global_channels();
		}
		if ( 'none' === strtolower( $override ) ) {
			return [];
		}

		return self::normalise( $override );
	}

	public static function channel_enabled( ?object $questionnaire, string $channel ): bool {
		return in_array( $channel, self::channels_for_questionnaire( $questionnaire ), true );
	}

	/** True when any channel at all would put this report in front of a customer. */
	public static function delivery_enabled( ?object $questionnaire ): bool {
		if ( ! $questionnaire || ! class_exists( 'WPQ_Feature_Flags' ) ) {
			return false;
		}
		if ( ! WPQ_Feature_Flags::questionnaire_report_enabled_for_questionnaire( $questionnaire ) ) {
			return false;
		}

		return ! empty( self::channels_for_questionnaire( $questionnaire ) );
	}

	/**
	 * Normalise a stored channel list (comma-separated or JSON) to known keys,
	 * de-duplicated and in the canonical order channels() defines.
	 *
	 * @return array<int, string>
	 */
	public static function normalise( string $stored ): array {
		$stored = trim( $stored );
		if ( '' === $stored ) {
			return [];
		}

		$decoded = json_decode( $stored, true );
		$values  = is_array( $decoded ) ? $decoded : explode( ',', $stored );

		$clean = [];
		foreach ( $values as $value ) {
			if ( ! is_scalar( $value ) ) {
				continue;
			}
			$key = sanitize_key( (string) $value );
			if ( '' !== $key && ! in_array( $key, $clean, true ) ) {
				$clean[] = $key;
			}
		}

		// Canonical order, and unknown keys dropped.
		return array_values( array_intersect( self::channel_keys(), $clean ) );
	}

	/**
	 * @param array<int, string> $channels
	 */
	public static function to_storage( array $channels ): string {
		$clean = self::normalise( implode( ',', array_map( 'strval', $channels ) ) );
		return implode( ',', $clean );
	}

	/**
	 * Run the push channels for a report that has just finished generating.
	 * Pull channels (results screen, post-checkout) need nothing here - they mint
	 * a link on demand when the customer asks for one.
	 *
	 * @return array{email_sent: bool, reason: string}
	 */
	public static function deliver( object $submission, ?object $questionnaire ): array {
		if ( ! self::channel_enabled( $questionnaire, self::CHANNEL_EMAIL ) ) {
			return [ 'email_sent' => false, 'reason' => 'email_channel_disabled' ];
		}
		if ( class_exists( 'WPQ_Mailer' ) && ! WPQ_Mailer::allowed_for_questionnaire( $questionnaire ) ) {
			return [ 'email_sent' => false, 'reason' => 'mail_delivery_disabled' ];
		}
		if ( ! empty( $submission->qr_email_sent_at ) ) {
			return [ 'email_sent' => false, 'reason' => 'already_sent' ];
		}
		if ( 'completed' !== (string) ( $submission->qr_status ?? '' ) || empty( $submission->qr_pdf_path ) ) {
			return [ 'email_sent' => false, 'reason' => 'report_not_ready' ];
		}

		$email = sanitize_email( (string) ( $submission->contact_email ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return [ 'email_sent' => false, 'reason' => 'no_contact_email' ];
		}

		$link = self::mint_link( (int) $submission->id );
		if ( '' === $link ) {
			return [ 'email_sent' => false, 'reason' => 'link_unavailable' ];
		}

		$sent = self::send_email( $email, $submission, $questionnaire, $link );
		if ( $sent ) {
			WPQ_Database::update_submission_questionnaire_report( (int) $submission->id, [
				'qr_email_sent_at' => current_time( 'mysql', true ),
			] );
		}

		return [ 'email_sent' => $sent, 'reason' => $sent ? 'sent' : 'send_failed' ];
	}

	/**
	 * Admin-initiated resend: mints a fresh token and re-sends the delivery
	 * email even when one was already sent (the qr_email_sent_at idempotency
	 * stamp exists to stop *automatic* duplicates, not an administrator
	 * deliberately re-delivering after a customer exhausted or lost their
	 * link). Still refuses when mail is disabled for the questionnaire or the
	 * report artefact is not actually downloadable.
	 *
	 * @return array{email_sent: bool, reason: string}
	 */
	public static function resend_email( object $submission, ?object $questionnaire ): array {
		if ( class_exists( 'WPQ_Mailer' ) && ! WPQ_Mailer::allowed_for_questionnaire( $questionnaire ) ) {
			return [ 'email_sent' => false, 'reason' => 'mail_delivery_disabled' ];
		}
		if ( 'completed' !== (string) ( $submission->qr_status ?? '' ) || empty( $submission->qr_pdf_path ) ) {
			return [ 'email_sent' => false, 'reason' => 'report_not_ready' ];
		}

		$email = sanitize_email( (string) ( $submission->contact_email ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return [ 'email_sent' => false, 'reason' => 'no_contact_email' ];
		}

		$link = self::mint_link( (int) $submission->id );
		if ( '' === $link ) {
			return [ 'email_sent' => false, 'reason' => 'link_unavailable' ];
		}

		$sent = self::send_email( $email, $submission, $questionnaire, $link );
		if ( $sent ) {
			WPQ_Database::update_submission_questionnaire_report( (int) $submission->id, [
				'qr_email_sent_at' => current_time( 'mysql', true ),
			] );
		}

		return [ 'email_sent' => $sent, 'reason' => $sent ? 'sent' : 'send_failed' ];
	}

	/**
	 * Mint a fresh tokenised download URL. Tokens are stored hashed, expire, and
	 * are scoped to this artefact by purpose, so one minted for the paid HTML
	 * report cannot be redeemed here and vice versa.
	 */
	public static function mint_link( int $submission_id ): string {
		if ( $submission_id <= 0 ) {
			return '';
		}

		$token = WPQ_Database::create_report_token(
			$submission_id,
			self::TOKEN_TTL_SECONDS,
			self::TOKEN_MAX_USES,
			self::TOKEN_PURPOSE
		);
		if ( empty( $token['token'] ) ) {
			return '';
		}

		return add_query_arg(
			[ 'token' => (string) $token['token'] ],
			rest_url( WPQ_REST_NAMESPACE . '/questionnaire-report/' . $submission_id )
		);
	}

	/**
	 * What the customer-facing UI should say and offer right now.
	 *
	 * Only ever returns a download URL when a pull channel is enabled and the PDF
	 * genuinely exists, so a caller cannot mint a link for an artefact that has
	 * been deleted or has not finished generating.
	 *
	 * @return array{channels: array<int,string>, status: string, message: string, download_url: string}
	 */
	public static function state_for_submission( object $submission, ?object $questionnaire ): array {
		$channels = self::channels_for_questionnaire( $questionnaire );
		$state    = [
			'channels'     => $channels,
			'status'       => 'unavailable',
			'message'      => '',
			'download_url' => '',
			// Framework readiness radar for the results screen, present once
			// the report run has stored framework assessments. Server-rendered
			// SVG (presentation attributes only) so the CSP-locked frontend
			// can inject it without inline styles or scripts.
			'framework_radar_svg' => class_exists( 'WPQ_Framework_Radar' )
				? WPQ_Framework_Radar::render_svg( WPQ_Framework_Radar::rows_from_analysis( WPQ_Framework_Radar::stored_frameworks( $submission ) ) )
				: '',
		];

		if ( empty( $channels ) || ! self::delivery_enabled( $questionnaire ) ) {
			return $state;
		}

		$status       = (string) ( $submission->qr_status ?? 'not_requested' );
		$email_wanted = in_array( self::CHANNEL_EMAIL, $channels, true );
		$pull_wanted  = self::pull_channel_available( $submission, $channels );

		// A delivery channel can be enabled (e.g. the one-time activation
		// default) on a site where report generation itself was never
		// configured - no Claude/analysis key, no renderer library. If
		// nothing has ever run for this submission and nothing is running
		// now, nothing will ever be produced either - showing this whole
		// section (even with an apologetic message) is just confusing dead
		// UI for a customer who will never get a report. A job already in
		// flight, or a submission with an already-completed report, keeps
		// surfacing normally even if generation was unconfigured afterwards.
		$generation_possible = class_exists( 'WPQ_Questionnaire_Report' ) && WPQ_Questionnaire_Report::is_configured();
		if ( ! $generation_possible && empty( $submission->qr_pdf_path ) && ! in_array( $status, self::GENERATING_STATES, true ) ) {
			$state['channels'] = [];
			return $state;
		}

		if ( in_array( $status, self::GENERATING_STATES, true ) ) {
			$state['status']  = 'generating';
			$state['message'] = $email_wanted
				? 'Your report is being prepared. We will email it to you as soon as it is ready.'
				: 'Your report is being prepared. This page will offer it for download as soon as it is ready.';
			return $state;
		}

		if ( 'completed' === $status && ! empty( $submission->qr_pdf_path ) ) {
			if ( $pull_wanted ) {
				$link = self::mint_link( (int) $submission->id );
				if ( '' !== $link ) {
					$state['status']       = 'ready';
					$state['download_url'] = $link;
					$state['message']      = 'Your report is ready to download.';
					return $state;
				}
			}

			if ( $email_wanted ) {
				$state['status']  = 'emailed';
				$state['message'] = 'Your report has been sent to the email address you provided.';
				return $state;
			}
		}

		// Anything else (not_requested, failed, partial, or completed without a
		// usable channel) is a genuine "nothing is running - a click will start
		// one" state, as long as generation is actually possible: the customer
		// is offered a Generate/try-again button rather than a status message.
		if ( $generation_possible ) {
			$state['status'] = 'not_requested';
			return $state;
		}

		$state['message'] = $email_wanted
			? 'Your report could not be prepared automatically. Our team has been notified and will be in touch.'
			: '';

		return $state;
	}

	/**
	 * @param array<int, string> $channels
	 */
	private static function pull_channel_available( object $submission, array $channels ): bool {
		if ( in_array( self::CHANNEL_RESULTS_LINK, $channels, true ) ) {
			return true;
		}

		// The post-checkout channel only applies once a linked product has been paid for.
		return in_array( self::CHANNEL_POST_CHECKOUT, $channels, true )
			&& 'paid' === (string) ( $submission->payment_status ?? '' );
	}

	public static function email_subject(): string {
		$subject = trim( (string) get_option( self::OPTION_EMAIL_SUBJECT, '' ) );
		return '' !== $subject ? $subject : 'Your assessment report is ready';
	}

	public static function email_intro(): string {
		$intro = trim( (string) get_option( self::OPTION_EMAIL_INTRO, '' ) );
		return '' !== $intro
			? $intro
			: 'Thank you for completing your assessment. Your report is ready to download using the secure link below.';
	}

	private static function send_email( string $email, object $submission, ?object $questionnaire, string $link ): bool {
		$name = trim( (string) ( $submission->contact_name ?? '' ) );
		$body = ( '' !== $name ? 'Hello ' . $name . ',' : 'Hello,' ) . "\n\n"
			. self::email_intro() . "\n\n"
			. $link . "\n\n"
			. sprintf(
				'This link is personal to you and expires in %d days.',
				(int) round( self::TOKEN_TTL_SECONDS / DAY_IN_SECONDS )
			) . "\n\n"
			. ( $questionnaire ? 'Assessment: ' . (string) ( $questionnaire->name ?? '' ) . "\n" : '' )
			. ( ! empty( $submission->ref ) ? 'Reference: ' . (string) $submission->ref . "\n" : '' );

		if ( class_exists( 'WPQ_Mailer' ) ) {
			return WPQ_Mailer::send( $email, self::email_subject(), $body );
		}

		return (bool) wp_mail(
			$email,
			self::email_subject(),
			$body,
			[ 'Content-Type: text/plain; charset=UTF-8' ]
		);
	}
}
