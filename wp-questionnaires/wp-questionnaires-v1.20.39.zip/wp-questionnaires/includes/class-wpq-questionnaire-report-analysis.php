<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Calls Claude to produce the substantive analytical Questionnaire Report
 * content and validates the strict JSON response contract. Kept separate
 * from WPQ_Remediation_Plan's task-generation prompt: this prompt asks for
 * cross-domain synthesis and narrative, not an operational task list.
 *
 * Reuses WPQ_Remediation_Plan's API key resolution and model selection so
 * both features share one Anthropic configuration surface, without
 * duplicating that logic or the remediation task-generation workflow itself.
 */
class WPQ_Questionnaire_Report_Analysis {

	public const PROMPT_VERSION = 'questionnaire-report-v1';

	private const API_URL             = 'https://api.anthropic.com/v1/messages';
	private const API_VERSION         = '2023-06-01';
	private const DEBUG_ENABLED_OPTION = 'wpq_claude_debug_enabled';
	private const DEBUG_LOG_OPTION     = 'wpq_claude_debug_log';
	private const DEBUG_LOG_LIMIT      = 50;

	public const FINDING_ID_PREFIX = 'F';

	private const VALID_PRIORITIES = [ 'Critical', 'High', 'Medium', 'Low' ];
	private const VALID_TIMEFRAMES = [ 'Immediate', '30 days', '60 days', '90 days', 'Strategic' ];

	public static function is_configured(): bool {
		if ( ! class_exists( 'WPQ_Remediation_Plan' ) ) {
			return false;
		}
		$details = WPQ_Remediation_Plan::get_api_key_details();
		return ! empty( $details['present'] );
	}

	/**
	 * @return array{data: array<string, mixed>, meta: array<string, mixed>}
	 */
	public static function analyse( array $context ): array {
		$details = WPQ_Remediation_Plan::get_api_key_details();
		$api_key = (string) ( $details['value'] ?? '' );
		if ( '' === $api_key ) {
			throw new RuntimeException( 'Claude API key missing.' );
		}

		$model      = WPQ_Remediation_Plan::select_model( $api_key );
		// Shared with the remediation plan's own call - one admin-configured
		// ceiling (Settings -> AI), not a value fixed in this class's own code.
		$max_tokens = WPQ_Remediation_Plan::get_max_tokens_preference();
		$timeout    = WPQ_Remediation_Plan::timeout_for_max_tokens( $max_tokens );
		$prompt     = self::build_prompt( $context );

		$request_meta = [
			'endpoint'     => 'messages',
			'model'        => $model,
			'prompt_chars' => strlen( $prompt ),
			'context'      => WPQ_Questionnaire_Report_Context::summary( $context ),
		];
		self::log_debug_event( 'questionnaire_report_request', $request_meta );

		$payload = wp_json_encode( [
			'model'      => $model,
			'max_tokens' => $max_tokens,
			'system'     => self::system_prompt(),
			'messages'   => [
				[ 'role' => 'user', 'content' => $prompt ],
			],
		] );
		if ( ! is_string( $payload ) || '' === $payload ) {
			self::log_debug_event( 'questionnaire_report_payload_encode_failed', $request_meta );
			throw new RuntimeException( 'Claude request payload could not be encoded.' );
		}

		$started  = microtime( true );
		$response = wp_remote_post(
			self::API_URL,
			[
				'timeout' => $timeout,
				'headers' => [
					'content-type'      => 'application/json',
					'x-api-key'         => $api_key,
					'anthropic-version' => self::API_VERSION,
				],
				'body'    => $payload,
			]
		);
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		if ( is_wp_error( $response ) ) {
			self::log_debug_event( 'questionnaire_report_wp_error', $request_meta + [
				'elapsed_ms' => $elapsed_ms,
				'error'      => $response->get_error_message(),
			] );
			throw new RuntimeException( 'Claude request failed.' );
		}

		$code      = (int) wp_remote_retrieve_response_code( $response );
		$body_text = wp_remote_retrieve_body( $response );
		$request_id = self::response_header( $response, 'request-id' );
		$usage      = self::response_usage_summary( $body_text );

		self::log_debug_event( 'questionnaire_report_response', $request_meta + [
			'status_code'  => $code,
			'request_id'   => $request_id,
			'elapsed_ms'   => $elapsed_ms,
			'body_chars'   => strlen( $body_text ),
			'body_excerpt' => self::excerpt( $body_text, 1800 ),
			'usage'        => $usage,
		] );

		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( 'Claude returned an error response.' );
		}

		$body = json_decode( $body_text, true );
		if ( ! is_array( $body ) ) {
			self::log_debug_event( 'questionnaire_report_invalid_json', $request_meta + [ 'status_code' => $code ] );
			throw new RuntimeException( 'Claude response was not JSON.' );
		}

		$text = '';
		foreach ( $body['content'] ?? [] as $part ) {
			if ( is_array( $part ) && ( $part['type'] ?? '' ) === 'text' ) {
				$text .= (string) ( $part['text'] ?? '' );
			}
		}

		if ( ( $body['stop_reason'] ?? '' ) === 'max_tokens' ) {
			// The direct signal that generation was cut off mid-response, not
			// left to be inferred from "JSON failed to parse" after the fact -
			// the response then always fails JSON parsing anyway, since the
			// output stops wherever the token ceiling landed.
			self::log_debug_event( 'questionnaire_report_truncated', $request_meta + [
				'status_code' => $code,
				'max_tokens'  => $max_tokens,
				'note'        => 'Response hit the output-token ceiling before the report finished; raise the Max output tokens setting in Settings -> AI.',
			] );
		}

		try {
			$data = self::parse_and_validate( $text );
		} catch ( Throwable $e ) {
			self::log_debug_event( 'questionnaire_report_parse_failed', $request_meta + [
				'status_code'  => $code,
				'text_chars'   => strlen( $text ),
				'text_excerpt' => self::excerpt( $text, 1800 ),
				'error'        => $e->getMessage(),
			] );
			throw $e;
		}

		self::log_debug_event( 'questionnaire_report_parse_success', $request_meta + [
			'status_code' => $code,
			'text_chars'  => strlen( $text ),
		] );

		return [
			'data' => $data,
			'meta' => [
				'request_id'    => $request_id,
				'model'         => $model,
				'input_tokens'  => $usage['input_tokens'] ?? null,
				'output_tokens' => $usage['output_tokens'] ?? null,
				'elapsed_ms'    => $elapsed_ms,
				'status_code'   => $code,
			],
		];
	}

	private static function system_prompt(): string {
		return 'You are a senior cyber risk assessor producing a customer-facing questionnaire report. '
			. 'Synthesise findings across domains, explain overall organisational posture, identify strengths and '
			. 'weaknesses, distinguish symptoms from root causes where the evidence supports it, explain material '
			. 'business implications, prioritise by risk and urgency, and propose practical next steps. Use UK '
			. 'business terminology and avoid excessive technical jargon. Do not invent facts not supported by the '
			. 'assessment evidence provided; where evidence is insufficient, say so explicitly in "limitations". '
			. 'Every finding and strength must reference the evidence (question_ref values) it is based on. '
			. 'Return only valid JSON matching the requested schema - no markdown, no commentary.';
	}

	private static function build_prompt( array $context ): string {
		$payload = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$schema  = wp_json_encode( [
			'report_title'            => 'string',
			'executive_summary'       => 'string',
			'overall_assessment'      => 'string',
			'strengths'               => [ [ 'title' => 'string', 'detail' => 'string', 'evidence_refs' => [ 'A1' ] ] ],
			'priority_findings'       => [ [
				'priority'         => 'Critical|High|Medium|Low',
				'domain'           => 'string',
				'title'            => 'string',
				'finding'          => 'string',
				'business_impact'  => 'string',
				'recommendation'   => 'string',
				'evidence_refs'    => [ 'A2' ],
			], ],
			'domain_assessments'      => [ [
				'domain'          => 'string',
				'score'           => 0,
				'maximum_score'   => 0,
				'summary'         => 'string',
				'strengths'       => [ 'string' ],
				'concerns'        => [ 'string' ],
				'recommendations' => [ 'string' ],
			], ],
			'recommended_next_steps' => [ [
				'sequence'   => 1,
				'timeframe'  => 'Immediate|30 days|60 days|90 days|Strategic',
				'action'     => 'string',
				'reason'     => 'string',
				'owner_type' => 'string',
			], ],
			'conclusion'  => 'string',
			'limitations' => [ 'string' ],
		] );

		return "Produce a Questionnaire Report analysis for this completed assessment.\n"
			. "Return strict JSON only, matching exactly this shape (arrays may be empty but must be present):\n{$schema}\n"
			. "Do not include markdown or text outside the JSON object.\n"
			. "Assessment context JSON:\n{$payload}";
	}

	/**
	 * @return array<string, mixed>
	 */
	private static function parse_and_validate( string $text ): array {
		$text = trim( $text );
		if ( '' === $text ) {
			throw new RuntimeException( 'Claude response was empty.' );
		}

		$decoded = json_decode( $text, true );
		if ( ! is_array( $decoded ) ) {
			if ( preg_match( '/\{.*\}/s', $text, $matches ) ) {
				$decoded = json_decode( $matches[0], true );
			}
		}

		if ( ! is_array( $decoded ) ) {
			throw new RuntimeException( 'Claude response was not valid JSON.' );
		}

		foreach ( [ 'report_title', 'executive_summary', 'overall_assessment', 'conclusion' ] as $field ) {
			if ( empty( $decoded[ $field ] ) || ! is_string( $decoded[ $field ] ) ) {
				throw new RuntimeException( 'Claude response is missing a required field.' );
			}
		}

		if ( ! isset( $decoded['priority_findings'] ) || ! is_array( $decoded['priority_findings'] ) ) {
			throw new RuntimeException( 'Claude response is missing "priority_findings".' );
		}
		if ( ! isset( $decoded['domain_assessments'] ) || ! is_array( $decoded['domain_assessments'] ) ) {
			throw new RuntimeException( 'Claude response is missing "domain_assessments".' );
		}

		return [
			'report_title'            => sanitize_text_field( (string) $decoded['report_title'] ),
			'executive_summary'       => sanitize_textarea_field( (string) $decoded['executive_summary'] ),
			'overall_assessment'      => sanitize_textarea_field( (string) $decoded['overall_assessment'] ),
			'strengths'               => self::sanitise_strengths( $decoded['strengths'] ?? [] ),
			'priority_findings'       => self::sanitise_findings( $decoded['priority_findings'] ),
			'domain_assessments'      => self::sanitise_domain_assessments( $decoded['domain_assessments'] ),
			'recommended_next_steps'  => self::sanitise_next_steps( $decoded['recommended_next_steps'] ?? [] ),
			'conclusion'              => sanitize_textarea_field( (string) $decoded['conclusion'] ),
			'limitations'             => self::sanitise_string_list( $decoded['limitations'] ?? [] ),
		];
	}

	private static function sanitise_strengths( mixed $strengths ): array {
		if ( ! is_array( $strengths ) ) {
			return [];
		}
		$rows = [];
		foreach ( $strengths as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$rows[] = [
				'title'         => sanitize_text_field( (string) ( $item['title'] ?? '' ) ),
				'detail'        => sanitize_textarea_field( (string) ( $item['detail'] ?? '' ) ),
				'evidence_refs' => self::sanitise_string_list( $item['evidence_refs'] ?? [], 12 ),
			];
		}
		return $rows;
	}

	/**
	 * Findings are given a stable, locally assigned id (F1, F2, ...) rather than
	 * trusting one from the model: the id is what links a report finding to the
	 * remediation workbook task that addresses it, so it must be deterministic
	 * for a given analysis and must exist for every finding.
	 */
	private static function sanitise_findings( array $findings ): array {
		$rows = [];
		foreach ( $findings as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$priority = ucfirst( strtolower( trim( (string) ( $item['priority'] ?? '' ) ) ) );
			if ( ! in_array( $priority, self::VALID_PRIORITIES, true ) ) {
				$priority = 'Medium';
			}
			$rows[] = [
				'id'              => self::FINDING_ID_PREFIX . ( count( $rows ) + 1 ),
				'priority'        => $priority,
				'domain'          => sanitize_text_field( (string) ( $item['domain'] ?? '' ) ),
				'title'           => sanitize_text_field( (string) ( $item['title'] ?? '' ) ),
				'finding'         => sanitize_textarea_field( (string) ( $item['finding'] ?? '' ) ),
				'business_impact' => sanitize_textarea_field( (string) ( $item['business_impact'] ?? '' ) ),
				'recommendation'  => sanitize_textarea_field( (string) ( $item['recommendation'] ?? '' ) ),
				'evidence_refs'   => self::sanitise_string_list( $item['evidence_refs'] ?? [], 12 ),
			];
		}
		return $rows;
	}

	private static function sanitise_domain_assessments( array $domains ): array {
		$rows = [];
		foreach ( $domains as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$rows[] = [
				'domain'          => sanitize_text_field( (string) ( $item['domain'] ?? '' ) ),
				'score'           => isset( $item['score'] ) && is_numeric( $item['score'] ) ? (int) $item['score'] : null,
				'maximum_score'   => isset( $item['maximum_score'] ) && is_numeric( $item['maximum_score'] ) ? (int) $item['maximum_score'] : null,
				'summary'         => sanitize_textarea_field( (string) ( $item['summary'] ?? '' ) ),
				'strengths'       => self::sanitise_string_list( $item['strengths'] ?? [] ),
				'concerns'        => self::sanitise_string_list( $item['concerns'] ?? [] ),
				'recommendations' => self::sanitise_string_list( $item['recommendations'] ?? [] ),
			];
		}
		return $rows;
	}

	private static function sanitise_next_steps( mixed $steps ): array {
		if ( ! is_array( $steps ) ) {
			return [];
		}
		$rows = [];
		$next_sequence = 1;
		foreach ( $steps as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$timeframe = trim( (string) ( $item['timeframe'] ?? '' ) );
			if ( ! in_array( $timeframe, self::VALID_TIMEFRAMES, true ) ) {
				$timeframe = 'Strategic';
			}
			$rows[] = [
				'sequence'   => isset( $item['sequence'] ) && is_numeric( $item['sequence'] ) ? max( 1, (int) $item['sequence'] ) : $next_sequence,
				'timeframe'  => $timeframe,
				'action'     => sanitize_text_field( (string) ( $item['action'] ?? '' ) ),
				'reason'     => sanitize_textarea_field( (string) ( $item['reason'] ?? '' ) ),
				'owner_type' => sanitize_text_field( (string) ( $item['owner_type'] ?? 'Customer' ) ),
			];
			$next_sequence++;
		}
		return $rows;
	}

	private static function sanitise_string_list( mixed $list, int $item_limit = 200 ): array {
		if ( ! is_array( $list ) ) {
			return [];
		}
		$rows = [];
		foreach ( $list as $item ) {
			if ( ! is_scalar( $item ) ) {
				continue;
			}
			$value = sanitize_text_field( (string) $item );
			if ( '' !== $value ) {
				$rows[] = mb_strlen( $value ) > $item_limit ? mb_substr( $value, 0, $item_limit ) : $value;
			}
		}
		return $rows;
	}

	public static function debug_logging_enabled(): bool {
		return get_option( self::DEBUG_ENABLED_OPTION, 'no' ) === 'yes';
	}

	public static function get_debug_log(): array {
		$rows = get_option( self::DEBUG_LOG_OPTION, [] );
		return is_array( $rows ) ? array_values( array_filter( $rows, 'is_array' ) ) : [];
	}

	/** Public: also used by the REST layer to log why a customer-initiated
	 * request was blocked before generation ever started (e.g. is_configured()
	 * failing), so that failure shows up on the same debug log as everything
	 * else instead of vanishing silently. */
	public static function log_debug_event( string $event, array $data = [] ): void {
		if ( ! self::debug_logging_enabled() ) {
			return;
		}

		$rows = self::get_debug_log();
		array_unshift( $rows, [
			'time'  => current_time( 'mysql', true ),
			'event' => sanitize_key( $event ),
			'data'  => self::sanitise_debug_data( $data ),
		] );

		$rows = array_slice( $rows, 0, self::DEBUG_LOG_LIMIT );
		update_option( self::DEBUG_LOG_OPTION, $rows, false );
	}

	private static function sanitise_debug_data( mixed $data ): mixed {
		if ( is_array( $data ) ) {
			$out = [];
			foreach ( $data as $key => $value ) {
				$clean_key = is_string( $key ) ? sanitize_key( $key ) : (int) $key;
				if ( in_array( (string) $clean_key, [ 'api_key', 'x-api-key', 'authorization', 'password', 'secret' ], true ) ) {
					$out[ $clean_key ] = '[redacted]';
					continue;
				}
				$out[ $clean_key ] = self::sanitise_debug_data( $value );
			}
			return $out;
		}

		if ( is_bool( $data ) || is_int( $data ) || is_float( $data ) || null === $data ) {
			return $data;
		}

		return self::excerpt( sanitize_textarea_field( (string) $data ), 2000 );
	}

	private static function response_usage_summary( string $body_text ): array {
		$body = json_decode( $body_text, true );
		if ( ! is_array( $body ) || ! isset( $body['usage'] ) || ! is_array( $body['usage'] ) ) {
			return [];
		}

		return [
			'input_tokens'  => isset( $body['usage']['input_tokens'] ) ? (int) $body['usage']['input_tokens'] : null,
			'output_tokens' => isset( $body['usage']['output_tokens'] ) ? (int) $body['usage']['output_tokens'] : null,
		];
	}

	private static function response_header( mixed $response, string $name ): string {
		if ( function_exists( 'wp_remote_retrieve_header' ) ) {
			$value = wp_remote_retrieve_header( $response, $name );
			return is_scalar( $value ) ? (string) $value : '';
		}
		return '';
	}

	private static function excerpt( string $text, int $limit ): string {
		$text = trim( preg_replace( '/\s+/', ' ', $text ) ?? $text );
		if ( strlen( $text ) <= $limit ) {
			return $text;
		}
		return substr( $text, 0, max( 0, $limit - 3 ) ) . '...';
	}
}
