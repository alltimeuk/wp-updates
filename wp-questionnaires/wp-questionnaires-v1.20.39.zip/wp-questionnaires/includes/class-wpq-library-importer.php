<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Imports questionnaires from the committed library data file into the database.
 *
 * The library PHP file is generated from the source spreadsheet and committed to
 * version control. This class applies that data to the DB idempotently: it skips
 * questionnaires that already exist with `created_by_seed = 1` and preserves any
 * record with `is_customised = 1`.
 */
class WPQ_Questionnaire_Library_Importer {

	const LIBRARY_VERSION = '1.0.0';
	const LIBRARY_FILE    = 'questionnaire-library-1.0.0.php';

	/** Default scoring per question_ref for the 15-question library template. */
	const SCORING_DEFAULTS = [
		'Q04' => [ 'scoring_mode' => 'boolean',      'score_yes' => 2, 'score_no' => 0 ],
		'Q05' => [ 'scoring_mode' => 'sum_selected',  'max_score' => 2 ],
		'Q06' => [ 'scoring_mode' => 'sum_selected',  'max_score' => 2 ],
		'Q07' => [ 'scoring_mode' => 'single_option', 'max_score' => 2 ],
		'Q08' => [ 'scoring_mode' => 'single_option', 'max_score' => 2 ],
		'Q09' => [ 'scoring_mode' => 'boolean',       'score_yes' => 2, 'score_no' => 0 ],
		'Q13' => [ 'scoring_mode' => 'single_option', 'max_score' => 2 ],
	];

	/** Option score overrides per question_ref. '__default' applies to unlisted option keys. */
	const OPTION_SCORE_DEFAULTS = [
		'Q05' => [ '__default' => 1, 'option_9'  => 0 ],
		'Q06' => [ '__default' => 1, 'option_10' => 0 ],
		'Q07' => [ 'option_1' => 0, 'option_2' => 0, 'option_3' => 2, 'option_4' => 2, 'option_5' => 1, 'option_6' => 2 ],
		'Q08' => [ 'option_1' => 0, 'option_2' => 0, 'option_3' => 1, 'option_4' => 2, 'option_5' => 2 ],
		'Q13' => [ 'option_1' => 0, 'option_2' => 1, 'option_3' => 2, 'option_4' => 2, 'option_5' => 0 ],
	];

	/** Supported answer_type_raw → question_type mapping (lower-cased keys). */
	const TYPE_MAP = [
		'boolean'        => 'boolean',
		'yes/no'         => 'boolean',
		'yes / no'       => 'boolean',
		'select'         => 'select',
		'combobox'       => 'select',
		'radio'          => 'radio',
		'single choice'  => 'radio',
		'multiple choice'=> 'checkbox',
		'checkbox'       => 'checkbox',
		'memo'           => 'memo',
		'notes'          => 'memo',
		'short_text'     => 'short_text',
		'number'         => 'number',
	];

	/** @var array<string,int> */
	private array $diagnostics = [
		'seeded'           => 0,
		'skipped'          => 0,
		'errors'           => 0,
		'questions_seeded' => 0,
		'options_seeded'   => 0,
	];

	/** @var list<string> */
	private array $skipped_refs = [];

	/** @var array<string,int> */
	private array $unsupported_types = [];

	// ------------------------------------------------------------------ //
	// Public interface
	// ------------------------------------------------------------------ //

	/**
	 * Run the full library import and return diagnostics.
	 *
	 * @return array<string,mixed>
	 */
	public function import(): array {
		$data_file = WPQ_PLUGIN_DIR . 'includes/data/' . self::LIBRARY_FILE;
		if ( ! file_exists( $data_file ) ) {
			return $this->error_result( 'Library data file not found: ' . self::LIBRARY_FILE );
		}

		/** @var mixed $data */
		$data = require $data_file;
		if ( ! is_array( $data ) || empty( $data['questionnaires'] ) || ! is_array( $data['questionnaires'] ) ) {
			return $this->error_result( 'Library data file is empty or malformed.' );
		}

		foreach ( $data['questionnaires'] as $q_data ) {
			if ( is_array( $q_data ) ) {
				$this->import_questionnaire( $q_data );
			}
		}

		$this->log_run();
		return $this->get_diagnostics();
	}

	/**
	 * @return array<string,mixed>
	 */
	public function get_diagnostics(): array {
		return array_merge( $this->diagnostics, [
			'skipped_refs'      => $this->skipped_refs,
			'unsupported_types' => $this->unsupported_types,
			'library_version'   => self::LIBRARY_VERSION,
		] );
	}

	// ------------------------------------------------------------------ //
	// Static helpers for admin diagnostics
	// ------------------------------------------------------------------ //

	/**
	 * Last wpq_library_log row, or null if none.
	 */
	public static function get_last_log(): ?object {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a constant prefix.
		return $wpdb->get_row(
			"SELECT * FROM {$wpdb->prefix}wpq_library_log ORDER BY id DESC LIMIT 1"
		) ?: null;
	}

	/**
	 * Aggregate diagnostics queried from the live database.
	 *
	 * @return array<string,mixed>
	 */
	public static function get_db_diagnostics(): array {
		global $wpdb;
		$qt = $wpdb->prefix . 'wpq_questionnaires';
		$q2 = $wpdb->prefix . 'wpq_questions';
		$o  = $wpdb->prefix . 'wpq_question_options';

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $qt/$q2/$o are table-name constants, not user input.
		$seeded_q    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$qt} WHERE created_by_seed = 1 AND library_version IS NOT NULL" );
		$seeded_qns  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$q2} WHERE created_by_seed = 1 AND library_version IS NOT NULL" );
		$seeded_opts = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$o}  WHERE created_by_seed = 1" );
		$customised  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$qt} WHERE is_customised = 1" );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$log = self::get_last_log();

		return [
			'library_version'       => self::LIBRARY_VERSION,
			'seeded_questionnaires' => $seeded_q,
			'seeded_questions'      => $seeded_qns,
			'seeded_options'        => $seeded_opts,
			'customised_count'      => $customised,
			'last_run_at'           => $log ? $log->run_at           : null,
			'last_run_seeded'       => $log ? (int) $log->q_seeded   : null,
			'last_run_skipped'      => $log ? (int) $log->q_skipped  : null,
			'last_run_errors'       => $log ? (int) $log->q_errors   : null,
			'last_run_unsupported'  => $log ? $log->unsupported_types : null,
		];
	}

	// ------------------------------------------------------------------ //
	// Private import logic
	// ------------------------------------------------------------------ //

	/**
	 * @param array<string,mixed> $q_data
	 */
	private function import_questionnaire( array $q_data ): void {
		$ref = (string) ( $q_data['ref'] ?? '' );
		if ( $ref === '' ) return;

		$existing = WPQ_Database::get_questionnaire_any_status_by_ref( $ref );
		if ( $existing !== null ) {
			$seeded_by_lib = isset( $existing->created_by_seed ) && (bool) $existing->created_by_seed;
			$customised    = isset( $existing->is_customised )   && (bool) $existing->is_customised;
			// Preserve any questionnaire not owned by the library, or that was customised after seeding.
			if ( ! $seeded_by_lib || $customised ) {
				$this->skipped_refs[] = $ref;
			}
			$this->diagnostics['skipped']++;
			return;
		}

		$q_id = WPQ_Database::insert_questionnaire( [
			'ref'            => $ref,
			'category'       => 'cyber_security',
			'name'           => (string) ( $q_data['title']        ?? $ref ),
			'description'    => (string) ( $q_data['intended_use'] ?? '' ),
			'status'         => 'live',
			'source_type'    => 'spreadsheet',
			'source_file'    => 'cyber_security_questionnaire_library.xlsx',
			'source_sheet'   => (string) ( $q_data['sheet']        ?? '' ),
			'source_version' => self::LIBRARY_VERSION,
			'library_version'=> self::LIBRARY_VERSION,
			'library_id'     => (string) ( $q_data['library_id']   ?? '' ),
			'library_family' => (string) ( $q_data['family']       ?? '' ),
			'created_by_seed'=> 1,
			'is_customised'  => 0,
		] );

		if ( ! $q_id ) {
			$this->diagnostics['errors']++;
			return;
		}

		$domain_id = WPQ_Database::insert_domain( [
			'questionnaire_id' => $q_id,
			'sort_order'       => 0,
			'slug'             => 'general',
			'name'             => 'Questions',
			'icon'             => '',
		] );

		if ( ! $domain_id ) {
			$this->diagnostics['errors']++;
			return;
		}

		$questions = is_array( $q_data['questions'] ?? null ) ? $q_data['questions'] : [];
		foreach ( $questions as $sort_order => $q ) {
			if ( is_array( $q ) ) {
				$this->import_question( $domain_id, (int) $sort_order, $q );
			}
		}

		$this->diagnostics['seeded']++;
	}

	/**
	 * @param array<string,mixed> $q
	 */
	private function import_question( int $domain_id, int $sort_order, array $q ): void {
		$type_raw = strtolower( trim( (string) ( $q['type_raw'] ?? '' ) ) );
		$qtype    = (string) ( $q['type'] ?? '' );

		if ( $qtype === '' ) {
			$mapped = self::TYPE_MAP[ $type_raw ] ?? null;
			if ( $mapped === null ) {
				$this->unsupported_types[ $type_raw ] = ( $this->unsupported_types[ $type_raw ] ?? 0 ) + 1;
				$qtype = 'memo'; // safe fallback
			} else {
				$qtype = $mapped;
			}
		}

		$ref     = (string) ( $q['index'] ?? '' );
		$scoring = self::SCORING_DEFAULTS[ $ref ] ?? [];
		$s_mode  = (string) ( $scoring['scoring_mode'] ?? 'non_scoring' );
		$s_yes   = (int) ( $scoring['score_yes'] ?? 0 );
		$s_no    = (int) ( $scoring['score_no'] ?? 0 );
		$s_max   = isset( $scoring['max_score'] ) ? (int) $scoring['max_score'] : null;

		$q_id = WPQ_Database::insert_question( [
			'domain_id'       => $domain_id,
			'sort_order'      => $sort_order,
			'question_ref'    => $ref,
			'question_text'   => (string) ( $q['text']    ?? '' ),
			'guidance_yes'    => '',
			'guidance_no'     => '',
			'score_yes'       => $s_yes,
			'score_partial'   => 0,
			'score_no'        => $s_no,
			'question_type'   => $qtype,
			'answer_type_raw' => $type_raw,
			'is_required'     => 1,
			'scoring_mode'    => $s_mode,
			'max_score'       => $s_max,
			'help_text'       => (string) ( $q['guidance'] ?? '' ),
			'created_by_seed' => 1,
			'library_version' => self::LIBRARY_VERSION,
		] );

		if ( ! $q_id ) return;

		$this->diagnostics['questions_seeded']++;

		$options         = is_array( $q['options'] ?? null ) ? $q['options'] : [];
		$opt_score_map   = self::OPTION_SCORE_DEFAULTS[ $ref ] ?? [];
		$default_opt_score = (int) ( $opt_score_map['__default'] ?? 0 );

		foreach ( $options as $opt_sort => $opt ) {
			if ( ! is_array( $opt ) ) continue;
			$key   = (string) ( $opt['key']   ?? "option_{$opt_sort}" );
			$label = (string) ( $opt['label'] ?? '' );
			if ( $label === '' ) continue;

			$opt_score = isset( $opt_score_map[ $key ] ) ? (int) $opt_score_map[ $key ] : $default_opt_score;

			WPQ_Database::insert_question_option( [
				'question_id'    => $q_id,
				'option_key'     => $key,
				'option_label'   => $label,
				'score'          => $opt_score,
				'sort_order'     => (int) $opt_sort,
				'is_default'     => 0,
				'is_active'      => 1,
				'requires_notes' => 0,
				'exclusive'      => 0,
				'created_by_seed'=> 1,
			] );
			$this->diagnostics['options_seeded']++;
		}
	}

	/**
	 * Record this import run to wpq_library_log.
	 */
	private function log_run(): void {
		global $wpdb;
		$wpdb->insert(
			"{$wpdb->prefix}wpq_library_log",
			[
				'library_version'  => self::LIBRARY_VERSION,
				'run_at'           => current_time( 'mysql', true ),
				'q_seeded'         => $this->diagnostics['seeded'],
				'q_skipped'        => $this->diagnostics['skipped'],
				'q_errors'         => $this->diagnostics['errors'],
				'questions_seeded' => $this->diagnostics['questions_seeded'],
				'options_seeded'   => $this->diagnostics['options_seeded'],
				'unsupported_types'=> wp_json_encode( $this->unsupported_types ) ?: '{}',
				'skipped_refs'     => wp_json_encode( $this->skipped_refs )      ?: '[]',
			]
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private function error_result( string $message ): array {
		return array_merge( $this->diagnostics, [
			'error'             => $message,
			'skipped_refs'      => [],
			'unsupported_types' => [],
			'library_version'   => self::LIBRARY_VERSION,
		] );
	}
}
