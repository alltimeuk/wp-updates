<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

interface WPQ_Docx_Pdf_Converter_Interface {

	/**
	 * Whether this converter can currently run (executable present, invocable).
	 */
	public function is_available(): bool;

	/**
	 * Safe, customer-facing diagnostic data. Must never include raw shell output.
	 *
	 * @return array<string, mixed>
	 */
	public function diagnostics(): array;

	/**
	 * Convert a DOCX file to PDF, writing the result into $output_directory.
	 *
	 * @return string Absolute path to the generated PDF.
	 * @throws RuntimeException On any failure (converter unavailable, non-zero exit, missing/invalid output, timeout).
	 */
	public function convert( string $docx_path, string $output_directory ): string;
}
