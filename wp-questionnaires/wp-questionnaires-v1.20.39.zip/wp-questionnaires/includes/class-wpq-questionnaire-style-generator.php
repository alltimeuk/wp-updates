<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Publishes each questionnaire's admin-configured grade colours as a small,
 * publicly-readable, content-addressed CSS file instead of setting them via
 * inline `style="..."` attributes/elements. Under a strict CSP that blocks
 * `style-src-attr` outright (with no nonce or hash support - the browser
 * spec does not allow hashing style attributes unless the page opts into
 * 'unsafe-hashes'), an external stylesheet loaded via `<link>` is the only
 * way to apply a colour an administrator picked freely in the Grades editor,
 * since `<link>`-loaded CSS is never "inline" and so is outside CSP's reach
 * regardless of nonce/hash support anywhere in the chain.
 *
 * The stylesheet only ever defines two CSS custom properties per grade
 * (--wpq-grade-color / --wpq-grade-bg) scoped to a `.wpq-grade-{grade_id}`
 * class; every actual visual rule that consumes them (ring stroke, pill
 * background, etc.) is static and lives in assessment.css.
 */
class WPQ_Questionnaire_Style_Generator {

	private const SUBDIR = 'generated-styles';

	/**
	 * Ensures the questionnaire's grade stylesheet exists on disk and returns
	 * its public URL, or null if it has no grade thresholds or storage is
	 * unavailable (the page still renders - grade elements simply fall back
	 * to the static default colours defined in assessment.css).
	 */
	public static function ensure_stylesheet_url( int $questionnaire_id ): ?string {
		if ( $questionnaire_id <= 0 ) {
			return null;
		}

		$thresholds = WPQ_Database::get_grade_thresholds( $questionnaire_id );
		if ( empty( $thresholds ) ) {
			return null;
		}

		$css = self::build_css( $thresholds );
		if ( '' === $css ) {
			return null;
		}

		$directory = self::get_storage_dir();
		if ( '' === $directory ) {
			return null;
		}

		$file_name = sprintf( 'wpq-grades-%d-%s.css', $questionnaire_id, substr( hash( 'sha256', $css ), 0, 16 ) );
		$path      = $directory . DIRECTORY_SEPARATOR . $file_name;

		if ( ! is_file( $path ) ) {
			self::cleanup_stale_files( $directory, $questionnaire_id, $file_name );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Plugin-owned generated public asset in uploads.
			if ( file_put_contents( $path, $css ) === false ) {
				return null;
			}
		}

		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return null;
		}
		$upload = wp_upload_dir();
		if ( ! is_array( $upload ) || empty( $upload['baseurl'] ) ) {
			return null;
		}

		return rtrim( (string) $upload['baseurl'], '/' ) . '/wp-questionnaires/' . self::SUBDIR . '/' . $file_name;
	}

	/**
	 * @param array<int, object> $thresholds Rows from wp_grade_thresholds.
	 */
	private static function build_css( array $thresholds ): string {
		$rules = [];
		foreach ( $thresholds as $t ) {
			$grade_id = sanitize_html_class( (string) ( $t->grade_id ?? '' ) );
			if ( '' === $grade_id ) {
				continue;
			}
			$color = self::safe_hex( (string) ( $t->color_hex ?? '' ), '#1a5068' );
			$bg    = self::safe_hex( (string) ( $t->bg_hex ?? '' ), '#e8f4f8' );

			$rules[] = "#wpq-app .wpq-grade-{$grade_id}{--wpq-grade-color:{$color};--wpq-grade-bg:{$bg};}";
		}

		return implode( "\n", $rules );
	}

	private static function safe_hex( string $value, string $fallback ): string {
		$value = trim( $value );
		return ( preg_match( '/^#[0-9a-fA-F]{6}$/', $value ) || preg_match( '/^#[0-9a-fA-F]{3}$/', $value ) ) ? $value : $fallback;
	}

	private static function get_storage_dir(): string {
		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return '';
		}

		$upload = wp_upload_dir();
		if ( ! is_array( $upload ) || ! empty( $upload['error'] ) || empty( $upload['basedir'] ) ) {
			return '';
		}

		$directory = rtrim( (string) $upload['basedir'], DIRECTORY_SEPARATOR )
			. DIRECTORY_SEPARATOR . 'wp-questionnaires'
			. DIRECTORY_SEPARATOR . self::SUBDIR;

		if ( ! is_dir( $directory ) && function_exists( 'wp_mkdir_p' ) && ! wp_mkdir_p( $directory ) ) {
			return '';
		}

		return is_dir( $directory ) ? $directory : '';
	}

	/**
	 * Removes this questionnaire's previous generated stylesheet(s) once its
	 * grade colours change and a new content-addressed file is about to be
	 * written, so an admin editing grade colours doesn't silently accumulate
	 * an ever-growing set of stale CSS files in uploads.
	 */
	private static function cleanup_stale_files( string $directory, int $questionnaire_id, string $keep_file_name ): void {
		$pattern = $directory . DIRECTORY_SEPARATOR . 'wpq-grades-' . $questionnaire_id . '-*.css';
		foreach ( glob( $pattern ) ?: [] as $existing ) {
			if ( basename( $existing ) !== $keep_file_name ) {
				wp_delete_file( $existing );
			}
		}
	}
}
