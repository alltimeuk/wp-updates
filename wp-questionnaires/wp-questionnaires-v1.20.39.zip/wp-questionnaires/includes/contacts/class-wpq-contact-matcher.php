<?php
/**
 * Pure matching decisions for contact resolution. Given candidate data the
 * repository has already fetched, decide what to do - link, create, or send
 * to review. No database access, so every rule is unit-testable.
 *
 * Resolution precedence (spec §6.1):
 *   1. Authenticated WordPress user already linked to one contact.
 *   2. Trusted internal UUID (server-side integrations only).
 *   3. Verified identity linked to one active contact.
 *   4. Single unambiguous unverified email match.
 *   5. No safe match → new provisional contact.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Contact_Matcher {

	public const DECISION_LINK   = 'link';
	public const DECISION_CREATE = 'create';
	public const DECISION_REVIEW = 'review'; // Create provisional AND queue a review candidate.

	/**
	 * Decide how to treat an unverified email match set.
	 *
	 * @param string             $email          The submitted email (original form).
	 * @param string             $submitted_name The submitted display name.
	 * @param array<int, object> $candidates     Active/provisional contacts already
	 *        holding this normalised email, each with ->id, ->display_name,
	 *        ->status, ->wp_user_id and ->identity_verification.
	 * @return array{decision: string, contact_id: int, reason: string}
	 */
	public static function decide_email_match( string $email, string $submitted_name, array $candidates ): array {
		if ( empty( $candidates ) ) {
			return [ 'decision' => self::DECISION_CREATE, 'contact_id' => 0, 'reason' => 'no_match' ];
		}

		// A shared role mailbox is never proof of identity: each interaction gets
		// its own provisional contact and a review row records the ambiguity.
		if ( WPQ_Contact_Normaliser::is_role_mailbox( $email ) ) {
			return [ 'decision' => self::DECISION_REVIEW, 'contact_id' => 0, 'reason' => 'role_mailbox' ];
		}

		if ( count( $candidates ) > 1 ) {
			return [ 'decision' => self::DECISION_REVIEW, 'contact_id' => 0, 'reason' => 'multiple_candidates' ];
		}

		$candidate = $candidates[0];

		// A verified identity outranks anything a public form claims: link, and
		// let the update rules decide which attributes may change.
		if ( ( $candidate->identity_verification ?? '' ) === 'verified' ) {
			return [ 'decision' => self::DECISION_LINK, 'contact_id' => (int) $candidate->id, 'reason' => 'verified_identity' ];
		}

		if ( WPQ_Contact_Normaliser::names_conflict_materially( $submitted_name, (string) ( $candidate->display_name ?? '' ) ) ) {
			return [ 'decision' => self::DECISION_REVIEW, 'contact_id' => 0, 'reason' => 'name_conflict' ];
		}

		return [ 'decision' => self::DECISION_LINK, 'contact_id' => (int) $candidate->id, 'reason' => 'unverified_email_match' ];
	}

	/**
	 * Whether a canonical scalar field may be updated from new input.
	 * Blank input never erases; verified contacts only accept non-conflicting
	 * additions (a fuller form of the same name is fine, a different name is not).
	 */
	public static function may_update_field( string $current, string $incoming, bool $contact_verified ): bool {
		$incoming = trim( $incoming );
		if ( '' === $incoming || trim( $current ) === $incoming ) {
			return false;
		}
		if ( '' === trim( $current ) ) {
			return true;
		}
		if ( $contact_verified ) {
			return ! WPQ_Contact_Normaliser::names_conflict_materially( $current, $incoming )
				&& mb_strlen( $incoming ) > mb_strlen( trim( $current ) );
		}

		return true;
	}

	/**
	 * Project the current state for one purpose from its consent events.
	 * The most restrictive event wins regardless of order; only an
	 * administrative correction newer than the restriction can relax it.
	 *
	 * @param array<int, object> $events Each with ->event and ->occurred_at.
	 */
	public static function project_preference_state( array $events ): string {
		if ( empty( $events ) ) {
			return 'unknown';
		}

		usort( $events, static fn( object $a, object $b ): int => strcmp( (string) $a->occurred_at, (string) $b->occurred_at ) );

		$state = 'unknown';
		foreach ( $events as $event ) {
			$type = (string) $event->event;
			if ( 'administratively_corrected' === $type ) {
				// A correction resets projection to the explicit state it carries
				// in ->reason ('granted'/'declined'), defaulting to declined.
				$state = in_array( (string) ( $event->reason ?? '' ), [ 'granted', 'declined' ], true )
					? (string) $event->reason
					: 'declined';
				continue;
			}
			if ( in_array( $type, [ 'suppressed', 'objected', 'withdrawn' ], true ) ) {
				$state = $type;
				continue;
			}
			// granted/declined never override a standing restriction.
			if ( ! in_array( $state, [ 'suppressed', 'objected', 'withdrawn' ], true ) ) {
				$state = $type;
			}
		}

		return $state;
	}
}
