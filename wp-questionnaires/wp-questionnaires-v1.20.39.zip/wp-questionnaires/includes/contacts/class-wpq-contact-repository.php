<?php
/**
 * SQL access for the canonical contact domain. All canonical-table reads and
 * writes live here - REST controllers and admin screens go through
 * WPQ_Contact_Service, other plugins through the versioned service filter
 * (Phase 4), and nothing else touches these tables.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Contact_Repository {

	// ------------------------------------------------------------------ //
	// Contacts
	// ------------------------------------------------------------------ //

	/**
	 * @param array<string, mixed> $data
	 */
	public static function insert_contact( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_contacts", [
			'uuid'              => wp_generate_uuid4(),
			'wp_user_id'        => isset( $data['wp_user_id'] ) && (int) $data['wp_user_id'] > 0 ? (int) $data['wp_user_id'] : null,
			'given_name'        => mb_substr( sanitize_text_field( (string) ( $data['given_name'] ?? '' ) ), 0, 100 ),
			'family_name'       => mb_substr( sanitize_text_field( (string) ( $data['family_name'] ?? '' ) ), 0, 100 ),
			'display_name'      => mb_substr( sanitize_text_field( (string) ( $data['display_name'] ?? '' ) ), 0, 191 ),
			'organisation'      => mb_substr( sanitize_text_field( (string) ( $data['organisation'] ?? '' ) ), 0, 191 ),
			'job_title'         => isset( $data['job_title'] ) ? mb_substr( sanitize_text_field( (string) $data['job_title'] ), 0, 100 ) : null,
			'status'            => in_array( (string) ( $data['status'] ?? '' ), [ 'provisional', 'active' ], true ) ? (string) $data['status'] : 'provisional',
			'created_source'    => sanitize_key( (string) ( $data['created_source'] ?? '' ) ),
			'first_observed_at' => (string) ( $data['observed_at'] ?? $now ),
			'last_observed_at'  => (string) ( $data['observed_at'] ?? $now ),
			'created_at'        => $now,
			'updated_at'        => $now,
		] );

		return false === $inserted ? 0 : (int) $wpdb->insert_id;
	}

	public static function get_contact( int $contact_id ): ?object {
		global $wpdb;
		if ( $contact_id <= 0 ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_contacts WHERE id = %d",
			$contact_id
		) ) ?: null;
	}

	public static function get_contact_by_uuid( string $uuid ): ?object {
		global $wpdb;
		if ( ! WPQ_Contact_Normaliser::is_valid_uuid( $uuid ) ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_contacts WHERE uuid = %s",
			$uuid
		) ) ?: null;
	}

	public static function get_contact_by_wp_user( int $user_id ): ?object {
		global $wpdb;
		if ( $user_id <= 0 ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_contacts
			 WHERE wp_user_id = %d AND status NOT IN ('merged','deleted','anonymised')
			 ORDER BY id ASC LIMIT 1",
			$user_id
		) ) ?: null;
	}

	/** Follow a merged contact to its survivor (bounded against cycles). */
	public static function resolve_merged( object $contact ): object {
		$hops = 0;
		while ( 'merged' === (string) ( $contact->status ?? '' ) && (int) ( $contact->merged_into_contact_id ?? 0 ) > 0 && $hops < 5 ) {
			$next = self::get_contact( (int) $contact->merged_into_contact_id );
			if ( ! $next ) {
				break;
			}
			$contact = $next;
			++$hops;
		}
		return $contact;
	}

	/**
	 * @param array<string, mixed> $fields Whitelisted canonical scalar fields.
	 */
	public static function update_contact( int $contact_id, array $fields ): bool {
		global $wpdb;
		$allowed = [ 'given_name', 'family_name', 'display_name', 'organisation', 'job_title', 'status', 'wp_user_id', 'last_observed_at', 'verified_at', 'merged_into_contact_id' ];
		$clean   = [];
		foreach ( $fields as $key => $value ) {
			if ( in_array( (string) $key, $allowed, true ) ) {
				$clean[ (string) $key ] = is_string( $value ) ? sanitize_text_field( $value ) : $value;
			}
		}
		if ( empty( $clean ) ) {
			return false;
		}
		$clean['updated_at'] = current_time( 'mysql', true );

		return false !== $wpdb->update( "{$wpdb->prefix}wpq_contacts", $clean, [ 'id' => $contact_id ] );
	}

	// ------------------------------------------------------------------ //
	// Identities
	// ------------------------------------------------------------------ //

	/**
	 * Contacts holding an identity with this hash, with the strongest
	 * verification state each contact holds for it.
	 *
	 * @return array<int, object> ->id, ->display_name, ->status, ->wp_user_id, ->identity_verification, ->identity_id
	 */
	public static function find_contacts_by_identity( string $type, string $value_hash ): array {
		global $wpdb;

		return $wpdb->get_results( $wpdb->prepare(
			"SELECT c.id, c.display_name, c.status, c.wp_user_id, c.verified_at,
			        i.verification AS identity_verification, i.id AS identity_id
			 FROM {$wpdb->prefix}wpq_contact_identities i
			 INNER JOIN {$wpdb->prefix}wpq_contacts c ON c.id = i.contact_id
			 WHERE i.type = %s AND i.value_hash = %s
			   AND i.verification NOT IN ('revoked','superseded')
			   AND c.status IN ('provisional','active','restricted')
			 ORDER BY (i.verification = 'verified') DESC, c.id ASC",
			$type,
			$value_hash
		) ) ?: [];
	}

	/**
	 * @param array<string, mixed> $data
	 */
	public static function insert_identity( array $data ): int {
		global $wpdb;
		$now = current_time( 'mysql', true );

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_contact_identities", [
			'contact_id'        => (int) $data['contact_id'],
			'type'              => in_array( (string) ( $data['type'] ?? '' ), [ 'email', 'telephone' ], true ) ? (string) $data['type'] : 'email',
			'value_original'    => mb_substr( sanitize_text_field( (string) ( $data['value_original'] ?? '' ) ), 0, 255 ),
			'value_normalised'  => mb_substr( sanitize_text_field( (string) ( $data['value_normalised'] ?? '' ) ), 0, 255 ),
			'value_hash'        => substr( (string) ( $data['value_hash'] ?? '' ), 0, 64 ),
			'verification'      => 'unverified',
			'is_primary'        => ! empty( $data['is_primary'] ) ? 1 : 0,
			'source_type'       => sanitize_key( (string) ( $data['source_type'] ?? '' ) ),
			'source_id'         => isset( $data['source_id'] ) && (int) $data['source_id'] > 0 ? (int) $data['source_id'] : null,
			'first_observed_at' => (string) ( $data['observed_at'] ?? $now ),
			'last_observed_at'  => (string) ( $data['observed_at'] ?? $now ),
			'created_at'        => $now,
			'updated_at'        => $now,
		] );

		return false === $inserted ? 0 : (int) $wpdb->insert_id;
	}

	/** The contact's identity row for a hash, if it already holds one. */
	public static function get_contact_identity( int $contact_id, string $type, string $value_hash ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}wpq_contact_identities
			 WHERE contact_id = %d AND type = %s AND value_hash = %s LIMIT 1",
			$contact_id,
			$type,
			$value_hash
		) ) ?: null;
	}

	public static function touch_identity( int $identity_id, string $observed_at ): void {
		global $wpdb;
		$wpdb->update(
			"{$wpdb->prefix}wpq_contact_identities",
			[ 'last_observed_at' => $observed_at, 'updated_at' => current_time( 'mysql', true ) ],
			[ 'id' => $identity_id ]
		);
	}

	public static function contact_has_primary_identity( int $contact_id, string $type ): bool {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contact_identities
			 WHERE contact_id = %d AND type = %s AND is_primary = 1",
			$contact_id,
			$type
		) ) > 0;
	}

	// ------------------------------------------------------------------ //
	// Organisations
	// ------------------------------------------------------------------ //

	public static function record_organisation( int $contact_id, string $organisation_name, string $source ): void {
		global $wpdb;
		$organisation_name = mb_substr( sanitize_text_field( $organisation_name ), 0, 191 );
		if ( $contact_id <= 0 || '' === $organisation_name ) {
			return;
		}

		$exists = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contact_organisations
			 WHERE contact_id = %d AND organisation_name = %s",
			$contact_id,
			$organisation_name
		) );
		if ( $exists > 0 ) {
			return;
		}

		$has_primary = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contact_organisations
			 WHERE contact_id = %d AND is_primary = 1",
			$contact_id
		) );

		$wpdb->insert( "{$wpdb->prefix}wpq_contact_organisations", [
			'contact_id'        => $contact_id,
			'organisation_name' => $organisation_name,
			'relationship'      => 'employee',
			'is_primary'        => $has_primary > 0 ? 0 : 1,
			'source'            => sanitize_key( $source ),
			'valid_from'        => current_time( 'mysql', true ),
			'created_at'        => current_time( 'mysql', true ),
		] );
	}

	// ------------------------------------------------------------------ //
	// Interactions
	// ------------------------------------------------------------------ //

	/**
	 * Idempotent insert: the unique (product, source_type, source_id,
	 * interaction_type) key makes re-recording a no-op.
	 *
	 * @param array<string, mixed> $data
	 * @return int Interaction id (existing or new); 0 on failure.
	 */
	public static function record_interaction( array $data ): int {
		global $wpdb;

		$product = sanitize_key( (string) ( $data['product'] ?? 'wp-questionnaires' ) );
		$type    = sanitize_key( (string) ( $data['interaction_type'] ?? '' ) );
		$source  = sanitize_key( (string) ( $data['source_type'] ?? '' ) );
		$sid     = (int) ( $data['source_id'] ?? 0 );
		if ( '' === $type || '' === $source || $sid <= 0 || (int) ( $data['contact_id'] ?? 0 ) <= 0 ) {
			return 0;
		}

		$existing = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_contact_interactions
			 WHERE product = %s AND source_type = %s AND source_id = %d AND interaction_type = %s LIMIT 1",
			$product,
			$source,
			$sid,
			$type
		) );
		if ( $existing > 0 ) {
			return $existing;
		}

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_contact_interactions", [
			'contact_id'       => (int) $data['contact_id'],
			'product'          => $product,
			'interaction_type' => $type,
			'source_type'      => $source,
			'source_id'        => $sid,
			'source_ref'       => mb_substr( sanitize_text_field( (string) ( $data['source_ref'] ?? '' ) ), 0, 64 ),
			'questionnaire_id' => isset( $data['questionnaire_id'] ) && (int) $data['questionnaire_id'] > 0 ? (int) $data['questionnaire_id'] : null,
			'occurred_at'      => (string) ( $data['occurred_at'] ?? current_time( 'mysql', true ) ),
			'completion_state' => sanitize_key( (string) ( $data['completion_state'] ?? '' ) ),
			'organisation'     => mb_substr( sanitize_text_field( (string) ( $data['organisation'] ?? '' ) ), 0, 191 ),
			'attribution'      => isset( $data['attribution'] ) ? mb_substr( sanitize_text_field( (string) $data['attribution'] ), 0, 191 ) : null,
			'created_at'       => current_time( 'mysql', true ),
		] );

		// A racing duplicate violates the unique key; re-read instead of failing.
		if ( false === $inserted ) {
			return (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}wpq_contact_interactions
				 WHERE product = %s AND source_type = %s AND source_id = %d AND interaction_type = %s LIMIT 1",
				$product,
				$source,
				$sid,
				$type
			) );
		}

		return (int) $wpdb->insert_id;
	}

	// ------------------------------------------------------------------ //
	// Consent
	// ------------------------------------------------------------------ //

	/**
	 * @param array<string, mixed> $data
	 */
	public static function record_consent_event( array $data ): int {
		global $wpdb;
		$contact_id = (int) ( $data['contact_id'] ?? 0 );
		$purpose    = sanitize_key( (string) ( $data['purpose'] ?? '' ) );
		$event      = (string) ( $data['event'] ?? '' );
		$valid      = [ 'granted', 'declined', 'withdrawn', 'objected', 'suppressed', 'administratively_corrected' ];
		if ( $contact_id <= 0 || '' === $purpose || ! in_array( $event, $valid, true ) ) {
			return 0;
		}

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_contact_consent_events", [
			'contact_id'        => $contact_id,
			'identity_id'       => isset( $data['identity_id'] ) && (int) $data['identity_id'] > 0 ? (int) $data['identity_id'] : null,
			'purpose'           => $purpose,
			'event'             => $event,
			'statement_version' => mb_substr( sanitize_text_field( (string) ( $data['statement_version'] ?? '' ) ), 0, 20 ),
			'notice_version'    => mb_substr( sanitize_text_field( (string) ( $data['notice_version'] ?? '' ) ), 0, 20 ),
			'source'            => sanitize_key( (string) ( $data['source'] ?? '' ) ),
			'actor'             => mb_substr( sanitize_text_field( (string) ( $data['actor'] ?? '' ) ), 0, 100 ),
			'occurred_at'       => (string) ( $data['occurred_at'] ?? current_time( 'mysql', true ) ),
			'evidence'          => isset( $data['evidence'] ) ? wp_json_encode( $data['evidence'] ) : null,
			'reason'            => isset( $data['reason'] ) ? sanitize_textarea_field( (string) $data['reason'] ) : null,
			'created_at'        => current_time( 'mysql', true ),
		] );
		if ( false === $inserted ) {
			return 0;
		}
		$event_id = (int) $wpdb->insert_id;

		self::reproject_preference( $contact_id, $purpose, (int) ( $data['identity_id'] ?? 0 ) );

		return $event_id;
	}

	/** Rebuild the current-state projection for one (contact, purpose, identity). */
	public static function reproject_preference( int $contact_id, string $purpose, int $identity_id = 0 ): void {
		global $wpdb;

		$events = $wpdb->get_results( $wpdb->prepare(
			"SELECT event, occurred_at, reason FROM {$wpdb->prefix}wpq_contact_consent_events
			 WHERE contact_id = %d AND purpose = %s AND COALESCE(identity_id, 0) = %d
			 ORDER BY occurred_at ASC, id ASC",
			$contact_id,
			$purpose,
			$identity_id
		) ) ?: [];

		$state = WPQ_Contact_Matcher::project_preference_state( $events );
		$now   = current_time( 'mysql', true );

		$existing = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_contact_preferences_current
			 WHERE contact_id = %d AND purpose = %s AND identity_id = %d",
			$contact_id,
			$purpose,
			$identity_id
		) );

		if ( $existing > 0 ) {
			$wpdb->update(
				"{$wpdb->prefix}wpq_contact_preferences_current",
				[ 'state' => $state, 'updated_at' => $now ],
				[ 'id' => $existing ]
			);
		} else {
			$wpdb->insert( "{$wpdb->prefix}wpq_contact_preferences_current", [
				'contact_id'  => $contact_id,
				'purpose'     => $purpose,
				'identity_id' => $identity_id,
				'state'       => $state,
				'updated_at'  => $now,
			] );
		}
	}

	// ------------------------------------------------------------------ //
	// Review queue
	// ------------------------------------------------------------------ //

	/**
	 * @param array<int, int> $candidate_ids
	 * @param array<string, mixed> $details
	 */
	public static function queue_review( string $source_type, int $source_id, array $candidate_ids, string $reason, array $details = [] ): int {
		global $wpdb;

		// One pending review per source record.
		$existing = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}wpq_contact_match_review
			 WHERE source_type = %s AND source_id = %d AND status = 'pending' LIMIT 1",
			sanitize_key( $source_type ),
			$source_id
		) );
		if ( $existing > 0 ) {
			return $existing;
		}

		$inserted = $wpdb->insert( "{$wpdb->prefix}wpq_contact_match_review", [
			'source_type'           => sanitize_key( $source_type ),
			'source_id'             => $source_id,
			'candidate_contact_ids' => implode( ',', array_map( 'intval', $candidate_ids ) ),
			'reason'                => sanitize_key( $reason ),
			'details'               => wp_json_encode( $details ),
			'status'                => 'pending',
			'created_at'            => current_time( 'mysql', true ),
		] );

		return false === $inserted ? 0 : (int) $wpdb->insert_id;
	}

	// ------------------------------------------------------------------ //
	// Diagnostics
	// ------------------------------------------------------------------ //

	/** @return array{contacts: int, unlinked_submissions: int, unlinked_enquiries: int, pending_reviews: int} */
	public static function diagnostics(): array {
		global $wpdb;

		return [
			'contacts'             => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contacts WHERE status NOT IN ('merged','deleted')" ),
			'unlinked_submissions' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpq_submissions WHERE contact_id IS NULL AND deleted_at IS NULL" ),
			'unlinked_enquiries'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpq_enquiries WHERE contact_id IS NULL" ),
			'pending_reviews'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpq_contact_match_review WHERE status = 'pending'" ),
		];
	}
}
