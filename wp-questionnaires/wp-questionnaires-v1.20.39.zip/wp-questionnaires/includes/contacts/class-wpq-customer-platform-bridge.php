<?php
/**
 * Publishes wp-questionnaires' canonical contact service on
 * wp-reconnaissance's Alltime\CustomerPlatform discovery hook, so both
 * products resolve ONE canonical contact - the wpq_* store, which carries the
 * richer model (merge pointers, hashed identities, consent projections,
 * match review) and is the store HaloPSA reconciles against. A contact then
 * has many questionnaire submissions AND many reconnaissance reports, not a
 * row in each product's private contact table.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPQ_Customer_Platform_Bridge {

	/**
	 * Priority matters, registration order does not: ContactPlatformDiscovery
	 * resolves with `$current ?? [service, version]` semantics, so the
	 * LOWEST-priority filter callback that returns a service wins. Recon
	 * self-provides at the default 10; registering at 1 makes this plugin the
	 * deterministic provider whenever both are active, regardless of plugin
	 * load order.
	 */
	private const FILTER   = 'alltime_customer_platform_contact_service';
	private const PRIORITY = 1;

	/** Contract version satisfied - resolve() checks the major segment only. */
	private const CONTRACT_VERSION = '1.0.0';

	/**
	 * Called on plugins_loaded (after every plugin's autoloader exists). A
	 * no-op unless the Alltime\CustomerPlatform contract classes are actually
	 * present - this plugin never hard-depends on wp-reconnaissance.
	 */
	public static function register(): void {
		if ( ! interface_exists( '\\Alltime\\CustomerPlatform\\ContactServiceInterface' ) ) {
			return;
		}
		if ( ! class_exists( 'WPQ_Contact_Service' ) || ! WPQ_Contact_Service::enabled() ) {
			return;
		}

		require_once __DIR__ . '/class-wpq-customer-platform-adapter.php';

		add_filter(
			self::FILTER,
			static function ( $current ) {
				if ( null !== $current ) {
					return $current; // Another provider answered at an even lower priority.
				}
				return [
					'service' => new WPQ_Customer_Platform_Adapter(),
					'version' => self::CONTRACT_VERSION,
				];
			},
			self::PRIORITY
		);
	}
}
