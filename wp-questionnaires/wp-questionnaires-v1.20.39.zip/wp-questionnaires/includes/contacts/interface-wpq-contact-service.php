<?php
/**
 * Contract for the canonical contact resolution service. Other Alltime
 * plugins receive an implementation of this interface through the versioned
 * `alltime_contact_service` filter (Phase 4) and never touch wpq_* tables.
 *
 * @package WP_Questionnaires
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface WPQ_Contact_Service_Interface {
	/**
	 * @param array{name?: string, email?: string, telephone?: string, organisation?: string} $input
	 * @param array{source: string, source_type?: string, source_id?: int, wp_user_id?: int, trusted_uuid?: string, observed_at?: string} $context
	 * @return array{contact_id: int, created: bool, decision: string, reason: string}
	 */
	public function resolve_or_create( array $input, array $context ): array;

	public function get_by_id( int $contact_id ): ?object;

	public function get_by_uuid( string $uuid ): ?object;

	public function get_for_wordpress_user( int $user_id ): ?object;

	public function link_wordpress_user( int $contact_id, int $user_id ): bool;

	/** @param array<string, mixed> $input */
	public function record_interaction( int $contact_id, array $input ): int;

	/** @param array<string, mixed> $input */
	public function record_consent_event( int $contact_id, array $input ): int;
}
