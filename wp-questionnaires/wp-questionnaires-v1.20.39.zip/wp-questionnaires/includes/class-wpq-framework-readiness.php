<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Assesses a completed submission's readiness against the frameworks selected
 * for its questionnaire, using the ATLAS skill registered for each framework.
 *
 * Each framework is assessed in its own beta Messages call with the framework's
 * Anthropic skill attached via `container.skills` (which requires the
 * code-execution tool - skills execute inside the container). The response is
 * a strict JSON posture assessment; every control reference it cites is
 * validated against the framework's imported catalogue, the same
 * anti-hallucination pattern used for `related_finding_ids`.
 *
 * Readiness is an enhancement to the Questionnaire Report: a framework whose
 * assessment fails is skipped (logged, never fatal), and a questionnaire with
 * no selected or registered frameworks simply produces no frameworks section.
 */
class WPQ_Framework_Readiness {

	public const PROMPT_VERSION = 'framework-readiness-v1';

	private const API_URL         = 'https://api.anthropic.com/v1/messages';
	private const API_VERSION     = '2023-06-01';
	private const BETA_HEADER     = 'code-execution-2025-08-25,skills-2025-10-02';
	private const REQUEST_TIMEOUT = 180;
	private const MAX_TOKENS      = 4000;

	/** Cost/latency guard: a report assesses at most this many frameworks. */
	public const MAX_FRAMEWORKS = 8;

	public const READINESS_LEVELS = [ 'aligned', 'partially_aligned', 'not_aligned', 'insufficient_evidence' ];

	private const LEVEL_LABELS = [
		'aligned'               => 'Aligned',
		'partially_aligned'     => 'Partially aligned',
		'not_aligned'           => 'Not aligned',
		'insufficient_evidence' => 'Insufficient evidence',
	];

	/**
	 * Assess the submission context against every selected, Anthropic-registered
	 * framework. Returns one row per successful assessment, in selection order.
	 *
	 * @param array<string, mixed> $context The questionnaire report context.
	 * @return array<int, array<string, mixed>>
	 */
	public static function assess_for_questionnaire( object $questionnaire, array $context ): array {
		$framework_ids = self::selected_framework_ids( $questionnaire );
		if ( empty( $framework_ids ) ) {
			return [];
		}

		$results = [];
		foreach ( array_slice( $framework_ids, 0, self::MAX_FRAMEWORKS ) as $framework_id ) {
			$framework = WPQ_Database::get_framework( $framework_id );
			if ( ! $framework || '' === trim( (string) ( $framework->skill_id ?? '' ) ) ) {
				continue; // Not imported, or not registered with the Skills API yet.
			}

			try {
				$results[] = self::assess_framework( $framework, $context );
			} catch ( Throwable $e ) {
				self::log_debug_event( 'framework_readiness_failed', [
					'framework_id' => (int) $framework->id,
					'slug'         => (string) $framework->slug,
					'error_type'   => get_class( $e ),
					'error'        => $e->getMessage(),
				] );
			}
		}

		return $results;
	}

	/** @return array<int, int> */
	public static function selected_framework_ids( object $questionnaire ): array {
		$raw = trim( (string) ( $questionnaire->framework_ids ?? '' ) );
		if ( '' === $raw ) {
			return [];
		}
		$ids = [];
		foreach ( explode( ',', $raw ) as $part ) {
			$id = (int) trim( $part );
			if ( $id > 0 && ! in_array( $id, $ids, true ) ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	/**
	 * One framework, one call, one validated assessment row.
	 *
	 * @param array<string, mixed> $context
	 * @return array<string, mixed>
	 */
	public static function assess_framework( object $framework, array $context ): array {
		$details = WPQ_Remediation_Plan::get_api_key_details();
		$api_key = (string) ( $details['value'] ?? '' );
		if ( '' === $api_key ) {
			throw new RuntimeException( 'Claude API key missing.' );
		}

		$model   = WPQ_Remediation_Plan::select_model( $api_key );
		$payload = self::build_payload( $framework, $context, $model );

		$encoded = wp_json_encode( $payload );
		if ( ! is_string( $encoded ) || '' === $encoded ) {
			throw new RuntimeException( 'Readiness request payload could not be encoded.' );
		}

		self::log_debug_event( 'framework_readiness_request', [
			'framework_id' => (int) $framework->id,
			'slug'         => (string) $framework->slug,
			'skill_id'     => (string) $framework->skill_id,
			'model'        => $model,
		] );

		$started  = microtime( true );
		$response = wp_remote_post( self::API_URL, [
			'timeout' => self::REQUEST_TIMEOUT,
			'headers' => [
				'content-type'      => 'application/json',
				'x-api-key'         => $api_key,
				'anthropic-version' => self::API_VERSION,
				'anthropic-beta'    => self::BETA_HEADER,
			],
			'body'    => $encoded,
		] );
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'Readiness request failed: ' . esc_html( $response->get_error_message() ) );
		}

		$code      = (int) wp_remote_retrieve_response_code( $response );
		$body_text = wp_remote_retrieve_body( $response );

		self::log_debug_event( 'framework_readiness_response', [
			'framework_id' => (int) $framework->id,
			'slug'         => (string) $framework->slug,
			'status_code'  => $code,
			'elapsed_ms'   => $elapsed_ms,
			'body_chars'   => strlen( $body_text ),
		] );

		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( 'Readiness request returned HTTP ' . (int) $code . '.' );
		}

		$body = json_decode( $body_text, true );
		if ( ! is_array( $body ) ) {
			throw new RuntimeException( 'Readiness response was not JSON.' );
		}

		$text = '';
		foreach ( $body['content'] ?? [] as $part ) {
			if ( is_array( $part ) && ( $part['type'] ?? '' ) === 'text' ) {
				$text .= (string) ( $part['text'] ?? '' );
			}
		}

		$known_refs = self::known_control_refs( (int) $framework->id );
		$assessment = self::parse_and_validate( $text, $known_refs );

		$assessment['framework_id'] = (int) $framework->id;
		$assessment['slug']         = (string) $framework->slug;
		$assessment['name']         = (string) $framework->name;

		return $assessment;
	}

	/**
	 * The Messages API request. The framework's skill rides in
	 * `container.skills` and executes through the code-execution tool; both
	 * beta flags are required.
	 *
	 * @param array<string, mixed> $context
	 * @return array<string, mixed>
	 */
	public static function build_payload( object $framework, array $context, string $model ): array {
		return [
			'model'      => $model,
			'max_tokens' => self::MAX_TOKENS,
			'container'  => [
				'skills' => [
					[
						'type'     => 'custom',
						'skill_id' => (string) $framework->skill_id,
						'version'  => '' !== trim( (string) ( $framework->skill_version ?? '' ) ) ? (string) $framework->skill_version : 'latest',
					],
				],
			],
			'tools'      => [
				[ 'type' => 'code_execution_20260521', 'name' => 'code_execution' ],
			],
			'system'     => 'You are a senior compliance assessor. Use the attached ' . (string) $framework->name
				. ' skill to assess the organisation\'s formal posture against that standard, based only on the '
				. 'questionnaire evidence provided. Cite the standard\'s own control/clause references. Do not '
				. 'invent evidence; where the questionnaire does not cover a control, treat it as unassessed '
				. 'rather than failed. Return only valid JSON matching the requested schema.',
			'messages'   => [
				[ 'role' => 'user', 'content' => self::build_prompt( $framework, $context ) ],
			],
		];
	}

	/** @param array<string, mixed> $context */
	public static function build_prompt( object $framework, array $context ): string {
		$schema = wp_json_encode( [
			'readiness_level'   => 'aligned|partially_aligned|not_aligned|insufficient_evidence',
			'readiness_percent' => 'integer 0-100, or null unless the standard\'s own methodology yields a defensible figure',
			'summary'           => 'string - 2-4 sentences on formal posture against the standard',
			'strengths'         => [ [ 'control_ref' => 'string - the standard\'s own reference', 'note' => 'string' ] ],
			'gaps'              => [ [ 'control_ref' => 'string', 'gap' => 'string', 'recommendation' => 'string' ] ],
		] );

		$payload = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		return 'Assess this organisation\'s posture against ' . (string) $framework->name . ".\n"
			. "Return strict JSON only, matching exactly this shape (arrays may be empty but must be present):\n{$schema}\n"
			. "Set readiness_percent to null unless the standard's methodology produces a defensible percentage - never estimate one.\n"
			. "Do not include markdown or text outside the JSON object.\n"
			. "Questionnaire evidence JSON:\n{$payload}";
	}

	/**
	 * @param array<int, string> $known_refs Lower-cased control refs from the imported catalogue.
	 * @return array<string, mixed>
	 */
	public static function parse_and_validate( string $text, array $known_refs ): array {
		$text = trim( $text );
		if ( '' === $text ) {
			throw new RuntimeException( 'Readiness response was empty.' );
		}

		$decoded = json_decode( $text, true );
		if ( ! is_array( $decoded ) && preg_match( '/\{.*\}/s', $text, $matches ) ) {
			$decoded = json_decode( $matches[0], true );
		}
		if ( ! is_array( $decoded ) ) {
			throw new RuntimeException( 'Readiness response was not valid JSON.' );
		}

		$level = strtolower( trim( (string) ( $decoded['readiness_level'] ?? '' ) ) );
		if ( ! in_array( $level, self::READINESS_LEVELS, true ) ) {
			$level = 'insufficient_evidence';
		}

		$percent = null;
		if ( isset( $decoded['readiness_percent'] ) && is_numeric( $decoded['readiness_percent'] ) ) {
			$percent = max( 0, min( 100, (int) $decoded['readiness_percent'] ) );
		}

		$summary = sanitize_textarea_field( (string) ( $decoded['summary'] ?? '' ) );
		if ( '' === $summary ) {
			throw new RuntimeException( 'Readiness response is missing a summary.' );
		}

		return [
			'readiness_level' => $level,
			'readiness_label' => self::LEVEL_LABELS[ $level ],
			'readiness_percent' => $percent,
			'summary'         => $summary,
			'strengths'       => self::sanitise_ref_rows( $decoded['strengths'] ?? [], $known_refs, [ 'note' ] ),
			'gaps'            => self::sanitise_ref_rows( $decoded['gaps'] ?? [], $known_refs, [ 'gap', 'recommendation' ] ),
		];
	}

	/**
	 * Sanitise rows carrying a control_ref plus text fields. A cited ref that
	 * does not exist in the imported catalogue is cleared (never shown to a
	 * client as if it were real) while the row's substance is kept. When the
	 * catalogue is empty (metadata-only frameworks such as ITIL), refs pass
	 * through untouched - there is nothing to validate against.
	 *
	 * @param array<int, string> $known_refs
	 * @param array<int, string> $text_fields
	 * @return array<int, array<string, string>>
	 */
	private static function sanitise_ref_rows( mixed $rows, array $known_refs, array $text_fields ): array {
		if ( ! is_array( $rows ) ) {
			return [];
		}

		$out = [];
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$clean = [];
			$has_text = false;
			foreach ( $text_fields as $field ) {
				$value = sanitize_textarea_field( (string) ( $row[ $field ] ?? '' ) );
				$clean[ $field ] = $value;
				if ( '' !== $value ) {
					$has_text = true;
				}
			}
			if ( ! $has_text ) {
				continue;
			}

			$ref = sanitize_text_field( (string) ( $row['control_ref'] ?? '' ) );
			if ( ! empty( $known_refs ) && '' !== $ref && ! in_array( strtolower( $ref ), $known_refs, true ) ) {
				$ref = '';
			}
			$clean['control_ref'] = mb_substr( $ref, 0, 50 );

			$out[] = $clean;
		}

		return $out;
	}

	/** @return array<int, string> */
	public static function known_control_refs( int $framework_id ): array {
		$refs = [];
		foreach ( WPQ_Database::get_framework_controls( $framework_id ) as $control ) {
			$ref = strtolower( trim( (string) ( $control->control_ref ?? '' ) ) );
			if ( '' !== $ref ) {
				$refs[] = $ref;
			}
		}
		return $refs;
	}

	private static function log_debug_event( string $event, array $data = [] ): void {
		if ( class_exists( 'WPQ_Questionnaire_Report_Analysis' )
			&& WPQ_Questionnaire_Report_Analysis::debug_logging_enabled()
			&& method_exists( 'WPQ_Remediation_Plan', 'get_api_key_details' ) ) {
			// Reuse the shared Claude debug log via the analysis class's channel.
			$log   = get_option( 'wpq_claude_debug_log', [] );
			$log   = is_array( $log ) ? $log : [];
			array_unshift( $log, [
				'time'  => current_time( 'mysql', true ),
				'event' => sanitize_key( $event ),
				'data'  => $data,
			] );
			update_option( 'wpq_claude_debug_log', array_slice( $log, 0, 50 ), false );
		}
	}
}
