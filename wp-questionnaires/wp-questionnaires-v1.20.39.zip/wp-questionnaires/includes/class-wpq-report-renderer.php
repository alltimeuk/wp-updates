<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Report_Renderer {
	private static ?string $test_pdf_binary = null;

	public static function set_test_pdf_binary( ?string $pdf_binary ): void {
		self::$test_pdf_binary = $pdf_binary;
	}

	public static function template_path(): string {
		return WPQ_PLUGIN_DIR . 'templates/report.php';
	}

	public static function template_available(): bool {
		return is_readable( self::template_path() );
	}

	public static function can_render(): bool {
		return class_exists( '\Dompdf\Dompdf' ) && self::template_available();
	}

	public static function storage_available(): bool {
		$directory = self::get_storage_dir( false );
		if ( $directory === '' ) {
			return false;
		}
		if ( is_dir( $directory ) ) {
			return is_writable( $directory );
		}

		$parent = self::nearest_existing_parent( $directory );
		return $parent !== '' && is_writable( $parent );
	}

	public static function storage_diagnostics(): array {
		// ensure=true: same rationale as WPQ_Questionnaire_Report_Storage::diagnostics()
		// - a never-yet-used install otherwise misreports "not writable" for a
		// directory generation would create fine on first real render.
		$directory = self::get_storage_dir();
		if ( '' === $directory ) {
			$directory = self::get_storage_dir( false );
		}
		$parent = $directory !== '' ? self::nearest_existing_parent( $directory ) : '';

		return [
			'path'                  => $directory,
			'available'             => $directory !== '' && is_dir( $directory ),
			'writable'              => $directory !== '' && is_dir( $directory ) && is_writable( $directory ),
			'creatable'             => $directory !== '' && ! is_dir( $directory ) && $parent !== '' && is_writable( $parent ),
			'index_guard_present'   => $directory !== '' && is_file( $directory . DIRECTORY_SEPARATOR . 'index.html' ),
			'htaccess_guard_present'=> $directory !== '' && is_file( $directory . DIRECTORY_SEPARATOR . '.htaccess' ),
		];
	}

	public static function render_report_html( int $submission_id, int $product_id ): string {
		$submission = WPQ_Database::get_submission( $submission_id );
		$product = WPQ_Database::get_product_admin( $product_id );
		if ( ! $submission || ! $product ) {
			throw new RuntimeException( 'Report source data not found.' );
		}

		$questionnaire = WPQ_Database::get_questionnaire( (int) $submission->questionnaire_id );
		$domain_scores = $submission->domain_scores_json ? json_decode( (string) $submission->domain_scores_json, true ) : [];
		$findings = $submission->findings_json ? json_decode( (string) $submission->findings_json, true ) : [];
		$findings = is_array( $findings ) ? self::prepare_findings_for_report( $findings ) : [];
		$generated_at = current_time( 'mysql', true );

		// Framework readiness radar, when the submission carries stored
		// framework assessments. Dompdf cannot fetch remote assets, so the
		// chart is embedded as a data URI; template renders the section only
		// when both rows and the image exist.
		$framework_rows      = class_exists( 'WPQ_Framework_Radar' )
			? WPQ_Framework_Radar::rows_from_analysis( WPQ_Framework_Radar::stored_frameworks( $submission ) )
			: [];
		$framework_radar_uri = '';
		if ( ! empty( $framework_rows ) ) {
			$radar_png = WPQ_Framework_Radar::render_png( $framework_rows );
			if ( null !== $radar_png ) {
				$framework_radar_uri = 'data:image/png;base64,' . base64_encode( $radar_png );
			}
		}

		ob_start();
		include self::template_path();
		return (string) ob_get_clean();
	}

	private static function prepare_findings_for_report( array $findings ): array {
		$allowed_priorities = [ 'critical', 'high', 'medium', 'low' ];
		$severity_rank      = [
			'critical' => 0,
			'high'     => 1,
			'medium'   => 2,
			'low'      => 3,
		];

		$prepared = [];
		foreach ( $findings as $finding ) {
			if ( ! is_array( $finding ) ) {
				continue;
			}

			$priority = strtolower( trim( (string) ( $finding['priority'] ?? '' ) ) );
			if ( ! in_array( $priority, $allowed_priorities, true ) ) {
				continue;
			}

			$finding['priority'] = $priority;
			$finding['domain']   = (string) ( $finding['domain'] ?? $finding['domain_name'] ?? '' );
			$prepared[]          = $finding;
		}

		usort(
			$prepared,
			static function ( array $a, array $b ) use ( $severity_rank ): int {
				$domain_cmp = strcasecmp( (string) ( $a['domain'] ?? '' ), (string) ( $b['domain'] ?? '' ) );
				if ( $domain_cmp !== 0 ) {
					return $domain_cmp;
				}

				return ( $severity_rank[ $a['priority'] ] ?? 99 ) <=> ( $severity_rank[ $b['priority'] ] ?? 99 );
			}
		);

		return $prepared;
	}

	public static function generate_pdf( string $html ): string {
		if ( self::$test_pdf_binary !== null ) {
			return self::$test_pdf_binary;
		}
		if ( ! class_exists( '\Dompdf\Dompdf' ) ) {
			throw new RuntimeException( 'Dompdf is not available.' );
		}

		$dompdf = new \Dompdf\Dompdf( [
			'isRemoteEnabled' => false,
			'defaultFont'     => 'DejaVu Sans',
		] );
		$dompdf->loadHtml( $html );
		$dompdf->setPaper( 'A4', 'portrait' );
		$dompdf->render();
		return (string) $dompdf->output();
	}

	public static function store_report( int $submission_id, int $product_id, string $pdf_binary ): array {
		$directory = self::get_storage_dir();
		if ( $directory === '' ) {
			return [];
		}

		$file_name = preg_replace( '/[^A-Za-z0-9._-]/', '-', sprintf(
			'wpq-report-%d-%d-%s.pdf',
			$submission_id,
			$product_id,
			substr( hash( 'sha256', $pdf_binary . wp_salt( 'auth' ) ), 0, 16 )
		) );
		$file_name = $file_name ?: 'wpq-report.pdf';
		$path = $directory . DIRECTORY_SEPARATOR . $file_name;

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Plugin-owned generated PDF in uploads.
		if ( file_put_contents( $path, $pdf_binary ) === false ) {
			return [];
		}

		return [
			'path' => $file_name,
			'name' => $file_name,
		];
	}

	public static function generate_and_store( int $submission_id, int $product_id ): array {
		$html = self::render_report_html( $submission_id, $product_id );
		$pdf = self::generate_pdf( $html );
		$stored = self::store_report( $submission_id, $product_id, $pdf );
		if ( empty( $stored['path'] ) ) {
			throw new RuntimeException( 'Could not store generated report.' );
		}

		if ( ! WPQ_Database::update_submission_report( $submission_id, $product_id, $stored['path'] ) ) {
			throw new RuntimeException( 'Could not record generated report.' );
		}
		return $stored;
	}

	public static function get_storage_dir( bool $ensure = true ): string {
		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return '';
		}

		$upload = wp_upload_dir();
		if ( ! is_array( $upload ) || ! empty( $upload['error'] ) || empty( $upload['basedir'] ) ) {
			return '';
		}

		$directory = rtrim( (string) $upload['basedir'], DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'wp-questionnaires' . DIRECTORY_SEPARATOR . 'reports';
		if ( ! $ensure ) {
			return $directory;
		}

		if ( ! is_dir( $directory ) && function_exists( 'wp_mkdir_p' ) && ! wp_mkdir_p( $directory ) ) {
			return '';
		}
		if ( ! is_dir( $directory ) ) {
			return '';
		}

		self::write_access_guards( $directory );
		return $directory;
	}

	public static function reports_directory(): string {
		return self::get_storage_dir();
	}

	public static function resolve_report_path( string $stored_path ): ?string {
		$stored_path = trim( $stored_path );
		if ( $stored_path === '' ) {
			return null;
		}

		$directory = self::get_storage_dir();
		if ( $directory === '' ) {
			return null;
		}

		$storage_root = realpath( $directory );
		if ( ! is_string( $storage_root ) || $storage_root === '' ) {
			return null;
		}

		$is_absolute = str_starts_with( $stored_path, '/' )
			|| str_starts_with( $stored_path, '\\' )
			|| preg_match( '/^[A-Za-z]:[\/\\\\]/', $stored_path );
		$candidate = $is_absolute
			? $stored_path
			: $storage_root . DIRECTORY_SEPARATOR . ltrim( str_replace( [ '/', '\\' ], DIRECTORY_SEPARATOR, $stored_path ), DIRECTORY_SEPARATOR );

		$resolved = realpath( $candidate );
		if ( ! is_string( $resolved ) || $resolved === '' ) {
			return null;
		}

		$storage_root = self::normalise_path_for_compare( rtrim( $storage_root, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR );
		$resolved_compare = self::normalise_path_for_compare( $resolved );
		if ( strncmp( $resolved_compare, $storage_root, strlen( $storage_root ) ) !== 0 ) {
			return null;
		}

		return $resolved;
	}

	private static function normalise_path_for_compare( string $path ): string {
		$path = str_replace( '\\', '/', $path );
		return PHP_OS_FAMILY === 'Windows' ? strtolower( $path ) : $path;
	}

	private static function nearest_existing_parent( string $path ): string {
		$parent = dirname( $path );
		while ( $parent !== '' && $parent !== '.' && ! is_dir( $parent ) ) {
			$next = dirname( $parent );
			if ( $next === $parent ) {
				return '';
			}
			$parent = $next;
		}

		return is_dir( $parent ) ? $parent : '';
	}

	private static function write_access_guards( string $directory ): void {
		$index = $directory . DIRECTORY_SEPARATOR . 'index.html';
		if ( ! is_file( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Static guard file in plugin-owned uploads directory.
			file_put_contents( $index, '' );
		}

		$htaccess = $directory . DIRECTORY_SEPARATOR . '.htaccess';
		if ( ! is_file( $htaccess ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Best-effort Apache guard for generated private reports.
			file_put_contents( $htaccess, "Require all denied\nDeny from all\n" );
		}
	}
}
