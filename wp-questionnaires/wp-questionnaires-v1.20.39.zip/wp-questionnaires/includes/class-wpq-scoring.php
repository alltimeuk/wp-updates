<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Scoring {
	public const SCHEMA_VERSION = '1.0.0';

	/**
	 * Score a completed set of answers against a questionnaire's domain/question structure.
	 *
	 * @param array $answers   Flat key→value map. Keys: "{domain_index}_{question_index}".
	 *                         Values vary by question_type (string or JSON-encoded array for checkbox).
	 * @param array $structure Output of WPQ_Database::get_questionnaire_structure().
	 * @return array Scored result ready for storage and API response.
	 */
	public static function score( array $answers, array $structure ): array {
		$domains    = $structure['domains'];
		$thresholds = $structure['thresholds'];

		$total_raw     = 0;
		$total_max     = 0;
		$domain_scores = [];
		$findings      = [];
		$yes_count     = 0;

		foreach ( $domains as $di => $domain ) {
			$domain_raw = 0;
			$domain_max = 0;

			foreach ( $domain['questions'] as $qi => $question ) {
				$key          = "{$di}_{$qi}";
				$raw_answer   = $answers[ $key ] ?? null;
				$q_type       = (string) ( $question['question_type'] ?? 'tri_state' );
				$scoring_mode = self::resolve_scoring_mode( $q_type, (string) ( $question['scoring_mode'] ?? '' ) );

				// Hidden conditional questions are excluded from the denominator.
				$condition = $question['condition'] ?? null;
				if ( ! self::is_condition_met( $condition, $answers ) ) {
					continue;
				}

				// Non-scoring questions never enter the denominator.
				if ( $scoring_mode === 'non_scoring' ) {
					continue;
				}

				// Unanswered questions are skipped (don't contribute to numerator or denominator).
				if ( $raw_answer === null ) {
					continue;
				}

				// Decode checkbox arrays stored as JSON strings.
				$answer = $raw_answer;
				if ( $scoring_mode === 'sum_selected' || $scoring_mode === 'max_selected' ) {
					if ( is_string( $raw_answer ) ) {
						$decoded = json_decode( $raw_answer, true );
						$answer  = is_array( $decoded ) ? $decoded : [ $raw_answer ];
					}
				}

				$max    = self::question_max_score( $question, $scoring_mode );
				$points = self::score_answer( $answer, $scoring_mode, $question );

				$domain_raw += $points;
				$domain_max += $max;
				$total_max  += $max;

				// Findings for legacy tri_state and boolean.
				if ( $scoring_mode === 'legacy_tri_state' ) {
					if ( $answer === 'yes' ) {
						$yes_count++;
					} elseif ( $answer === 'no' ) {
						$findings[] = [
							'priority'    => 'critical',
							'domain_name' => $domain['name'],
							'domain_slug' => $domain['slug'],
							'question'    => $question['question'],
							'action'      => ( ! empty( $question['recommendation'] ) ) ? $question['recommendation'] : ( $question['guidance_no'] ?? '' ),
							'answer_label' => 'No',
						];
					} elseif ( $answer === 'partial' ) {
						$findings[] = [
							'priority'    => 'medium',
							'domain_name' => $domain['name'],
							'domain_slug' => $domain['slug'],
							'question'    => $question['question'],
							'action'      => rtrim( $question['question'], '?' ) . ' – partially in place. Completing this control is recommended.',
							'answer_label' => 'Partial',
						];
					}
				} elseif ( $scoring_mode === 'boolean' ) {
					if ( $answer === 'yes' ) {
						$yes_count++;
					} elseif ( $answer === 'no' ) {
						$findings[] = [
							'priority'    => 'critical',
							'domain_name' => $domain['name'],
							'domain_slug' => $domain['slug'],
							'question'    => $question['question'],
							'action'      => ( ! empty( $question['recommendation'] ) ) ? $question['recommendation'] : ( $question['guidance_no'] ?? '' ),
							'answer_label' => 'No',
						];
					}
				} elseif ( $scoring_mode === 'reverse_boolean' ) {
					if ( $answer === 'yes' ) {
						$findings[] = [
							'priority'    => 'critical',
							'domain_name' => $domain['name'],
							'domain_slug' => $domain['slug'],
							'question'    => $question['question'],
							'action'      => $question['guidance_yes'],
							'answer_label' => 'Yes',
						];
					}
				} elseif ( $scoring_mode === 'single_option' ) {
					$selected_option = self::find_option( (string) $answer, $question['options'] ?? [] );
					if ( $selected_option ) {
						$priority = $selected_option['finding_priority'] ?? null;
						$action   = $selected_option['finding_action'] ?? null;
						if ( $priority && $action ) {
							$findings[] = [
								'priority'    => $priority,
								'domain_name' => $domain['name'],
								'domain_slug' => $domain['slug'],
								'question'    => $question['question'],
								'action'      => $action,
								'answer_label' => $selected_option['label'] ?? '',
							];
						} elseif ( $points < $max ) {
							$fallback = ! empty( $question['recommendation'] )
								? $question['recommendation']
								: rtrim( $question['question'], '?' ) . ' – consider improving to a higher level.';
							$findings[] = [
								'priority'    => 'medium',
								'domain_name' => $domain['name'],
								'domain_slug' => $domain['slug'],
								'question'    => $question['question'],
								'action'      => $fallback,
								'answer_label' => $selected_option['label'] ?? '',
							];
						}
					}
				} elseif ( $scoring_mode === 'sum_selected' || $scoring_mode === 'max_selected' ) {
					$selected_keys = is_array( $answer ) ? $answer : [ $answer ];
					foreach ( $selected_keys as $opt_key ) {
						$opt = self::find_option( (string) $opt_key, $question['options'] ?? [] );
						if ( $opt ) {
							$priority = $opt['finding_priority'] ?? null;
							$action   = $opt['finding_action'] ?? null;
							if ( $priority && $action ) {
								$findings[] = [
									'priority'    => $priority,
									'domain_name' => $domain['name'],
									'domain_slug' => $domain['slug'],
									'question'    => $question['question'],
									'action'      => $action,
									'answer_label' => $opt['label'] ?? '',
								];
							}
						}
					}
				}
			}

			$domain_pct      = $domain_max > 0 ? (int) round( ( $domain_raw / $domain_max ) * 100 ) : 0;
			$domain_scores[] = [
				'id'    => $domain['id'],
				'slug'  => $domain['slug'],
				'name'  => $domain['name'],
				'icon'  => $domain['icon'],
				'score' => $domain_raw,
				'max'   => $domain_max,
				'pct'   => $domain_pct,
			];

			$total_raw += $domain_raw;
		}

		$overall_pct = $total_max > 0 ? (int) round( ( $total_raw / $total_max ) * 100 ) : 0;
		$grade       = self::resolve_grade( $overall_pct, $thresholds );
		$grade_scale = self::build_grade_scale( $thresholds );

		// Sort: critical before medium, preserve order within each priority.
		usort( $findings, fn( $a, $b ) =>
			( $a['priority'] === 'critical' ? 0 : 1 ) <=> ( $b['priority'] === 'critical' ? 0 : 1 )
		);

		$top_actions = array_map( fn( $f ) => [
			'priority'     => $f['priority'],
			'domain'       => $f['domain_name'],
			'domain_slug'  => $f['domain_slug'],
			'question'     => $f['question'],
			'action'       => $f['action'],
			'answer_label' => $f['answer_label'] ?? '',
		], $findings );

		return [
			'overall_score'  => $overall_pct,
			'grade'          => $grade,
			'grade_scale'    => $grade_scale,
			'domain_scores'  => $domain_scores,
			'findings'       => $findings,
			'top_actions'    => $top_actions,
			'yes_count'      => $yes_count,
			'generated_at'   => gmdate( 'c' ),
		];
	}

	/**
	 * Validate that answers are present and valid for their question type.
	 *
	 * @param array $answers   Submitted answers.
	 * @param array $structure Questionnaire structure from WPQ_Database::get_questionnaire_structure().
	 * @return true|array      true on success, ['code'=>string,'message'=>string] on failure.
	 */
	public static function validate( array $answers, array $structure ): bool|array {
		$missing = [];
		$invalid = [];

		foreach ( $structure['domains'] as $di => $domain ) {
			foreach ( $domain['questions'] as $qi => $question ) {
				$key          = "{$di}_{$qi}";
				$q_type       = (string) ( $question['question_type'] ?? 'tri_state' );
				$scoring_mode = self::resolve_scoring_mode( $q_type, (string) ( $question['scoring_mode'] ?? '' ) );
				$is_required  = (bool) ( $question['is_required'] ?? true );
				$has_answer   = array_key_exists( $key, $answers );
				$answer       = $answers[ $key ] ?? null;

				// Hidden conditional questions skip required validation entirely.
				$condition = $question['condition'] ?? null;
				if ( ! self::is_condition_met( $condition, $answers ) ) {
					continue;
				}

				if ( ! $has_answer || $answer === null || $answer === '' ) {
					// For non-scoring memo: optional is fine; required is missing.
					if ( $is_required && $scoring_mode !== 'non_scoring' ) {
						$missing[] = $key;
					} elseif ( $is_required && ( ! $has_answer || $answer === '' ) ) {
						// non_scoring required questions must also have a value.
						$missing[] = $key;
					}
					continue;
				}

				// Validate per type.
				switch ( $q_type ) {
					case 'tri_state':
						if ( ! in_array( $answer, [ 'yes', 'partial', 'no' ], true ) ) {
							$invalid[] = $key;
						}
						break;

					case 'boolean':
						if ( ! in_array( $answer, [ 'yes', 'no' ], true ) ) {
							$invalid[] = $key;
						}
						break;

					case 'select':
					case 'radio':
						if ( ! is_string( $answer ) || ! self::is_valid_option_key( $answer, $question['options'] ?? [] ) ) {
							$invalid[] = $key;
						}
						break;

					case 'checkbox':
						$selected = $answer;
						if ( is_string( $answer ) ) {
							$decoded  = json_decode( $answer, true );
							$selected = is_array( $decoded ) ? $decoded : [ $answer ];
						}
						if ( ! is_array( $selected ) || empty( $selected ) ) {
							if ( $is_required ) {
								$invalid[] = $key;
							}
							break;
						}
						$opts             = $question['options'] ?? [];
						$invalid_key_found = false;
						foreach ( $selected as $opt_key ) {
							if ( ! self::is_valid_option_key( (string) $opt_key, $opts ) ) {
								$invalid[]        = $key;
								$invalid_key_found = true;
								break;
							}
						}
						if ( $invalid_key_found ) {
							break;
						}
						$min_sel  = isset( $question['min_selections'] ) ? (int) $question['min_selections'] : null;
						$max_sel  = isset( $question['max_selections'] ) ? (int) $question['max_selections'] : null;
						$sel_count = count( $selected );
						if ( $min_sel !== null && $sel_count < $min_sel ) {
							$invalid[] = $key;
							break;
						}
						if ( $max_sel !== null && $sel_count > $max_sel ) {
							$invalid[] = $key;
							break;
						}
						$has_exclusive = false;
						foreach ( $selected as $opt_key ) {
							$opt = self::find_option( (string) $opt_key, $opts );
							if ( $opt && ! empty( $opt['exclusive'] ) ) {
								$has_exclusive = true;
								break;
							}
						}
						if ( $has_exclusive && $sel_count > 1 ) {
							$invalid[] = $key;
						}
						break;

					case 'memo':
						if ( ! is_string( $answer ) ) {
							$invalid[] = $key;
						} elseif ( mb_strlen( $answer ) > 2000 ) {
							$invalid[] = $key;
						}
						break;

					case 'short_text':
						if ( ! is_string( $answer ) ) {
							$invalid[] = $key;
						} elseif ( mb_strlen( $answer ) > 255 ) {
							$invalid[] = $key;
						}
						break;

					case 'number':
						if ( ! is_numeric( $answer ) ) {
							$invalid[] = $key;
						}
						break;
				}
			}
		}

		if ( ! empty( $missing ) ) {
			return [
				'code'    => 'INCOMPLETE_ANSWERS',
				'message' => 'The following answer keys are missing: ' . implode( ', ', $missing ) . '.',
			];
		}

		if ( ! empty( $invalid ) ) {
			return [
				'code'    => 'INVALID_PAYLOAD',
				'message' => 'Invalid values for keys: ' . implode( ', ', $invalid ) . '.',
			];
		}

		return true;
	}

	/**
	 * Rebuild the client-facing micro report for an already-completed
	 * submission, e.g. when a customer's page refresh needs to restore the
	 * results they already saw rather than losing them. Reconstructed from
	 * the submission's *stored* domain_scores_json/findings_json/
	 * overall_score snapshot rather than re-scoring the answers - that
	 * snapshot is the authoritative record of what the customer was
	 * originally shown, and must not silently drift if the questionnaire's
	 * questions or weightings are edited afterwards. Only the grade
	 * label/colour lookup and top_actions are recomputed, both pure
	 * functions of the stored data.
	 */
	public static function build_micro_report_from_submission( object $submission, array $structure ): array {
		$domain_scores = self::decode_json_array( $submission->domain_scores_json ?? '' );
		$findings      = self::decode_json_array( $submission->findings_json ?? '' );
		$overall_score = (int) ( $submission->overall_score ?? 0 );
		$thresholds    = $structure['thresholds'] ?? [];

		$top_actions = array_map( fn( $f ) => [
			'priority'     => $f['priority'] ?? '',
			'domain'       => $f['domain_name'] ?? '',
			'domain_slug'  => $f['domain_slug'] ?? '',
			'question'     => $f['question'] ?? '',
			'action'       => $f['action'] ?? '',
			'answer_label' => $f['answer_label'] ?? '',
		], $findings );

		return self::build_micro_report( [
			'overall_score' => $overall_score,
			'grade'         => self::resolve_grade( $overall_score, $thresholds ),
			'grade_scale'   => self::build_grade_scale( $thresholds ),
			'domain_scores' => $domain_scores,
			'findings'      => $findings,
			'top_actions'   => $top_actions,
			'yes_count'     => 0,
			'generated_at'  => (string) ( $submission->completed_at ?? gmdate( 'c' ) ),
		] );
	}

	private static function decode_json_array( mixed $json ): array {
		if ( ! is_string( $json ) || '' === $json ) {
			return [];
		}
		$decoded = json_decode( $json, true );
		return is_array( $decoded ) ? $decoded : [];
	}

	/**
	 * Build the micro report payload from a scored result.
	 */
	public static function build_micro_report( array $result ): array {
		return [
			'status'        => 'ok',
			'report_type'   => 'micro',
			'overall_score' => $result['overall_score'],
			'grade'         => $result['grade']['grade_id'],
			'grade_label'   => $result['grade']['grade_label'],
			'grade_color'   => self::grade_color( $result['grade'] ),
			'grade_bg'      => self::grade_bg( $result['grade'] ),
			'grade_scale'   => $result['grade_scale'] ?? [],
			'verdict'       => $result['grade']['verdict'],
			'domains'       => array_map(
				static function ( $d ) use ( $result ) {
					$domain_grade = self::resolve_grade_from_scale( (int) ( $d['pct'] ?? 0 ), $result['grade_scale'] ?? [] );

					return [
						'id'          => $d['id'] ?? null,
						'slug'        => $d['slug'] ?? '',
						'name'        => $d['name'] ?? '',
						'score'       => $d['score'] ?? 0,
						'max'         => $d['max'] ?? 0,
						'pct'         => $d['pct'] ?? 0,
						'grade'       => $domain_grade['grade'],
						'grade_label' => $domain_grade['grade_label'],
						'grade_color' => $domain_grade['color'],
						'grade_bg'    => $domain_grade['bg'],
					];
				},
				$result['domain_scores']
			),
			'top_actions'   => $result['top_actions'],
			'yes_count'     => $result['yes_count'],
			'generated_at'  => $result['generated_at'],
		];
	}

	// ------------------------------------------------------------------ //
	// Private helpers
	// ------------------------------------------------------------------ //

	/**
	 * Derive the effective scoring mode from question_type when scoring_mode is empty.
	 */
	private static function resolve_scoring_mode( string $question_type, string $scoring_mode ): string {
		if ( ( $scoring_mode !== '' && $scoring_mode !== 'legacy_tri_state' ) || $question_type === 'tri_state' ) {
			return $scoring_mode !== '' ? $scoring_mode : 'legacy_tri_state';
		}

		return match ( $question_type ) {
			'boolean'                   => 'boolean',
			'select', 'radio'           => 'single_option',
			'checkbox'                  => 'sum_selected',
			'memo', 'short_text',
			'number'                    => 'non_scoring',
			default                     => 'legacy_tri_state',
		};
	}

	/**
	 * Calculate the maximum achievable score for a question.
	 */
	private static function question_max_score( array $question, string $scoring_mode ): int {
		$explicit_max = null;
		if ( isset( $question['max_score'] ) && (int) $question['max_score'] > 0 ) {
			$explicit_max = (int) $question['max_score'];
		}

		if ( $explicit_max !== null ) {
			return $explicit_max;
		}

		return match ( $scoring_mode ) {
			'legacy_tri_state'  => (int) ( $question['score_yes'] ?? 0 ),
			'boolean'           => (int) ( $question['score_yes'] ?? 0 ),
			'reverse_boolean'   => (int) ( $question['score_no'] ?? 0 ),
			'single_option', 'max_selected' => self::max_option_score( $question['options'] ?? [] ),
			'sum_selected'      => self::sum_all_option_scores( $question['options'] ?? [] ),
			default             => 0,
		};
	}

	/**
	 * Calculate the score for a given answer under the specified scoring mode.
	 *
	 * @param string|array $answer
	 */
	private static function score_answer( $answer, string $scoring_mode, array $question ): int {
		switch ( $scoring_mode ) {
			case 'legacy_tri_state':
				return match ( (string) $answer ) {
					'yes'     => (int) ( $question['score_yes'] ?? 0 ),
					'partial' => (int) ( $question['score_partial'] ?? 0 ),
					'no'      => (int) ( $question['score_no'] ?? 0 ),
					default   => 0,
				};

			case 'boolean':
				return match ( (string) $answer ) {
					'yes' => (int) ( $question['score_yes'] ?? 0 ),
					'no'  => (int) ( $question['score_no'] ?? 0 ),
					default => 0,
				};

			case 'reverse_boolean':
				return match ( (string) $answer ) {
					'yes' => (int) ( $question['score_yes'] ?? 0 ),
					'no'  => (int) ( $question['score_no'] ?? 0 ),
					default => 0,
				};

			case 'single_option':
				$opt = self::find_option( (string) $answer, $question['options'] ?? [] );
				return $opt ? (int) $opt['score'] : 0;

			case 'sum_selected':
				$keys = is_array( $answer ) ? $answer : [ $answer ];
				$sum  = 0;
				foreach ( $keys as $k ) {
					$opt = self::find_option( (string) $k, $question['options'] ?? [] );
					if ( $opt ) {
						$sum += (int) $opt['score'];
					}
				}
				$max = self::question_max_score( $question, 'sum_selected' );
				return $max > 0 ? min( $sum, $max ) : $sum;

			case 'max_selected':
				$keys   = is_array( $answer ) ? $answer : [ $answer ];
				$best   = 0;
				foreach ( $keys as $k ) {
					$opt = self::find_option( (string) $k, $question['options'] ?? [] );
					if ( $opt ) {
						$best = max( $best, (int) $opt['score'] );
					}
				}
				return $best;

			default:
				return 0;
		}
	}

	/** Find an option by key from the options array. */
	private static function find_option( string $key, array $options ): ?array {
		foreach ( $options as $opt ) {
			if ( ( $opt['key'] ?? '' ) === $key ) {
				return $opt;
			}
		}

		return null;
	}

	/** Check whether a key matches an active option. */
	private static function is_valid_option_key( string $key, array $options ): bool {
		return self::find_option( $key, $options ) !== null;
	}

	/** Highest score among all options. */
	private static function max_option_score( array $options ): int {
		$max = 0;
		foreach ( $options as $opt ) {
			$max = max( $max, (int) ( $opt['score'] ?? 0 ) );
		}

		return $max;
	}

	/** Sum of all option scores (used as default max for sum_selected). */
	private static function sum_all_option_scores( array $options ): int {
		$sum = 0;
		foreach ( $options as $opt ) {
			$sum += (int) ( $opt['score'] ?? 0 );
		}

		return $sum;
	}

	/**
	 * Evaluate whether a conditional question's condition is met by the current answers.
	 *
	 * @param array|null $condition  Resolved condition object from get_questionnaire_structure(), or null.
	 * @param array      $answers    Flat di_qi → value answer map.
	 */
	private static function is_condition_met( ?array $condition, array $answers ): bool {
		if ( $condition === null ) {
			return true;
		}

		$controlling_key = (string) ( $condition['key'] ?? '' );
		$condition_value = (string) ( $condition['value'] ?? '' );
		$condition_op    = (string) ( $condition['op'] ?? 'eq' );
		$controlling_raw = $answers[ $controlling_key ] ?? null;

		if ( $controlling_raw === null ) {
			return false;
		}

		$answer_scalar = (string) $controlling_raw;

		if ( $condition_op === 'contains' || $condition_op === 'not_contains' ) {
			$decoded    = is_string( $controlling_raw ) ? json_decode( $controlling_raw, true ) : null;
			$answer_arr = is_array( $decoded ) ? array_map( 'strval', $decoded ) : [ $answer_scalar ];
			return $condition_op === 'contains'
				? in_array( $condition_value, $answer_arr, true )
				: ! in_array( $condition_value, $answer_arr, true );
		}

		return match ( $condition_op ) {
			'eq'    => $answer_scalar === $condition_value,
			'ne'    => $answer_scalar !== $condition_value,
			default => false,
		};
	}

	private static function resolve_grade( int $pct, array $thresholds ): array {
		// Thresholds are ordered by min_score DESC.
		foreach ( $thresholds as $t ) {
			if ( $pct >= $t['min_score'] ) {
				return $t;
			}
		}

		return end( $thresholds ) ?: [
			'grade_id'    => 'high_risk',
			'grade_label' => 'High Risk',
			'verdict'     => 'Your business is at high risk. Please act on the critical findings immediately.',
			'color'       => '#8a1c22',
			'bg'          => '#fff5f5',
		];
	}

	/**
	 * Build the public grade scale used by frontend result colour rendering.
	 */
	private static function build_grade_scale( array $thresholds ): array {
		return array_map( fn( $t ) => [
			'min_score'   => (int) ( $t['min_score'] ?? 0 ),
			'grade'       => (string) ( $t['grade_id'] ?? '' ),
			'grade_label' => (string) ( $t['grade_label'] ?? '' ),
			'color'       => self::grade_color( $t ),
			'bg'          => self::grade_bg( $t ),
		], $thresholds );
	}

	/**
	 * Resolve a domain percentage against the public grade scale.
	 */
	private static function resolve_grade_from_scale( int $pct, array $grade_scale ): array {
		$scale = array_values( array_filter(
			$grade_scale,
			static fn( $grade ) => is_array( $grade ) && isset( $grade['min_score'] )
		) );

		usort(
			$scale,
			static fn( $a, $b ) => (int) ( $b['min_score'] ?? 0 ) <=> (int) ( $a['min_score'] ?? 0 )
		);

		foreach ( $scale as $grade ) {
			if ( $pct >= (int) $grade['min_score'] ) {
				return [
					'grade'       => (string) ( $grade['grade'] ?? '' ),
					'grade_label' => (string) ( $grade['grade_label'] ?? '' ),
					'color'       => self::grade_color( $grade ),
					'bg'          => self::grade_bg( $grade ),
				];
			}
		}

		return [
			'grade'       => '',
			'grade_label' => '',
			'color'       => '#8a1c22',
			'bg'          => '#fff5f5',
		];
	}

	/**
	 * Read a grade foreground colour from either database-shaped or fixture-shaped arrays.
	 */
	private static function grade_color( array $grade ): string {
		return (string) ( $grade['color'] ?? $grade['color_hex'] ?? '#8a1c22' );
	}

	/**
	 * Read a grade background colour from either database-shaped or fixture-shaped arrays.
	 */
	private static function grade_bg( array $grade ): string {
		return (string) ( $grade['bg'] ?? $grade['bg_hex'] ?? '#fff5f5' );
	}
}
