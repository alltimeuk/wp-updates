<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

class WPQ_Stripe {
	private static ?object $test_checkout_session = null;
	private static ?object $test_webhook_event = null;

	public static function set_test_checkout_session( ?object $session ): void {
		self::$test_checkout_session = $session;
	}

	public static function set_test_webhook_event( ?object $event ): void {
		self::$test_webhook_event = $event;
	}

	public static function has_test_checkout_session(): bool {
		return self::$test_checkout_session !== null;
	}

	public static function has_test_webhook_event(): bool {
		return self::$test_webhook_event !== null;
	}

	public static function can_initialise(): bool {
		if ( ! class_exists( '\Stripe\StripeClient' ) ) {
			return false;
		}

		$secret = WPQ_Secrets::get_stripe_secret_key_details();
		if ( empty( $secret['valid'] ) ) {
			return false;
		}

		try {
			self::get_client();
			return true;
		} catch ( Throwable $e ) {
			return false;
		}
	}

	public static function get_client(): \Stripe\StripeClient {
		$secret = WPQ_Secrets::get_stripe_secret_key_details();
		if ( empty( $secret['valid'] ) ) {
			throw new RuntimeException( 'Stripe secret key is missing or invalid.' );
		}

		return new \Stripe\StripeClient( $secret['value'] );
	}

	public static function create_checkout_session( object $submission, object $product, string $answers_hash, string $success_url, string $cancel_url ): object {
		if ( self::$test_checkout_session ) {
			return self::$test_checkout_session;
		}

		$client = self::get_client();
		return $client->checkout->sessions->create( [
			'mode'        => 'payment',
			'line_items'  => [
				[
					'price'    => (string) $product->stripe_price_id,
					'quantity' => 1,
				],
			],
			'metadata'    => [
				'submission_id'  => (string) $submission->id,
				'product_id'     => (string) $product->id,
				'submission_ref' => (string) $submission->ref,
				'answers_hash'   => $answers_hash,
			],
			'success_url' => $success_url,
			'cancel_url'  => $cancel_url,
		] );
	}

	public static function create_coupon( array $params ): object {
		$client = self::get_client();
		return $client->coupons->create( $params );
	}

	public static function create_promotion_code( string $coupon_id, string $code, ?int $max_redemptions, ?int $expires_at ): object {
		$client = self::get_client();
		$params = [
			'coupon' => $coupon_id,
			'code'   => strtoupper( $code ),
		];
		if ( $max_redemptions !== null ) {
			$params['max_redemptions'] = $max_redemptions;
		}
		if ( $expires_at !== null ) {
			$params['expires_at'] = $expires_at;
		}
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Stripe SDK uses camelCase property names.
		return $client->promotionCodes->create( $params );
	}

	public static function delete_coupon( string $coupon_id ): object {
		$client = self::get_client();
		return $client->coupons->delete( $coupon_id );
	}

	public static function create_product( string $name, string $description ): object {
		$client = self::get_client();
		return $client->products->create( [
			'name'        => $name,
			'description' => $description ?: null,
		] );
	}

	public static function update_product( string $product_id, array $params ): object {
		$client = self::get_client();
		return $client->products->update( $product_id, $params );
	}

	public static function archive_product( string $product_id ): object {
		$client = self::get_client();
		return $client->products->update( $product_id, [ 'active' => false ] );
	}

	public static function create_price( string $product_id, int $amount_pence, string $currency, string $billing_type ): object {
		$client = self::get_client();
		$params = [
			'product'     => $product_id,
			'currency'    => $currency,
			'unit_amount' => $amount_pence,
		];
		if ( $billing_type === 'subscription_monthly' ) {
			$params['recurring'] = [ 'interval' => 'month' ];
		} elseif ( $billing_type === 'subscription_annual' ) {
			$params['recurring'] = [ 'interval' => 'year' ];
		}
		return $client->prices->create( $params );
	}

	public static function archive_price( string $price_id ): object {
		$client = self::get_client();
		return $client->prices->update( $price_id, [ 'active' => false ] );
	}

	public static function construct_webhook_event( string $payload, string $signature ): object {
		if ( self::$test_webhook_event ) {
			return self::$test_webhook_event;
		}

		$secret = WPQ_Secrets::get_stripe_webhook_secret_details();
		if ( empty( $secret['valid'] ) ) {
			throw new RuntimeException( 'Stripe webhook secret is missing or invalid.' );
		}
		if ( ! class_exists( '\Stripe\Webhook' ) ) {
			throw new RuntimeException( 'Stripe webhook library is not available.' );
		}

		return \Stripe\Webhook::constructEvent( $payload, $signature, $secret['value'] );
	}
}
