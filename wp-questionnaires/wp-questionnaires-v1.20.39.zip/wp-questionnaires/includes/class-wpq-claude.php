<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Claude {

	public const PROVIDER_MODE_MESSAGES_API_INTERNAL_SESSION = 'messages_api_internal_session';
	public const STATUS_NOT_STARTED = 'not_started';
	public const STATUS_MANUAL_CONFIGURATION_REQUIRED = 'manual_configuration_required';
	public const STATUS_READY = 'ready';
	public const STATUS_PROCESSING = 'processing';
	public const STATUS_FAILED = 'failed';
	public const REPORT_STATUS_NOT_REQUESTED = 'not_requested';

	public static function display_ref( string $ref ): string {
		return str_replace( '-', '', strtoupper( trim( $ref ) ) );
	}

	public static function project_name_for_questionnaire( object $questionnaire ): string {
		$name = trim( (string) ( $questionnaire->name ?? '' ) );
		if ( '' === $name ) {
			$name = 'Questionnaire';
		}

		return sprintf(
			'%s (%s)',
			$name,
			self::display_ref( (string) ( $questionnaire->ref ?? '' ) )
		);
	}

	public static function conversation_title_for_submission( object $submission ): string {
		$company = trim( sanitize_text_field( (string) ( $submission->contact_company ?? '' ) ) );
		$contact = trim( sanitize_text_field( (string) ( $submission->contact_name ?? '' ) ) );
		$id      = (int) ( $submission->id ?? 0 );

		if ( '' !== $company && '' !== $contact ) {
			return "{$company} - {$contact}";
		}
		if ( '' !== $contact ) {
			return $contact;
		}
		if ( '' !== $company ) {
			return "{$company} - Submission {$id}";
		}

		return "Submission {$id}";
	}

	public static function provision_project_for_questionnaire( int $questionnaire_id ): bool {
		$questionnaire = WPQ_Database::get_questionnaire( $questionnaire_id );
		if ( ! $questionnaire ) {
			return false;
		}

		$project_name = self::project_name_for_questionnaire( $questionnaire );
		$project_id   = trim( sanitize_text_field( (string) ( $questionnaire->claude_project_id ?? '' ) ) );
		$now          = current_time( 'mysql', true );

		$data = [
			'claude_project_name'        => $project_name,
			'claude_project_verified_at' => $now,
			'claude_project_last_error'  => null,
		];

		if ( '' === $project_id ) {
			$data['claude_project_status']      = self::STATUS_MANUAL_CONFIGURATION_REQUIRED;
			$data['claude_project_last_error']  = 'Anthropic API project creation is not available through the supported public API; enter an existing project identifier manually if needed.';
			$data['claude_project_verified_at'] = null;
		} else {
			$data['claude_project_id']     = $project_id;
			$data['claude_project_status'] = 'configured';
		}

		return WPQ_Database::update_questionnaire( $questionnaire_id, $data );
	}

	public static function initialise_submission_session( int $submission_id ): bool {
		return WPQ_Database::initialise_claude_conversation( $submission_id );
	}
}
