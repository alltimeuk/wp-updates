<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Converts DOCX to PDF using a local headless LibreOffice/soffice binary.
 *
 * Commands are executed via proc_open() with an argv array, never a shell
 * string, so no argument is ever interpreted by a shell and no escaping is
 * required to stay safe against command injection.
 */
class WPQ_LibreOffice_Pdf_Converter implements WPQ_Docx_Pdf_Converter_Interface {

	private const DEFAULT_TIMEOUT = 60;
	private const CANDIDATE_EXECUTABLES = [
		'/usr/bin/soffice',
		'/usr/bin/libreoffice',
		'/opt/libreoffice/program/soffice',
		'/Applications/LibreOffice.app/Contents/MacOS/soffice',
		'C:\\Program Files\\LibreOffice\\program\\soffice.exe',
	];

	private ?string $last_safe_error = null;

	public static function configured_executable(): string {
		return trim( (string) get_option( 'wpq_docx_pdf_converter_path', '' ) );
	}

	public static function timeout_seconds(): int {
		$timeout = (int) get_option( 'wpq_docx_pdf_converter_timeout', self::DEFAULT_TIMEOUT );
		return $timeout > 0 ? $timeout : self::DEFAULT_TIMEOUT;
	}

	public static function detect_executable(): string {
		$configured = self::configured_executable();
		if ( '' !== $configured && is_file( $configured ) && is_executable( $configured ) ) {
			return $configured;
		}

		foreach ( self::CANDIDATE_EXECUTABLES as $candidate ) {
			if ( is_file( $candidate ) && is_executable( $candidate ) ) {
				return $candidate;
			}
		}

		return '';
	}

	public function is_available(): bool {
		return self::detect_executable() !== '';
	}

	public function diagnostics(): array {
		$executable = self::detect_executable();
		$temp_dir   = sys_get_temp_dir();

		return [
			'configured_executable' => self::configured_executable(),
			'detected_executable'   => $executable,
			'available'             => $executable !== '',
			'temp_writable'         => $temp_dir !== '' && is_writable( $temp_dir ),
			'timeout_seconds'       => self::timeout_seconds(),
			'last_safe_error'       => $this->last_safe_error,
		];
	}

	public function convert( string $docx_path, string $output_directory ): string {
		$this->last_safe_error = null;

		if ( ! is_readable( $docx_path ) ) {
			$this->last_safe_error = 'Source DOCX is not readable.';
			throw new RuntimeException( 'Source DOCX is not readable.' );
		}

		$executable = self::detect_executable();
		if ( '' === $executable ) {
			$this->last_safe_error = 'No LibreOffice/soffice executable is configured or detected.';
			throw new RuntimeException( 'No LibreOffice/soffice executable is configured or detected.' );
		}

		if ( ! is_dir( $output_directory ) || ! is_writable( $output_directory ) ) {
			$this->last_safe_error = 'PDF output directory is not writable.';
			throw new RuntimeException( 'PDF output directory is not writable.' );
		}

		$profile_dir = rtrim( sys_get_temp_dir(), DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'wpq-lo-' . wp_generate_password( 12, false, false );
		if ( ! wp_mkdir_p( $profile_dir ) ) {
			$this->last_safe_error = 'Could not create an isolated conversion profile directory.';
			throw new RuntimeException( 'Could not create an isolated conversion profile directory.' );
		}

		$command = [
			$executable,
			'--headless',
			'--norestore',
			'--nolockcheck',
			'-env:UserInstallation=' . self::path_to_uri( $profile_dir ),
			'--convert-to',
			'pdf',
			'--outdir',
			$output_directory,
			$docx_path,
		];

		$descriptors = [
			0 => [ 'pipe', 'r' ],
			1 => [ 'pipe', 'w' ],
			2 => [ 'pipe', 'w' ],
		];

		$process = @proc_open( $command, $descriptors, $pipes, $output_directory );
		if ( ! is_resource( $process ) ) {
			$this->remove_directory( $profile_dir );
			$this->last_safe_error = 'Could not start the PDF converter process.';
			throw new RuntimeException( 'Could not start the PDF converter process.' );
		}

		fclose( $pipes[0] );
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );

		$timeout      = self::timeout_seconds();
		$started      = microtime( true );
		$stdout       = '';
		$stderr       = '';
		$timed_out    = false;

		do {
			$stdout .= (string) stream_get_contents( $pipes[1] );
			$stderr .= (string) stream_get_contents( $pipes[2] );

			$status = proc_get_status( $process );
			if ( ! $status['running'] ) {
				break;
			}

			if ( ( microtime( true ) - $started ) > $timeout ) {
				$timed_out = true;
				proc_terminate( $process, 9 );
				break;
			}

			usleep( 100000 );
		} while ( true );

		$stdout .= (string) stream_get_contents( $pipes[1] );
		$stderr .= (string) stream_get_contents( $pipes[2] );
		fclose( $pipes[1] );
		fclose( $pipes[2] );
		$exit_code = proc_close( $process );
		$this->remove_directory( $profile_dir );

		if ( $timed_out ) {
			$this->last_safe_error = sprintf( 'PDF conversion timed out after %d seconds.', $timeout );
			throw new RuntimeException( 'PDF conversion timed out.' );
		}

		if ( 0 !== $exit_code ) {
			$this->last_safe_error = sprintf( 'PDF converter exited with status %d.', $exit_code );
			throw new RuntimeException( 'PDF converter exited with a non-zero status.' );
		}

		$expected_name = pathinfo( $docx_path, PATHINFO_FILENAME ) . '.pdf';
		$output_path   = rtrim( $output_directory, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . $expected_name;

		if ( ! is_file( $output_path ) || ! is_readable( $output_path ) ) {
			$this->last_safe_error = 'PDF converter did not produce the expected output file.';
			throw new RuntimeException( 'PDF converter did not produce the expected output file.' );
		}

		$signature = @file_get_contents( $output_path, false, null, 0, 5 );
		if ( ! is_string( $signature ) || ! str_starts_with( $signature, '%PDF-' ) ) {
			wp_delete_file( $output_path );
			$this->last_safe_error = 'PDF converter output failed signature validation.';
			throw new RuntimeException( 'PDF converter output failed signature validation.' );
		}

		unset( $stdout, $stderr );

		return $output_path;
	}

	private static function path_to_uri( string $path ): string {
		$normalised = str_replace( '\\', '/', $path );
		if ( preg_match( '/^[A-Za-z]:\//', $normalised ) ) {
			return 'file:///' . $normalised;
		}
		return 'file://' . $normalised;
	}

	private function remove_directory( string $directory ): void {
		if ( ! is_dir( $directory ) ) {
			return;
		}

		$items = @scandir( $directory );
		if ( ! is_array( $items ) ) {
			return;
		}

		foreach ( $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}
			$path = $directory . DIRECTORY_SEPARATOR . $item;
			if ( is_dir( $path ) ) {
				$this->remove_directory( $path );
			} else {
				wp_delete_file( $path );
			}
		}

		@rmdir( $directory );
	}
}
