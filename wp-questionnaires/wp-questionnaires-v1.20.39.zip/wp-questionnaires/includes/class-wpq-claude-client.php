<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPQ_Claude_Client {
	public const CAPABILITY_MESSAGES = 'messages';
	public const CAPABILITY_MODELS = 'models';
	public const CAPABILITY_FILES = 'files_beta';
	public const CAPABILITY_CLAUDE_AI_PROJECTS = 'claude_ai_projects';
	public const CAPABILITY_CLAUDE_AI_CHATS = 'claude_ai_chats';

	public static function can_initialise(): bool {
		return class_exists( 'WPQ_Remediation_Plan' )
			&& ! empty( WPQ_Remediation_Plan::get_api_key_details()['valid'] );
	}

	/**
	 * Returns the supported Anthropic API surface this plugin can rely on.
	 *
	 * Claude.ai Project and web-chat lifecycle operations are intentionally false:
	 * the supported public API exposes Messages, Models, beta Files, and managed
	 * agent/session primitives, but not Claude.ai web application project/chat
	 * creation or visible chat-title management.
	 *
	 * @return array<string, bool>
	 */
	public static function documented_capabilities(): array {
		return [
			self::CAPABILITY_MESSAGES           => true,
			self::CAPABILITY_MODELS             => true,
			self::CAPABILITY_FILES              => true,
			self::CAPABILITY_CLAUDE_AI_PROJECTS => false,
			self::CAPABILITY_CLAUDE_AI_CHATS    => false,
		];
	}

	public static function supports_claude_ai_project_lifecycle(): bool {
		return false;
	}

	public static function supports_claude_ai_chat_lifecycle(): bool {
		return false;
	}

	public static function selected_model(): string {
		$details = class_exists( 'WPQ_Remediation_Plan' ) ? WPQ_Remediation_Plan::get_api_key_details() : [];
		$key     = (string) ( $details['value'] ?? '' );
		if ( '' === $key || ! class_exists( 'WPQ_Remediation_Plan' ) ) {
			return '';
		}

		return WPQ_Remediation_Plan::select_model( $key );
	}
}
