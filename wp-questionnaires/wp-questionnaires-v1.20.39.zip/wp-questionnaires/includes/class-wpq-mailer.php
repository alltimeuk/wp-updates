<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Outbound email for the plugin, behind a single switchboard.
 *
 * Every customer-facing email the plugin sends (report delivery links, resume
 * links, enquiry notifications and acknowledgements) goes through
 * WPQ_Mailer::send(), which applies:
 *
 *  1. the global kill switch (Settings → Email Delivery), and
 *  2. the active provider preference - WordPress's own wp_mail(), the Gmail
 *     API (OAuth2 refresh-token flow against Google Cloud), or AWS SES v2
 *     (SigV4-signed, no AWS SDK required).
 *
 * Per-questionnaire and per-enquiry-form gating happens in the callers via
 * allowed_for_questionnaire() / the enquiry form's own mail setting; this
 * class only knows about the global switch and transports.
 *
 * Provider credentials resolve constant → environment → option, matching
 * WPQ_Secrets' convention, so production secrets can live outside the
 * database.
 */
class WPQ_Mailer {

	public const PROVIDER_WP_MAIL = 'wp_mail';
	public const PROVIDER_GMAIL   = 'gmail';
	public const PROVIDER_SES     = 'ses';

	public const PROVIDERS = [ self::PROVIDER_WP_MAIL, self::PROVIDER_GMAIL, self::PROVIDER_SES ];

	private const OPTION_ENABLED  = 'wpq_mail_enabled';
	private const OPTION_PROVIDER = 'wpq_mail_provider';

	private const GMAIL_TOKEN_URL     = 'https://oauth2.googleapis.com/token';
	private const GMAIL_SEND_URL      = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send';
	private const GMAIL_TOKEN_CACHE   = 'wpq_gmail_access_token';
	private const REQUEST_TIMEOUT     = 30;

	private const LAST_ERROR_OPTION = 'wpq_mail_last_error';

	// ------------------------------------------------------------------ //
	// Configuration
	// ------------------------------------------------------------------ //

	/** The global kill switch. Default on: wp_mail behaviour is unchanged until an admin intervenes. */
	public static function globally_enabled(): bool {
		return get_option( self::OPTION_ENABLED, 'enabled' ) !== 'disabled';
	}

	public static function active_provider(): string {
		$provider = (string) get_option( self::OPTION_PROVIDER, self::PROVIDER_WP_MAIL );
		return in_array( $provider, self::PROVIDERS, true ) ? $provider : self::PROVIDER_WP_MAIL;
	}

	/**
	 * Whether outbound mail is allowed for a questionnaire: the global switch
	 * combined with the questionnaire's own inherit/enabled/disabled setting.
	 */
	public static function allowed_for_questionnaire( ?object $questionnaire ): bool {
		if ( ! self::globally_enabled() ) {
			return false;
		}
		$setting = (string) ( $questionnaire->mail_enabled ?? 'inherit' );
		if ( 'disabled' === $setting ) {
			return false;
		}
		return true; // 'inherit' and 'enabled' both follow the (enabled) global switch.
	}

	/**
	 * @return array{value: string, source: string}
	 */
	public static function get_setting_details( string $option, string $constant, string $environment_key ): array {
		if ( defined( $constant ) && constant( $constant ) ) {
			return [ 'value' => (string) constant( $constant ), 'source' => 'constant' ];
		}
		$environment_value = getenv( $environment_key );
		if ( is_string( $environment_value ) && '' !== $environment_value ) {
			return [ 'value' => $environment_value, 'source' => 'environment' ];
		}
		$option_value = (string) get_option( $option, '' );
		return [ 'value' => $option_value, 'source' => '' !== $option_value ? 'option' : 'none' ];
	}

	/** @return array<string, array{value: string, source: string}> */
	public static function gmail_settings(): array {
		return [
			'client_id'     => self::get_setting_details( 'wpq_gmail_client_id', 'WPQ_GMAIL_CLIENT_ID', 'WPQ_GMAIL_CLIENT_ID' ),
			'client_secret' => self::get_setting_details( 'wpq_gmail_client_secret', 'WPQ_GMAIL_CLIENT_SECRET', 'WPQ_GMAIL_CLIENT_SECRET' ),
			'refresh_token' => self::get_setting_details( 'wpq_gmail_refresh_token', 'WPQ_GMAIL_REFRESH_TOKEN', 'WPQ_GMAIL_REFRESH_TOKEN' ),
			'sender'        => self::get_setting_details( 'wpq_gmail_sender', 'WPQ_GMAIL_SENDER', 'WPQ_GMAIL_SENDER' ),
		];
	}

	/** @return array<string, array{value: string, source: string}> */
	public static function ses_settings(): array {
		return [
			'access_key' => self::get_setting_details( 'wpq_ses_access_key', 'WPQ_SES_ACCESS_KEY', 'WPQ_SES_ACCESS_KEY' ),
			'secret_key' => self::get_setting_details( 'wpq_ses_secret_key', 'WPQ_SES_SECRET_KEY', 'WPQ_SES_SECRET_KEY' ),
			'region'     => self::get_setting_details( 'wpq_ses_region', 'WPQ_SES_REGION', 'WPQ_SES_REGION' ),
			'from'       => self::get_setting_details( 'wpq_ses_from', 'WPQ_SES_FROM', 'WPQ_SES_FROM' ),
		];
	}

	/**
	 * Configuration state per provider, for the settings/readiness UI.
	 *
	 * @return array{enabled: bool, provider: string, provider_ready: bool, missing: array<int, string>, last_error: string}
	 */
	public static function diagnostics(): array {
		$provider = self::active_provider();
		$missing  = [];

		if ( self::PROVIDER_GMAIL === $provider ) {
			foreach ( self::gmail_settings() as $key => $details ) {
				if ( '' === $details['value'] ) {
					$missing[] = $key;
				}
			}
		} elseif ( self::PROVIDER_SES === $provider ) {
			foreach ( self::ses_settings() as $key => $details ) {
				if ( '' === $details['value'] ) {
					$missing[] = $key;
				}
			}
		}

		return [
			'enabled'        => self::globally_enabled(),
			'provider'       => $provider,
			'provider_ready' => empty( $missing ),
			'missing'        => $missing,
			'last_error'     => (string) get_option( self::LAST_ERROR_OPTION, '' ),
		];
	}

	// ------------------------------------------------------------------ //
	// Sending
	// ------------------------------------------------------------------ //

	/**
	 * Send a plain-text email through the active provider. Returns false when
	 * mail delivery is globally disabled or the transport fails; the transport
	 * failure reason is retrievable via diagnostics() for the settings screen.
	 */
	public static function send( string $to, string $subject, string $body ): bool {
		$to = sanitize_email( $to );
		if ( '' === $to || ! is_email( $to ) ) {
			return false;
		}
		if ( ! self::globally_enabled() ) {
			return false;
		}

		try {
			switch ( self::active_provider() ) {
				case self::PROVIDER_GMAIL:
					self::send_via_gmail( $to, $subject, $body );
					break;
				case self::PROVIDER_SES:
					self::send_via_ses( $to, $subject, $body );
					break;
				default:
					if ( ! wp_mail( $to, $subject, $body, [ 'Content-Type: text/plain; charset=UTF-8' ] ) ) {
						throw new RuntimeException( 'wp_mail() reported failure - check the site\'s PHP mail configuration.' );
					}
			}
		} catch ( Throwable $e ) {
			update_option( self::LAST_ERROR_OPTION, sanitize_text_field(
				gmdate( 'Y-m-d H:i:s' ) . ' UTC [' . self::active_provider() . '] ' . $e->getMessage()
			), false );
			return false;
		}

		update_option( self::LAST_ERROR_OPTION, '', false );
		return true;
	}

	// ------------------------------------------------------------------ //
	// Gmail API (Google Cloud)
	// ------------------------------------------------------------------ //

	private static function send_via_gmail( string $to, string $subject, string $body ): void {
		$settings = self::gmail_settings();
		foreach ( [ 'client_id', 'client_secret', 'refresh_token', 'sender' ] as $required ) {
			if ( '' === $settings[ $required ]['value'] ) {
				throw new RuntimeException( 'Gmail is not fully configured (missing ' . esc_html( $required ) . ').' );
			}
		}

		$access_token = self::gmail_access_token( $settings );
		$mime         = self::build_mime_message( $settings['sender']['value'], $to, $subject, $body );

		$response = wp_remote_post( self::GMAIL_SEND_URL, [
			'timeout' => self::REQUEST_TIMEOUT,
			'headers' => [
				'authorization' => 'Bearer ' . $access_token,
				'content-type'  => 'application/json',
			],
			'body'    => wp_json_encode( [ 'raw' => self::base64url( $mime ) ] ),
		] );

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'Gmail request failed: ' . esc_html( $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( 'Gmail API returned HTTP ' . esc_html( (string) $code ) . ': ' . esc_html( self::api_error_excerpt( wp_remote_retrieve_body( $response ) ) ) );
		}
	}

	/**
	 * Exchange the stored refresh token for a short-lived access token, cached
	 * in a transient until shortly before expiry.
	 *
	 * @param array<string, array{value: string, source: string}> $settings
	 */
	private static function gmail_access_token( array $settings ): string {
		$cached = get_transient( self::GMAIL_TOKEN_CACHE );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$response = wp_remote_post( self::GMAIL_TOKEN_URL, [
			'timeout' => self::REQUEST_TIMEOUT,
			'body'    => [
				'grant_type'    => 'refresh_token',
				'client_id'     => $settings['client_id']['value'],
				'client_secret' => $settings['client_secret']['value'],
				'refresh_token' => $settings['refresh_token']['value'],
			],
		] );

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'Google token request failed: ' . esc_html( $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $data ) || empty( $data['access_token'] ) ) {
			throw new RuntimeException( 'Google token exchange returned HTTP ' . esc_html( (string) $code ) . ': ' . esc_html( self::api_error_excerpt( wp_remote_retrieve_body( $response ) ) ) );
		}

		$token   = (string) $data['access_token'];
		$expires = max( 60, (int) ( $data['expires_in'] ?? 3600 ) - 120 );
		set_transient( self::GMAIL_TOKEN_CACHE, $token, $expires );

		return $token;
	}

	/**
	 * A minimal RFC 5322 plain-text message. Subject is RFC 2047 encoded so
	 * non-ASCII survives; header injection is impossible because every header
	 * value is either sanitised email or encoded.
	 */
	public static function build_mime_message( string $from, string $to, string $subject, string $body ): string {
		$eol = "\r\n";
		return 'From: ' . sanitize_email( $from ) . $eol
			. 'To: ' . sanitize_email( $to ) . $eol
			. 'Subject: =?UTF-8?B?' . base64_encode( str_replace( [ "\r", "\n" ], ' ', $subject ) ) . '?=' . $eol
			. 'MIME-Version: 1.0' . $eol
			. 'Content-Type: text/plain; charset=UTF-8' . $eol
			. 'Content-Transfer-Encoding: base64' . $eol
			. $eol
			. chunk_split( base64_encode( $body ), 76, $eol );
	}

	public static function base64url( string $data ): string {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}

	// ------------------------------------------------------------------ //
	// AWS SES v2
	// ------------------------------------------------------------------ //

	private static function send_via_ses( string $to, string $subject, string $body ): void {
		$settings = self::ses_settings();
		foreach ( [ 'access_key', 'secret_key', 'region', 'from' ] as $required ) {
			if ( '' === $settings[ $required ]['value'] ) {
				throw new RuntimeException( 'AWS SES is not fully configured (missing ' . esc_html( $required ) . ').' );
			}
		}

		$region  = sanitize_key( $settings['region']['value'] );
		$host    = 'email.' . $region . '.amazonaws.com';
		$path    = '/v2/email/outbound-emails';
		$payload = wp_json_encode( [
			'FromEmailAddress' => $settings['from']['value'],
			'Destination'      => [ 'ToAddresses' => [ $to ] ],
			'Content'          => [
				'Simple' => [
					'Subject' => [ 'Data' => $subject, 'Charset' => 'UTF-8' ],
					'Body'    => [ 'Text' => [ 'Data' => $body, 'Charset' => 'UTF-8' ] ],
				],
			],
		] );
		if ( ! is_string( $payload ) ) {
			throw new RuntimeException( 'SES payload could not be encoded.' );
		}

		$amz_date = gmdate( 'Ymd\THis\Z' );
		$headers  = self::sign_aws_request(
			'POST',
			$host,
			$path,
			$payload,
			$amz_date,
			$region,
			$settings['access_key']['value'],
			$settings['secret_key']['value']
		);

		$response = wp_remote_post( 'https://' . $host . $path, [
			'timeout' => self::REQUEST_TIMEOUT,
			'headers' => $headers,
			'body'    => $payload,
		] );

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'SES request failed: ' . esc_html( $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( 'SES returned HTTP ' . esc_html( (string) $code ) . ': ' . esc_html( self::api_error_excerpt( wp_remote_retrieve_body( $response ) ) ) );
		}
	}

	/**
	 * AWS Signature Version 4 for a JSON POST - the full canonical-request /
	 * string-to-sign / HMAC-chain derivation, so no AWS SDK is needed.
	 *
	 * @return array<string, string> Request headers including Authorization.
	 */
	public static function sign_aws_request( string $method, string $host, string $path, string $payload, string $amz_date, string $region, string $access_key, string $secret_key, string $service = 'ses' ): array {
		$date_stamp   = substr( $amz_date, 0, 8 );
		$content_type = 'application/json';

		$canonical_headers = 'content-type:' . $content_type . "\n"
			. 'host:' . $host . "\n"
			. 'x-amz-date:' . $amz_date . "\n";
		$signed_headers    = 'content-type;host;x-amz-date';
		$payload_hash      = hash( 'sha256', $payload );

		$canonical_request = implode( "\n", [ $method, $path, '', $canonical_headers, $signed_headers, $payload_hash ] );

		$credential_scope = $date_stamp . '/' . $region . '/' . $service . '/aws4_request';
		$string_to_sign   = implode( "\n", [
			'AWS4-HMAC-SHA256',
			$amz_date,
			$credential_scope,
			hash( 'sha256', $canonical_request ),
		] );

		$k_date    = hash_hmac( 'sha256', $date_stamp, 'AWS4' . $secret_key, true );
		$k_region  = hash_hmac( 'sha256', $region, $k_date, true );
		$k_service = hash_hmac( 'sha256', $service, $k_region, true );
		$k_signing = hash_hmac( 'sha256', 'aws4_request', $k_service, true );
		$signature = hash_hmac( 'sha256', $string_to_sign, $k_signing );

		return [
			'content-type'  => $content_type,
			'x-amz-date'    => $amz_date,
			'authorization' => 'AWS4-HMAC-SHA256 Credential=' . $access_key . '/' . $credential_scope
				. ', SignedHeaders=' . $signed_headers
				. ', Signature=' . $signature,
		];
	}

	private static function api_error_excerpt( string $body ): string {
		$decoded = json_decode( $body, true );
		if ( is_array( $decoded ) ) {
			$message = $decoded['error']['message'] ?? $decoded['message'] ?? $decoded['Message'] ?? '';
			if ( is_string( $message ) && '' !== $message ) {
				return sanitize_text_field( mb_substr( $message, 0, 300 ) );
			}
		}
		return sanitize_text_field( mb_substr( $body, 0, 200 ) );
	}
}
