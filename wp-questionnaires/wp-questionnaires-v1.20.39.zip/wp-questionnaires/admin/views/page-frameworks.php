<?php if ( ! defined( 'ABSPATH' ) ) exit;
/** @var array<int, object> $frameworks - output of WPQ_Database::get_frameworks_with_counts() */
$frameworks = $frameworks ?? [];

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Feedback query args are display-only; every mutating action below carries its own nonce.
$imported       = isset( $_GET['wpq_imported'] ) ? (int) $_GET['wpq_imported'] : null;
$import_failed  = isset( $_GET['wpq_import_failed'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_import_failed'] ) ) : '';
$registered     = isset( $_GET['wpq_registered'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_registered'] ) ) : '';
$register_error = isset( $_GET['wpq_register_error'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_register_error'] ) ) : '';
$deleted        = isset( $_GET['wpq_deleted'] ) ? sanitize_key( wp_unslash( (string) $_GET['wpq_deleted'] ) ) : '';
$renamed        = isset( $_GET['wpq_renamed'] ) ? sanitize_key( wp_unslash( (string) $_GET['wpq_renamed'] ) ) : '';
$rename_error   = isset( $_GET['wpq_rename_error'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wpq_rename_error'] ) ) : '';
$import_error   = isset( $_GET['wpq_import_error'] ) ? sanitize_key( (string) $_GET['wpq_import_error'] ) : '';
// phpcs:enable WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap">
<h1>Frameworks &amp; Standards</h1>
<p style="color:#666;max-width:60em">
	Each framework below is imported from an ATLAS <code>.skill</code> bundle: the bundle registers the
	framework, its control catalogue is parsed into the database, and the same bundle can then be
	registered with the Anthropic Skills API for use in Report readiness analysis -
	so the catalogue shown here and the skill Claude analyses with always come from one artefact.
</p>

<?php if ( null !== $imported ) : ?>
	<div class="notice notice-<?php echo '' === $import_failed ? 'success' : 'warning'; ?> is-dismissible">
		<p>
			Imported <?php echo (int) $imported; ?> skill bundle(s).
			<?php if ( '' !== $import_failed ) : ?>
				Failed: <?php echo esc_html( $import_failed ); ?>
			<?php endif; ?>
		</p>
	</div>
<?php endif; ?>
<?php if ( 'no_files' === $import_error ) : ?>
	<div class="notice notice-error is-dismissible"><p>No .skill files were selected.</p></div>
<?php endif; ?>
<?php if ( '' !== $registered ) : ?>
	<div class="notice notice-success is-dismissible"><p>Registered with the Anthropic Skills API as <code><?php echo esc_html( $registered ); ?></code>.</p></div>
<?php endif; ?>
<?php if ( '' !== $register_error ) : ?>
	<div class="notice notice-error is-dismissible"><p>Skills API registration failed: <?php echo esc_html( $register_error ); ?></p></div>
<?php endif; ?>
<?php if ( '1' === $deleted ) : ?>
	<div class="notice notice-success is-dismissible"><p>Framework deleted.</p></div>
<?php endif; ?>
<?php if ( '1' === $renamed ) : ?>
	<div class="notice notice-success is-dismissible"><p>Framework renamed. Push a new version to update the registered Anthropic skill's title.</p></div>
<?php endif; ?>
<?php if ( '' !== $rename_error ) : ?>
	<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $rename_error ); ?></p></div>
<?php endif; ?>

<h2>Import ATLAS skill bundles</h2>
<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="margin-bottom:24px">
	<?php wp_nonce_field( 'wpq_import_atlas_skills' ); ?>
	<input type="hidden" name="action" value="wpq_import_atlas_skills">
	<input type="file" name="wpq_skill_files[]" multiple accept=".skill,.zip" required>
	<button type="submit" class="button button-primary">Import bundles</button>
	<p class="description" style="max-width:60em">
		Select one or more <code>.skill</code> files (multiple files can be imported in one go).
		Re-importing a bundle refreshes the framework and replaces its control catalogue. Some
		frameworks (process frameworks such as ITIL and COBIT, and guides such as FedRAMP) carry no
		control tables in their bundle - they import with zero controls and remain fully usable for
		readiness analysis.
	</p>
</form>

<h2>Imported frameworks (<?php echo count( $frameworks ); ?>)</h2>
<?php if ( empty( $frameworks ) ) : ?>
	<p>No frameworks imported yet.</p>
<?php else : ?>
<table class="widefat striped">
	<thead>
		<tr>
			<th>Framework</th>
			<th>Slug</th>
			<th>Version</th>
			<th>Controls</th>
			<th>Anthropic skill</th>
			<th>Imported</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ( $frameworks as $framework ) : ?>
		<tr>
			<td>
				<strong><?php echo esc_html( (string) $framework->name ); ?></strong>
				<?php if ( '' !== (string) ( $framework->description ?? '' ) ) : ?>
					<br><span style="color:#666"><?php echo esc_html( mb_substr( (string) $framework->description, 0, 140 ) ); ?></span>
				<?php endif; ?>
				<details style="margin-top:4px;">
					<summary style="cursor:pointer;color:#2271b1;font-size:12px;">Edit name</summary>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:6px;">
						<?php wp_nonce_field( 'wpq_rename_framework' ); ?>
						<input type="hidden" name="action" value="wpq_rename_framework">
						<input type="hidden" name="framework_id" value="<?php echo (int) $framework->id; ?>">
						<input type="text" name="framework_name" maxlength="191" style="width:100%;max-width:420px;"
							value="<?php echo esc_attr( (string) $framework->name ); ?>">
						<button type="submit" class="button button-small">Save name</button>
						<?php if ( class_exists( 'WPQ_Framework_Importer' ) && mb_strlen( (string) $framework->name ) > WPQ_Framework_Importer::MAX_DISPLAY_TITLE_CHARS ) : ?>
							<p class="description" style="margin:4px 0 0;">Longer than the Skills API's
								<?php echo (int) WPQ_Framework_Importer::MAX_DISPLAY_TITLE_CHARS; ?>-character title limit -
								registers as &ldquo;<?php echo esc_html( WPQ_Framework_Importer::skill_display_title( (string) $framework->name ) ); ?>&rdquo;.</p>
						<?php endif; ?>
					</form>
				</details>
			</td>
			<td><code><?php echo esc_html( (string) $framework->slug ); ?></code></td>
			<td><?php echo esc_html( (string) ( $framework->version ?: '-' ) ); ?></td>
			<td><?php echo (int) ( $framework->control_count ?? 0 ); ?></td>
			<td>
				<?php if ( '' !== (string) ( $framework->skill_id ?? '' ) ) : ?>
					<code><?php echo esc_html( (string) $framework->skill_id ); ?></code>
					<?php if ( '' !== (string) ( $framework->skill_version ?? '' ) ) : ?>
						<br><span style="color:#666">v<?php echo esc_html( (string) $framework->skill_version ); ?></span>
					<?php endif; ?>
				<?php else : ?>
					<span style="color:#666">Not registered</span>
				<?php endif; ?>
			</td>
			<td><?php echo esc_html( (string) ( $framework->skill_imported_at ?: '-' ) ); ?></td>
			<td>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
					<?php wp_nonce_field( 'wpq_register_framework_skill' ); ?>
					<input type="hidden" name="action" value="wpq_register_framework_skill">
					<input type="hidden" name="framework_id" value="<?php echo (int) $framework->id; ?>">
					<button type="submit" class="button button-small">
						<?php echo '' !== (string) ( $framework->skill_id ?? '' ) ? 'Push new version' : 'Register with Anthropic'; ?>
					</button>
				</form>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"
					onsubmit="return confirm('Delete this framework and its control catalogue?');">
					<?php wp_nonce_field( 'wpq_delete_framework' ); ?>
					<input type="hidden" name="action" value="wpq_delete_framework">
					<input type="hidden" name="framework_id" value="<?php echo (int) $framework->id; ?>">
					<button type="submit" class="button button-small button-link-delete">Delete</button>
				</form>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
<?php endif; ?>
</div>
