<?php
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) exit;

$nonce = wp_create_nonce( 'wpq_import_export' );
?>
<div class="wrap">
	<h1>Import / Export</h1>

	<!-- ========== EXPORT ========== -->
	<div class="wpq-card" style="max-width:860px;margin-top:20px;">
		<h2 style="margin-top:0;">Export</h2>
		<p>Download data from this site as a JSON file you can import elsewhere.</p>

		<?php
		$export_groups = [
			'questionnaires' => 'Questionnaires (full structure: domains, questions, options, grade thresholds)',
			'contacts'       => 'Contacts & Submissions',
			'enquiries'      => 'Enquiries (forms, field definitions and received enquiries)',
			'orders'         => 'Orders',
			'pricing'        => 'Pricing',
			'coupons'        => 'Coupons',
			'ctas'           => 'Call to Action',
			'settings'       => 'Settings',
		];
		foreach ( $export_groups as $type => $label ) :
			$url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wpq_export&type=' . rawurlencode( $type ) ),
				'wpq_export_' . $type,
				'_wpnonce'
			);
		?>
		<div style="display:flex;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid #eee;">
			<span style="flex:1;"><?php echo esc_html( $label ); ?></span>
			<a href="<?php echo esc_url( $url ); ?>" class="button"
				style="white-space:nowrap;">&#8595; Download JSON</a>
		</div>
		<?php endforeach; ?>
	</div>

	<!-- ========== IMPORT ========== -->
	<div class="wpq-card" style="max-width:860px;margin-top:24px;">
		<h2 style="margin-top:0;">Import</h2>
		<p>Drop one or more JSON files exported from this plugin. Multiple files are processed together - resolve conflicts once, then import all in one click.</p>

		<div id="wpq-import-dropzone">
			<p style="margin:0 0 6px;font-size:1.05em;">Drop JSON file(s) here, or click to browse</p>
			<p style="margin:0 0 12px;font-size:.85em;color:#666;">Multiple files supported - hold Ctrl / ⌘ to select more than one</p>
			<input type="file" id="wpq-import-file" accept=".json,application/json" multiple style="display:none;">
			<button type="button" class="button" id="wpq-import-browse">Choose file(s)&hellip;</button>
		</div>

		<div id="wpq-import-workspace" style="display:none;margin-top:20px;"></div>
	</div>
</div>

<style>
/* ---- Drop zone ---- */
#wpq-import-dropzone {
	border: 2px dashed #c3c4c7;
	border-radius: 4px;
	padding: 28px 32px;
	text-align: center;
	cursor: pointer;
	background: #fafafa;
	transition: background .15s, border-color .15s;
}
#wpq-import-dropzone.wpq-drag-over { background: #e8f0fe; border-color: #4285f4; }

/* ---- Set-all bar ---- */
.wpq-setall-bar {
	display: flex;
	align-items: center;
	gap: 10px;
	background: #f0f4ff;
	border: 1px solid #c3cde8;
	border-radius: 4px;
	padding: 8px 12px;
	margin-bottom: 16px;
	font-size: .9em;
}
.wpq-setall-bar select { padding: 2px 6px; }

/* ---- Per-file sections ---- */
.wpq-file-section {
	border: 1px solid #ddd;
	border-radius: 4px;
	margin-bottom: 12px;
	overflow: hidden;
}
.wpq-file-header {
	display: flex;
	align-items: center;
	gap: 10px;
	padding: 9px 14px;
	background: #f6f7f7;
	border-bottom: 1px solid #ddd;
	font-size: .9em;
}
.wpq-file-header strong { font-size: 1em; }
.wpq-file-meta { color: #666; }
.wpq-file-badge {
	margin-left: auto;
	font-size: .85em;
}
.wpq-file-body { padding: 12px 14px; }

/* ---- Conflict table ---- */
.wpq-conflict-table { width: 100%; border-collapse: collapse; margin: 6px 0 10px; }
.wpq-conflict-table th,
.wpq-conflict-table td { padding: 6px 10px; border: 1px solid #ddd; font-size: .88em; }
.wpq-conflict-table th { background: #f6f7f7; }
.wpq-conflict-resolution select { width: 100%; }

/* ---- Status indicators ---- */
.wpq-status-ok   { color: #1a5e35; font-weight: 600; }
.wpq-status-err  { color: #c0392b; font-weight: 600; }
.wpq-status-spin { color: #555; font-style: italic; }

/* ---- Import actions bar ---- */
.wpq-import-actions {
	display: flex;
	align-items: center;
	gap: 14px;
	margin-top: 4px;
	padding-top: 14px;
	border-top: 1px solid #eee;
}
.wpq-import-progress-msg { color: #555; font-size: .9em; font-style: italic; }
</style>

<script>
(function ($) {
	'use strict';

	var nonce      = <?php echo json_encode( $nonce ); ?>;
	var files      = []; // [{name, payload, analysis, status:'reading|analysing|ready|importing|done|error', result}]
	var $drop      = $('#wpq-import-dropzone');
	var $fileIn    = $('#wpq-import-file');
	var $workspace = $('#wpq-import-workspace');

	// ------------------------------------------------------------------ //
	// Drop zone wiring
	// ------------------------------------------------------------------ //

	$('#wpq-import-browse').on('click', function () { $fileIn.trigger('click'); });

	$drop.on('click', function (e) {
		if (!$(e.target).is('button, input')) $fileIn.trigger('click');
	});

	$drop.on('dragover dragenter', function (e) {
		e.preventDefault(); e.stopPropagation();
		$drop.addClass('wpq-drag-over');
	}).on('dragleave dragend drop', function (e) {
		e.preventDefault(); e.stopPropagation();
		$drop.removeClass('wpq-drag-over');
		if (e.type === 'drop') {
			var dropped = e.originalEvent.dataTransfer.files;
			if (dropped && dropped.length) processFiles(dropped);
		}
	});

	$fileIn.on('change', function () {
		if (this.files && this.files.length) processFiles(this.files);
		this.value = ''; // reset so same files can be re-selected
	});

	// ------------------------------------------------------------------ //
	// Phase 1 - read files
	// ------------------------------------------------------------------ //

	function processFiles(fileList) {
		files = [];
		var total    = fileList.length;
		var readDone = 0;

		setWorkspace('<p class="wpq-status-spin">Reading ' + total + ' file(s)&hellip;</p>');

		var MAX_FILE_BYTES = 8 * 1024 * 1024; // 8 MB hard limit before reading

		for (var i = 0; i < total; i++) {
			(function (idx, file) {
				files.push({ name: file.name, payload: null, analysis: null, status: 'reading', result: null });

				if (file.size > MAX_FILE_BYTES) {
					var fileMB = (file.size / 1048576).toFixed(1);
					files[idx].status = 'error';
					files[idx].result = { error: file.name + ' is ' + fileMB + ' MB - too large to upload in a single request. '
						+ 'Use the individual batch files (wpq-library-csq-batch-01.json … 06.json, ~7 MB each) instead of the combined file.' };
					if (++readDone === total) analyseAll();
					return;
				}

				var reader = new FileReader();
				reader.onload = function (ev) {
					try {
						var p = JSON.parse(ev.target.result);
						if (!p || !p.wpq_export || !p.data) throw new Error('Not a WPQ Questionnaires export file.');
						files[idx].payload = p;
						files[idx].status  = 'analysing';
					} catch (err) {
						files[idx].status = 'error';
						files[idx].result = { error: err.message };
					}
					if (++readDone === total) analyseAll();
				};
				reader.onerror = function () {
					files[idx].status = 'error';
					files[idx].result = { error: 'File could not be read.' };
					if (++readDone === total) analyseAll();
				};
				reader.readAsText(file);
			})(i, fileList[i]);
		}
	}

	// ------------------------------------------------------------------ //
	// Phase 2 - analyse (sequential to avoid server overload)
	// ------------------------------------------------------------------ //

	function analyseAll() {
		var queue = files.filter(function (f) { return f.status === 'analysing'; });
		var idx   = 0;

		function next() {
			if (idx >= queue.length) { renderWorkspace(); return; }
			var f = queue[idx++];
			setWorkspace('<p class="wpq-status-spin">Analysing ' + esc(f.name) + '&hellip; (' + idx + ' of ' + queue.length + ')</p>');

			var payloadStr = JSON.stringify(f.payload);
			var sizeMB     = (payloadStr.length / 1048576).toFixed(1);
			if (payloadStr.length > 8 * 1024 * 1024) {
				f.status = 'error';
				f.result = { error: f.name + ' is ' + sizeMB + ' MB - too large for a single HTTP request '
					+ '(server limit is typically 8 MB). Use the individual batch files '
					+ '(wpq-library-csq-batch-01.json … 06.json, ~7 MB each) instead of the combined file.' };
				next();
				return;
			}

			$.post(ajaxurl, {
				action:  'wpq_import_analyse',
				nonce:   nonce,
				payload: payloadStr,
			}, function (res) {
				if (res.success) {
					f.analysis = res.data;
					f.status   = 'ready';
				} else {
					f.status = 'error';
					f.result = { error: res.data || 'Analysis failed.' };
				}
				next();
			}).fail(function (jqXHR, textStatus, errorThrown) {
				f.status = 'error';
				f.result = { error: httpError( jqXHR, textStatus, errorThrown, sizeMB ) };
				next();
			});
		}
		next();
	}

	// ------------------------------------------------------------------ //
	// Phase 3 - render conflict UI
	// ------------------------------------------------------------------ //

	function renderWorkspace() {
		var ready   = files.filter(function (f) { return f.status === 'ready'; });
		var errored = files.filter(function (f) { return f.status === 'error'; });
		var html    = '';

		// File-read / analysis errors
		if (errored.length) {
			html += '<div class="notice notice-error inline" style="margin-bottom:12px;"><ul>';
			errored.forEach(function (f) {
				html += '<li><strong>' + esc(f.name) + '</strong>: ' + esc(f.result.error) + '</li>';
			});
			html += '</ul></div>';
		}

		if (!ready.length) {
			setWorkspace(html + '<p>No valid files to import.</p>');
			return;
		}

		var totalRecords   = ready.reduce(function (n, f) { return n + (f.analysis.total || 0); }, 0);
		var totalConflicts = ready.reduce(function (n, f) { return n + (f.analysis.conflicts ? f.analysis.conflicts.length : 0); }, 0);

		html += '<p><strong>' + totalRecords + '</strong> record(s) across <strong>' + ready.length + '</strong> file(s)';
		if (totalConflicts) html += ' - <strong>' + totalConflicts + '</strong> conflict(s) to resolve';
		html += '.</p>';

		// Set-all bar (only when there are conflicts)
		if (totalConflicts) {
			html += '<div class="wpq-setall-bar">';
			html += '<span>Set all conflicts to:</span>';
			html += '<select id="wpq-setall-action">'
				+ '<option value="skip">Skip</option>'
				+ '<option value="overwrite">Overwrite</option>'
				+ '</select>';
			html += '<button type="button" class="button" id="wpq-setall-apply">Apply to all</button>';
			html += '</div>';
		}

		// Per-file sections
		ready.forEach(function (f, readyIdx) {
			var a       = f.analysis;
			var fileIdx = files.indexOf(f);
			var type    = a.type ? (a.type.charAt(0).toUpperCase() + a.type.slice(1)) : '';

			html += '<div class="wpq-file-section" data-file-idx="' + fileIdx + '">';
			html += '<div class="wpq-file-header">';
			html += '<strong>' + esc(f.name) + '</strong>';
			html += '<span class="wpq-file-meta">' + a.total + ' ' + type + '(s)';
			if (a.conflicts && a.conflicts.length) html += ', ' + a.conflicts.length + ' conflict(s)';
			if (a.clean_count > 0) html += ', ' + a.clean_count + ' clean';
			html += '</span>';
			html += '<span class="wpq-file-badge" id="wpq-badge-' + fileIdx + '"></span>';
			html += '</div>';

			html += '<div class="wpq-file-body" id="wpq-body-' + fileIdx + '">';

			if (a.errors && a.errors.length) {
				html += '<div class="notice notice-warning inline" style="margin-bottom:8px;"><ul>';
				a.errors.forEach(function (e) { html += '<li>' + esc(e) + '</li>'; });
				html += '</ul></div>';
			}

			if (a.conflicts && a.conflicts.length) {
				html += '<table class="wpq-conflict-table">';
				html += '<thead><tr><th>Record</th><th>Detail</th><th style="width:140px;">Action</th></tr></thead><tbody>';
				a.conflicts.forEach(function (c) {
					html += '<tr data-key="' + esc(c.key) + '">';
					html += '<td>' + esc(c.label) + '</td>';
					html += '<td>' + esc(c.detail) + '</td>';
					html += '<td class="wpq-conflict-resolution"><select>'
						+ '<option value="skip">Skip</option>'
						+ '<option value="overwrite">Overwrite</option>'
						+ '</select></td>';
					html += '</tr>';
				});
				html += '</tbody></table>';
			} else {
				html += '<p style="margin:0;font-size:.88em;color:#555;">No conflicts - will import cleanly.</p>';
			}

			html += '</div>'; // .wpq-file-body
			html += '</div>'; // .wpq-file-section
		});

		// Import actions bar
		html += '<div class="wpq-import-actions">';
		html += '<button type="button" class="button button-primary" id="wpq-import-apply">';
		html += 'Import ' + ready.length + ' file' + (ready.length !== 1 ? 's' : '');
		html += '</button>';
		html += '<span class="wpq-import-progress-msg" id="wpq-import-progress"></span>';
		html += '</div>';

		setWorkspace(html);
	}

	// ------------------------------------------------------------------ //
	// Set-all handler (delegated - works after dynamic render)
	// ------------------------------------------------------------------ //

	$workspace.on('click', '#wpq-setall-apply', function () {
		var val = $('#wpq-setall-action').val();
		$workspace.find('.wpq-conflict-resolution select').val(val);
	});

	// ------------------------------------------------------------------ //
	// Phase 4 - import (sequential per file)
	// ------------------------------------------------------------------ //

	$workspace.on('click', '#wpq-import-apply', function () {
		var $btn = $(this).prop('disabled', true).text('Importing…');
		$('#wpq-setall-apply').prop('disabled', true);
		var ready    = files.filter(function (f) { return f.status === 'ready'; });
		var queue    = ready.slice();
		var qIdx     = 0;
		var totImported = 0, totSkipped = 0, allErrors = [];

		function importNext() {
			if (qIdx >= queue.length) {
				renderDone(totImported, totSkipped, allErrors);
				return;
			}

			var f       = queue[qIdx++];
			var fileIdx = files.indexOf(f);
			var $badge  = $('#wpq-badge-' + fileIdx);
			var $body   = $('#wpq-body-'  + fileIdx);

			$badge.html('<span class="wpq-status-spin">⧗ importing…</span>');
			$('#wpq-import-progress').text('(' + qIdx + ' of ' + queue.length + ')');

			// Collect resolutions from this file's conflict table
			var resolutions = {};
			$('.wpq-file-section[data-file-idx="' + fileIdx + '"] tr[data-key]').each(function () {
				var key = $(this).data('key');
				resolutions[key] = $(this).find('.wpq-conflict-resolution select').val();
			});

			$.post(ajaxurl, {
				action:      'wpq_import_apply',
				nonce:       nonce,
				payload:     JSON.stringify(f.payload),
				resolutions: JSON.stringify(resolutions),
			}, function (res) {
				if (!res.success) {
					f.status = 'error';
					var msg  = res.data || 'Import failed.';
					$badge.html('<span class="wpq-status-err">✗ failed</span>');
					$body.prepend('<div class="notice notice-error inline" style="margin-bottom:8px;"><p>' + esc(msg) + '</p></div>');
					allErrors.push('[' + f.name + '] ' + msg);
					importNext();
					return;
				}

				var d = res.data;
				f.status = 'done';
				totImported += d.imported || 0;
				totSkipped  += d.skipped  || 0;

				// Update badge
				var badgeHtml = '<span class="wpq-status-ok">✓ ' + (d.imported || 0) + ' imported';
				if (d.skipped) badgeHtml += ', ' + d.skipped + ' skipped';
				badgeHtml += '</span>';
				$badge.html(badgeHtml);

				// Collapse the conflict table
				$body.find('.wpq-conflict-table').hide();
				$body.find('p').hide(); // "No conflicts" line

				// Show per-file errors (question-level failures)
				if (d.errors && d.errors.length) {
					var errHtml = '<div class="notice notice-error inline" style="margin:6px 0;"><details>'
						+ '<summary style="cursor:pointer;"><strong>' + d.errors.length + ' row error(s)</strong> in ' + esc(f.name) + ' - click to expand</summary>'
						+ '<ul style="margin:.5em 0 0 1em;">';
					d.errors.forEach(function (e) {
						errHtml += '<li>' + esc(e) + '</li>';
						allErrors.push('[' + f.name + '] ' + e);
					});
					errHtml += '</ul></details></div>';
					$body.prepend(errHtml);
				}

				importNext();

			}).fail(function (jqXHR, textStatus, errorThrown) {
				var msg = httpError( jqXHR, textStatus, errorThrown );
				f.status = 'error';
				$badge.html('<span class="wpq-status-err">✗ request failed</span>');
				$body.prepend('<div class="notice notice-error inline" style="margin-bottom:8px;"><p>' + esc(msg) + '</p></div>');
				allErrors.push('[' + f.name + '] ' + msg);
				importNext();
			});
		}

		importNext();
	});

	// ------------------------------------------------------------------ //
	// Phase 5 - done summary
	// ------------------------------------------------------------------ //

	function renderDone(imported, skipped, errors) {
		$('#wpq-import-apply').remove();
		$('#wpq-import-progress').remove();
		$('.wpq-setall-bar').hide();

		var html = '<div class="notice notice-success inline" style="margin-bottom:12px;"><p>';
		html += '<strong>' + imported + '</strong> record(s) imported';
		if (skipped) html += ', <strong>' + skipped + '</strong> skipped';
		html += ' across <strong>' + files.filter(function (f) { return f.status === 'done'; }).length + '</strong> file(s).';
		html += '</p></div>';

		if (errors.length) {
			html += '<div class="notice notice-error inline" style="margin-bottom:12px;"><details>'
				+ '<summary style="cursor:pointer;"><strong>' + errors.length + ' error(s) across all files</strong> - click to expand</summary>'
				+ '<ul style="margin:.5em 0 0 1em;">';
			errors.forEach(function (e) { html += '<li>' + esc(e) + '</li>'; });
			html += '</ul></details></div>';
		}

		$workspace.prepend(html);
	}

	// ------------------------------------------------------------------ //
	// Helpers
	// ------------------------------------------------------------------ //

	function setWorkspace(html) {
		$workspace.show().html(html);
	}

	function esc(str) {
		return $('<span>').text(String(str || '')).html();
	}

	function httpError(jqXHR, textStatus, errorThrown, sizeMB) {
		var status = jqXHR.status;
		if (status === 413) {
			return 'HTTP 413 - payload too large (' + (sizeMB || '?') + ' MB). '
				+ 'The server rejected the request before PHP ran. '
				+ 'Use smaller files (< 7 MB each) or raise client_max_body_size (nginx) / post_max_size (PHP).';
		}
		if (status === 0 || textStatus === 'timeout') {
			return 'Network error or request timeout - the server did not respond.';
		}
		var detail = 'HTTP ' + status + (errorThrown ? ' ' + errorThrown : '');
		var body   = (jqXHR.responseText || '').replace(/<[^>]+>/g, ' ').trim().substring(0, 300);
		if (body) detail += ' - ' + body;
		return detail;
	}

})(jQuery);
</script>
