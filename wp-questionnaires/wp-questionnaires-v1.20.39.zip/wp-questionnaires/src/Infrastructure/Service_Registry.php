<?php
declare(strict_types=1);

namespace Alltime\WPQ\Infrastructure;

use InvalidArgumentException;

final class Service_Registry {
	/** @var array<string,mixed> */
	private array $services = [];

	/**
	 * @param mixed $service Concrete service or factory result.
	 */
	public function set( string $id, $service ): void {
		$id = $this->normalise_id( $id );
		$this->services[ $id ] = $service;
	}

	public function has( string $id ): bool {
		return array_key_exists( $this->normalise_id( $id ), $this->services );
	}

	/**
	 * @return mixed
	 */
	public function get( string $id ) {
		$id = $this->normalise_id( $id );
		if ( ! array_key_exists( $id, $this->services ) ) {
			throw new InvalidArgumentException( 'Requested service is not registered.' );
		}

		return $this->services[ $id ];
	}

	public function remove( string $id ): void {
		unset( $this->services[ $this->normalise_id( $id ) ] );
	}

	public function clear(): void {
		$this->services = [];
	}

	private function normalise_id( string $id ): string {
		$id = trim( $id );
		if ( $id === '' ) {
			throw new InvalidArgumentException( 'Service id cannot be empty.' );
		}

		return $id;
	}
}
