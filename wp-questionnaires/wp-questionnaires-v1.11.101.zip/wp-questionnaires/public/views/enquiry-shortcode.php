<?php if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * @var object $form               The enquiry form row (published).
 * @var array  $wpq_enquiry_fields Sanitised field definitions.
 */
?>
<div class="wpq-root wpq-enquiry-root" data-wpq-enquiry-ref="<?php echo esc_attr( (string) $form->ref ); ?>">
  <div class="wpq-step">
    <div class="wpq-step-header">
      <h2><?php echo esc_html( (string) $form->name ); ?></h2>
      <?php if ( '' !== (string) $form->description ) : ?>
        <p class="wpq-desc"><?php echo esc_html( (string) $form->description ); ?></p>
      <?php endif; ?>
    </div>

    <form class="wpq-enquiry-form" novalidate>
      <div class="wpq-form-grid">
        <label>
          Name <span aria-hidden="true">*</span>
          <input type="text" name="contact_name" required maxlength="200" autocomplete="name">
        </label>
        <label>
          Email <span aria-hidden="true">*</span>
          <input type="email" name="contact_email" required maxlength="190" autocomplete="email">
        </label>
        <label>
          Company
          <input type="text" name="contact_company" maxlength="200" autocomplete="organization">
        </label>
        <label>
          Phone
          <input type="tel" name="contact_phone" maxlength="50" autocomplete="tel">
        </label>
      </div>

      <?php foreach ( $wpq_enquiry_fields as $wpq_field ) : ?>
        <div class="wpq-enquiry-field" data-field-key="<?php echo esc_attr( $wpq_field['key'] ); ?>" data-field-type="<?php echo esc_attr( $wpq_field['type'] ); ?>">
          <?php if ( 'checkbox' === $wpq_field['type'] ) : ?>
            <fieldset>
              <legend><?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?></legend>
              <?php foreach ( $wpq_field['options'] as $wpq_option ) : ?>
                <label class="wpq-checkbox-label">
                  <input type="checkbox" value="<?php echo esc_attr( $wpq_option ); ?>">
                  <?php echo esc_html( $wpq_option ); ?>
                </label>
              <?php endforeach; ?>
            </fieldset>
          <?php elseif ( 'select' === $wpq_field['type'] ) : ?>
            <label>
              <?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?>
              <select <?php echo $wpq_field['required'] ? 'required' : ''; ?>>
                <option value="">— Please choose —</option>
                <?php foreach ( $wpq_field['options'] as $wpq_option ) : ?>
                  <option value="<?php echo esc_attr( $wpq_option ); ?>"><?php echo esc_html( $wpq_option ); ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          <?php elseif ( 'textarea' === $wpq_field['type'] ) : ?>
            <label>
              <?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?>
              <textarea rows="4" maxlength="5000" <?php echo $wpq_field['required'] ? 'required' : ''; ?>></textarea>
            </label>
          <?php else : ?>
            <label>
              <?php echo esc_html( $wpq_field['label'] ); ?><?php echo $wpq_field['required'] ? ' *' : ''; ?>
              <input type="text" maxlength="500" <?php echo $wpq_field['required'] ? 'required' : ''; ?>>
            </label>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>

      <!-- Honeypot — hidden from humans; a bot that fills it is silently discarded -->
      <div class="wpq-hp" aria-hidden="true">
        <label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
      </div>

      <label class="wpq-consent">
        <input type="checkbox" name="consent" required>
        I consent to being contacted about this enquiry. <span aria-hidden="true">*</span>
      </label>

      <div class="wpq-form-footer">
        <button type="submit" class="wpq-btn wpq-btn-primary">Send enquiry</button>
      </div>
      <p class="wpq-enquiry-status" role="status" aria-live="polite"></p>
    </form>

    <div class="wpq-enquiry-done wpq-hidden">
      <h3>Thank you</h3>
      <p>Your enquiry has been received<span class="wpq-enquiry-done-ref"></span>. We will be in touch.</p>
    </div>
  </div>
</div>
